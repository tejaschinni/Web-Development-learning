import 'dart:developer';

import 'package:dio/dio.dart';
import 'package:flutter/widgets.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/features/seller/data/models/certificate_model.dart';
import 'package:society_seva/features/seller/data/models/kyc_docment_model.dart';
import 'package:society_seva/features/seller/data/models/seller_image_model.dart';
import 'package:society_seva/features/seller/data/models/seller_profile_model.dart';
import 'package:society_seva/features/seller/data/models/request/seller_profile_request.dart';

abstract class SellerOnboardingRemoteDataSource {
  Future<SellerProfileModel?> createAndSaveAsDraftDataSource({
    required SellerProfileRequest request,
  });
  Future<SellerProfileModel?> submitDartDataSource({required String sellerId});
  Future<void> uploadSellerShopImagesDataSource(String sellerId, XFile file);
  Future<List<SellerImageModel>> fetchSellerUploadedImagesDataSource(String sellerId);
  Future<SellerProfileModel?> mySellerProfileDataSource();
  Future<SellerProfileModel?> fetchSellerProfileByIDDataSource(String sellerID);
  Future<SellerProfileModel?> updateProfileDataSource({
    required SellerProfileRequest request,
    required String sellerID,
  });
  Future<void> deleteUploadedSellerImagesDataSource({
    required String sellerID,
    required String imageId,
  });

  Future<CertificateModel?> uploadCertificateDataSource({
    required String sellerId,
    required XFile file,
    required String certificateName,
    required String certificateType,
    required DateTime issueDate,
    required bool hasExpiry,
    required String issueAuthority,
    required String certificateNumber,
    DateTime? expiryDate,
  });

  Future<List<CertificateModel>> fetchCertificatesDataSource(String sellerId);

  Future<List<KycDocumentModel>> fetchKychDocumentDataSource(String sellerId);

  Future<bool> uploadKYCDocumentDataSource({
    required XFile file,
    required String documentType,
    required String documentNumber,
    required String sellerId,
  });

  /// Downloads a previously uploaded KYC document's file content.
  Future<String> downloadKycDocumentFileDataSource({
    required String sellerId,
    required String documentFileUrl,
  });
}

class SellerOnboardingRemoteDataSourceImpl implements SellerOnboardingRemoteDataSource {
  SellerOnboardingRemoteDataSourceImpl({required this._apiClient});

  final ApiClient _apiClient;

  @override
  Future<SellerProfileModel?> createAndSaveAsDraftDataSource({
    required SellerProfileRequest request,
  }) async {
    try {
      final response = await _apiClient.post(
        ApiEndpoints.createSellerProfile,
        data: request.toJson(),
      );
      return SellerProfileModel.fromJson(response.data);
    } on DioException catch (e) {
      if (e.response?.statusCode == 404) return null;
      rethrow;
    }
  }

  /// DELETE /api/v1/sellers/{sellerID}/images/{imageId}
  @override
  Future<void> deleteUploadedSellerImagesDataSource({
    required String sellerID,
    required String imageId,
  }) async {
    try {
      // Was previously hitting the wrong path (missing the '/images/' segment).
      await _apiClient.delete(ApiEndpoints.deleteImages(sellerID, imageId));
    } on DioException catch (e) {
      debugPrint("Dio Exceoption on delete images ${e.error}");
    }
  }

  @override
  Future<SellerProfileModel?> fetchSellerProfileByIDDataSource(String sellerID) async {
    try {
      final response = await _apiClient.get(ApiEndpoints.sellerByID(sellerID));
      return SellerProfileModel.fromJson(response.data);
    } on DioException catch (e) {
      if (e.response?.statusCode == 404) return null;
      rethrow;
    }
  }

  @override
  Future<List<SellerImageModel>> fetchSellerUploadedImagesDataSource(String sellerId) async {
    final response = await _apiClient.get(ApiEndpoints.fetchSellerImages(sellerId));

    final List<dynamic> data = response.data as List<dynamic>;
    return data.map((item) => SellerImageModel.fromJson(item as Map<String, dynamic>)).toList();
  }

  @override
  Future<SellerProfileModel?> mySellerProfileDataSource() async {
    try {
      final response = await _apiClient.get(ApiEndpoints.sellerProfile);
      return SellerProfileModel.fromJson(response.data);
    } on DioException catch (e) {
      if (e.response?.statusCode == 404) return null;
      rethrow;
    }
  }

  @override
  Future<SellerProfileModel?> submitDartDataSource({required String sellerId}) async {
    try {
      final response = await _apiClient.post(ApiEndpoints.submitSellerProfile(sellerId));
      return SellerProfileModel.fromJson(response.data);
    } on DioException catch (e) {
      if (e.response?.statusCode == 404) return null;
      rethrow;
    }
  }

  @override
  Future<SellerProfileModel?> updateProfileDataSource({
    required SellerProfileRequest request,
    required String sellerID,
  }) async {
    try {
      final response = await _apiClient.patch(
        '${ApiEndpoints.createSellerProfile}/$sellerID',
        data: request.toJson(),
      );
      return SellerProfileModel.fromJson(response.data);
    } on DioException catch (e) {
      if (e.response?.statusCode == 404) return null;
      rethrow;
    }
  }

  @override
  Future<void> uploadSellerShopImagesDataSource(String sellerId, XFile file) async {
    final form = FormData();

    form.files.add(MapEntry('file', await MultipartFile.fromFile(file.path, filename: file.name)));

    final response = await _apiClient.post(ApiEndpoints.fetchSellerImages(sellerId), data: form);
  }

  @override
  Future<List<CertificateModel>> fetchCertificatesDataSource(String sellerId) async {
    final response = await _apiClient.get(ApiEndpoints.certificate(sellerId));
    final List<dynamic> data = response.data as List<dynamic>;
    return data.map((item) => CertificateModel.fromJson(item as Map<String, dynamic>)).toList();
  }

  @override
  Future<CertificateModel?> uploadCertificateDataSource({
    required String sellerId,
    required XFile file,
    required String certificateName,
    required String certificateType,
    required DateTime issueDate,
    required bool hasExpiry,
    required String issueAuthority,
    required String certificateNumber,
    DateTime? expiryDate,
  }) async {
    try {
      final form = FormData();
      final dateFromate = DateFormat('yyyy-MM-dd');
      form.files.add(
        MapEntry('file', await MultipartFile.fromFile(file.path, filename: file.name)),
      );
      final formData = FormData.fromMap({
        'file': await MultipartFile.fromFile(file.path, filename: file.name),
        'certificateType': certificateType,
        'certificateName': certificateName,
        'certificateNumber': certificateNumber,
        'issuingAuthority': issueAuthority,
        'issueDate': dateFromate.format(issueDate),
        'expiryDate': hasExpiry ? dateFromate.format(expiryDate!) : null,
      });

      // Text fields
      for (final field in formData.fields) {
        log('FIELD  ${field.key}: ${field.value}');
      }

      // Files
      for (final file in formData.files) {
        final f = file.value;
        log(
          'FILE   ${file.key}: filename=${f.filename}, '
          'length=${f.length}, contentType=${f.contentType}',
        );
      }
      final response = await _apiClient.post(ApiEndpoints.certificate(sellerId), data: formData);

      if (response.statusCode == 200) {
        CertificateModel model = CertificateModel.fromJson(response.data);
        return model;
      }

      return null;
    } catch (e) {
      rethrow;
    }
  }

  @override
  Future<List<KycDocumentModel>> fetchKychDocumentDataSource(String sellerId) async {
    final response = await _apiClient.get(ApiEndpoints.fetchKycDocument(sellerId));

    final List<dynamic> data = response.data as List<dynamic>;
    return data.map((item) => KycDocumentModel.fromJson(item as Map<String, dynamic>)).toList();
  }

  @override
  Future<bool> uploadKYCDocumentDataSource({
    required XFile file,
    required String documentType,
    required String documentNumber,
    required String sellerId,
  }) async {
    try {
      final formData = FormData.fromMap({
        'file': await MultipartFile.fromFile(file.path, filename: file.name),
        'documentType': documentType,
        'documentNumber': documentNumber,
      });

      final response = await _apiClient.post(
        ApiEndpoints.uploadKycDocument(sellerId),
        data: formData,
      );

      if (response.statusCode == 200) {
        KycDocumentModel kycDocumentModel = KycDocumentModel.fromJson(response.data);
        if (kycDocumentModel.verificationStatus.toLowerCase() == "pending") {
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    } catch (e) {
      return false;
    }
  }

  /// GET /api/v1/sellers/{sellerId}/kyc/{documentFileUrl}/file
  ///
  /// Returns the document's file content as a base64 string (per the API
  /// doc). STATIC FOR NOW: returns a placeholder base64 string instead of
  /// calling the backend. To go live, delete the static return below and
  /// uncomment the real call.
  @override
  Future<String> downloadKycDocumentFileDataSource({
    required String sellerId,
    required String documentFileUrl,
  }) async {
    // final response = await _apiClient.get(
    //   ApiEndpoints.kycDocumentFile(sellerId, documentFileUrl),
    // );
    // return response.data as String;

    // Tiny 1x1 transparent PNG, base64 encoded - static placeholder only.
    return 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=';
  }
}
