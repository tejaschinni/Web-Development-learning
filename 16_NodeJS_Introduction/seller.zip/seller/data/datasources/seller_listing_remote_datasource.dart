import 'dart:developer';

import 'package:dio/dio.dart';
import 'package:image_picker/image_picker.dart';
import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/seller/data/models/food_detail_model.dart';
import 'package:society_seva/features/seller/data/models/request/food_additinal_information_request.dart';
import 'package:society_seva/features/seller/data/models/request/seller_listing_basic_info_request.dart';
import 'package:society_seva/features/seller/data/models/request/service_additional_information_request.dart';
import 'package:society_seva/features/seller/data/models/seller_listing_image_model.dart';
import 'package:society_seva/features/seller/data/models/seller_listing_model.dart';
import 'package:society_seva/features/seller/data/models/service_detail_model.dart';
import 'package:society_seva/features/seller/data/models/service_slot_model.dart';

abstract class SellerListingRemoteDatasource {
  Future<PageResponse<SellerListingModel>> fetchMyListingDataSource({required String sellerId});

  Future<SellerListingModel> fetchListingByIdDataSource({required String listingID});

  Future<List<SellerListingImageModel>> getListingImagesDataSource(String listingId);

  Future<SellerListingModel?> createListingDataSource({
    required SellerListingBasicInfoRequest request,
  });

  Future<SellerListingModel?> submitListingDataSource({required String listingId});

  Future<SellerListingModel?> updatesubmitListingDataSource({
    required String listingId,
    required SellerListingBasicInfoRequest request,
  });

  Future<SellerListingImageModel> uploadSellerShopImagesDataSource(String sellerId, XFile file);

  Future<bool> additionalFoodInformationDataSource({
    required FoodAdditinalInformationRequest request,
    required String listingId,
  });

  Future<bool> additionalServiceInformationDataSource({
    required ServiceAdditionalInformationRequest request,
    required String listingId,
  });

  Future<FoodListingDetailsModel?> updateadditionalFoodInformationDataSource({
    required FoodAdditinalInformationRequest request,
    required String listingId,
  });

  Future<ServiceListingDetailsModel?> updateadditionalServiceInformationDataSource({
    required ServiceAdditionalInformationRequest request,
    required String listingId,
  });

  Future<FoodListingDetailsModel> detchadditionalFoodInformationDataSource({
    required String listingId,
  });

  Future<ServiceListingDetailsModel> fetchadditionalServiceInformationDataSource({
    required String listingId,
  });

  /// PUT /api/v1/service-schedules/listings/{listingId}/availability/{date}
  /// Replaces the whole day's availability windows - safe to resend on every
  /// save. `windows` is a list of `{"startsAt": "HH:mm", "endsAt": "HH:mm"}`.
  Future<List<ServiceSlotModel>> saveServiceSlotsDataSource({
    required String listingId,
    required String date,
    required List<Map<String, String>> windows,
  });

  /// DELETE /api/v1/service-schedules/listings/{listingId}/availability/{date}
  Future<void> deleteServiceSlotsDataSource({required String listingId, required String date});

  /// DELETE /api/v1/listings/{listingId}/images/{imageId}
  Future<void> deleteListingImageDataSource({required String listingId, required String imageId});
}

class SellerListingRemoteDataSourceImpl implements SellerListingRemoteDatasource {
  SellerListingRemoteDataSourceImpl(this._apiClient);
  final ApiClient _apiClient;
  @override
  Future<PageResponse<SellerListingModel>> fetchMyListingDataSource({
    required String sellerId,
  }) async {
    final queryParameters = {'sellerId': sellerId};
    log(
      '[SellerListingDataSource] GET ${ApiEndpoints.myListing} '
      'queryParameters: $queryParameters',
    );
    final response = await _apiClient.get(
      ApiEndpoints.myListing,
      queryParameters: queryParameters,
    );
    return PageResponse.fromJson(
      Map<String, dynamic>.from(response.data as Map),
      SellerListingModel.fromJson,
    );
  }

  @override
  Future<List<SellerListingImageModel>> getListingImagesDataSource(String listingId) async {
    log('[SellerListingDataSource] GET ${ApiEndpoints.listingImages(listingId)}');
    final response = await _apiClient.get(ApiEndpoints.listingImages(listingId));
    final images = response.data as List<dynamic>? ?? const [];
    return images
        .whereType<Map>()
        .map((image) => SellerListingImageModel.fromJson(Map<String, dynamic>.from(image)))
        .toList()
      ..sort((a, b) => a.displayOrder.compareTo(b.displayOrder));
  }

  @override
  Future<SellerListingModel?> createListingDataSource({
    required SellerListingBasicInfoRequest request,
  }) async {
    final payload = request.toJson();
    log('[SellerListingDataSource] POST ${ApiEndpoints.listings} payload: $payload');
    try {
      final response = await _apiClient.post(ApiEndpoints.listings, data: payload);
      return SellerListingModel.fromJson(response.data);
    } on DioException catch (e) {
      if (e.response?.statusCode == 404) return null;
      rethrow;
    }
  }

  @override
  Future<SellerListingImageModel> uploadSellerShopImagesDataSource(
    String listingId,
    XFile file,
  ) async {
    final form = FormData();
    form.files.add(MapEntry('file', await MultipartFile.fromFile(file.path, filename: file.name)));
    form.fields.add(const MapEntry('displayOrder', '1'));
    log(
      '[SellerListingDataSource] POST ${ApiEndpoints.listingImages(listingId)} '
      'payload: file=${file.path}, fields=${form.fields}',
    );
    final response = await _apiClient.post(ApiEndpoints.listingImages(listingId), data: form);
    SellerListingImageModel model = SellerListingImageModel.fromJson(response.data);
    return model;
  }

  @override
  Future<bool> additionalFoodInformationDataSource({
    required FoodAdditinalInformationRequest request,
    required String listingId,
  }) async {
    final payload = request.toJson();
    log(
      '[SellerListingDataSource] POST ${ApiEndpoints.listingFoodDetails(listingId)} '
      'payload: $payload',
    );
    try {
      final response = await _apiClient.post(
        ApiEndpoints.listingFoodDetails(listingId),
        data: payload,
      );
      if (response.statusCode == 200) {
        return true;
      } else {
        return false;
      }
    } on DioException catch (e) {
      if (e.response?.statusCode == 404) return false;
      rethrow;
    }
  }

  @override
  Future<bool> additionalServiceInformationDataSource({
    required ServiceAdditionalInformationRequest request,
    required String listingId,
  }) async {
    final payload = request.toJson();
    log(
      '[SellerListingDataSource] POST ${ApiEndpoints.listingServiceDetails(listingId)} '
      'payload: $payload',
    );
    try {
      final response = await _apiClient.post(
        ApiEndpoints.listingServiceDetails(listingId),
        data: payload,
      );
      if (response.statusCode == 200) {
        return true;
      } else {
        return false;
      }
    } on DioException catch (e) {
      if (e.response?.statusCode == 404) return false;
      rethrow;
    }
  }

  @override
  Future<SellerListingModel?> submitListingDataSource({required String listingId}) async {
    log('[SellerListingDataSource] POST ${ApiEndpoints.submitlistings(listingId)}');
    try {
      final response = await _apiClient.post(ApiEndpoints.submitlistings(listingId));
      return SellerListingModel.fromJson(response.data);
    } on DioException catch (e) {
      if (e.response?.statusCode == 404) return null;
      rethrow;
    }
  }

  @override
  Future<SellerListingModel?> updatesubmitListingDataSource({
    required String listingId,
    required SellerListingBasicInfoRequest request,
  }) async {
    final payload = request.toJson();
    log('[SellerListingDataSource] PATCH ${ApiEndpoints.listing(listingId)} payload: $payload');
    try {
      final response = await _apiClient.patch(
        ApiEndpoints.listing(listingId),
        data: payload,
      );
      return SellerListingModel.fromJson(response.data);
    } on DioException catch (e) {
      if (e.response?.statusCode == 404) return null;
      rethrow;
    }
  }

  @override
  Future<SellerListingModel> fetchListingByIdDataSource({required String listingID}) async {
    log('[SellerListingDataSource] GET ${ApiEndpoints.listing(listingID)}');
    final response = await _apiClient.get(ApiEndpoints.listing(listingID));
    return SellerListingModel.fromJson(response.data);
  }

  @override
  Future<FoodListingDetailsModel> detchadditionalFoodInformationDataSource({
    required String listingId,
  }) async {
    log('[SellerListingDataSource] GET ${ApiEndpoints.listingFoodDetails(listingId)}');
    final response = await _apiClient.get(ApiEndpoints.listingFoodDetails(listingId));
    return FoodListingDetailsModel.fromJson(response.data);
  }

  @override
  Future<ServiceListingDetailsModel> fetchadditionalServiceInformationDataSource({
    required String listingId,
  }) async {
    log('[SellerListingDataSource] GET ${ApiEndpoints.listingServiceDetails(listingId)}');
    final response = await _apiClient.get(ApiEndpoints.listingServiceDetails(listingId));
    return ServiceListingDetailsModel.fromJson(response.data);
  }

  @override
  Future<FoodListingDetailsModel?> updateadditionalFoodInformationDataSource({
    required FoodAdditinalInformationRequest request,
    required String listingId,
  }) async {
    final payload = request.toJson();
    log(
      '[SellerListingDataSource] PATCH ${ApiEndpoints.listingFoodDetails(listingId)} '
      'payload: $payload',
    );
    try {
      final response = await _apiClient.patch(
        ApiEndpoints.listingFoodDetails(listingId),
        data: payload,
      );
      if (response.statusCode == 200) {
        return FoodListingDetailsModel.fromJson(response.data);
      } else {
        return null;
      }
    } on DioException catch (e) {
      if (e.response?.statusCode == 404) return null;
      rethrow;
    }
  }

  @override
  Future<ServiceListingDetailsModel?> updateadditionalServiceInformationDataSource({
    required ServiceAdditionalInformationRequest request,
    required String listingId,
  }) async {
    final payload = request.toJson();
    log(
      '[SellerListingDataSource] PATCH ${ApiEndpoints.listingServiceDetails(listingId)} '
      'payload: $payload',
    );
    try {
      final response = await _apiClient.patch(
        ApiEndpoints.listingServiceDetails(listingId),
        data: payload,
      );
      if (response.statusCode == 200) {
        return ServiceListingDetailsModel.fromJson(response.data);
      } else {
        return null;
      }
    } on DioException catch (e) {
      if (e.response?.statusCode == 404) return null;
      rethrow;
    }
  }

  /// PUT /api/v1/service-schedules/listings/{listingId}/availability/{date}
  ///
  /// STATIC FOR NOW: returns the windows the caller sent, converted into the
  /// shape the real response would have (with a made-up `durationMinutes`
  /// and `timeZone`), instead of calling the backend. To go live, delete the
  /// static block below and uncomment the real call.
  @override
  Future<List<ServiceSlotModel>> saveServiceSlotsDataSource({
    required String listingId,
    required String date,
    required List<Map<String, String>> windows,
  }) async {
    final endpoint = ApiEndpoints.serviceAvailability(listingId, date);
    final payload = {'windows': windows};
    log('[SellerListingDataSource] PUT $endpoint payload: $payload');

    // final response = await _apiClient.put(endpoint, data: payload);
    // final data = response.data as List<dynamic>;
    // return data
    //     .map((item) => ServiceSlotModel.fromJson(Map<String, dynamic>.from(item)))
    //     .toList();

    return windows.map((w) {
      final start = DateTime.parse('${date}T${w['startsAt']}:00');
      final end = DateTime.parse('${date}T${w['endsAt']}:00');
      return ServiceSlotModel(
        startsAt: start,
        endsAt: end,
        durationMinutes: end.difference(start).inMinutes,
        timeZone: 'Asia/Kolkata',
        status: 'AVAILABLE',
      );
    }).toList();
  }

  /// DELETE /api/v1/service-schedules/listings/{listingId}/availability/{date}
  ///
  /// STATIC FOR NOW: no-op success instead of an actual network call.
  @override
  Future<void> deleteServiceSlotsDataSource({required String listingId, required String date}) async {
    final endpoint = ApiEndpoints.serviceAvailability(listingId, date);
    log('[SellerListingDataSource] DELETE $endpoint');

    // await _apiClient.delete(endpoint);
  }

  /// DELETE /api/v1/listings/{listingId}/images/{imageId}
  ///
  /// STATIC FOR NOW: no-op success instead of an actual network call.
  @override
  Future<void> deleteListingImageDataSource({
    required String listingId,
    required String imageId,
  }) async {
    final endpoint = ApiEndpoints.listingImageById(listingId, imageId);
    log('[SellerListingDataSource] DELETE $endpoint');

    // await _apiClient.delete(endpoint);
  }
}
