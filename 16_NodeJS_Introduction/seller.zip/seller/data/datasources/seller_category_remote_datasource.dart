import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/seller/data/models/seller_category_model.dart';
import 'package:society_seva/features/shop/data/models/shop_category_model.dart';

abstract class SellerCategoryRemoteDatasource {
  Future<PageResponse<CategoriesModel>> fetchCategoriesDataSource({
    String? categoryType,
    String? parentCategoryId,
    bool? rootsOnly,
    String? search,
  });

  Future<List<ShopCategoryModel>> fetchCategoriesTreeDataSouce({String? categoryType});
}

class SellerCategoryRemoteDatasourceImpl implements SellerCategoryRemoteDatasource {
  SellerCategoryRemoteDatasourceImpl(this._apiClient);
  final ApiClient _apiClient;
  @override
  Future<PageResponse<CategoriesModel>> fetchCategoriesDataSource({
    String? categoryType,
    String? parentCategoryId,
    bool? rootsOnly,
    String? search,
  }) async {
    final response = await _apiClient.get(
      ApiEndpoints.allcategory,
      queryParameters: {
        'isActive': true,
        'categoryType': categoryType,
        'parentCategoryId': parentCategoryId,
        'rootsOnly': rootsOnly,
        'search': search,
      },
    );
    return PageResponse.fromJson(
      Map<String, dynamic>.from(response.data as Map),
      CategoriesModel.fromJson,
    );
  }

  @override
  Future<List<ShopCategoryModel>> fetchCategoriesTreeDataSouce({String? categoryType}) async {
    final response = await _apiClient.get(
      ApiEndpoints.categoryTree,
      queryParameters: {'isActive': true, 'categoryType': categoryType},
    );

    final data = response.data;
    if (data is! List) {
      throw const FormatException('Invalid category tree response: expected a JSON array.');
    }
    return data
        .whereType<Map>()
        .map((item) => ShopCategoryModel.fromJson(Map<String, dynamic>.from(item)))
        .toList(growable: false);
  }
}
