import 'dart:developer';

import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/seller/data/models/seller_order_model.dart';

abstract class SellerOrderRemoteDataSource {
  /// GET /api/v1/orders?sellerId={sellerId}
  Future<PageResponse<SellerOrderModel>> fetchSellerOrdersDataSource({required String sellerId});

  /// POST /api/v1/orders/{orderId}/transition
  Future<SellerOrderModel> transitionOrderDataSource({
    required String orderId,
    required String newStatus,
    String? note,
  });
}

final _staticOrders = <SellerOrderModel>[
  SellerOrderModel(
    id: 'mock-order-1',
    orderNumber: 'ORD-20260101-AB12CD',
    buyerId: 'mock-buyer-1',
    sellerId: 'mock-seller-1',
    orderType: 'FOOD_ORDER',
    orderStatus: 'PAID',
    subtotalAmount: 300,
    discountAmount: 0,
    platformCommission: 30,
    welfareFundAmount: 15,
    sellerEarning: 255,
    totalAmount: 300,
    paymentStatus: 'PAID',
    items: const [
      SellerOrderItemModel(
        id: 'mock-order-item-1',
        listingId: 'mock-listing-1',
        titleSnapshot: 'Homemade Veg Thali',
        quantity: 2,
        unitPrice: 150,
        totalPrice: 300,
      ),
    ],
    createdAt: DateTime(2026, 1, 1, 12, 30),
  ),
  SellerOrderModel(
    id: 'mock-order-2',
    orderNumber: 'ORD-20260102-EF34GH',
    buyerId: 'mock-buyer-2',
    sellerId: 'mock-seller-1',
    orderType: 'PRODUCT_ORDER',
    orderStatus: 'PREPARING',
    subtotalAmount: 700,
    discountAmount: 0,
    platformCommission: 70,
    welfareFundAmount: 35,
    sellerEarning: 595,
    totalAmount: 700,
    paymentStatus: 'PAID',
    items: const [
      SellerOrderItemModel(
        id: 'mock-order-item-2',
        listingId: 'mock-listing-3',
        titleSnapshot: 'Handmade Chocolate Box (12 pcs)',
        quantity: 2,
        unitPrice: 350,
        totalPrice: 700,
      ),
    ],
    createdAt: DateTime(2026, 1, 2, 9, 0),
  ),
  SellerOrderModel(
    id: 'mock-order-3',
    orderNumber: 'ORD-20260103-IJ56KL',
    buyerId: 'mock-buyer-3',
    sellerId: 'mock-seller-1',
    orderType: 'SERVICE_BOOKING',
    orderStatus: 'COMPLETED',
    subtotalAmount: 500,
    discountAmount: 50,
    platformCommission: 45,
    welfareFundAmount: 22.5,
    sellerEarning: 382.5,
    totalAmount: 450,
    paymentStatus: 'PAID',
    items: const [
      SellerOrderItemModel(
        id: 'mock-order-item-3',
        listingId: 'mock-listing-2',
        titleSnapshot: 'Home Tutoring - Maths & Science',
        quantity: 1,
        unitPrice: 500,
        totalPrice: 500,
      ),
    ],
    createdAt: DateTime(2026, 1, 3, 16, 0),
  ),
];

class SellerOrderRemoteDataSourceImpl implements SellerOrderRemoteDataSource {
  SellerOrderRemoteDataSourceImpl(this._apiClient);

  // Not called yet - both methods below are static for now. Kept so the
  // real `_apiClient.get/post` calls (commented out in each method) can be
  // switched on without changing the constructor signature.
  // ignore: unused_field
  final ApiClient _apiClient;

  /// GET /api/v1/orders?sellerId={sellerId}
  ///
  /// STATIC FOR NOW: returns a fixed list of sample orders instead of
  /// calling the backend. To go live, delete the static return below and
  /// uncomment the real call.
  @override
  Future<PageResponse<SellerOrderModel>> fetchSellerOrdersDataSource({
    required String sellerId,
  }) async {
    log('[SellerOrderDataSource] GET ${ApiEndpoints.orders} queryParameters: {sellerId: $sellerId}');

    // final response = await _apiClient.get(
    //   ApiEndpoints.orders,
    //   queryParameters: {'sellerId': sellerId},
    // );
    // return PageResponse.fromJson(
    //   Map<String, dynamic>.from(response.data as Map),
    //   SellerOrderModel.fromJson,
    // );

    return PageResponse<SellerOrderModel>(
      content: _staticOrders,
      page: 0,
      size: _staticOrders.length,
      totalElements: _staticOrders.length,
      totalPages: 1,
      first: true,
      last: true,
    );
  }

  /// POST /api/v1/orders/{orderId}/transition
  ///
  /// STATIC FOR NOW: returns the matching sample order with `orderStatus`
  /// swapped to `newStatus`, instead of calling the backend. To go live,
  /// delete the static block below and uncomment the real call.
  @override
  Future<SellerOrderModel> transitionOrderDataSource({
    required String orderId,
    required String newStatus,
    String? note,
  }) async {
    final payload = {'newStatus': newStatus, 'note': note ?? 'na'};
    log('[SellerOrderDataSource] POST ${ApiEndpoints.orderTransition(orderId)} payload: $payload');

    // final response = await _apiClient.post(
    //   ApiEndpoints.orderTransition(orderId),
    //   data: payload,
    // );
    // return SellerOrderModel.fromJson(response.data as Map<String, dynamic>);

    final existing = _staticOrders.firstWhere(
      (o) => o.id == orderId,
      orElse: () => _staticOrders.first,
    );
    return SellerOrderModel(
      id: existing.id,
      orderNumber: existing.orderNumber,
      buyerId: existing.buyerId,
      sellerId: existing.sellerId,
      orderType: existing.orderType,
      orderStatus: newStatus,
      subtotalAmount: existing.subtotalAmount,
      discountAmount: existing.discountAmount,
      platformCommission: existing.platformCommission,
      welfareFundAmount: existing.welfareFundAmount,
      sellerEarning: existing.sellerEarning,
      totalAmount: existing.totalAmount,
      paymentStatus: existing.paymentStatus,
      items: existing.items,
      createdAt: existing.createdAt,
    );
  }
}
