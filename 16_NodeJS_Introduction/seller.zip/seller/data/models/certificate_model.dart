import '../../domain/entities/certificate_entity.dart';

class CertificateModel {
  final String id;
  final String sellerId;
  final String certificateType;
  final String certificateName;
  final String issuingAuthority;
  final String certificateFileUrl;
  final String verificationStatus;
  final DateTime createdAt;
  final DateTime updatedAt;

  const CertificateModel({
    required this.id,
    required this.sellerId,
    required this.certificateType,
    required this.certificateName,
    required this.issuingAuthority,
    required this.certificateFileUrl,
    required this.verificationStatus,
    required this.createdAt,
    required this.updatedAt,
  });

  factory CertificateModel.fromJson(Map<String, dynamic> json) {
    return CertificateModel(
      id: json['id'] as String,
      sellerId: json['sellerId'] as String,
      certificateType: json['certificateType'] as String,
      certificateName: json['certificateName'] as String,
      issuingAuthority: json['issuingAuthority'] as String,
      certificateFileUrl: json['certificateFileUrl'] as String,
      verificationStatus: json['verificationStatus'] as String,
      createdAt: DateTime.parse(json['createdAt'] as String),
      updatedAt: DateTime.parse(json['updatedAt'] as String),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'sellerId': sellerId,
      'certificateType': certificateType,
      'certificateName': certificateName,
      'issuingAuthority': issuingAuthority,
      'certificateFileUrl': certificateFileUrl,
      'verificationStatus': verificationStatus,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
    };
  }

  CertificateEntity toEntity() {
    return CertificateEntity(
      id: id,
      sellerId: sellerId,
      certificateType: certificateType,
      certificateName: certificateName,
      issuingAuthority: issuingAuthority,
      certificateFileUrl: certificateFileUrl,
      verificationStatus: verificationStatus,
      createdAt: createdAt,
      updatedAt: updatedAt,
    );
  }

  factory CertificateModel.fromEntity(CertificateEntity entity) {
    return CertificateModel(
      id: entity.id,
      sellerId: entity.sellerId,
      certificateType: entity.certificateType,
      certificateName: entity.certificateName,
      issuingAuthority: entity.issuingAuthority,
      certificateFileUrl: entity.certificateFileUrl,
      verificationStatus: entity.verificationStatus,
      createdAt: entity.createdAt,
      updatedAt: entity.updatedAt,
    );
  }

  CertificateModel copyWith({
    String? id,
    String? sellerId,
    String? certificateType,
    String? certificateName,
    String? issuingAuthority,
    String? certificateFileUrl,
    String? verificationStatus,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return CertificateModel(
      id: id ?? this.id,
      sellerId: sellerId ?? this.sellerId,
      certificateType: certificateType ?? this.certificateType,
      certificateName: certificateName ?? this.certificateName,
      issuingAuthority: issuingAuthority ?? this.issuingAuthority,
      certificateFileUrl: certificateFileUrl ?? this.certificateFileUrl,
      verificationStatus: verificationStatus ?? this.verificationStatus,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}
