import 'package:society_seva/features/seller/domain/entities/food_detail_entity.dart';

class FoodListingDetailsModel extends FoodListingDetailsEntity {
  const FoodListingDetailsModel({
    required super.id,
    required super.listingId,
    super.preparationTime,
    super.spiceLevel,
    super.spiceLevelText,
    super.freshnessDeclaration,
    super.isFrozenItem,
    super.fssaiRequired,
    super.expiryTime,
    super.ingredients,
    super.allergens,
    super.foodType,
    super.storageInstruction,
    super.packagingDetails,
    super.fssaiCertificateId,
    super.servingSizes,
  });

  factory FoodListingDetailsModel.fromJson(Map<String, dynamic> json) {
    return FoodListingDetailsModel(
      id: json['id']?.toString() ?? '',
      listingId: json['listingId']?.toString() ?? '',
      preparationTime: json['preparationTime']?.toString(),
      spiceLevel: (json['spiceLevel'] as num?)?.toInt(),
      spiceLevelText: json['spiceLevelText']?.toString(),
      freshnessDeclaration: json['freshnessDeclaration']?.toString(),
      isFrozenItem: json['isFrozenItem'] as bool?,
      fssaiRequired: json['fssaiRequired'] as bool?,
      expiryTime: json['expiryTime']?.toString(),
      ingredients: json['ingredients']?.toString(),
      allergens: json['allergens']?.toString(),
      foodType: json['foodType']?.toString(),
      storageInstruction: json['storageInstruction']?.toString(),
      packagingDetails: json['packagingDetails']?.toString(),
      fssaiCertificateId: json['fssaiCertificateId']?.toString(),
      servingSizes:
          (json['servingSizes'] as List<dynamic>?)
              ?.map((item) => ServingSizeModel.fromJson(item as Map<String, dynamic>))
              .toList() ??
          [],
    );
  }

  factory FoodListingDetailsModel.fromEntity(FoodListingDetailsEntity entity) {
    return FoodListingDetailsModel(
      id: entity.id,
      listingId: entity.listingId,
      preparationTime: entity.preparationTime,
      spiceLevel: entity.spiceLevel,
      spiceLevelText: entity.spiceLevelText,
      freshnessDeclaration: entity.freshnessDeclaration,
      isFrozenItem: entity.isFrozenItem,
      fssaiRequired: entity.fssaiRequired,
      expiryTime: entity.expiryTime,
      ingredients: entity.ingredients,
      allergens: entity.allergens,
      foodType: entity.foodType,
      storageInstruction: entity.storageInstruction,
      packagingDetails: entity.packagingDetails,
      fssaiCertificateId: entity.fssaiCertificateId,
      servingSizes: entity.servingSizes.map(ServingSizeModel.fromEntity).toList(),
    );
  }

  FoodListingDetailsEntity toEntity() {
    return FoodListingDetailsEntity(
      id: id,
      listingId: listingId,
      preparationTime: preparationTime,
      spiceLevel: spiceLevel,
      spiceLevelText: spiceLevelText,
      freshnessDeclaration: freshnessDeclaration,
      isFrozenItem: isFrozenItem,
      fssaiRequired: fssaiRequired,
      expiryTime: expiryTime,
      ingredients: ingredients,
      allergens: allergens,
      foodType: foodType,
      storageInstruction: storageInstruction,
      packagingDetails: packagingDetails,
      fssaiCertificateId: fssaiCertificateId,
      servingSizes: servingSizes
          .map(
            (item) => ServingSizeEntity(
              id: item.id,
              sizeValue: item.sizeValue,
              sizeUnit: item.sizeUnit,
              description: item.description,
              price: item.price,
              quantityAvailable: item.quantityAvailable,
              isAvailable: item.isAvailable,
            ),
          )
          .toList(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'listingId': listingId,
      'preparationTime': preparationTime,
      'spiceLevel': spiceLevel,
      'spiceLevelText': spiceLevelText,
      'freshnessDeclaration': freshnessDeclaration,
      'isFrozenItem': isFrozenItem,
      'fssaiRequired': fssaiRequired,
      'expiryTime': expiryTime,
      'ingredients': ingredients,
      'allergens': allergens,
      'foodType': foodType,
      'storageInstruction': storageInstruction,
      'packagingDetails': packagingDetails,
      'fssaiCertificateId': fssaiCertificateId,
      'servingSizes': servingSizes
          .map((item) => ServingSizeModel.fromEntity(item).toJson())
          .toList(),
    }..removeWhere((key, value) {
      if (value == null) return true;
      if (value is String) {
        final normalized = value.trim().toLowerCase();
        return normalized.isEmpty || normalized == 'null';
      }
      return false;
    });
  }
}

class ServingSizeModel extends ServingSizeEntity {
  const ServingSizeModel({
    required super.id,
    required super.sizeValue,
    required super.sizeUnit,
    required super.description,
    required super.price,
    required super.quantityAvailable,
    required super.isAvailable,
  });

  factory ServingSizeModel.fromJson(Map<String, dynamic> json) {
    return ServingSizeModel(
      id: json['id']?.toString() ?? '',
      sizeValue: (json['sizeValue'] as num?) ?? 0,
      sizeUnit: json['sizeUnit']?.toString() ?? '',
      description: json['description']?.toString() ?? '',
      price: (json['price'] as num?) ?? 0,
      quantityAvailable: int.tryParse(json['quantityAvailable']?.toString() ?? '') ?? 0,
      isAvailable: json['isAvailable'] as bool? ?? false,
    );
  }

  factory ServingSizeModel.fromEntity(ServingSizeEntity entity) {
    return ServingSizeModel(
      id: entity.id,
      sizeValue: entity.sizeValue,
      sizeUnit: entity.sizeUnit,
      description: entity.description,
      price: entity.price,
      quantityAvailable: entity.quantityAvailable,
      isAvailable: entity.isAvailable,
    );
  }

  ServingSizeEntity toEntity() {
    return ServingSizeEntity(
      id: id,
      sizeValue: sizeValue,
      sizeUnit: sizeUnit,
      description: description,
      price: price,
      quantityAvailable: quantityAvailable,
      isAvailable: isAvailable,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'sizeValue': sizeValue,
      'sizeUnit': sizeUnit,
      'description': description,
      'price': price,
      'quantityAvailable': quantityAvailable,
      'isAvailable': isAvailable,
    };
  }
}
