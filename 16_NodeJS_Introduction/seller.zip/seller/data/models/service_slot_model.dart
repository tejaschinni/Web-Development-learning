import 'package:society_seva/features/seller/domain/entities/service_slot_entity.dart';

class ServiceSlotModel extends ServiceSlotEntity {
  const ServiceSlotModel({
    required super.startsAt,
    required super.endsAt,
    required super.durationMinutes,
    required super.timeZone,
    required super.status,
  });

  factory ServiceSlotModel.fromJson(Map<String, dynamic> json) => ServiceSlotModel(
    startsAt: DateTime.parse(json['startsAt'] as String),
    endsAt: DateTime.parse(json['endsAt'] as String),
    durationMinutes: (json['durationMinutes'] as num).toInt(),
    timeZone: json['timeZone'] as String? ?? 'Asia/Kolkata',
    status: json['status'] as String? ?? 'AVAILABLE',
  );
}
