import 'dart:convert';

import '../../domain/entities/seller_listing_entity.dart';

SellerListingModel sellerListingModelFromJson(String str) =>
    SellerListingModel.fromJson(json.decode(str));

String sellerListingModelToJson(SellerListingModel data) => json.encode(data.toJson());

class SellerListingModel extends SellerListingEntity {
  const SellerListingModel({
    required super.id,
    required super.sellerId,
    required super.categoryId,
    required super.additionalCategoryIds,
    required super.listingType,
    required super.title,
    required super.description,
    required super.basePrice,
    required super.priceUnit,
    required super.isFree,
    required super.quantityAvailable,
    required super.availabilityStatus,
    required super.approvalStatus,
    required super.moderationStatus,
    required super.sponsoredStatus,
    required super.averageRating,
    required super.totalReviews,
    required super.tagNames,
    required super.createdAt,
    required super.updatedAt,
  });

  factory SellerListingModel.fromJson(Map<String, dynamic> json) {
    return SellerListingModel(
      id: json['id']?.toString() ?? '',
      sellerId: json['sellerId']?.toString() ?? '',
      categoryId: json['categoryId']?.toString() ?? '',
      additionalCategoryIds:
          (json['additionalCategoryIds'] as List<dynamic>?)?.map((e) => e.toString()).toList() ??
          [],
      listingType: json['listingType']?.toString() ?? '',
      title: json['title']?.toString() ?? '',
      description: json['description']?.toString() ?? '',
      basePrice: (json['basePrice'] as num?)?.toDouble() ?? 0.0,
      priceUnit: json['priceUnit']?.toString() ?? '',
      isFree: json['isFree'] as bool? ?? false,
      quantityAvailable: int.tryParse(json['quantityAvailable']?.toString() ?? '') ?? 0,
      availabilityStatus: json['availabilityStatus']?.toString() ?? '',
      approvalStatus: json['approvalStatus']?.toString() ?? '',
      moderationStatus: json['moderationStatus']?.toString() ?? '',
      sponsoredStatus: json['sponsoredStatus']?.toString() ?? '',
      averageRating: (json['averageRating'] as num?)?.toDouble() ?? 0.0,
      totalReviews: int.tryParse(json['totalReviews']?.toString() ?? '') ?? 0,
      tagNames: (json['tagNames'] as List<dynamic>?)?.map((e) => e.toString()).toList() ?? [],
      createdAt:
          DateTime.tryParse(json['createdAt']?.toString() ?? '') ??
          DateTime.fromMillisecondsSinceEpoch(0),
      updatedAt:
          DateTime.tryParse(json['updatedAt']?.toString() ?? '') ??
          DateTime.fromMillisecondsSinceEpoch(0),
    );
  }

  factory SellerListingModel.fromEntity(SellerListingEntity entity) {
    return SellerListingModel(
      id: entity.id,
      sellerId: entity.sellerId,
      categoryId: entity.categoryId,
      additionalCategoryIds: entity.additionalCategoryIds,
      listingType: entity.listingType,
      title: entity.title,
      description: entity.description,
      basePrice: entity.basePrice,
      priceUnit: entity.priceUnit,
      isFree: entity.isFree,
      quantityAvailable: entity.quantityAvailable,
      availabilityStatus: entity.availabilityStatus,
      approvalStatus: entity.approvalStatus,
      moderationStatus: entity.moderationStatus,
      sponsoredStatus: entity.sponsoredStatus,
      averageRating: entity.averageRating,
      totalReviews: entity.totalReviews,
      tagNames: entity.tagNames,
      createdAt: entity.createdAt,
      updatedAt: entity.updatedAt,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'sellerId': sellerId,
    'categoryId': categoryId,
    'additionalCategoryIds': additionalCategoryIds,
    'listingType': listingType,
    'title': title,
    'description': description,
    'basePrice': basePrice,
    'priceUnit': priceUnit,
    'isFree': isFree,
    'quantityAvailable': quantityAvailable,
    'availabilityStatus': availabilityStatus,
    'approvalStatus': approvalStatus,
    'moderationStatus': moderationStatus,
    'sponsoredStatus': sponsoredStatus,
    'averageRating': averageRating,
    'totalReviews': totalReviews,
    'tagNames': tagNames,
    'createdAt': createdAt.toIso8601String(),
    'updatedAt': updatedAt.toIso8601String(),
  };

  SellerListingEntity toEntity() {
    return SellerListingEntity(
      id: id,
      sellerId: sellerId,
      categoryId: categoryId,
      additionalCategoryIds: additionalCategoryIds,
      listingType: listingType,
      title: title,
      description: description,
      basePrice: basePrice,
      priceUnit: priceUnit,
      isFree: isFree,
      quantityAvailable: quantityAvailable,
      availabilityStatus: availabilityStatus,
      approvalStatus: approvalStatus,
      moderationStatus: moderationStatus,
      sponsoredStatus: sponsoredStatus,
      averageRating: averageRating,
      totalReviews: totalReviews,
      tagNames: tagNames,
      createdAt: createdAt,
      updatedAt: updatedAt,
    );
  }
}
