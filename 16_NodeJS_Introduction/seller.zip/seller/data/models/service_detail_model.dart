import 'package:society_seva/features/seller/domain/entities/service_detail_entity.dart';

class ServiceListingDetailsModel extends ServiceListingDetailsEntity {
  const ServiceListingDetailsModel({
    required super.id,
    required super.listingId,
    super.serviceDurationMinutes,
    super.serviceLocationType,
    super.homeVisitAvailable,
    super.onlineAvailable,
    super.requiredMaterials,
    super.cancellationPolicy,
    super.certificateRequired,
  });

  factory ServiceListingDetailsModel.fromJson(Map<String, dynamic> json) {
    return ServiceListingDetailsModel(
      id: json['id']?.toString() ?? '',
      listingId: json['listingId']?.toString() ?? '',
      serviceDurationMinutes: (json['serviceDurationMinutes'] as num?)?.toInt(),
      serviceLocationType: json['serviceLocationType']?.toString(),
      homeVisitAvailable: json['homeVisitAvailable'] as bool?,
      onlineAvailable: json['onlineAvailable'] as bool?,
      requiredMaterials: json['requiredMaterials']?.toString(),
      cancellationPolicy: json['cancellationPolicy']?.toString(),
      certificateRequired: json['certificateRequired'] as bool?,
    );
  }

  factory ServiceListingDetailsModel.fromEntity(ServiceListingDetailsEntity entity) {
    return ServiceListingDetailsModel(
      id: entity.id,
      listingId: entity.listingId,
      serviceDurationMinutes: entity.serviceDurationMinutes,
      serviceLocationType: entity.serviceLocationType,
      homeVisitAvailable: entity.homeVisitAvailable,
      onlineAvailable: entity.onlineAvailable,
      requiredMaterials: entity.requiredMaterials,
      cancellationPolicy: entity.cancellationPolicy,
      certificateRequired: entity.certificateRequired,
    );
  }

  ServiceListingDetailsEntity toEntity() {
    return ServiceListingDetailsEntity(
      id: id,
      listingId: listingId,
      serviceDurationMinutes: serviceDurationMinutes,
      serviceLocationType: serviceLocationType,
      homeVisitAvailable: homeVisitAvailable,
      onlineAvailable: onlineAvailable,
      requiredMaterials: requiredMaterials,
      cancellationPolicy: cancellationPolicy,
      certificateRequired: certificateRequired,
    );
  }

  Map<String, dynamic> toJson() {
    final json = <String, dynamic>{
      'id': id,
      'listingId': listingId,
      'serviceDurationMinutes': serviceDurationMinutes,
      'serviceLocationType': serviceLocationType,
      'homeVisitAvailable': homeVisitAvailable,
      'onlineAvailable': onlineAvailable,
      'requiredMaterials': requiredMaterials,
      'cancellationPolicy': cancellationPolicy,
      'certificateRequired': certificateRequired,
    };

    json.removeWhere((key, value) {
      if (value == null) return true;

      if (value is String) {
        final normalized = value.trim().toLowerCase();
        return normalized.isEmpty || normalized == 'null';
      }

      return false;
    });

    return json;
  }
}
