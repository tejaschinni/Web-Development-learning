import 'package:society_seva/features/seller/domain/entities/seller_order_entity.dart';

class SellerOrderItemModel extends SellerOrderItemEntity {
  const SellerOrderItemModel({
    required super.id,
    required super.listingId,
    required super.titleSnapshot,
    required super.quantity,
    required super.unitPrice,
    required super.totalPrice,
  });

  factory SellerOrderItemModel.fromJson(Map<String, dynamic> json) => SellerOrderItemModel(
    id: json['id']?.toString() ?? '',
    listingId: json['listingId']?.toString() ?? '',
    titleSnapshot: json['titleSnapshot']?.toString() ?? '',
    quantity: (json['quantity'] as num?)?.toInt() ?? 0,
    unitPrice: (json['unitPrice'] as num?)?.toDouble() ?? 0,
    totalPrice: (json['totalPrice'] as num?)?.toDouble() ?? 0,
  );
}

class SellerOrderModel extends SellerOrderEntity {
  const SellerOrderModel({
    required super.id,
    required super.orderNumber,
    required super.buyerId,
    required super.sellerId,
    required super.orderType,
    required super.orderStatus,
    required super.subtotalAmount,
    required super.discountAmount,
    required super.platformCommission,
    required super.welfareFundAmount,
    required super.sellerEarning,
    required super.totalAmount,
    required super.paymentStatus,
    required super.items,
    required super.createdAt,
  });

  factory SellerOrderModel.fromJson(Map<String, dynamic> json) {
    final items = (json['items'] as List<dynamic>? ?? const [])
        .whereType<Map>()
        .map((item) => SellerOrderItemModel.fromJson(Map<String, dynamic>.from(item)))
        .toList();
    return SellerOrderModel(
      id: json['id']?.toString() ?? '',
      orderNumber: json['orderNumber']?.toString() ?? '',
      buyerId: json['buyerId']?.toString() ?? '',
      sellerId: json['sellerId']?.toString() ?? '',
      orderType: json['orderType']?.toString() ?? '',
      orderStatus: json['orderStatus']?.toString() ?? '',
      subtotalAmount: (json['subtotalAmount'] as num?)?.toDouble() ?? 0,
      discountAmount: (json['discountAmount'] as num?)?.toDouble() ?? 0,
      platformCommission: (json['platformCommission'] as num?)?.toDouble() ?? 0,
      welfareFundAmount: (json['welfareFundAmount'] as num?)?.toDouble() ?? 0,
      sellerEarning: (json['sellerEarning'] as num?)?.toDouble() ?? 0,
      totalAmount: (json['totalAmount'] as num?)?.toDouble() ?? 0,
      paymentStatus: json['paymentStatus']?.toString() ?? '',
      items: items,
      createdAt: DateTime.tryParse(json['createdAt']?.toString() ?? '') ?? DateTime.now(),
    );
  }
}
