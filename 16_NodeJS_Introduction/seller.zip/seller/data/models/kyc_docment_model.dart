import '../../domain/entities/kyc_document_entity.dart';

class KycDocumentModel {
  final String id;
  final String sellerId;
  final String documentType;
  final String documentFileUrl;
  final String verificationStatus;
  final DateTime createdAt;
  final DateTime updatedAt;

  const KycDocumentModel({
    required this.id,
    required this.sellerId,
    required this.documentType,
    required this.documentFileUrl,
    required this.verificationStatus,
    required this.createdAt,
    required this.updatedAt,
  });

  factory KycDocumentModel.fromJson(Map<String, dynamic> json) {
    return KycDocumentModel(
      id: json['id'] as String,
      sellerId: json['sellerId'] as String,
      documentType: json['documentType'] as String,
      documentFileUrl: json['documentFileUrl'] as String,
      verificationStatus: json['verificationStatus'] as String,
      createdAt: DateTime.parse(json['createdAt'] as String),
      updatedAt: DateTime.parse(json['updatedAt'] as String),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'sellerId': sellerId,
      'documentType': documentType,
      'documentFileUrl': documentFileUrl,
      'verificationStatus': verificationStatus,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
    };
  }

  KycDocumentEntity toEntity() {
    return KycDocumentEntity(
      id: id,
      sellerId: sellerId,
      documentType: documentType,
      documentFileUrl: documentFileUrl,
      verificationStatus: verificationStatus,
      createdAt: createdAt,
      updatedAt: updatedAt,
    );
  }

  factory KycDocumentModel.fromEntity(KycDocumentEntity entity) {
    return KycDocumentModel(
      id: entity.id,
      sellerId: entity.sellerId,
      documentType: entity.documentType,
      documentFileUrl: entity.documentFileUrl,
      verificationStatus: entity.verificationStatus,
      createdAt: entity.createdAt,
      updatedAt: entity.updatedAt,
    );
  }

  KycDocumentModel copyWith({
    String? id,
    String? sellerId,
    String? documentType,
    String? documentFileUrl,
    String? verificationStatus,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return KycDocumentModel(
      id: id ?? this.id,
      sellerId: sellerId ?? this.sellerId,
      documentType: documentType ?? this.documentType,
      documentFileUrl: documentFileUrl ?? this.documentFileUrl,
      verificationStatus: verificationStatus ?? this.verificationStatus,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}
