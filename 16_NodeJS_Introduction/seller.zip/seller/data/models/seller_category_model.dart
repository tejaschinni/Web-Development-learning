import 'package:society_seva/features/seller/domain/entities/seller_category_entity.dart';

class CategoriesModel {
  final String id;
  final String name;
  final String slug;
  final String categoryType;
  final bool requiresCertificate;
  final bool isActive;
  final int displayOrder;
  final DateTime createdAt;
  final DateTime updatedAt;

  const CategoriesModel({
    required this.id,
    required this.name,
    required this.slug,
    required this.categoryType,
    required this.requiresCertificate,
    required this.isActive,
    required this.displayOrder,
    required this.createdAt,
    required this.updatedAt,
  });

  factory CategoriesModel.fromJson(Map<String, dynamic> json) {
    return CategoriesModel(
      id: json['id'] as String,
      name: json['name'] as String,
      slug: json['slug'] as String,
      categoryType: json['categoryType'] as String,
      requiresCertificate: json['requiresCertificate'] as bool,
      isActive: json['isActive'] as bool,
      displayOrder: json['displayOrder'] as int,
      createdAt: DateTime.parse(json['createdAt'] as String),
      updatedAt: DateTime.parse(json['updatedAt'] as String),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'slug': slug,
      'categoryType': categoryType,
      'requiresCertificate': requiresCertificate,
      'isActive': isActive,
      'displayOrder': displayOrder,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
    };
  }

  CategoriesEntity toEntity() {
    return CategoriesEntity(
      id: id,
      name: name,
      slug: slug,
      categoryType: categoryType,
      requiresCertificate: requiresCertificate,
      isActive: isActive,
      displayOrder: displayOrder,
      createdAt: createdAt,
      updatedAt: updatedAt,
    );
  }

  factory CategoriesModel.fromEntity(CategoriesEntity entity) {
    return CategoriesModel(
      id: entity.id,
      name: entity.name,
      slug: entity.slug,
      categoryType: entity.categoryType,
      requiresCertificate: entity.requiresCertificate,
      isActive: entity.isActive,
      displayOrder: entity.displayOrder,
      createdAt: entity.createdAt,
      updatedAt: entity.updatedAt,
    );
  }

  CategoriesModel copyWith({
    String? id,
    String? name,
    String? slug,
    String? categoryType,
    bool? requiresCertificate,
    bool? isActive,
    int? displayOrder,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return CategoriesModel(
      id: id ?? this.id,
      name: name ?? this.name,
      slug: slug ?? this.slug,
      categoryType: categoryType ?? this.categoryType,
      requiresCertificate: requiresCertificate ?? this.requiresCertificate,
      isActive: isActive ?? this.isActive,
      displayOrder: displayOrder ?? this.displayOrder,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}
