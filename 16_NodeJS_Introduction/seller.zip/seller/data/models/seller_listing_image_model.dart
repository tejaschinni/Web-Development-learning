import 'package:society_seva/features/seller/domain/entities/seller_listing_images_entity.dart';

class SellerListingImageModel {
  final String id;
  final String listingId;
  final String imageUrl;
  final String moderationStatus;
  final int displayOrder;
  final DateTime createdAt;

  const SellerListingImageModel({
    required this.id,
    required this.listingId,
    required this.imageUrl,
    required this.moderationStatus,
    required this.displayOrder,
    required this.createdAt,
  });

  factory SellerListingImageModel.fromJson(Map<String, dynamic> json) {
    return SellerListingImageModel(
      id: json['id'] as String,
      listingId: json['listingId'] as String,
      imageUrl: json['imageUrl'] as String,
      moderationStatus: json['moderationStatus'] as String,
      displayOrder: (json['displayOrder'] as num).toInt(),
      createdAt: DateTime.parse(json['createdAt'] as String),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'listingId': listingId,
      'imageUrl': imageUrl,
      'moderationStatus': moderationStatus,
      'displayOrder': displayOrder,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  SellerListingImageEntity toEntity() {
    return SellerListingImageEntity(
      id: id,
      listingId: listingId,
      imageUrl: imageUrl,
      moderationStatus: moderationStatus,
      displayOrder: displayOrder,
      createdAt: createdAt,
    );
  }

  factory SellerListingImageModel.fromEntity(SellerListingImageEntity entity) {
    return SellerListingImageModel(
      id: entity.id,
      listingId: entity.listingId,
      imageUrl: entity.imageUrl,
      moderationStatus: entity.moderationStatus,
      displayOrder: entity.displayOrder,
      createdAt: entity.createdAt,
    );
  }

  SellerListingImageModel copyWith({
    String? id,
    String? listingId,
    String? imageUrl,
    String? moderationStatus,
    int? displayOrder,
    DateTime? createdAt,
  }) {
    return SellerListingImageModel(
      id: id ?? this.id,
      listingId: listingId ?? this.listingId,
      imageUrl: imageUrl ?? this.imageUrl,
      moderationStatus: moderationStatus ?? this.moderationStatus,
      displayOrder: displayOrder ?? this.displayOrder,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}
