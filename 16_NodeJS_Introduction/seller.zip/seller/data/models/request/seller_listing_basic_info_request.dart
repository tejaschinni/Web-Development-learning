class SellerListingBasicInfoRequest {
  final String? sellerId;
  final String? categoryId;
  final List<String>? additionalCategoryIds;
  final String? listingType;
  final String? title;
  final String? description;
  final double? basePrice;
  final String? priceUnit;
  final bool? isFree;
  final int? quantityAvailable;
  final List<String>? tagNames;

  const SellerListingBasicInfoRequest({
    this.sellerId,
    this.categoryId,
    this.additionalCategoryIds,
    this.listingType,
    this.title,
    this.description,
    this.basePrice,
    this.priceUnit,
    this.isFree,
    this.quantityAvailable,
    this.tagNames,
  });

  Map<String, dynamic> toJson() {
    final json = <String, dynamic>{
      'sellerId': sellerId,
      'categoryId': categoryId,
      'additionalCategoryIds': additionalCategoryIds,
      'listingType': listingType,
      'title': title,
      'description': description,
      'basePrice': basePrice,
      'priceUnit': priceUnit,
      'isFree': isFree,
      'quantityAvailable': quantityAvailable?.toString(),
      'tagNames': tagNames,
    };

    json.removeWhere((key, value) {
      if (value == null) return true;

      if (value is String) {
        final normalized = value.trim().toLowerCase();
        return normalized.isEmpty || normalized == 'null';
      }

      if (value is List) {
        return value.isEmpty;
      }

      if (value is Map) {
        return value.isEmpty;
      }

      return false;
    });

    return json;
  }
}
