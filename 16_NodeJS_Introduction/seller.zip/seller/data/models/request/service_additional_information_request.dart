class ServiceAdditionalInformationRequest {
  final int? serviceDurationMinutes;
  final String? serviceLocationType;
  final bool? homeVisitAvailable;
  final bool? onlineAvailable;
  final String? requiredMaterials;
  final String? cancellationPolicy;
  final bool? certificateRequired;

  const ServiceAdditionalInformationRequest({
    this.serviceDurationMinutes,
    this.serviceLocationType,
    this.homeVisitAvailable,
    this.onlineAvailable,
    this.requiredMaterials,
    this.cancellationPolicy,
    this.certificateRequired,
  });

  Map<String, dynamic> toJson() {
    return _removeEmptyValues({
      'serviceDurationMinutes': serviceDurationMinutes,
      'serviceLocationType': serviceLocationType,
      'homeVisitAvailable': homeVisitAvailable,
      'onlineAvailable': onlineAvailable,
      'requiredMaterials': requiredMaterials,
      'cancellationPolicy': cancellationPolicy,
      'certificateRequired': certificateRequired,
    });
  }
}

Map<String, dynamic> _removeEmptyValues(Map<String, dynamic> json) {
  json.removeWhere((key, value) {
    if (value == null) return true;

    if (value is String) {
      final normalized = value.trim().toLowerCase();
      return normalized.isEmpty || normalized == 'null';
    }

    if (value is List) return value.isEmpty;

    if (value is Map) return value.isEmpty;

    return false;
  });

  return json;
}
