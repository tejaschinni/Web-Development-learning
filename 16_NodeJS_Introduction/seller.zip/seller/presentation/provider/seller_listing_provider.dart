import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/core/providers/app_providers.dart';
import 'package:society_seva/features/seller/data/datasources/seller_listing_remote_datasource.dart';
import 'package:society_seva/features/seller/data/models/request/food_additinal_information_request.dart';
import 'package:society_seva/features/seller/data/models/request/seller_listing_basic_info_request.dart';
import 'package:society_seva/features/seller/data/models/request/service_additional_information_request.dart';
import 'package:society_seva/features/seller/domain/entities/seller_listing_entity.dart';
import 'package:society_seva/features/seller/domain/entities/seller_listing_images_entity.dart';
import 'package:society_seva/features/seller/domain/enum/category_type.dart';
import 'package:society_seva/features/seller/domain/repositories/seller_listing_respository.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/shop/data/models/shop_category_model.dart';
import 'package:society_seva/features/shop/domain/enums/shop_category_type.dart';

final sellerListingRemoteDataSource = Provider<SellerListingRemoteDatasource>((ref) {
  return SellerListingRemoteDataSourceImpl(ref.watch(apiClientProvider));
});

final sellerListingRemoteRepository = Provider<SellerListingRespository>((ref) {
  return SellerListingRespositoryImpl(ref.watch(sellerListingRemoteDataSource));
});
final sellerListingProvier =
    FutureProvider.family<PageResponse<SellerListingEntity>, ({String sellerID})>((ref, args) {
      return ref.watch(sellerListingRemoteRepository).fetchMyListingRepo(sellerId: args.sellerID);
    });

final sellerListingImagesProvider = FutureProvider.family<List<SellerListingImageEntity>, String>((
  ref,
  id,
) {
  return ref.watch(sellerListingRemoteRepository).getListingImagesRepo(id);
});

const kListingSteps = ['Category', 'Basic', 'Pricing', 'Details', 'Photos', 'Review'];
const kMaxListingImages = 6;
const kMaxImageBytes = 5 * 1024 * 1024; // 5 MB, as shown in the design

const kPriceUnits = <String, String>{
  'PER_ITEM': 'Per item',
  'PER_PLATE': 'Per plate',
  'PER_KG': 'Per kg',
  'PER_HOUR': 'Per hour',
  'PER_SESSION': 'Per session',
  'FIXED': 'Fixed price',
};

const kAvailabilityStatuses = <String, String>{
  'AVAILABLE': 'Available',
  'UNAVAILABLE': 'Unavailable',
  'OUT_OF_STOCK': 'Out of stock',
  'PAUSED': 'Paused',
};

const kLocationTypes = <String, String>{
  'COMMON_AREA': 'Common area',
  'BUYER_FLAT': "Buyer's flat",
  'SELLER_FLAT': "Seller's flat",
  'ONLINE': 'Online',
  'EXTERNAL': 'External',
};

// Adjust the numbers to whatever your backend expects.
const kSpiceLevels = <String, int>{
  'NOT_APPLICABLE': 0,
  'MILD': 1,
  'MEDIUM': 3,
  'HOT': 4,
  'EXTRA_HOT': 5,
};

// Align with your backend FoodType enum.
const kFoodTypes = <String, String>{
  'VEG': 'Veg',
  'NON_VEG': 'Non-veg',
  'VEGAN': 'Vegan',
  'EGG': 'Eggetarian',
};

enum ListingType {
  food('FOOD', 'Food'),
  product('PRODUCT', 'Product'),
  service('SERVICE', 'Service'),
  classes('CLASS', 'Class'),
  consultation('CONSULTATION', 'Consultation'),
  eventSupport('EVENT_SUPPORT', 'Event support'),
  help('HELP', 'Help'),
  grocery('GROCERY', 'Grocery');

  const ListingType(this.api, this.label);
  final String api;
  final String label;

  bool get isFood => this == food;

  /// Types that use the service-details API (duration, location, slots).
  /// PRODUCT / GROCERY need no extra details.
  bool get isService =>
      this == service ||
      this == classes ||
      this == consultation ||
      this == eventSupport ||
      this == help;
}

extension CategoryTypeX on CategoryType {
  // Adjust if your enum value is named differently.
  bool get isFoodCategory => name.toLowerCase().contains('food');
}

// ───────────────────────── small models ─────────────────────────

double? _d(TextEditingController c) => double.tryParse(c.text.trim());
int? _i(TextEditingController c) => int.tryParse(c.text.trim());
String? _t(TextEditingController c) {
  final v = c.text.trim();
  return v.isEmpty ? null : v;
}

String _two(int n) => n.toString().padLeft(2, '0');
String _hhmm(TimeOfDay t) => '${_two(t.hour)}:${_two(t.minute)}';
String ymd(DateTime d) => '${d.year}-${_two(d.month)}-${_two(d.day)}';

/// One serving size row. Owns its controllers (disposed by the notifier).
class ServingSizeDraft {
  ServingSizeDraft(VoidCallback onChanged) {
    for (final c in [sizeValue, sizeUnit, description, price, quantity]) {
      c.addListener(onChanged);
    }
  }

  final sizeValue = TextEditingController();
  final sizeUnit = TextEditingController();
  final description = TextEditingController();
  final price = TextEditingController();
  final quantity = TextEditingController();
  bool isAvailable = true;

  String get uniqueKey => '${sizeValue.text.trim()}|${sizeUnit.text.trim().toLowerCase()}';

  bool get isValid =>
      (_d(sizeValue) ?? 0) > 0 &&
      sizeUnit.text.trim().isNotEmpty &&
      description.text.trim().isNotEmpty &&
      (_d(price) ?? 0) > 0 &&
      (_i(quantity) ?? -1) >= 0;

  Map<String, dynamic> toJson() => {
    'sizeValue': _d(sizeValue),
    'sizeUnit': sizeUnit.text.trim(),
    'description': description.text.trim(),
    'price': _d(price),
    'quantityAvailable': _i(quantity) ?? 0,
    'isAvailable': isAvailable,
  };

  void dispose() {
    for (final c in [sizeValue, sizeUnit, description, price, quantity]) {
      c.dispose();
    }
  }
}

/// A seller availability window for one date ("HH:mm").
class SlotWindow {
  const SlotWindow(this.startsAt, this.endsAt);
  final String startsAt;
  final String endsAt;
  Map<String, String> toJson() => {'startsAt': startsAt, 'endsAt': endsAt};
}

/// All free-text inputs live here so values survive step changes.
class ListingFormControllers {
  ListingFormControllers(VoidCallback onChanged) {
    for (final c in all) {
      c.addListener(onChanged);
    }
  }

  // basic
  final title = TextEditingController();
  final shortDescription = TextEditingController();
  final detailedDescription = TextEditingController();
  final description = TextEditingController();
  final tagInput = TextEditingController();
  // pricing
  final basePrice = TextEditingController();
  final quantity = TextEditingController();
  // service
  final duration = TextEditingController();
  final requiredMaterials = TextEditingController();
  final cancellationPolicy = TextEditingController();
  // food
  final prepTime = TextEditingController();
  final ingredients = TextEditingController();
  final allergens = TextEditingController();
  final freshness = TextEditingController();
  final storage = TextEditingController();
  final packaging = TextEditingController();
  final fssaiId = TextEditingController();
  final otherDietaryNote = TextEditingController();

  List<TextEditingController> get all => [
    title,
    shortDescription,
    detailedDescription,
    description,
    tagInput,
    basePrice,
    quantity,
    duration,
    requiredMaterials,
    cancellationPolicy,
    prepTime,
    ingredients,
    allergens,
    freshness,
    storage,
    packaging,
    fssaiId,
    otherDietaryNote,
  ];

  void dispose() {
    for (final c in all) {
      c.dispose();
    }
  }
}

// ───────────────────────── state ─────────────────────────

class ListingFormState {
  const ListingFormState({
    required this.categoryType,
    this.currentStep = 0,
    this.mainCategoryId,
    this.mainCategoryName,
    this.selectedMainCategory,
    this.subcategoryId,
    this.listingType = ListingType.food,
    this.additionalCategoryIds = const {},
    this.tags = const ['homemade', 'thali', 'lunch', 'veg food'],
    this.dietaryType = 'VEG',
    this.isImmediateOrder = true,
    this.isPreOrder = true,
    this.prepTimeMinutes = '30 minutes',
    this.availableDays = const {'Mon', 'Tue', 'Wed', 'Thu', 'Fri'},
    this.timeSlotStart = '10:00 AM',
    this.timeSlotEnd = '9:00 PM',
    this.containsOnion = true,
    this.containsGarlic = true,
    this.isJainFood = true,
    this.isGlutenFree = false,
    this.isOtherDietary = false,
    this.isFree = false,
    this.priceUnit = 'PER_ITEM',
    this.availabilityStatus = 'AVAILABLE',
    this.locationType = 'COMMON_AREA',
    this.homeVisit = false,
    this.online = false,
    this.certificateRequired = false,
    this.foodType = 'VEG',
    this.spiceLevel = 'MEDIUM',
    this.frozen = false,
    this.fssaiRequired = false,
    this.expiryTime,
    this.servings = const [],
    this.slots = const {},
    this.pendingImages = const [],
    this.remoteImages = const [],
    this.deletingImageIds = const {},
    this.listingId,
    this.detailsSaved = false,
    this.isSaving = false,
    this.isSubmitting = false,
    this.isUploadingImages = false,
    this.error,
    this.revision = 0,
  });

  // step 0 & 1
  final int currentStep;
  final CategoryType categoryType;
  final String? mainCategoryId;
  final String? mainCategoryName;
  final ShopCategoryModel? selectedMainCategory;
  final String? subcategoryId; // sent as `categoryId`
  // step 1: basic
  final ListingType listingType;
  final Set<String> additionalCategoryIds;
  final List<String> tags;
  final String dietaryType; // VEG, NON_VEG, EGG, EGGLESS
  // step 2: pricing & availability
  final bool isImmediateOrder;
  final bool isPreOrder;
  final String prepTimeMinutes;
  final Set<String> availableDays;
  final String timeSlotStart;
  final String timeSlotEnd;
  final bool isFree;
  final String priceUnit;
  final String availabilityStatus;
  final Map<String, List<SlotWindow>> slots; // 'yyyy-MM-dd' -> windows
  // step 3 & 4: details (food/service)
  final bool containsOnion;
  final bool containsGarlic;
  final bool isJainFood;
  final bool isGlutenFree;
  final bool isOtherDietary;
  final String locationType;
  final bool homeVisit, online, certificateRequired;
  final String foodType;
  final String spiceLevel;
  final bool frozen, fssaiRequired;
  final DateTime? expiryTime;
  final List<ServingSizeDraft> servings;
  // photos
  final List<XFile> pendingImages;
  final List<SellerListingImageEntity> remoteImages;
  final Set<String> deletingImageIds;
  // pipeline progress
  final String? listingId;
  final bool detailsSaved;
  final bool isSaving, isSubmitting, isUploadingImages;
  final Object? error;
  final int revision; // bumped on every keystroke so validators re-run

  bool get isBusy => isSaving || isSubmitting || isUploadingImages;
  List<SellerListingImageEntity> get visibleRemoteImages =>
      remoteImages.where((i) => !deletingImageIds.contains(i.id)).toList();
  int get totalImageCount => visibleRemoteImages.length + pendingImages.length;

  static const _keep = Object();

  ListingFormState copyWith({
    int? currentStep,
    CategoryType? categoryType,
    Object? mainCategoryId = _keep,
    Object? mainCategoryName = _keep,
    Object? selectedMainCategory = _keep,
    Object? subcategoryId = _keep,
    ListingType? listingType,
    Set<String>? additionalCategoryIds,
    List<String>? tags,
    String? dietaryType,
    bool? isImmediateOrder,
    bool? isPreOrder,
    String? prepTimeMinutes,
    Set<String>? availableDays,
    String? timeSlotStart,
    String? timeSlotEnd,
    bool? containsOnion,
    bool? containsGarlic,
    bool? isJainFood,
    bool? isGlutenFree,
    bool? isOtherDietary,
    bool? isFree,
    String? priceUnit,
    String? availabilityStatus,
    String? locationType,
    bool? homeVisit,
    bool? online,
    bool? certificateRequired,
    String? foodType,
    String? spiceLevel,
    bool? frozen,
    bool? fssaiRequired,
    Object? expiryTime = _keep,
    List<ServingSizeDraft>? servings,
    Map<String, List<SlotWindow>>? slots,
    List<XFile>? pendingImages,
    List<SellerListingImageEntity>? remoteImages,
    Set<String>? deletingImageIds,
    Object? listingId = _keep,
    bool? detailsSaved,
    bool? isSaving,
    bool? isSubmitting,
    bool? isUploadingImages,
    Object? error,
    bool clearError = false,
    int? revision,
  }) => ListingFormState(
    currentStep: currentStep ?? this.currentStep,
    categoryType: categoryType ?? this.categoryType,
    mainCategoryId: identical(mainCategoryId, _keep) ? this.mainCategoryId : mainCategoryId as String?,
    mainCategoryName: identical(mainCategoryName, _keep) ? this.mainCategoryName : mainCategoryName as String?,
    selectedMainCategory: identical(selectedMainCategory, _keep) ? this.selectedMainCategory : selectedMainCategory as ShopCategoryModel?,
    subcategoryId: identical(subcategoryId, _keep) ? this.subcategoryId : subcategoryId as String?,
    listingType: listingType ?? this.listingType,
    additionalCategoryIds: additionalCategoryIds ?? this.additionalCategoryIds,
    tags: tags ?? this.tags,
    dietaryType: dietaryType ?? this.dietaryType,
    isImmediateOrder: isImmediateOrder ?? this.isImmediateOrder,
    isPreOrder: isPreOrder ?? this.isPreOrder,
    prepTimeMinutes: prepTimeMinutes ?? this.prepTimeMinutes,
    availableDays: availableDays ?? this.availableDays,
    timeSlotStart: timeSlotStart ?? this.timeSlotStart,
    timeSlotEnd: timeSlotEnd ?? this.timeSlotEnd,
    containsOnion: containsOnion ?? this.containsOnion,
    containsGarlic: containsGarlic ?? this.containsGarlic,
    isJainFood: isJainFood ?? this.isJainFood,
    isGlutenFree: isGlutenFree ?? this.isGlutenFree,
    isOtherDietary: isOtherDietary ?? this.isOtherDietary,
    isFree: isFree ?? this.isFree,
    priceUnit: priceUnit ?? this.priceUnit,
    availabilityStatus: availabilityStatus ?? this.availabilityStatus,
    locationType: locationType ?? this.locationType,
    homeVisit: homeVisit ?? this.homeVisit,
    online: online ?? this.online,
    certificateRequired: certificateRequired ?? this.certificateRequired,
    foodType: foodType ?? this.foodType,
    spiceLevel: spiceLevel ?? this.spiceLevel,
    frozen: frozen ?? this.frozen,
    fssaiRequired: fssaiRequired ?? this.fssaiRequired,
    expiryTime: identical(expiryTime, _keep) ? this.expiryTime : expiryTime as DateTime?,
    servings: servings ?? this.servings,
    slots: slots ?? this.slots,
    pendingImages: pendingImages ?? this.pendingImages,
    remoteImages: remoteImages ?? this.remoteImages,
    deletingImageIds: deletingImageIds ?? this.deletingImageIds,
    listingId: identical(listingId, _keep) ? this.listingId : listingId as String?,
    detailsSaved: detailsSaved ?? this.detailsSaved,
    isSaving: isSaving ?? this.isSaving,
    isSubmitting: isSubmitting ?? this.isSubmitting,
    isUploadingImages: isUploadingImages ?? this.isUploadingImages,
    error: clearError ? null : (error ?? this.error),
    revision: revision ?? this.revision,
  );
}

// ───────────────────────── providers ─────────────────────────

final productListingProvider = NotifierProvider.autoDispose<ListingFormNotifier, ListingFormState>(
  ListingFormNotifier.new,
);

/// Drives the enabled/disabled state of the Next / Submit button.
final listingStepValidProvider = Provider.autoDispose<bool>((ref) {
  final s = ref.watch(productListingProvider); // re-run on every change
  return ref.read(productListingProvider.notifier).isStepValid(s.currentStep);
});

// ───────────────────────── notifier ─────────────────────────

class ListingFormNotifier extends AutoDisposeNotifier<ListingFormState> {
  late ListingFormControllers controllers;

  SellerListingRespository get repo => ref.read(sellerListingRemoteRepository);
  @override
  ListingFormState build() {
    controllers = ListingFormControllers(_onTextChanged);
    ref.onDispose(() {
      controllers.dispose();
      for (final d in state.servings) {
        d.dispose();
      }
    });
    return ListingFormState(
      categoryType: CategoryType.values.first,
      listingType: CategoryType.values.first.isFoodCategory
          ? ListingType.food
          : ListingType.product,
      servings: [ServingSizeDraft(_onTextChanged)],
    );
  }

  void _onTextChanged() => state = state.copyWith(revision: state.revision + 1);

  // ── navigation ──

  void next() {
    if (state.currentStep < kListingSteps.length - 1 && isStepValid(state.currentStep)) {
      state = state.copyWith(currentStep: state.currentStep + 1);
    }
  }

  void back() {
    if (state.currentStep > 0) state = state.copyWith(currentStep: state.currentStep - 1);
  }

  /// Stepper tap: always allow going back, forward only one valid step.
  void goTo(int step) {
    if (step < state.currentStep ||
        (step == state.currentStep + 1 && isStepValid(state.currentStep))) {
      state = state.copyWith(currentStep: step);
    }
  }

  // ── step 1: category ──

  void selectMainCategoryModel(ShopCategoryModel category) {
    final isFood = category.categoryType == ShopCategoryType.food ||
        category.name.toLowerCase().contains('food');
    final isService = category.categoryType == ShopCategoryType.service ||
        category.name.toLowerCase().contains('service');
    final matchedListingType = isFood
        ? ListingType.food
        : (isService ? ListingType.service : ListingType.product);

    state = state.copyWith(
      mainCategoryId: category.id,
      mainCategoryName: category.name,
      selectedMainCategory: category,
      subcategoryId: null,
      additionalCategoryIds: {},
      listingType: matchedListingType,
    );
  }

  void toggleSubcategory(String subId) {
    final set = Set<String>.from(state.additionalCategoryIds);
    if (set.contains(subId)) {
      set.remove(subId);
    } else {
      set.add(subId);
    }
    final primary = set.isNotEmpty ? set.first : null;
    state = state.copyWith(
      subcategoryId: primary,
      additionalCategoryIds: set,
    );
  }

  void setSubcategories(List<String> subIds) {
    final set = subIds.toSet();
    final primary = set.isNotEmpty ? set.first : null;
    state = state.copyWith(
      subcategoryId: primary,
      additionalCategoryIds: set,
    );
  }

  void clearSelectedCategory() {
    state = state.copyWith(
      mainCategoryId: null,
      mainCategoryName: null,
      selectedMainCategory: null,
      subcategoryId: null,
      additionalCategoryIds: {},
    );
  }

  void selectCategory(CategoryType type) {
    if (type == state.categoryType) return;
    state = state.copyWith(
      categoryType: type,
      subcategoryId: null,
      additionalCategoryIds: {},
      listingType: type.isFoodCategory ? ListingType.food : ListingType.product,
    );
  }

  void selectSubcategory(String id) {
    toggleSubcategory(id);
  }

  // ── step 2: basic ──

  void setListingType(ListingType t) => state = state.copyWith(listingType: t);

  void toggleAdditionalCategory(String id) {
    final set = {...state.additionalCategoryIds};
    set.contains(id) ? set.remove(id) : set.add(id);
    state = state.copyWith(additionalCategoryIds: set);
  }

  void addTagsFromInput() {
    final parts = controllers.tagInput.text
        .split(',')
        .map((e) => e.trim().toLowerCase())
        .where((e) => e.isNotEmpty);
    final tags = [...state.tags];
    for (final p in parts) {
      if (!tags.contains(p) && tags.length < 10) tags.add(p);
    }
    controllers.tagInput.clear();
    state = state.copyWith(tags: tags);
  }

  void removeTag(String tag) =>
      state = state.copyWith(tags: state.tags.where((t) => t != tag).toList());

  // ── step 3: pricing & availability ──

  void setFree(bool v) {
    if (v) controllers.basePrice.clear();
    state = state.copyWith(isFree: v);
  }

  void setPriceUnit(String v) => state = state.copyWith(priceUnit: v);
  void setAvailabilityStatus(String v) => state = state.copyWith(availabilityStatus: v);

  /// Returns an error message or null.
  String? addSlot(DateTime date, TimeOfDay start, TimeOfDay end) {
    final s = _hhmm(start), e = _hhmm(end);
    if (s.compareTo(e) >= 0) return 'End time must be after start time';
    final key = ymd(date);
    final list = [...?state.slots[key]];
    if (list.any((w) => s.compareTo(w.endsAt) < 0 && e.compareTo(w.startsAt) > 0)) {
      return 'This overlaps an existing window';
    }
    list
      ..add(SlotWindow(s, e))
      ..sort((a, b) => a.startsAt.compareTo(b.startsAt));
    state = state.copyWith(slots: {...state.slots, key: list});
    return null;
  }

  void removeSlot(String dateKey, SlotWindow w) {
    final list = state.slots[dateKey]!.where((x) => x != w).toList();
    final map = {...state.slots};
    list.isEmpty ? map.remove(dateKey) : map[dateKey] = list;
    state = state.copyWith(slots: map);
  }

  // ── step 4: additional info ──

  void setLocationType(String v) => state = state.copyWith(locationType: v);
  void setHomeVisit(bool v) => state = state.copyWith(homeVisit: v);
  void setOnline(bool v) => state = state.copyWith(online: v);
  void setCertificateRequired(bool v) => state = state.copyWith(certificateRequired: v);
  void setFoodType(String v) => state = state.copyWith(foodType: v);
  void setSpiceLevel(String v) => state = state.copyWith(spiceLevel: v);
  void setFrozen(bool v) => state = state.copyWith(frozen: v);
  void setExpiry(DateTime? v) => state = state.copyWith(expiryTime: v);

  void setFssaiRequired(bool v) {
    if (!v) controllers.fssaiId.clear();
    state = state.copyWith(fssaiRequired: v);
  }

  void addServing() =>
      state = state.copyWith(servings: [...state.servings, ServingSizeDraft(_onTextChanged)]);

  void removeServing(int index) {
    if (state.servings.length <= 1) return;
    final list = [...state.servings];
    final removed = list.removeAt(index);
    state = state.copyWith(servings: list);
    // dispose after the frame so the widget tree is no longer using it
    WidgetsBinding.instance.addPostFrameCallback((_) => removed.dispose());
  }

  void setServingAvailable(int index, bool v) {
    state.servings[index].isAvailable = v;
    state = state.copyWith(revision: state.revision + 1);
  }

  // ── step 5: images (local only until Save/Submit) ──

  /// Returns a message to show the user, or null.
  Future<String?> addPendingImages(List<XFile> files) async {
    final room = kMaxListingImages - state.totalImageCount;
    if (room <= 0) return 'You can add up to $kMaxListingImages photos';
    final accepted = <XFile>[];
    String? msg;
    for (final f in files) {
      if (accepted.length >= room) {
        msg = 'Only $kMaxListingImages photos allowed';
        break;
      }
      if (await f.length() > kMaxImageBytes) {
        msg = 'Each photo must be under 5 MB';
        continue;
      }
      if (state.pendingImages.any((p) => p.path == f.path)) continue;
      accepted.add(f);
    }
    state = state.copyWith(pendingImages: [...state.pendingImages, ...accepted]);
    return msg;
  }

  void removePendingImage(XFile f) => state = state.copyWith(
    pendingImages: state.pendingImages.where((p) => p.path != f.path).toList(),
  );

  void addSampleImageUrl(String url) {
    final room = kMaxListingImages - state.totalImageCount;
    if (room <= 0) return;
    final newImage = SellerListingImageEntity(
      id: 'sample-${DateTime.now().millisecondsSinceEpoch}',
      listingId: state.listingId ?? '',
      imageUrl: url,
      moderationStatus: 'APPROVED',
      displayOrder: state.totalImageCount + 1,
      createdAt: DateTime.now(),
    );
    state = state.copyWith(remoteImages: [...state.remoteImages, newImage]);
  }

  void setAsCoverPhoto(int index) {
    if (index <= 0 || index >= state.totalImageCount) return;
    final visibleRemotes = [...state.visibleRemoteImages];
    final pendings = [...state.pendingImages];

    if (index < visibleRemotes.length) {
      final item = visibleRemotes.removeAt(index);
      visibleRemotes.insert(0, item);
      state = state.copyWith(remoteImages: visibleRemotes);
    } else {
      final pIndex = index - visibleRemotes.length;
      if (pIndex < pendings.length) {
        final item = pendings.removeAt(pIndex);
        pendings.insert(0, item);
        state = state.copyWith(pendingImages: pendings);
      }
    }
  }

  void markRemoteForDelete(String id) =>
      state = state.copyWith(deletingImageIds: {...state.deletingImageIds, id});

  void unmarkRemoteForDelete(String id) =>
      state = state.copyWith(deletingImageIds: {...state.deletingImageIds}..remove(id));

  void setDietaryType(String v) => state = state.copyWith(dietaryType: v);
  void setImmediateOrder(bool v) => state = state.copyWith(isImmediateOrder: v);
  void setPreOrder(bool v) => state = state.copyWith(isPreOrder: v);
  void setPrepTimeMinutes(String v) {
    state = state.copyWith(prepTimeMinutes: v);
    // Extract first digits for prepTime controller
    final digits = RegExp(r'\d+').firstMatch(v)?.group(0);
    if (digits != null) controllers.prepTime.text = digits;
  }

  void toggleAvailableDay(String day) {
    final set = {...state.availableDays};
    set.contains(day) ? set.remove(day) : set.add(day);
    state = state.copyWith(availableDays: set);
  }

  void setTimeSlotStart(String v) => state = state.copyWith(timeSlotStart: v);
  void setTimeSlotEnd(String v) => state = state.copyWith(timeSlotEnd: v);

  void setContainsOnion(bool v) => state = state.copyWith(containsOnion: v);
  void setContainsGarlic(bool v) => state = state.copyWith(containsGarlic: v);
  void setIsJainFood(bool v) => state = state.copyWith(isJainFood: v);
  void setIsGlutenFree(bool v) => state = state.copyWith(isGlutenFree: v);
  void setIsOtherDietary(bool v) => state = state.copyWith(isOtherDietary: v);

  void addTag(String tag) {
    final clean = tag.trim().toLowerCase();
    if (clean.isNotEmpty && !state.tags.contains(clean)) {
      state = state.copyWith(tags: [...state.tags, clean]);
    }
  }

  void resetForm() {
    for (final c in controllers.all) {
      c.clear();
    }
    state = ListingFormState(
      categoryType: CategoryType.values.first,
      listingType: ListingType.food,
    );
  }

  // ── validation ──

  bool isStepValid(int step) {
    final s = state, c = controllers;
    switch (step) {
      case 0:
        return s.selectedMainCategory != null ||
            (s.mainCategoryId != null && s.mainCategoryId!.isNotEmpty);
      case 1:
        return _t(c.title) != null;
      case 2:
        return s.isFree || (_d(c.basePrice) ?? 0) > 0;
      case 3:
        return true; // Additional details step
      case 4:
        return true; // Photos step
      case 5:
        return true; // Review section step
      default:
        return false;
    }
  }

  // ───────────────────── Save / Submit pipeline ─────────────────────

  Future<bool> save() => _persist(submit: false);
  Future<bool> submit() => _persist(submit: true);

  // Future<bool> _persist({required bool submit}) async {
  //   if (state.isBusy) return false;
  //   state = state.copyWith(isSaving: !submit, isSubmitting: submit, clearError: true);
  //   try {
  //     final sellerId = ref.read(mySellerProfileProvider).value?.id; // TODO(import)
  //     if (sellerId == null || sellerId.isEmpty) {
  //       throw Exception('Seller profile not found. Please complete seller registration first.');
  //     }

  //     // 1. create (first time) or update (listingId already known)
  //     var listingId = state.listingId;
  //     if (listingId == null) {
  //       listingId = await _createListing(sellerId);
  //       state = state.copyWith(listingId: listingId); // survives a later failure
  //     } else {
  //       await _updateListing(listingId);
  //     }

  //     // 2. food-details / service-details (skipped for PRODUCT / GROCERY)
  //     await _saveDetails(listingId);

  //     // 3. service availability slots (service types only)
  //     await _saveSlots(listingId);

  //     // 4. images: delete marked ones, then upload pending ones one by one
  //     await _flushImages(listingId);

  //     // 5. submit for approval (Submit button only)
  //     if (submit) await _submitListing(listingId);

  //     return true;
  //   } catch (e) {
  //     state = state.copyWith(error: e);
  //     return false;
  //   } finally {
  //     state = state.copyWith(isSaving: false, isSubmitting: false);
  //   }
  // }

  Future<bool> _persist({required bool submit}) async {
    if (state.isBusy) {
      debugPrint('PERSIST: Already busy');
      return false;
    }

    state = state.copyWith(isSaving: !submit, isSubmitting: submit, clearError: true);

    try {
      debugPrint('PERSIST: Started');

      final sellerId = ref.read(mySellerProfileProvider).value?.id;

      if (sellerId == null || sellerId.isEmpty) {
        throw Exception('Seller profile not found. Please complete seller registration first.');
      }

      var listingId = state.listingId;

      if (listingId == null) {
        debugPrint('PERSIST: Creating listing');
        listingId = await _createListing(sellerId);
        state = state.copyWith(listingId: listingId);
        debugPrint('PERSIST: Listing created: $listingId');
      } else {
        debugPrint('PERSIST: Updating listing: $listingId');
        // await _updateListing(listingId);
        debugPrint('PERSIST: Listing updated');
      }

      debugPrint('PERSIST: Saving details');
      await _saveDetails(listingId);
      debugPrint('PERSIST: Details saved');

      debugPrint('PERSIST: Saving slots');
      await _saveSlots(listingId);
      debugPrint('PERSIST: Slots saved');

      debugPrint('PERSIST: Processing images');
      await _flushImages(listingId);
      debugPrint('PERSIST: Images processed');

      if (submit) {
        debugPrint('PERSIST: Submitting listing');
        await _submitListing(listingId);
        debugPrint('PERSIST: Submitted');
      }

      debugPrint('PERSIST: Completed successfully');
      return true;
    } catch (e, stackTrace) {
      debugPrint('PERSIST ERROR: $e');
      debugPrint('$stackTrace');

      state = state.copyWith(error: e);
      return false;
    } finally {
      state = state.copyWith(isSaving: false, isSubmitting: false);
    }
  }

  // 1 ─────────────────────────────────────────────

  Future<String> _createListing(String sellerId) async {
    // ignore: unused_local_variable
    final payload = _basicPayload(sellerId);

    final result = await repo.createListingRepo(request: payload);

    return result!.id.toString();
  }

  // ignore: unused_element
  Future<void> _updateListing(String listingId) async {
    // ignore: unused_local_variable
    final payload = _basicPayload(null);

    log("update listing payload ${payload.toJson()}");

    await repo.updatesubmitListingRepo(listingId: listingId, request: payload);
  }

  // 2 ─────────────────────────────────────────────

  Future<void> _saveDetails(String listingId) async {
    final type = state.listingType;
    if (type.isFood) {
      // ignore: unused_local_variable
      final foodpayload = _foodPayload();

      // TODO(api): map to your additional-info request model, then:
      state.detailsSaved
          ? await repo.updateadditionalFoodInformationRepo(
              listingId: listingId,
              request: foodpayload,
            ) // PATCH .../food-details
          : await repo.additionalFoodInformationRepo(
              listingId: listingId,
              request: foodpayload,
            ); // POST  .../food-details
    } else if (type.isService) {
      // ignore: unused_local_variable
      final servicepayload = _servicePayload();
      log("save addititonal info ${servicepayload.toJson()}");
      // TODO(api):
      state.detailsSaved
          ? await repo.updateadditionalServiceInformationRepo(
              listingId: listingId,
              request: servicepayload,
            ) // PATCH .../service-details
          : await repo.additionalServiceInformationRepo(
              listingId: listingId,
              request: servicepayload,
            ); // POST  .../service-details
    } else {
      return;
    }

    state = state.copyWith(detailsSaved: true);
  }

  // 3 ─────────────────────────────────────────────

  /// Pushes every edited date's windows to
  /// `PUT /api/v1/service-schedules/listings/{listingId}/availability/{date}`.
  /// PUT replaces the whole date, so re-sending on every Save is safe.
  Future<void> _saveSlots(String listingId) async {
    if (!state.listingType.isService) return;
    for (final entry in state.slots.entries) {
      final windows = entry.value.map((w) => w.toJson()).toList();
      await repo.saveServiceSlotsRepo(listingId: listingId, date: entry.key, windows: windows);
    }
  }

  // 4 ─────────────────────────────────────────────

  /// Flushes pending image changes: deletes removed images via
  /// `DELETE /api/v1/listings/{listingId}/images/{imageId}`, then uploads
  /// queued local photos via `POST /api/v1/listings/{listingId}/images`.
  Future<void> _flushImages(String listingId) async {
    if (state.deletingImageIds.isEmpty && state.pendingImages.isEmpty) return;
    state = state.copyWith(isUploadingImages: true);
    try {
      // 4a. delete images the user removed (already-uploaded ones)
      for (final imageId in List.of(state.deletingImageIds)) {
        log("image is $imageId");
        await repo.deleteListingImageRepo(listingId: listingId, imageId: imageId);
        state = state.copyWith(deletingImageIds: {...state.deletingImageIds}..remove(imageId));
      }

      for (final file in List.of(state.pendingImages)) {
        log("image path ${file.name}");
        await repo.uploadSellerShopImagesRepo(listingId, file);
        removePendingImage(file);
      }
    } finally {
      state = state.copyWith(isUploadingImages: false);
      await refreshRemoteImages(listingId);
    }
  }

  /// Loads images already on the server so the Photos step can show them.
  /// Also call this when opening the screen for an existing listing.
  Future<void> refreshRemoteImages(String listingId) async {
    await repo.getListingImagesRepo(listingId);
  }

  // 5 ─────────────────────────────────────────────

  Future<void> _submitListing(String listingId) async {
    await repo.submitListingRepo(listingId: listingId);
  }

  SellerListingBasicInfoRequest _basicPayload(String? sellerId) {
    final s = state, c = controllers;

    log("base price ${c.basePrice.text}");
    final desc = c.shortDescription.text.trim().isNotEmpty
        ? c.shortDescription.text.trim()
        : (c.detailedDescription.text.trim().isNotEmpty
            ? c.detailedDescription.text.trim()
            : c.description.text.trim());

    return SellerListingBasicInfoRequest(
      additionalCategoryIds: s.additionalCategoryIds.toList(),
      basePrice: s.isFree ? 0 : _d(c.basePrice),
      categoryId: (s.subcategoryId != null && s.subcategoryId!.isNotEmpty)
          ? s.subcategoryId
          : (s.selectedMainCategory?.id ?? s.mainCategoryId),
      description: desc,
      isFree: s.isFree,
      listingType: s.listingType.api,
      priceUnit: s.priceUnit,
      quantityAvailable: _i(c.quantity),
      sellerId: sellerId,
      tagNames: s.tags,
      title: c.title.text.trim(),
    );
  }

  FoodAdditinalInformationRequest _foodPayload() {
    final s = state, c = controllers;
    final prep = c.prepTime.text.trim().isNotEmpty
        ? c.prepTime.text.trim()
        : (RegExp(r'\d+').firstMatch(s.prepTimeMinutes)?.group(0) ?? '30');

    final servings = s.servings.isNotEmpty && s.servings.any((d) => d.isValid)
        ? s.servings
            .where((d) => d.isValid)
            .map(
              (d) => ServingSizeRequest(
                description: d.description.text.trim(),
                isAvailable: d.isAvailable,
                price: num.tryParse(d.price.text.trim()) ?? (_d(c.basePrice) ?? 0),
                quantityAvailable: int.tryParse(d.quantity.text.trim()) ?? (_i(c.quantity) ?? 10),
                sizeUnit: d.sizeUnit.text.trim(),
                sizeValue: num.tryParse(d.sizeValue.text.trim()) ?? 1,
              ),
            )
            .toList()
        : [
            ServingSizeRequest(
              description: 'Standard',
              isAvailable: true,
              price: _d(c.basePrice) ?? 0,
              quantityAvailable: _i(c.quantity) ?? 10,
              sizeUnit: 'portion',
              sizeValue: 1,
            ),
          ];

    return FoodAdditinalInformationRequest(
      allergens: _t(c.allergens),
      expiryTime: s.expiryTime != null ? DateFormat('yyyy-MM-dd').format(s.expiryTime!) : '',
      foodType: s.dietaryType,
      freshnessDeclaration: _t(c.freshness),
      fssaiCertificateId: _t(c.fssaiId),
      fssaiRequired: s.fssaiRequired.toString(),
      ingredients: c.ingredients.text.trim().isNotEmpty ? c.ingredients.text.trim() : 'Fresh ingredients',
      isFrozenItem: s.frozen,
      packagingDetails: _t(c.packaging),
      preparationTime: prep,
      servingSizes: servings,
      spiceLevel: kSpiceLevels[s.spiceLevel] ?? 2,
      spiceLevelText: s.spiceLevel,
      storageInstruction: _t(c.storage),
    );
  }

  ServiceAdditionalInformationRequest _servicePayload() {
    final s = state, c = controllers;

    return ServiceAdditionalInformationRequest(
      cancellationPolicy: _t(c.cancellationPolicy),
      certificateRequired: s.certificateRequired,
      homeVisitAvailable: s.homeVisit,
      onlineAvailable: s.online,
      requiredMaterials: _t(c.requiredMaterials),
      serviceDurationMinutes: _i(c.duration),
      serviceLocationType: s.locationType,
    );
  }
}
