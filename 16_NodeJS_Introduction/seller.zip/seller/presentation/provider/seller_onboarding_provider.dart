import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:society_seva/core/providers/app_providers.dart';
import 'package:society_seva/features/seller/data/datasources/seller_onboarding_remote_data_source.dart';
import 'package:society_seva/features/seller/data/models/request/seller_profile_request.dart';
import 'package:society_seva/features/seller/domain/entities/certificate_entity.dart';
import 'package:society_seva/features/seller/domain/entities/kyc_document_entity.dart';
import 'package:society_seva/features/seller/domain/entities/seller_image_entity.dart';
import 'package:society_seva/features/seller/domain/entities/seller_profile_entity.dart';
import 'package:society_seva/features/seller/domain/repositories/seller_onboarding_respository.dart';
import 'package:society_seva/features/seller/domain/usecase/on_boarding/create_seller_and_daft_usecase.dart';
import 'package:society_seva/features/seller/domain/usecase/on_boarding/delete_seller_image_by_id_use_case.dart';
import 'package:society_seva/features/seller/domain/usecase/on_boarding/download_kyc_document_file_usecase.dart';
import 'package:society_seva/features/seller/domain/usecase/on_boarding/fetch_images_by_seller_id_usecase.dart';
import 'package:society_seva/features/seller/domain/usecase/on_boarding/fetch_seller_profile_by_id_usecase.dart';
import 'package:society_seva/features/seller/domain/usecase/on_boarding/my_seller_profile_usecase.dart';
import 'package:society_seva/features/seller/domain/usecase/on_boarding/submit_seller_usecase.dart';
import 'package:society_seva/features/seller/domain/usecase/on_boarding/update_seller_profile_by_id_use_case.dart';
import 'package:society_seva/features/seller/domain/usecase/on_boarding/upload_images_by_seller_id_usecase.dart';

final sellerOnBoardingRemoteDataSource = Provider<SellerOnboardingRemoteDataSource>((ref) {
  return SellerOnboardingRemoteDataSourceImpl(apiClient: ref.watch(apiClientProvider));
});

final sellerOnBoardingRepository = Provider<SellerOnboardingRespository>((ref) {
  return SellerOnboardingRespositoryImpl(
    sellerOnboardingRemoteDataSource: ref.watch(sellerOnBoardingRemoteDataSource),
  );
});

final mySellerProfileUseCase = Provider<MySellerProfileUsecase>((ref) {
  return MySellerProfileUsecase(ref.watch(sellerOnBoardingRepository));
});

final fetchSellerProfileByIdUsecase = Provider<FetchSellerProfileByIdUsecase>((ref) {
  return FetchSellerProfileByIdUsecase(ref.watch(sellerOnBoardingRepository));
});

final createAndDraftSellerUsecase = Provider<CreateSellerAndDaftUsecase>((ref) {
  return CreateSellerAndDaftUsecase(ref.watch(sellerOnBoardingRepository));
});

final submitSellerProfileUsecase = Provider<SubmitSellerUseCase>((ref) {
  return SubmitSellerUseCase(ref.watch(sellerOnBoardingRepository));
});

final updateSellerProfileUseCase = Provider<UpdateSellerProfileByIdUseCase>((ref) {
  return UpdateSellerProfileByIdUseCase(ref.watch(sellerOnBoardingRepository));
});

final uploadImagesBySellerIdUsecase = Provider<UploadImagesBySellerIdUsecase>((ref) {
  return UploadImagesBySellerIdUsecase(ref.watch(sellerOnBoardingRepository));
});

final deleteSellerImagesByIDUsecase = Provider<DeleteSellerImageByIdUseCase>((ref) {
  return DeleteSellerImageByIdUseCase(ref.watch(sellerOnBoardingRepository));
});

final fetchSellerImagesByIDUsecase = Provider<FetchImagesBySellerIdUsecase>((ref) {
  return FetchImagesBySellerIdUsecase(ref.watch(sellerOnBoardingRepository));
});

/// Wraps GET /api/v1/sellers/{sellerId}/kyc/{documentFileUrl}/file.
/// Call it on demand (e.g. from a "download"/"view" button) - it is not a
/// FutureProvider because the file isn't needed until the user asks for it.
final downloadKycDocumentFileUsecase = Provider<DownloadKycDocumentFileUsecase>((ref) {
  return DownloadKycDocumentFileUsecase(ref.watch(sellerOnBoardingRepository));
});

final sellerCertificatesProvider = FutureProvider.autoDispose
    .family<List<CertificateEntity>, String>((ref, sellerId) {
      return ref.read(sellerOnBoardingRepository).fetchCertificatesRepo(sellerId);
    });
final sellerDocumentProvider = FutureProvider.autoDispose.family<List<KycDocumentEntity>, String>((
  ref,
  sellerId,
) {
  return ref.read(sellerOnBoardingRepository).fetchKYCDocumentRepo(sellerId);
});

final fetchSellerUploadedImagesProvider =
    AsyncNotifierProvider.family<FetchImagesBySellerIDNotifier, List<SellerImageEntity>?, String>(
      FetchImagesBySellerIDNotifier.new,
    );

class FetchImagesBySellerIDNotifier extends FamilyAsyncNotifier<List<SellerImageEntity>?, String> {
  late FetchImagesBySellerIdUsecase _useCase;

  @override
  Future<List<SellerImageEntity>?> build(String sellerId) async {
    _useCase = ref.read(fetchSellerImagesByIDUsecase);

    return await _useCase.call(sellerId: sellerId);
  }

  Future<List<SellerImageEntity>?> fetchSellerImages() async {
    state = const AsyncLoading();

    state = await AsyncValue.guard(() => _useCase.call(sellerId: arg));
    return state.value;
  }
}

final mySellerProfileProvider =
    AsyncNotifierProvider<MySellerProfileNotifier, SellerProfileEntity?>(
      MySellerProfileNotifier.new,
    );

class MySellerProfileNotifier extends AsyncNotifier<SellerProfileEntity?> {
  late MySellerProfileUsecase _useCase;

  @override
  Future<SellerProfileEntity?> build() async {
    _useCase = ref.read(mySellerProfileUseCase);
    return fetchMySellerProfile();
  }

  Future<SellerProfileEntity?> fetchMySellerProfile() async {
    state = const AsyncLoading();

    state = await AsyncValue.guard(() async {
      return await _useCase.call();
    });

    return state.value;
  }

  Future<SellerProfileEntity?> refresh() => fetchMySellerProfile();
}

final sellerFormActionProvider = NotifierProvider<SellerFormActionNotifier, SellerFormState>(
  SellerFormActionNotifier.new,
);

class SellerFormActionNotifier extends Notifier<SellerFormState> {
  @override
  SellerFormState build() => const SellerFormState();

  void addPendingImage(XFile file) =>
      state = state.copyWith(queuedImages: [...state.queuedImages, file]);

  void removePendingImage(XFile file) => state = state.copyWith(
    queuedImages: state.queuedImages.where((f) => f.path != file.path).toList(),
  );

  void markImageForDelete(String imageId) =>
      state = state.copyWith(pendingDeleteImageIds: {...state.pendingDeleteImageIds, imageId});

  void unmarkImageForDelete(String imageId) => state = state.copyWith(
    pendingDeleteImageIds: state.pendingDeleteImageIds.where((id) => id != imageId).toSet(),
  );

  void addPendingDocument(PendingDocument doc) =>
      state = state.copyWith(pendingDocuments: [...state.pendingDocuments, doc]);

  void removePendingDocument(PendingDocument doc) => state = state.copyWith(
    pendingDocuments: state.pendingDocuments.where((d) => d != doc).toList(),
  );

  void addPendingCertificate(PendingCertificate cert) =>
      state = state.copyWith(pendingCertificates: [...state.pendingCertificates, cert]);

  void removePendingCertificate(PendingCertificate cert) => state = state.copyWith(
    pendingCertificates: state.pendingCertificates.where((c) => c != cert).toList(),
  );

  String? get currentSellerId {
    final id = ref.read(mySellerProfileProvider).value?.id;
    return (id == null || id.isEmpty) ? null : id;
  }

  Future<void> _flushPendingUploads(String sellerId) async {
    state = state.copyWith(isUploadingImages: true);
    try {
      for (final file in List.of(state.queuedImages)) {
        await ref.read(uploadImagesBySellerIdUsecase).call(sellerId: sellerId, file: file);
        removePendingImage(file);
      }
      for (final imageId in List.of(state.pendingDeleteImageIds)) {
        await ref.read(deleteSellerImagesByIDUsecase).call(imageId: imageId, sellerId: sellerId);
        unmarkImageForDelete(imageId);
      }
    } finally {
      state = state.copyWith(isUploadingImages: false);
      ref.invalidate(fetchSellerUploadedImagesProvider(sellerId));
    }

    final repo = ref.read(sellerOnBoardingRepository);
    for (final doc in List.of(state.pendingDocuments)) {
      await repo.uploadKYCDocumentRepo(
        sellerId: sellerId,
        documentType: doc.type,
        documentNumber: doc.number,
        file: doc.file,
      );
      removePendingDocument(doc);
    }
    ref.invalidate(sellerCertificatesProvider(sellerId));

    for (final cert in List.of(state.pendingCertificates)) {
      await repo.uploadCertificateRepo(
        sellerId: sellerId,
        file: cert.file,
        certificateName: cert.name,
        certificateNumber: cert.certificateNumber.toString(),
        certificateType: cert.type.toString(),
        issueAuthority: cert.issuingAuthority.toString(),
        issueDate: cert.issueDate,
        hasExpiry: cert.hasExpiry,
        expiryDate: cert.expiryDate,
      );
      removePendingCertificate(cert);
    }
    ref.invalidate(sellerCertificatesProvider(sellerId));
  }

  Future<bool> save(SellerProfileRequest request) async {
    state = state.copyWith(isSaving: true, clearError: true);
    try {
      await ref.read(createAndDraftSellerUsecase).call(request: request);
      final seller = await ref.read(mySellerProfileProvider.notifier).refresh();
      if (seller == null) {
        throw Exception('Draft was saved but the seller profile could not be loaded.');
      }
      await _flushPendingUploads(seller.id);
      return true;
    } catch (e) {
      state = state.copyWith(error: e);
      return false;
    } finally {
      state = state.copyWith(isSaving: false);
    }
  }

  Future<bool> submit(SellerProfileRequest request) async {
    state = state.copyWith(isSubmitting: true, clearError: true);
    try {
      var sellerId = currentSellerId;
      if (sellerId == null) {
        await ref.read(createAndDraftSellerUsecase).call(request: request);
        final seller = await ref.read(mySellerProfileProvider.notifier).refresh();
        if (seller == null) {
          throw Exception('Draft was saved but the seller profile could not be loaded.');
        }
        sellerId = seller.id;
      }

      await ref.read(submitSellerProfileUsecase).call(sellerId);
      await _flushPendingUploads(sellerId);
      await ref.read(mySellerProfileProvider.notifier).refresh();
      return true;
    } catch (e) {
      state = state.copyWith(error: e);
      return false;
    } finally {
      state = state.copyWith(isSubmitting: false);
    }
  }

  Future<bool> update(SellerProfileRequest request, String sellerId) async {
    state = state.copyWith(isSubmitting: true, clearError: true);
    try {
      if (!request.isEmpty) {
        await ref.read(updateSellerProfileUseCase).call(request: request, sellerId: sellerId);
      }
      await _flushPendingUploads(sellerId);
      await ref.read(mySellerProfileProvider.notifier).refresh();
      return true;
    } catch (e) {
      state = state.copyWith(error: e);
      return false;
    } finally {
      state = state.copyWith(isSubmitting: false);
    }
  }
}

class SellerFormState {
  final bool isSaving;
  final bool isSubmitting;
  final bool isUploadingImages;
  final List<XFile> queuedImages;
  final Set<String> pendingDeleteImageIds;
  final List<PendingDocument> pendingDocuments;
  final List<PendingCertificate> pendingCertificates;
  final Object? error;

  const SellerFormState({
    this.isSaving = false,
    this.isSubmitting = false,
    this.isUploadingImages = false,
    this.queuedImages = const [],
    this.pendingDeleteImageIds = const {},
    this.pendingDocuments = const [],
    this.pendingCertificates = const [],
    this.error,
  });

  bool get isBusy => isSaving || isSubmitting || isUploadingImages;

  SellerFormState copyWith({
    bool? isSaving,
    bool? isSubmitting,
    bool? isUploadingImages,
    List<XFile>? queuedImages,
    Set<String>? pendingDeleteImageIds,
    List<PendingDocument>? pendingDocuments,
    List<PendingCertificate>? pendingCertificates,
    Object? error,
    bool clearError = false,
  }) => SellerFormState(
    isSaving: isSaving ?? this.isSaving,
    isSubmitting: isSubmitting ?? this.isSubmitting,
    isUploadingImages: isUploadingImages ?? this.isUploadingImages,
    queuedImages: queuedImages ?? this.queuedImages,
    pendingDeleteImageIds: pendingDeleteImageIds ?? this.pendingDeleteImageIds,
    pendingDocuments: pendingDocuments ?? this.pendingDocuments,
    pendingCertificates: pendingCertificates ?? this.pendingCertificates,
    error: clearError ? null : (error ?? this.error),
  );
}

class PendingDocument {
  const PendingDocument({required this.type, required this.number, required this.file});

  final String type;
  final String number;
  final XFile file;
}

class PendingCertificate {
  const PendingCertificate({
    required this.name,
    required this.file,
    required this.issueDate,
    required this.hasExpiry,
    this.certificateNumber,
    this.issuingAuthority,
    this.type,
    this.expiryDate,
  });

  final String? type;
  final String name;
  final String? certificateNumber;
  final String? issuingAuthority;
  final XFile file;
  final DateTime issueDate;
  final bool hasExpiry;
  final DateTime? expiryDate;
}

class SellerActionState {
  const SellerActionState({
    this.isSaving = false,
    this.isSubmitting = false,
    this.isUploading = false,
    this.pendingImages = const [],
    this.pendingDocuments = const [],
    this.pendingCertificates = const [],
    this.pendingDeleteImageIds = const {},
    this.error,
  });

  final bool isSaving;
  final bool isSubmitting;
  final bool isUploading;
  final List<XFile> pendingImages;
  final Set<String> pendingDeleteImageIds;
  final List<PendingDocument>? pendingDocuments;
  final List<PendingCertificate>? pendingCertificates;
  final Object? error;

  bool get isBusy => isSaving || isSubmitting || isUploading;

  SellerActionState copyWith({
    bool? isSaving,
    bool? isSubmitting,
    bool? isUploading,
    List<XFile>? pendingImages,
    Set<String>? pendingDeleteImageIds,
    Object? error,
    bool clearError = false,
    List<PendingDocument>? pendingDocuments,
    List<PendingCertificate>? pendingCertificates,
  }) {
    return SellerActionState(
      isSaving: isSaving ?? this.isSaving,
      isSubmitting: isSubmitting ?? this.isSubmitting,
      isUploading: isUploading ?? this.isUploading,
      pendingImages: pendingImages ?? this.pendingImages,
      error: clearError ? null : (error ?? this.error),
      pendingDocuments: pendingDocuments ?? this.pendingDocuments,
      pendingCertificates: pendingCertificates ?? this.pendingCertificates,
      pendingDeleteImageIds: pendingDeleteImageIds ?? this.pendingDeleteImageIds,
    );
  }
}
