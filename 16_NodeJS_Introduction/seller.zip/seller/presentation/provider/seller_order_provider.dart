import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/core/providers/app_providers.dart';
import 'package:society_seva/features/seller/data/datasources/seller_order_remote_data_source.dart';
import 'package:society_seva/features/seller/domain/entities/seller_order_entity.dart';
import 'package:society_seva/features/seller/domain/repositories/seller_order_repository.dart';

final sellerOrderRemoteDataSource = Provider<SellerOrderRemoteDataSource>((ref) {
  return SellerOrderRemoteDataSourceImpl(ref.watch(apiClientProvider));
});

final sellerOrderRepository = Provider<SellerOrderRepository>((ref) {
  return SellerOrderRepositoryImpl(ref.watch(sellerOrderRemoteDataSource));
});

/// The logged-in seller's orders. Backed by `GET /api/v1/orders?sellerId=`
/// (currently returns static sample data - see seller_order_remote_data_source.dart).
final sellerOrdersProvider = FutureProvider.autoDispose
    .family<PageResponse<SellerOrderEntity>, String>((ref, sellerId) {
      return ref.watch(sellerOrderRepository).fetchSellerOrdersRepo(sellerId: sellerId);
    });

/// Statuses a seller can move an order to, per the API doc. The valid "from"
/// state depends on order type (e.g. IN_SERVICE only applies to bookings),
/// so this is intentionally the full set - narrow it down once the real UI
/// design says which buttons should show for which order.
const kSellerOrderTransitions = <String>[
  'ACCEPTED',
  'REJECTED',
  'PREPARING',
  'READY_FOR_PICKUP',
  'OUT_FOR_DELIVERY',
  'IN_SERVICE',
  'COMPLETED',
];

/// Drives the "transition order status" action so the orders screen can show
/// a per-order busy/error state without re-fetching the whole list.
class SellerOrderActionState {
  const SellerOrderActionState({this.busyOrderId, this.error});

  final String? busyOrderId;
  final Object? error;

  bool isBusy(String orderId) => busyOrderId == orderId;
}

final sellerOrderActionProvider =
    NotifierProvider<SellerOrderActionNotifier, SellerOrderActionState>(
      SellerOrderActionNotifier.new,
    );

class SellerOrderActionNotifier extends Notifier<SellerOrderActionState> {
  @override
  SellerOrderActionState build() => const SellerOrderActionState();

  /// Calls `POST /api/v1/orders/{orderId}/transition` (static response for
  /// now) and refreshes the seller's order list on success.
  Future<bool> transition({
    required String sellerId,
    required String orderId,
    required String newStatus,
    String? note,
  }) async {
    state = SellerOrderActionState(busyOrderId: orderId);
    try {
      await ref
          .read(sellerOrderRepository)
          .transitionOrderRepo(orderId: orderId, newStatus: newStatus, note: note);
      ref.invalidate(sellerOrdersProvider(sellerId));
      state = const SellerOrderActionState();
      return true;
    } catch (e) {
      state = SellerOrderActionState(error: e);
      return false;
    }
  }
}
