import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/core/providers/app_providers.dart';
import 'package:society_seva/features/seller/data/datasources/seller_category_remote_datasource.dart';
import 'package:society_seva/features/seller/domain/entities/seller_category_entity.dart';
import 'package:society_seva/features/seller/domain/repositories/seller_category_respository.dart';
import 'package:society_seva/features/shop/data/models/shop_category_model.dart';

final sellerCategoryRemoteDataSource = Provider<SellerCategoryRemoteDatasource>((ref) {
  return SellerCategoryRemoteDatasourceImpl(ref.watch(apiClientProvider));
});

final sellerCategoryRespository = Provider<SellerCategoryRespository>((ref) {
  return SellerCategoryRespositoryImpl(ref.watch(sellerCategoryRemoteDataSource));
});

final sellerCategoryListingProvier =
    FutureProvider.family<
      PageResponse<CategoriesEntity>,
      ({String? categoryType, String? parentCategoryId, bool? rootsOnly, String? search})
    >((ref, args) {
      return ref
          .watch(sellerCategoryRespository)
          .fetchCategoriesRepo(
            categoryType: args.categoryType,
            parentCategoryId: args.parentCategoryId,
            rootsOnly: args.rootsOnly,
            search: args.search,
          );
    });

final sellerCategorytreeProvier = FutureProvider<List<ShopCategoryModel>>((ref) {
  return ref.watch(sellerCategoryRespository).fetchCategoriesTreeRepo();
});
