import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/screens/orders/models/seller_order_ui_model.dart';
import 'package:society_seva/features/seller/presentation/screens/orders/widgets/seller_order_app_bar.dart';

class SellerOrderAcceptedScreen extends StatelessWidget {
  const SellerOrderAcceptedScreen({
    super.key,
    this.order,
  });

  final SellerOrderUiModel? order;

  @override
  Widget build(BuildContext context) {
    final currentOrder = order ?? SellerOrderUiModel.sampleOrders.first;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: const SellerOrderAppBar(showBack: true),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                child: Column(
                  children: [
                    const SizedBox(height: 10),
                    // Large circular green checkmark
                    Container(
                      width: 58,
                      height: 58,
                      decoration: const BoxDecoration(
                        color: AppColors.green,
                        shape: BoxShape.circle,
                      ),
                      child: const Center(
                        child: Icon(
                          Icons.check_rounded,
                          color: Colors.white,
                          size: 36,
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    Text(
                      'Order Accepted',
                      style: AppTheme.display(20, w: FontWeight.w800, c: AppColors.ink),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'You have accepted the order.\nNow prepare the order and mark it\nas ready when done.',
                      textAlign: TextAlign.center,
                      style: AppTheme.hind(14, c: AppColors.muted, h: 1.4),
                    ),
                    const SizedBox(height: 28),
                    // Timeline steps container
                    _buildTimelineCard(currentOrder),
                    const SizedBox(height: 20),
                    // Information tip banner
                    _buildInfoTipBanner(),
                  ],
                ),
              ),
            ),
            _buildBottomButtons(context, currentOrder),
          ],
        ),
      ),
    );
  }

  Widget _buildTimelineCard(SellerOrderUiModel order) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: [
          _buildVerticalStep(
            icon: Icons.check_circle_rounded,
            iconColor: AppColors.green,
            title: 'Order Accepted',
            subtitle: '15 Oct 2026, 10:20 AM',
            isCompleted: true,
            hasLineBelow: true,
          ),
          _buildVerticalStep(
            icon: Icons.circle_outlined,
            iconColor: AppColors.border,
            title: 'Preparing',
            subtitle: null,
            isCompleted: false,
            hasLineBelow: true,
          ),
          _buildVerticalStep(
            icon: Icons.circle_outlined,
            iconColor: AppColors.border,
            title: 'Ready for Pickup',
            subtitle: null,
            isCompleted: false,
            hasLineBelow: true,
          ),
          _buildVerticalStep(
            icon: Icons.circle_outlined,
            iconColor: AppColors.border,
            title: 'Completed',
            subtitle: null,
            isCompleted: false,
            hasLineBelow: false,
          ),
        ],
      ),
    );
  }

  Widget _buildVerticalStep({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String? subtitle,
    required bool isCompleted,
    required bool hasLineBelow,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          children: [
            Icon(icon, color: iconColor, size: 22),
            if (hasLineBelow)
              Container(
                width: 1.5,
                height: 38,
                color: isCompleted ? AppColors.green : AppColors.border,
              ),
          ],
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: AppTheme.hind(
                  14,
                  w: isCompleted ? FontWeight.w700 : FontWeight.w500,
                  c: isCompleted ? AppColors.ink : AppColors.muted,
                ),
              ),
              if (subtitle != null) ...[
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: AppTheme.hind(12, c: AppColors.muted),
                ),
              ],
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildInfoTipBanner() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.greenSoft,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.green.withValues(alpha: 0.3)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(
            Icons.info_outline_rounded,
            color: AppColors.green,
            size: 20,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              "Please prepare the order and mark it as 'Ready for Pickup' when it is ready.",
              style: AppTheme.hind(13, c: AppColors.greenDeep, h: 1.3),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomButtons(BuildContext context, SellerOrderUiModel order) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: AppColors.border)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: () {
                context.push('/modules/seller/orders/details', extra: order);
              },
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: AppColors.border),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: Text(
                'View Order Details',
                style: AppTheme.hind(14, w: FontWeight.w600, c: AppColors.ink),
              ),
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                context.go('/modules/seller/orders');
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.green,
                foregroundColor: Colors.white,
                elevation: 0,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: Text(
                'Go to Orders',
                style: AppTheme.hind(14, w: FontWeight.w600, c: Colors.white),
              ),
            ),
          ),
          const SizedBox(height: 6),
          // Helper link for quick flow testing to next screen
          TextButton(
            onPressed: () {
              context.push('/modules/seller/orders/preparing', extra: order);
            },
            child: Text(
              'Next: Mark as Preparing ->',
              style: AppTheme.hind(13, w: FontWeight.w600, c: AppColors.blue),
            ),
          ),
        ],
      ),
    );
  }
}
