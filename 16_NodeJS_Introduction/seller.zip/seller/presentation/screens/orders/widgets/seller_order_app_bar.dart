import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:society_seva/app/theme/app_theme.dart';

class SellerOrderAppBar extends StatelessWidget implements PreferredSizeWidget {
  const SellerOrderAppBar({
    super.key,
    this.showBack = true,
    this.onBack,
    this.showNotification = false,
    this.notificationCount = 1,
    this.actions,
    this.bottom,
  });

  final bool showBack;
  final VoidCallback? onBack;
  final bool showNotification;
  final int notificationCount;
  final List<Widget>? actions;
  final PreferredSizeWidget? bottom;

  @override
  Size get preferredSize => Size.fromHeight(kToolbarHeight + (bottom?.preferredSize.height ?? 0));

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: Colors.white,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      centerTitle: true,
      leading: showBack
          ? IconButton(
              icon: const Icon(Icons.arrow_back, color: AppColors.ink),
              onPressed: () {
                if (onBack != null) {
                  onBack!();
                } else if (Navigator.of(context).canPop()) {
                  Navigator.of(context).pop();
                } else {
                  context.go('/modules/seller/orders');
                }
              },
            )
          : null,
      title: Image.asset(
        'assets/images/logo/h-logo.png',
        height: 30,
        fit: BoxFit.contain,
        errorBuilder: (context, error, stackTrace) => Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.eco_rounded, color: AppColors.green, size: 24),
            const SizedBox(width: 6),
            Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Vasundhara SEVA',
                  style: AppTheme.display(
                    17,
                    w: FontWeight.w800,
                    c: AppColors.green,
                  ),
                ),
                Text(
                  'Earn Together  Live Together',
                  style: AppTheme.hind(8, w: FontWeight.w500, c: AppColors.muted),
                ),
              ],
            ),
          ],
        ),
      ),
      actions: actions ??
          (showNotification
              ? [
                  Padding(
                    padding: const EdgeInsets.only(right: 12),
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        IconButton(
                          onPressed: () {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Order notifications up to date.')),
                            );
                          },
                          icon: const Icon(Icons.notifications_none_rounded, color: AppColors.ink, size: 24),
                        ),
                        if (notificationCount > 0)
                          Positioned(
                            top: 10,
                            right: 10,
                            child: Container(
                              width: 8,
                              height: 8,
                              decoration: const BoxDecoration(
                                color: AppColors.red,
                                shape: BoxShape.circle,
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ]
              : null),
      bottom: bottom,
    );
  }
}
