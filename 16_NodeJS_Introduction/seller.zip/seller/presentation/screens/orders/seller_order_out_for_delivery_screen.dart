import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_order_provider.dart';
import 'package:society_seva/features/seller/presentation/screens/orders/models/seller_order_ui_model.dart';
import 'package:society_seva/features/seller/presentation/screens/orders/widgets/seller_order_app_bar.dart';
import 'package:society_seva/features/seller/presentation/screens/orders/widgets/seller_order_stepper.dart';

class SellerOrderOutForDeliveryScreen extends ConsumerStatefulWidget {
  const SellerOrderOutForDeliveryScreen({
    super.key,
    this.order,
  });

  final SellerOrderUiModel? order;

  @override
  ConsumerState<SellerOrderOutForDeliveryScreen> createState() =>
      _SellerOrderOutForDeliveryScreenState();
}

class _SellerOrderOutForDeliveryScreenState
    extends ConsumerState<SellerOrderOutForDeliveryScreen> {
  late TextEditingController _noteController;
  late SellerOrderUiModel _order;

  @override
  void initState() {
    super.initState();
    _order = widget.order ?? SellerOrderUiModel.sampleOrders.first;
    _noteController = TextEditingController(
      text: 'Your order is out for delivery. Please keep your phone nearby.',
    );
  }

  @override
  void dispose() {
    _noteController.dispose();
    super.dispose();
  }

  void _onConfirmOutForDelivery() {
    final updated = _order.copyWith(
      status: SellerOrderStatus.outForDelivery,
      note: _noteController.text.trim(),
    );

    final sellerId = ref.read(mySellerProfileProvider.select((s) => s.valueOrNull?.id));
    if (sellerId != null && sellerId.isNotEmpty) {
      ref.read(sellerOrderActionProvider.notifier).transition(
            sellerId: sellerId,
            orderId: updated.id,
            newStatus: 'OUT_FOR_DELIVERY',
            note: _noteController.text.trim(),
          );
    }

    context.push('/modules/seller/orders/completed', extra: updated);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: const SellerOrderAppBar(showBack: true),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      'Update Order Status',
                      style: AppTheme.display(18, w: FontWeight.w800, c: AppColors.ink),
                    ),
                    const SizedBox(height: 16),
                    // Stepper: Accepted, Preparing, Ready, Out for Delivery
                    const SellerOrderStepper(
                      activeColor: AppColors.blue,
                      steps: [
                        OrderStepItem(
                          title: 'Accepted',
                          icon: Icons.check,
                          isCompleted: true,
                        ),
                        OrderStepItem(
                          title: 'Preparing',
                          icon: Icons.soup_kitchen_outlined,
                          isCompleted: true,
                        ),
                        OrderStepItem(
                          title: 'Ready',
                          icon: Icons.shopping_bag_outlined,
                          isCompleted: true,
                        ),
                        OrderStepItem(
                          title: 'Out for Delivery',
                          icon: Icons.local_shipping_outlined,
                          isActive: true,
                        ),
                      ],
                    ),
                    const SizedBox(height: 32),
                    // Delivery truck icon circle
                    Container(
                      width: 80,
                      height: 80,
                      decoration: const BoxDecoration(
                        color: AppColors.blueSoft,
                        shape: BoxShape.circle,
                      ),
                      child: const Center(
                        child: Icon(
                          Icons.local_shipping_outlined,
                          color: AppColors.blue,
                          size: 42,
                        ),
                      ),
                    ),
                    const SizedBox(height: 18),
                    Text(
                      'Out for Delivery',
                      style: AppTheme.display(18, w: FontWeight.w700, c: AppColors.ink),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'Mark the order as out for delivery.',
                      textAlign: TextAlign.center,
                      style: AppTheme.hind(14, c: AppColors.muted),
                    ),
                    const SizedBox(height: 28),
                    // Add note section
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'Add a note to customer (Optional)',
                        style: AppTheme.hind(13, w: FontWeight.w600, c: AppColors.ink),
                      ),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _noteController,
                      maxLines: 4,
                      maxLength: 200,
                      style: AppTheme.hind(14, c: AppColors.ink),
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: const Color(0xFFF9FAFB),
                        hintText: 'Add an optional note about delivery status...',
                        hintStyle: AppTheme.hind(13, c: AppColors.muted),
                        contentPadding: const EdgeInsets.all(14),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(color: AppColors.border),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(color: AppColors.border),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(color: AppColors.blue, width: 1.5),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // Bottom button
            Container(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
              decoration: const BoxDecoration(
                color: Colors.white,
                border: Border(top: BorderSide(color: AppColors.border)),
              ),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _onConfirmOutForDelivery,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.green,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: Text(
                    'Mark as Out for Delivery',
                    style: AppTheme.hind(15, w: FontWeight.w600, c: Colors.white),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
