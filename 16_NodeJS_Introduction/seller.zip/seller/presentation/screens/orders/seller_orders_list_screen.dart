import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_order_provider.dart';
import 'package:society_seva/features/seller/presentation/screens/orders/models/seller_order_ui_model.dart';
import 'package:society_seva/features/seller/presentation/screens/orders/widgets/seller_order_app_bar.dart';

enum OrderFilterTab {
  all('All'),
  pending('Pending'),
  preparing('Preparing'),
  ready('Ready'),
  outForDelivery('Out for Delivery'),
  completed('Completed'),
  cancelled('Cancelled');

  const OrderFilterTab(this.label);
  final String label;
}

class SellerOrdersListScreen extends ConsumerStatefulWidget {
  const SellerOrdersListScreen({
    super.key,
    this.isEmbeddedTab = false,
  });

  final bool isEmbeddedTab;

  @override
  ConsumerState<SellerOrdersListScreen> createState() => _SellerOrdersListScreenState();
}

class _SellerOrdersListScreenState extends ConsumerState<SellerOrdersListScreen> {
  OrderFilterTab _selectedTab = OrderFilterTab.all;
  late List<SellerOrderUiModel> _orders;

  @override
  void initState() {
    super.initState();
    _orders = List.from(SellerOrderUiModel.sampleOrders);
  }

  int _countFor(OrderFilterTab tab) {
    switch (tab) {
      case OrderFilterTab.all:
        return _orders.length;
      case OrderFilterTab.pending:
        return _orders.where((o) => o.status == SellerOrderStatus.pendingAcceptance).length;
      case OrderFilterTab.preparing:
        return _orders.where((o) => o.status == SellerOrderStatus.preparing).length;
      case OrderFilterTab.ready:
        return _orders.where((o) => o.status == SellerOrderStatus.ready).length;
      case OrderFilterTab.outForDelivery:
        return _orders.where((o) => o.status == SellerOrderStatus.outForDelivery).length;
      case OrderFilterTab.completed:
        return _orders.where((o) => o.status == SellerOrderStatus.completed).length;
      case OrderFilterTab.cancelled:
        return _orders.where((o) => o.status == SellerOrderStatus.cancelled).length;
    }
  }

  List<SellerOrderUiModel> get _filteredOrders {
    switch (_selectedTab) {
      case OrderFilterTab.all:
        return _orders;
      case OrderFilterTab.pending:
        return _orders.where((o) => o.status == SellerOrderStatus.pendingAcceptance).toList();
      case OrderFilterTab.preparing:
        return _orders.where((o) => o.status == SellerOrderStatus.preparing).toList();
      case OrderFilterTab.ready:
        return _orders.where((o) => o.status == SellerOrderStatus.ready).toList();
      case OrderFilterTab.outForDelivery:
        return _orders.where((o) => o.status == SellerOrderStatus.outForDelivery).toList();
      case OrderFilterTab.completed:
        return _orders.where((o) => o.status == SellerOrderStatus.completed).toList();
      case OrderFilterTab.cancelled:
        return _orders.where((o) => o.status == SellerOrderStatus.cancelled).toList();
    }
  }

  void _onAcceptOrder(SellerOrderUiModel order) {
    setState(() {
      final index = _orders.indexWhere((o) => o.id == order.id);
      if (index != -1) {
        _orders[index] = order.copyWith(status: SellerOrderStatus.accepted);
      }
    });

    // Also trigger provider transition if real backend exists
    final sellerId = ref.read(mySellerProfileProvider.select((s) => s.valueOrNull?.id));
    if (sellerId != null && sellerId.isNotEmpty) {
      ref.read(sellerOrderActionProvider.notifier).transition(
            sellerId: sellerId,
            orderId: order.id,
            newStatus: 'ACCEPTED',
          );
    }

    context.push(
      '/modules/seller/orders/accepted',
      extra: order.copyWith(status: SellerOrderStatus.accepted),
    );
  }

  void _onViewOrder(SellerOrderUiModel order) {
    if (order.status == SellerOrderStatus.completed) {
      context.push('/modules/seller/orders/completed', extra: order);
    } else if (order.status == SellerOrderStatus.cancelled) {
      if (order.cancelledBy == 'Customer') {
        context.push('/modules/seller/orders/cancelled-customer', extra: order);
      } else {
        context.push('/modules/seller/orders/cancelled-seller', extra: order);
      }
    } else if (order.status == SellerOrderStatus.preparing) {
      context.push('/modules/seller/orders/preparing', extra: order);
    } else if (order.status == SellerOrderStatus.ready) {
      context.push('/modules/seller/orders/ready', extra: order);
    } else if (order.status == SellerOrderStatus.outForDelivery) {
      context.push('/modules/seller/orders/out-for-delivery', extra: order);
    } else {
      context.push('/modules/seller/orders/details', extra: order);
    }
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _filteredOrders;

    final content = Scaffold(
      backgroundColor: Colors.white,
      appBar: SellerOrderAppBar(
        showBack: !widget.isEmbeddedTab && Navigator.of(context).canPop(),
        showNotification: true,
        notificationCount: 1,
      ),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: Text(
                'Orders',
                style: AppTheme.display(22, w: FontWeight.w800, c: AppColors.ink),
              ),
            ),
            _buildFilterTabs(),
            const SizedBox(height: 8),
            Expanded(
              child: filtered.isEmpty
                  ? _buildEmptyState()
                  : ListView.separated(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      itemCount: filtered.length,
                      separatorBuilder: (context, index) => const SizedBox(height: 12),
                      itemBuilder: (context, index) {
                        return _buildOrderCard(filtered[index]);
                      },
                    ),
            ),
          ],
        ),
      ),
    );

    return content;
  }

  Widget _buildFilterTabs() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: Row(
        children: OrderFilterTab.values.map((tab) {
          final isSelected = _selectedTab == tab;
          final count = _countFor(tab);
          String label = tab.label;
          if (tab == OrderFilterTab.pending || tab == OrderFilterTab.preparing) {
            label = '${tab.label} ($count)';
          }

          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: InkWell(
              onTap: () => setState(() => _selectedTab = tab),
              borderRadius: BorderRadius.circular(20),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: isSelected ? AppColors.green : Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: isSelected ? AppColors.green : AppColors.border,
                    width: 1.2,
                  ),
                ),
                child: Text(
                  label,
                  style: AppTheme.hind(
                    13,
                    w: isSelected ? FontWeight.w600 : FontWeight.w500,
                    c: isSelected ? Colors.white : AppColors.muted,
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildOrderCard(SellerOrderUiModel order) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.02),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header row: #ORD12345, Today 10:15 AM & Status badge
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      order.orderNumber,
                      style: AppTheme.display(15, w: FontWeight.w700, c: AppColors.ink),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      order.orderDate,
                      style: AppTheme.hind(12, c: AppColors.muted),
                    ),
                  ],
                ),
              ),
              _buildStatusBadge(order.status),
            ],
          ),
          const SizedBox(height: 14),
          // Middle row: Customer avatar, name, item description, delivery type and price
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(
                radius: 20,
                backgroundColor: AppColors.orangeSoft,
                child: Text(
                  order.customerName.isNotEmpty ? order.customerName[0] : 'C',
                  style: AppTheme.display(16, w: FontWeight.w700, c: AppColors.orange),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      order.customerName,
                      style: AppTheme.display(14, w: FontWeight.w600, c: AppColors.ink),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${order.itemsSummary} (${order.itemCount})',
                      style: AppTheme.hind(13, c: AppColors.muted),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${order.deliveryType} | ${order.pickupOrDeliveryTime}',
                      style: AppTheme.hind(12, c: AppColors.ink, w: FontWeight.w500),
                    ),
                  ],
                ),
              ),
              Text(
                '₹ ${order.totalAmount.toStringAsFixed(0)}',
                style: AppTheme.display(16, w: FontWeight.w800, c: AppColors.ink),
              ),
            ],
          ),
          const SizedBox(height: 16),
          // Bottom action buttons: View, Accept
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => _onViewOrder(order),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.ink,
                    side: const BorderSide(color: AppColors.border),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                  child: Text(
                    'View',
                    style: AppTheme.hind(14, w: FontWeight.w600, c: AppColors.ink),
                  ),
                ),
              ),
              if (order.status == SellerOrderStatus.pendingAcceptance) ...[
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => _onAcceptOrder(order),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.green,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                    child: Text(
                      'Accept',
                      style: AppTheme.hind(14, w: FontWeight.w600, c: Colors.white),
                    ),
                  ),
                ),
              ] else if (order.status == SellerOrderStatus.accepted ||
                  order.status == SellerOrderStatus.preparing) ...[
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      if (order.status == SellerOrderStatus.accepted) {
                        context.push('/modules/seller/orders/preparing', extra: order);
                      } else {
                        context.push('/modules/seller/orders/ready', extra: order);
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.green,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                    child: Text(
                      order.status == SellerOrderStatus.accepted
                          ? 'Start Preparing'
                          : 'Mark Ready',
                      style: AppTheme.hind(14, w: FontWeight.w600, c: Colors.white),
                    ),
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatusBadge(SellerOrderStatus status) {
    Color bg;
    Color fg;
    IconData icon;
    String label = status.label;

    switch (status) {
      case SellerOrderStatus.pendingAcceptance:
        bg = AppColors.orangeSoft;
        fg = const Color(0xFFD97706); // Amber dark
        icon = Icons.hourglass_empty_rounded;
        break;
      case SellerOrderStatus.accepted:
      case SellerOrderStatus.preparing:
        bg = AppColors.blueSoft;
        fg = AppColors.blue;
        icon = Icons.soup_kitchen_outlined;
        break;
      case SellerOrderStatus.ready:
        bg = AppColors.orangeSoft;
        fg = AppColors.orange;
        icon = Icons.shopping_bag_outlined;
        break;
      case SellerOrderStatus.outForDelivery:
        bg = AppColors.blueSoft;
        fg = AppColors.blue;
        icon = Icons.local_shipping_outlined;
        break;
      case SellerOrderStatus.completed:
        bg = AppColors.greenSoft;
        fg = AppColors.green;
        icon = Icons.check_circle_outline_rounded;
        break;
      case SellerOrderStatus.cancelled:
        bg = AppColors.redSoft;
        fg = AppColors.red;
        icon = Icons.cancel_outlined;
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: fg),
          const SizedBox(width: 4),
          Text(
            label,
            style: AppTheme.hind(11, w: FontWeight.w600, c: fg),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.receipt_long_outlined, size: 54, color: AppColors.muted.withValues(alpha: 0.5)),
          const SizedBox(height: 12),
          Text(
            'No orders in this category',
            style: AppTheme.display(16, w: FontWeight.w600, c: AppColors.ink),
          ),
          const SizedBox(height: 4),
          Text(
            'New customer orders will show up here.',
            style: AppTheme.hind(13, c: AppColors.muted),
          ),
        ],
      ),
    );
  }
}
