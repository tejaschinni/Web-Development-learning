import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/screens/orders/models/seller_order_ui_model.dart';
import 'package:society_seva/features/seller/presentation/screens/orders/widgets/seller_order_app_bar.dart';

class SellerOrderCompletedScreen extends StatelessWidget {
  const SellerOrderCompletedScreen({
    super.key,
    this.order,
  });

  final SellerOrderUiModel? order;

  @override
  Widget build(BuildContext context) {
    final currentOrder = order ??
        SellerOrderUiModel.sampleOrders.firstWhere(
          (o) => o.status == SellerOrderStatus.completed,
          orElse: () => SellerOrderUiModel.sampleOrders.first.copyWith(
            status: SellerOrderStatus.completed,
            completedOn: '15 Oct 2026, 12:10 PM',
          ),
        );

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: const SellerOrderAppBar(showBack: true),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                child: Column(
                  children: [
                    Center(
                      child: Text(
                        'Order Completed',
                        style: AppTheme.display(20, w: FontWeight.w800, c: AppColors.ink),
                      ),
                    ),
                    const SizedBox(height: 24),
                    // Large circular green checkmark
                    Container(
                      width: 64,
                      height: 64,
                      decoration: const BoxDecoration(
                        color: AppColors.green,
                        shape: BoxShape.circle,
                      ),
                      child: const Center(
                        child: Icon(
                          Icons.check_rounded,
                          color: Colors.white,
                          size: 40,
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    Text(
                      'Order Completed',
                      style: AppTheme.display(20, w: FontWeight.w800, c: AppColors.ink),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'The order has been successfully\ncompleted.',
                      textAlign: TextAlign.center,
                      style: AppTheme.hind(14, c: AppColors.muted),
                    ),
                    const SizedBox(height: 28),
                    // Details container
                    _buildDetailsContainer(currentOrder),
                    const SizedBox(height: 16),
                    // Timeline shortcut
                    TextButton.icon(
                      onPressed: () {
                        context.push('/modules/seller/orders/timeline', extra: currentOrder);
                      },
                      icon: const Icon(Icons.timeline_rounded, color: AppColors.green, size: 20),
                      label: Text(
                        'View Order Timeline',
                        style: AppTheme.hind(13, w: FontWeight.w700, c: AppColors.green),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            _buildBottomButtons(context, currentOrder),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailsContainer(SellerOrderUiModel order) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: [
          _buildRow('Order ID', order.orderNumber, isBold: true),
          const Divider(height: 20, color: AppColors.border),
          _buildRow('Completed On', order.completedOn ?? '15 Oct 2026, 12:10 PM'),
          const Divider(height: 20, color: AppColors.border),
          _buildRow('Customer', order.customerName),
          const Divider(height: 20, color: AppColors.border),
          _buildRow('Items', '${order.itemsSummary} x ${order.itemCount}'),
          const Divider(height: 20, color: AppColors.border),
          _buildRow('Total Amount', '₹ ${order.totalAmount.toStringAsFixed(0)}', isBold: true),
          const Divider(height: 20, color: AppColors.border),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Payment Status', style: AppTheme.hind(13, c: AppColors.muted)),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.greenSoft,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Text(
                  order.paymentStatus,
                  style: AppTheme.hind(12, w: FontWeight.w700, c: AppColors.green),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildRow(String label, String value, {bool isBold = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: AppTheme.hind(13, c: AppColors.muted)),
        Text(
          value,
          style: AppTheme.hind(
            13,
            w: isBold ? FontWeight.w700 : FontWeight.w500,
            c: AppColors.ink,
          ),
        ),
      ],
    );
  }

  Widget _buildBottomButtons(BuildContext context, SellerOrderUiModel order) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: AppColors.border)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: () {
                context.push('/modules/seller/orders/details', extra: order);
              },
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: AppColors.border),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: Text(
                'View Order Details',
                style: AppTheme.hind(14, w: FontWeight.w600, c: AppColors.ink),
              ),
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                context.go('/modules/seller/orders');
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.green,
                foregroundColor: Colors.white,
                elevation: 0,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: Text(
                'Go to Orders',
                style: AppTheme.hind(14, w: FontWeight.w600, c: Colors.white),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
