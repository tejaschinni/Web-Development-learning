import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_order_provider.dart';
import 'package:society_seva/features/seller/presentation/screens/orders/models/seller_order_ui_model.dart';
import 'package:society_seva/features/seller/presentation/screens/orders/widgets/seller_order_app_bar.dart';

class SellerOrderDetailsScreen extends ConsumerStatefulWidget {
  const SellerOrderDetailsScreen({
    super.key,
    this.order,
  });

  final SellerOrderUiModel? order;

  @override
  ConsumerState<SellerOrderDetailsScreen> createState() => _SellerOrderDetailsScreenState();
}

class _SellerOrderDetailsScreenState extends ConsumerState<SellerOrderDetailsScreen> {
  late SellerOrderUiModel _order;

  @override
  void initState() {
    super.initState();
    _order = widget.order ?? SellerOrderUiModel.sampleOrders.first;
  }

  void _onAccept() {
    final updated = _order.copyWith(status: SellerOrderStatus.accepted);
    final sellerId = ref.read(mySellerProfileProvider.select((s) => s.valueOrNull?.id));
    if (sellerId != null && sellerId.isNotEmpty) {
      ref.read(sellerOrderActionProvider.notifier).transition(
            sellerId: sellerId,
            orderId: updated.id,
            newStatus: 'ACCEPTED',
          );
    }
    context.push('/modules/seller/orders/accepted', extra: updated);
  }

  void _onReject() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Reject Order?', style: AppTheme.display(16, w: FontWeight.w700)),
        content: Text(
          'Are you sure you want to reject this order? This action cannot be undone.',
          style: AppTheme.hind(14),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text('Cancel', style: AppTheme.hind(14, c: AppColors.muted)),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.red),
            onPressed: () {
              Navigator.of(ctx).pop();
              final cancelled = _order.copyWith(
                status: SellerOrderStatus.cancelled,
                cancelledBy: 'You (Seller)',
                cancelledOn: '15 Oct 2026, 11:00 AM',
                cancelReason: 'Item not available',
                refundStatus: 'Processing (Automatic)',
              );
              context.push('/modules/seller/orders/cancelled-seller', extra: cancelled);
            },
            child: const Text('Reject Order'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: const SellerOrderAppBar(showBack: true),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Text(
                        'Order Details',
                        style: AppTheme.display(20, w: FontWeight.w800, c: AppColors.ink),
                      ),
                    ),
                    const SizedBox(height: 16),
                    _buildPendingAlertBanner(),
                    const SizedBox(height: 20),
                    _buildOrderInfoCard(),
                    const SizedBox(height: 20),
                    _buildItemsSection(),
                    const SizedBox(height: 20),
                    _buildPaymentSummary(),
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
            _buildBottomActionBar(),
          ],
        ),
      ),
    );
  }

  Widget _buildPendingAlertBanner() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.orangeSoft,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.orange.withValues(alpha: 0.3)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(
              Icons.hourglass_bottom_rounded,
              color: AppColors.orange,
              size: 24,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Pending Acceptance',
                  style: AppTheme.display(14, w: FontWeight.w700, c: const Color(0xFFB45309)),
                ),
                const SizedBox(height: 2),
                Text(
                  'Please accept or reject this order within 1 hour.',
                  style: AppTheme.hind(12, c: const Color(0xFF78350F)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOrderInfoCard() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Column(
        children: [
          _buildInfoRow('Order ID', _order.orderNumber, isBold: true),
          const Divider(height: 20, color: AppColors.border),
          _buildInfoRow('Order Date', _order.orderDate),
          const Divider(height: 20, color: AppColors.border),
          // Customer row with Phone and Chat button
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(
                width: 100,
                child: Text('Customer', style: AppTheme.hind(13, c: AppColors.muted)),
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _order.customerName,
                      style: AppTheme.hind(13, w: FontWeight.w600, c: AppColors.ink),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Text(
                          _order.customerPhone,
                          style: AppTheme.hind(12, c: AppColors.muted),
                        ),
                        const SizedBox(width: 8),
                        InkWell(
                          onTap: () {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('Opening chat with ${_order.customerName}...')),
                            );
                          },
                          borderRadius: BorderRadius.circular(12),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: AppColors.greenSoft,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: AppColors.green.withValues(alpha: 0.3)),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(Icons.chat_bubble_outline_rounded,
                                    size: 12, color: AppColors.green),
                                const SizedBox(width: 4),
                                Text(
                                  'Chat',
                                  style: AppTheme.hind(11, w: FontWeight.w700, c: AppColors.green),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const Divider(height: 20, color: AppColors.border),
          _buildInfoRow('Delivery Type', _order.deliveryType),
          const Divider(height: 20, color: AppColors.border),
          _buildInfoRow('${_order.deliveryType} Date', _order.pickupOrDeliveryDate),
          const Divider(height: 20, color: AppColors.border),
          _buildInfoRow('${_order.deliveryType} Time', _order.pickupOrDeliveryTime),
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value, {bool isBold = false}) {
    return Row(
      children: [
        SizedBox(
          width: 100,
          child: Text(label, style: AppTheme.hind(13, c: AppColors.muted)),
        ),
        Expanded(
          child: Text(
            value,
            style: AppTheme.hind(
              13,
              w: isBold ? FontWeight.w700 : FontWeight.w500,
              c: AppColors.ink,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildItemsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Items',
          style: AppTheme.display(15, w: FontWeight.w700, c: AppColors.ink),
        ),
        const SizedBox(height: 10),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: AppColors.border),
          ),
          child: Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: AppColors.orangeSoft,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Center(
                  child: Icon(Icons.restaurant_rounded, color: AppColors.orange, size: 28),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Text(
                  '${_order.itemsSummary}   x ${_order.itemCount}',
                  style: AppTheme.hind(14, w: FontWeight.w600, c: AppColors.ink),
                ),
              ),
              Text(
                '₹ ${_order.totalAmount.toStringAsFixed(0)}',
                style: AppTheme.display(15, w: FontWeight.w700, c: AppColors.ink),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildPaymentSummary() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Total Amount', style: AppTheme.display(14, w: FontWeight.w700, c: AppColors.ink)),
              Text(
                '₹ ${_order.totalAmount.toStringAsFixed(0)}',
                style: AppTheme.display(16, w: FontWeight.w800, c: AppColors.ink),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Payment Status', style: AppTheme.hind(13, c: AppColors.muted)),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.greenSoft,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Text(
                  _order.paymentStatus,
                  style: AppTheme.hind(12, w: FontWeight.w700, c: AppColors.green),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildBottomActionBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: AppColors.border)),
      ),
      child: Row(
        children: [
          Expanded(
            child: OutlinedButton(
              onPressed: _onReject,
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.red,
                side: const BorderSide(color: AppColors.red),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: Text(
                'Reject',
                style: AppTheme.hind(15, w: FontWeight.w600, c: AppColors.red),
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            flex: 2,
            child: ElevatedButton(
              onPressed: _onAccept,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.green,
                foregroundColor: Colors.white,
                elevation: 0,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: Text(
                'Accept Order',
                style: AppTheme.hind(15, w: FontWeight.w600, c: Colors.white),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
