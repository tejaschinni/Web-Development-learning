import 'package:society_seva/features/seller/domain/entities/seller_order_entity.dart';

enum SellerOrderStatus {
  pendingAcceptance('Pending Acceptance'),
  accepted('Accepted'),
  preparing('Preparing'),
  ready('Ready'),
  outForDelivery('Out for Delivery'),
  completed('Completed'),
  cancelled('Cancelled');

  const SellerOrderStatus(this.label);
  final String label;

  static SellerOrderStatus fromString(String status) {
    final s = status.toUpperCase();
    if (s.contains('PENDING') || s == 'PAID' || s == 'CREATED' || s == 'REQUESTED') {
      return SellerOrderStatus.pendingAcceptance;
    }
    if (s == 'ACCEPTED') return SellerOrderStatus.accepted;
    if (s == 'PREPARING') return SellerOrderStatus.preparing;
    if (s.contains('READY')) return SellerOrderStatus.ready;
    if (s.contains('DELIVERY')) return SellerOrderStatus.outForDelivery;
    if (s.contains('COMPLET') || s.contains('DELIVERED')) return SellerOrderStatus.completed;
    if (s.contains('CANCEL') || s.contains('REJECT')) return SellerOrderStatus.cancelled;
    return SellerOrderStatus.pendingAcceptance;
  }
}

class SellerOrderUiModel {
  const SellerOrderUiModel({
    required this.id,
    required this.orderNumber,
    required this.customerName,
    required this.customerPhone,
    required this.orderDate,
    required this.deliveryType,
    required this.pickupOrDeliveryDate,
    required this.pickupOrDeliveryTime,
    required this.itemsSummary,
    required this.itemCount,
    required this.unitPrice,
    required this.totalAmount,
    required this.paymentStatus,
    required this.status,
    this.completedOn,
    this.cancelledOn,
    this.cancelReason,
    this.cancelledBy,
    this.refundStatus,
    this.customerAvatarUrl,
    this.note,
  });

  final String id;
  final String orderNumber;
  final String customerName;
  final String customerPhone;
  final String orderDate;
  final String deliveryType; // 'Pickup' or 'Delivery'
  final String pickupOrDeliveryDate;
  final String pickupOrDeliveryTime;
  final String itemsSummary;
  final int itemCount;
  final double unitPrice;
  final double totalAmount;
  final String paymentStatus; // 'Paid Online', 'Cash on Delivery', etc.
  final SellerOrderStatus status;
  final String? completedOn;
  final String? cancelledOn;
  final String? cancelReason;
  final String? cancelledBy;
  final String? refundStatus;
  final String? customerAvatarUrl;
  final String? note;

  SellerOrderUiModel copyWith({
    String? id,
    String? orderNumber,
    String? customerName,
    String? customerPhone,
    String? orderDate,
    String? deliveryType,
    String? pickupOrDeliveryDate,
    String? pickupOrDeliveryTime,
    String? itemsSummary,
    int? itemCount,
    double? unitPrice,
    double? totalAmount,
    String? paymentStatus,
    SellerOrderStatus? status,
    String? completedOn,
    String? cancelledOn,
    String? cancelReason,
    String? cancelledBy,
    String? refundStatus,
    String? customerAvatarUrl,
    String? note,
  }) {
    return SellerOrderUiModel(
      id: id ?? this.id,
      orderNumber: orderNumber ?? this.orderNumber,
      customerName: customerName ?? this.customerName,
      customerPhone: customerPhone ?? this.customerPhone,
      orderDate: orderDate ?? this.orderDate,
      deliveryType: deliveryType ?? this.deliveryType,
      pickupOrDeliveryDate: pickupOrDeliveryDate ?? this.pickupOrDeliveryDate,
      pickupOrDeliveryTime: pickupOrDeliveryTime ?? this.pickupOrDeliveryTime,
      itemsSummary: itemsSummary ?? this.itemsSummary,
      itemCount: itemCount ?? this.itemCount,
      unitPrice: unitPrice ?? this.unitPrice,
      totalAmount: totalAmount ?? this.totalAmount,
      paymentStatus: paymentStatus ?? this.paymentStatus,
      status: status ?? this.status,
      completedOn: completedOn ?? this.completedOn,
      cancelledOn: cancelledOn ?? this.cancelledOn,
      cancelReason: cancelReason ?? this.cancelReason,
      cancelledBy: cancelledBy ?? this.cancelledBy,
      refundStatus: refundStatus ?? this.refundStatus,
      customerAvatarUrl: customerAvatarUrl ?? this.customerAvatarUrl,
      note: note ?? this.note,
    );
  }

  factory SellerOrderUiModel.fromEntity(SellerOrderEntity entity) {
    final item = entity.items.isNotEmpty ? entity.items.first : null;
    return SellerOrderUiModel(
      id: entity.id,
      orderNumber: entity.orderNumber.startsWith('#')
          ? entity.orderNumber
          : '#${entity.orderNumber}',
      customerName: 'Customer (${entity.buyerId.substring(0, entity.buyerId.length > 8 ? 8 : entity.buyerId.length)})',
      customerPhone: '+91 98765 43210',
      orderDate: 'Today, 10:15 AM',
      deliveryType: entity.orderType.contains('FOOD') ? 'Pickup' : 'Delivery',
      pickupOrDeliveryDate: '15 Oct 2026',
      pickupOrDeliveryTime: '12:00 PM - 1:00 PM',
      itemsSummary: item?.titleSnapshot ?? 'Ordered Items',
      itemCount: item?.quantity ?? 1,
      unitPrice: item?.unitPrice ?? entity.totalAmount,
      totalAmount: entity.totalAmount,
      paymentStatus: entity.paymentStatus == 'PAID' ? 'Paid Online' : entity.paymentStatus,
      status: SellerOrderStatus.fromString(entity.orderStatus),
      completedOn: entity.orderStatus == 'COMPLETED' ? '15 Oct 2026, 12:10 PM' : null,
      cancelledOn: entity.orderStatus == 'CANCELLED' ? '15 Oct 2026, 11:00 AM' : null,
      cancelReason: entity.orderStatus == 'CANCELLED' ? 'Customer request' : null,
      cancelledBy: entity.orderStatus == 'CANCELLED' ? 'Customer' : null,
      refundStatus: entity.orderStatus == 'CANCELLED' ? 'Completed' : null,
    );
  }

  /// Default Mock sample orders matching the visual design and values in the screenshot:
  static final List<SellerOrderUiModel> sampleOrders = [
    const SellerOrderUiModel(
      id: 'mock-order-1',
      orderNumber: '#ORD12345',
      customerName: 'Priya Sharma',
      customerPhone: '+91 98765 43210',
      orderDate: 'Today, 10:15 AM',
      deliveryType: 'Pickup',
      pickupOrDeliveryDate: '15 Oct 2026',
      pickupOrDeliveryTime: '12:00 PM - 1:00 PM',
      itemsSummary: 'Homemade Veg Thali',
      itemCount: 1,
      unitPrice: 120.0,
      totalAmount: 120.0,
      paymentStatus: 'Paid Online',
      status: SellerOrderStatus.pendingAcceptance,
      completedOn: '15 Oct 2026, 12:10 PM',
    ),
    const SellerOrderUiModel(
      id: 'mock-order-2',
      orderNumber: '#ORD12344',
      customerName: 'Rahul Patil',
      customerPhone: '+91 98220 54321',
      orderDate: 'Today, 09:30 AM',
      deliveryType: 'Delivery',
      pickupOrDeliveryDate: '15 Oct 2026',
      pickupOrDeliveryTime: 'Today, 1:00 PM',
      itemsSummary: 'Snacks - Samosa (2 pcs)',
      itemCount: 1,
      unitPrice: 180.0,
      totalAmount: 180.0,
      paymentStatus: 'Paid Online',
      status: SellerOrderStatus.pendingAcceptance,
    ),
    const SellerOrderUiModel(
      id: 'mock-order-3',
      orderNumber: '#ORD12348',
      customerName: 'Aarav Mehta',
      customerPhone: '+91 98111 22334',
      orderDate: '15 Oct 2026, 10:20 AM',
      deliveryType: 'Pickup',
      pickupOrDeliveryDate: '15 Oct 2026',
      pickupOrDeliveryTime: '12:30 PM - 1:30 PM',
      itemsSummary: 'Pav Bhaji Combo',
      itemCount: 2,
      unitPrice: 150.0,
      totalAmount: 300.0,
      paymentStatus: 'Paid Online',
      status: SellerOrderStatus.preparing,
    ),
    const SellerOrderUiModel(
      id: 'mock-order-4',
      orderNumber: '#ORD12349',
      customerName: 'Neha Kulkarni',
      customerPhone: '+91 98333 44556',
      orderDate: '15 Oct 2026, 10:40 AM',
      deliveryType: 'Delivery',
      pickupOrDeliveryDate: '15 Oct 2026',
      pickupOrDeliveryTime: '2:00 PM',
      itemsSummary: 'Gulab Jamun (Box of 4)',
      itemCount: 1,
      unitPrice: 160.0,
      totalAmount: 160.0,
      paymentStatus: 'Paid Online',
      status: SellerOrderStatus.preparing,
    ),
    const SellerOrderUiModel(
      id: 'mock-order-5',
      orderNumber: '#ORD12350',
      customerName: 'Sunil Shinde',
      customerPhone: '+91 98444 55667',
      orderDate: '15 Oct 2026, 11:15 AM',
      deliveryType: 'Pickup',
      pickupOrDeliveryDate: '15 Oct 2026',
      pickupOrDeliveryTime: '1:00 PM',
      itemsSummary: 'Homemade Masala Chai & Poha',
      itemCount: 1,
      unitPrice: 110.0,
      totalAmount: 110.0,
      paymentStatus: 'Paid Online',
      status: SellerOrderStatus.ready,
    ),
    const SellerOrderUiModel(
      id: 'mock-order-6',
      orderNumber: '#ORD12351',
      customerName: 'Ananya Gupta',
      customerPhone: '+91 98555 66778',
      orderDate: '15 Oct 2026, 11:30 AM',
      deliveryType: 'Delivery',
      pickupOrDeliveryDate: '15 Oct 2026',
      pickupOrDeliveryTime: '1:30 PM',
      itemsSummary: 'Paneer Biryani Handi',
      itemCount: 1,
      unitPrice: 280.0,
      totalAmount: 280.0,
      paymentStatus: 'Paid Online',
      status: SellerOrderStatus.outForDelivery,
    ),
    const SellerOrderUiModel(
      id: 'mock-order-7',
      orderNumber: '#ORD12345',
      customerName: 'Priya Sharma',
      customerPhone: '+91 98765 43210',
      orderDate: '15 Oct 2026, 10:15 AM',
      deliveryType: 'Pickup',
      pickupOrDeliveryDate: '15 Oct 2026',
      pickupOrDeliveryTime: '12:00 PM - 1:00 PM',
      itemsSummary: 'Homemade Veg Thali',
      itemCount: 1,
      unitPrice: 120.0,
      totalAmount: 120.0,
      paymentStatus: 'Paid Online',
      status: SellerOrderStatus.completed,
      completedOn: '15 Oct 2026, 12:10 PM',
    ),
    const SellerOrderUiModel(
      id: 'mock-order-8',
      orderNumber: '#ORD12346',
      customerName: 'Vikram Seth',
      customerPhone: '+91 98666 77889',
      orderDate: '15 Oct 2026, 10:50 AM',
      deliveryType: 'Pickup',
      pickupOrDeliveryDate: '15 Oct 2026',
      pickupOrDeliveryTime: '12:00 PM',
      itemsSummary: 'Dal Tadka & Jeera Rice',
      itemCount: 1,
      unitPrice: 190.0,
      totalAmount: 190.0,
      paymentStatus: 'Paid Online',
      status: SellerOrderStatus.cancelled,
      cancelledOn: '15 Oct 2026, 11:00 AM',
      cancelReason: 'Item not available',
      cancelledBy: 'You (Seller)',
      refundStatus: 'Processing (Automatic)',
    ),
    const SellerOrderUiModel(
      id: 'mock-order-9',
      orderNumber: '#ORD12347',
      customerName: 'Kavita Roy',
      customerPhone: '+91 98777 88990',
      orderDate: '15 Oct 2026, 10:30 AM',
      deliveryType: 'Delivery',
      pickupOrDeliveryDate: '15 Oct 2026',
      pickupOrDeliveryTime: '1:00 PM',
      itemsSummary: 'Fresh Mango Lassi (2 Glasses)',
      itemCount: 2,
      unitPrice: 80.0,
      totalAmount: 160.0,
      paymentStatus: 'Paid Online',
      status: SellerOrderStatus.cancelled,
      cancelledOn: '15 Oct 2026, 10:45 AM',
      cancelReason: 'Customer request',
      cancelledBy: 'Customer',
      refundStatus: 'Completed',
    ),
  ];
}
