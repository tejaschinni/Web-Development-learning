import 'package:flutter/material.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/screens/orders/models/seller_order_ui_model.dart';
import 'package:society_seva/features/seller/presentation/screens/orders/widgets/seller_order_app_bar.dart';

class SellerOrderTimelineScreen extends StatelessWidget {
  const SellerOrderTimelineScreen({
    super.key,
    this.order,
  });

  final SellerOrderUiModel? order;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: const SellerOrderAppBar(showBack: true),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Text(
                  'Order Timeline',
                  style: AppTheme.display(20, w: FontWeight.w800, c: AppColors.ink),
                ),
              ),
              const SizedBox(height: 28),
              // Timeline vertical items
              _buildTimelineStep(
                title: 'Order Placed',
                time: '15 Oct 2026, 10:15 AM',
                actor: 'Customer',
                state: _TimelineStepState.completed,
                isLast: false,
              ),
              _buildTimelineStep(
                title: 'Order Accepted',
                time: '15 Oct 2026, 10:20 AM',
                actor: 'Seller',
                state: _TimelineStepState.completed,
                isLast: false,
              ),
              _buildTimelineStep(
                title: 'Preparing',
                time: '15 Oct 2026, 10:40 AM',
                actor: 'Seller',
                state: _TimelineStepState.completed,
                isLast: false,
              ),
              _buildTimelineStep(
                title: 'Ready for Pickup',
                time: '15 Oct 2026, 11:50 AM',
                actor: 'Seller',
                state: _TimelineStepState.active,
                isLast: false,
              ),
              _buildTimelineStep(
                title: 'Completed',
                time: 'Pending',
                actor: null,
                state: _TimelineStepState.pending,
                isLast: true,
              ),
              const SizedBox(height: 36),
              // Customer updates blue card
              _buildCustomerUpdatesCard(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTimelineStep({
    required String title,
    required String time,
    required String? actor,
    required _TimelineStepState state,
    required bool isLast,
  }) {
    Widget iconWidget;
    Color lineColor;

    switch (state) {
      case _TimelineStepState.completed:
        iconWidget = Container(
          width: 24,
          height: 24,
          decoration: const BoxDecoration(
            color: AppColors.green,
            shape: BoxShape.circle,
          ),
          child: const Center(
            child: Icon(Icons.check_rounded, color: Colors.white, size: 16),
          ),
        );
        lineColor = AppColors.green;
        break;
      case _TimelineStepState.active:
        iconWidget = Container(
          width: 24,
          height: 24,
          decoration: BoxDecoration(
            color: Colors.white,
            shape: BoxShape.circle,
            border: Border.all(color: AppColors.blue, width: 3),
          ),
          child: Center(
            child: Container(
              width: 10,
              height: 10,
              decoration: const BoxDecoration(
                color: AppColors.blue,
                shape: BoxShape.circle,
              ),
            ),
          ),
        );
        lineColor = AppColors.border;
        break;
      case _TimelineStepState.pending:
        iconWidget = Container(
          width: 24,
          height: 24,
          decoration: BoxDecoration(
            color: Colors.white,
            shape: BoxShape.circle,
            border: Border.all(color: AppColors.border, width: 2),
          ),
        );
        lineColor = Colors.transparent;
        break;
    }

    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Left indicator column
          Column(
            children: [
              iconWidget,
              if (!isLast)
                Expanded(
                  child: Container(
                    width: 2,
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    color: lineColor,
                  ),
                ),
            ],
          ),
          const SizedBox(width: 16),
          // Content column
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(bottom: 24),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          style: AppTheme.hind(
                            14,
                            w: state == _TimelineStepState.active
                                ? FontWeight.w700
                                : (state == _TimelineStepState.completed
                                    ? FontWeight.w600
                                    : FontWeight.w400),
                            c: state == _TimelineStepState.pending
                                ? AppColors.muted
                                : AppColors.ink,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          time,
                          style: AppTheme.hind(
                            12,
                            c: state == _TimelineStepState.pending
                                ? AppColors.muted.withValues(alpha: 0.8)
                                : AppColors.muted,
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (actor != null)
                    Text(
                      actor,
                      style: AppTheme.hind(12, c: AppColors.muted, w: FontWeight.w500),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCustomerUpdatesCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.blueSoft,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppColors.blue.withValues(alpha: 0.12),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.mail_outline_rounded,
              color: AppColors.blue,
              size: 20,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Customer Updates',
                  style: AppTheme.display(14, w: FontWeight.w700, c: AppColors.blue),
                ),
                const SizedBox(height: 3),
                Text(
                  'The customer is notified automatically at each stage.',
                  style: AppTheme.hind(13, c: AppColors.ink, h: 1.3),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

enum _TimelineStepState {
  completed,
  active,
  pending,
}
