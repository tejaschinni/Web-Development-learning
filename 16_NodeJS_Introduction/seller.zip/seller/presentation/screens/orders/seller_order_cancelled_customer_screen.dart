import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/screens/orders/models/seller_order_ui_model.dart';
import 'package:society_seva/features/seller/presentation/screens/orders/widgets/seller_order_app_bar.dart';

class SellerOrderCancelledCustomerScreen extends StatelessWidget {
  const SellerOrderCancelledCustomerScreen({
    super.key,
    this.order,
  });

  final SellerOrderUiModel? order;

  @override
  Widget build(BuildContext context) {
    final currentOrder = order ??
        SellerOrderUiModel.sampleOrders.firstWhere(
          (o) => o.cancelledBy == 'Customer',
          orElse: () => SellerOrderUiModel.sampleOrders.first.copyWith(
            orderNumber: '#ORD12347',
            status: SellerOrderStatus.cancelled,
            cancelledOn: '15 Oct 2026, 10:45 AM',
            cancelReason: 'Customer request',
            cancelledBy: 'Customer',
            refundStatus: 'Completed',
          ),
        );

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: const SellerOrderAppBar(showBack: true),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                child: Column(
                  children: [
                    Center(
                      child: Text(
                        'Order Cancelled',
                        style: AppTheme.display(20, w: FontWeight.w800, c: AppColors.ink),
                      ),
                    ),
                    const SizedBox(height: 24),
                    // Large red circle with white X
                    Container(
                      width: 64,
                      height: 64,
                      decoration: const BoxDecoration(
                        color: AppColors.red,
                        shape: BoxShape.circle,
                      ),
                      child: const Center(
                        child: Icon(
                          Icons.close_rounded,
                          color: Colors.white,
                          size: 40,
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    Text(
                      'Order Cancelled by Customer',
                      textAlign: TextAlign.center,
                      style: AppTheme.display(19, w: FontWeight.w800, c: AppColors.red),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'This order has been cancelled\nby the customer.',
                      textAlign: TextAlign.center,
                      style: AppTheme.hind(14, c: AppColors.muted),
                    ),
                    const SizedBox(height: 28),
                    // Details container
                    _buildDetailsContainer(currentOrder),
                  ],
                ),
              ),
            ),
            _buildBottomButtons(context, currentOrder),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailsContainer(SellerOrderUiModel order) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: [
          _buildRow('Order ID', order.orderNumber, isBold: true),
          const Divider(height: 20, color: AppColors.border),
          _buildRow('Cancelled On', order.cancelledOn ?? '15 Oct 2026, 10:45 AM'),
          const Divider(height: 20, color: AppColors.border),
          _buildRow('Reason', order.cancelReason ?? 'Customer request'),
          const Divider(height: 20, color: AppColors.border),
          _buildRow('Cancelled By', order.cancelledBy ?? 'Customer'),
          const Divider(height: 20, color: AppColors.border),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Refund Status', style: AppTheme.hind(13, c: AppColors.muted)),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.greenSoft,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.check_circle_rounded, size: 12, color: AppColors.green),
                    const SizedBox(width: 4),
                    Text(
                      order.refundStatus ?? 'Completed',
                      style: AppTheme.hind(12, w: FontWeight.w700, c: AppColors.green),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildRow(String label, String value, {bool isBold = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: AppTheme.hind(13, c: AppColors.muted)),
        Text(
          value,
          style: AppTheme.hind(
            13,
            w: isBold ? FontWeight.w700 : FontWeight.w500,
            c: AppColors.ink,
          ),
        ),
      ],
    );
  }

  Widget _buildBottomButtons(BuildContext context, SellerOrderUiModel order) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: AppColors.border)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: () {
                context.push('/modules/seller/orders/details', extra: order);
              },
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: AppColors.border),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: Text(
                'View Order Details',
                style: AppTheme.hind(14, w: FontWeight.w600, c: AppColors.ink),
              ),
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                context.go('/modules/seller/orders');
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.green,
                foregroundColor: Colors.white,
                elevation: 0,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: Text(
                'Go to Orders',
                style: AppTheme.hind(14, w: FontWeight.w600, c: Colors.white),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
