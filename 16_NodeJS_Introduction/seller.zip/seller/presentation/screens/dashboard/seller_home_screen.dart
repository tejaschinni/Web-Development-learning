import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/features/seller/domain/entities/seller_profile_entity.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';

class SellerHomeScreen extends ConsumerWidget {
  const SellerHomeScreen({
    super.key,
    this.onViewListings,
    this.onViewOrders,
    this.onViewReviews,
    this.onExploreMarketplace,
  });

  /// Switches the dashboard to the corresponding tab. Left null (no-op) if
  /// this screen is ever used outside the dashboard's tab bar.
  final VoidCallback? onViewListings;
  final VoidCallback? onViewOrders;
  final VoidCallback? onViewReviews;
  final VoidCallback? onExploreMarketplace;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sellerAsync = ref.watch(mySellerProfileProvider);

    return RefreshIndicator(
      onRefresh: () async => ref.invalidate(mySellerProfileProvider),
      child: sellerAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => ListView(
          children: const [
            SizedBox(height: 120),
            Center(child: Text('Could not load seller details')),
          ],
        ),
        data: (seller) {
          if (seller == null) return const _NotASeller();
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _BusinessCard(seller: seller),
              _StatsGrid(seller: seller, onViewListings: onViewListings),
              // const SizedBox(height: 12),
              // _AvailabilityCard(seller: seller),
              const SizedBox(height: 20),
              Text('Quick Actions', style: _sectionTitle(context)),
              const SizedBox(height: 12),
              _QuickActions(
                onAddProduct: onViewListings,
                onAddService: onViewListings,
                onViewOrders: onViewOrders,
                onManageListings: onViewListings,
                onOffers: () => _comingSoon(context, 'Offers & Deals'),
                onAnalytics: () => _comingSoon(context, 'Analytics'),
              ),
              const SizedBox(height: 20),
              // SellerOrdersSummarySection(onTapStatus: (_) => onViewOrders?.call()),
              // const SizedBox(height: 12),
              // _PerformanceCard(seller: seller),
              // const SizedBox(height: 12),
              _ReviewsPreviewCard(seller: seller, onViewReviews: onViewReviews),
              const SizedBox(height: 20),
              _GrowBanner(onExplore: onExploreMarketplace),
            ],
          );
        },
      ),
    );
  }
}

TextStyle? _sectionTitle(BuildContext context) => GoogleFonts.hind(
  textStyle: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
);

void _comingSoon(BuildContext context, String name) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text('$name is coming soon')));
}

String _cap(String s) {
  final t = s.replaceAll('_', ' ').toLowerCase();
  return t.isEmpty ? t : t[0].toUpperCase() + t.substring(1);
}

bool _isApproved(SellerProfileEntity s) => s.approvalStatus.toUpperCase() == 'APPROVED';

class _NotASeller extends StatelessWidget {
  const _NotASeller();

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: ListTile(
            leading: const HugeIcon(icon: HugeIcons.strokeRoundedStore01),
            title: const Text('You are not a seller yet'),
            subtitle: const Text('Register to start selling'),
            trailing: const HugeIcon(icon: HugeIcons.strokeRoundedArrowRight01),
            onTap: () => context.push('/modules/seller/onboarding', extra: false),
          ),
        ),
      ],
    );
  }
}

/// Icon + colors for a seller approval status, pulled from the current
/// ColorScheme so it follows light/dark theme automatically.
class _StatusStyle {
  const _StatusStyle({required this.icon, required this.container, required this.onContainer});

  final List<List<dynamic>> icon;
  final Color container;
  final Color onContainer;

  static _StatusStyle forStatus(String status, ColorScheme scheme) {
    switch (status.toUpperCase()) {
      case 'APPROVED':
        return _StatusStyle(
          icon: HugeIcons.strokeRoundedStoreVerified01,
          container: scheme.primaryContainer,
          onContainer: scheme.onPrimaryContainer,
        );
      case 'PENDING':
      case 'SUBMITTED':
        return _StatusStyle(
          icon: HugeIcons.strokeRoundedHourglass,
          container: scheme.secondaryContainer,
          onContainer: scheme.onSecondaryContainer,
        );
      case 'REJECTED':
        return _StatusStyle(
          icon: HugeIcons.strokeRoundedAlertCircle,
          container: scheme.errorContainer,
          onContainer: scheme.onErrorContainer,
        );
      default: // DRAFT or unknown
        return _StatusStyle(
          icon: HugeIcons.strokeRoundedFileEdit,
          container: scheme.surfaceContainerHighest,
          onContainer: scheme.onSurfaceVariant,
        );
    }
  }
}

/// Business card at the top: store icon, name, type, status chip, chevron.
class _BusinessCard extends StatelessWidget {
  const _BusinessCard({required this.seller});
  final SellerProfileEntity seller;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final title = (seller.businessName?.isNotEmpty ?? false)
        ? seller.businessName!
        : seller.displayName;
    final status = _StatusStyle.forStatus(seller.approvalStatus, scheme);
    final approved = _isApproved(seller);

    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () {}, // e.g. open seller profile
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: scheme.primaryContainer,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Center(
                  child: HugeIcon(
                    icon: HugeIcons.strokeRoundedStore01,
                    color: scheme.onPrimaryContainer,
                    size: 28,
                  ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.hind(
                        textStyle: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    Text(_cap(seller.sellerType), style: theme.textTheme.bodySmall),
                    const SizedBox(height: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: status.container,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          HugeIcon(icon: status.icon, size: 14, color: status.onContainer),
                          const SizedBox(width: 4),
                          Text(
                            approved ? 'Verified Seller' : _cap(seller.approvalStatus),
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: status.onContainer,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              HugeIcon(icon: HugeIcons.strokeRoundedArrowRight01, color: scheme.outline),
            ],
          ),
        ),
      ),
    );
  }
}

/// Blockers first: approval and FSSAI.
class _StatusBanners extends StatelessWidget {
  const _StatusBanners({required this.seller});
  final SellerProfileEntity seller;

  @override
  Widget build(BuildContext context) {
    final banners = <Widget>[];

    switch (seller.approvalStatus.toUpperCase()) {
      case 'DRAFT':
        banners.add(
          _Banner(
            icon: HugeIcons.strokeRoundedFileEdit,
            text: 'Your seller profile is a draft. Submit it to start selling.',
            actionLabel: 'Complete',
            onAction: () => context.push('/modules/seller/onboarding', extra: true),
          ),
        );
        break;
      case 'PENDING':
      case 'SUBMITTED':
        banners.add(
          const _Banner(
            icon: HugeIcons.strokeRoundedHourglass,
            text: 'Your profile is under review.',
          ),
        );
        break;
      case 'REJECTED':
        banners.add(
          _Banner(
            icon: HugeIcons.strokeRoundedAlertCircle,
            text: 'Your profile was rejected. Update details and re-submit.',
            actionLabel: 'Update',
            onAction: () => context.push('/modules/seller/onboarding', extra: true),
            isError: true,
          ),
        );
        break;
    }

    if (seller.fssaiRequired && seller.fssaiStatus.toUpperCase() != 'APPROVED') {
      banners.add(
        _Banner(
          icon: HugeIcons.strokeRoundedShieldCheck,
          text: 'FSSAI verification: ${_cap(seller.fssaiStatus)}',
        ),
      );
    }

    if (banners.isEmpty) return const SizedBox.shrink();
    return Column(children: banners);
  }
}

class _Banner extends StatelessWidget {
  const _Banner({
    required this.icon,
    required this.text,
    this.actionLabel,
    this.onAction,
    this.isError = false,
  });

  final List<List<dynamic>> icon;
  final String text;
  final String? actionLabel;
  final VoidCallback? onAction;
  final bool isError;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: isError ? scheme.errorContainer : scheme.secondaryContainer,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          HugeIcon(
            icon: icon,
            color: isError ? scheme.onErrorContainer : scheme.onSecondaryContainer,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                color: isError ? scheme.onErrorContainer : scheme.onSecondaryContainer,
              ),
            ),
          ),
          if (actionLabel != null) TextButton(onPressed: onAction, child: Text(actionLabel!)),
        ],
      ),
    );
  }
}

/// 2x2 stats grid.
class _StatsGrid extends StatelessWidget {
  const _StatsGrid({required this.seller, this.onViewListings});
  final SellerProfileEntity seller;
  final VoidCallback? onViewListings;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: _StatTile(label: 'Total Orders', value: '${seller.totalOrders}'),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _StatTile(
                label: 'Rating',
                value: seller.totalReviews == 0 ? '-' : seller.averageRating.toStringAsFixed(1),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: _StatTile(
                label: 'Reviews',
                value: '${seller.totalReviews}',
                valueColor: scheme.tertiary,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _StatTile(
                label: 'Active Listings',
                value: '${seller.totalListings}',
                onTap: onViewListings,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _StatTile extends StatelessWidget {
  const _StatTile({
    required this.label,
    required this.value,
    this.trend,
    this.valueColor,
    this.onTap,
  });

  final String label;
  final String value;

  /// e.g. "20%". Shown with an up arrow in the primary color. Omit to hide.
  final String? trend;
  final Color? valueColor;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;

    return Card(
      margin: EdgeInsets.zero,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(label, style: theme.textTheme.bodySmall),
                    const SizedBox(height: 6),
                    Text(
                      value,
                      style: GoogleFonts.hind(
                        textStyle: theme.textTheme.headlineSmall?.copyWith(
                          fontWeight: FontWeight.w700,
                          color: valueColor,
                        ),
                      ),
                    ),
                    if (trend != null) ...[
                      const SizedBox(height: 2),
                      Row(
                        children: [
                          Icon(Icons.arrow_upward, size: 14, color: scheme.primary),
                          Text(
                            trend!,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: scheme.primary,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
              if (onTap != null)
                HugeIcon(
                  icon: HugeIcons.strokeRoundedArrowRight01,
                  size: 18,
                  color: scheme.outline,
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AvailabilityCard extends StatelessWidget {
  const _AvailabilityCard({required this.seller});
  final SellerProfileEntity seller;

  @override
  Widget build(BuildContext context) {
    final available = seller.availabilityStatus.toUpperCase() == 'AVAILABLE';
    final approved = _isApproved(seller);
    final scheme = Theme.of(context).colorScheme;

    return Card(
      child: SwitchListTile(
        secondary: HugeIcon(
          icon: available ? HugeIcons.strokeRoundedToggleOn : HugeIcons.strokeRoundedToggleOff,
          color: available ? scheme.primary : scheme.outline,
        ),
        title: Text(available ? 'Accepting orders' : 'Not accepting orders'),
        subtitle: Text(approved ? 'Changing this is coming soon' : 'Available after approval'),
        value: available,
        onChanged: approved
            ? (value) => ScaffoldMessenger.of(context)
                  .showSnackBar(const SnackBar(content: Text('Availability toggle is coming soon')))
            : null,
      ),
    );
  }
}

/// 3-column quick actions grid.
class _QuickActions extends StatelessWidget {
  const _QuickActions({
    this.onAddProduct,
    this.onAddService,
    this.onViewOrders,
    this.onManageListings,
    this.onOffers,
    this.onAnalytics,
  });

  final VoidCallback? onAddProduct;
  final VoidCallback? onAddService;
  final VoidCallback? onViewOrders;
  final VoidCallback? onManageListings;
  final VoidCallback? onOffers;
  final VoidCallback? onAnalytics;

  @override
  Widget build(BuildContext context) {
    final items = [
      _ActionTile(
        icon: HugeIcons.strokeRoundedPackageAdd01,
        label: 'Add Product',
        onTap: onAddProduct,
      ),
      _ActionTile(icon: HugeIcons.strokeRoundedWrench01, label: 'Add Service', onTap: onAddService),
      _ActionTile(icon: HugeIcons.strokeRoundedReceipt, label: 'View Orders', onTap: onViewOrders),
      _ActionTile(
        icon: HugeIcons.strokeRoundedListView,
        label: 'Manage Listings',
        onTap: onManageListings,
      ),
      _ActionTile(
        icon: HugeIcons.strokeRoundedDiscountTag01,
        label: 'Offers & Deals',
        onTap: onOffers,
      ),
      _ActionTile(
        icon: HugeIcons.strokeRoundedChartLineData01,
        label: 'Analytics',
        onTap: onAnalytics,
      ),
    ];

    return GridView.count(
      crossAxisCount: 3,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 12,
      crossAxisSpacing: 12,
      childAspectRatio: 1.0,
      children: items,
    );
  }
}

class _ActionTile extends StatelessWidget {
  const _ActionTile({required this.icon, required this.label, this.onTap});

  final List<List<dynamic>> icon;
  final String label;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;

    return Card(
      margin: EdgeInsets.zero,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: scheme.primaryContainer,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Center(
                  child: HugeIcon(icon: icon, size: 22, color: scheme.onPrimaryContainer),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                label,
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.hind(
                  textStyle: theme.textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w600),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PerformanceCard extends StatelessWidget {
  const _PerformanceCard({required this.seller});
  final SellerProfileEntity seller;

  String _pct(int part, int total) =>
      total == 0 ? '-' : '${(part * 100 / total).toStringAsFixed(0)}%';

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final total = seller.totalOrders;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                HugeIcon(
                  icon: HugeIcons.strokeRoundedChartLineData01,
                  size: 20,
                  color: theme.colorScheme.primary,
                ),
                const SizedBox(width: 8),
                Text('Performance', style: theme.textTheme.titleMedium),
              ],
            ),
            const SizedBox(height: 8),
            _row(
              'Rejected orders',
              '${seller.rejectedOrders} (${_pct(seller.rejectedOrders, total)})',
            ),
            _row(
              'Cancelled orders',
              '${seller.cancelledOrders} (${_pct(seller.cancelledOrders, total)})',
            ),
          ],
        ),
      ),
    );
  }

  Widget _row(String label, String value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(
      children: [
        Expanded(child: Text(label)),
        Text(value),
      ],
    ),
  );
}

class _ReviewsPreviewCard extends StatelessWidget {
  const _ReviewsPreviewCard({required this.seller, this.onViewReviews});
  final SellerProfileEntity seller;
  final VoidCallback? onViewReviews;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final hasReviews = seller.totalReviews > 0;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            HugeIcon(icon: HugeIcons.strokeRoundedStar, color: theme.colorScheme.primary),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    hasReviews
                        ? '${seller.averageRating.toStringAsFixed(1)} average rating'
                        : 'No reviews yet',
                    style: theme.textTheme.titleMedium,
                  ),
                  Text('${seller.totalReviews} total reviews', style: theme.textTheme.bodySmall),
                ],
              ),
            ),
            TextButton(onPressed: onViewReviews, child: const Text('View all')),
          ],
        ),
      ),
    );
  }
}

/// "Grow Your Business" banner at the bottom.
class _GrowBanner extends StatelessWidget {
  const _GrowBanner({this.onExplore});
  final VoidCallback? onExplore;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: scheme.primaryContainer,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Grow Your Business',
                  style: GoogleFonts.hind(
                    textStyle: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w700,
                      color: scheme.onPrimaryContainer,
                    ),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Reach more residents in your society and nearby communities.',
                  style: theme.textTheme.bodySmall?.copyWith(color: scheme.onPrimaryContainer),
                ),
                const SizedBox(height: 12),
                FilledButton(
                  onPressed: onExplore ?? () => _comingSoon(context, 'Marketplace'),
                  child: Text('Explore Marketplace', style: GoogleFonts.hind()),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          HugeIcon(
            icon: HugeIcons.strokeRoundedStore01,
            size: 64,
            color: scheme.onPrimaryContainer.withValues(alpha: 0.7),
          ),
        ],
      ),
    );
  }
}
