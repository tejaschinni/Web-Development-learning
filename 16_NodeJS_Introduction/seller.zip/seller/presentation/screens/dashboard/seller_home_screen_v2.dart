import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/screens/dashboard/seller_dashbard_screen.dart';

const _navy = Color(0xFF0B2F6B);
const _pageBg = Color(0xFFF6F8FB);
const _twoColumnBreakpoint = 700.0;

class SellerHomeScreenV2 extends ConsumerWidget {
  const SellerHomeScreenV2({super.key});

  void _createListing(BuildContext context) {
    context.push('/modules/seller/addListing');
  }

  void _navigateToOrders(BuildContext context, WidgetRef ref) {
    try {
      ref.read(sellerDashboardTabProvider.notifier).state = 1;
    } catch (_) {
      context.push('/modules/seller/orders');
    }
  }

  void _navigateToListings(BuildContext context, WidgetRef ref) {
    try {
      ref.read(sellerDashboardTabProvider.notifier).state = 2;
    } catch (_) {
      context.push('/modules/seller/listings');
    }
  }

  void _navigateToProfile(BuildContext context, WidgetRef ref) {
    try {
      ref.read(sellerDashboardTabProvider.notifier).state = 4;
    } catch (_) {
      context.push('/profile');
    }
  }

  void _navigateToSellerProfileEdit(BuildContext context) {
    context.push('/modules/seller/onboarding', extra: true);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      backgroundColor: _pageBg,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final twoCol = constraints.maxWidth >= _twoColumnBreakpoint;
            void onCreate() => _createListing(context);
            void onOrders() => _navigateToOrders(context, ref);
            void onListings() => _navigateToListings(context, ref);
            void onProfile() => _navigateToProfile(context, ref);
            void onSellerProfileEdit() => _navigateToSellerProfileEdit(context);

            Widget pair(Widget a, Widget b) => twoCol
                ? Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(child: a),
                      const SizedBox(width: 12),
                      Expanded(child: b),
                    ],
                  )
                : Column(children: [a, const SizedBox(height: 12), b]);

            return Column(
              children: [
                _TopBar(onOpenProfile: onProfile),
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                    child: Center(
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 1100),
                        child: Column(
                          children: [
                            _ProfileCard(
                              onViewProfile: onSellerProfileEdit,
                              onEditAvatar: onSellerProfileEdit,
                            ),
                            const SizedBox(height: 12),
                            _QuickActions(
                              onCreateListing: onCreate,
                              onViewListings: onListings,
                              onViewOrders: onOrders,
                            ),
                            const SizedBox(height: 12),
                            _OrderOverview(onViewAllOrders: onOrders),
                            const SizedBox(height: 12),
                            pair(
                              _MyListings(
                                onCreate: onCreate,
                                onViewAll: onListings,
                              ),
                              _EarningsOverview(onViewOrders: onOrders),
                            ),
                            const SizedBox(height: 12),
                            pair(
                              _ProfileDocuments(onOpenSellerProfile: onSellerProfileEdit),
                              const _HelpSupport(),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

// ───────────────────────── top bar ─────────────────────────

class _TopBar extends StatelessWidget {
  const _TopBar({this.onOpenProfile});
  final VoidCallback? onOpenProfile;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      child: Row(
        children: [
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Vasundhara SEVA',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: AppColors.green,
                  ),
                ),
                Text('Earn Together  Live Together', style: TextStyle(fontSize: 10, color: _navy)),
              ],
            ),
          ),
          Stack(
            clipBehavior: Clip.none,
            children: [
              IconButton(
                onPressed: () {
                  // TODO: Navigate to NotificationsScreen once implemented (e.g. context.push('/notifications'))
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Notifications screen is coming soon')),
                  );
                },
                icon: const Icon(Icons.notifications_none, size: 26, color: _navy),
              ),
              Positioned(
                right: 6,
                top: 6,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                  decoration: BoxDecoration(
                    color: Colors.red,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Text('3', style: TextStyle(color: Colors.white, fontSize: 10)),
                ),
              ),
            ],
          ),
          const SizedBox(width: 4),
          InkWell(
            onTap: onOpenProfile ?? () => context.push('/profile'),
            borderRadius: BorderRadius.circular(20),
            child: const Padding(
              padding: EdgeInsets.symmetric(horizontal: 4, vertical: 2),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 18,
                    backgroundColor: Color(0xFFFFE3D1),
                    child: Icon(Icons.person, color: Color(0xFFB3541E)),
                  ),
                  SizedBox(width: 8),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Meena Sharma', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                      Text('Seller', style: TextStyle(fontSize: 11, color: AppColors.muted)),
                    ],
                  ),
                  Icon(Icons.keyboard_arrow_down, size: 20),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ───────────────────────── shared pieces ─────────────────────────

class _Card extends StatelessWidget {
  const _Card({required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: AppColors.border),
    ),
    child: child,
  );
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader(this.title, {this.action, this.onActionTap, this.trailing});
  final String title;
  final String? action;
  final VoidCallback? onActionTap;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Row(
      children: [
        Expanded(
          child: Text(
            title,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: _navy),
          ),
        ),
        ?trailing,
        if (action != null)
          InkWell(
            onTap: onActionTap,
            child: Row(
              children: [
                Text(
                  action!,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF1B5FD6),
                  ),
                ),
                const SizedBox(width: 2),
                const Icon(Icons.arrow_forward, size: 14, color: Color(0xFF1B5FD6)),
              ],
            ),
          ),
      ],
    ),
  );
}

class _Pill extends StatelessWidget {
  const _Pill(this.text, {this.icon});
  final String text;
  final IconData? icon;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
    decoration: BoxDecoration(color: const Color(0xFFDDF3E2), borderRadius: BorderRadius.circular(20)),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (icon != null) ...[Icon(icon, size: 13, color: AppColors.green), const SizedBox(width: 4)],
        Text(
          text,
          style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.green),
        ),
      ],
    ),
  );
}

class _OutlineArrowButton extends StatelessWidget {
  const _OutlineArrowButton(this.label, {required this.onPressed});
  final String label;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) => OutlinedButton(
    onPressed: onPressed,
    style: OutlinedButton.styleFrom(
      foregroundColor: AppColors.green,
      side: const BorderSide(color: AppColors.green),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(label, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
        const SizedBox(width: 6),
        const Icon(Icons.arrow_forward, size: 15),
      ],
    ),
  );
}

class _ListRow extends StatelessWidget {
  const _ListRow({
    required this.icon,
    required this.label,
    this.value,
    this.onTap,
  });
  final IconData icon;
  final String label;
  final String? value;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    child: Padding(
      padding: const EdgeInsets.symmetric(vertical: 11),
      child: Row(
        children: [
          Icon(icon, size: 20, color: _navy),
          const SizedBox(width: 12),
          Expanded(child: Text(label, style: const TextStyle(fontSize: 13.5))),
          if (value != null)
            Text(
              value!,
              style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700),
            ),
          const SizedBox(width: 4),
          const Icon(Icons.chevron_right, size: 20, color: AppColors.muted),
        ],
      ),
    ),
  );
}

// ───────────────────────── profile card ─────────────────────────

class _ProfileCard extends StatelessWidget {
  const _ProfileCard({required this.onViewProfile, this.onEditAvatar});
  final VoidCallback onViewProfile;
  final VoidCallback? onEditAvatar;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFEAF6EE),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFCFE8D6)),
      ),
      child: LayoutBuilder(
        builder: (context, c) {
          final compact = c.maxWidth < 420;
          final button = _OutlineArrowButton('View Profile', onPressed: onViewProfile);
          final info = Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Wrap(
                spacing: 8,
                runSpacing: 4,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: const [
                  Text(
                    "Meena's Homemade Kitchen",
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: _navy),
                  ),
                  _Pill('Approved', icon: Icons.check_circle),
                ],
              ),
              const SizedBox(height: 4),
              const Text(
                'Food  •  Home Cooked Meals',
                style: TextStyle(fontSize: 12, color: Color(0xFF33425B)),
              ),
              const SizedBox(height: 2),
              const Row(
                children: [
                  Icon(Icons.location_on_outlined, size: 14, color: AppColors.muted),
                  SizedBox(width: 2),
                  Text('Kharadi, Pune', style: TextStyle(fontSize: 12, color: AppColors.muted)),
                ],
              ),
            ],
          );

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Stack(
                    clipBehavior: Clip.none,
                    children: [
                      Container(
                        width: 60,
                        height: 60,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          color: Color(0xFFFFE0B2),
                        ),
                        child: const Icon(Icons.ramen_dining, size: 30, color: Color(0xFFB3541E)),
                      ),
                      Positioned(
                        right: -2,
                        bottom: -2,
                        child: InkWell(
                          onTap: onEditAvatar ?? onViewProfile,
                          borderRadius: BorderRadius.circular(10),
                          child: Container(
                            padding: const EdgeInsets.all(4),
                            decoration: const BoxDecoration(
                              color: AppColors.green,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.edit, size: 11, color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(width: 12),
                  Expanded(child: info),
                  if (!compact) button,
                ],
              ),
              if (compact) ...[
                const SizedBox(height: 10),
                Align(alignment: Alignment.centerRight, child: button),
              ],
            ],
          );
        },
      ),
    );
  }
}

// ───────────────────────── quick actions ─────────────────────────

class _Action {
  const _Action(this.icon, this.title, this.subtitle, this.bg, this.fg, {this.subtitleColor});
  final IconData icon;
  final String title;
  final String subtitle;
  final Color bg;
  final Color fg;
  final Color? subtitleColor;
}

class _QuickActions extends StatelessWidget {
  const _QuickActions({
    required this.onCreateListing,
    required this.onViewListings,
    required this.onViewOrders,
  });

  final VoidCallback onCreateListing;
  final VoidCallback onViewListings;
  final VoidCallback onViewOrders;

  static const _items = [
    _Action(Icons.add, 'Create New\nListing', '', Color(0xFFE3F5E8), AppColors.green),
    _Action(Icons.list_alt, 'My Listings', '5 Active', Color(0xFFEBE6FA), Color(0xFF5B3FC4)),
    _Action(
      Icons.shopping_bag,
      'Orders',
      '3 Pending',
      Color(0xFFFFEBD6),
      Color(0xFFE67A1F),
      subtitleColor: Color(0xFFE67A1F),
    ),
    _Action(
      Icons.calendar_month,
      'Availability',
      'Set Schedule',
      Color(0xFFDDEBFF),
      Color(0xFF1B5FD6),
    ),
    _Action(
      Icons.account_balance_wallet,
      'Payouts',
      '₹ 5,240\nThis Month',
      Color(0xFFFFE1E6),
      Color(0xFFD6334C),
      subtitleColor: Color(0xFFD6334C),
    ),
    _Action(Icons.bar_chart, 'Reports', 'View Sales', Color(0xFFEBE6FA), Color(0xFF5B3FC4)),
  ];

  void _handleAction(BuildContext context, _Action a) {
    if (a.title.startsWith('Create')) {
      onCreateListing();
    } else if (a.title.startsWith('My Listings')) {
      onViewListings();
    } else if (a.title.startsWith('Orders')) {
      onViewOrders();
    } else if (a.title.startsWith('Availability')) {
      // TODO: Navigate to SellerAvailabilityScreen once implemented (e.g. context.push('/modules/seller/availability'))
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Seller availability schedule feature is coming soon')),
      );
    } else if (a.title.startsWith('Payouts')) {
      // TODO: Navigate to SellerPayoutsScreen once implemented (e.g. context.push('/modules/seller/payouts'))
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Seller payouts and wallet details screen is coming soon')),
      );
    } else if (a.title.startsWith('Reports')) {
      // TODO: Navigate to SellerReportsScreen/Analytics once implemented (e.g. context.push('/modules/seller/reports'))
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Seller reports and analytics screen is coming soon')),
      );
    }
  }

  Widget _tile(BuildContext context, _Action a, {double? width}) => SizedBox(
    width: width,
    child: InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: () => _handleAction(context, a),
      child: Container(
        padding: const EdgeInsets.fromLTRB(10, 12, 8, 12),
        constraints: const BoxConstraints(minHeight: 108),
        decoration: BoxDecoration(color: a.bg, borderRadius: BorderRadius.circular(12)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            a.title.startsWith('Create')
                ? CircleAvatar(
                    radius: 15,
                    backgroundColor: a.fg,
                    child: Icon(a.icon, size: 18, color: Colors.white),
                  )
                : Icon(a.icon, size: 28, color: a.fg),
            const SizedBox(height: 10),
            Text(
              a.title,
              style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: _navy),
            ),
            if (a.subtitle.isNotEmpty) ...[
              const SizedBox(height: 2),
              Text(
                a.subtitle,
                style: TextStyle(fontSize: 11, color: a.subtitleColor ?? AppColors.muted),
              ),
            ],
          ],
        ),
      ),
    ),
  );

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, c) {
        // wide: all six fill the row; phones: swipe horizontally
        if (c.maxWidth >= 640) {
          return Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              for (var i = 0; i < _items.length; i++) ...[
                Expanded(child: _tile(context, _items[i])),
                if (i != _items.length - 1) const SizedBox(width: 10),
              ],
            ],
          );
        }
        return SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          physics: const BouncingScrollPhysics(),
          child: IntrinsicHeight(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                for (var i = 0; i < _items.length; i++) ...[
                  _tile(context, _items[i], width: 108),
                  if (i != _items.length - 1) const SizedBox(width: 10),
                ],
              ],
            ),
          ),
        );
      },
    );
  }
}

// ───────────────────────── order overview ─────────────────────────

class _OrderStat {
  const _OrderStat(this.icon, this.count, this.label, this.bg, this.fg);
  final IconData icon;
  final String count;
  final String label;
  final Color bg;
  final Color fg;
}

class _OrderOverview extends StatelessWidget {
  const _OrderOverview({this.onViewAllOrders});
  final VoidCallback? onViewAllOrders;

  static const _stats = [
    _OrderStat(
      Icons.hourglass_bottom,
      '3',
      'Pending\nAcceptance',
      Color(0xFFFFF0DD),
      Color(0xFFE67A1F),
    ),
    _OrderStat(Icons.soup_kitchen, '2', 'Preparing', Color(0xFFDDEBFF), Color(0xFF1B5FD6)),
    _OrderStat(Icons.local_shipping, '1', 'Out for\nDelivery', Color(0xFFDDF3E2), AppColors.green),
    _OrderStat(
      Icons.check_circle,
      '12',
      'Completed\n(This Month)',
      Color(0xFFEDEFF3),
      Color(0xFF4A5568),
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return _Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SectionHeader(
            'Order Overview',
            action: 'View All Orders',
            onActionTap: onViewAllOrders,
          ),
          LayoutBuilder(
            builder: (context, c) {
              const gap = 8.0;
              final cols = c.maxWidth >= 440 ? 4 : 2;
              final w = (c.maxWidth - gap * (cols - 1)) / cols;
              return Wrap(
                spacing: gap,
                runSpacing: gap,
                children: [
                  for (final s in _stats)
                    SizedBox(
                      width: w,
                      child: InkWell(
                        onTap: onViewAllOrders,
                        borderRadius: BorderRadius.circular(12),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
                          decoration: BoxDecoration(
                            color: s.bg,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(
                            children: [
                              Icon(s.icon, size: 26, color: s.fg),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      s.count,
                                      style: const TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.w800,
                                        color: _navy,
                                      ),
                                    ),
                                  Text(
                                    s.label,
                                    style: const TextStyle(
                                      fontSize: 10.5,
                                      color: Color(0xFF33425B),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }
}

// ───────────────────────── my listings ─────────────────────────

class _ListingItem {
  const _ListingItem(this.name, this.price, this.stock, this.time, this.icon, this.color);
  final String name;
  final String price;
  final String stock;
  final String time;
  final IconData icon;
  final Color color;
}

class _MyListings extends StatelessWidget {
  const _MyListings({required this.onCreate, this.onViewAll});
  final VoidCallback onCreate;
  final VoidCallback? onViewAll;

  static const _items = [
    _ListingItem(
      'Homemade Veg Thali',
      '₹ 120',
      'Stock: 10',
      'Today: 11:00 AM – 2:00 PM',
      Icons.rice_bowl,
      Color(0xFFFFE0B2),
    ),
    _ListingItem(
      'Snacks – Samosa (6 pcs)',
      '₹ 90',
      'Stock: 25',
      'Today: 11:00 AM – 2:00 PM',
      Icons.bakery_dining,
      Color(0xFFFFD9A8),
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return _Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SectionHeader('My Listings', action: 'View All', onActionTap: onViewAll),
          for (final item in _items)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: InkWell(
                onTap: onViewAll,
                borderRadius: BorderRadius.circular(10),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 56,
                      height: 56,
                      decoration: BoxDecoration(
                        color: item.color,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Icon(item.icon, size: 28, color: const Color(0xFFB3541E)),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            item.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
                          ),
                          const SizedBox(height: 2),
                          Row(
                            children: [
                              Text(
                                item.price,
                                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
                              ),
                              const SizedBox(width: 8),
                              const _Pill('Active'),
                            ],
                          ),
                          const SizedBox(height: 2),
                          Text(
                            '${item.stock}  |  ${item.time}',
                            maxLines: 2,
                            style: const TextStyle(fontSize: 11, color: AppColors.muted),
                          ),
                        ],
                      ),
                    ),
                    InkWell(
                      onTap: onViewAll,
                      child: const Icon(Icons.more_vert, size: 20, color: AppColors.muted),
                    ),
                  ],
                ),
              ),
            ),
          SizedBox(
            width: double.infinity,
            child: _OutlineArrowButton('Create New Listing', onPressed: onCreate),
          ),
        ],
      ),
    );
  }
}

// ───────────────────────── earnings ─────────────────────────

class _EarningsOverview extends StatelessWidget {
  const _EarningsOverview({this.onViewOrders});
  final VoidCallback? onViewOrders;

  Widget _bar(double h) => Container(
    width: 8,
    height: h,
    decoration: BoxDecoration(color: AppColors.green, borderRadius: BorderRadius.circular(3)),
  );

  @override
  Widget build(BuildContext context) {
    return _Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SectionHeader(
            'Earnings Overview',
            action: 'View Details',
            onActionTap: () {
              // TODO: Navigate to SellerEarningsDetailsScreen once implemented (e.g. context.push('/modules/seller/earnings'))
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Detailed earnings statement screen is coming soon')),
              );
            },
          ),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFFDDF3E2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Total Earnings (This Month)',
                        style: TextStyle(fontSize: 11.5, color: Color(0xFF33425B)),
                      ),
                      const SizedBox(height: 4),
                      Wrap(
                        crossAxisAlignment: WrapCrossAlignment.center,
                        spacing: 8,
                        children: const [
                          Text(
                            '₹ 5,240',
                            style: TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.w800,
                              color: _navy,
                            ),
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.trending_up, size: 16, color: AppColors.green),
                              SizedBox(width: 2),
                              Text(
                                '+18%',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.green,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    _bar(16),
                    const SizedBox(width: 4),
                    _bar(26),
                    const SizedBox(width: 4),
                    _bar(40),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 6),
          _ListRow(
            icon: Icons.assignment_turned_in_outlined,
            label: 'Completed Orders',
            value: '12',
            onTap: onViewOrders,
          ),
          const Divider(height: 1, color: AppColors.border),
          _ListRow(
            icon: Icons.hourglass_empty,
            label: 'Pending Payout',
            value: '₹ 2,480',
            onTap: () {
              // TODO: Navigate to PendingPayoutsScreen once implemented (e.g. context.push('/modules/seller/payouts/pending'))
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Pending payouts details screen is coming soon')),
              );
            },
          ),
          const Divider(height: 1, color: AppColors.border),
          _ListRow(
            icon: Icons.account_balance_wallet_outlined,
            label: 'Total Payout (Till Date)',
            value: '₹ 18,760',
            onTap: () {
              // TODO: Navigate to PayoutHistoryScreen once implemented (e.g. context.push('/modules/seller/payouts/history'))
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Payout history screen is coming soon')),
              );
            },
          ),
        ],
      ),
    );
  }
}

// ───────────────────────── profile & help ─────────────────────────

class _ProfileDocuments extends StatelessWidget {
  const _ProfileDocuments({this.onOpenSellerProfile});
  final VoidCallback? onOpenSellerProfile;

  @override
  Widget build(BuildContext context) {
    return _Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _SectionHeader(
            'Profile & Documents',
            trailing: _Pill('Verified', icon: Icons.check_circle),
          ),
          _ListRow(
            icon: Icons.person_outline,
            label: 'Personal & Business Details',
            onTap: onOpenSellerProfile ?? () => context.push('/modules/seller/onboarding', extra: true),
          ),
          const Divider(height: 1, color: AppColors.border),
          _ListRow(
            icon: Icons.description_outlined,
            label: 'Documents (FSSAI, ID, etc.)',
            onTap: onOpenSellerProfile ?? () => context.push('/modules/seller/onboarding', extra: true),
          ),
          const Divider(height: 1, color: AppColors.border),
          _ListRow(
            icon: Icons.account_balance_outlined,
            label: 'Bank & Payout Details',
            // Navigates to Seller Onboarding (Edit mode) where bank details are managed.
            // TODO: Navigate to dedicated BankPayoutDetailsScreen once separated into its own route.
            onTap: onOpenSellerProfile ?? () => context.push('/modules/seller/onboarding', extra: true),
          ),
        ],
      ),
    );
  }
}

class _HelpSupport extends StatelessWidget {
  const _HelpSupport();

  @override
  Widget build(BuildContext context) {
    return _Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _SectionHeader('Help & Support'),
          _ListRow(
            icon: Icons.help_outline,
            label: 'FAQs for Sellers',
            onTap: () {
              // TODO: Navigate to SellerFaqScreen once implemented (e.g. context.push('/help/seller-faqs'))
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Seller FAQs screen is coming soon')),
              );
            },
          ),
          const Divider(height: 1, color: AppColors.border),
          _ListRow(
            icon: Icons.headset_mic_outlined,
            label: 'Contact Support',
            onTap: () {
              // TODO: Navigate to ContactSupportScreen once implemented (e.g. context.push('/help/contact-support'))
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Contact support screen is coming soon')),
              );
            },
          ),
          const Divider(height: 1, color: AppColors.border),
          _ListRow(
            icon: Icons.menu_book_outlined,
            label: 'Seller Guidelines',
            onTap: () {
              // TODO: Navigate to SellerGuidelinesScreen once implemented (e.g. context.push('/help/guidelines'))
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Seller guidelines screen is coming soon')),
              );
            },
          ),
          const Divider(height: 1, color: AppColors.border),
          _ListRow(
            icon: Icons.restaurant_menu,
            label: 'Food Safety & Compliance (FSSAI)',
            onTap: () {
              // TODO: Navigate to FoodSafetyComplianceScreen once implemented (e.g. context.push('/help/food-safety'))
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Food safety & compliance guidelines are coming soon')),
              );
            },
          ),
        ],
      ),
    );
  }
}
