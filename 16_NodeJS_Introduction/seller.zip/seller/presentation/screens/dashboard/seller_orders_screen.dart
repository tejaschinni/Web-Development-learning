// lib/features/seller/presentation/screens/dashboard/seller_orders_screen.dart

import 'package:flutter/material.dart';
import 'package:society_seva/features/seller/presentation/screens/orders/seller_orders_list_screen.dart';

export 'package:society_seva/features/seller/presentation/screens/orders/seller_orders_list_screen.dart';

/// Seller Orders screen embedded in SellerDashboardScreen tabs.
/// Delegates to the redesigned [SellerOrdersListScreen] matching the design screenshot.
class SellerOrdersScreen extends StatelessWidget {
  const SellerOrdersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const SellerOrdersListScreen(isEmbeddedTab: true);
  }
}
