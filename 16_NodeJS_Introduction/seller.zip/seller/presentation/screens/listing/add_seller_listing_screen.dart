// lib/features/seller/presentation/screens/listing/add_seller_listing_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_listing_provider.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/seller/presentation/widgets/listing/listing_success_dialogs.dart';
import 'package:society_seva/features/seller/presentation/widgets/listing/steps/listing_additional_info_step.dart';
import 'package:society_seva/features/seller/presentation/widgets/listing/steps/listing_basic_info_step.dart';
import 'package:society_seva/features/seller/presentation/widgets/listing/steps/listing_photos_step.dart';
import 'package:society_seva/features/seller/presentation/widgets/listing/steps/listing_pricing_step.dart';
import 'package:society_seva/features/seller/presentation/widgets/listing/steps/review_section_step.dart';
import 'package:society_seva/features/seller/presentation/widgets/listing/steps/select_catgeory_step.dart';

class AddSellerListingScreen extends ConsumerWidget {
  const AddSellerListingScreen({super.key});

  Widget _buildStep(int step) {
    switch (step) {
      case 0:
        return const SelectCatgeoryStep();
      case 1:
        return const ListingBasicInfoStep();
      case 2:
        return const ListingPricingStep();
      case 3:
        return const ListingAdditionalInfoStep();
      case 4:
        return const ListingPhotosStep();
      case 5:
      default:
        return const ListingReviewStep();
    }
  }

  Future<void> _handleSubmit(BuildContext context, WidgetRef ref) async {
    final notifier = ref.read(productListingProvider.notifier);
    final ok = await notifier.submit();
    if (!context.mounted) return;

    if (ok) {
      showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (sheetCtx) => ListingSubmittedSheet(
          onGoToListings: () {
            Navigator.pop(sheetCtx);
            Navigator.pop(context, true);
          },
          onCreateAnother: () {
            Navigator.pop(sheetCtx);
            notifier.resetForm();
          },
        ),
      );
    } else {
      final error = ref.read(productListingProvider).error;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Submission failed: $error')),
      );
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final step = ref.watch(productListingProvider.select((s) => s.currentStep));
    final busy = ref.watch(productListingProvider.select((s) => s.isBusy));
    final submitting = ref.watch(productListingProvider.select((s) => s.isSubmitting));
    final canProceed = ref.watch(listingStepValidProvider);
    final notifier = ref.read(productListingProvider.notifier);

    final isCategoryStep = step == 0;

    void goBack() => isCategoryStep ? Navigator.maybePop(context) : notifier.back();

    return PopScope(
      canPop: isCategoryStep && !busy,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop && !busy) notifier.back();
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: Column(
            children: [
              _Header(onBack: busy ? null : goBack),
              _ListingStepper(
                currentStep: step,
                onStepTapped: (index) => notifier.goTo(index),
              ),
              const Divider(height: 1, color: Color(0xFFF2F4F7)),
              Expanded(
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 200),
                  child: KeyedSubtree(key: ValueKey(step), child: _buildStep(step)),
                ),
              ),
              _BottomBar(
                currentStep: step,
                canProceed: canProceed && !busy,
                submitting: submitting,
                busy: busy,
                onBack: goBack,
                onNext: () => notifier.next(),
                onSubmit: () => _handleSubmit(context, ref),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ───────────────────────── header ─────────────────────────

class _Header extends ConsumerWidget {
  const _Header({required this.onBack});
  final VoidCallback? onBack;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sellerProfile = ref.watch(mySellerProfileProvider).valueOrNull;
    final sellerName = sellerProfile?.businessName ?? 'Meena Sharma';

    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 4, 16, 4),
      child: Row(
        children: [
          IconButton(onPressed: onBack, icon: const Icon(Icons.arrow_back, color: AppColors.ink)),
          const Spacer(),
          Image.asset(
            'assets/images/logo/h-logo.png',
            height: 28,
            fit: BoxFit.contain,
            errorBuilder: (context, error, stackTrace) => const Text(
              'Vasundhara SEVA',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.green),
            ),
          ),
          const Spacer(),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircleAvatar(
                radius: 14,
                backgroundColor: AppColors.orangeSoft,
                child: Text(
                  sellerName.isNotEmpty ? sellerName[0] : 'S',
                  style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.orange),
                ),
              ),
              const SizedBox(width: 6),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    sellerName,
                    style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.ink),
                  ),
                  const Text(
                    'Seller',
                    style: TextStyle(fontSize: 10, color: AppColors.muted),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ───────────────────────── 6-Step Stepper ─────────────────────────

class _ListingStepper extends StatelessWidget {
  const _ListingStepper({
    required this.currentStep,
    required this.onStepTapped,
  });

  final int currentStep;
  final ValueChanged<int> onStepTapped;

  @override
  Widget build(BuildContext context) {
    const steps = [
      'Category',
      'Basic',
      'Pricing',
      'Details',
      'Photos',
      'Review',
    ];

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      color: Colors.white,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          for (var i = 0; i < steps.length; i++) ...[
            Expanded(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => onStepTapped(i),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _StepCircle(
                      number: i + 1,
                      isActive: currentStep == i,
                      isDone: currentStep > i,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      steps[i],
                      textAlign: TextAlign.center,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 9.5,
                        fontWeight: currentStep == i ? FontWeight.w700 : FontWeight.w500,
                        color: currentStep == i
                            ? AppColors.green
                            : (currentStep > i ? AppColors.ink : AppColors.muted),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            if (i < steps.length - 1)
              Padding(
                padding: const EdgeInsets.only(top: 11),
                child: Container(
                  width: 12,
                  height: 1.5,
                  color: currentStep > i ? AppColors.green : const Color(0xFFE4E7EC),
                ),
              ),
          ],
        ],
      ),
    );
  }
}

class _StepCircle extends StatelessWidget {
  const _StepCircle({
    required this.number,
    required this.isActive,
    required this.isDone,
  });

  final int number;
  final bool isActive;
  final bool isDone;

  @override
  Widget build(BuildContext context) {
    if (isDone) {
      return Container(
        width: 24,
        height: 24,
        decoration: const BoxDecoration(
          color: AppColors.green,
          shape: BoxShape.circle,
        ),
        alignment: Alignment.center,
        child: const Icon(Icons.check, size: 14, color: Colors.white),
      );
    }

    if (isActive) {
      return Container(
        width: 24,
        height: 24,
        decoration: const BoxDecoration(
          color: AppColors.green,
          shape: BoxShape.circle,
        ),
        alignment: Alignment.center,
        child: Text(
          '$number',
          style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: Colors.white),
        ),
      );
    }

    return Container(
      width: 24,
      height: 24,
      decoration: BoxDecoration(
        color: Colors.white,
        shape: BoxShape.circle,
        border: Border.all(color: const Color(0xFFD0D5DD), width: 1.5),
      ),
      alignment: Alignment.center,
      child: Text(
        '$number',
        style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: Color(0xFF98A2B3)),
      ),
    );
  }
}

// ───────────────────────── bottom bar ─────────────────────────

class _BottomBar extends StatelessWidget {
  const _BottomBar({
    required this.currentStep,
    required this.canProceed,
    required this.submitting,
    required this.busy,
    required this.onBack,
    required this.onNext,
    required this.onSubmit,
  });

  final int currentStep;
  final bool canProceed, submitting, busy;
  final VoidCallback onBack, onNext, onSubmit;

  @override
  Widget build(BuildContext context) {
    final filledGreen = FilledButton.styleFrom(
      minimumSize: const Size.fromHeight(48),
      backgroundColor: AppColors.green,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    );

    final outlined = OutlinedButton.styleFrom(
      minimumSize: const Size.fromHeight(48),
      foregroundColor: AppColors.ink,
      side: const BorderSide(color: Color(0xFFD0D5DD)),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    );

    // Step 0: Category step -> Full width Next button
    if (currentStep == 0) {
      return Container(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
        decoration: const BoxDecoration(
          color: Colors.white,
          border: Border(top: BorderSide(color: Color(0xFFF2F4F7))),
        ),
        child: FilledButton(
          style: filledGreen,
          onPressed: canProceed ? onNext : null,
          child: const Text('Next', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
        ),
      );
    }

    // Steps 1 to 4: Basic, Pricing, Details, Photos -> Back + Next buttons
    if (currentStep >= 1 && currentStep <= 4) {
      return Container(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
        decoration: const BoxDecoration(
          color: Colors.white,
          border: Border(top: BorderSide(color: Color(0xFFF2F4F7))),
        ),
        child: Row(
          children: [
            Expanded(
              flex: 1,
              child: OutlinedButton(
                style: outlined,
                onPressed: onBack,
                child: const Text('Back', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              flex: 2,
              child: FilledButton(
                style: filledGreen,
                onPressed: canProceed ? onNext : null,
                child: const Text('Next', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
              ),
            ),
          ],
        ),
      );
    }

    // Step 5: Review -> Back + Submit for Review button
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: Color(0xFFF2F4F7))),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 1,
            child: OutlinedButton(
              style: outlined,
              onPressed: onBack,
              child: const Text('Back', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            flex: 2,
            child: FilledButton(
              style: filledGreen,
              onPressed: busy ? null : onSubmit,
              child: submitting
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : const Text('Submit for Review', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
            ),
          ),
        ],
      ),
    );
  }
}
