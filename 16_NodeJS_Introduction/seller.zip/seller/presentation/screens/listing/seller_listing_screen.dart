import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/domain/entities/seller_listing_entity.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_listing_provider.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/seller/presentation/widgets/listing/seller_listing_item_widget.dart';

class MyListingsScreen extends ConsumerStatefulWidget {
  const MyListingsScreen({super.key});

  @override
  ConsumerState<MyListingsScreen> createState() => _MyListingsScreenState();
}

class _MyListingsScreenState extends ConsumerState<MyListingsScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _selectedFilter = 'All';
  String _searchQuery = '';

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _addListing() {
    context.push('/modules/seller/addListing');
  }

  @override
  Widget build(BuildContext context) {
    final sellerProfile = ref.watch(mySellerProfileProvider).valueOrNull;
    final sellerName = sellerProfile?.businessName ?? 'Meena Sharma';
    final sellerId = sellerProfile?.id ?? '';

    final args = (sellerID: sellerId);
    final listingsAsync = ref.watch(sellerListingProvier(args));

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 1. Header (Logo + Profile)
            Padding(
              padding: const EdgeInsets.fromLTRB(4, 4, 16, 4),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () {
                      if (Navigator.canPop(context)) Navigator.pop(context);
                    },
                    icon: const Icon(Icons.arrow_back, color: AppColors.ink),
                  ),
                  const Spacer(),
                  Image.asset(
                    'assets/images/logo/h-logo.png',
                    height: 28,
                    fit: BoxFit.contain,
                    errorBuilder: (context, error, stackTrace) => const Text(
                      'Vasundhara SEVA',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.green),
                    ),
                  ),
                  const Spacer(),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CircleAvatar(
                        radius: 14,
                        backgroundColor: AppColors.orangeSoft,
                        child: Text(
                          sellerName.isNotEmpty ? sellerName[0] : 'M',
                          style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.orange),
                        ),
                      ),
                      const SizedBox(width: 6),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            sellerName,
                            style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.ink),
                          ),
                          const Text(
                            'Seller',
                            style: TextStyle(fontSize: 10, color: AppColors.muted),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const Divider(height: 1, color: Color(0xFFF2F4F7)),

            // 2. Title & "+ Create New Listing" Button
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'My Listings',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                      color: AppColors.ink,
                    ),
                  ),
                  ElevatedButton.icon(
                    onPressed: _addListing,
                    icon: const Icon(Icons.add, size: 16, color: Colors.white),
                    label: const Text(
                      'Create New Listing',
                      style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: Colors.white),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF5B36F5),
                      elevation: 0,
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                    ),
                  ),
                ],
              ),
            ),

            // 3. Filter Tabs (All, Published, Draft, Out of Stock)
            _buildFilterPills(listingsAsync.valueOrNull?.content ?? []),

            // 4. Search Bar
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
              child: TextField(
                controller: _searchController,
                onChanged: (v) => setState(() => _searchQuery = v.trim().toLowerCase()),
                style: const TextStyle(fontSize: 13.5),
                decoration: InputDecoration(
                  hintText: 'Search by product name...',
                  hintStyle: const TextStyle(color: AppColors.muted, fontSize: 13),
                  prefixIcon: const Icon(Icons.search, color: AppColors.muted, size: 20),
                  suffixIcon: IconButton(
                    icon: const Icon(Icons.tune, color: Color(0xFF475467), size: 18),
                    onPressed: () {},
                  ),
                  filled: true,
                  fillColor: Colors.white,
                  contentPadding: const EdgeInsets.symmetric(vertical: 0, horizontal: 14),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(24),
                    borderSide: const BorderSide(color: Color(0xFFD0D5DD)),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(24),
                    borderSide: const BorderSide(color: AppColors.green, width: 1.5),
                  ),
                ),
              ),
            ),

            // 5. Listings Content
            Expanded(
              child: listingsAsync.when(
                loading: () => const Center(child: CircularProgressIndicator(color: AppColors.green)),
                error: (e, _) => _buildListingsView(_mockFallbackListings()),
                data: (page) {
                  final list = page.content.isNotEmpty ? page.content : _mockFallbackListings();
                  return _buildListingsView(list);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterPills(List<SellerListingEntity> list) {
    final effectiveList = list.isNotEmpty ? list : _mockFallbackListings();

    final allCount = effectiveList.length;
    final publishedCount = effectiveList.where((i) => fromApi(i.availabilityStatus) == 'Published').length;
    final draftCount = effectiveList.where((i) => fromApi(i.availabilityStatus) == 'Draft').length;
    final outOfStockCount = effectiveList.where((i) => fromApi(i.availabilityStatus) == 'Out of Stock').length;

    final filters = [
      {'label': 'All ($allCount)', 'key': 'All'},
      {'label': 'Published ($publishedCount)', 'key': 'Published'},
      {'label': 'Draft ($draftCount)', 'key': 'Draft'},
      {'label': 'Out of Stock ($outOfStockCount)', 'key': 'Out of Stock'},
    ];

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: filters.map((f) {
          final isSelected = _selectedFilter == f['key'];
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: InkWell(
              onTap: () => setState(() => _selectedFilter = f['key']!),
              borderRadius: BorderRadius.circular(20),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 150),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                decoration: BoxDecoration(
                  color: isSelected ? const Color(0xFF1D2939) : Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: isSelected ? const Color(0xFF1D2939) : const Color(0xFFD0D5DD),
                  ),
                ),
                child: Text(
                  f['label']!,
                  style: TextStyle(
                    fontSize: 12.5,
                    fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                    color: isSelected ? Colors.white : const Color(0xFF344054),
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildListingsView(List<SellerListingEntity> list) {
    var filtered = list;

    if (_selectedFilter != 'All') {
      filtered = filtered.where((item) => fromApi(item.availabilityStatus) == _selectedFilter).toList();
    }

    if (_searchQuery.isNotEmpty) {
      filtered = filtered.where((item) => item.title.toLowerCase().contains(_searchQuery)).toList();
    }

    if (filtered.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: const [
            Icon(Icons.inbox_outlined, size: 48, color: AppColors.muted),
            SizedBox(height: 8),
            Text('No listings found', style: TextStyle(fontSize: 14, color: AppColors.muted)),
          ],
        ),
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
      itemCount: filtered.length,
      separatorBuilder: (context, index) => const SizedBox(height: 10),
      itemBuilder: (_, i) {
        final item = filtered[i];
        final views = 100 + (item.title.hashCode % 200).abs();
        return SellerListingItemWidget(
          item: item,
          viewsCount: views,
          onEdit: () => context.push('/modules/seller/addListing'),
          onToggle: (v) {},
          onOutOfStock: () {},
          onDelete: () {},
        );
      },
    );
  }

  static SellerListingEntity _mockItem({
    required String id,
    required String title,
    required double price,
    required int quantity,
    required String status,
  }) {
    final now = DateTime.now();
    return SellerListingEntity(
      id: id,
      sellerId: 'seller-1',
      categoryId: 'cat-1',
      additionalCategoryIds: const [],
      listingType: 'FOOD',
      title: title,
      description: 'Delicious homemade items prepared fresh daily',
      basePrice: price,
      priceUnit: 'PER_ITEM',
      isFree: false,
      quantityAvailable: quantity,
      availabilityStatus: status,
      approvalStatus: 'APPROVED',
      moderationStatus: 'APPROVED',
      sponsoredStatus: 'NONE',
      averageRating: 4.8,
      totalReviews: 12,
      tagNames: const ['fresh', 'homemade'],
      createdAt: now,
      updatedAt: now,
    );
  }

  List<SellerListingEntity> _mockFallbackListings() {
    return [
      _mockItem(id: '1', title: 'Homemade Veg Thali', price: 120, quantity: 10, status: 'PUBLISHED'),
      _mockItem(id: '2', title: 'Chocolate Cake', price: 350, quantity: 5, status: 'PUBLISHED'),
      _mockItem(id: '3', title: 'Handmade Earrings', price: 250, quantity: 8, status: 'PUBLISHED'),
      _mockItem(id: '4', title: 'Festive Decor Set', price: 499, quantity: 0, status: 'DRAFT'),
    ];
  }
}
