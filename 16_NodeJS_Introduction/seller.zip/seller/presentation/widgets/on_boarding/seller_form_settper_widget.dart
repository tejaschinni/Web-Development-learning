import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:society_seva/features/profile/presentation/providers/profile_provider.dart';
import 'package:society_seva/features/seller/data/models/request/seller_profile_request.dart';
import 'package:society_seva/features/seller/domain/entities/seller_profile_entity.dart';
import 'package:society_seva/features/seller/domain/enum/seller_type_config.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/steps/address_step.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/steps/basic_info_step.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/steps/certificates_step.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/steps/documents_step.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/steps/photos_step.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/steps/seller_type_step.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';

class SellerFormSettperWidget extends ConsumerStatefulWidget {
  const SellerFormSettperWidget({super.key, this.initial, this.isEdit});
  final SellerProfileEntity? initial;
  final bool? isEdit;

  @override
  ConsumerState<SellerFormSettperWidget> createState() => _SellerFormSettperWidgetState();
}

class _SellerFormSettperWidgetState extends ConsumerState<SellerFormSettperWidget> {
  static const _addressStepIndex = 2;
  static const _documentsStepIndex = 4;
  static const _certificatesStepIndex = 5;
  static const _lastStep = _certificatesStepIndex; // certificates is optional, but still last
  static const _detailSteps = 3; // steps 0..2 hold the profile data

  // Each step has its own form so "Next" only validates the current step.
  final _basicFormKey = GlobalKey<FormState>();
  final _typeFormKey = GlobalKey<FormState>();
  final _addressFormKey = GlobalKey<FormState>();

  int _step = 0;

  late final _displayName = TextEditingController();
  late final _businessName = TextEditingController();
  late final _bio = TextEditingController();

  late final _address = TextEditingController();
  late final _city = TextEditingController();
  late final _state = TextEditingController();
  late final _country = TextEditingController();
  late final _pincode = TextEditingController();

  late final _deliveryRadius = TextEditingController();
  late final _targetArea = TextEditingController();
  late final _fassiCertificateID = TextEditingController();
  late final _socialMediaLinks = TextEditingController();
  late final _websiteUrl = TextEditingController();
  late final _legelCompliances = TextEditingController();
  String _sellerType = sellerTypes.first;
  bool _isFassaiStatus = true;

  GoogleMapController? _map;
  LatLng? _selected;
  LatLng? _devicePoint;
  bool _pointChanged = false;
  LocationPermission _permission = LocationPermission.denied;
  bool _permissionReady = false;
  bool _serviceDisabled = false;
  bool _locating = false;
  bool _geocoding = false;
  bool _locationRequested = false;
  String? _locationError;
  int _geocodeRequest = 0;

  SellerTypeConfig get _cfg => sellerTypeConfigs[_sellerType]!;

  bool get _hasLocationPermission =>
      _permission == LocationPermission.whileInUse || _permission == LocationPermission.always;

  @override
  void initState() {
    super.initState();
    final s = widget.initial;
    if (s == null) return;

    _displayName.text = s.displayName;
    _address.text = s.address;
    _city.text = s.city;
    _state.text = s.state;
    _country.text = s.country;
    _pincode.text = s.pinCode;
    _bio.text = s.bio.toString();
    _businessName.text = s.businessName.toString();
    _socialMediaLinks.text = s.socialMediaLinks.toString();
    _websiteUrl.text = s.websiteUrl.toString();
    _legelCompliances.text = s.legalCompliance.toString();
    _fassiCertificateID.text = s.fssaiCertificateId.toString();

    _deliveryRadius.text = s.deliveryRadiusKm?.toString() ?? '';
    _targetArea.text = s.targetArea ?? '';
    if (sellerTypes.contains(s.sellerType)) _sellerType = s.sellerType;
    if (isFassaiRequiredOptions.contains(s.fssaiRequired)) _isFassaiStatus = s.fssaiRequired;

    final lat = s.latitude;
    final lng = s.longitude;
    if (lat != null && lng != null && !(lat == 0 && lng == 0)) {
      _selected = LatLng(lat, lng);
    }
  }

  @override
  void dispose() {
    _displayName.dispose();
    _businessName.dispose();
    _bio.dispose();
    _address.dispose();
    _city.dispose();
    _state.dispose();
    _country.dispose();
    _pincode.dispose();
    _deliveryRadius.dispose();
    _targetArea.dispose();
    _fassiCertificateID.dispose();
    _socialMediaLinks.dispose();
    _websiteUrl.dispose();
    _legelCompliances.dispose();
    super.dispose();
  }

  String get _userId => ref.read(profileControllerProvider).profile!.id.toString();

  String get _sellerID {
    final seller = ref.watch(mySellerProfileProvider).value ?? widget.initial;
    return seller?.id.toString() ?? "";
  }

  bool get _fssaiRequiredValue => _cfg.fssai && _isFassaiStatus;
  String get _fssaiIdValue => _fssaiRequiredValue ? _fassiCertificateID.text.trim() : '';
  double? get _radiusValue => _cfg.delivery ? double.tryParse(_deliveryRadius.text.trim()) : null;
  String get _targetAreaValue => _cfg.targetArea ? _targetArea.text.trim() : '';
  String get _socialValue => _cfg.social ? _socialMediaLinks.text.trim() : '';
  String get _websiteValue => _cfg.website ? _websiteUrl.text.trim() : '';
  String get _legalValue => _cfg.legal ? _legelCompliances.text.trim() : '';

  bool _filled(Iterable<TextEditingController> cs) => cs.every((c) => c.text.trim().isNotEmpty);

  bool get _basicFilled => _filled([_displayName, _businessName, _bio]);
  bool get _typeFilled {
    final c = _cfg;
    return _filled([
      if (_fssaiRequiredValue) _fassiCertificateID,
      if (c.delivery && c.deliveryRequired) _deliveryRadius,
      if (c.targetArea && c.targetAreaRequired) _targetArea,
    ]);
  }

  bool get _addressFilled => _filled([_address, _city, _state, _country, _pincode]);

  bool _stepValid(int i) {
    switch (i) {
      case 0:
        return _basicFormKey.currentState?.validate() ?? _basicFilled;
      case 1:
        return _typeFormKey.currentState?.validate() ?? _typeFilled;
      case 2:
        {
          final fieldsOk = _addressFormKey.currentState?.validate() ?? _addressFilled;
          if (_selected == null) {
            if (mounted) {
              setState(() => _locationError = 'Choose your location on the map.');
            }
            return false;
          }
          return fieldsOk;
        }
      default:
        return true;
    }
  }

  bool _validateDetails() {
    for (var i = 0; i < _detailSteps; i++) {
      if (!_stepValid(i)) {
        if (_step != i && mounted) _setStep(i);
        return false;
      }
    }
    return true;
  }

  Future<bool> _save() async {
    if (!_validateDetails()) return false;
    final point = _selected!; // _validateDetails guarantees a picked point

    return ref
        .read(sellerFormActionProvider.notifier)
        .save(
          SellerProfileRequest(
            userId: _userId,
            displayName: _displayName.text.trim(),
            sellerType: _sellerType,
            address: _address.text.trim(),
            city: _city.text.trim(),
            state: _state.text.trim(),
            country: _country.text.trim(),
            pinCode: _pincode.text.trim(),
            bio: _bio.text.trim(),
            businessName: _businessName.text.trim(),
            fssaiCertificateId: _fssaiIdValue,
            fssaiRequired: _fssaiRequiredValue,
            geofencePolygon: '',
            latitude: point.latitude,
            longitude: point.longitude,
            legalCompliance: _legalValue,
            socialMediaLinks: _socialValue,
            websiteUrl: _websiteValue,
            deliveryRadiusKm: _radiusValue,
            targetArea: _targetAreaValue,
          ),
        );
  }

  Future<void> _onSavePressed() async {
    final ok = await _save();
    if (ok && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Saved as draft')));
    }
  }

  Future<void> _onUpdateSellerProfile() async {
    if (!_validateDetails()) return;

    final orig = widget.initial!;

    String? diff(String now, String? original) {
      final n = now.trim();
      return n == (original ?? '').trim() ? null : n;
    }

    final address = diff(_address.text, orig.address);
    final city = diff(_city.text, orig.city);
    final state = diff(_state.text, orig.state);
    final country = diff(_country.text, orig.country);
    final pinCode = diff(_pincode.text, orig.pinCode);

    final point = _pointChanged ? _selected : null;
    final lat = point?.latitude;
    final lng = point?.longitude;

    final radius = _radiusValue;

    final request = SellerProfileRequest(
      userId: _userId, // identifier, always sent
      displayName: diff(_displayName.text, orig.displayName).toString(),
      businessName: diff(_businessName.text, orig.businessName),
      bio: diff(_bio.text, orig.bio),
      sellerType: _sellerType != orig.sellerType ? _sellerType : '',
      address: address.toString(),
      city: city.toString(),
      state: state.toString(),
      country: country.toString(),
      pinCode: pinCode.toString(),
      latitude: lat,
      longitude: lng,
      fssaiCertificateId: diff(_fssaiIdValue, orig.fssaiCertificateId),
      fssaiRequired: _fssaiRequiredValue != orig.fssaiRequired ? _fssaiRequiredValue : null,
      legalCompliance: diff(_legalValue, orig.legalCompliance),
      socialMediaLinks: diff(_socialValue, orig.socialMediaLinks),
      websiteUrl: diff(_websiteValue, orig.websiteUrl),
      deliveryRadiusKm: radius != orig.deliveryRadiusKm ? radius : null,
      targetArea: diff(_targetAreaValue, orig.targetArea),
    );

    final pending = ref.read(sellerFormActionProvider);
    final noPendingUploads =
        pending.pendingDocuments.isEmpty && pending.pendingCertificates.isEmpty;

    if (request.isEmpty && noPendingUploads) {
      if (mounted) Navigator.pop(context, false);
      return;
    }

    final ok = await ref
        .read(sellerFormActionProvider.notifier)
        .update(request, widget.initial!.id.toString());

    if (ok && mounted) Navigator.pop(context, true);
  }

  Future<void> _onSubmitPressed() async {
    if (!_validateDetails()) return;

    if (ref.read(sellerFormActionProvider).pendingDocuments.isEmpty) {
      _setStep(_documentsStepIndex);
      _snack('Please add at least one document before submitting');
      return;
    }

    final point = _selected!;

    final request = SellerProfileRequest(
      userId: _userId,
      displayName: _displayName.text.trim(),
      sellerType: _sellerType,
      address: _address.text.trim(),
      city: _city.text.trim(),
      state: _state.text.trim(),
      country: _country.text.trim(),
      pinCode: _pincode.text.trim(),
      bio: _bio.text.trim(),
      businessName: _businessName.text.trim(),
      fssaiCertificateId: _fssaiIdValue,
      fssaiRequired: _fssaiRequiredValue,
      latitude: point.latitude,
      longitude: point.longitude,
      legalCompliance: _legalValue,
      socialMediaLinks: _socialValue,
      websiteUrl: _websiteValue,
      deliveryRadiusKm: _radiusValue,
      targetArea: _targetAreaValue,
    );

    final ok = await ref.read(sellerFormActionProvider.notifier).submit(request);
    if (ok && mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Submitted for approval')));
      Navigator.pop(context, true);
    }
  }

  Future<void> _requestLocation() async {
    if (_locating) return;
    setState(() {
      _locating = true;
      _locationError = null;
    });
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        if (mounted) {
          setState(() {
            _serviceDisabled = true;
            _permissionReady = true;
            _locationError = 'Turn on device location to center the map on you.';
          });
        }
        return;
      }
      if (mounted) setState(() => _serviceDisabled = false);
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (!mounted) return;
      setState(() {
        _permission = permission;
        _permissionReady = true;
      });
      if (permission != LocationPermission.whileInUse && permission != LocationPermission.always) {
        setState(
          () => _locationError = permission == LocationPermission.deniedForever
              ? 'Location access is disabled for this app. You can enable it in Settings or choose a point on the map.'
              : 'Location access was not granted. You can still choose a point on the map.',
        );
        return;
      }
      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 15),
        ),
      );
      final current = LatLng(position.latitude, position.longitude);
      if (!mounted) return;
      setState(() => _devicePoint = current);
      await _moveTo(current, zoom: 16);
    } catch (_) {
      if (mounted) {
        setState(
          () => _locationError =
              'Could not get your current location. You can still choose a point on the map.',
        );
      }
    } finally {
      if (mounted) setState(() => _locating = false);
    }
  }

  Future<void> _moveTo(LatLng point, {required double zoom}) async {
    try {
      await _map?.animateCamera(
        CameraUpdate.newCameraPosition(CameraPosition(target: point, zoom: zoom)),
      );
    } catch (_) {
      // The map can be disposed while the step is closing.
    }
  }

  Future<void> _selectPoint(LatLng point) async {
    final requestId = ++_geocodeRequest;
    setState(() {
      _selected = point;
      _pointChanged = true;
      _geocoding = true;
      _locationError = null;
    });
    _address.clear();
    _city.clear();
    _state.clear();
    _country.clear();
    _pincode.clear();
    try {
      final places = await Geocoding().placemarkFromCoordinates(point.latitude, point.longitude);
      if (!mounted || requestId != _geocodeRequest) return;
      if (places.isEmpty) throw StateError('No address found for this point.');
      final place = places.first;
      final locality = [place.subLocality, place.thoroughfare, place.name]
          .whereType<String>()
          .map((value) => value.trim())
          .where((value) => value.isNotEmpty)
          .toSet()
          .join(', ');
      _address.text = locality.isNotEmpty ? locality : (place.locality ?? '');
      _city.text = [place.locality, place.subAdministrativeArea, place.administrativeArea]
          .whereType<String>()
          .map((value) => value.trim())
          .firstWhere((value) => value.isNotEmpty, orElse: () => '');
      _state.text = place.administrativeArea ?? '';
      _country.text =
          (place.country?.isNotEmpty == true ? place.country : place.isoCountryCode) ?? '';
      _pincode.text = place.postalCode ?? '';
      if (_address.text.isEmpty || _city.text.isEmpty) {
        setState(
          () =>
              _locationError = 'Some address details were unavailable. Please complete the fields.',
        );
      }
    } catch (_) {
      if (mounted && requestId == _geocodeRequest) {
        setState(
          () => _locationError =
              'Could not look up this address. Fill in the address fields to continue.',
        );
      }
    } finally {
      if (mounted && requestId == _geocodeRequest) {
        setState(() => _geocoding = false);
      }
    }
  }

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  void _setStep(int index) {
    setState(() => _step = index);

    if (index == _addressStepIndex && !_locationRequested && _selected == null) {
      _locationRequested = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _requestLocation();
      });
    }
  }

  void _goTo(int target) {
    if (target > _step) {
      for (var i = _step; i < target && i < _detailSteps; i++) {
        if (!_stepValid(i)) {
          _setStep(i);
          return;
        }
      }
    }
    _setStep(target);
  }

  void _next() => _goTo(_step + 1);

  void _back() {
    if (_step > 0) _setStep(_step - 1);
  }

  @override
  Widget build(BuildContext context) {
    ref.listen<Object?>(sellerFormActionProvider.select((s) => s.error), (prev, error) {
      if (error == null) return;
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(content: Text(error.toString())));
    });

    final action = ref.watch(sellerFormActionProvider); // SellerFormState
    final isBusy = action.isBusy;
    final isPending = widget.initial?.approvalStatus == 'PENDING';

    Step buildStep(int index, String title, Widget content) {
      return Step(
        title: Text(title, style: GoogleFonts.hind()),
        isActive: _step >= index,
        state: _step > index ? StepState.complete : StepState.indexed,
        content: content,
      );
    }

    return Stepper(
      type: StepperType.vertical,
      currentStep: _step,
      onStepTapped: isBusy ? null : _goTo,
      controlsBuilder: (context, details) => _controls(action, isBusy, isPending),
      steps: [
        buildStep(
          0,
          'Basic info',
          BasicInfoStep(
            formKey: _basicFormKey,
            displayName: _displayName,
            businessName: _businessName,
            bio: _bio,
          ),
        ),
        buildStep(
          1,
          'Seller type',
          SellerTypeStep(
            formKey: _typeFormKey,
            sellerType: _sellerType,
            onSellerTypeChanged: (v) => setState(() => _sellerType = v ?? _sellerType),
            isFssaiStatus: _isFassaiStatus,
            onFssaiStatusChanged: (v) => setState(() => _isFassaiStatus = v ?? _isFassaiStatus),
            fssaiCertificateId: _fassiCertificateID,
            deliveryRadius: _deliveryRadius,
            targetArea: _targetArea,
            socialMediaLinks: _socialMediaLinks,
            websiteUrl: _websiteUrl,
            legalCompliance: _legelCompliances,
          ),
        ),
        buildStep(
          2,
          'Address',
          AddressStep(
            formKey: _addressFormKey,
            isActive: _step == _addressStepIndex,
            selected: _selected,
            devicePoint: _devicePoint,
            hasLocationPermission: _hasLocationPermission,
            locating: _locating,
            permissionReady: _permissionReady,
            serviceDisabled: _serviceDisabled,
            permission: _permission,
            geocoding: _geocoding,
            locationError: _locationError,
            onMapCreated: (controller) {
              _map = controller;
              final devicePoint = _devicePoint;
              if (_selected == null && devicePoint != null) {
                _moveTo(devicePoint, zoom: 16);
              }
            },
            onMapTap: _selectPoint,
            onRequestLocation: _requestLocation,
            address: _address,
            city: _city,
            state: _state,
            country: _country,
            pincode: _pincode,
          ),
        ),
        buildStep(3, 'Photos', PhotosStep(sellerId: _sellerID)),
        buildStep(4, 'Documents', DocumentsStep(sellerId: _sellerID)),
        buildStep(5, 'Certificates (optional)', CertificatesStep(sellerId: _sellerID)),
      ],
    );
  }

  Widget _controls(SellerFormState action, bool isBusy, bool isPending) {
    final isLast = _step == _lastStep;
    final blocked = isBusy || _geocoding;
    final exists = widget.initial != null;
    final isDraft = !exists || widget.initial!.approvalStatus == 'DRAFT';

    return Padding(
      padding: const EdgeInsets.only(top: 16, bottom: 16),
      child: Wrap(
        alignment: WrapAlignment.end,
        crossAxisAlignment: WrapCrossAlignment.center,
        spacing: 12,
        runSpacing: 8,
        children: [
          if (_step > 0)
            TextButton(
              onPressed: isBusy ? null : _back,
              child: Text('Back', style: GoogleFonts.hind()),
            ),

          if (isDraft)
            _actionButton(
              label: 'Save',
              isLoading: action.isSaving, // spinner only while saving
              disabled: blocked || isPending,
              onPressed: _onSavePressed,
            ),
          if (!isLast)
            _actionButton(label: 'Next', isLoading: false, disabled: blocked, onPressed: _next),
          if (isLast && isDraft)
            _actionButton(
              label: isPending ? 'Pending approval' : 'Submit',
              isLoading: action.isSubmitting, // spinner only while submitting
              disabled: blocked || isPending,
              onPressed: _onSubmitPressed,
            ),
          if (isLast && widget.isEdit == true)
            _actionButton(
              label: 'Update',
              isLoading: action.isSubmitting,
              disabled: blocked || isPending,
              onPressed: _onUpdateSellerProfile,
            ),
        ],
      ),
    );
  }

  Widget _actionButton({
    required String label,
    required bool isLoading,
    required bool disabled,
    required VoidCallback onPressed,
  }) {
    return FilledButton(
      onPressed: disabled ? null : onPressed,
      child: isLoading
          ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2))
          : Text(label, style: GoogleFonts.hind()),
    );
  }
}
