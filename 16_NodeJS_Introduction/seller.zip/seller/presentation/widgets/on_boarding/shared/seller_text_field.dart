import 'package:flutter/material.dart';

class SellerTextField extends StatelessWidget {
  const SellerTextField(
    this.controller,
    this.label, {
    super.key,
    this.required = true,
    this.keyboardType,
    this.validator,
    this.maxLine = 1,
    this.prefixIcon,
    this.suffixIcon,
    this.onSuffixTap,
  });

  final TextEditingController controller;
  final String label;
  final bool required;
  final TextInputType? keyboardType;
  final String? Function(String?)? validator;
  final int? maxLine;

  final IconData? prefixIcon;
  final IconData? suffixIcon;
  final VoidCallback? onSuffixTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        maxLines: maxLine,
        textCapitalization: keyboardType == null
            ? TextCapitalization.words
            : TextCapitalization.none,
        validator:
            validator ??
            (v) {
              final value = (v ?? '').trim();

              if (required && value.isEmpty) {
                return 'Required';
              }

              if (keyboardType == TextInputType.number &&
                  value.isNotEmpty &&
                  double.tryParse(value) == null) {
                return 'Enter a valid number';
              }

              return null;
            },
        decoration: InputDecoration(
          labelText: label,

          // Show prefix icon only when provided.
          prefixIcon: prefixIcon != null ? Icon(prefixIcon) : null,

          // Show suffix icon only when provided.
          suffixIcon: suffixIcon != null
              ? IconButton(icon: Icon(suffixIcon), onPressed: onSuffixTap)
              : null,
        ),
      ),
    );
  }
}
