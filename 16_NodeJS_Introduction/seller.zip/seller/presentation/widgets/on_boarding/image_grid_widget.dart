import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:society_seva/features/seller/domain/entities/seller_image_entity.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';

class ImageGridWidget extends ConsumerStatefulWidget {
  const ImageGridWidget({super.key, this.sellerId});

  final String? sellerId; // null until the draft exists

  @override
  ConsumerState<ImageGridWidget> createState() => _ImageGridWidgetState();
}

class _ImageGridWidgetState extends ConsumerState<ImageGridWidget> {
  // Change these two together: 3 columns -> show 3 (one row), 4 columns -> show 4.
  static const _columns = 3;
  static const _collapsedCount = 3;

  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    final pending = ref.watch(
      sellerFormActionProvider.select((s) => s.queuedImages),
    );
    final isBusy = ref.watch(sellerFormActionProvider.select((s) => s.isBusy));
    final markedForDelete = ref.watch(
      sellerFormActionProvider.select((s) => s.pendingDeleteImageIds),
    );

    final id = widget.sellerId;
    if (id == null) {
      return _grid(
        uploaded: const [],
        pending: pending,
        isBusy: isBusy,
        markedForDelete: markedForDelete,
      );
    }

    final images = ref.watch(fetchSellerUploadedImagesProvider(id));

    return images.when(
      skipLoadingOnRefresh: true,
      loading: () => pending.isEmpty
          ? const Padding(
              padding: EdgeInsets.all(24),
              child: Center(child: CircularProgressIndicator()),
            )
          : _grid(
              uploaded: const [],
              pending: pending,
              isBusy: isBusy,
              markedForDelete: markedForDelete,
            ),
      error: (e, _) => Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8),
            child: Row(
              children: [
                const Expanded(child: Text('Could not load photos')),
                widget.sellerId != null && widget.sellerId != ''
                    ? TextButton(
                        onPressed: () => ref.invalidate(
                          fetchSellerUploadedImagesProvider(id),
                        ),
                        child: const Text('Retry'),
                      )
                    : SizedBox.shrink(),
              ],
            ),
          ),
          if (pending.isNotEmpty)
            _grid(
              uploaded: const [],
              pending: pending,
              isBusy: isBusy,
              markedForDelete: markedForDelete,
            ),
        ],
      ),

      data: (list) => _grid(
        uploaded: list ?? const [],
        pending: pending,
        isBusy: isBusy,
        markedForDelete: markedForDelete,
      ),
    );
  }

  Widget _grid({
    required List<SellerImageEntity> uploaded,
    required List<XFile> pending,
    required bool isBusy,
    required Set<String> markedForDelete,
  }) {
    final total = pending.length + uploaded.length;

    if (total == 0) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 16),
        child: Text('No photos yet'),
      );
    }

    final canExpand = total > _collapsedCount;
    final visibleCount = (_expanded || !canExpand) ? total : _collapsedCount;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: visibleCount,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: _columns,
            mainAxisSpacing: 8,
            crossAxisSpacing: 8,
          ),
          itemBuilder: (_, i) {
            // Pending images come first, then uploaded ones.
            if (i < pending.length) {
              return _pendingTile(pending[i], isBusy);
            }
            final image = uploaded[i - pending.length];
            return _uploadedTile(
              image,
              isBusy: isBusy,
              markedForDelete: markedForDelete.contains(image.id),
            );
          },
        ),
        if (canExpand)
          TextButton.icon(
            onPressed: () => setState(() => _expanded = !_expanded),
            icon: Icon(_expanded ? Icons.expand_less : Icons.expand_more),
            label: Text(_expanded ? 'Show less' : 'View all ($total)'),
          ),
      ],
    );
  }

  Widget _uploadedTile(
    SellerImageEntity image, {
    required bool isBusy,
    required bool markedForDelete,
  }) {
    final url = image.imageUrl;
    return Stack(
      key: ValueKey(image.id),
      fit: StackFit.expand,
      children: [
        GestureDetector(
          onTap: markedForDelete
              ? null // viewing a tile queued for delete isn't useful
              : () => showDialog(
                  context: context,
                  builder: (_) => Dialog(
                    child: InteractiveViewer(child: Image.network(url)),
                  ),
                ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: Opacity(
              opacity: markedForDelete ? 0.4 : 1,
              child: Image.network(
                url,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) =>
                    const Center(child: Icon(Icons.broken_image_outlined)),
              ),
            ),
          ),
        ),
        // "Marked for deletion" label
        if (markedForDelete)
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: ClipRRect(
              borderRadius: const BorderRadius.vertical(
                bottom: Radius.circular(16),
              ),
              child: Container(
                color: Colors.red.shade700,
                padding: const EdgeInsets.symmetric(vertical: 2),
                child: const Text(
                  'Marked for deletion',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white, fontSize: 11),
                ),
              ),
            ),
          ),
        // delete / undo button. The actual delete API call happens on the
        // next save/submit/update (see SellerFormActionNotifier._flushPendingUploads).
        Positioned(
          top: 4,
          right: 4,
          child: GestureDetector(
            onTap: isBusy
                ? null // can't change delete marks while an upload is running
                : () => markedForDelete
                      ? ref
                            .read(sellerFormActionProvider.notifier)
                            .unmarkImageForDelete(image.id)
                      : ref
                            .read(sellerFormActionProvider.notifier)
                            .markImageForDelete(image.id),
            child: CircleAvatar(
              radius: 12,
              backgroundColor: isBusy
                  ? Colors.grey
                  : (markedForDelete ? Colors.blueGrey : Colors.black87),
              child: Icon(
                markedForDelete ? Icons.undo : Icons.delete_outline,
                size: 14,
                color: Colors.white,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _pendingTile(XFile file, bool isBusy) {
    return Stack(
      key: ValueKey(file.path),
      fit: StackFit.expand,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: Image.file(File(file.path), fit: BoxFit.cover),
        ),
        // "Pending" label
        Positioned(
          left: 0,
          right: 0,
          bottom: 0,
          child: ClipRRect(
            borderRadius: const BorderRadius.vertical(
              bottom: Radius.circular(16),
            ),
            child: Container(
              color: Colors.black54,
              padding: const EdgeInsets.symmetric(vertical: 2),
              child: const Text(
                'Pending',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white, fontSize: 11),
              ),
            ),
          ),
        ),
        // remove button
        Positioned(
          top: 4,
          right: 4,
          child: GestureDetector(
            onTap: isBusy
                ? null // can't remove while an upload is running
                : () => ref
                      .read(sellerFormActionProvider.notifier)
                      .removePendingImage(file),
            child: CircleAvatar(
              radius: 12,
              backgroundColor: isBusy ? Colors.grey : Colors.black87,
              child: const Icon(Icons.close, size: 14, color: Colors.white),
            ),
          ),
        ),
      ],
    );
  }
}
