import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:image_picker/image_picker.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/image_grid_widget.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/image_source_sheet.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';

class PhotosStep extends ConsumerWidget {
  const PhotosStep({super.key, required this.sellerId});

  final String sellerId;

  static final _picker = ImagePicker();

  Future<void> _onAddPhotosPressed(BuildContext context, WidgetRef ref) async {
    final source = await chooseImageSource(context);
    if (source == null) return; // dismissed

    final notifier = ref.read(sellerFormActionProvider.notifier);
    if (source == ImageSource.camera) {
      final file = await _picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 80,
        maxWidth: 1600,
        preferredCameraDevice: CameraDevice.rear,
      );
      if (file == null) return; // user cancelled
      notifier.addPendingImage(file);
    } else {
      final files = await _picker.pickMultiImage(imageQuality: 80, maxWidth: 1600);
      if (files.isEmpty) return; // user cancelled
      for (final file in files) {
        notifier.addPendingImage(file);
      }
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Gap(8),
        Row(
          children: [
            const Expanded(
              child: Text('Photos', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
            ),
            Consumer(
              builder: (context, ref, _) {
                final isBusy = ref.watch(sellerFormActionProvider.select((s) => s.isBusy));
                final isUploading = ref.watch(
                  sellerFormActionProvider.select((s) => s.isUploadingImages),
                );
                return TextButton.icon(
                  onPressed: isBusy ? null : () => _onAddPhotosPressed(context, ref),
                  icon: isUploading
                      ? const SizedBox(
                          height: 16,
                          width: 16,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.add_photo_alternate_outlined),
                  label: const Text('Add photos'),
                );
              },
            ),
          ],
        ),
        if (sellerId == '')
          Text(
            'Save as draft to enable photo upload',
            style: Theme.of(context).textTheme.bodySmall,
          ),
        const Gap(28),
        ImageGridWidget(sellerId: sellerId),
        const Gap(8),
      ],
    );
  }
}
