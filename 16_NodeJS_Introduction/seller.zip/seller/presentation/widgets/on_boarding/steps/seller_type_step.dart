import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:society_seva/features/seller/domain/enum/seller_type_config.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/seller_text_field.dart';

class SellerTypeStep extends StatelessWidget {
  const SellerTypeStep({
    super.key,
    required this.formKey,
    required this.sellerType,
    required this.onSellerTypeChanged,
    required this.isFssaiStatus,
    required this.onFssaiStatusChanged,
    required this.fssaiCertificateId,
    required this.deliveryRadius,
    required this.targetArea,
    required this.socialMediaLinks,
    required this.websiteUrl,
    required this.legalCompliance,
  });

  final GlobalKey<FormState> formKey;
  final String sellerType;
  final ValueChanged<String?> onSellerTypeChanged;
  final bool isFssaiStatus;
  final ValueChanged<bool?> onFssaiStatusChanged;
  final TextEditingController fssaiCertificateId;
  final TextEditingController deliveryRadius;
  final TextEditingController targetArea;
  final TextEditingController socialMediaLinks;
  final TextEditingController websiteUrl;
  final TextEditingController legalCompliance;

  SellerTypeConfig get _cfg => sellerTypeConfigs[sellerType]!;

  String _label(String value) {
    final s = value.toLowerCase().replaceAll('_', ' ');
    return '${s[0].toUpperCase()}${s.substring(1)}';
  }

  @override
  Widget build(BuildContext context) {
    final c = _cfg;
    return Form(
      key: formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Gap(8),
          DropdownButtonFormField<String>(
            initialValue: sellerType,
            decoration: const InputDecoration(labelText: 'Seller Type'),
            items: sellerTypes
                .map(
                  (t) => DropdownMenuItem(
                    value: t,
                    child: Text(_label(t.replaceAll('_', ' ')), style: GoogleFonts.hind()),
                  ),
                )
                .toList(),
            onChanged: onSellerTypeChanged,
          ),
          const Gap(8),
          Text(c.description, style: Theme.of(context).textTheme.bodySmall),
          const Gap(20),
          if (c.fssai) ...[
            DropdownButtonFormField<bool>(
              initialValue: isFssaiStatus,
              decoration: const InputDecoration(labelText: 'FSSAI Required'),
              items: [
                DropdownMenuItem(value: true, child: Text('Yes', style: GoogleFonts.hind())),
                DropdownMenuItem(value: false, child: Text('No', style: GoogleFonts.hind())),
              ],
              onChanged: onFssaiStatusChanged,
            ),
            const Gap(20),
            if (isFssaiStatus) SellerTextField(fssaiCertificateId, 'Fssai Certificate Id'),
          ],
          if (c.delivery)
            SellerTextField(
              deliveryRadius,
              c.deliveryLabel,
              required: c.deliveryRequired,
              keyboardType: TextInputType.number,
            ),
          if (c.targetArea)
            SellerTextField(targetArea, c.targetAreaLabel, required: c.targetAreaRequired),
          if (c.social) SellerTextField(socialMediaLinks, 'Social Media Links', required: false),
          if (c.website) SellerTextField(websiteUrl, 'Website Url', required: false),
          if (c.legal)
            SellerTextField(legalCompliance, 'Legal Compliance', required: false, maxLine: 3),
        ],
      ),
    );
  }
}
