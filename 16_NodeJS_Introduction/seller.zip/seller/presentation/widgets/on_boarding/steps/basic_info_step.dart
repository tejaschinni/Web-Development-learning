import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/seller_text_field.dart';

class BasicInfoStep extends StatelessWidget {
  const BasicInfoStep({
    super.key,
    required this.formKey,
    required this.displayName,
    required this.businessName,
    required this.bio,
  });

  final GlobalKey<FormState> formKey;
  final TextEditingController displayName;
  final TextEditingController businessName;
  final TextEditingController bio;

  @override
  Widget build(BuildContext context) {
    return Form(
      key: formKey,
      child: Column(
        children: [
          const Gap(8),
          SellerTextField(displayName, 'Display Name'),
          SellerTextField(businessName, 'Business Name'),
          SellerTextField(bio, 'Bio', maxLine: 4),
        ],
      ),
    );
  }
}
