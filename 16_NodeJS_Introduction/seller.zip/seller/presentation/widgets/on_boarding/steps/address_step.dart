import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/seller_text_field.dart';

class AddressStep extends StatelessWidget {
  const AddressStep({
    super.key,
    required this.formKey,
    required this.isActive,
    required this.selected,
    required this.devicePoint,
    required this.hasLocationPermission,
    required this.locating,
    required this.permissionReady,
    required this.serviceDisabled,
    required this.permission,
    required this.geocoding,
    required this.locationError,
    required this.onMapCreated,
    required this.onMapTap,
    required this.onRequestLocation,
    required this.address,
    required this.city,
    required this.state,
    required this.country,
    required this.pincode,
  });

  static const _fallbackPoint = LatLng(20.5937, 78.9629);

  final GlobalKey<FormState> formKey;
  final bool isActive; // only build the map while this step is open (platform view)

  final LatLng? selected;
  final LatLng? devicePoint;
  final bool hasLocationPermission;
  final bool locating;
  final bool permissionReady;
  final bool serviceDisabled;
  final LocationPermission permission;
  final bool geocoding;
  final String? locationError;

  final void Function(GoogleMapController controller) onMapCreated;
  final void Function(LatLng point) onMapTap;
  final VoidCallback onRequestLocation;

  final TextEditingController address;
  final TextEditingController city;
  final TextEditingController state;
  final TextEditingController country;
  final TextEditingController pincode;

  String? _validatePinCode(String? value) {
    if (value == null || value.trim().isEmpty) return 'Required';
    if (!RegExp(r'^\d{4,10}$').hasMatch(value.trim())) return 'Enter a valid PIN code';
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final point = selected;
    final target = point ?? devicePoint ?? _fallbackPoint;
    final zoom = (point != null || devicePoint != null) ? 16.0 : 5.0;

    return Form(
      key: formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Gap(8),
          // Only build the map while this step is open (it's a platform view).
          if (isActive)
            SizedBox(
              height: 300,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Stack(
                  children: [
                    GoogleMap(
                      initialCameraPosition: CameraPosition(target: target, zoom: zoom),
                      gestureRecognizers: <Factory<OneSequenceGestureRecognizer>>{
                        Factory<OneSequenceGestureRecognizer>(() => EagerGestureRecognizer()),
                      },
                      myLocationEnabled: hasLocationPermission,
                      myLocationButtonEnabled: false,
                      zoomControlsEnabled: false,
                      mapToolbarEnabled: false,
                      markers: point == null
                          ? const {}
                          : {Marker(markerId: const MarkerId('seller-location'), position: point)},
                      onMapCreated: onMapCreated,
                      onTap: onMapTap,
                    ),
                    Positioned(
                      right: 12,
                      top: 12,
                      child: Material(
                        color: Theme.of(context).colorScheme.surface,
                        shape: const CircleBorder(),
                        child: IconButton(
                          tooltip: 'Use my current location',
                          onPressed: locating ? null : onRequestLocation,
                          icon: locating
                              ? const SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(strokeWidth: 2),
                                )
                              : const Icon(Icons.my_location),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          const Gap(8),
          Text(
            locationError ??
                (permissionReady && !hasLocationPermission
                    ? 'Location permission is off. You can still tap the map to choose your location.'
                    : point == null
                    ? 'Tap the map to choose your business location.'
                    : 'Location selected. Address details are filled from the map.'),
            style: GoogleFonts.hind(),
          ),
          if (serviceDisabled || (permissionReady && !hasLocationPermission))
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton.icon(
                onPressed: serviceDisabled
                    ? Geolocator.openLocationSettings
                    : permission == LocationPermission.deniedForever
                    ? Geolocator.openAppSettings
                    : onRequestLocation,
                icon: const Icon(Icons.location_searching),
                label: Text(
                  serviceDisabled
                      ? 'Open device location settings'
                      : permission == LocationPermission.deniedForever
                      ? 'Open app settings'
                      : 'Allow location access',
                ),
              ),
            ),
          if (geocoding) const LinearProgressIndicator(),
          const Gap(16),
          SellerTextField(address, 'Address'),
          SellerTextField(city, 'City'),
          SellerTextField(state, 'State'),
          SellerTextField(country, 'Country'),
          SellerTextField(
            pincode,
            'Pincode',
            keyboardType: TextInputType.number,
            validator: _validatePinCode,
          ),
        ],
      ),
    );
  }
}
