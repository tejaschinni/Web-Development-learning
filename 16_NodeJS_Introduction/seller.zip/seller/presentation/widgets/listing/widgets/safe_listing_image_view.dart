// lib/features/seller/presentation/widgets/listing/widgets/safe_listing_image_view.dart

import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:society_seva/app/theme/app_theme.dart';

class SafeListingImageView extends StatelessWidget {
  const SafeListingImageView.pending(
    this.xFile, {
    super.key,
    this.fit = BoxFit.cover,
    this.width,
    this.height,
  }) : remoteUrl = null;

  const SafeListingImageView.remote(
    this.remoteUrl, {
    super.key,
    this.fit = BoxFit.cover,
    this.width,
    this.height,
  }) : xFile = null;

  final XFile? xFile;
  final String? remoteUrl;
  final BoxFit fit;
  final double? width;
  final double? height;

  String _resolveUrl(String raw) {
    if (raw.startsWith('http://') || raw.startsWith('https://')) {
      return raw;
    }
    // Prepend default API base path if relative URL
    return 'http://192.168.1.42:8080/society_rest/api/v1/listings/images/$raw';
  }

  @override
  Widget build(BuildContext context) {
    if (remoteUrl != null && remoteUrl!.isNotEmpty) {
      final resolved = _resolveUrl(remoteUrl!);
      return Image.network(
        resolved,
        fit: fit,
        width: width,
        height: height,
        loadingBuilder: (context, child, loadingProgress) {
          if (loadingProgress == null) return child;
          return Container(
            width: width,
            height: height,
            color: const Color(0xFFF1F3F6),
            child: const Center(
              child: SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.green),
              ),
            ),
          );
        },
        errorBuilder: (context, error, stackTrace) => _buildPlaceholder(),
      );
    }

    if (xFile != null) {
      if (kIsWeb) {
        return FutureBuilder<Uint8List>(
          future: xFile!.readAsBytes(),
          builder: (context, snapshot) {
            if (snapshot.hasData && snapshot.data != null) {
              return Image.memory(
                snapshot.data!,
                fit: fit,
                width: width,
                height: height,
              );
            }
            if (snapshot.hasError) {
              return _buildPlaceholder();
            }
            return Container(
              width: width,
              height: height,
              color: const Color(0xFFF1F3F6),
              child: const Center(
                child: SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.green),
                ),
              ),
            );
          },
        );
      } else {
        return Image.file(
          File(xFile!.path),
          fit: fit,
          width: width,
          height: height,
          errorBuilder: (context, error, stackTrace) => _buildPlaceholder(),
        );
      }
    }

    return _buildPlaceholder();
  }

  Widget _buildPlaceholder() {
    return Container(
      width: width,
      height: height,
      color: const Color(0xFFF2F4F7),
      child: const Center(
        child: Icon(Icons.restaurant_rounded, color: AppColors.muted, size: 28),
      ),
    );
  }
}
