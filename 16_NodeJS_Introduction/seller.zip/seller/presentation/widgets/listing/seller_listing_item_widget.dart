import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/domain/entities/seller_listing_entity.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_listing_provider.dart';

enum _MenuAction { edit, toggle, outOfStock, delete }

class SellerListingItemWidget extends ConsumerWidget {
  final SellerListingEntity item;
  final ValueChanged<bool> onToggle;
  final VoidCallback onEdit;
  final VoidCallback onOutOfStock;
  final VoidCallback onDelete;
  final int viewsCount;

  const SellerListingItemWidget({
    super.key,
    required this.item,
    required this.onToggle,
    required this.onEdit,
    required this.onOutOfStock,
    required this.onDelete,
    this.viewsCount = 189,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final status = fromApi(item.availabilityStatus);
    final isActive = status == 'Published';

    // first approved image for this listing
    final imageUrl = ref
        .watch(sellerListingImagesProvider(item.id))
        .valueOrNull
        ?.where((image) => image.moderationStatus.toUpperCase() == 'APPROVED')
        .firstOrNull
        ?.imageUrl;

    final priceText = '\u20B9 ${_fmt(item.basePrice.toDouble())}';

    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFEAECF0)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x06000000),
            blurRadius: 6,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Thumbnail
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: _Thumb(url: imageUrl),
          ),
          const SizedBox(width: 12),

          // Details (Title, Price, Stock)
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 14.5,
                    fontWeight: FontWeight.w700,
                    color: AppColors.ink,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  priceText,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: AppColors.ink,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  'Stock: ${item.quantityAvailable}',
                  style: const TextStyle(fontSize: 12, color: AppColors.muted),
                ),
              ],
            ),
          ),

          // Right side (Status chip, 3 dots, Views)
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _StatusChip(status: status),
                  const SizedBox(width: 2),
                  PopupMenuButton<_MenuAction>(
                    padding: EdgeInsets.zero,
                    icon: const Icon(Icons.more_vert, color: AppColors.muted, size: 18),
                    onSelected: (a) {
                      switch (a) {
                        case _MenuAction.edit:
                          onEdit();
                        case _MenuAction.toggle:
                          onToggle(!isActive);
                        case _MenuAction.outOfStock:
                          onOutOfStock();
                        case _MenuAction.delete:
                          onDelete();
                      }
                    },
                    itemBuilder: (_) => [
                      const PopupMenuItem(value: _MenuAction.edit, child: Text('Edit')),
                      PopupMenuItem(
                        value: _MenuAction.toggle,
                        child: Text(isActive ? 'Pause' : 'Activate'),
                      ),
                      if (status != 'Out of Stock')
                        const PopupMenuItem(
                          value: _MenuAction.outOfStock,
                          child: Text('Mark out of stock'),
                        ),
                      const PopupMenuItem(value: _MenuAction.delete, child: Text('Delete')),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.visibility_outlined, size: 13, color: Color(0xFF475467)),
                  const SizedBox(width: 4),
                  Text(
                    'Views $viewsCount',
                    style: const TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      color: Color(0xFF475467),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _fmt(double v) => v == v.roundToDouble() ? v.toInt().toString() : v.toStringAsFixed(2);
}

String fromApi(String? value) {
  final v = (value ?? '').toLowerCase().replaceAll(RegExp(r'[\s_\-]'), '');
  switch (v) {
    case 'active':
    case 'available':
    case 'published':
      return 'Published';
    case 'paused':
    case 'inactive':
    case 'draft':
      return 'Draft';
    case 'outofstock':
    case 'soldout':
      return 'Out of Stock';
    default:
      return 'Published';
  }
}

class _StatusChip extends StatelessWidget {
  final String status;
  const _StatusChip({required this.status});

  @override
  Widget build(BuildContext context) {
    late final Color fg;
    late final Color bg;

    switch (status) {
      case 'Published':
        fg = const Color(0xFF027A48);
        bg = const Color(0xFFD1FADF);
        break;
      case 'Draft':
        fg = const Color(0xFFB54708);
        bg = const Color(0xFFFEF0C7);
        break;
      case 'Out of Stock':
      default:
        fg = const Color(0xFFD92D20);
        bg = const Color(0xFFFEE4E2);
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Text(
        status,
        style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: fg),
      ),
    );
  }
}

class _Thumb extends StatelessWidget {
  final String? url;
  const _Thumb({required this.url});

  @override
  Widget build(BuildContext context) {
    const fallback = SizedBox(
      width: 72,
      height: 72,
      child: DecoratedBox(
        decoration: BoxDecoration(color: Color(0xFFF2F4F7)),
        child: Icon(Icons.restaurant, color: AppColors.muted, size: 28),
      ),
    );

    if (url == null || url!.isEmpty) return fallback;
    final resolvedUrl = (url!.startsWith('http://') || url!.startsWith('https://'))
        ? url!
        : 'http://192.168.1.42:8080/society_rest/api/v1/listings/images/$url';
    return Image.network(
      resolvedUrl,
      width: 72,
      height: 72,
      fit: BoxFit.cover,
      errorBuilder: (context, error, stackTrace) => fallback,
    );
  }
}
