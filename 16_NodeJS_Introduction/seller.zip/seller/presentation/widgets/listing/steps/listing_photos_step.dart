// lib/features/seller/presentation/widgets/listing/steps/listing_photos_step.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_listing_provider.dart';
import 'package:society_seva/features/seller/presentation/widgets/listing/widgets/safe_listing_image_view.dart';

class ListingPhotosStep extends ConsumerStatefulWidget {
  const ListingPhotosStep({super.key});

  @override
  ConsumerState<ListingPhotosStep> createState() => _ListingPhotosStepState();
}

class _ListingPhotosStepState extends ConsumerState<ListingPhotosStep> {
  int _selectedPhotoIndex = 0;

  static const _samplePhotos = [
    {
      'label': '🍛 Veg Thali',
      'url': 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=800&auto=format&fit=crop&q=80',
    },
    {
      'label': '🍲 Kanda Poha',
      'url': 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=800&auto=format&fit=crop&q=80',
    },
    {
      'label': '🥟 Samosa & Snacks',
      'url': 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=800&auto=format&fit=crop&q=80',
    },
    {
      'label': '🍰 Fresh Cake',
      'url': 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=800&auto=format&fit=crop&q=80',
    },
    {
      'label': '🥘 Biryani Bowl',
      'url': 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?w=800&auto=format&fit=crop&q=80',
    },
  ];

  Future<void> _pick(BuildContext context, ImageSource source) async {
    final picker = ImagePicker();
    final List<XFile> files;
    if (source == ImageSource.gallery) {
      files = await picker.pickMultiImage(imageQuality: 85, maxWidth: 1600);
    } else {
      final f = await picker.pickImage(source: source, imageQuality: 85, maxWidth: 1600);
      files = f == null ? [] : [f];
    }
    if (files.isEmpty) return;
    final msg = await ref.read(productListingProvider.notifier).addPendingImages(files);
    if (msg != null && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
    }
  }

  void _chooseSource(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (sheetCtx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.photo_library_outlined, color: AppColors.green),
                title: Text('Choose from Gallery', style: AppTheme.hind(14, w: FontWeight.w600)),
                onTap: () {
                  Navigator.pop(sheetCtx);
                  _pick(context, ImageSource.gallery);
                },
              ),
              ListTile(
                leading: const Icon(Icons.photo_camera_outlined, color: AppColors.green),
                title: Text('Take a Photo', style: AppTheme.hind(14, w: FontWeight.w600)),
                onTap: () {
                  Navigator.pop(sheetCtx);
                  _pick(context, ImageSource.camera);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = ref.watch(productListingProvider);
    final n = ref.read(productListingProvider.notifier);
    final totalCount = s.totalImageCount;
    final atLimit = totalCount >= kMaxListingImages;

    // Clamp preview index
    if (_selectedPhotoIndex >= totalCount && totalCount > 0) {
      _selectedPhotoIndex = totalCount - 1;
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      children: [
        Text(
          'Product Photos',
          style: AppTheme.display(18, w: FontWeight.w700, c: AppColors.ink),
        ),
        const SizedBox(height: 4),
        Text(
          'Add clear photos of your product. The first photo will be your cover photo.',
          style: AppTheme.hind(12.5, c: AppColors.muted),
        ),
        const SizedBox(height: 16),

        // Header with count
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            RichText(
              text: const TextSpan(
                text: 'Photos ',
                style: TextStyle(
                  fontSize: 13.5,
                  fontWeight: FontWeight.w600,
                  color: AppColors.ink,
                ),
                children: [
                  TextSpan(
                    text: '*',
                    style: TextStyle(color: AppColors.red, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: totalCount > 0 ? AppColors.greenSoft : const Color(0xFFF1F3F6),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                '$totalCount/$kMaxListingImages',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: totalCount > 0 ? AppColors.green : AppColors.muted,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),

        // ── Horizontal Photo Reel ──
        SizedBox(
          height: 104,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: [
              // "+ Add Photo" dashed tile
              if (!atLimit)
                Padding(
                  padding: const EdgeInsets.only(right: 12),
                  child: InkWell(
                    onTap: s.isBusy ? null : () => _chooseSource(context),
                    borderRadius: BorderRadius.circular(12),
                    child: Container(
                      width: 96,
                      height: 96,
                      decoration: BoxDecoration(
                        color: const Color(0xFFF9FAFB),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: const Color(0xFF4A80F0),
                          width: 1.5,
                        ),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          Icon(Icons.add_photo_alternate_outlined, color: Color(0xFF4A80F0), size: 26),
                          SizedBox(height: 4),
                          Text(
                            '+ Add Photo',
                            style: TextStyle(
                              fontSize: 11.5,
                              fontWeight: FontWeight.w600,
                              color: Color(0xFF4A80F0),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

              // Remote images
              for (var i = 0; i < s.visibleRemoteImages.length; i++) ...[
                Padding(
                  padding: const EdgeInsets.only(right: 12),
                  child: _HorizontalPhotoCard(
                    isSelected: _selectedPhotoIndex == i,
                    isCover: i == 0,
                    onTap: () => setState(() => _selectedPhotoIndex = i),
                    image: SafeListingImageView.remote(
                      s.visibleRemoteImages[i].imageUrl,
                      fit: BoxFit.cover,
                    ),
                    onRemove: () {
                      n.markRemoteForDelete(s.visibleRemoteImages[i].id);
                      if (_selectedPhotoIndex >= totalCount - 1 && _selectedPhotoIndex > 0) {
                        setState(() => _selectedPhotoIndex--);
                      }
                    },
                  ),
                ),
              ],

              // Pending local files
              for (var j = 0; j < s.pendingImages.length; j++) ...[
                Padding(
                  padding: const EdgeInsets.only(right: 12),
                  child: _HorizontalPhotoCard(
                    isSelected: _selectedPhotoIndex == (s.visibleRemoteImages.length + j),
                    isCover: (s.visibleRemoteImages.length + j) == 0,
                    onTap: () => setState(() => _selectedPhotoIndex = s.visibleRemoteImages.length + j),
                    image: SafeListingImageView.pending(
                      s.pendingImages[j],
                      fit: BoxFit.cover,
                    ),
                    onRemove: () {
                      n.removePendingImage(s.pendingImages[j]);
                      if (_selectedPhotoIndex >= totalCount - 1 && _selectedPhotoIndex > 0) {
                        setState(() => _selectedPhotoIndex--);
                      }
                    },
                  ),
                ),
              ],
            ],
          ),
        ),
        const SizedBox(height: 20),

        // ── Main Preview Area (Large Image or Upload Dropzone) ──
        if (totalCount > 0) ...[
          Container(
            height: 220,
            width: double.infinity,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.border),
              color: const Color(0xFFF8FAF9),
            ),
            child: Stack(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: SizedBox(
                    width: double.infinity,
                    height: double.infinity,
                    child: _buildLargePreview(s, _selectedPhotoIndex),
                  ),
                ),
                // Badge: Cover Photo / Photo X
                Positioned(
                  top: 10,
                  left: 10,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: _selectedPhotoIndex == 0
                          ? AppColors.green
                          : Colors.black.withValues(alpha: 0.65),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (_selectedPhotoIndex == 0) ...[
                          const Icon(Icons.star, size: 12, color: Colors.white),
                          const SizedBox(width: 4),
                        ],
                        Text(
                          _selectedPhotoIndex == 0 ? 'Cover Photo' : 'Photo ${_selectedPhotoIndex + 1} of $totalCount',
                          style: const TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                // Make Cover button if selected is not index 0
                if (_selectedPhotoIndex != 0)
                  Positioned(
                    bottom: 10,
                    right: 10,
                    child: ElevatedButton.icon(
                      onPressed: () {
                        n.setAsCoverPhoto(_selectedPhotoIndex);
                        setState(() => _selectedPhotoIndex = 0);
                      },
                      icon: const Icon(Icons.star_border, size: 14, color: AppColors.ink),
                      label: const Text('Set as Cover', style: TextStyle(fontSize: 11.5, color: AppColors.ink, fontWeight: FontWeight.w700)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 16),
        ] else ...[
          // Empty state: Upload Hero Dropzone
          InkWell(
            onTap: () => _chooseSource(context),
            borderRadius: BorderRadius.circular(14),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 16),
              decoration: BoxDecoration(
                color: const Color(0xFFF9FAFB),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: const Color(0xFF4A80F0).withValues(alpha: 0.5),
                  width: 1.5,
                ),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      color: const Color(0xFF4A80F0).withValues(alpha: 0.1),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.cloud_upload_outlined,
                      color: Color(0xFF4A80F0),
                      size: 30,
                    ),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Upload Product Photos',
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      color: AppColors.ink,
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'Tap here to browse from gallery or take a picture',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 12, color: AppColors.muted),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      OutlinedButton.icon(
                        onPressed: () => _pick(context, ImageSource.gallery),
                        icon: const Icon(Icons.photo_library_outlined, size: 16, color: Color(0xFF4A80F0)),
                        label: const Text('Gallery', style: TextStyle(fontSize: 12.5, color: Color(0xFF4A80F0), fontWeight: FontWeight.w600)),
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: Color(0xFF4A80F0)),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                        ),
                      ),
                      const SizedBox(width: 12),
                      OutlinedButton.icon(
                        onPressed: () => _pick(context, ImageSource.camera),
                        icon: const Icon(Icons.photo_camera_outlined, size: 16, color: Color(0xFF4A80F0)),
                        label: const Text('Camera', style: TextStyle(fontSize: 12.5, color: Color(0xFF4A80F0), fontWeight: FontWeight.w600)),
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: Color(0xFF4A80F0)),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
        ],

        // ── Quick-Add Sample Food Photos ──
        if (!atLimit) ...[
          Row(
            children: const [
              Icon(Icons.auto_awesome, size: 15, color: AppColors.orange),
              SizedBox(width: 6),
              Text(
                'Or choose a sample photo:',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: AppColors.ink,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _samplePhotos.map((sample) {
              return ActionChip(
                backgroundColor: Colors.white,
                side: const BorderSide(color: Color(0xFFE4E7EC)),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                labelPadding: const EdgeInsets.symmetric(horizontal: 4),
                avatar: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Image.network(
                    sample['url']!,
                    width: 20,
                    height: 20,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) =>
                        const Icon(Icons.fastfood, size: 14, color: AppColors.green),
                  ),
                ),
                label: Text(
                  sample['label']!,
                  style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: AppColors.ink),
                ),
                onPressed: () {
                  n.addSampleImageUrl(sample['url']!);
                  setState(() => _selectedPhotoIndex = totalCount);
                },
              );
            }).toList(),
          ),
          const SizedBox(height: 20),
        ],

        // Information banner
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFFF4F7FB),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: const Color(0xFFE2E8F0)),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Icon(
                Icons.info_outline_rounded,
                color: Color(0xFF4A80F0),
                size: 18,
              ),
              SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Use clear, well-lit photos for higher order conversion.\nRecommended: 1080 x 1080 px (Square JPG/PNG up to 5 MB)',
                  style: TextStyle(
                    fontSize: 11.5,
                    color: Color(0xFF475569),
                    height: 1.35,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildLargePreview(ListingFormState s, int index) {
    if (index < s.visibleRemoteImages.length) {
      return SafeListingImageView.remote(
        s.visibleRemoteImages[index].imageUrl,
        fit: BoxFit.cover,
      );
    }
    final pendingIdx = index - s.visibleRemoteImages.length;
    if (pendingIdx < s.pendingImages.length) {
      return SafeListingImageView.pending(
        s.pendingImages[pendingIdx],
        fit: BoxFit.cover,
      );
    }
    return const Center(child: Icon(Icons.broken_image, color: AppColors.muted));
  }
}

class _HorizontalPhotoCard extends StatelessWidget {
  const _HorizontalPhotoCard({
    required this.image,
    required this.onRemove,
    required this.isSelected,
    required this.isCover,
    required this.onTap,
  });

  final Widget image;
  final VoidCallback onRemove;
  final bool isSelected;
  final bool isCover;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            width: 96,
            height: 96,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: isSelected ? AppColors.green : AppColors.border,
                width: isSelected ? 2.5 : 1.0,
              ),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: image,
            ),
          ),
          // Cover pill badge
          if (isCover)
            Positioned(
              bottom: 6,
              left: 6,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: AppColors.green,
                  borderRadius: BorderRadius.circular(4),
                ),
                child: const Text(
                  'Cover',
                  style: TextStyle(fontSize: 9, fontWeight: FontWeight.w700, color: Colors.white),
                ),
              ),
            ),
          // Delete icon
          Positioned(
            top: 4,
            right: 4,
            child: InkWell(
              onTap: onRemove,
              child: Container(
                width: 22,
                height: 22,
                decoration: const BoxDecoration(
                  color: Color(0xFF1E293B),
                  shape: BoxShape.circle,
                ),
                child: const Center(
                  child: Icon(Icons.close, size: 13, color: Colors.white),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
