// lib/features/seller/presentation/widgets/listing/steps/listing_additional_info_step.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_listing_provider.dart';

class ListingAdditionalInfoStep extends ConsumerStatefulWidget {
  const ListingAdditionalInfoStep({super.key});

  @override
  ConsumerState<ListingAdditionalInfoStep> createState() => _ListingAdditionalInfoStepState();
}

class _ListingAdditionalInfoStepState extends ConsumerState<ListingAdditionalInfoStep> {
  final TextEditingController _tagController = TextEditingController();

  @override
  void dispose() {
    _tagController.dispose();
    super.dispose();
  }

  void _addTag() {
    final text = _tagController.text.trim();
    if (text.isNotEmpty) {
      ref.read(productListingProvider.notifier).addTag(text);
      _tagController.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = ref.watch(productListingProvider);
    final n = ref.read(productListingProvider.notifier);
    final c = n.controllers;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      children: [
        Text(
          'Additional Information',
          style: AppTheme.display(18, w: FontWeight.w700, c: AppColors.ink),
        ),
        const SizedBox(height: 16),

        // 1. Food Specific Information
        const Text(
          'Food Specific Information',
          style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.ink),
        ),
        const SizedBox(height: 8),

        _buildCheckboxRow('Contains Onion', s.containsOnion, n.setContainsOnion),
        _buildCheckboxRow('Contains Garlic', s.containsGarlic, n.setContainsGarlic),
        _buildCheckboxRow('Jain Food Available', s.isJainFood, n.setIsJainFood),
        _buildCheckboxRow('Gluten Free', s.isGlutenFree, n.setIsGlutenFree),
        _buildCheckboxRow('Other (please specify)', s.isOtherDietary, n.setIsOtherDietary),

        const SizedBox(height: 8),
        TextField(
          controller: c.otherDietaryNote,
          style: const TextStyle(fontSize: 13, color: AppColors.ink),
          decoration: InputDecoration(
            hintText: 'e.g. No dairy, no nuts, etc.',
            hintStyle: const TextStyle(color: AppColors.muted, fontSize: 13),
            filled: true,
            fillColor: Colors.white,
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: AppColors.border),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: AppColors.green, width: 1.5),
            ),
          ),
        ),
        const SizedBox(height: 20),

        // 2. Tags (Search keywords)
        const Text(
          'Tags (Search keywords)',
          style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.ink),
        ),
        const SizedBox(height: 8),

        if (s.tags.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Wrap(
              spacing: 8,
              runSpacing: 6,
              children: s.tags.map((tag) {
                return Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: const Color(0xFFEFF8FF),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFFB2DDFF)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        tag,
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                          color: Color(0xFF175CD3),
                        ),
                      ),
                      const SizedBox(width: 4),
                      InkWell(
                        onTap: () => n.removeTag(tag),
                        child: const Icon(Icons.close, size: 14, color: Color(0xFF175CD3)),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
          ),

        TextField(
          controller: _tagController,
          onSubmitted: (_) => _addTag(),
          style: const TextStyle(fontSize: 13, color: AppColors.ink),
          decoration: InputDecoration(
            hintText: 'Add tag',
            hintStyle: const TextStyle(color: AppColors.muted, fontSize: 13),
            suffixIcon: IconButton(
              icon: const Icon(Icons.add, color: AppColors.green),
              onPressed: _addTag,
            ),
            filled: true,
            fillColor: Colors.white,
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: AppColors.border),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: AppColors.green, width: 1.5),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildCheckboxRow(String label, bool value, ValueChanged<bool> onChanged) {
    return InkWell(
      onTap: () => onChanged(!value),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          children: [
            SizedBox(
              width: 24,
              height: 24,
              child: Checkbox(
                value: value,
                activeColor: AppColors.green,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                onChanged: (v) => onChanged(v ?? false),
              ),
            ),
            const SizedBox(width: 10),
            Text(
              label,
              style: const TextStyle(fontSize: 13, color: AppColors.ink, fontWeight: FontWeight.w500),
            ),
          ],
        ),
      ),
    );
  }
}
