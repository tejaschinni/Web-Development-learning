import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_category_provider.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_listing_provider.dart';
import 'package:society_seva/features/shop/data/models/shop_category_model.dart';
import 'package:society_seva/features/shop/domain/enums/shop_category_type.dart';

class SelectCatgeoryStep extends ConsumerStatefulWidget {
  const SelectCatgeoryStep({super.key});

  @override
  ConsumerState<SelectCatgeoryStep> createState() => _SelectCatgeoryStepState();
}

class _SelectCatgeoryStepState extends ConsumerState<SelectCatgeoryStep> {
  final TextEditingController _categorySearchController = TextEditingController();
  final TextEditingController _subcategorySearchController = TextEditingController();
  String _categorySearchQuery = '';
  String _subcategorySearchQuery = '';

  @override
  void dispose() {
    _categorySearchController.dispose();
    _subcategorySearchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final listing = ref.watch(productListingProvider);
    final notifier = ref.read(productListingProvider.notifier);
    final categoryTreeAsync = ref.watch(sellerCategorytreeProvier);

    return categoryTreeAsync.when(
      loading: () => const Padding(
        padding: EdgeInsets.symmetric(vertical: 60),
        child: Center(
          child: CircularProgressIndicator(color: AppColors.green),
        ),
      ),
      error: (e, _) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline_rounded, size: 48, color: AppColors.red),
            const SizedBox(height: 12),
            Text(
              'Failed to load categories',
              style: AppTheme.display(16, w: FontWeight.w600, c: AppColors.ink),
            ),
            const SizedBox(height: 6),
            Text(
              e.toString(),
              textAlign: TextAlign.center,
              style: AppTheme.hind(12, c: AppColors.muted),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () => ref.invalidate(sellerCategorytreeProvier),
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.green),
              child: const Text('Retry', style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
      data: (categories) {
        if (categories.isEmpty) {
          return const Center(child: Text('No categories found.'));
        }

        // Identify current selected main category
        ShopCategoryModel? currentSelectedCategory = listing.selectedMainCategory;
        if (currentSelectedCategory == null && listing.mainCategoryId != null) {
          try {
            currentSelectedCategory = categories.firstWhere(
              (c) => c.id == listing.mainCategoryId,
            );
          } catch (_) {}
        }
        // Default MUST be Food category as requested
        if (currentSelectedCategory == null) {
          try {
            currentSelectedCategory = categories.firstWhere(
              (c) => c.name.toLowerCase().contains('food') || c.categoryType == ShopCategoryType.food,
            );
          } catch (_) {
            currentSelectedCategory = categories.first;
          }
          // Immediately select in notifier so main category is selected without requiring a click
          final defaultCat = currentSelectedCategory;
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted && listing.selectedMainCategory == null) {
              notifier.selectMainCategoryModel(defaultCat);
            }
          });
        }

        return ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          children: [
            // Header
            Text(
              'Create New Listing',
              style: AppTheme.display(20, w: FontWeight.w800, c: AppColors.ink),
            ),
            const SizedBox(height: 4),
            Text(
              'Select the category for your listing',
              style: AppTheme.hind(13, c: AppColors.muted),
            ),
            const SizedBox(height: 16),

            // Searchable Category Dropdown / Selector Bar
            _buildSearchableCategoryDropdown(categories, currentSelectedCategory, notifier),
            const SizedBox(height: 16),

            // Main Category Cards
            _buildMainCategoryCards(categories, currentSelectedCategory, notifier),
            const SizedBox(height: 24),

            // Subcategories Section for Selected Category
            _buildSubcategoriesSection(currentSelectedCategory, listing, notifier),
          ],
        );
      },
    );
  }

  /// Searchable Dropdown for scalable selection across dozens/hundreds of categories
  Widget _buildSearchableCategoryDropdown(
    List<ShopCategoryModel> allCategories,
    ShopCategoryModel? currentSelected,
    ListingFormNotifier notifier,
  ) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAF9),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      child: Row(
        children: [
          const Icon(Icons.search, size: 20, color: AppColors.muted),
          const SizedBox(width: 8),
          Expanded(
            child: TextField(
              controller: _categorySearchController,
              decoration: const InputDecoration(
                hintText: 'Search main category (e.g. Food, Art, Services)...',
                hintStyle: TextStyle(fontSize: 13, color: AppColors.muted),
                border: InputBorder.none,
                isDense: true,
                contentPadding: EdgeInsets.symmetric(vertical: 8),
              ),
              onChanged: (val) {
                setState(() => _categorySearchQuery = val.trim().toLowerCase());
              },
            ),
          ),
          if (_categorySearchQuery.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.clear, size: 18, color: AppColors.muted),
              onPressed: () {
                _categorySearchController.clear();
                setState(() => _categorySearchQuery = '');
              },
            ),
        ],
      ),
    );
  }

  /// Visual Category Selection Cards (matching Screen 2 in screenshots: Food, Art & Creative, etc.)
  Widget _buildMainCategoryCards(
    List<ShopCategoryModel> allCategories,
    ShopCategoryModel? selectedCategory,
    ListingFormNotifier notifier,
  ) {
    final filtered = _categorySearchQuery.isEmpty
        ? allCategories
        : allCategories
            .where((c) =>
                c.name.toLowerCase().contains(_categorySearchQuery) ||
                c.slug.toLowerCase().contains(_categorySearchQuery))
            .toList();

    if (filtered.isEmpty) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 16),
        child: Center(
          child: Text(
            'No matching categories found.',
            style: AppTheme.hind(13, c: AppColors.muted),
          ),
        ),
      );
    }

    return Column(
      children: filtered.map((category) {
        final isSelected = selectedCategory?.id == category.id;
        final iconData = _getCategoryIcon(category.name);
        final subtitle = _getCategorySubtitle(category.name);
        final color = _getCategoryAccentColor(category.name);

        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: InkWell(
            onTap: () {
              notifier.selectMainCategoryModel(category);
              setState(() {
                _subcategorySearchQuery = '';
                _subcategorySearchController.clear();
              });
            },
            borderRadius: BorderRadius.circular(16),
            child: Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: isSelected ? const Color(0xFFF3FBF5) : Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: isSelected ? AppColors.green : AppColors.border,
                  width: isSelected ? 1.8 : 1.0,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.02),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    width: 54,
                    height: 54,
                    decoration: BoxDecoration(
                      color: color.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Center(
                      child: Icon(iconData, color: color, size: 28),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          category.name,
                          style: AppTheme.display(
                            15,
                            w: FontWeight.w700,
                            c: isSelected ? AppColors.greenDeep : AppColors.ink,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          subtitle,
                          style: AppTheme.hind(12, c: AppColors.muted, h: 1.25),
                        ),
                      ],
                    ),
                  ),
                  Icon(
                    isSelected ? Icons.check_circle_rounded : Icons.arrow_forward_ios_rounded,
                    size: isSelected ? 22 : 16,
                    color: isSelected ? AppColors.green : AppColors.muted,
                  ),
                ],
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  /// Subcategory Multi-Select section matching Screen 3 with searchable filter
  Widget _buildSubcategoriesSection(
    ShopCategoryModel category,
    ListingFormState listing,
    ListingFormNotifier notifier,
  ) {
    final subcategories = category.subCategories;

    if (subcategories.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: const Color(0xFFF9FAFB),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            const Icon(Icons.info_outline_rounded, color: AppColors.green, size: 20),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                'No additional subcategories needed for ${category.name}. You can proceed to next step.',
                style: AppTheme.hind(13, c: AppColors.ink),
              ),
            ),
          ],
        ),
      );
    }

    final filteredSubs = _subcategorySearchQuery.isEmpty
        ? subcategories
        : subcategories
            .where((s) => s.name.toLowerCase().contains(_subcategorySearchQuery))
            .toList();

    final selectedCount = listing.additionalCategoryIds.length;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Select ${category.name} Subcategory',
              style: AppTheme.display(16, w: FontWeight.w800, c: AppColors.ink),
            ),
            if (selectedCount > 0)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: AppColors.greenSoft,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  '$selectedCount Selected',
                  style: AppTheme.hind(11, w: FontWeight.w700, c: AppColors.green),
                ),
              ),
          ],
        ),
        const SizedBox(height: 4),
        Text(
          'Select subcategories (Optional - you can leave this empty and continue)',
          style: AppTheme.hind(12, c: AppColors.muted),
        ),
        const SizedBox(height: 12),

        // Subcategory Search Bar
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
          child: Row(
            children: [
              const Icon(Icons.search, size: 18, color: AppColors.muted),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  controller: _subcategorySearchController,
                  decoration: InputDecoration(
                    hintText: 'Search ${category.name.toLowerCase()} subcategories...',
                    hintStyle: const TextStyle(fontSize: 13, color: AppColors.muted),
                    border: InputBorder.none,
                    isDense: true,
                    contentPadding: const EdgeInsets.symmetric(vertical: 8),
                  ),
                  onChanged: (val) {
                    setState(() => _subcategorySearchQuery = val.trim().toLowerCase());
                  },
                ),
              ),
              if (_subcategorySearchQuery.isNotEmpty)
                IconButton(
                  icon: const Icon(Icons.clear, size: 16, color: AppColors.muted),
                  onPressed: () {
                    _subcategorySearchController.clear();
                    setState(() => _subcategorySearchQuery = '');
                  },
                ),
            ],
          ),
        ),
        const SizedBox(height: 12),

        // Active Selected Tags summary
        if (listing.additionalCategoryIds.isNotEmpty) ...[
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: listing.additionalCategoryIds.map((id) {
              final subItem = subcategories.firstWhere(
                (s) => s.id == id,
                orElse: () => ShopCategoryModel(
                  id: id,
                  name: id,
                  slug: id,
                  categoryType: category.categoryType,
                  requiresCertificate: false,
                  isActive: true,
                  displayOrder: 0,
                  subCategories: const [],
                ),
              );

              return Chip(
                label: Text(subItem.name, style: AppTheme.hind(12, c: AppColors.greenDeep)),
                backgroundColor: AppColors.greenSoft,
                deleteIcon: const Icon(Icons.close, size: 14, color: AppColors.green),
                onDeleted: () => notifier.toggleSubcategory(id),
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 0),
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                side: BorderSide(color: AppColors.green.withValues(alpha: 0.3)),
              );
            }).toList(),
          ),
          const SizedBox(height: 12),
        ],

        // Subcategory Multi-select list
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: AppColors.border),
          ),
          child: ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: filteredSubs.length,
            separatorBuilder: (context, index) => const Divider(height: 1, color: AppColors.border),
            itemBuilder: (context, index) {
              final sub = filteredSubs[index];
              final isSelected = listing.additionalCategoryIds.contains(sub.id) ||
                  listing.subcategoryId == sub.id;

              return InkWell(
                onTap: () => notifier.toggleSubcategory(sub.id),
                borderRadius: BorderRadius.circular(14),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  child: Row(
                    children: [
                      // Subcategory Thumbnail Icon
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: const Color(0xFFF4F7F5),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Center(
                          child: Icon(
                            _getSubcategoryIcon(sub.name),
                            size: 22,
                            color: AppColors.green,
                          ),
                        ),
                      ),
                      const SizedBox(width: 14),
                      // Subcategory Name
                      Expanded(
                        child: Text(
                          sub.name,
                          style: AppTheme.hind(
                            14,
                            w: isSelected ? FontWeight.w600 : FontWeight.w500,
                            c: isSelected ? AppColors.greenDeep : AppColors.ink,
                          ),
                        ),
                      ),
                      // Multi-select Round Checkbox matching screenshot
                      Container(
                        width: 22,
                        height: 22,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: isSelected ? AppColors.green : Colors.transparent,
                          border: Border.all(
                            color: isSelected ? AppColors.green : const Color(0xFFC4CBD3),
                            width: 1.6,
                          ),
                        ),
                        child: isSelected
                            ? const Center(
                                child: Icon(Icons.check, size: 14, color: Colors.white),
                              )
                            : null,
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  IconData _getCategoryIcon(String name) {
    final lower = name.toLowerCase();
    if (lower.contains('food')) return Icons.restaurant_menu_rounded;
    if (lower.contains('art') || lower.contains('creative')) return Icons.palette_rounded;
    if (lower.contains('service')) return Icons.handyman_rounded;
    if (lower.contains('grocery')) return Icons.local_grocery_store_rounded;
    return Icons.category_rounded;
  }

  String _getCategorySubtitle(String name) {
    final lower = name.toLowerCase();
    if (lower.contains('food')) {
      return 'Homemade meals, snacks, cakes, pickles and more';
    }
    if (lower.contains('art') || lower.contains('creative')) {
      return 'Handmade gifts, artwork, jewellery, decor and workshops';
    }
    if (lower.contains('service')) {
      return 'Tutoring, repairs, beauty & personal care, events';
    }
    if (lower.contains('grocery')) {
      return 'Fresh farm produce, spices, grains and organic staples';
    }
    return 'Browse and list items in this category';
  }

  Color _getCategoryAccentColor(String name) {
    final lower = name.toLowerCase();
    if (lower.contains('food')) return const Color(0xFFE28B14);
    if (lower.contains('art') || lower.contains('creative')) return const Color(0xFF8B3FD8);
    if (lower.contains('service')) return AppColors.blue;
    return AppColors.green;
  }

  IconData _getSubcategoryIcon(String name) {
    final lower = name.toLowerCase();
    if (lower.contains('meal') || lower.contains('tiffin')) return Icons.lunch_dining_rounded;
    if (lower.contains('snack') || lower.contains('namkeen')) return Icons.bakery_dining_rounded;
    if (lower.contains('cake') || lower.contains('bakery')) return Icons.cake_rounded;
    if (lower.contains('sweet') || lower.contains('dessert')) return Icons.icecream_rounded;
    if (lower.contains('pickle') || lower.contains('chutney')) return Icons.kitchen_rounded;
    if (lower.contains('festival')) return Icons.celebration_rounded;
    if (lower.contains('catering')) return Icons.food_bank_rounded;
    if (lower.contains('gift') || lower.contains('craft')) return Icons.card_giftcard_rounded;
    if (lower.contains('artwork') || lower.contains('paint')) return Icons.brush_rounded;
    if (lower.contains('jewel')) return Icons.diamond_rounded;
    if (lower.contains('decor')) return Icons.home_rounded;
    if (lower.contains('tutor')) return Icons.school_rounded;
    if (lower.contains('repair')) return Icons.build_rounded;
    if (lower.contains('beauty') || lower.contains('salon')) return Icons.spa_rounded;
    return Icons.check_circle_outline_rounded;
  }
}
