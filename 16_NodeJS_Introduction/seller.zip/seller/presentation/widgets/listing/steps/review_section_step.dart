// lib/features/seller/presentation/widgets/listing/steps/review_section_step.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_category_provider.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_listing_provider.dart';
import 'package:society_seva/features/seller/presentation/widgets/listing/widgets/safe_listing_image_view.dart';

class ListingReviewStep extends ConsumerWidget {
  const ListingReviewStep({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(productListingProvider);
    final n = ref.read(productListingProvider.notifier);
    final c = n.controllers;

    final categories = ref.watch(sellerCategorytreeProvier).valueOrNull ?? [];
    String categoryName = s.mainCategoryName ?? 'Food';
    String subcategoryName = 'Homemade meals and tiffin';

    if (s.selectedMainCategory != null) {
      categoryName = s.selectedMainCategory!.name;
      final sub = s.selectedMainCategory!.subCategories
          .where((sub) => sub.id == s.subcategoryId || s.additionalCategoryIds.contains(sub.id))
          .map((sub) => sub.name)
          .join(', ');
      if (sub.isNotEmpty) subcategoryName = sub;
    } else if (categories.isNotEmpty) {
      categoryName = categories.first.name;
      if (categories.first.subCategories.isNotEmpty) {
        subcategoryName = categories.first.subCategories.first.name;
      }
    }

    final title = c.title.text.trim().isNotEmpty ? c.title.text.trim() : 'Homemade Veg Thali';
    final shortDesc = c.shortDescription.text.trim().isNotEmpty
        ? c.shortDescription.text.trim()
        : (c.detailedDescription.text.trim().isNotEmpty
            ? c.detailedDescription.text.trim()
            : 'Fresh homemade delicious food prepared with authentic spices.');
    final price = c.basePrice.text.trim().isNotEmpty ? c.basePrice.text.trim() : '120';
    final stock = c.quantity.text.trim().isNotEmpty ? c.quantity.text.trim() : '10';

    final orderTypes = <String>[
      if (s.isImmediateOrder) 'Immediate',
      if (s.isPreOrder) 'Pre-order',
    ];
    final orderTypeText = orderTypes.isEmpty ? 'Immediate + Pre-order' : orderTypes.join(' + ');

    final daysText = s.availableDays.isEmpty
        ? 'All days'
        : s.availableDays.join(', ');

    final foodAttrs = <String>[
      if (s.containsOnion) 'Contains Onion',
      if (s.containsGarlic) 'Contains Garlic',
      if (s.isJainFood) 'Jain Available',
      if (s.isGlutenFree) 'Gluten Free',
    ];

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      children: [
        Text(
          'Review Your Listing',
          style: AppTheme.display(18, w: FontWeight.w700, c: AppColors.ink),
        ),
        const SizedBox(height: 14),

        // 1. Preview Card
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border),
            boxShadow: const [
              BoxShadow(
                color: Color(0x08000000),
                blurRadius: 8,
                offset: Offset(0, 2),
              ),
            ],
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: _buildThumbnail(s),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: AppColors.ink,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      '$categoryName > $subcategoryName',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 11, color: AppColors.muted),
                    ),
                    const SizedBox(height: 6),
                    _buildDietaryBadge(s.dietaryType),
                    const SizedBox(height: 6),
                    Text(
                      shortDesc,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 11.5, color: Color(0xFF4A5568)),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),

        // 2. Structured Table of Details
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border),
          ),
          child: Column(
            children: [
              _buildDetailRow('Price', '₹ $price', isFirst: true),
              _buildDetailRow('Stock', stock),
              _buildDetailRow('Order Type', orderTypeText),
              _buildDetailRow('Preparation Time', s.prepTimeMinutes),
              _buildDetailRow('Available Days', daysText),
              _buildDetailRow('Available Time', '${s.timeSlotStart} - ${s.timeSlotEnd}'),
              if (foodAttrs.isNotEmpty)
                _buildDetailRow('Food Details', foodAttrs.join(', ')),
              if (s.tags.isNotEmpty)
                _buildDetailRow('Tags', s.tags.join(', '), isLast: true),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildThumbnail(ListingFormState s) {
    if (s.visibleRemoteImages.isNotEmpty) {
      return SafeListingImageView.remote(
        s.visibleRemoteImages.first.imageUrl,
        width: 80,
        height: 80,
        fit: BoxFit.cover,
      );
    }
    if (s.pendingImages.isNotEmpty) {
      return SafeListingImageView.pending(
        s.pendingImages.first,
        width: 80,
        height: 80,
        fit: BoxFit.cover,
      );
    }
    return Container(
      width: 80,
      height: 80,
      color: const Color(0xFFF2F4F7),
      child: const Icon(Icons.restaurant, size: 36, color: AppColors.muted),
    );
  }

  Widget _buildDietaryBadge(String type) {
    late final Color color;
    late final String label;

    switch (type) {
      case 'NON_VEG':
        color = const Color(0xFFD92D20);
        label = 'Non-Veg';
        break;
      case 'EGG':
        color = const Color(0xFFF79009);
        label = 'Egg';
        break;
      case 'EGGLESS':
        color = const Color(0xFF667085);
        label = 'Eggless';
        break;
      case 'VEG':
      default:
        color = const Color(0xFF027A48);
        label = 'Veg';
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: color.withValues(alpha: 0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(shape: BoxShape.circle, color: color),
          ),
          const SizedBox(width: 5),
          Text(
            label,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(String label, String value, {bool isFirst = false, bool isLast = false}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
      decoration: BoxDecoration(
        border: Border(
          bottom: isLast ? BorderSide.none : const BorderSide(color: Color(0xFFF2F4F7)),
        ),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 130,
            child: Text(
              label,
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w500,
                color: AppColors.muted,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: AppColors.ink,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
