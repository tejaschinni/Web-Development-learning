// lib/features/seller/presentation/widgets/listing/steps/listing_pricing_step.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_listing_provider.dart';

class ListingPricingStep extends ConsumerWidget {
  const ListingPricingStep({super.key});

  static const _days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  static const _prepOptions = [
    '15 minutes',
    '30 minutes',
    '45 minutes',
    '1 hour',
    '2 hours',
    '4 hours',
    '1 day',
    '2 days',
  ];
  static const _timeSlots = [
    '08:00 AM',
    '09:00 AM',
    '10:00 AM',
    '11:00 AM',
    '12:00 PM',
    '01:00 PM',
    '02:00 PM',
    '04:00 PM',
    '06:00 PM',
    '08:00 PM',
    '09:00 PM',
    '10:00 PM',
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(productListingProvider);
    final n = ref.read(productListingProvider.notifier);
    final c = n.controllers;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      children: [
        Text(
          'Pricing & Availability',
          style: AppTheme.display(18, w: FontWeight.w700, c: AppColors.ink),
        ),
        const SizedBox(height: 16),

        // 1. Price per Unit (₹) * and Stock Quantity *
        Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildFieldLabel('Price per Unit (₹)', required: true),
                  const SizedBox(height: 6),
                  TextField(
                    controller: c.basePrice,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    style: const TextStyle(fontSize: 14, color: AppColors.ink),
                    decoration: _inputDecoration(hintText: '120'),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildFieldLabel('Stock Quantity', required: true),
                  const SizedBox(height: 6),
                  TextField(
                    controller: c.quantity,
                    keyboardType: TextInputType.number,
                    style: const TextStyle(fontSize: 14, color: AppColors.ink),
                    decoration: _inputDecoration(hintText: '10'),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 18),

        // 2. Order Type
        _buildFieldLabel('Order Type', required: false),
        const SizedBox(height: 8),
        InkWell(
          onTap: () => n.setImmediateOrder(!s.isImmediateOrder),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Row(
              children: [
                SizedBox(
                  width: 24,
                  height: 24,
                  child: Checkbox(
                    value: s.isImmediateOrder,
                    activeColor: AppColors.green,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                    onChanged: (v) => n.setImmediateOrder(v ?? false),
                  ),
                ),
                const SizedBox(width: 10),
                const Text(
                  'Immediate Order (Available now)',
                  style: TextStyle(fontSize: 13, color: AppColors.ink, fontWeight: FontWeight.w500),
                ),
              ],
            ),
          ),
        ),
        InkWell(
          onTap: () => n.setPreOrder(!s.isPreOrder),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Row(
              children: [
                SizedBox(
                  width: 24,
                  height: 24,
                  child: Checkbox(
                    value: s.isPreOrder,
                    activeColor: AppColors.green,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                    onChanged: (v) => n.setPreOrder(v ?? false),
                  ),
                ),
                const SizedBox(width: 10),
                const Text(
                  'Pre-order (Future date)',
                  style: TextStyle(fontSize: 13, color: AppColors.ink, fontWeight: FontWeight.w500),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 18),

        // 3. Preparation Time
        _buildFieldLabel('Preparation Time', required: false),
        const SizedBox(height: 6),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: AppColors.border),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: _prepOptions.contains(s.prepTimeMinutes) ? s.prepTimeMinutes : _prepOptions[1],
              isExpanded: true,
              icon: const Icon(Icons.keyboard_arrow_down, color: AppColors.muted),
              style: const TextStyle(fontSize: 14, color: AppColors.ink),
              onChanged: (v) {
                if (v != null) n.setPrepTimeMinutes(v);
              },
              items: _prepOptions
                  .map((opt) => DropdownMenuItem(value: opt, child: Text(opt)))
                  .toList(),
            ),
          ),
        ),
        const SizedBox(height: 18),

        // 4. Available Days
        _buildFieldLabel('Available Days', required: false),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: _days.map((day) {
            final isSelected = s.availableDays.contains(day);
            return Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 2),
                child: InkWell(
                  onTap: () => n.toggleAvailableDay(day),
                  borderRadius: BorderRadius.circular(6),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 150),
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: isSelected ? AppColors.green : Colors.white,
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(
                        color: isSelected ? AppColors.green : AppColors.border,
                      ),
                    ),
                    child: Text(
                      day,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                        color: isSelected ? Colors.white : AppColors.muted,
                      ),
                    ),
                  ),
                ),
              ),
            );
          }).toList(),
        ),
        const SizedBox(height: 18),

        // 5. Available Time Slots
        _buildFieldLabel('Available Time Slots', required: false),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: AppColors.border),
                ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    value: _timeSlots.contains(s.timeSlotStart) ? s.timeSlotStart : _timeSlots[2],
                    isExpanded: true,
                    icon: const Icon(Icons.keyboard_arrow_down, color: AppColors.muted, size: 18),
                    style: const TextStyle(fontSize: 13, color: AppColors.ink),
                    onChanged: (v) {
                      if (v != null) n.setTimeSlotStart(v);
                    },
                    items: _timeSlots
                        .map((t) => DropdownMenuItem(value: t, child: Text(t)))
                        .toList(),
                  ),
                ),
              ),
            ),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 10),
              child: Text(
                'to',
                style: TextStyle(fontSize: 13, color: AppColors.muted),
              ),
            ),
            Expanded(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: AppColors.border),
                ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    value: _timeSlots.contains(s.timeSlotEnd) ? s.timeSlotEnd : _timeSlots[10],
                    isExpanded: true,
                    icon: const Icon(Icons.keyboard_arrow_down, color: AppColors.muted, size: 18),
                    style: const TextStyle(fontSize: 13, color: AppColors.ink),
                    onChanged: (v) {
                      if (v != null) n.setTimeSlotEnd(v);
                    },
                    items: _timeSlots
                        .map((t) => DropdownMenuItem(value: t, child: Text(t)))
                        .toList(),
                  ),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildFieldLabel(String label, {required bool required}) {
    return RichText(
      text: TextSpan(
        text: label,
        style: const TextStyle(
          fontSize: 13,
          fontWeight: FontWeight.w600,
          color: AppColors.ink,
        ),
        children: [
          if (required)
            const TextSpan(
              text: ' *',
              style: TextStyle(color: AppColors.red, fontWeight: FontWeight.bold),
            ),
        ],
      ),
    );
  }

  InputDecoration _inputDecoration({required String hintText}) {
    return InputDecoration(
      hintText: hintText,
      hintStyle: const TextStyle(color: AppColors.muted, fontSize: 13),
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: AppColors.border),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: AppColors.green, width: 1.5),
      ),
    );
  }
}
