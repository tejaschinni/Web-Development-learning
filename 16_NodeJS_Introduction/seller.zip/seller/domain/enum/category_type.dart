enum CategoryType {
  food,
  service,
  product,
  classType,
  consultancy,
  event,
  communityNeed;

  String get label {
    switch (this) {
      case CategoryType.food:
        return 'FOOD';
      case CategoryType.service:
        return 'SERVICE';
      case CategoryType.product:
        return 'PRODUCT';
      case CategoryType.classType:
        return 'CLASS';
      case CategoryType.consultancy:
        return 'CONSULTANCY';
      case CategoryType.event:
        return 'EVENT';
      case CategoryType.communityNeed:
        return 'COMMUNITY NEED';
    }
  }

  String get apiValue {
    switch (this) {
      case CategoryType.food:
        return 'FOOD';
      case CategoryType.service:
        return 'SERVICE';
      case CategoryType.product:
        return 'PRODUCT';
      case CategoryType.classType:
        return 'CLASS';
      case CategoryType.consultancy:
        return 'CONSULTANCY';
      case CategoryType.event:
        return 'EVENT';
      case CategoryType.communityNeed:
        return 'COMMUNITY_NEED';
    }
  }
}
