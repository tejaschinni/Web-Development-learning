enum CertificateType {
  cookingCertificate('COOKING_CERTIFICATE', 'Cooking Certificate'),
  culinaryDiploma('CULINARY_DIPLOMA', 'Culinary Diploma / Degree'),
  foodHandler('FOOD_HANDLER', 'Food Handler Certificate'),
  foodSafety('FOOD_SAFETY', 'Food Safety Training Certificate'),
  fssaiLicense('FSSAI_LICENSE', 'FSSAI License'),
  fssaiRegistration('FSSAI_REGISTRATION', 'FSSAI Registration'),
  hygieneRating('HYGIENE_RATING', 'Hygiene Rating Certificate'),
  healthCertificate('HEALTH_CERTIFICATE', 'Health / Medical Fitness Certificate'),
  bakingCertificate('BAKING_CERTIFICATE', 'Baking / Pastry Certificate'),
  tradeLicense('TRADE_LICENSE', 'Trade License'),
  gstRegistration('GST_REGISTRATION', 'GST Registration'),
  other('OTHER', 'Other');

  final String value; // sent to the backend
  final String label; // shown to the user

  const CertificateType(this.value, this.label);
}
