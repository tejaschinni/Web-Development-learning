enum DocumentType {
  aadhaar('AADHAAR', 'Aadhaar card'),
  pan('PAN', 'PAN card'),
  gst('GST_CERTIFICATE', 'GST certificate'),
  fssai('FSSAI_LICENSE', 'FSSAI license'),
  shopAct('SHOP_ACT_LICENSE', 'Shop Act license'),
  other('OTHER', 'Other');

  const DocumentType(this.type, this.label);

  final String type; // sent to / received from the API
  final String label; // shown in the UI

  // Convert an API string back to the enum (e.g. for uploaded documents)
  static DocumentType fromType(String type) =>
      DocumentType.values.firstWhere((d) => d.type == type, orElse: () => DocumentType.other);
}
