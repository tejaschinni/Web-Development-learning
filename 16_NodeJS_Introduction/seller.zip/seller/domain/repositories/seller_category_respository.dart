import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/seller/data/datasources/seller_category_remote_datasource.dart';
import 'package:society_seva/features/seller/domain/entities/seller_category_entity.dart';
import 'package:society_seva/features/shop/data/models/shop_category_model.dart';
import 'package:society_seva/features/shop/domain/enums/shop_category_type.dart';

abstract class SellerCategoryRespository {
  Future<PageResponse<CategoriesEntity>> fetchCategoriesRepo({
    String? categoryType,
    String? parentCategoryId,
    bool? rootsOnly,
    String? search,
  });

  Future<List<ShopCategoryModel>> fetchCategoriesTreeRepo({String? categoryType});
}

final _mockSellerCategories = <CategoriesEntity>[
  CategoriesEntity(
    id: 'cat-food',
    name: 'Food',
    slug: 'food',
    categoryType: 'FOOD',
    requiresCertificate: true,
    isActive: true,
    displayOrder: 0,
    createdAt: DateTime(2024, 1, 1),
    updatedAt: DateTime(2024, 1, 1),
  ),
  CategoriesEntity(
    id: 'cat-product',
    name: 'Products',
    slug: 'products',
    categoryType: 'PRODUCT',
    requiresCertificate: false,
    isActive: true,
    displayOrder: 1,
    createdAt: DateTime(2024, 1, 1),
    updatedAt: DateTime(2024, 1, 1),
  ),
  CategoriesEntity(
    id: 'cat-service',
    name: 'Services',
    slug: 'services',
    categoryType: 'SERVICE',
    requiresCertificate: false,
    isActive: true,
    displayOrder: 2,
    createdAt: DateTime(2024, 1, 1),
    updatedAt: DateTime(2024, 1, 1),
  ),
];

final _mockFullCategoryTree = <ShopCategoryModel>[
  ShopCategoryModel(
    id: 'cat-food',
    name: 'Food',
    slug: 'food',
    categoryType: ShopCategoryType.food,
    requiresCertificate: true,
    isActive: true,
    displayOrder: 0,
    subCategories: const [
      ShopCategoryModel(
        id: 'food-sub-1',
        parentCategoryId: 'cat-food',
        name: 'Homemade meals and tiffin',
        slug: 'homemade-meals-and-tiffin',
        categoryType: ShopCategoryType.food,
        requiresCertificate: true,
        isActive: true,
        displayOrder: 0,
        subCategories: [],
      ),
      ShopCategoryModel(
        id: 'food-sub-2',
        parentCategoryId: 'cat-food',
        name: 'Snacks and namkeen',
        slug: 'snacks-and-namkeen',
        categoryType: ShopCategoryType.food,
        requiresCertificate: true,
        isActive: true,
        displayOrder: 1,
        subCategories: [],
      ),
      ShopCategoryModel(
        id: 'food-sub-3',
        parentCategoryId: 'cat-food',
        name: 'Cakes and bakery',
        slug: 'cakes-and-bakery',
        categoryType: ShopCategoryType.food,
        requiresCertificate: true,
        isActive: true,
        displayOrder: 2,
        subCategories: [],
      ),
      ShopCategoryModel(
        id: 'food-sub-4',
        parentCategoryId: 'cat-food',
        name: 'Sweets and desserts',
        slug: 'sweets-and-desserts',
        categoryType: ShopCategoryType.food,
        requiresCertificate: true,
        isActive: true,
        displayOrder: 3,
        subCategories: [],
      ),
      ShopCategoryModel(
        id: 'food-sub-5',
        parentCategoryId: 'cat-food',
        name: 'Pickles, chutneys and homemade products',
        slug: 'pickles-chutneys',
        categoryType: ShopCategoryType.food,
        requiresCertificate: true,
        isActive: true,
        displayOrder: 4,
        subCategories: [],
      ),
      ShopCategoryModel(
        id: 'food-sub-6',
        parentCategoryId: 'cat-food',
        name: 'Festival and special-occasion food',
        slug: 'festival-food',
        categoryType: ShopCategoryType.food,
        requiresCertificate: true,
        isActive: true,
        displayOrder: 5,
        subCategories: [],
      ),
      ShopCategoryModel(
        id: 'food-sub-7',
        parentCategoryId: 'cat-food',
        name: 'Catering and bulk orders',
        slug: 'catering-bulk-orders',
        categoryType: ShopCategoryType.food,
        requiresCertificate: true,
        isActive: true,
        displayOrder: 6,
        subCategories: [],
      ),
    ],
  ),
  ShopCategoryModel(
    id: 'cat-art-creative',
    name: 'Art & Creative',
    slug: 'art-creative',
    categoryType: ShopCategoryType.product,
    requiresCertificate: false,
    isActive: true,
    displayOrder: 1,
    subCategories: const [
      ShopCategoryModel(
        id: 'art-sub-1',
        parentCategoryId: 'cat-art-creative',
        name: 'Handmade gifts & crafts',
        slug: 'handmade-gifts',
        categoryType: ShopCategoryType.product,
        requiresCertificate: false,
        isActive: true,
        displayOrder: 0,
        subCategories: [],
      ),
      ShopCategoryModel(
        id: 'art-sub-2',
        parentCategoryId: 'cat-art-creative',
        name: 'Artwork, jewellery & decor',
        slug: 'artwork-jewellery',
        categoryType: ShopCategoryType.product,
        requiresCertificate: false,
        isActive: true,
        displayOrder: 1,
        subCategories: [],
      ),
      ShopCategoryModel(
        id: 'art-sub-3',
        parentCategoryId: 'cat-art-creative',
        name: 'Festive & seasonal decor',
        slug: 'festive-decor',
        categoryType: ShopCategoryType.product,
        requiresCertificate: false,
        isActive: true,
        displayOrder: 2,
        subCategories: [],
      ),
      ShopCategoryModel(
        id: 'art-sub-4',
        parentCategoryId: 'cat-art-creative',
        name: 'Workshops & creative sessions',
        slug: 'workshops-sessions',
        categoryType: ShopCategoryType.service,
        requiresCertificate: false,
        isActive: true,
        displayOrder: 3,
        subCategories: [],
      ),
    ],
  ),
  ShopCategoryModel(
    id: 'cat-service',
    name: 'Services',
    slug: 'services',
    categoryType: ShopCategoryType.service,
    requiresCertificate: false,
    isActive: true,
    displayOrder: 2,
    subCategories: const [
      ShopCategoryModel(
        id: 'service-sub-1',
        parentCategoryId: 'cat-service',
        name: 'Home Tutoring & Academics',
        slug: 'tutoring',
        categoryType: ShopCategoryType.service,
        requiresCertificate: false,
        isActive: true,
        displayOrder: 0,
        subCategories: [],
      ),
      ShopCategoryModel(
        id: 'service-sub-2',
        parentCategoryId: 'cat-service',
        name: 'Home Repairs & Maintenance',
        slug: 'home-repairs',
        categoryType: ShopCategoryType.service,
        requiresCertificate: false,
        isActive: true,
        displayOrder: 1,
        subCategories: [],
      ),
      ShopCategoryModel(
        id: 'service-sub-3',
        parentCategoryId: 'cat-service',
        name: 'Beauty, Wellness & Salon',
        slug: 'beauty-wellness',
        categoryType: ShopCategoryType.service,
        requiresCertificate: false,
        isActive: true,
        displayOrder: 2,
        subCategories: [],
      ),
      ShopCategoryModel(
        id: 'service-sub-4',
        parentCategoryId: 'cat-service',
        name: 'Event Management & Support',
        slug: 'event-support',
        categoryType: ShopCategoryType.service,
        requiresCertificate: false,
        isActive: true,
        displayOrder: 3,
        subCategories: [],
      ),
    ],
  ),
];

class SellerCategoryRespositoryImpl implements SellerCategoryRespository {
  SellerCategoryRespositoryImpl(this.sellerCategoryRemoteDatasource);

  final SellerCategoryRemoteDatasource sellerCategoryRemoteDatasource;
  @override
  Future<PageResponse<CategoriesEntity>> fetchCategoriesRepo({
    String? categoryType,
    String? parentCategoryId,
    bool? rootsOnly,
    String? search,
  }) async {
    return PageResponse<CategoriesEntity>(
      content: _mockSellerCategories,
      page: 0,
      size: _mockSellerCategories.length,
      totalElements: _mockSellerCategories.length,
      totalPages: 1,
      first: true,
      last: true,
    );
  }

  @override
  Future<List<ShopCategoryModel>> fetchCategoriesTreeRepo({String? categoryType}) async {
    try {
      final remote = await sellerCategoryRemoteDatasource.fetchCategoriesTreeDataSouce(
        categoryType: categoryType,
      );
      if (remote.isNotEmpty) return remote;
    } catch (_) {}

    if (categoryType != null && categoryType.isNotEmpty) {
      final filtered = _mockFullCategoryTree
          .where((cat) => cat.categoryType.name.toUpperCase() == categoryType.toUpperCase())
          .toList();
      if (filtered.isNotEmpty) return filtered;
    }

    return _mockFullCategoryTree;
  }
}
