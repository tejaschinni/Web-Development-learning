import 'package:image_picker/image_picker.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/seller/data/datasources/seller_listing_remote_datasource.dart';
import 'package:society_seva/features/seller/data/models/request/food_additinal_information_request.dart';
import 'package:society_seva/features/seller/data/models/request/seller_listing_basic_info_request.dart';
import 'package:society_seva/features/seller/data/models/request/service_additional_information_request.dart';
import 'package:society_seva/features/seller/domain/entities/food_detail_entity.dart';
import 'package:society_seva/features/seller/domain/entities/seller_listing_entity.dart';
import 'package:society_seva/features/seller/domain/entities/seller_listing_images_entity.dart';
import 'package:society_seva/features/seller/domain/entities/service_detail_entity.dart';
import 'package:society_seva/features/seller/domain/entities/service_slot_entity.dart';

abstract class SellerListingRespository {
  Future<PageResponse<SellerListingEntity>> fetchMyListingRepo({required String sellerId});
  Future<List<SellerListingImageEntity>> getListingImagesRepo(String listingId);
  Future<SellerListingEntity?> createListingRepo({required SellerListingBasicInfoRequest request});

  Future<SellerListingEntity?> submitListingRepo({required String listingId});

  Future<SellerListingEntity?> updatesubmitListingRepo({
    required String listingId,
    required SellerListingBasicInfoRequest request,
  });

  Future<SellerListingImageEntity> uploadSellerShopImagesRepo(String sellerId, XFile file);

  Future<bool> additionalFoodInformationRepo({
    required FoodAdditinalInformationRequest request,
    required String listingId,
  });

  Future<bool> additionalServiceInformationRepo({
    required ServiceAdditionalInformationRequest request,
    required String listingId,
  });

  Future<FoodListingDetailsEntity?> updateadditionalFoodInformationRepo({
    required FoodAdditinalInformationRequest request,
    required String listingId,
  });

  Future<ServiceListingDetailsEntity?> updateadditionalServiceInformationRepo({
    required ServiceAdditionalInformationRequest request,
    required String listingId,
  });

  Future<FoodListingDetailsEntity> fetchadditionalFoodInformationRepo({required String listingId});

  Future<ServiceListingDetailsEntity> fetchadditionalServiceInformationRepo({
    required String listingId,
  });

  /// PUT /api/v1/service-schedules/listings/{listingId}/availability/{date}
  Future<List<ServiceSlotEntity>> saveServiceSlotsRepo({
    required String listingId,
    required String date,
    required List<Map<String, String>> windows,
  });

  /// DELETE /api/v1/service-schedules/listings/{listingId}/availability/{date}
  Future<void> deleteServiceSlotsRepo({required String listingId, required String date});

  /// DELETE /api/v1/listings/{listingId}/images/{imageId}
  Future<void> deleteListingImageRepo({required String listingId, required String imageId});
}

final _mockListings = <SellerListingEntity>[
  SellerListingEntity(
    id: 'mock-listing-1',
    sellerId: 'mock-seller-1',
    categoryId: 'cat-food',
    additionalCategoryIds: const [],
    listingType: 'FOOD',
    title: 'Homemade Veg Thali',
    description: 'Freshly made North Indian thali with seasonal vegetables.',
    basePrice: 150,
    priceUnit: 'PER_PLATE',
    isFree: false,
    quantityAvailable: 10,
    availabilityStatus: 'AVAILABLE',
    approvalStatus: 'APPROVED',
    moderationStatus: 'APPROVED',
    sponsoredStatus: 'NONE',
    averageRating: 4.7,
    totalReviews: 21,
    tagNames: const ['thali', 'homemade', 'lunch'],
    createdAt: DateTime(2024, 3, 1),
    updatedAt: DateTime(2024, 3, 1),
  ),
  SellerListingEntity(
    id: 'mock-listing-2',
    sellerId: 'mock-seller-1',
    categoryId: 'cat-service',
    additionalCategoryIds: const [],
    listingType: 'SERVICE',
    title: 'Home Tutoring - Maths & Science',
    description: 'One-on-one tutoring for grades 6-10.',
    basePrice: 500,
    priceUnit: 'PER_SESSION',
    isFree: false,
    quantityAvailable: 0,
    availabilityStatus: 'AVAILABLE',
    approvalStatus: 'APPROVED',
    moderationStatus: 'APPROVED',
    sponsoredStatus: 'NONE',
    averageRating: 4.9,
    totalReviews: 8,
    tagNames: const ['tutoring', 'education'],
    createdAt: DateTime(2024, 3, 5),
    updatedAt: DateTime(2024, 3, 5),
  ),
  SellerListingEntity(
    id: 'mock-listing-3',
    sellerId: 'mock-seller-1',
    categoryId: 'cat-product',
    additionalCategoryIds: const [],
    listingType: 'PRODUCT',
    title: 'Handmade Chocolate Box (12 pcs)',
    description: 'Assorted handmade chocolates, made fresh every week.',
    basePrice: 350,
    priceUnit: 'PER_ITEM',
    isFree: false,
    quantityAvailable: 15,
    availabilityStatus: 'AVAILABLE',
    approvalStatus: 'PENDING',
    moderationStatus: 'PENDING',
    sponsoredStatus: 'NONE',
    averageRating: 0,
    totalReviews: 0,
    tagNames: const ['chocolate', 'gifting'],
    createdAt: DateTime(2024, 3, 10),
    updatedAt: DateTime(2024, 3, 10),
  ),
];

final _mockListingImages = <SellerListingImageEntity>[
  SellerListingImageEntity(
    id: 'mock-listing-image-1',
    listingId: 'mock-listing-1',
    imageUrl: 'https://picsum.photos/seed/listing-1/600/600',
    moderationStatus: 'APPROVED',
    displayOrder: 0,
    createdAt: DateTime(2024, 3, 1),
  ),
];

const _mockFoodDetails = FoodListingDetailsEntity(
  id: 'mock-food-detail-1',
  listingId: 'mock-listing-1',
  preparationTime: '30',
  spiceLevel: 3,
  spiceLevelText: 'MEDIUM',
  freshnessDeclaration: 'Freshly prepared on order',
  isFrozenItem: false,
  fssaiRequired: false,
  ingredients: 'Wheat flour, rice, dal, seasonal vegetables, spices',
  allergens: 'None',
  foodType: 'VEG',
  storageInstruction: 'Consume within 4 hours',
  packagingDetails: 'Eco-friendly container',
  servingSizes: [
    ServingSizeEntity(
      id: 'mock-serving-1',
      sizeValue: 1,
      sizeUnit: 'Plate',
      description: 'Full plate',
      price: 150,
      quantityAvailable: 10,
      isAvailable: true,
    ),
  ],
);

const _mockServiceDetails = ServiceListingDetailsEntity(
  id: 'mock-service-detail-1',
  listingId: 'mock-listing-2',
  serviceDurationMinutes: 60,
  serviceLocationType: 'BUYER_FLAT',
  homeVisitAvailable: true,
  onlineAvailable: false,
  requiredMaterials: 'Notebook and textbooks',
  cancellationPolicy: 'Free cancellation up to 24 hours before',
  certificateRequired: false,
);

class SellerListingRespositoryImpl implements SellerListingRespository {
  SellerListingRespositoryImpl(this.sellerListingRemoteDatasource);

  // Used by saveServiceSlotsRepo/deleteServiceSlotsRepo/deleteListingImageRepo
  // below; the rest of this class returns static mock data directly (see the
  // `_mock*` constants above) rather than going through the data source.
  final SellerListingRemoteDatasource sellerListingRemoteDatasource;

  @override
  Future<PageResponse<SellerListingEntity>> fetchMyListingRepo({required String sellerId}) async {
    return PageResponse<SellerListingEntity>(
      content: _mockListings,
      page: 0,
      size: _mockListings.length,
      totalElements: _mockListings.length,
      totalPages: 1,
      first: true,
      last: true,
    );
  }

  @override
  Future<List<SellerListingImageEntity>> getListingImagesRepo(String listingId) async {
    return _mockListingImages.where((i) => i.listingId == listingId).toList();
  }

  @override
  Future<SellerListingEntity?> createListingRepo({
    required SellerListingBasicInfoRequest request,
  }) async {
    return _mockListings.first;
  }

  @override
  Future<bool> additionalFoodInformationRepo({
    required FoodAdditinalInformationRequest request,
    required String listingId,
  }) async {
    return true;
  }

  @override
  Future<bool> additionalServiceInformationRepo({
    required ServiceAdditionalInformationRequest request,
    required String listingId,
  }) async {
    return true;
  }

  @override
  Future<FoodListingDetailsEntity> fetchadditionalFoodInformationRepo({
    required String listingId,
  }) async {
    return _mockFoodDetails;
  }

  @override
  Future<ServiceListingDetailsEntity> fetchadditionalServiceInformationRepo({
    required String listingId,
  }) async {
    return _mockServiceDetails;
  }

  @override
  Future<SellerListingEntity?> submitListingRepo({required String listingId}) async {
    return _mockListings.first.copyWith(approvalStatus: 'PENDING');
  }

  @override
  Future<FoodListingDetailsEntity?> updateadditionalFoodInformationRepo({
    required FoodAdditinalInformationRequest request,
    required String listingId,
  }) async {
    return _mockFoodDetails;
  }

  @override
  Future<ServiceListingDetailsEntity?> updateadditionalServiceInformationRepo({
    required ServiceAdditionalInformationRequest request,
    required String listingId,
  }) async {
    return _mockServiceDetails;
  }

  @override
  Future<SellerListingEntity?> updatesubmitListingRepo({
    required String listingId,
    required SellerListingBasicInfoRequest request,
  }) async {
    return _mockListings.first;
  }

  @override
  Future<SellerListingImageEntity> uploadSellerShopImagesRepo(String sellerId, XFile file) async {
    return _mockListingImages.first;
  }

  /// Passes straight through to the data source, which currently returns
  /// windows computed from the request instead of calling the backend.
  @override
  Future<List<ServiceSlotEntity>> saveServiceSlotsRepo({
    required String listingId,
    required String date,
    required List<Map<String, String>> windows,
  }) {
    return sellerListingRemoteDatasource.saveServiceSlotsDataSource(
      listingId: listingId,
      date: date,
      windows: windows,
    );
  }

  /// Passes straight through to the data source, which currently no-ops
  /// instead of calling the backend.
  @override
  Future<void> deleteServiceSlotsRepo({required String listingId, required String date}) {
    return sellerListingRemoteDatasource.deleteServiceSlotsDataSource(
      listingId: listingId,
      date: date,
    );
  }

  /// Passes straight through to the data source, which currently no-ops
  /// instead of calling the backend.
  @override
  Future<void> deleteListingImageRepo({required String listingId, required String imageId}) {
    return sellerListingRemoteDatasource.deleteListingImageDataSource(
      listingId: listingId,
      imageId: imageId,
    );
  }
}
