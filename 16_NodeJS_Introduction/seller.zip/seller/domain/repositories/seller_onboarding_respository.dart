import 'package:image_picker/image_picker.dart';
import 'package:society_seva/features/seller/data/datasources/seller_onboarding_remote_data_source.dart';
import 'package:society_seva/features/seller/data/models/request/seller_profile_request.dart';
import 'package:society_seva/features/seller/domain/entities/certificate_entity.dart';
import 'package:society_seva/features/seller/domain/entities/kyc_document_entity.dart';
import 'package:society_seva/features/seller/domain/entities/seller_image_entity.dart';
import 'package:society_seva/features/seller/domain/entities/seller_profile_entity.dart';

abstract class SellerOnboardingRespository {
  Future<SellerProfileEntity?> createAndSaveAsDraftRepo({required SellerProfileRequest request});
  Future<SellerProfileEntity?> submitDartRepo({required String sellerId});
  Future<void> uploadSellerShopImagesRepo(String sellerId, XFile file);
  Future<List<SellerImageEntity>> fetchSellerUploadedImagesRepo(String sellerId);
  Future<SellerProfileEntity?> mySellerProfileRepo();
  Future<SellerProfileEntity?> fetchSellerProfileByIDRepo(String sellerID);
  Future<SellerProfileEntity?> updateProfileRepo({
    required SellerProfileRequest request,
    required String sellerID,
  });
  Future<void> deleteUploadedSellerImagesRepo({required String sellerID, required String imageId});

  Future<CertificateEntity?> uploadCertificateRepo({
    required String sellerId,
    required XFile file,
    required String certificateName,
    required String certificateType,
    required DateTime issueDate,
    required bool hasExpiry,
    required String issueAuthority,
    required String certificateNumber,
    DateTime? expiryDate,
  });

  Future<List<CertificateEntity>> fetchCertificatesRepo(String sellerId);

  Future<bool> uploadKYCDocumentRepo({
    required XFile file,
    required String documentType,
    required String documentNumber,
    required String sellerId,
  });
  Future<List<KycDocumentEntity>> fetchKYCDocumentRepo(String sellerId);

  /// Downloads a KYC document's file content (base64 string).
  Future<String> downloadKYCDocumentFileRepo({
    required String sellerId,
    required String documentFileUrl,
  });
}

final _mockSellerProfile = SellerProfileEntity(
  id: 'mock-seller-1',
  userId: 'mock-user-1',
  displayName: 'Tejas Chinni',
  sellerType: 'INDIVIDUAL',
  availabilityStatus: 'AVAILABLE',
  approvalStatus: 'APPROVED',
  fssaiStatus: 'NOT_REQUIRED',
  fssaiRequired: false,
  renewalStatus: 'RENEWED',
  totalListings: 6,
  averageRating: 4.6,
  rejectedOrders: 1,
  cancelledOrders: 2,
  totalOrders: 48,
  totalReviews: 32,
  address: 'A-304, Vasundhara Enclave, Society Seva Layout',
  city: 'Bengaluru',
  state: 'Karnataka',
  country: 'IN',
  pinCode: '560037',
  createdAt: DateTime(2024, 2, 1).toIso8601String(),
  updatedAt: DateTime.now().toIso8601String(),
  societyId: 'mock-society-1',
  businessName: "Tejas's Homemade Treats",
  bio: 'Homemade food and daily essentials, made fresh for the society.',
  websiteUrl: null,
  legalCompliance: null,
  latitude: 12.9716,
  longitude: 77.5946,
  deliveryRadiusKm: 3,
  targetArea: 'Vasundhara Enclave',
);

final _mockSellerImages = <SellerImageEntity>[
  SellerImageEntity(
    id: 'mock-seller-image-1',
    sellerId: _mockSellerProfile.id,
    imageUrl: 'https://picsum.photos/seed/seller-shop-1/600/600',
    moderationStatus: 'APPROVED',
    displayOrder: 0,
    createdAt: DateTime(2024, 2, 2),
    updatedAt: DateTime(2024, 2, 2),
  ),
  SellerImageEntity(
    id: 'mock-seller-image-2',
    sellerId: _mockSellerProfile.id,
    imageUrl: 'https://picsum.photos/seed/seller-shop-2/600/600',
    moderationStatus: 'APPROVED',
    displayOrder: 1,
    createdAt: DateTime(2024, 2, 3),
    updatedAt: DateTime(2024, 2, 3),
  ),
];

final _mockCertificates = <CertificateEntity>[
  CertificateEntity(
    id: 'mock-certificate-1',
    sellerId: _mockSellerProfile.id,
    certificateType: 'BUSINESS_LICENSE',
    certificateName: 'Shop & Establishment Licence',
    issuingAuthority: 'BBMP',
    certificateFileUrl: 'https://picsum.photos/seed/certificate-1/400/560',
    verificationStatus: 'APPROVED',
    createdAt: DateTime(2024, 2, 4),
    updatedAt: DateTime(2024, 2, 4),
  ),
];

final _mockKycDocuments = <KycDocumentEntity>[
  KycDocumentEntity(
    id: 'mock-kyc-1',
    sellerId: _mockSellerProfile.id,
    documentType: 'AADHAAR',
    documentFileUrl: 'https://picsum.photos/seed/kyc-1/400/280',
    verificationStatus: 'APPROVED',
    createdAt: DateTime(2024, 2, 1),
    updatedAt: DateTime(2024, 2, 1),
  ),
];

class SellerOnboardingRespositoryImpl implements SellerOnboardingRespository {
  SellerOnboardingRespositoryImpl({required this.sellerOnboardingRemoteDataSource});
  // Used by downloadKYCDocumentFileRepo below; the rest of this class
  // currently returns static mock data directly (see the `_mock*` constants
  // above) rather than going through the data source.
  final SellerOnboardingRemoteDataSource sellerOnboardingRemoteDataSource;
  @override
  Future<SellerProfileEntity?> createAndSaveAsDraftRepo({
    required SellerProfileRequest request,
  }) async {
    return _mockSellerProfile;
  }

  @override
  Future<void> deleteUploadedSellerImagesRepo({
    required String sellerID,
    required String imageId,
  }) async {}

  @override
  Future<SellerProfileEntity?> fetchSellerProfileByIDRepo(String sellerID) async {
    return _mockSellerProfile;
  }

  @override
  Future<List<SellerImageEntity>> fetchSellerUploadedImagesRepo(String sellerId) async {
    return _mockSellerImages;
  }

  @override
  Future<SellerProfileEntity?> mySellerProfileRepo() async {
    return _mockSellerProfile;
  }

  @override
  Future<SellerProfileEntity?> submitDartRepo({required String sellerId}) async {
    return _mockSellerProfile;
  }

  @override
  Future<SellerProfileEntity?> updateProfileRepo({
    required SellerProfileRequest request,
    required String sellerID,
  }) async {
    return _mockSellerProfile;
  }

  @override
  Future<void> uploadSellerShopImagesRepo(String sellerId, XFile file) async {}

  @override
  Future<List<CertificateEntity>> fetchCertificatesRepo(String sellerId) async {
    return _mockCertificates;
  }

  @override
  Future<CertificateEntity?> uploadCertificateRepo({
    required String sellerId,
    required XFile file,
    required String certificateName,
    required String certificateType,
    required DateTime issueDate,
    required bool hasExpiry,
    required String issueAuthority,
    required String certificateNumber,
    DateTime? expiryDate,
  }) async {
    return _mockCertificates.first;
  }

  @override
  Future<List<KycDocumentEntity>> fetchKYCDocumentRepo(String sellerId) async {
    return _mockKycDocuments;
  }

  @override
  Future<bool> uploadKYCDocumentRepo({
    required XFile file,
    required String documentType,
    required String documentNumber,
    required String sellerId,
  }) async {
    return true;
  }

  /// Passes straight through to the data source, which currently returns a
  /// static placeholder (see seller_onboarding_remote_data_source.dart).
  @override
  Future<String> downloadKYCDocumentFileRepo({
    required String sellerId,
    required String documentFileUrl,
  }) {
    return sellerOnboardingRemoteDataSource.downloadKycDocumentFileDataSource(
      sellerId: sellerId,
      documentFileUrl: documentFileUrl,
    );
  }
}
