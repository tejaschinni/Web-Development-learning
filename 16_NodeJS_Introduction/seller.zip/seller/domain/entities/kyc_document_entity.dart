class KycDocumentEntity {
  final String id;
  final String sellerId;
  final String documentType;
  final String documentFileUrl;
  final String verificationStatus;
  final DateTime createdAt;
  final DateTime updatedAt;

  const KycDocumentEntity({
    required this.id,
    required this.sellerId,
    required this.documentType,
    required this.documentFileUrl,
    required this.verificationStatus,
    required this.createdAt,
    required this.updatedAt,
  });

  KycDocumentEntity copyWith({
    String? id,
    String? sellerId,
    String? documentType,
    String? documentFileUrl,
    String? verificationStatus,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return KycDocumentEntity(
      id: id ?? this.id,
      sellerId: sellerId ?? this.sellerId,
      documentType: documentType ?? this.documentType,
      documentFileUrl: documentFileUrl ?? this.documentFileUrl,
      verificationStatus: verificationStatus ?? this.verificationStatus,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}
