class FoodListingDetailsEntity {
  final String id;
  final String listingId;
  final String? preparationTime;
  final int? spiceLevel;
  final String? spiceLevelText;
  final String? freshnessDeclaration;
  final bool? isFrozenItem;
  final bool? fssaiRequired;
  final String? expiryTime;
  final String? ingredients;
  final String? allergens;
  final String? foodType;
  final String? storageInstruction;
  final String? packagingDetails;
  final String? fssaiCertificateId;
  final List<ServingSizeEntity> servingSizes;

  const FoodListingDetailsEntity({
    required this.id,
    required this.listingId,
    this.preparationTime,
    this.spiceLevel,
    this.spiceLevelText,
    this.freshnessDeclaration,
    this.isFrozenItem,
    this.fssaiRequired,
    this.expiryTime,
    this.ingredients,
    this.allergens,
    this.foodType,
    this.storageInstruction,
    this.packagingDetails,
    this.fssaiCertificateId,
    this.servingSizes = const [],
  });

  FoodListingDetailsEntity copyWith({
    String? id,
    String? listingId,
    String? preparationTime,
    int? spiceLevel,
    String? spiceLevelText,
    String? freshnessDeclaration,
    bool? isFrozenItem,
    bool? fssaiRequired,
    String? expiryTime,
    String? ingredients,
    String? allergens,
    String? foodType,
    String? storageInstruction,
    String? packagingDetails,
    String? fssaiCertificateId,
    List<ServingSizeEntity>? servingSizes,
  }) {
    return FoodListingDetailsEntity(
      id: id ?? this.id,
      listingId: listingId ?? this.listingId,
      preparationTime: preparationTime ?? this.preparationTime,
      spiceLevel: spiceLevel ?? this.spiceLevel,
      spiceLevelText: spiceLevelText ?? this.spiceLevelText,
      freshnessDeclaration: freshnessDeclaration ?? this.freshnessDeclaration,
      isFrozenItem: isFrozenItem ?? this.isFrozenItem,
      fssaiRequired: fssaiRequired ?? this.fssaiRequired,
      expiryTime: expiryTime ?? this.expiryTime,
      ingredients: ingredients ?? this.ingredients,
      allergens: allergens ?? this.allergens,
      foodType: foodType ?? this.foodType,
      storageInstruction: storageInstruction ?? this.storageInstruction,
      packagingDetails: packagingDetails ?? this.packagingDetails,
      fssaiCertificateId: fssaiCertificateId ?? this.fssaiCertificateId,
      servingSizes: servingSizes ?? this.servingSizes,
    );
  }
}

class ServingSizeEntity {
  final String id;
  final num sizeValue;
  final String sizeUnit;
  final String description;
  final num price;
  final int quantityAvailable;
  final bool isAvailable;

  const ServingSizeEntity({
    required this.id,
    required this.sizeValue,
    required this.sizeUnit,
    required this.description,
    required this.price,
    required this.quantityAvailable,
    required this.isAvailable,
  });

  ServingSizeEntity copyWith({
    String? id,
    num? sizeValue,
    String? sizeUnit,
    String? description,
    num? price,
    int? quantityAvailable,
    bool? isAvailable,
  }) {
    return ServingSizeEntity(
      id: id ?? this.id,
      sizeValue: sizeValue ?? this.sizeValue,
      sizeUnit: sizeUnit ?? this.sizeUnit,
      description: description ?? this.description,
      price: price ?? this.price,
      quantityAvailable: quantityAvailable ?? this.quantityAvailable,
      isAvailable: isAvailable ?? this.isAvailable,
    );
  }
}
