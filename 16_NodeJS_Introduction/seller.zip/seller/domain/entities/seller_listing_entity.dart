class SellerListingEntity {
  final String id;
  final String sellerId;
  final String categoryId;
  final List<String> additionalCategoryIds;
  final String listingType;
  final String title;
  final String description;
  final double basePrice;
  final String priceUnit;
  final bool isFree;
  final int quantityAvailable;
  final String availabilityStatus;
  final String approvalStatus;
  final String moderationStatus;
  final String sponsoredStatus;
  final double averageRating;
  final int totalReviews;
  final List<String> tagNames;
  final DateTime createdAt;
  final DateTime updatedAt;

  const SellerListingEntity({
    required this.id,
    required this.sellerId,
    required this.categoryId,
    required this.additionalCategoryIds,
    required this.listingType,
    required this.title,
    required this.description,
    required this.basePrice,
    required this.priceUnit,
    required this.isFree,
    required this.quantityAvailable,
    required this.availabilityStatus,
    required this.approvalStatus,
    required this.moderationStatus,
    required this.sponsoredStatus,
    required this.averageRating,
    required this.totalReviews,
    required this.tagNames,
    required this.createdAt,
    required this.updatedAt,
  });

  SellerListingEntity copyWith({
    String? id,
    String? sellerId,
    String? categoryId,
    List<String>? additionalCategoryIds,
    String? listingType,
    String? title,
    String? description,
    double? basePrice,
    String? priceUnit,
    bool? isFree,
    int? quantityAvailable,
    String? availabilityStatus,
    String? approvalStatus,
    String? moderationStatus,
    String? sponsoredStatus,
    double? averageRating,
    int? totalReviews,
    List<String>? tagNames,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return SellerListingEntity(
      id: id ?? this.id,
      sellerId: sellerId ?? this.sellerId,
      categoryId: categoryId ?? this.categoryId,
      additionalCategoryIds: additionalCategoryIds ?? this.additionalCategoryIds,
      listingType: listingType ?? this.listingType,
      title: title ?? this.title,
      description: description ?? this.description,
      basePrice: basePrice ?? this.basePrice,
      priceUnit: priceUnit ?? this.priceUnit,
      isFree: isFree ?? this.isFree,
      quantityAvailable: quantityAvailable ?? this.quantityAvailable,
      availabilityStatus: availabilityStatus ?? this.availabilityStatus,
      approvalStatus: approvalStatus ?? this.approvalStatus,
      moderationStatus: moderationStatus ?? this.moderationStatus,
      sponsoredStatus: sponsoredStatus ?? this.sponsoredStatus,
      averageRating: averageRating ?? this.averageRating,
      totalReviews: totalReviews ?? this.totalReviews,
      tagNames: tagNames ?? this.tagNames,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}
