class ServiceListingDetailsEntity {
  final String id;
  final String listingId;
  final int? serviceDurationMinutes;
  final String? serviceLocationType;
  final bool? homeVisitAvailable;
  final bool? onlineAvailable;
  final String? requiredMaterials;
  final String? cancellationPolicy;
  final bool? certificateRequired;

  const ServiceListingDetailsEntity({
    required this.id,
    required this.listingId,
    this.serviceDurationMinutes,
    this.serviceLocationType,
    this.homeVisitAvailable,
    this.onlineAvailable,
    this.requiredMaterials,
    this.cancellationPolicy,
    this.certificateRequired,
  });

  ServiceListingDetailsEntity copyWith({
    String? id,
    String? listingId,
    int? serviceDurationMinutes,
    String? serviceLocationType,
    bool? homeVisitAvailable,
    bool? onlineAvailable,
    String? requiredMaterials,
    String? cancellationPolicy,
    bool? certificateRequired,
  }) {
    return ServiceListingDetailsEntity(
      id: id ?? this.id,
      listingId: listingId ?? this.listingId,
      serviceDurationMinutes: serviceDurationMinutes ?? this.serviceDurationMinutes,
      serviceLocationType: serviceLocationType ?? this.serviceLocationType,
      homeVisitAvailable: homeVisitAvailable ?? this.homeVisitAvailable,
      onlineAvailable: onlineAvailable ?? this.onlineAvailable,
      requiredMaterials: requiredMaterials ?? this.requiredMaterials,
      cancellationPolicy: cancellationPolicy ?? this.cancellationPolicy,
      certificateRequired: certificateRequired ?? this.certificateRequired,
    );
  }
}
