class SellerListingImageEntity {
  final String id;
  final String listingId;
  final String imageUrl;
  final String moderationStatus;
  final int displayOrder;
  final DateTime createdAt;

  const SellerListingImageEntity({
    required this.id,
    required this.listingId,
    required this.imageUrl,
    required this.moderationStatus,
    required this.displayOrder,
    required this.createdAt,
  });

  SellerListingImageEntity copyWith({
    String? id,
    String? listingId,
    String? imageUrl,
    String? moderationStatus,
    int? displayOrder,
    DateTime? createdAt,
  }) {
    return SellerListingImageEntity(
      id: id ?? this.id,
      listingId: listingId ?? this.listingId,
      imageUrl: imageUrl ?? this.imageUrl,
      moderationStatus: moderationStatus ?? this.moderationStatus,
      displayOrder: displayOrder ?? this.displayOrder,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}
