/// One bookable time window returned after saving a day's availability via
/// `PUT /api/v1/service-schedules/listings/{listingId}/availability/{date}`.
class ServiceSlotEntity {
  const ServiceSlotEntity({
    required this.startsAt,
    required this.endsAt,
    required this.durationMinutes,
    required this.timeZone,
    required this.status,
  });

  final DateTime startsAt;
  final DateTime endsAt;
  final int durationMinutes;
  final String timeZone;
  final String status; // e.g. AVAILABLE
}
