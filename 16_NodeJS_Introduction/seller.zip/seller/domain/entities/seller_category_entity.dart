class CategoriesEntity {
  final String id;
  final String name;
  final String slug;
  final String categoryType;
  final bool requiresCertificate;
  final bool isActive;
  final int displayOrder;
  final DateTime createdAt;
  final DateTime updatedAt;

  const CategoriesEntity({
    required this.id,
    required this.name,
    required this.slug,
    required this.categoryType,
    required this.requiresCertificate,
    required this.isActive,
    required this.displayOrder,
    required this.createdAt,
    required this.updatedAt,
  });

  CategoriesEntity copyWith({
    String? id,
    String? name,
    String? slug,
    String? categoryType,
    bool? requiresCertificate,
    bool? isActive,
    int? displayOrder,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return CategoriesEntity(
      id: id ?? this.id,
      name: name ?? this.name,
      slug: slug ?? this.slug,
      categoryType: categoryType ?? this.categoryType,
      requiresCertificate: requiresCertificate ?? this.requiresCertificate,
      isActive: isActive ?? this.isActive,
      displayOrder: displayOrder ?? this.displayOrder,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}
