import 'package:society_seva/features/seller/domain/entities/seller_profile_entity.dart';
import 'package:society_seva/features/seller/domain/repositories/seller_onboarding_respository.dart';

class MySellerProfileUsecase {
  MySellerProfileUsecase(this._repository);

  final SellerOnboardingRespository _repository;

  Future<SellerProfileEntity?> call() => _repository.mySellerProfileRepo();
}
