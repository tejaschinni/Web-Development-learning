import 'package:society_seva/features/seller/domain/repositories/seller_onboarding_respository.dart';

class SubmitSellerUseCase {
  SubmitSellerUseCase(this._repository);

  final SellerOnboardingRespository _repository;

  Future<void> call(String sellerId) => _repository.submitDartRepo(sellerId: sellerId);
}
