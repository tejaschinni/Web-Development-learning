import 'package:society_seva/features/seller/data/models/request/seller_profile_request.dart';
import 'package:society_seva/features/seller/domain/entities/seller_profile_entity.dart';
import 'package:society_seva/features/seller/domain/repositories/seller_onboarding_respository.dart';

class UpdateSellerProfileByIdUseCase {
  UpdateSellerProfileByIdUseCase(this._repository);

  final SellerOnboardingRespository _repository;

  Future<SellerProfileEntity?> call({
    required SellerProfileRequest request,
    required String sellerId,
  }) => _repository.updateProfileRepo(request: request, sellerID: sellerId);
}
