import 'package:society_seva/features/seller/domain/entities/seller_image_entity.dart';
import 'package:society_seva/features/seller/domain/repositories/seller_onboarding_respository.dart';

class FetchImagesBySellerIdUsecase {
  FetchImagesBySellerIdUsecase(this._repository);

  final SellerOnboardingRespository _repository;

  Future<List<SellerImageEntity>?> call({required String sellerId}) async {
    return _repository.fetchSellerUploadedImagesRepo(sellerId);
  }
}
