import 'package:image_picker/image_picker.dart';
import 'package:society_seva/features/seller/domain/repositories/seller_onboarding_respository.dart';

class UploadImagesBySellerIdUsecase {
  UploadImagesBySellerIdUsecase(this._repository);

  final SellerOnboardingRespository _repository;

  Future<void> call({required String sellerId, required XFile file}) =>
      _repository.uploadSellerShopImagesRepo(sellerId, file);
}
