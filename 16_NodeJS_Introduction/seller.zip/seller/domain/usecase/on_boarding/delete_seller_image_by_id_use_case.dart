import 'package:society_seva/features/seller/domain/repositories/seller_onboarding_respository.dart';

class DeleteSellerImageByIdUseCase {
  DeleteSellerImageByIdUseCase(this._repository);

  final SellerOnboardingRespository _repository;

  Future<void> call({required String imageId, required String sellerId}) =>
      _repository.deleteUploadedSellerImagesRepo(imageId: imageId, sellerID: sellerId);
}
