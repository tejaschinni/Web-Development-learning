import 'package:flutter/material.dart';
import 'package:society_seva/features/common/presentation/screens/common_modules_screen.dart';

class SuperAdminModulesScreen extends StatelessWidget {
  const SuperAdminModulesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const ModulePlaceholderScreen(
      title: 'Super Admin',
      modules: [
        'Roles',
        'Commission rates',
        'Societies',
        'Categories',
        'Tags',
        'All orders',
        'Payment disputes and refunds',
        'Settlements',
        'Seller review rejection',
        'Review image moderation',
      ],
    );
  }
}
