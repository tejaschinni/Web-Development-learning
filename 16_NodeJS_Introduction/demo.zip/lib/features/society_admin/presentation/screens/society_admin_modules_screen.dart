import 'package:flutter/material.dart';
import 'package:society_seva/features/common/presentation/screens/common_modules_screen.dart';

class SocietyAdminModulesScreen extends StatelessWidget {
  const SocietyAdminModulesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const ModulePlaceholderScreen(
      title: 'Society Admin / Committee',
      modules: [
        'Society information and documents',
        'Buildings',
        'Floors',
        'Committee members',
        'Flats and allocations',
        'Flat members and approvals',
        'Society workers',
        'Seller approvals',
        'Seller image, KYC, and certificate moderation',
        'Listing approvals and image moderation',
        'Community posts',
        'Chat rooms',
        'Events',
        'Polls',
      ],
    );
  }
}
