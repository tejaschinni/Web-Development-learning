class SystemHealth {
  const SystemHealth({
    required this.success,
    required this.data,
    required this.message,
    required this.requestId,
  });

  final bool success;
  final HealthData data;
  final String message;
  final String requestId;

  factory SystemHealth.fromJson(Map<String, dynamic> json) {
    final dataMap =
        json['data'] as Map<String, dynamic>? ?? const <String, dynamic>{};

    return SystemHealth(
      success: json['success'] as bool? ?? false,
      data: HealthData.fromJson(dataMap),
      message: json['message'] as String? ?? 'Success',
      requestId: json['requestId'] as String? ?? 'system-health',
    );
  }
}

class HealthData {
  const HealthData({
    required this.version,
    required this.timestamp,
    required this.buildTime,
    required this.artifact,
  });

  final String version;
  final String timestamp;
  final String buildTime;
  final String artifact;

  factory HealthData.fromJson(Map<String, dynamic> json) {
    return HealthData(
      version: json['version'] as String? ?? 'unknown',
      timestamp: json['timestamp'] as String? ?? '',
      buildTime: json['buildTime'] as String? ?? '',
      artifact: json['artifact'] as String? ?? 'unknown',
    );
  }
}
