import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/core/providers/app_providers.dart';
import 'package:society_seva/features/system/data/models/system_health_model.dart';
import 'package:society_seva/features/system/data/repositories/system_repository.dart';

final systemRepositoryProvider = Provider<SystemRepository>((ref) {
  final apiClient = ref.watch(apiClientProvider);
  return SystemRepositoryImpl(apiClient);
});

final systemHealthProvider = FutureProvider<SystemHealth>((ref) async {
  final repository = ref.watch(systemRepositoryProvider);
  return repository.getHealth();
});
