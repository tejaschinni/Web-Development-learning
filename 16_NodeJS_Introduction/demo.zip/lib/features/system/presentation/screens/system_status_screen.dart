import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';

class SystemStatusScreen extends StatelessWidget {
  const SystemStatusScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Society Seva', style: GoogleFonts.hind(fontWeight: FontWeight.bold)),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const HugeIcon(icon: HugeIcons.strokeRoundedCheck, size: 64, color: Colors.green),
              const Gap(16),
              Text(
                'Foundation initialized',
                style: GoogleFonts.hind(textStyle: Theme.of(context).textTheme.headlineMedium),
              ),
              const Gap(12),
              Text(
                'Clean architecture, router, theme, and secure storage are in place.',
                textAlign: TextAlign.center,
                style: GoogleFonts.hind(textStyle: Theme.of(context).textTheme.bodyLarge),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
