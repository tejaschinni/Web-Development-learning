import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/core/providers/app_providers.dart';
import 'package:society_seva/features/location/data/models/saved_address.dart';
import 'package:society_seva/features/location/data/repositories/location_repository.dart';

final locationRepositoryProvider = Provider(
  (ref) => LocationRepository(ref.watch(apiClientProvider)),
);
final locationContextProvider =
    StateNotifierProvider<LocationController, AsyncValue<LocationContext>>(
      (ref) => LocationController(ref.watch(locationRepositoryProvider)),
    );

class LocationController extends StateNotifier<AsyncValue<LocationContext>> {
  LocationController(this._repository) : super(const AsyncValue.loading()) {
    load();
  }
  final LocationRepository _repository;

  Future<void> load() async {
    state = const AsyncValue.loading();
    state = await AsyncValue.guard(_repository.getContext);
  }

  Future<void> select(SavedAddress address) async {
    try {
      state = AsyncValue.data(await _repository.setActive(address));
    } catch (error, stackTrace) {
      state = AsyncValue.error(error, stackTrace);
      rethrow;
    }
  }

  Future<SavedAddress> save(SavedAddress address) async {
    final saved = await _repository.saveAddress(address);
    state = AsyncValue.data(await _repository.getContext());
    return saved;
  }

  Future<void> delete(String id) async {
    await _repository.deleteAddress(id);
    state = AsyncValue.data(await _repository.getContext());
  }

  Future<void> makeDefault(String id) async {
    await _repository.makeDefault(id);
    state = AsyncValue.data(await _repository.getContext());
  }
}
