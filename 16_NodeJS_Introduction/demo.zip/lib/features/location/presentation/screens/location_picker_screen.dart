import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:society_seva/features/location/data/models/saved_address.dart';
import 'package:society_seva/features/location/presentation/providers/location_provider.dart';

class LocationPickerScreen extends ConsumerWidget {
  const LocationPickerScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final locations = ref.watch(locationContextProvider);
    return Scaffold(
      appBar: AppBar(title: Text('Delivery location', style: GoogleFonts.hind())),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final saved = await Navigator.of(context)
              .push<bool>(MaterialPageRoute(builder: (_) => const _AddAddressScreen()));
          if (saved == true && context.mounted) context.pop();
        },
        icon: const Icon(Icons.add_location_alt_outlined),
        label: Text('Add address', style: GoogleFonts.hind()),
      ),
      body: locations.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, _) => Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Could not load saved addresses.\n$error', textAlign: TextAlign.center),
              const Gap(12),
              OutlinedButton(
                onPressed: () => ref.read(locationContextProvider.notifier).load(),
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
        data: (value) => value.savedAddresses.isEmpty
            ? Center(
                child: Text(
                  'Add an address to choose your delivery location.',
                  style: GoogleFonts.hind(),
                ),
              )
            : ListView(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 96),
                children: [
                  if (value.activeAddress != null)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Text(
                        'Currently delivering to ${value.activeAddress!.label}',
                        style: GoogleFonts.hind(fontWeight: FontWeight.w600),
                      ),
                    ),
                  ...value.savedAddresses.map(
                    (address) => Card(
                      child: ListTile(
                        leading: Icon(
                          address.isDefault ? Icons.location_on : Icons.location_on_outlined,
                        ),
                        title: Text(
                          address.label,
                          style: GoogleFonts.hind(fontWeight: FontWeight.w600),
                        ),
                        subtitle: Text(
                          '${address.addressLine1}, ${address.city} · ${address.pinCode}',
                          style: GoogleFonts.hind(),
                        ),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            if (value.activeAddress?.id == address.id)
                              const Icon(Icons.check_circle, color: Colors.green),
                            PopupMenuButton<String>(
                              onSelected: (action) async {
                                final controller = ref.read(locationContextProvider.notifier);
                                try {
                                  if (action == 'default') {
                                    await controller.makeDefault(address.id);
                                  } else {
                                    await controller.delete(address.id);
                                  }
                                } catch (error) {
                                  if (context.mounted) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(content: Text('Could not update address: $error')),
                                    );
                                  }
                                }
                              },
                              itemBuilder: (_) => [
                                if (!address.isDefault)
                                  const PopupMenuItem(
                                    value: 'default',
                                    child: Text('Make default'),
                                  ),
                                const PopupMenuItem(value: 'delete', child: Text('Delete address')),
                              ],
                            ),
                          ],
                        ),
                        onTap: () async {
                          try {
                            await ref.read(locationContextProvider.notifier).select(address);
                            if (context.mounted) context.pop();
                          } catch (error) {
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text('Could not select address: $error')),
                              );
                            }
                          }
                        },
                      ),
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}

class _AddAddressScreen extends ConsumerStatefulWidget {
  const _AddAddressScreen();
  @override
  ConsumerState<_AddAddressScreen> createState() => _AddAddressScreenState();
}

class _AddAddressScreenState extends ConsumerState<_AddAddressScreen> {
  final _formKey = GlobalKey<FormState>();
  final _label = TextEditingController();
  final _locality = TextEditingController();
  final _city = TextEditingController();
  final _pin = TextEditingController();
  GoogleMapController? _map;
  LatLng? _selected;
  LatLng? _devicePoint;
  LocationPermission _permission = LocationPermission.denied;
  bool _permissionReady = false;
  bool _serviceDisabled = false;
  bool _locating = false;
  bool _geocoding = false;
  bool _saving = false;
  String _countryCode = 'IN';
  String? _locationError;
  int _geocodeRequest = 0;
  static const _fallback = LatLng(20.5937, 78.9629);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _requestLocation());
  }

  @override
  void dispose() {
    _label.dispose();
    _locality.dispose();
    _city.dispose();
    _pin.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final point = _selected;
    final currentAddress = ref.watch(locationContextProvider).valueOrNull?.activeAddress;
    final initialTarget = currentAddress == null
        ? _fallback
        : LatLng(currentAddress.latitude, currentAddress.longitude);
    return Scaffold(
      appBar: AppBar(title: Text('Add delivery address', style: GoogleFonts.hind())),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            SizedBox(
              height: 300,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Stack(
                  children: [
                    GoogleMap(
                      initialCameraPosition: CameraPosition(
                        target: initialTarget,
                        zoom: currentAddress == null ? 5 : 15,
                      ),
                      gestureRecognizers: <Factory<OneSequenceGestureRecognizer>>{
                        Factory<OneSequenceGestureRecognizer>(() => EagerGestureRecognizer()),
                      },
                      myLocationEnabled:
                          _permission == LocationPermission.whileInUse ||
                          _permission == LocationPermission.always,
                      myLocationButtonEnabled: false,

                      zoomControlsEnabled: false,
                      mapToolbarEnabled: false,
                      markers: point == null
                          ? const {}
                          : {
                              Marker(
                                markerId: const MarkerId('delivery-location'),
                                position: point,
                              ),
                            },
                      onMapCreated: (controller) {
                        _map = controller;
                        final devicePoint = _devicePoint;
                        if (devicePoint != null) _moveTo(devicePoint, zoom: 16);
                      },
                      onTap: _selectPoint,
                    ),
                    Positioned(
                      right: 12,
                      top: 12,
                      child: Material(
                        color: Theme.of(context).colorScheme.surface,
                        shape: const CircleBorder(),
                        child: IconButton(
                          tooltip: 'Use my current location',
                          onPressed: _locating ? null : _requestLocation,
                          icon: _locating
                              ? const SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(strokeWidth: 2),
                                )
                              : const Icon(Icons.my_location),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const Gap(8),
            Text(
              _locationError ??
                  (_permissionReady &&
                          _permission != LocationPermission.whileInUse &&
                          _permission != LocationPermission.always
                      ? 'Location permission is off. You can still tap the map to choose a delivery point.'
                      : point == null
                      ? 'Tap the map to choose your delivery point.'
                      : 'Location selected. Address details are filled from the map.'),
              style: GoogleFonts.hind(),
            ),
            if (_serviceDisabled ||
                (_permissionReady &&
                    _permission != LocationPermission.whileInUse &&
                    _permission != LocationPermission.always))
              Align(
                alignment: Alignment.centerLeft,
                child: TextButton.icon(
                  onPressed: _serviceDisabled
                      ? Geolocator.openLocationSettings
                      : _permission == LocationPermission.deniedForever
                      ? Geolocator.openAppSettings
                      : _requestLocation,
                  icon: const Icon(Icons.location_searching),
                  label: Text(
                    _serviceDisabled
                        ? 'Open device location settings'
                        : _permission == LocationPermission.deniedForever
                        ? 'Open app settings'
                        : 'Allow location access',
                  ),
                ),
              ),
            if (_geocoding) const LinearProgressIndicator(),
            const Gap(16),
            TextFormField(
              controller: _label,
              textCapitalization: TextCapitalization.words,
              decoration: const InputDecoration(
                labelText: 'Address label',
                hintText: 'Home, Work, or another name',
              ),
              validator: _required,
            ),
            const Gap(12),
            TextFormField(
              controller: _locality,
              decoration: const InputDecoration(labelText: 'Area / locality'),
              validator: _required,
            ),
            const Gap(12),
            TextFormField(
              controller: _city,
              decoration: const InputDecoration(labelText: 'City'),
              validator: _required,
            ),
            const Gap(12),
            TextFormField(
              controller: _pin,
              decoration: const InputDecoration(labelText: 'PIN code'),
              keyboardType: TextInputType.number,
              validator: _validatePinCode,
            ),
            const Gap(20),
            FilledButton(
              onPressed: _saving || _geocoding ? null : _save,
              child: Text(
                _saving ? 'Saving…' : 'Save and use this location',
                style: GoogleFonts.hind(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  String? _required(String? value) => value == null || value.trim().isEmpty ? 'Required' : null;

  String? _validatePinCode(String? value) {
    if (value == null || value.trim().isEmpty) return 'Required';
    if (!RegExp(r'^\d{4,10}$').hasMatch(value.trim())) {
      return 'Enter a valid PIN code';
    }
    return null;
  }

  Future<void> _save() async {
    if (_geocoding || _saving) return;
    if (!_formKey.currentState!.validate()) return;
    final point = _selected;
    if (point == null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Choose a point on the map first.')));
      return;
    }
    setState(() => _saving = true);
    try {
      final address = SavedAddress(
        id: '',
        label: _label.text.trim(),
        addressLine1: _locality.text.trim(),
        city: _city.text.trim(),
        country: _countryCode,
        pinCode: _pin.text.trim(),
        latitude: point.latitude,
        longitude: point.longitude,
        isDefault: true,
      );
      final controller = ref.read(locationContextProvider.notifier);
      final saved = await controller.save(address);
      await controller.select(saved);
      if (mounted) Navigator.of(context).pop(true);
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Could not save address: $error')));
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _requestLocation() async {
    if (_locating) return;
    setState(() {
      _locating = true;
      _locationError = null;
    });
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        if (mounted) {
          setState(() {
            _serviceDisabled = true;
            _permissionReady = true;
            _locationError = 'Turn on device location to center the map on you.';
          });
        }
        return;
      }
      if (mounted) setState(() => _serviceDisabled = false);
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (!mounted) return;
      setState(() {
        _permission = permission;
        _permissionReady = true;
      });
      if (permission != LocationPermission.whileInUse && permission != LocationPermission.always) {
        setState(
          () => _locationError = permission == LocationPermission.deniedForever
              ? 'Location access is disabled for this app. You can enable it in Settings or choose a point on the map.'
              : 'Location access was not granted. You can still choose a point on the map.',
        );
        return;
      }
      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 15),
        ),
      );
      final current = LatLng(position.latitude, position.longitude);
      if (!mounted) return;
      setState(() => _devicePoint = current);
      await _moveTo(current, zoom: 16);
    } catch (_) {
      if (mounted) {
        setState(
          () => _locationError =
              'Could not get your current location. You can still choose a point on the map.',
        );
      }
    } finally {
      if (mounted) setState(() => _locating = false);
    }
  }

  Future<void> _moveTo(LatLng point, {required double zoom}) async {
    try {
      await _map?.animateCamera(
        CameraUpdate.newCameraPosition(CameraPosition(target: point, zoom: zoom)),
      );
    } catch (_) {
      // The map can be disposed while the picker is closing.
    }
  }

  Future<void> _selectPoint(LatLng point) async {
    final requestId = ++_geocodeRequest;
    setState(() {
      _selected = point;
      _geocoding = true;
      _locationError = null;
    });
    _locality.clear();
    _city.clear();
    _pin.clear();
    try {
      final places = await Geocoding().placemarkFromCoordinates(point.latitude, point.longitude);
      if (!mounted || requestId != _geocodeRequest) return;
      if (places.isEmpty) throw StateError('No address found for this point.');
      final place = places.first;
      final locality = [place.subLocality, place.thoroughfare, place.name]
          .whereType<String>()
          .map((value) => value.trim())
          .where((value) => value.isNotEmpty)
          .toSet()
          .join(', ');
      _locality.text = locality.isNotEmpty ? locality : (place.locality ?? '');
      _city.text = [place.locality, place.subAdministrativeArea, place.administrativeArea]
          .whereType<String>()
          .map((value) => value.trim())
          .firstWhere((value) => value.isNotEmpty, orElse: () => '');
      _pin.text = place.postalCode ?? '';
      _countryCode = place.isoCountryCode?.isNotEmpty == true ? place.isoCountryCode! : 'IN';
      if (_locality.text.isEmpty || _city.text.isEmpty) {
        setState(
          () =>
              _locationError = 'Some address details were unavailable. Please complete the fields.',
        );
      }
    } catch (_) {
      if (mounted && requestId == _geocodeRequest) {
        setState(
          () => _locationError =
              'Could not look up this address. Fill in the address fields to continue.',
        );
      }
    } finally {
      if (mounted && requestId == _geocodeRequest) {
        setState(() => _geocoding = false);
      }
    }
  }
}
