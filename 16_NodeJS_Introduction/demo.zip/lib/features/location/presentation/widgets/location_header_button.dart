import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/location/presentation/providers/location_provider.dart';

class LocationHeaderButton extends ConsumerWidget {
  const LocationHeaderButton({super.key, this.compact = false});

  final bool compact;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final location = ref.watch(locationContextProvider).valueOrNull?.activeAddress;

    return GestureDetector(
      onTap: () => context.push('/locations'),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: const Color.fromARGB(255, 241, 249, 243),
          borderRadius: BorderRadius.circular(18),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const HugeIcon(icon: HugeIcons.strokeRoundedLocation01, size: 20),
            const Gap(8),
            Flexible(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    location == null ? 'Choose delivery location' : location.label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: AppTheme.display(13),
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          location == null
                              ? 'Choose delivery location'
                              : '${location.addressLine1}, ${location.city}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: GoogleFonts.hind(
                            fontSize: compact ? 13 : 14,
                            color: AppColors.muted,
                          ),
                        ),
                      ),
                      const HugeIcon(icon: HugeIcons.strokeRoundedArrowDown01, size: 14),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
