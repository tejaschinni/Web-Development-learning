class SavedAddress {
  const SavedAddress({
    required this.id,
    required this.label,
    required this.addressLine1,
    required this.city,
    required this.country,
    required this.pinCode,
    required this.latitude,
    required this.longitude,
    required this.isDefault,
  });

  final String id;
  final String label;
  final String addressLine1;
  final String city;
  final String country;
  final String pinCode;
  final double latitude;
  final double longitude;
  final bool isDefault;

  factory SavedAddress.fromJson(Map<String, dynamic> json) => SavedAddress(
    id: json['id'] as String,
    label: json['label'] as String? ?? 'Address',
    addressLine1: json['addressLine1'] as String? ?? '',
    city: json['city'] as String? ?? '',
    country: json['country'] as String? ?? 'IN',
    pinCode: '${json['pinCode'] ?? ''}',
    latitude: (json['latitude'] as num?)?.toDouble() ?? 0,
    longitude: (json['longitude'] as num?)?.toDouble() ?? 0,
    isDefault: json['isDefault'] as bool? ?? false,
  );

  Map<String, dynamic> toJson({bool makeDefault = false}) => {
    'label': label,
    'addressLine1': addressLine1,
    'city': city,
    'country': country,
    'pinCode': int.tryParse(pinCode) ?? pinCode,
    'latitude': latitude,
    'longitude': longitude,
    'makeDefault': makeDefault,
  };
}

class LocationContext {
  const LocationContext({
    this.activeAddress,
    this.discoveryMode = 'NEARBY',
    this.radiusKm = 5,
    this.savedAddresses = const [],
  });

  final SavedAddress? activeAddress;
  final String discoveryMode;
  final int radiusKm;
  final List<SavedAddress> savedAddresses;

  factory LocationContext.fromJson(Map<String, dynamic> json) {
    final addresses = (json['savedAddresses'] as List? ?? const [])
        .whereType<Map>()
        .map((item) => SavedAddress.fromJson(Map<String, dynamic>.from(item)))
        .toList();
    final activeId = json['activeAddressId'] as String?;
    final activeJson = json['activeAddress'];
    return LocationContext(
      activeAddress: activeJson is Map
          ? SavedAddress.fromJson(Map<String, dynamic>.from(activeJson))
          : addresses.where((item) => item.id == activeId).firstOrNull,
      discoveryMode: json['discoveryMode'] as String? ?? 'NEARBY',
      radiusKm: (json['radiusKm'] as num?)?.toInt() ?? 5,
      savedAddresses: addresses,
    );
  }
}
