import 'package:society_seva/core/mock/mock_data.dart';
import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/core/network/request_logger.dart';
import 'package:society_seva/features/location/data/models/saved_address.dart';

class LocationRepository {
  LocationRepository(this._client);
  final ApiClient _client;

  Future<LocationContext> getContext() async {
    try {
      final response = await _client.get(ApiEndpoints.locationContext);
      return LocationContext.fromJson(
        Map<String, dynamic>.from(response.data as Map),
      );
    } catch (_) {
      return MockData.locationContext;
    }
  }

  Future<List<SavedAddress>> getAddresses() async {
    try {
      final response = await _client.get(ApiEndpoints.locationAddresses);
      return (response.data as List)
          .whereType<Map>()
          .map((item) => SavedAddress.fromJson(Map<String, dynamic>.from(item)))
          .toList();
    } catch (_) {
      return [MockData.primaryAddress];
    }
  }

  Future<SavedAddress> saveAddress(
    SavedAddress address, {
    bool makeDefault = true,
  }) async {
    final payload = address.toJson(makeDefault: makeDefault);
    RequestLogger.logPost(
      endpoint: ApiEndpoints.locationAddresses,
      payload: payload,
      method: 'POST',
    );

    try {
      final response = await _client.post(
        ApiEndpoints.locationAddresses,
        data: payload,
      );
      return SavedAddress.fromJson(
        Map<String, dynamic>.from(response.data as Map),
      );
    } catch (_) {
      return address;
    }
  }

  Future<LocationContext> setActive(
    SavedAddress address, {
    int radiusKm = 5,
  }) async {
    final payload = {
      'addressId': address.id,
      'discoveryMode': 'NEARBY',
      'radiusKm': radiusKm,
    };
    try {
      final response = await _client.put(
        ApiEndpoints.activeLocation,
        data: payload,
      );
      return LocationContext.fromJson(
        Map<String, dynamic>.from(response.data as Map),
      );
    } catch (_) {
      return LocationContext(
        activeAddress: address,
        savedAddresses: [address],
      );
    }
  }

  Future<void> deleteAddress(String id) async {
    try {
      await _client.delete(ApiEndpoints.locationAddress(id));
    } catch (_) {}
  }

  Future<void> makeDefault(String id) async {
    try {
      await _client.patch(
        ApiEndpoints.locationAddress(id),
        data: {'makeDefault': true},
      );
    } catch (_) {}
  }
}
