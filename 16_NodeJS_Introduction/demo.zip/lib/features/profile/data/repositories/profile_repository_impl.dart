import 'package:society_seva/features/profile/data/datasources/profile_remote_data_source.dart';
import 'package:society_seva/features/profile/data/models/update_profile_request.dart';
import 'package:society_seva/features/profile/data/models/phone_number_requests.dart';
import 'package:society_seva/features/profile/domain/entities/user_profile.dart';
import 'package:society_seva/features/profile/domain/repositories/profile_repository.dart';

class ProfileRepositoryImpl implements ProfileRepository {
  ProfileRepositoryImpl(this._remoteDataSource);

  final ProfileRemoteDataSource _remoteDataSource;

  @override
  Future<UserProfile> getCurrentUser() async {
    return (await _remoteDataSource.getCurrentUser()).toEntity();
  }

  @override
  Future<UserProfile> updateProfile(UpdateProfileRequest request) async {
    return (await _remoteDataSource.updateProfile(request)).toEntity();
  }

  @override
  Future<void> deleteAccount() {
    return _remoteDataSource.deleteAccount();
  }

  @override
  Future<Map<String, dynamic>> sendPhoneNumberOtp(
    SendPhoneNumberOtpRequest request,
  ) {
    return _remoteDataSource.sendPhoneNumberOtp(request);
  }

  @override
  Future<UserProfile> verifyPhoneNumberOtp(
    VerifyPhoneNumberOtpRequest request,
  ) async {
    return (await _remoteDataSource.verifyPhoneNumberOtp(request)).toEntity();
  }
}
