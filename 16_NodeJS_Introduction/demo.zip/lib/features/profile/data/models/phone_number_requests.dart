class SendPhoneNumberOtpRequest {
  const SendPhoneNumberOtpRequest({required this.mobileNumber});

  final String mobileNumber;

  Map<String, dynamic> toJson() => {'mobileNumber': mobileNumber};
}

class VerifyPhoneNumberOtpRequest {
  const VerifyPhoneNumberOtpRequest({
    required this.mobileNumber,
    required this.otp,
  });

  final String mobileNumber;
  final String otp;

  Map<String, dynamic> toJson() => {'mobileNumber': mobileNumber, 'otp': otp};
}
