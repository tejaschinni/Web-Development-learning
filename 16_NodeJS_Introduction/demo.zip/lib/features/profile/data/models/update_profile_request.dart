class UpdateProfileRequest {
  const UpdateProfileRequest({
    required this.fullName,
    required this.gender,
    required this.dateOfBirth,
    required this.email,
    required this.preferredLanguage,
    required this.profilePhotoUrl,
  });

  final String fullName;
  final String gender;
  final String dateOfBirth;
  final String email;
  final String preferredLanguage;
  final String profilePhotoUrl;

  Map<String, dynamic> toJson() {
    return {
      'fullName': fullName,
      'gender': gender,
      'dateOfBirth': dateOfBirth,
      'email': email,
      'preferredLanguage': preferredLanguage,
      'profilePhotoUrl': profilePhotoUrl,
    };
  }
}
