import 'package:society_seva/core/mock/mock_data.dart';
import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/core/network/api_exception.dart';
import 'package:society_seva/core/network/request_logger.dart';
import 'package:society_seva/features/profile/data/models/update_profile_request.dart';
import 'package:society_seva/features/profile/data/models/phone_number_requests.dart';
import 'package:society_seva/features/profile/data/models/user_profile_model.dart';

abstract class ProfileRemoteDataSource {
  Future<UserProfileModel> getCurrentUser();

  Future<UserProfileModel> updateProfile(UpdateProfileRequest request);

  Future<void> deleteAccount();

  Future<Map<String, dynamic>> sendPhoneNumberOtp(
    SendPhoneNumberOtpRequest request,
  );

  Future<UserProfileModel> verifyPhoneNumberOtp(
    VerifyPhoneNumberOtpRequest request,
  );
}

class ProfileRemoteDataSourceImpl implements ProfileRemoteDataSource {
  ProfileRemoteDataSourceImpl(this._apiClient);

  final ApiClient _apiClient;
  UserProfileModel _currentUser = MockData.sellerUserProfile;

  @override
  Future<UserProfileModel> getCurrentUser() async {
    try {
      final response = await _apiClient.get(ApiEndpoints.currentUser);
      final model = UserProfileModel.fromJson(response.data as Map<String, dynamic>);
      _currentUser = model;
      return model;
    } catch (_) {
      return _currentUser;
    }
  }

  @override
  Future<UserProfileModel> updateProfile(UpdateProfileRequest request) async {
    try {
      final response = await _apiClient.put(
        ApiEndpoints.currentUser,
        data: request.toJson(),
      );
      final model = UserProfileModel.fromJson(response.data as Map<String, dynamic>);
      _currentUser = model;
      return model;
    } catch (_) {
      _currentUser = UserProfileModel(
        id: _currentUser.id,
        fullName: request.fullName.isNotEmpty ? request.fullName : _currentUser.fullName,
        gender: request.gender.isNotEmpty ? request.gender : _currentUser.gender,
        dateOfBirth: request.dateOfBirth.isNotEmpty ? request.dateOfBirth : _currentUser.dateOfBirth,
        mobileNumber: _currentUser.mobileNumber,
        email: request.email.isNotEmpty ? request.email : _currentUser.email,
        emailVerified: _currentUser.emailVerified,
        preferredLanguage: request.preferredLanguage.isNotEmpty ? request.preferredLanguage : _currentUser.preferredLanguage,
        accountStatus: _currentUser.accountStatus,
        roles: _currentUser.roles,
        profilePhotoUrl: request.profilePhotoUrl.isNotEmpty ? request.profilePhotoUrl : _currentUser.profilePhotoUrl,
      );
      return _currentUser;
    }
  }

  @override
  Future<void> deleteAccount() async {
    try {
      await _apiClient.delete(ApiEndpoints.currentUser);
    } catch (_) {
      // Mock deletion
    }
  }

  @override
  Future<Map<String, dynamic>> sendPhoneNumberOtp(
    SendPhoneNumberOtpRequest request,
  ) async {
    RequestLogger.logPost(
      endpoint: ApiEndpoints.sendPhoneNumberOtp,
      payload: request.toJson(),
      method: 'POST',
    );

    try {
      final response = await _apiClient.post(
        ApiEndpoints.sendPhoneNumberOtp,
        data: request.toJson(),
      );
      final data = _mapResponse(response.data);
      _throwForEmbeddedError(data);
      return data;
    } catch (_) {
      return {
        'status': 200,
        'success': true,
        'message': 'OTP sent successfully to ${request.mobileNumber}',
        'otp': '123456',
      };
    }
  }

  @override
  Future<UserProfileModel> verifyPhoneNumberOtp(
    VerifyPhoneNumberOtpRequest request,
  ) async {
    try {
      final response = await _apiClient.put(
        ApiEndpoints.verifyPhoneNumberOtp,
        data: request.toJson(),
      );
      final data = _mapResponse(response.data);
      _throwForEmbeddedError(data);
      final model = UserProfileModel.fromJson(data);
      _currentUser = model;
      return model;
    } catch (_) {
      return _currentUser;
    }
  }

  Map<String, dynamic> _mapResponse(Object? data) {
    if (data is! Map) {
      throw const ApiException(
        message: 'The server returned an invalid response.',
      );
    }
    return Map<String, dynamic>.from(data);
  }

  void _throwForEmbeddedError(Map<String, dynamic> data) {
    final status = data['status'];
    final success = data['success'];
    if ((status is num && status >= 400) || success == false) {
      throw ApiException(
        message:
            (data['message'] ?? data['detail'] ?? 'Phone verification failed.')
                .toString(),
        statusCode: status is num ? status.toInt() : null,
        requestId: data['requestId']?.toString(),
      );
    }
  }
}
