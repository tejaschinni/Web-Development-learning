import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:image_picker/image_picker.dart';

import 'package:society_seva/features/profile/data/models/update_profile_request.dart';
import 'package:society_seva/features/profile/presentation/providers/profile_provider.dart';

class EditProfileScreen extends ConsumerStatefulWidget {
  const EditProfileScreen({super.key});

  @override
  ConsumerState<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends ConsumerState<EditProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  final _fullNameController = TextEditingController();
  final _emailController = TextEditingController();

  final _imagePicker = ImagePicker();

  static const _primary = Color(0xFF176B55);
  static const _background = Color(0xFFF6F8F7);
  static const _border = Color(0xFFE5EAE7);
  static const _textColor = Color(0xFF202925);
  static const _mutedColor = Color(0xFF78837D);

  static const _genders = <String>['Male', 'Female', 'Other', 'Prefer not to say'];

  static const _languages = <String, String>{
    'en': 'English',
    'hi': 'हिन्दी (Hindi)',
    'mr': 'मराठी (Marathi)',
  };

  String? _gender;
  String _language = 'en';
  DateTime? _dateOfBirth;
  File? _selectedImage;
  String? _existingPhotoUrl;
  bool _initialized = false;

  @override
  void dispose() {
    _fullNameController.dispose();
    _emailController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(profileControllerProvider);
    final profile = state.profile;

    if (!_initialized && profile != null) {
      _fullNameController.text = profile.fullName;
      _emailController.text = profile.email;

      _gender = _normalizeGender(profile.gender);
      _language = _languages.containsKey(profile.preferredLanguage)
          ? profile.preferredLanguage
          : 'en';

      _dateOfBirth = DateTime.tryParse(profile.dateOfBirth);
      _existingPhotoUrl = profile.profilePhotoUrl;
      _initialized = true;
    }

    final isSaving = state.status == ProfileStatus.updating;

    return Scaffold(
      backgroundColor: _background,
      appBar: AppBar(
        backgroundColor: _background,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          onPressed: () => Navigator.of(context).maybePop(),
          icon: const Icon(Icons.arrow_back_rounded),
        ),
        title: Text(
          'Edit profile',
          style: GoogleFonts.hind(fontSize: 21, fontWeight: FontWeight.w600, color: _textColor),
        ),
        centerTitle: false,
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
                children: [
                  _buildHeader(),
                  const Gap(24),
                  _buildPhotoSection(),
                  const Gap(28),
                  _buildSectionTitle(
                    'Personal information',
                    'Keep your profile details up to date.',
                  ),
                  const Gap(16),
                  _buildCard(
                    children: [
                      _buildTextField(
                        controller: _fullNameController,
                        label: 'Full name',
                        hint: 'Enter your full name',
                        icon: HugeIcons.strokeRoundedUser,
                        validator: (value) =>
                            value == null || value.trim().isEmpty ? 'Full name is required' : null,
                      ),
                      _buildDivider(),
                      _buildDropdown<String>(
                        label: 'Gender',
                        value: _gender,
                        hint: 'Select gender',
                        icon: HugeIcons.strokeRoundedUserCircle,
                        items: _genders
                            .map((gender) => DropdownMenuItem(value: gender, child: Text(gender)))
                            .toList(),
                        validator: (value) => value == null ? 'Please select your gender' : null,
                        onChanged: (value) => setState(() => _gender = value),
                      ),
                      _buildDivider(),
                      _buildDateField(),
                      _buildDivider(),
                      _buildTextField(
                        controller: _emailController,
                        label: 'Email address',
                        hint: 'you@example.com',
                        icon: HugeIcons.strokeRoundedMail01,
                        keyboardType: TextInputType.emailAddress,
                        validator: (value) {
                          if (value == null || value.trim().isEmpty) {
                            return 'Email is required';
                          }
                          if (!RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(value.trim())) {
                            return 'Enter a valid email address';
                          }
                          return null;
                        },
                      ),
                    ],
                  ),
                  const Gap(28),
                  _buildSectionTitle('Preferences', 'Choose your preferred app language.'),
                  const Gap(16),
                  _buildCard(
                    children: [
                      _buildDropdown<String>(
                        label: 'App language',
                        value: _language,
                        hint: 'Select language',
                        icon: HugeIcons.strokeRoundedLanguageCircle,
                        items: _languages.entries
                            .map(
                              (entry) =>
                                  DropdownMenuItem(value: entry.key, child: Text(entry.value)),
                            )
                            .toList(),
                        onChanged: (value) {
                          if (value != null) {
                            setState(() => _language = value);
                          }
                        },
                      ),
                    ],
                  ),
                  if (state.errorMessage != null) ...[
                    const Gap(16),
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFF0EF),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Text(
                        state.errorMessage!,
                        style: GoogleFonts.hind(color: Colors.red.shade800, fontSize: 14),
                      ),
                    ),
                  ],
                  const Gap(20),
                  Center(
                    child: Text(
                      'Your information helps personalize Society Seva.',
                      textAlign: TextAlign.center,
                      style: GoogleFonts.hind(fontSize: 12, color: _mutedColor),
                    ),
                  ),
                ],
              ),
            ),
            _buildBottomBar(isSaving),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Make it yours.',
          style: GoogleFonts.hind(
            fontSize: 29,
            height: 1.2,
            fontWeight: FontWeight.w700,
            color: _textColor,
          ),
        ),
        const Gap(6),
        Text(
          'Add your details to make your community experience better.',
          style: GoogleFonts.hind(fontSize: 15, height: 1.5, color: _mutedColor),
        ),
      ],
    );
  }

  Widget _buildPhotoSection() {
    return Center(
      child: Column(
        children: [
          Stack(
            clipBehavior: Clip.none,
            children: [
              Container(
                width: 116,
                height: 116,
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white,
                  border: Border.all(color: const Color(0xFFDCE9E1), width: 1.5),
                ),
                child: ClipOval(
                  child: _selectedImage != null
                      ? Image.file(_selectedImage!, fit: BoxFit.cover, width: 108, height: 108)
                      : (_existingPhotoUrl != null && _existingPhotoUrl!.isNotEmpty)
                      ? Image.network(
                          _existingPhotoUrl!,
                          fit: BoxFit.cover,
                          errorBuilder: (_, _, _) => _photoPlaceholder(),
                        )
                      : _photoPlaceholder(),
                ),
              ),
              Positioned(
                right: 0,
                bottom: 2,
                child: Material(
                  color: _primary,
                  shape: const CircleBorder(),
                  child: InkWell(
                    customBorder: const CircleBorder(),
                    onTap: _showPhotoOptions,
                    child: const Padding(
                      padding: EdgeInsets.all(10),
                      child: Icon(Icons.camera_alt_rounded, size: 19, color: Colors.white),
                    ),
                  ),
                ),
              ),
            ],
          ),
          const Gap(12),
          Text(
            'Your profile photo',
            style: GoogleFonts.hind(fontSize: 16, fontWeight: FontWeight.w600, color: _textColor),
          ),
          const Gap(3),
          Text(
            'A friendly face makes a great first impression.',
            textAlign: TextAlign.center,
            style: GoogleFonts.hind(fontSize: 13, color: _mutedColor),
          ),
          const Gap(10),
          TextButton.icon(
            onPressed: _showPhotoOptions,
            icon: const Icon(Icons.add_a_photo_outlined, size: 17),
            label: Text(
              _selectedImage == null ? 'Change photo' : 'Choose another photo',
              style: GoogleFonts.hind(fontWeight: FontWeight.w600),
            ),
            style: TextButton.styleFrom(foregroundColor: _primary),
          ),
        ],
      ),
    );
  }

  Widget _photoPlaceholder() {
    return Container(
      color: const Color(0xFFE8F1EB),
      alignment: Alignment.center,
      child: const HugeIcon(icon: HugeIcons.strokeRoundedUser, size: 48, color: _primary),
    );
  }

  Future<void> _showPhotoOptions() async {
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
      ),
      builder: (sheetContext) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Profile photo',
                  style: GoogleFonts.hind(
                    fontSize: 21,
                    fontWeight: FontWeight.w700,
                    color: _textColor,
                  ),
                ),
                const Gap(6),
                Text(
                  'Choose how you would like to add your photo.',
                  style: GoogleFonts.hind(color: _mutedColor),
                ),
                const Gap(20),
                Row(
                  children: [
                    Expanded(
                      child: _photoOption(
                        icon: Icons.photo_library_outlined,
                        title: 'Gallery',
                        onTap: () {
                          Navigator.pop(sheetContext);
                          _pickImage(ImageSource.gallery);
                        },
                      ),
                    ),
                    const Gap(14),
                    Expanded(
                      child: _photoOption(
                        icon: Icons.camera_alt_outlined,
                        title: 'Camera',
                        onTap: () {
                          Navigator.pop(sheetContext);
                          _pickImage(ImageSource.camera);
                        },
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _photoOption({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 22),
        decoration: BoxDecoration(
          color: _background,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: _border),
        ),
        child: Column(
          children: [
            Icon(icon, color: _primary, size: 29),
            const Gap(9),
            Text(
              title,
              style: GoogleFonts.hind(fontWeight: FontWeight.w600, color: _textColor),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final image = await _imagePicker.pickImage(
        source: source,
        imageQuality: 85,
        maxWidth: 1200,
        maxHeight: 1200,
      );

      if (image != null && mounted) {
        setState(() => _selectedImage = File(image.path));
      }
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Unable to select the photo. Please try again.', style: GoogleFonts.hind()),
        ),
      );
    }
  }

  Widget _buildSectionTitle(String title, String subtitle) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: GoogleFonts.hind(fontSize: 19, fontWeight: FontWeight.w700, color: _textColor),
        ),
        const Gap(3),
        Text(subtitle, style: GoogleFonts.hind(fontSize: 13, color: _mutedColor)),
      ],
    );
  }

  Widget _buildCard({required List<Widget> children}) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: _border),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF1D392B).withValues(alpha: 0.035),
            blurRadius: 18,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(children: children),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required dynamic icon,
    required String? Function(String?) validator,
    TextInputType? keyboardType,
  }) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 5, 16, 5),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        style: GoogleFonts.hind(fontSize: 15, color: _textColor),
        decoration: _inputDecoration(label: label, hint: hint, icon: icon),
        validator: validator,
      ),
    );
  }

  Widget _buildDropdown<T>({
    required String label,
    required T? value,
    required String hint,
    required dynamic icon,
    required List<DropdownMenuItem<T>> items,
    required ValueChanged<T?> onChanged,
    String? Function(T?)? validator,
  }) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 5, 16, 5),
      child: DropdownButtonFormField<T>(
        initialValue: value,
        isExpanded: true,
        items: items,
        onChanged: onChanged,
        validator: validator,
        icon: const Icon(Icons.keyboard_arrow_down_rounded, color: _mutedColor),
        style: GoogleFonts.hind(fontSize: 15, color: _textColor),
        decoration: _inputDecoration(label: label, hint: hint, icon: icon),
        dropdownColor: Colors.white,
        borderRadius: BorderRadius.circular(16),
      ),
    );
  }

  Widget _buildDateField() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 5, 16, 5),
      child: FormField<DateTime>(
        initialValue: _dateOfBirth,
        validator: (_) => _dateOfBirth == null ? 'Date of birth is required' : null,
        builder: (field) {
          return InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: _selectDate,
            child: InputDecorator(
              decoration:
                  _inputDecoration(
                    label: 'Date of birth',
                    hint: 'Select your date of birth',
                    icon: HugeIcons.strokeRoundedCalendar03,
                  ).copyWith(
                    errorText: field.errorText,
                    suffixIcon: const Icon(
                      Icons.calendar_month_outlined,
                      color: _mutedColor,
                      size: 21,
                    ),
                  ),
              child: Text(
                _dateOfBirth == null ? 'Select your date of birth' : _formatDate(_dateOfBirth!),
                style: GoogleFonts.hind(
                  fontSize: 15,
                  color: _dateOfBirth == null ? _mutedColor : _textColor,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Future<void> _selectDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _dateOfBirth ?? DateTime(now.year - 18, now.month, now.day),
      firstDate: DateTime(1900),
      lastDate: now.subtract(Duration(days: 3250)),
      helpText: 'SELECT DATE OF BIRTH',
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: _primary,
              onPrimary: Colors.white,
              surface: Colors.white,
              onSurface: _textColor,
            ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null && mounted) {
      setState(() => _dateOfBirth = picked);
      _formKey.currentState?.validate();
    }
  }

  InputDecoration _inputDecoration({
    required String label,
    required String hint,
    required dynamic icon,
  }) {
    return InputDecoration(
      labelText: label,
      hintText: hint,
      floatingLabelBehavior: FloatingLabelBehavior.always,
      hintStyle: GoogleFonts.hind(fontSize: 14, color: _mutedColor),
      labelStyle: GoogleFonts.hind(fontSize: 14, color: _mutedColor),
      prefixIcon: Center(
        widthFactor: 1,
        child: HugeIcon(icon: icon, size: 21, color: _primary),
      ),
      prefixIconConstraints: const BoxConstraints(minWidth: 42, minHeight: 24),
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 17),
      border: InputBorder.none,
      enabledBorder: InputBorder.none,
      focusedBorder: InputBorder.none,
      errorBorder: InputBorder.none,
      focusedErrorBorder: InputBorder.none,
    );
  }

  Widget _buildDivider() {
    return const Padding(
      padding: EdgeInsets.symmetric(horizontal: 16),
      child: Divider(height: 1, color: _border),
    );
  }

  Widget _buildBottomBar(bool isSaving) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 16),
      decoration: BoxDecoration(
        color: Colors.white,
        border: const Border(top: BorderSide(color: _border)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.025),
            blurRadius: 12,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: SizedBox(
          width: double.infinity,
          height: 54,
          child: FilledButton(
            onPressed: isSaving ? null : _save,
            style: FilledButton.styleFrom(
              backgroundColor: _primary,
              disabledBackgroundColor: _primary.withValues(alpha: 0.55),
              foregroundColor: Colors.white,
              elevation: 0,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            ),
            child: isSaving
                ? const SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'Save changes',
                        style: GoogleFonts.hind(fontSize: 16, fontWeight: FontWeight.w600),
                      ),
                      const Gap(8),
                      const Icon(Icons.arrow_forward_rounded, size: 19),
                    ],
                  ),
          ),
        ),
      ),
    );
  }

  String? _normalizeGender(String? gender) {
    if (gender == null || gender.isEmpty) return null;

    for (final option in _genders) {
      if (option.toLowerCase() == gender.toLowerCase()) {
        return option;
      }
    }

    return null;
  }

  String _formatDate(DateTime date) {
    final year = date.year.toString().padLeft(4, '0');
    final month = date.month.toString().padLeft(2, '0');
    final day = date.day.toString().padLeft(2, '0');
    return '$day/$month/$year';
  }

  Future<void> _save() async {
    FocusScope.of(context).unfocus();

    if (!_formKey.currentState!.validate()) return;

    // IMPORTANT:
    // Upload _selectedImage to your backend first and use the returned
    // URL here. UpdateProfileRequest currently accepts a URL, not a File.
    // Do not send _selectedImage.path as profilePhotoUrl.

    if (_selectedImage != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Photo selected. Connect your profile-photo upload API to save it.',
            style: GoogleFonts.hind(),
          ),
        ),
      );
      return;
    }

    final dob = _dateOfBirth!;

    await ref
        .read(profileControllerProvider.notifier)
        .updateProfile(
          UpdateProfileRequest(
            fullName: _fullNameController.text.trim(),
            gender: _gender!,
            dateOfBirth:
                '${dob.year.toString().padLeft(4, '0')}-'
                '${dob.month.toString().padLeft(2, '0')}-'
                '${dob.day.toString().padLeft(2, '0')}',
            email: _emailController.text.trim(),
            preferredLanguage: _language,
            profilePhotoUrl: _existingPhotoUrl ?? '',
          ),
        );

    if (!mounted) return;

    final state = ref.read(profileControllerProvider);

    if (state.status == ProfileStatus.loaded) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Profile updated successfully', style: GoogleFonts.hind()),
          behavior: SnackBarBehavior.floating,
        ),
      );
      Navigator.of(context).pop();
    }
  }
}
