import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/features/profile/data/models/phone_number_requests.dart';
import 'package:society_seva/features/profile/presentation/providers/profile_provider.dart';

enum _PhoneStep { mobileNumber, otp }

class PhoneNumberVerificationScreen extends ConsumerStatefulWidget {
  const PhoneNumberVerificationScreen({super.key});

  @override
  ConsumerState<PhoneNumberVerificationScreen> createState() =>
      _PhoneNumberVerificationScreenState();
}

class _PhoneNumberVerificationScreenState extends ConsumerState<PhoneNumberVerificationScreen> {
  final _mobileController = TextEditingController();
  final _otpController = TextEditingController();
  _PhoneStep _step = _PhoneStep.mobileNumber;
  String? _maskedMobile;
  String? _errorMessage;
  bool _isLoading = false;

  @override
  void dispose() {
    _mobileController.dispose();
    _otpController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Verify mobile number', style: GoogleFonts.hind())),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const HugeIcon(
                  icon: HugeIcons.strokeRoundedSmartphone,
                  size: 64,
                  color: Colors.green,
                ),
                const Gap(16),
                Text(
                  _step == _PhoneStep.mobileNumber
                      ? 'Add your mobile number'
                      : 'Enter the verification OTP',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.hind(textStyle: Theme.of(context).textTheme.headlineSmall),
                ),
                const Gap(8),
                Text(
                  _step == _PhoneStep.mobileNumber
                      ? 'A verified Indian mobile number is required to use Society Seva.'
                      : 'Enter the 6-digit OTP sent to ${_maskedMobile ?? 'your mobile number'}.',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.hind(),
                ),
                const Gap(24),
                if (_errorMessage != null) ...[
                  Text(
                    _errorMessage!,
                    textAlign: TextAlign.center,
                    style: GoogleFonts.hind(
                      textStyle: GoogleFonts.hind(color: Colors.red.shade700),
                    ),
                  ),
                  const Gap(16),
                ],
                if (_step == _PhoneStep.mobileNumber) _mobileNumberForm() else _otpForm(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _mobileNumberForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        TextField(
          controller: _mobileController,
          enabled: !_isLoading,
          keyboardType: TextInputType.phone,
          maxLength: 10,
          decoration: const InputDecoration(labelText: '10-digit Indian mobile number'),
        ),
        const Gap(16),
        _actionButton('Send OTP', _sendOtp),
      ],
    );
  }

  Widget _otpForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        TextField(
          controller: _otpController,
          enabled: !_isLoading,
          keyboardType: TextInputType.number,
          maxLength: 6,
          decoration: const InputDecoration(labelText: '6-digit OTP'),
        ),
        const Gap(16),
        _actionButton('Verify mobile number', _verifyOtp),
        TextButton(
          onPressed: _isLoading ? null : _sendOtp,
          child: Text('Send OTP again', style: GoogleFonts.hind()),
        ),
        TextButton(
          onPressed: _isLoading
              ? null
              : () => setState(() {
                  _step = _PhoneStep.mobileNumber;
                  _errorMessage = null;
                }),
          child: Text('Change mobile number', style: GoogleFonts.hind()),
        ),
      ],
    );
  }

  Widget _actionButton(String label, Future<void> Function() action) {
    return FilledButton(
      onPressed: _isLoading ? null : action,
      child: _isLoading
          ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2))
          : Text(label, style: GoogleFonts.hind()),
    );
  }

  Future<void> _sendOtp() async {
    final mobileNumber = _mobileController.text.trim();
    if (!RegExp(r'^[6-9]\d{9}$').hasMatch(mobileNumber)) {
      _showError('Enter a valid 10-digit Indian mobile number.');
      return;
    }

    await _run(() async {
      final response = await ref
          .read(profileRepositoryProvider)
          .sendPhoneNumberOtp(SendPhoneNumberOtpRequest(mobileNumber: mobileNumber));
      _maskedMobile = response['maskedMobile']?.toString();
      _step = _PhoneStep.otp;
    });
  }

  Future<void> _verifyOtp() async {
    final otp = _otpController.text.trim();
    if (!RegExp(r'^\d{6}$').hasMatch(otp)) {
      _showError('OTP must be exactly 6 digits.');
      return;
    }

    await _run(() async {
      await ref
          .read(profileRepositoryProvider)
          .verifyPhoneNumberOtp(
            VerifyPhoneNumberOtpRequest(mobileNumber: _mobileController.text.trim(), otp: otp),
          );
      if (!mounted) {
        return;
      }
      ref.read(profileControllerProvider.notifier).load(force: true);
      context.go('/');
    });
  }

  Future<void> _run(Future<void> Function() action) async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    try {
      await action();
    } catch (error) {
      if (mounted) {
        _showError(error.toString());
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
    if (mounted) {
      setState(() {});
    }
  }

  void _showError(String message) {
    if (!mounted) {
      return;
    }
    setState(() => _errorMessage = message);
  }
}
