import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/core/providers/app_providers.dart';
import 'package:society_seva/features/auth/presentation/providers/auth_provider.dart';
import 'package:society_seva/features/profile/data/datasources/profile_remote_data_source.dart';
import 'package:society_seva/features/profile/data/models/update_profile_request.dart';
import 'package:society_seva/features/profile/data/repositories/profile_repository_impl.dart';
import 'package:society_seva/features/profile/domain/entities/user_profile.dart';
import 'package:society_seva/features/profile/domain/repositories/profile_repository.dart';
import 'package:society_seva/features/profile/domain/usecases/delete_account_usecase.dart';
import 'package:society_seva/features/profile/domain/usecases/get_current_user_usecase.dart';
import 'package:society_seva/features/profile/domain/usecases/update_profile_usecase.dart';

final profileRemoteDataSourceProvider = Provider<ProfileRemoteDataSource>((
  ref,
) {
  final apiClient = ref.watch(apiClientProvider);
  return ProfileRemoteDataSourceImpl(apiClient);
});

final profileRepositoryProvider = Provider<ProfileRepository>((ref) {
  return ProfileRepositoryImpl(ref.watch(profileRemoteDataSourceProvider));
});

final getCurrentUserUseCaseProvider = Provider<GetCurrentUserUseCase>((ref) {
  return GetCurrentUserUseCase(ref.watch(profileRepositoryProvider));
});

final updateProfileUseCaseProvider = Provider<UpdateProfileUseCase>((ref) {
  return UpdateProfileUseCase(ref.watch(profileRepositoryProvider));
});


final deleteAccountUseCaseProvider = Provider<DeleteAccountUseCase>((ref) {
  return DeleteAccountUseCase(ref.watch(profileRepositoryProvider));
});

final profileControllerProvider =
    StateNotifierProvider<ProfileController, ProfileState>((ref) {
      return ProfileController(ref);
    });

enum ProfileStatus { initial, loading, loaded, updating, error, deleting }

class ProfileState {
  const ProfileState({required this.status, this.profile, this.errorMessage});

  const ProfileState.initial() : this(status: ProfileStatus.initial);

  final ProfileStatus status;
  final UserProfile? profile;
  final String? errorMessage;

  ProfileState copyWith({
    ProfileStatus? status,
    UserProfile? profile,
    String? errorMessage,
    bool clearError = false,
  }) {
    return ProfileState(
      status: status ?? this.status,
      profile: profile ?? this.profile,
      errorMessage: clearError ? null : errorMessage ?? this.errorMessage,
    );
  }
}

class ProfileController extends StateNotifier<ProfileState> {
  ProfileController(this._ref) : super(const ProfileState.initial());

  final Ref _ref;

  Future<void> load({bool force = false}) async {
    if (!force &&
        (state.status == ProfileStatus.loading ||
            state.status == ProfileStatus.loaded)) {
      return;
    }

    state = state.copyWith(status: ProfileStatus.loading, clearError: true);

    try {
      final profile = await _ref.read(getCurrentUserUseCaseProvider).call();
      state = ProfileState(status: ProfileStatus.loaded, profile: profile);
    } catch (error) {
      state = state.copyWith(
        status: ProfileStatus.error,
        errorMessage: error.toString(),
      );
    }
  }

  Future<void> updateProfile(UpdateProfileRequest request) async {
    state = state.copyWith(status: ProfileStatus.updating, clearError: true);

    try {
      final profile = await _ref
          .read(updateProfileUseCaseProvider)
          .call(request);
      state = ProfileState(status: ProfileStatus.loaded, profile: profile);
    } catch (error) {
      state = state.copyWith(
        status: ProfileStatus.error,
        errorMessage: error.toString(),
      );
    }
  }

  Future<bool> deleteAccount() async {
    state = state.copyWith(status: ProfileStatus.deleting, clearError: true);

    try {
      await _ref.read(deleteAccountUseCaseProvider).call();
      await _ref.read(authControllerProvider.notifier).clearLocalSession();
      state = const ProfileState.initial();
      return true;
    } catch (error) {
      state = state.copyWith(
        status: ProfileStatus.error,
        errorMessage: error.toString(),
      );
      return false;
    }
  }
}
