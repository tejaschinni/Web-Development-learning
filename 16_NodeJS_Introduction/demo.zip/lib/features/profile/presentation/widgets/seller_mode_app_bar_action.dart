import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/features/profile/presentation/providers/user_mode_provider.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';

class SellerModeAppBarAction extends ConsumerWidget {
  const SellerModeAppBarAction({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sellerProfile = ref.watch(mySellerProfileProvider).valueOrNull;
    if (sellerProfile?.approvalStatus != 'APPROVED') return const SizedBox.shrink();

    final isSeller = ref.watch(userModeProvider) == UserMode.seller;

    return IconButton(
      onPressed: () async {
        final mode = isSeller ? UserMode.user : UserMode.seller;
        await ref.read(userModeProvider.notifier).setMode(mode);

        if (!context.mounted) return;
        context.go(isSeller ? '/' : '/modules/seller/sellerDashboard');
      },
      icon: const HugeIcon(icon: HugeIcons.strokeRoundedUserSwitch),
      tooltip: isSeller ? 'Switch to Seva dashboard' : 'Switch to seller dashboard',
    );
  }
}
