import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';

class SellerInfoSection extends ConsumerWidget {
  const SellerInfoSection({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sellerAsync = ref.watch(mySellerProfileProvider);
    final theme = Theme.of(context);

    return sellerAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => const Text('Could not load seller details'),
      data: (seller) {
        if (seller == null) {
          return SizedBox.shrink();
        }

        return Card(
          child: Padding(
            padding: const EdgeInsets.all(0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header: business name + display name
                Text(seller.businessName ?? seller.displayName, style: theme.textTheme.titleMedium),
                if (seller.businessName != null)
                  Text(seller.displayName, style: theme.textTheme.bodySmall),
                if (seller.bio?.isNotEmpty ?? false) ...[const Gap(4), Text(seller.bio!)],

                // Status chips
                const Gap(12),
                Wrap(
                  spacing: 8,
                  runSpacing: 4,
                  children: [
                    Chip(label: Text(_cap(seller.approvalStatus))),
                    Chip(label: Text(_cap(seller.availabilityStatus))),
                    Chip(label: Text(_cap(seller.sellerTypeList.first))),
                  ],
                ),

                // Stats
                const Gap(12),
                Row(
                  children: [
                    _stat('Orders', '${seller.totalOrders}'),
                    _stat('Listings', '${seller.totalListings}'),
                    _stat(
                      'Rating',
                      seller.totalReviews == 0 ? '-' : seller.averageRating.toStringAsFixed(1),
                    ),
                    _stat('Reviews', '${seller.totalReviews}'),
                  ],
                ),
                const Divider(height: 24),

                // Details
                _row(
                  'Address',
                  '${seller.address}, ${seller.city}, ${seller.state} ${seller.pinCode}',
                ),
                _row('Target area', seller.targetArea.toString()),
                _row('Delivery radius', '${seller.deliveryRadiusKm!.toStringAsFixed(0)} km'),

                if (seller.fssaiRequired) ...[
                  _row('FSSAI ID', seller.fssaiCertificateId ?? '-'),
                  _row('FSSAI status', _cap(seller.fssaiStatus)),
                ],

                if (seller.rejectedOrders > 0 || seller.cancelledOrders > 0)
                  _row(
                    'Rejected / cancelled',
                    '${seller.rejectedOrders} / ${seller.cancelledOrders}',
                  ),

                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton(
                    onPressed: () {
                      context.push('/modules/seller/onboarding', extra: true);
                    },
                    child: const Text('Edit seller details'),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _stat(String label, String value) => Expanded(
    child: Column(
      children: [
        Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
        Text(label, style: const TextStyle(fontSize: 12)),
      ],
    ),
  );

  Widget _row(String label, String value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(width: 130, child: Text(label)),
        Expanded(child: Text(value)),
      ],
    ),
  );

  // FOOD_SELLER -> "Food seller", APPROVED -> "Approved"
  String _cap(String s) {
    final t = s.replaceAll('_', ' ').toLowerCase();
    return t.isEmpty ? t : t[0].toUpperCase() + t.substring(1);
  }
}
