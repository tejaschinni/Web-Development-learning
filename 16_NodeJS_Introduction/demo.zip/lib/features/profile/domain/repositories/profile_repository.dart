import 'package:society_seva/features/profile/data/models/update_profile_request.dart';
import 'package:society_seva/features/profile/data/models/phone_number_requests.dart';
import 'package:society_seva/features/profile/domain/entities/user_profile.dart';

abstract class ProfileRepository {
  Future<UserProfile> getCurrentUser();

  Future<UserProfile> updateProfile(UpdateProfileRequest request);

  Future<void> deleteAccount();

  Future<Map<String, dynamic>> sendPhoneNumberOtp(
    SendPhoneNumberOtpRequest request,
  );

  Future<UserProfile> verifyPhoneNumberOtp(VerifyPhoneNumberOtpRequest request);
}
