class UserProfile {
  const UserProfile({
    required this.id,
    required this.fullName,
    required this.gender,
    required this.dateOfBirth,
    required this.mobileNumber,
    required this.email,
    required this.emailVerified,
    this.profilePhotoUrl,
    required this.preferredLanguage,
    required this.accountStatus,
    required this.roles,
  });

  final String id;
  final String fullName;
  final String gender;
  final String dateOfBirth;
  final String mobileNumber;
  final String email;
  final bool emailVerified;
  final String? profilePhotoUrl;
  final String preferredLanguage;
  final String accountStatus;
  final List<String> roles;

  UserProfile copyWith({
    String? fullName,
    String? gender,
    String? dateOfBirth,
    String? email,
    String? preferredLanguage,
    String? profilePhotoUrl,
  }) {
    return UserProfile(
      id: id,
      fullName: fullName ?? this.fullName,
      gender: gender ?? this.gender,
      dateOfBirth: dateOfBirth ?? this.dateOfBirth,
      email: email ?? this.email,
      emailVerified: emailVerified,
      profilePhotoUrl: profilePhotoUrl ?? this.profilePhotoUrl,
      mobileNumber: mobileNumber,
      preferredLanguage: preferredLanguage ?? this.preferredLanguage,
      accountStatus: accountStatus,
      roles: roles,
    );
  }
}
