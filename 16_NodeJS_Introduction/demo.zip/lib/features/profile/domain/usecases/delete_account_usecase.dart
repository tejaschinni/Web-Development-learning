import 'package:society_seva/features/profile/domain/repositories/profile_repository.dart';

class DeleteAccountUseCase {
  DeleteAccountUseCase(this._repository);

  final ProfileRepository _repository;

  Future<void> call() => _repository.deleteAccount();
}
