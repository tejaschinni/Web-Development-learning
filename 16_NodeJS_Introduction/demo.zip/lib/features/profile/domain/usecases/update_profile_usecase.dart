import 'package:society_seva/features/profile/data/models/update_profile_request.dart';
import 'package:society_seva/features/profile/domain/entities/user_profile.dart';
import 'package:society_seva/features/profile/domain/repositories/profile_repository.dart';

class UpdateProfileUseCase {
  UpdateProfileUseCase(this._repository);

  final ProfileRepository _repository;

  Future<UserProfile> call(UpdateProfileRequest request) {
    return _repository.updateProfile(request);
  }
}
