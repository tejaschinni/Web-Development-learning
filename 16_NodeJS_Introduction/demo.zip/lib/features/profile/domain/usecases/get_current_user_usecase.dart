import 'package:society_seva/features/profile/domain/entities/user_profile.dart';
import 'package:society_seva/features/profile/domain/repositories/profile_repository.dart';

class GetCurrentUserUseCase {
  GetCurrentUserUseCase(this._repository);

  final ProfileRepository _repository;

  Future<UserProfile> call() => _repository.getCurrentUser();
}
