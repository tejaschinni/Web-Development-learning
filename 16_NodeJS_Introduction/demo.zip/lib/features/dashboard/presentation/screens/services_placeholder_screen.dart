import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';

class ServicesPlaceholderScreen extends StatelessWidget {
  const ServicesPlaceholderScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(24),
      children: [
        Text(
          'Services and facilities',
          style: GoogleFonts.hind(textStyle: Theme.of(context).textTheme.headlineSmall),
        ),
        const Gap(8),
        Text(
          'Service modules are organized and ready for API integration.',
          style: GoogleFonts.hind(),
        ),
        const Gap(24),
        ListTile(
          leading: HugeIcon(icon: HugeIcons.strokeRoundedPrisonGuard),
          title: Text('Security', style: GoogleFonts.hind()),
        ),
        ListTile(
          leading: HugeIcon(icon: HugeIcons.strokeRoundedPackage03),
          title: Text('Visitors and parcels', style: GoogleFonts.hind()),
        ),
        ListTile(
          leading: HugeIcon(icon: HugeIcons.strokeRoundedWrench01),
          title: Text('Service requests', style: GoogleFonts.hind()),
        ),
      ],
    );
  }
}
