import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';

class DashboardHomeScreen extends StatelessWidget {
  const DashboardHomeScreen({super.key, required this.fullName, required this.roles});

  final String fullName;
  final List<String> roles;

  Set<String> get _roles =>
      roles.map((role) => role.trim().toUpperCase().replaceFirst('ROLE_', '')).toSet();

  bool get _seller => _roles.contains('SELLER');
  bool get _committee =>
      _roles.contains('SOCIETY_ADMIN') ||
      _roles.contains('COMMITTEE_MEMBER') ||
      _roles.contains('ADMIN');
  bool get _superAdmin => _roles.contains('SUPER_ADMIN');

  String get _workspace {
    if (_superAdmin) return 'Super Admin workspace';
    if (_committee) return 'Society Admin workspace';
    if (_seller) return 'Seller workspace';
    return 'Common user workspace';
  }

  @override
  Widget build(BuildContext context) {
    final sections = <Widget>[
      _WorkspaceCard(
        title: 'Common / Buyer',
        description: 'Profile, society, marketplace, orders, wallet, and community modules.',
        route: '/modules/common',
      ),
      if (_seller)
        _WorkspaceCard(
          title: 'Seller',
          description: 'Seller profile, listings, food, services, KYC, and orders.',
          route: '/modules/seller',
        ),
      if (_committee)
        _WorkspaceCard(
          title: 'Society Admin / Committee',
          description: 'Society structure, members, workers, sellers, and moderation.',
          route: '/modules/society-admin',
        ),
      if (_superAdmin)
        _WorkspaceCard(
          title: 'Super Admin',
          description: 'Roles, societies, categories, payments, settlements, and disputes.',
          route: '/modules/super-admin',
        ),
    ];

    return ListView(
      padding: const EdgeInsets.all(24),
      children: [
        Text(
          'Welcome${fullName.isEmpty ? '' : ', $fullName'}',
          style: GoogleFonts.hind(textStyle: Theme.of(context).textTheme.headlineSmall),
        ),
        const Gap(8),
        Text(
          _workspace,
          style: GoogleFonts.hind(textStyle: Theme.of(context).textTheme.titleMedium),
        ),
        const Gap(24),
        ...sections,
      ],
    );
  }
}

class _WorkspaceCard extends StatelessWidget {
  const _WorkspaceCard({required this.title, required this.description, required this.route});

  final String title;
  final String description;
  final String route;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: ListTile(
        contentPadding: const EdgeInsets.all(16),
        title: Text(title, style: GoogleFonts.hind()),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Text(description, style: GoogleFonts.hind()),
        ),
        trailing: const HugeIcon(icon: HugeIcons.strokeRoundedArrowRight01),
        onTap: () => context.push(route),
      ),
    );
  }
}
