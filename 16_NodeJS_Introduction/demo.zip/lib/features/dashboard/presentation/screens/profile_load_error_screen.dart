import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';

class ProfileLoadErrorScreen extends StatelessWidget {
  const ProfileLoadErrorScreen({super.key, required this.message, required this.onRetry});
  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.all(24),
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const HugeIcon(icon: HugeIcons.strokeRoundedCloudOff, size: 56),
        const Gap(16),
        Text(message, textAlign: TextAlign.center, style: GoogleFonts.hind()),
        const Gap(16),
        OutlinedButton.icon(
          onPressed: onRetry,
          icon: const HugeIcon(icon: HugeIcons.strokeRoundedRefresh01),
          label: Text('Retry', style: GoogleFonts.hind()),
        ),
      ],
    ),
  );
}
