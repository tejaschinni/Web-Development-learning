class OrderStatusHistoryEntity {
  final DateTime createdAt;
  final String id;
  final String newStatus;
  final String note;
  final String? oldStatus;
  final String orderId;

  const OrderStatusHistoryEntity({
    required this.createdAt,
    required this.id,
    required this.newStatus,
    required this.note,
    required this.oldStatus,
    required this.orderId,
  });

  OrderStatusHistoryEntity copyWith({
    DateTime? createdAt,
    String? id,
    String? newStatus,
    String? note,
    String? oldStatus,
    String? orderId,
  }) {
    return OrderStatusHistoryEntity(
      createdAt: createdAt ?? this.createdAt,
      id: id ?? this.id,
      newStatus: newStatus ?? this.newStatus,
      note: note ?? this.note,
      oldStatus: oldStatus ?? this.oldStatus,
      orderId: orderId ?? this.orderId,
    );
  }
}
