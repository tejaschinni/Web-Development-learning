class AvailableDaysEntity {
  final String sellerId;
  final String daysType;
  final List<String> availableDays;
  final String fromTime;
  final String toTime;

  const AvailableDaysEntity({
    required this.sellerId,
    required this.daysType,
    required this.availableDays,
    required this.fromTime,
    required this.toTime,
  });

  AvailableDaysEntity copyWith({
    String? sellerId,
    String? daysType,
    List<String>? availableDays,
    String? fromTime,
    String? toTime,
  }) {
    return AvailableDaysEntity(
      sellerId: sellerId ?? this.sellerId,
      daysType: daysType ?? this.daysType,
      availableDays: availableDays ?? this.availableDays,
      fromTime: fromTime ?? this.fromTime,
      toTime: toTime ?? this.toTime,
    );
  }
}
