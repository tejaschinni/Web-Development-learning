class CertificateEntity {
  final String id;
  final String sellerId;
  final String certificateType;
  final String certificateName;
  final String issuingAuthority;
  final String certificateFileUrl;
  final String verificationStatus;
  final DateTime createdAt;
  final DateTime updatedAt;

  const CertificateEntity({
    required this.id,
    required this.sellerId,
    required this.certificateType,
    required this.certificateName,
    required this.issuingAuthority,
    required this.certificateFileUrl,
    required this.verificationStatus,
    required this.createdAt,
    required this.updatedAt,
  });

  CertificateEntity copyWith({
    String? id,
    String? sellerId,
    String? certificateType,
    String? certificateName,
    String? issuingAuthority,
    String? certificateFileUrl,
    String? verificationStatus,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return CertificateEntity(
      id: id ?? this.id,
      sellerId: sellerId ?? this.sellerId,
      certificateType: certificateType ?? this.certificateType,
      certificateName: certificateName ?? this.certificateName,
      issuingAuthority: issuingAuthority ?? this.issuingAuthority,
      certificateFileUrl: certificateFileUrl ?? this.certificateFileUrl,
      verificationStatus: verificationStatus ?? this.verificationStatus,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}
