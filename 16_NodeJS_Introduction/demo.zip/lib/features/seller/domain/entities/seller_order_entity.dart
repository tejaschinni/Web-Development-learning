/// One line item within a seller order (what was bought, how much of it).
class SellerOrderItemEntity {
  const SellerOrderItemEntity({
    required this.id,
    required this.listingId,
    required this.titleSnapshot,
    required this.quantity,
    required this.unitPrice,
    required this.totalPrice,
  });

  final String id;
  final String listingId;
  final String titleSnapshot;
  final int quantity;
  final double unitPrice;
  final double totalPrice;
}

/// An order placed against one of the logged-in seller's listings.
/// Matches the shape returned by `GET /api/v1/orders?sellerId={sellerId}`.
class SellerOrderEntity {
  const SellerOrderEntity({
    required this.id,
    required this.orderNumber,
    required this.buyerId,
    required this.sellerId,
    required this.orderType,
    required this.orderStatus,
    required this.subtotalAmount,
    required this.discountAmount,
    required this.platformCommission,
    required this.welfareFundAmount,
    required this.sellerEarning,
    required this.totalAmount,
    required this.paymentStatus,
    required this.items,
    required this.createdAt,
  });

  final String id;
  final String orderNumber;
  final String buyerId;
  final String sellerId;
  final String orderType; // e.g. PRODUCT_ORDER, FOOD_ORDER, SERVICE_BOOKING
  final String orderStatus; // CREATED, PAID, ACCEPTED, REJECTED, PREPARING,
  // READY_FOR_PICKUP, OUT_FOR_DELIVERY, IN_SERVICE, COMPLETED
  final double subtotalAmount;
  final double discountAmount;
  final double platformCommission;
  final double welfareFundAmount;
  final double sellerEarning;
  final double totalAmount;
  final String paymentStatus;
  final List<SellerOrderItemEntity> items;
  final DateTime createdAt;

  SellerOrderEntity copyWith({String? orderStatus}) => SellerOrderEntity(
    id: id,
    orderNumber: orderNumber,
    buyerId: buyerId,
    sellerId: sellerId,
    orderType: orderType,
    orderStatus: orderStatus ?? this.orderStatus,
    subtotalAmount: subtotalAmount,
    discountAmount: discountAmount,
    platformCommission: platformCommission,
    welfareFundAmount: welfareFundAmount,
    sellerEarning: sellerEarning,
    totalAmount: totalAmount,
    paymentStatus: paymentStatus,
    items: items,
    createdAt: createdAt,
  );
}
