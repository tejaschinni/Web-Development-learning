import 'package:society_seva/features/seller/domain/entities/seller_profile_entity.dart';
import 'package:society_seva/features/seller/domain/repositories/seller_onboarding_repository.dart';

class MySellerProfileUsecase {
  MySellerProfileUsecase(this._repository);

  final SellerOnboardingRepository _repository;

  Future<SellerProfileEntity?> call() => _repository.mySellerProfileRepo();
}
