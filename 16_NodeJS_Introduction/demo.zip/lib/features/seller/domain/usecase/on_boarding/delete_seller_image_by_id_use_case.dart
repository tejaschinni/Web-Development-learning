import 'package:society_seva/features/seller/domain/repositories/seller_onboarding_repository.dart';

class DeleteSellerImageByIdUseCase {
  DeleteSellerImageByIdUseCase(this._repository);

  final SellerOnboardingRepository _repository;

  Future<void> call({required String imageId, required String sellerId}) =>
      _repository.deleteUploadedSellerImagesRepo(imageId: imageId, sellerID: sellerId);
}
