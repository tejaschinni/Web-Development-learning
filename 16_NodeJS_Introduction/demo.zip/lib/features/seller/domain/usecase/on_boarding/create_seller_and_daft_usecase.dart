import 'package:society_seva/features/seller/data/models/request/seller_profile_request.dart';
import 'package:society_seva/features/seller/domain/repositories/seller_onboarding_repository.dart';

class CreateSellerAndDaftUsecase {
  CreateSellerAndDaftUsecase(this._repository);

  final SellerOnboardingRepository _repository;

  Future<void> call({required SellerProfileRequest request}) =>
      _repository.createAndSaveAsDraftRepo(request: request);
}
