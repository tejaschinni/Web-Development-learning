import 'package:society_seva/features/seller/domain/repositories/seller_onboarding_repository.dart';

/// Downloads a single KYC document's file content.
///
/// Maps to `GET /api/v1/sellers/{sellerId}/kyc/{documentFileUrl}/file`.
/// The response is the raw file content as a base64 string - decode it with
/// `base64Decode` and feed the bytes to an image/pdf viewer or a file saver.
class DownloadKycDocumentFileUsecase {
  DownloadKycDocumentFileUsecase(this._repository);

  final SellerOnboardingRepository _repository;

  Future<String> call({required String sellerId, required String documentFileUrl}) {
    return _repository.downloadKYCDocumentFileRepo(
      sellerId: sellerId,
      documentFileUrl: documentFileUrl,
    );
  }
}
