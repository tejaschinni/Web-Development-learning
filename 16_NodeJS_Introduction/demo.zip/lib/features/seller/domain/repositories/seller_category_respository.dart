import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/seller/data/datasources/seller_category_remote_datasource.dart';

import 'package:society_seva/features/seller/domain/entities/seller_category_entity.dart';
import 'package:society_seva/features/shop/data/models/shop_category_model.dart';

abstract class SellerCategoryRespository {
  Future<PageResponse<CategoriesEntity>> fetchCategoriesRepo({
    String? categoryType,
    String? parentCategoryId,
    bool? rootsOnly,
    String? search,
  });

  Future<List<ShopCategoryModel>> fetchCategoriesTreeRepo({String? categoryType});
}

class SellerCategoryRespositoryImpl implements SellerCategoryRespository {
  SellerCategoryRespositoryImpl(this.sellerCategoryRemoteDatasource);

  // ignore: unused_field
  final SellerCategoryRemoteDatasource sellerCategoryRemoteDatasource;
  @override
  Future<PageResponse<CategoriesEntity>> fetchCategoriesRepo({
    String? categoryType,
    String? parentCategoryId,
    bool? rootsOnly,
    String? search,
  }) async {
    final result = await sellerCategoryRemoteDatasource.fetchCategoriesDataSource();
    PageResponse<CategoriesEntity> page = PageResponse(
      content: result.content.map((e) => e.toEntity()).toList(),
      page: result.page,
      size: result.size,
      totalElements: result.totalElements,
      totalPages: result.totalPages,
      first: result.first,
      last: result.last,
    );
    return page;
  }

  @override
  Future<List<ShopCategoryModel>> fetchCategoriesTreeRepo({String? categoryType}) async {
    final result = await sellerCategoryRemoteDatasource.fetchCategoriesTreeDataSource(
      categoryType: categoryType,
    );
    return result;
  }
}
