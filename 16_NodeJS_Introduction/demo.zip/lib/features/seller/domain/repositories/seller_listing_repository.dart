import 'package:image_picker/image_picker.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/seller/data/datasources/seller_listing_remote_datasource.dart';
import 'package:society_seva/features/seller/data/models/request/food_additional_information_request.dart';
import 'package:society_seva/features/seller/data/models/request/seller_listing_basic_info_request.dart';
import 'package:society_seva/features/seller/data/models/request/service_additional_information_request.dart';
import 'package:society_seva/features/seller/domain/entities/food_detail_entity.dart';
import 'package:society_seva/features/seller/domain/entities/seller_listing_entity.dart';
import 'package:society_seva/features/seller/domain/entities/seller_listing_images_entity.dart';
import 'package:society_seva/features/seller/domain/entities/service_detail_entity.dart';
import 'package:society_seva/features/seller/domain/entities/service_slot_entity.dart';

abstract class SellerListingRepository {
  Future<PageResponse<SellerListingEntity>> fetchMyListingRepo({required String sellerId});
  Future<List<SellerListingImageEntity>> getListingImagesRepo(String listingId);
  Future<SellerListingEntity?> createListingRepo({required SellerListingBasicInfoRequest request});

  Future<SellerListingEntity?> submitListingRepo({required String listingId});

  Future<SellerListingEntity?> fetchListingByIDRepo({required String listingId});

  Future<SellerListingEntity?> updateSubmitListingRepo({
    required String listingId,
    required SellerListingBasicInfoRequest request,
  });

  Future<SellerListingImageEntity> uploadSellerShopImagesRepo(String sellerId, XFile file);

  Future<bool> additionalFoodInformationRepo({
    required FoodAdditionalInformationRequest request,
    required String listingId,
  });

  Future<bool> additionalServiceInformationRepo({
    required ServiceAdditionalInformationRequest request,
    required String listingId,
  });

  Future<FoodListingDetailsEntity?> updateAdditionalFoodInformationRepo({
    required FoodAdditionalInformationRequest request,
    required String listingId,
  });

  Future<ServiceListingDetailsEntity?> updateAdditionalServiceInformationRepo({
    required ServiceAdditionalInformationRequest request,
    required String listingId,
  });

  Future<FoodListingDetailsEntity> fetchAdditionalFoodInformationRepo({required String listingId});

  Future<ServiceListingDetailsEntity> fetchAdditionalServiceInformationRepo({
    required String listingId,
  });

  Future<List<ServiceSlotEntity>> saveServiceSlotsRepo({
    required String listingId,
    required String date,
    required List<Map<String, String>> windows,
  });

  Future<List<DateTime>> fetchServiceAvailableDatesRepo({
    required String listingId,
    required String fromDate,
    required String toDate,
  });
  Future<List<ServiceSlotEntity>> getServiceAvailableSlotsRepo({
    required String listingId,
    required String date,
  });

  Future<void> deleteServiceSlotsRepo({required String listingId, required String date});

  Future<void> deleteListingImageRepo({required String listingId, required String imageId});
}

class SellerListingRepositoryImpl implements SellerListingRepository {
  SellerListingRepositoryImpl(this.sellerListingRemoteDatasource);
  final SellerListingRemoteDatasource sellerListingRemoteDatasource;

  @override
  Future<PageResponse<SellerListingEntity>> fetchMyListingRepo({required String sellerId}) async {
    final result = await sellerListingRemoteDatasource.fetchMyListingDataSource(sellerId: sellerId);
    return result;
  }

  @override
  Future<List<SellerListingImageEntity>> getListingImagesRepo(String listingId) async {
    final result = await sellerListingRemoteDatasource.getListingImagesDataSource(listingId);
    return result.map((e) => e.toEntity()).toList();
  }

  @override
  Future<SellerListingEntity?> createListingRepo({
    required SellerListingBasicInfoRequest request,
  }) async {
    final result = await sellerListingRemoteDatasource.createListingDataSource(request: request);
    return result;
  }

  @override
  Future<bool> additionalFoodInformationRepo({
    required FoodAdditionalInformationRequest request,
    required String listingId,
  }) async {
    final result = await sellerListingRemoteDatasource.additionalFoodInformationDataSource(
      request: request,
      listingId: listingId,
    );
    return result;
  }

  @override
  Future<bool> additionalServiceInformationRepo({
    required ServiceAdditionalInformationRequest request,
    required String listingId,
  }) async {
    final result = await sellerListingRemoteDatasource.additionalServiceInformationDataSource(
      request: request,
      listingId: listingId,
    );
    return result;
  }

  @override
  Future<FoodListingDetailsEntity> fetchAdditionalFoodInformationRepo({
    required String listingId,
  }) async {
    final result = await sellerListingRemoteDatasource.fetchAdditionalFoodInformationDataSource(
      listingId: listingId,
    );

    return result;
  }

  @override
  Future<ServiceListingDetailsEntity> fetchAdditionalServiceInformationRepo({
    required String listingId,
  }) async {
    final result = await sellerListingRemoteDatasource.fetchAdditionalServiceInformationDataSource(
      listingId: listingId,
    );
    return result;
  }

  @override
  Future<SellerListingEntity?> submitListingRepo({required String listingId}) async {
    final result = await sellerListingRemoteDatasource.submitListingDataSource(
      listingId: listingId,
    );
    return result;
  }

  @override
  Future<FoodListingDetailsEntity?> updateAdditionalFoodInformationRepo({
    required FoodAdditionalInformationRequest request,
    required String listingId,
  }) async {
    final result = await sellerListingRemoteDatasource.updateAdditionalFoodInformationDataSource(
      request: request,
      listingId: listingId,
    );
    return result;
  }

  @override
  Future<ServiceListingDetailsEntity?> updateAdditionalServiceInformationRepo({
    required ServiceAdditionalInformationRequest request,
    required String listingId,
  }) async {
    final result = await sellerListingRemoteDatasource.updateAdditionalServiceInformationDataSource(
      request: request,
      listingId: listingId,
    );
    return result;
  }

  @override
  Future<SellerListingEntity?> updateSubmitListingRepo({
    required String listingId,
    required SellerListingBasicInfoRequest request,
  }) async {
    final result = await sellerListingRemoteDatasource.updateSubmitListingDataSource(
      listingId: listingId,
      request: request,
    );
    return result;
  }

  @override
  Future<SellerListingImageEntity> uploadSellerShopImagesRepo(String sellerId, XFile file) async {
    final result = await sellerListingRemoteDatasource.uploadSellerShopImagesDataSource(
      sellerId,
      file,
    );
    return result.toEntity();
  }

  @override
  Future<List<ServiceSlotEntity>> saveServiceSlotsRepo({
    required String listingId,
    required String date,
    required List<Map<String, String>> windows,
  }) {
    return sellerListingRemoteDatasource.saveServiceSlotsDataSource(
      listingId: listingId,
      date: date,
      windows: windows,
    );
  }

  @override
  Future<void> deleteServiceSlotsRepo({required String listingId, required String date}) {
    return sellerListingRemoteDatasource.deleteServiceSlotsDataSource(
      listingId: listingId,
      date: date,
    );
  }

  @override
  Future<void> deleteListingImageRepo({required String listingId, required String imageId}) {
    return sellerListingRemoteDatasource.deleteListingImageDataSource(
      listingId: listingId,
      imageId: imageId,
    );
  }

  @override
  Future<SellerListingEntity?> fetchListingByIDRepo({required String listingId}) async {
    return sellerListingRemoteDatasource.fetchListingByIdDataSource(listingID: listingId);
  }

  @override
  Future<List<DateTime>> fetchServiceAvailableDatesRepo({
    required String listingId,
    required String fromDate,
    required String toDate,
  }) async {
    return await sellerListingRemoteDatasource.fetchServiceAvailableDatesDataSource(
      listingId: listingId,
      fromDate: fromDate,
      toDate: toDate,
    );
  }

  @override
  Future<List<ServiceSlotEntity>> getServiceAvailableSlotsRepo({
    required String listingId,
    required String date,
  }) async {
    return await sellerListingRemoteDatasource.getServiceAvailableSlotsDataSource(
      listingId: listingId,
      date: date,
    );
  }
}
