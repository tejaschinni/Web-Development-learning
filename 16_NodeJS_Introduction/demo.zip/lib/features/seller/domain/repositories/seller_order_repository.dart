import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/seller/data/datasources/seller_order_remote_data_source.dart';
import 'package:society_seva/features/seller/domain/entities/order_status_history_entity.dart';
import 'package:society_seva/features/seller/domain/entities/seller_order_entity.dart';

abstract class SellerOrderRepository {
  Future<PageResponse<SellerOrderEntity>> fetchSellerOrdersRepo({required String sellerId});

  Future<SellerOrderEntity> transitionOrderRepo({
    required String orderId,
    required String newStatus,
    String? note,
  });

  Future<String> fetchBuyerIdRepo({required String buyerId});

  Future<List<OrderStatusHistoryEntity>> fetchOrderStatusHistoryRepo({required String orderID});
}

class SellerOrderRepositoryImpl implements SellerOrderRepository {
  SellerOrderRepositoryImpl(this._remoteDataSource);

  final SellerOrderRemoteDataSource _remoteDataSource;

  @override
  Future<PageResponse<SellerOrderEntity>> fetchSellerOrdersRepo({required String sellerId}) async {
    final page = await _remoteDataSource.fetchSellerOrdersDataSource(sellerId: sellerId);
    return PageResponse<SellerOrderEntity>(
      content: page.content,
      page: page.page,
      size: page.size,
      totalElements: page.totalElements,
      totalPages: page.totalPages,
      first: page.first,
      last: page.last,
    );
  }

  @override
  Future<SellerOrderEntity> transitionOrderRepo({
    required String orderId,
    required String newStatus,
    String? note,
  }) {
    return _remoteDataSource.transitionOrderDataSource(
      orderId: orderId,
      newStatus: newStatus,
      note: note,
    );
  }

  @override
  Future<String> fetchBuyerIdRepo({required String buyerId}) async {
    final result = await _remoteDataSource.fetchBuyerIdDataSource(buyerId: buyerId);
    return result;
  }

  @override
  Future<List<OrderStatusHistoryEntity>> fetchOrderStatusHistoryRepo({
    required String orderID,
  }) async {
    final result = await _remoteDataSource.fetchOrderStatusHistoryDataSource(orderID: orderID);
    return result;
  }
}
