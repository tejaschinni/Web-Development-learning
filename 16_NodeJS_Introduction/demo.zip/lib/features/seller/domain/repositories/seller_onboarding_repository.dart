import 'package:image_picker/image_picker.dart';
import 'package:society_seva/features/seller/data/datasources/seller_onboarding_remote_data_source.dart';
import 'package:society_seva/features/seller/data/models/request/seller_profile_request.dart';
import 'package:society_seva/features/seller/domain/entities/certificate_entity.dart';
import 'package:society_seva/features/seller/domain/entities/kyc_document_entity.dart';
import 'package:society_seva/features/seller/domain/entities/seller_availabledays_entity.dart';
import 'package:society_seva/features/seller/domain/entities/seller_image_entity.dart';
import 'package:society_seva/features/seller/domain/entities/seller_profile_entity.dart';

abstract class SellerOnboardingRepository {
  Future<SellerProfileEntity?> createAndSaveAsDraftRepo({required SellerProfileRequest request});
  Future<SellerProfileEntity?> submitDartRepo({required String sellerId});
  Future<void> uploadSellerShopImagesRepo(String sellerId, XFile file);
  Future<List<SellerImageEntity>> fetchSellerUploadedImagesRepo(String sellerId);
  Future<SellerProfileEntity?> mySellerProfileRepo();
  Future<SellerProfileEntity?> fetchSellerProfileByIDRepo(String sellerID);
  Future<SellerProfileEntity?> updateProfileRepo({
    required SellerProfileRequest request,
    required String sellerID,
  });
  Future<void> deleteUploadedSellerImagesRepo({required String sellerID, required String imageId});

  Future<CertificateEntity?> uploadCertificateRepo({
    required String sellerId,
    required XFile file,
    required String certificateName,
    required String certificateType,
    required DateTime issueDate,
    required bool hasExpiry,
    required String issueAuthority,
    required String certificateNumber,
    DateTime? expiryDate,
  });

  Future<List<CertificateEntity>> fetchCertificatesRepo(String sellerId);

  Future<bool> uploadKYCDocumentRepo({
    required XFile file,
    required String documentType,
    required String documentNumber,
    required String sellerId,
  });
  Future<List<KycDocumentEntity>> fetchKYCDocumentRepo(String sellerId);

  /// Downloads a KYC document's file content (base64 string).
  Future<String> downloadKYCDocumentFileRepo({
    required String sellerId,
    required String documentFileUrl,
  });

  Future<AvailableDaysEntity> fetchSellerAvailableDaysRepo({required String sellerID});

  Future<AvailableDaysEntity> updateSellerAvailableDaysRepo({
    required String sellerID,
    required Map<String, dynamic> data,
  });
}

class SellerOnboardingRepositoryImpl implements SellerOnboardingRepository {
  SellerOnboardingRepositoryImpl({required this.sellerOnboardingRemoteDataSource});

  final SellerOnboardingRemoteDataSource sellerOnboardingRemoteDataSource;
  @override
  Future<SellerProfileEntity?> createAndSaveAsDraftRepo({
    required SellerProfileRequest request,
  }) async {
    final result = await sellerOnboardingRemoteDataSource.createAndSaveAsDraftDataSource(
      request: request,
    );
    return result;
  }

  @override
  Future<void> deleteUploadedSellerImagesRepo({
    required String sellerID,
    required String imageId,
  }) async {
    final result = await sellerOnboardingRemoteDataSource.deleteUploadedSellerImagesDataSource(
      sellerID: sellerID,
      imageId: imageId,
    );
    return result;
  }

  @override
  Future<SellerProfileEntity?> fetchSellerProfileByIDRepo(String sellerID) async {
    final result = await sellerOnboardingRemoteDataSource.fetchSellerProfileByIDDataSource(
      sellerID,
    );
    return result;
  }

  @override
  Future<List<SellerImageEntity>> fetchSellerUploadedImagesRepo(String sellerId) async {
    final result = await sellerOnboardingRemoteDataSource.fetchSellerUploadedImagesDataSource(
      sellerId,
    );
    return result;
  }

  @override
  Future<SellerProfileEntity?> mySellerProfileRepo() async {
    final result = await sellerOnboardingRemoteDataSource.mySellerProfileDataSource();
    return result;
  }

  @override
  Future<SellerProfileEntity?> submitDartRepo({required String sellerId}) async {
    final result = await sellerOnboardingRemoteDataSource.submitDartDataSource(sellerId: sellerId);
    return result;
  }

  @override
  Future<SellerProfileEntity?> updateProfileRepo({
    required SellerProfileRequest request,
    required String sellerID,
  }) async {
    final result = await sellerOnboardingRemoteDataSource.updateProfileDataSource(
      request: request,
      sellerID: sellerID,
    );
    return result;
  }

  @override
  Future<void> uploadSellerShopImagesRepo(String sellerId, XFile file) async {
    final result = await sellerOnboardingRemoteDataSource.uploadSellerShopImagesDataSource(
      sellerId,
      file,
    );
    return result;
  }

  @override
  Future<List<CertificateEntity>> fetchCertificatesRepo(String sellerId) async {
    final result = await sellerOnboardingRemoteDataSource.fetchCertificatesDataSource(sellerId);
    return result.map((e) => e.toEntity()).toList();
  }

  @override
  Future<CertificateEntity?> uploadCertificateRepo({
    required String sellerId,
    required XFile file,
    required String certificateName,
    required String certificateType,
    required DateTime issueDate,
    required bool hasExpiry,
    required String issueAuthority,
    required String certificateNumber,
    DateTime? expiryDate,
  }) async {
    final result = await sellerOnboardingRemoteDataSource.uploadCertificateDataSource(
      sellerId: sellerId,
      file: file,
      certificateName: certificateName,
      certificateType: certificateType,
      issueDate: issueDate,
      hasExpiry: hasExpiry,
      issueAuthority: issueAuthority,
      certificateNumber: certificateNumber,
    );
    return result!.toEntity();
  }

  @override
  Future<List<KycDocumentEntity>> fetchKYCDocumentRepo(String sellerId) async {
    final result = await sellerOnboardingRemoteDataSource.fetchKycDocumentDataSource(sellerId);
    return result.map((e) => e.toEntity()).toList();
  }

  @override
  Future<bool> uploadKYCDocumentRepo({
    required XFile file,
    required String documentType,
    required String documentNumber,
    required String sellerId,
  }) async {
    final result = await sellerOnboardingRemoteDataSource.uploadKYCDocumentDataSource(
      file: file,
      documentType: documentType,
      documentNumber: documentNumber,
      sellerId: sellerId,
    );
    return result;
  }

  @override
  Future<String> downloadKYCDocumentFileRepo({
    required String sellerId,
    required String documentFileUrl,
  }) {
    return sellerOnboardingRemoteDataSource.downloadKycDocumentFileDataSource(
      sellerId: sellerId,
      documentFileUrl: documentFileUrl,
    );
  }

  @override
  Future<AvailableDaysEntity> fetchSellerAvailableDaysRepo({required String sellerID}) async {
    return sellerOnboardingRemoteDataSource.fetchSellerAvailableDaysDataSource(sellerID: sellerID);
  }

  @override
  Future<AvailableDaysEntity> updateSellerAvailableDaysRepo({
    required String sellerID,
    required Map<String, dynamic> data,
  }) async {
    // TODO: implement updateSellerAvailableDaysRepo
    throw UnimplementedError();
  }
}
