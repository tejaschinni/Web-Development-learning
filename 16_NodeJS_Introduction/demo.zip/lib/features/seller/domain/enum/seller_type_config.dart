import 'package:flutter/material.dart';

const sellerTypes = [
  'FOOD_SELLER',
  'SERVICE_PROVIDER',
  'PRODUCT_SELLER',
  'ART_SELLER',
  'CONSULTANT',
  'TRAINER',
  'FREE_HELP_PROVIDER',
  'MIXED',
];

const isFassaiRequiredOptions = [true, false];

class SellerCategory {
  final String title;
  final String description;
  final String sellerType;
  final IconData icon;

  const SellerCategory({
    required this.title,
    required this.description,
    required this.sellerType,
    required this.icon,
  });
}

SellerCategory? categoryFor(String sellerType) {
  for (final c in sellerCategories) {
    if (c.sellerType == sellerType) return c;
  }
  return null;
}

const sellerCategories = <SellerCategory>[
  SellerCategory(
    title: 'Food',
    description: 'Homemade meals, snacks, sweets, bakery and more',
    sellerType: 'FOOD_SELLER',
    icon: Icons.restaurant,
  ),
  SellerCategory(
    title: 'Art & Creative',
    description: 'Handmade gifts, paintings, jewellery, home decor and more',
    sellerType: 'ART_SELLER',
    icon: Icons.palette,
  ),
  SellerCategory(
    title: 'Products',
    description: 'Groceries, clothing, accessories and other goods',
    sellerType: 'PRODUCT_SELLER',
    icon: Icons.shopping_bag,
  ),
  SellerCategory(
    title: 'Services',
    description: 'Repairs, cleaning, tailoring, beauty and home services',
    sellerType: 'SERVICE_PROVIDER',
    icon: Icons.handyman,
  ),
  SellerCategory(
    title: 'Consulting',
    description: 'Expert advice and guidance in your field',
    sellerType: 'CONSULTANT',
    icon: Icons.support_agent,
  ),
  SellerCategory(
    title: 'Training',
    description: 'Classes, coaching, tuition and workshops',
    sellerType: 'TRAINER',
    icon: Icons.school,
  ),
  SellerCategory(
    title: 'Free Help',
    description: 'Volunteer support and free services for the community',
    sellerType: 'FREE_HELP_PROVIDER',
    icon: Icons.volunteer_activism,
  ),
  SellerCategory(
    title: 'Mixed',
    description: 'A bit of everything: products, services and more',
    sellerType: 'MIXED',
    icon: Icons.category,
  ),
];
