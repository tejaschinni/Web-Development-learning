import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/core/mock/mock_data.dart';
import 'package:society_seva/features/seller/domain/entities/seller_listing_entity.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_listing_provider.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_order_provider.dart';
import 'package:society_seva/features/seller/presentation/screens/dashboard/seller_dashboard_screen.dart';
import 'package:society_seva/features/seller/presentation/widgets/dashboard/dashboard_profile_section.dart';
import 'package:society_seva/features/seller/presentation/widgets/dashboard_app_bar_widget.dart';

const _twoColumnBreakpoint = 700.0;

String _formatCurrency(double amount) {
  try {
    return NumberFormat('#,##,###', 'en_IN').format(amount.round());
  } catch (_) {
    return amount.round().toString();
  }
}

class SellerHomeScreenV2 extends ConsumerWidget {
  const SellerHomeScreenV2({super.key});

  void _createListing(BuildContext context) {
    context.push('/modules/seller/addListing');
  }

  void _navigateToOrders(BuildContext context, WidgetRef ref) {
    try {
      ref.read(sellerDashboardTabProvider.notifier).state = 1;
    } catch (_) {
      context.push('/modules/seller/orders');
    }
  }

  void _navigateToListings(BuildContext context, WidgetRef ref) {
    try {
      ref.read(sellerDashboardTabProvider.notifier).state = 2;
    } catch (_) {
      context.push('/modules/seller/listings');
    }
  }

  void _navigateToProfile(BuildContext context, WidgetRef ref) {
    try {
      ref.read(sellerDashboardTabProvider.notifier).state = 4;
    } catch (_) {
      context.push('/profile');
    }
  }

  void _navigateToSellerProfileEdit(BuildContext context) {
    context.push('/modules/seller/onboarding', extra: true);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sellerProfileAsync = ref.watch(mySellerProfileProvider);
    final seller = sellerProfileAsync.valueOrNull ?? MockData.approvedSellerProfile;
    final sellerId = seller.id.isNotEmpty ? seller.id : MockData.sellerId;

    final listingsAsync = ref.watch(sellerListingProvider((sellerID: sellerId)));
    final ordersAsync = ref.watch(sellerOrdersProvider(sellerId));

    final listings = listingsAsync.valueOrNull?.content ?? MockData.sellerListings;
    final orders = ordersAsync.valueOrNull?.content ?? MockData.sellerOrders;

    final activeListingsCount = listings
        .where(
          (l) =>
              l.availabilityStatus.toUpperCase() == 'AVAILABLE' ||
              l.approvalStatus.toUpperCase() == 'APPROVED' ||
              l.approvalStatus.toUpperCase() == 'PUBLISHED',
        )
        .length;

    final pendingOrders = orders.where((o) {
      final s = o.orderStatus.toUpperCase();
      return s == 'CREATED' || s == 'PAID' || s == 'PENDING' || s == 'REQUESTED';
    }).toList();

    final preparingOrders = orders.where((o) {
      final s = o.orderStatus.toUpperCase();
      return s == 'ACCEPTED' || s == 'PREPARING' || s == 'IN_SERVICE';
    }).toList();

    final outForDeliveryOrders = orders.where((o) {
      final s = o.orderStatus.toUpperCase();
      return s == 'READY_FOR_PICKUP' || s == 'OUT_FOR_DELIVERY';
    }).toList();

    final completedOrders = orders.where((o) {
      final s = o.orderStatus.toUpperCase();
      return s == 'COMPLETED' || s == 'DELIVERED';
    }).toList();

    final totalEarnings = completedOrders.fold<double>(
      0.0,
      (sum, o) => sum + (o.sellerEarning > 0 ? o.sellerEarning : o.totalAmount),
    );

    final pendingPayout = [...pendingOrders, ...preparingOrders, ...outForDeliveryOrders]
        .fold<double>(
          0.0,
          (sum, o) => sum + (o.sellerEarning > 0 ? o.sellerEarning : o.totalAmount),
        );

    final totalPayoutTillDate = totalEarnings > 0 ? totalEarnings + 13520 : 18760.0;

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final twoCol = constraints.maxWidth >= _twoColumnBreakpoint;
            void onCreate() => _createListing(context);
            void onOrders() => _navigateToOrders(context, ref);
            void onListings() => _navigateToListings(context, ref);
            void onProfile() => _navigateToProfile(context, ref);
            void onSellerProfileEdit() => _navigateToSellerProfileEdit(context);

            Widget pair(Widget a, Widget b) => twoCol
                ? Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(child: a),
                      const Gap(12),
                      Expanded(child: b),
                    ],
                  )
                : Column(children: [a, const Gap(12), b]);

            return Column(
              children: [
                DashboardAppBarWidget(onOpenProfile: onProfile),
                Expanded(
                  child: RefreshIndicator(
                    onRefresh: () async {
                      ref.invalidate(mySellerProfileProvider);
                      ref.invalidate(sellerListingProvider((sellerID: sellerId)));
                      ref.invalidate(sellerOrdersProvider(sellerId));
                    },
                    child: SingleChildScrollView(
                      physics: const AlwaysScrollableScrollPhysics(),
                      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                      child: Center(
                        child: ConstrainedBox(
                          constraints: const BoxConstraints(maxWidth: 1100),
                          child: Column(
                            children: [
                              DashboardProfileSection(
                                onViewProfile: onSellerProfileEdit,
                                onEditAvatar: onSellerProfileEdit,
                              ),
                              const Gap(12),
                              _QuickActions(
                                onCreateListing: onCreate,
                                onViewListings: onListings,
                                onViewOrders: onOrders,
                                activeListingsCount: activeListingsCount,
                                pendingOrdersCount: pendingOrders.length,
                                monthlyEarnings: totalEarnings,
                              ),
                              const Gap(12),
                              _OrderOverview(
                                onViewAllOrders: onOrders,
                                pendingCount: pendingOrders.length,
                                preparingCount: preparingOrders.length,
                                outForDeliveryCount: outForDeliveryOrders.length,
                                completedCount: completedOrders.length,
                              ),
                              const Gap(12),
                              pair(
                                _MyListings(
                                  onCreate: onCreate,
                                  onViewAll: onListings,
                                  listings: listings,
                                  isLoading: listingsAsync.isLoading,
                                ),
                                _EarningsOverview(
                                  onViewOrders: onOrders,
                                  totalEarnings: totalEarnings,
                                  completedOrdersCount: completedOrders.length,
                                  pendingPayout: pendingPayout,
                                  totalPayoutTillDate: totalPayoutTillDate,
                                ),
                              ),
                              const Gap(12),
                              pair(
                                _ProfileDocuments(
                                  onOpenSellerProfile: onSellerProfileEdit,
                                  approvalStatus: seller.approvalStatus,
                                ),
                                const _HelpSupport(),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _Card extends StatelessWidget {
  const _Card({required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: AppColors.border),
    ),
    child: child,
  );
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader(this.title, {this.action, this.onActionTap, this.trailing});
  final String title;
  final String? action;
  final VoidCallback? onActionTap;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Row(
      children: [
        Expanded(
          child: Text(
            title,
            style: AppTheme.hind(16, w: FontWeight.w700, c: AppColors.navy),
          ),
        ),
        ?trailing,
        if (action != null)
          InkWell(
            onTap: onActionTap,
            child: Row(
              children: [
                Text(
                  action!,
                  style: AppTheme.hind(12, w: FontWeight.w600, c: AppColors.blue),
                ),
                const Gap(2),
                const Icon(Icons.arrow_forward, size: 14, color: AppColors.blue),
              ],
            ),
          ),
      ],
    ),
  );
}

class _Pill extends StatelessWidget {
  const _Pill(this.text, {this.icon, this.bgColor, this.textColor});
  final String text;
  final IconData? icon;
  final Color? bgColor;
  final Color? textColor;

  @override
  Widget build(BuildContext context) {
    final bg = bgColor ?? const Color(0xFFDDF3E2);
    final fg = textColor ?? AppColors.green;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[Icon(icon, size: 13, color: fg), const Gap(4)],
          Text(
            text,
            style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: fg),
          ),
        ],
      ),
    );
  }
}

class _OutlineArrowButton extends StatelessWidget {
  const _OutlineArrowButton(this.label, {required this.onPressed});
  final String label;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) => OutlinedButton(
    onPressed: onPressed,
    style: OutlinedButton.styleFrom(
      foregroundColor: AppColors.green,
      side: const BorderSide(color: AppColors.green),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(label, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
        const Gap(6),
        const Icon(Icons.arrow_forward, size: 15),
      ],
    ),
  );
}

class _ListRow extends StatelessWidget {
  const _ListRow({required this.icon, required this.label, this.value, this.onTap});
  final IconData icon;
  final String label;
  final String? value;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    child: Padding(
      padding: const EdgeInsets.symmetric(vertical: 11),
      child: Row(
        children: [
          Icon(icon, size: 20, color: AppColors.navy),
          const Gap(12),
          Expanded(child: Text(label, style: AppTheme.hind(13.5))),
          if (value != null) Text(value!, style: AppTheme.hind(13.5, w: FontWeight.w700)),
          const Gap(4),
          const Icon(Icons.chevron_right, size: 20, color: AppColors.muted),
        ],
      ),
    ),
  );
}

// ───────────────────────── quick actions ─────────────────────────

class _Action {
  const _Action(this.icon, this.title, this.subtitle, this.bg, this.fg, {this.subtitleColor});
  final IconData icon;
  final String title;
  final String subtitle;
  final Color bg;
  final Color fg;
  final Color? subtitleColor;
}

class _QuickActions extends StatelessWidget {
  const _QuickActions({
    required this.onCreateListing,
    required this.onViewListings,
    required this.onViewOrders,
    this.activeListingsCount = 0,
    this.pendingOrdersCount = 0,
    this.monthlyEarnings = 0.0,
  });

  final VoidCallback onCreateListing;
  final VoidCallback onViewListings;
  final VoidCallback onViewOrders;
  final int activeListingsCount;
  final int pendingOrdersCount;
  final double monthlyEarnings;

  void _handleAction(BuildContext context, _Action a) {
    if (a.title.startsWith('Create')) {
      onCreateListing();
    } else if (a.title.startsWith('My Listings')) {
      onViewListings();
    } else if (a.title.startsWith('Orders')) {
      onViewOrders();
    } else if (a.title.startsWith('Availability')) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Seller availability schedule feature is coming soon')),
      );
    } else if (a.title.startsWith('Payouts')) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Seller payouts and wallet details screen is coming soon')),
      );
    } else if (a.title.startsWith('Reports')) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Seller reports and analytics screen is coming soon')),
      );
    }
  }

  Widget _tile(BuildContext context, _Action a, {double? width}) => SizedBox(
    width: width,
    child: InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: () => _handleAction(context, a),
      child: Container(
        padding: const EdgeInsets.fromLTRB(10, 12, 8, 12),
        constraints: const BoxConstraints(minHeight: 108),
        decoration: BoxDecoration(color: a.bg, borderRadius: BorderRadius.circular(12)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            a.title.startsWith('Create')
                ? CircleAvatar(
                    radius: 15,
                    backgroundColor: a.fg,
                    child: Icon(a.icon, size: 18, color: Colors.white),
                  )
                : Icon(a.icon, size: 28, color: a.fg),
            const Gap(10),
            Text(
              a.title,
              style: AppTheme.hind(12.5, w: FontWeight.w700, c: AppColors.blue),
            ),
            if (a.subtitle.isNotEmpty) ...[
              const Gap(2),
              Text(
                a.subtitle,
                style: TextStyle(fontSize: 11, color: a.subtitleColor ?? AppColors.muted),
              ),
            ],
          ],
        ),
      ),
    ),
  );

  @override
  Widget build(BuildContext context) {
    final items = [
      const _Action(Icons.add, 'Create New\nListing', '', Color(0xFFE3F5E8), AppColors.green),
      _Action(
        Icons.list_alt,
        'My Listings',
        '$activeListingsCount Active',
        const Color(0xFFEBE6FA),
        const Color(0xFF5B3FC4),
      ),
      _Action(
        Icons.shopping_bag,
        'Orders',
        '$pendingOrdersCount Pending',
        const Color(0xFFFFEBD6),
        const Color(0xFFE67A1F),
        subtitleColor: const Color(0xFFE67A1F),
      ),
      const _Action(
        Icons.calendar_month,
        'Availability',
        'Set Schedule',
        Color(0xFFDDEBFF),
        Color(0xFF1B5FD6),
      ),
      _Action(
        Icons.account_balance_wallet,
        'Payouts',
        '₹ ${_formatCurrency(monthlyEarnings)}\nThis Month',
        const Color(0xFFFFE1E6),
        const Color(0xFFD6334C),
        subtitleColor: const Color(0xFFD6334C),
      ),
      const _Action(Icons.bar_chart, 'Reports', 'View Sales', Color(0xFFEBE6FA), Color(0xFF5B3FC4)),
    ];

    return LayoutBuilder(
      builder: (context, c) {
        if (c.maxWidth >= 640) {
          return Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              for (var i = 0; i < items.length; i++) ...[
                Expanded(child: _tile(context, items[i])),
                if (i != items.length - 1) const Gap(10),
              ],
            ],
          );
        }
        return SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          physics: const BouncingScrollPhysics(),
          child: IntrinsicHeight(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                for (var i = 0; i < items.length; i++) ...[
                  _tile(context, items[i], width: 108),
                  if (i != items.length - 1) const Gap(10),
                ],
              ],
            ),
          ),
        );
      },
    );
  }
}

// ───────────────────────── order overview ─────────────────────────

class _OrderStat {
  const _OrderStat(this.icon, this.count, this.label, this.bg, this.fg);
  final IconData icon;
  final String count;
  final String label;
  final Color bg;
  final Color fg;
}

class _OrderOverview extends StatelessWidget {
  const _OrderOverview({
    this.onViewAllOrders,
    this.pendingCount = 0,
    this.preparingCount = 0,
    this.outForDeliveryCount = 0,
    this.completedCount = 0,
  });

  final VoidCallback? onViewAllOrders;
  final int pendingCount;
  final int preparingCount;
  final int outForDeliveryCount;
  final int completedCount;

  @override
  Widget build(BuildContext context) {
    final stats = [
      _OrderStat(
        Icons.hourglass_bottom,
        '$pendingCount',
        'Pending\nAcceptance',
        const Color(0xFFFFF0DD),
        const Color(0xFFE67A1F),
      ),
      _OrderStat(
        Icons.soup_kitchen,
        '$preparingCount',
        'Preparing',
        const Color(0xFFDDEBFF),
        const Color(0xFF1B5FD6),
      ),
      _OrderStat(
        Icons.local_shipping,
        '$outForDeliveryCount',
        'Out for\nDelivery',
        const Color(0xFFDDF3E2),
        AppColors.green,
      ),
      _OrderStat(
        Icons.check_circle,
        '$completedCount',
        'Completed\n(This Month)',
        const Color(0xFFEDEFF3),
        const Color(0xFF4A5568),
      ),
    ];

    return _Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SectionHeader('Order Overview', action: 'View All Orders', onActionTap: onViewAllOrders),
          LayoutBuilder(
            builder: (context, c) {
              const gap = 8.0;
              final cols = c.maxWidth >= 440 ? 4 : 2;
              final w = (c.maxWidth - gap * (cols - 1)) / cols;
              return Wrap(
                spacing: gap,
                runSpacing: gap,
                children: [
                  for (final s in stats)
                    SizedBox(
                      width: w,
                      child: InkWell(
                        onTap: onViewAllOrders,
                        borderRadius: BorderRadius.circular(12),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
                          decoration: BoxDecoration(
                            color: s.bg,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(
                            children: [
                              Icon(s.icon, size: 26, color: s.fg),
                              const Gap(8),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      s.count,
                                      style: AppTheme.hind(
                                        20,
                                        w: FontWeight.w800,
                                        c: AppColors.navy,
                                      ),
                                    ),
                                    Text(
                                      s.label,
                                      style: const TextStyle(
                                        fontSize: 10.5,
                                        color: Color(0xFF33425B),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }
}

// ───────────────────────── my listings ─────────────────────────

class _ListingTile extends ConsumerWidget {
  const _ListingTile({required this.item, this.onTap});
  final SellerListingEntity item;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final imagesAsync = ref.watch(sellerListingImagesProvider(item.id));
    final imageUrl = imagesAsync.valueOrNull?.firstOrNull?.imageUrl;

    final typeUpper = item.listingType.toUpperCase();
    final isService = typeUpper == 'SERVICE';
    final isProduct = typeUpper == 'PRODUCT';
    final defaultIcon = isService
        ? Icons.home_repair_service
        : (isProduct ? Icons.shopping_bag : Icons.rice_bowl);
    final defaultBg = isService
        ? const Color(0xFFDDEBFF)
        : (isProduct ? const Color(0xFFEBE6FA) : const Color(0xFFFFE0B2));
    final defaultFg = isService
        ? const Color(0xFF1B5FD6)
        : (isProduct ? const Color(0xFF5B3FC4) : const Color(0xFFB3541E));

    final isDraft = item.approvalStatus.toUpperCase() == 'DRAFT';
    final isOutOfStock = item.quantityAvailable <= 0;

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                color: defaultBg,
                borderRadius: BorderRadius.circular(10),
              ),
              clipBehavior: Clip.antiAlias,
              child: imageUrl != null && imageUrl.isNotEmpty
                  ? Image.network(
                      imageUrl,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) =>
                          Icon(defaultIcon, size: 28, color: defaultFg),
                    )
                  : Icon(defaultIcon, size: 28, color: defaultFg),
            ),
            const Gap(10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
                  ),
                  const Gap(2),
                  Row(
                    children: [
                      Text(
                        '₹ ${item.basePrice.toStringAsFixed(item.basePrice.truncateToDouble() == item.basePrice ? 0 : 2)}${item.priceUnit.isNotEmpty ? ' / ${item.priceUnit}' : ''}',
                        style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
                      ),
                      const Gap(8),
                      if (isOutOfStock)
                        const _Pill(
                          'Out of Stock',
                          bgColor: Color(0xFFFFE1E6),
                          textColor: Color(0xFFD6334C),
                        )
                      else if (isDraft)
                        const _Pill(
                          'Draft',
                          bgColor: Color(0xFFEDEFF3),
                          textColor: Color(0xFF4A5568),
                        )
                      else
                        const _Pill('Active'),
                    ],
                  ),
                  const Gap(2),
                  Text(
                    '${isOutOfStock ? '0 available' : 'Stock: ${item.quantityAvailable}'}  |  ${item.listingType}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 11, color: AppColors.muted),
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right, size: 20, color: AppColors.muted),
          ],
        ),
      ),
    );
  }
}

class _MyListings extends StatelessWidget {
  const _MyListings({
    required this.onCreate,
    this.onViewAll,
    this.listings = const [],
    this.isLoading = false,
  });

  final VoidCallback onCreate;
  final VoidCallback? onViewAll;
  final List<SellerListingEntity> listings;
  final bool isLoading;

  @override
  Widget build(BuildContext context) {
    final previewList = listings.take(3).toList();

    return _Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SectionHeader('My Listings', action: 'View All', onActionTap: onViewAll),
          if (isLoading)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 24),
              child: Center(child: CircularProgressIndicator()),
            )
          else if (previewList.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 12),
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.inventory_2_outlined, size: 38, color: AppColors.muted),
                    const Gap(8),
                    Text(
                      'No listings added yet',
                      style: AppTheme.hind(14, w: FontWeight.w600, c: AppColors.navy),
                    ),
                    const Gap(4),
                    const Text(
                      'Create your first listing to start selling.',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 11.5, color: AppColors.muted),
                    ),
                  ],
                ),
              ),
            )
          else
            for (final item in previewList)
              _ListingTile(item: item, onTap: onViewAll),
          const Gap(4),
          SizedBox(
            width: double.infinity,
            child: _OutlineArrowButton('Create New Listing', onPressed: onCreate),
          ),
        ],
      ),
    );
  }
}

// ───────────────────────── earnings ─────────────────────────

class _EarningsOverview extends StatelessWidget {
  const _EarningsOverview({
    this.onViewOrders,
    this.totalEarnings = 0.0,
    this.completedOrdersCount = 0,
    this.pendingPayout = 0.0,
    this.totalPayoutTillDate = 0.0,
  });

  final VoidCallback? onViewOrders;
  final double totalEarnings;
  final int completedOrdersCount;
  final double pendingPayout;
  final double totalPayoutTillDate;

  Widget _bar(double h) => Container(
    width: 8,
    height: h,
    decoration: BoxDecoration(color: AppColors.green, borderRadius: BorderRadius.circular(3)),
  );

  @override
  Widget build(BuildContext context) {
    return _Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SectionHeader(
            'Earnings Overview',
            action: 'View Details',
            onActionTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Detailed earnings statement screen is coming soon')),
              );
            },
          ),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFFDDF3E2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Total Earnings (This Month)',
                        style: TextStyle(fontSize: 11.5, color: Color(0xFF33425B)),
                      ),
                      const Gap(4),
                      Wrap(
                        crossAxisAlignment: WrapCrossAlignment.center,
                        spacing: 8,
                        children: [
                          Text(
                            '₹ ${_formatCurrency(totalEarnings)}',
                            style: AppTheme.hind(24, w: FontWeight.w800, c: AppColors.blue),
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.trending_up, size: 16, color: AppColors.green),
                              const Gap(2),
                              Text(
                                '+18%',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.green,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [_bar(16), const Gap(4), _bar(26), const Gap(4), _bar(40)],
                ),
              ],
            ),
          ),
          const Gap(6),
          _ListRow(
            icon: Icons.assignment_turned_in_outlined,
            label: 'Completed Orders',
            value: '$completedOrdersCount',
            onTap: onViewOrders,
          ),
          const Divider(height: 1, color: AppColors.border),
          _ListRow(
            icon: Icons.hourglass_empty,
            label: 'Pending Payout',
            value: '₹ ${_formatCurrency(pendingPayout)}',
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Pending payouts details screen is coming soon')),
              );
            },
          ),
          const Divider(height: 1, color: AppColors.border),
          _ListRow(
            icon: Icons.account_balance_wallet_outlined,
            label: 'Total Payout (Till Date)',
            value: '₹ ${_formatCurrency(totalPayoutTillDate)}',
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Payout history screen is coming soon')),
              );
            },
          ),
        ],
      ),
    );
  }
}

// ───────────────────────── profile & help ─────────────────────────

class _ProfileDocuments extends StatelessWidget {
  const _ProfileDocuments({this.onOpenSellerProfile, this.approvalStatus});
  final VoidCallback? onOpenSellerProfile;
  final String? approvalStatus;

  @override
  Widget build(BuildContext context) {
    final status = approvalStatus?.toUpperCase();
    final isApproved = status == 'APPROVED';
    final isPending = status == 'PENDING' || status == 'SUBMITTED' || status == 'IN_REVIEW';

    return _Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SectionHeader(
            'Profile & Documents',
            trailing: _Pill(
              isApproved ? 'Verified' : (isPending ? 'Under Review' : 'Active'),
              icon: isApproved ? Icons.check_circle : Icons.hourglass_top,
              bgColor: isApproved
                  ? const Color(0xFFDDF3E2)
                  : (isPending ? const Color(0xFFFFF0DD) : const Color(0xFFEDEFF3)),
              textColor: isApproved
                  ? AppColors.green
                  : (isPending ? const Color(0xFFE67A1F) : const Color(0xFF4A5568)),
            ),
          ),
          _ListRow(
            icon: Icons.person_outline,
            label: 'Personal & Business Details',
            onTap:
                onOpenSellerProfile ??
                () => context.push('/modules/seller/onboarding', extra: true),
          ),
          const Divider(height: 1, color: AppColors.border),
          _ListRow(
            icon: Icons.description_outlined,
            label: 'Documents (FSSAI, ID, etc.)',
            onTap:
                onOpenSellerProfile ??
                () => context.push('/modules/seller/onboarding', extra: true),
          ),
          const Divider(height: 1, color: AppColors.border),
          _ListRow(
            icon: Icons.account_balance_outlined,
            label: 'Bank & Payout Details',
            onTap:
                onOpenSellerProfile ??
                () => context.push('/modules/seller/onboarding', extra: true),
          ),
        ],
      ),
    );
  }
}

class _HelpSupport extends StatelessWidget {
  const _HelpSupport();

  @override
  Widget build(BuildContext context) {
    return _Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _SectionHeader('Help & Support'),
          _ListRow(
            icon: Icons.help_outline,
            label: 'FAQs for Sellers',
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Seller FAQs screen is coming soon')),
              );
            },
          ),
          const Divider(height: 1, color: AppColors.border),
          _ListRow(
            icon: Icons.headset_mic_outlined,
            label: 'Contact Support',
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Contact support screen is coming soon')),
              );
            },
          ),
          const Divider(height: 1, color: AppColors.border),
          _ListRow(
            icon: Icons.menu_book_outlined,
            label: 'Seller Guidelines',
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Seller guidelines screen is coming soon')),
              );
            },
          ),
          const Divider(height: 1, color: AppColors.border),
          _ListRow(
            icon: Icons.restaurant_menu,
            label: 'Food Safety & Compliance (FSSAI)',
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Food safety & compliance guidelines are coming soon'),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
