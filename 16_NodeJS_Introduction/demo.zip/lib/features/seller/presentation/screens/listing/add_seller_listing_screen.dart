// lib/features/seller/presentation/screens/listing/add_seller_listing_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_listing_provider.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/seller/presentation/widgets/listing/listing_submit_sheet.dart';
import 'package:society_seva/features/seller/presentation/widgets/listing/steps/listing_additional_info_step.dart';
import 'package:society_seva/features/seller/presentation/widgets/listing/steps/listing_basic_info_step.dart';
import 'package:society_seva/features/seller/presentation/widgets/listing/steps/listing_photos_step.dart';
import 'package:society_seva/features/seller/presentation/widgets/listing/steps/listing_pricing_step.dart';
import 'package:society_seva/features/seller/presentation/widgets/listing/steps/listing_review_step.dart';
import 'package:society_seva/features/seller/presentation/widgets/listing/steps/select_category_steps.dart';

class AddSellerListingScreen extends ConsumerStatefulWidget {
  const AddSellerListingScreen({super.key, this.isEdit = false, this.listingId});
  final bool isEdit;
  final String? listingId;

  @override
  ConsumerState<AddSellerListingScreen> createState() => _AddSellerListingScreenState();
}

class _AddSellerListingScreenState extends ConsumerState<AddSellerListingScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final notifier = ref.read(productListingProvider.notifier);
      if (widget.isEdit && widget.listingId != null) {
        notifier.loadListingForEdit(widget.listingId!);
      } else {}
    });
  }

  Widget _buildStep(int step) {
    switch (step) {
      case 0:
        return const SelectCatgeoryStep();
      case 1:
        return const ListingBasicInfoStep();
      case 2:
        return const ListingPricingStep();
      case 3:
        return const ListingAdditionalInfoStep();
      case 4:
        return const ListingPhotosStep();
      default:
        return const ListingReviewStep();
    }
  }

  Future<void> _handleSubmit(BuildContext context, WidgetRef ref) async {
    final notifier = ref.read(productListingProvider.notifier);
    final title = notifier.controllers.title.text.trim().isNotEmpty
        ? notifier.controllers.title.text.trim()
        : 'Homemade Veg Thali';

    await notifier.submit();
    if (!context.mounted) return;

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (ctx) => ListingSubmissionResultScreen(
          listingTitle: title,
          onGoToListings: () {
            Navigator.pop(ctx);
            Navigator.pop(context, true);
          },
          onCreateAnother: () {
            Navigator.pop(ctx);
            notifier.goTo(0);
          },
          onViewListing: () {
            Navigator.pop(ctx);
            Navigator.pop(context, true);
          },
        ),
      ),
    );
  }

  Future<void> _persist({required bool submit}) async {
    final notifier = ref.read(productListingProvider.notifier);
    final ok = submit ? await notifier.submit() : await notifier.save();
    if (!mounted) return;

    final messenger = ScaffoldMessenger.of(context);
    if (ok) {
      messenger.showSnackBar(
        SnackBar(
          content: Text(
            submit
                ? 'Listing submitted for approval'
                : widget.isEdit
                ? 'Listing updated'
                : 'Listing saved as draft',
          ),
        ),
      );
      if (submit || widget.isEdit) Navigator.pop(context, true);
    } else {
      final error = ref.read(productListingProvider).error;
      messenger.showSnackBar(SnackBar(content: Text('Something went wrong: $error')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final step = ref.watch(productListingProvider.select((s) => s.currentStep));
    final loading = ref.watch(productListingProvider.select((s) => s.isBusy));
    final busy = ref.watch(productListingProvider.select((s) => s.isBusy));
    final saving = ref.watch(productListingProvider.select((s) => s.isSaving));
    final submitting = ref.watch(productListingProvider.select((s) => s.isSubmitting));
    final canProceed = ref.watch(listingStepValidProvider);
    final listingStatus = ref.watch(productListingProvider);
    final notifier = ref.read(productListingProvider.notifier);

    final isFirst = step == 0;
    final isLast = step == kListingSteps.length - 1;

    void goBack() => isFirst ? Navigator.maybePop(context) : notifier.back();

    if (loading) {
      return const Scaffold(
        backgroundColor: Colors.white,
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return PopScope(
      canPop: isFirst && !busy,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop && !busy) notifier.back();
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: Column(
            children: [
              _Header(onBack: busy ? null : goBack),
              _ListingStepper(currentStep: step, onTap: notifier.goTo),
              const Gap(8),
              Expanded(
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 200),
                  child: KeyedSubtree(key: ValueKey(step), child: _buildStep(step)),
                ),
              ),
              _BottomBar(
                isFirst: isFirst,
                isLast: isLast,
                // isEdit: widget.isEdit, // new: lets the bar show "Update"
                canProceed: canProceed && !busy,
                saving: saving,
                submitting: submitting,
                busy: busy,
                status: listingStatus.approvalStatus,
                onBack: goBack,
                onNext: notifier.next,
                onSave: () => _persist(submit: false),
                onSubmit: () => _handleSubmit(context, ref),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Header extends ConsumerWidget {
  const _Header({required this.onBack});
  final VoidCallback? onBack;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final seller = ref.watch(mySellerProfileProvider).valueOrNull;
    final sellerName = seller?.displayName ?? 'Meena Sharma';

    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 4, 16, 4),
      child: Row(
        children: [
          IconButton(onPressed: onBack, icon: const Icon(Icons.arrow_back)),
          const Gap(4),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(4),
                decoration: const BoxDecoration(
                  color: Color(0xFFE6F3EA),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.eco, size: 16, color: Color(0xFF0E4D2F)),
              ),
              const Gap(6),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: const [
                  Text(
                    'Vasundhara SEVA',
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                      color: Color(0xFF0E4D2F),
                    ),
                  ),
                  Text(
                    'Earn Together • Live Together',
                    style: TextStyle(
                      fontSize: 8.5,
                      fontWeight: FontWeight.w500,
                      color: Color(0xFF7A827D),
                    ),
                  ),
                ],
              ),
            ],
          ),
          const Spacer(),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const CircleAvatar(
                radius: 14,
                backgroundColor: Color(0xFFFFEAD5),
                child: Icon(Icons.person, size: 16, color: Color(0xFFE04F16)),
              ),
              const Gap(6),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    sellerName,
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF1B1F1D),
                    ),
                  ),
                  const Text(
                    'Seller',
                    style: TextStyle(fontSize: 10, color: Color(0xFF7A827D)),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _ListingStepper extends StatelessWidget {
  const _ListingStepper({required this.currentStep, required this.onTap});
  final int currentStep;
  final ValueChanged<int> onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      child: Row(
        children: [
          for (var i = 0; i < kListingSteps.length; i++)
            Expanded(
              child: InkWell(
                onTap: () => onTap(i),
                child: Column(
                  children: [
                    _Dot(index: i, current: currentStep),
                    const Gap(4),
                    Text(
                      kListingSteps[i],
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: i == currentStep ? FontWeight.w700 : FontWeight.w400,
                        color: i == currentStep ? AppColors.green : AppColors.muted,
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _Dot extends StatelessWidget {
  const _Dot({required this.index, required this.current});
  final int index;
  final int current;

  @override
  Widget build(BuildContext context) {
    final done = index < current;
    final active = index == current;
    return Container(
      width: 26,
      height: 26,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: (done || active) ? AppColors.green : Colors.white,
        border: Border.all(color: (done || active) ? AppColors.green : AppColors.border),
      ),
      child: done
          ? const Icon(Icons.check, size: 15, color: Colors.white)
          : Text(
              '${index + 1}',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: active ? Colors.white : AppColors.muted,
              ),
            ),
    );
  }
}

class _BottomBar extends StatelessWidget {
  const _BottomBar({
    required this.isFirst,
    required this.isLast,
    required this.canProceed,
    required this.saving,
    required this.submitting,
    required this.busy,
    required this.onBack,
    required this.onNext,
    required this.onSave,
    required this.onSubmit,
    this.status,
  });

  final bool isFirst, isLast, canProceed, saving, submitting, busy;
  final VoidCallback onBack, onNext, onSave, onSubmit;
  final String? status;

  static const _spinner = SizedBox(
    width: 18,
    height: 18,
    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
  );

  @override
  Widget build(BuildContext context) {
    final outlined = OutlinedButton.styleFrom(
      minimumSize: const Size(0, 52),
      foregroundColor: AppColors.green,
      padding: const EdgeInsets.symmetric(horizontal: 20),
      side: const BorderSide(color: AppColors.green),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
    );
    final filled = FilledButton.styleFrom(
      minimumSize: const Size(0, 52),
      padding: const EdgeInsets.symmetric(horizontal: 20),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
    );

    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: Color(0xFFEFEFEF))),
      ),
      child: isLast
          ? Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    style: outlined,
                    onPressed: (busy || !canProceed) ? null : onSave,
                    child: saving
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Text('Save Draft'),
                  ),
                ),
                const Gap(12),
                Expanded(
                  child: FilledButton(
                    style: filled,
                    onPressed: (busy || !canProceed) ? null : onSubmit,
                    child: submitting
                        ? _spinner
                        : Text(
                            (status != null && status != 'null' && status!.isNotEmpty)
                                ? status!
                                : 'Submit for Review',
                          ),
                  ),
                ),
              ],
            )
          : Row(
              children: [
                Expanded(
                  flex: 4,
                  child: OutlinedButton.icon(
                    style: outlined,
                    onPressed: onBack,
                    icon: const Icon(Icons.arrow_back, size: 18),
                    label: Text(isFirst ? 'Cancel' : 'Back'),
                  ),
                ),
                const Gap(12),
                Expanded(
                  flex: 4,
                  child: FilledButton.icon(
                    style: filled,
                    onPressed: canProceed ? onNext : null,
                    icon: const Icon(Icons.arrow_forward, size: 18),
                    iconAlignment: IconAlignment.end,
                    label: const Text('Next'),
                  ),
                ),
              ],
            ),
    );
  }
}
