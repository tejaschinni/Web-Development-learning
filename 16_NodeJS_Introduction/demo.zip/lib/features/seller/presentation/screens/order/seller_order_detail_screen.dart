import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:society_seva/app/router/app_router.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/domain/entities/seller_order_entity.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_order_provider.dart';
import 'package:society_seva/features/seller/presentation/widgets/dashboard/order_widget.dart';

class OrderDetailsScreen extends ConsumerWidget {
  const OrderDetailsScreen({super.key, this.orderDetailEntity});
  final OrderDetailsArgs? orderDetailEntity;

  Future<void> _changeStatus(BuildContext context, WidgetRef ref, String status) async {
    if (orderDetailEntity!.order.orderStatus != "CREATED" &&
        orderDetailEntity!.order.orderStatus != "PENDING" &&
        orderDetailEntity!.order.orderStatus != "PAID") {
    } else {
      final ok = await ref
          .read(sellerOrderActionProvider.notifier)
          .transition(
            sellerId: orderDetailEntity!.order.sellerId,
            orderId: orderDetailEntity!.order.id,
            newStatus: status,
          );
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            ok ? 'Order ${status.toLowerCase()}' : 'Could not ${status.toLowerCase()} order',
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final SellerOrderEntity orderDetail = orderDetailEntity!.order;
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Column(
          children: [
            const OrderHeader(),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Center(
                    child: Text('Order Details', style: AppTheme.hind(22, w: FontWeight.w700)),
                  ),
                  const Gap(14),
                  if (orderDetail.orderStatus.toLowerCase() == 'created' ||
                      orderDetail.orderStatus.toLowerCase() == 'pending') ...[
                    _pendingBanner(),
                  ],
                  const Gap(12),
                  AppCard(
                    child: Column(
                      children: [
                        _row('Order ID', _Bold(orderDetail.orderNumber)),
                        _row(
                          'Order Date',
                          _Txt(
                            DateFormat('d MMM yyyy, hh:mm a')
                                .format(orderDetail.createdAt.toLocal()),
                          ),
                        ),
                        _row(
                          'Customer',
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _Txt(orderDetailEntity!.buyerName.toString()),
                              const Gap(6),
                              Row(
                                children: [
                                  const Icon(Icons.phone, size: 14, color: AppColors.green),
                                  const Gap(4),
                                  _Txt('+91 98765 43210'),
                                  const Spacer(),
                                  _chatButton(),
                                ],
                              ),
                            ],
                          ),
                        ),
                        _row('Delivery Type', const _Bold('Pickup')),
                        _row(
                          'Pickup Date',
                          _Txt(DateFormat('d MMM yyyy').format(orderDetail.createdAt.toLocal())),
                        ),
                        _row('Pickup Time', const _Txt('12:00 PM - 1:00 PM'), last: true),
                      ],
                    ),
                  ),
                  const Gap(12),
                  AppCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Items', style: AppTheme.hind(14, w: FontWeight.w700)),
                        const Gap(8),
                        ListView.builder(
                          itemCount: orderDetail.items.length,
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(),
                          itemBuilder: (context, index) {
                            return Row(
                              children: [
                                Container(
                                  width: 40,
                                  height: 40,
                                  decoration: BoxDecoration(
                                    color: AppColors.greenSoft,
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: const Icon(
                                    Icons.restaurant,
                                    color: AppColors.green,
                                    size: 22,
                                  ),
                                ),
                                const Gap(10),
                                Expanded(child: _Txt(orderDetail.items[index].titleSnapshot)),
                                _Txt('x ${orderDetail.items[index].quantity}'),
                                const Gap(16),
                                _Bold('\u20B9 ${orderDetail.items[index].unitPrice}'),
                              ],
                            );
                          },
                        ),
                        const Divider(height: 24),
                        Row(
                          children: [
                            Expanded(child: _Bold('Total Amount')),
                            _Bold('\u20B9 ${orderDetail.totalAmount}'),
                          ],
                        ),
                        const Gap(8),
                        Row(
                          children: [
                            const Expanded(child: _Txt('Payment Status')),
                            StatusBadge(
                              label: orderDetail.paymentStatus.toUpperCase(),
                              background: AppColors.greenSoft,
                              foreground: AppColors.green,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
              color: Colors.white,
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedAppButton(
                      label:
                          (orderDetailEntity!.order.orderStatus != "CREATED" &&
                              orderDetailEntity!.order.orderStatus != "PENDING" &&
                              orderDetailEntity!.order.orderStatus != "PAID")
                          ? 'Back'
                          : 'Reject',
                      color:
                          (orderDetailEntity!.order.orderStatus != "CREATED" &&
                              orderDetailEntity!.order.orderStatus != "PENDING" &&
                              orderDetailEntity!.order.orderStatus != "PAID")
                          ? AppColors.green
                          : AppColors.red,
                      onPressed: () {
                        if ((orderDetailEntity!.order.orderStatus != "CREATED" &&
                            orderDetailEntity!.order.orderStatus != "PENDING" &&
                            orderDetailEntity!.order.orderStatus != "PAID")) {
                          context.pop();
                        } else {
                          _changeStatus(context, ref, 'REJECTED');
                        }
                      },
                    ),
                  ),
                  const Gap(12),
                  (orderDetailEntity!.order.orderStatus != "CREATED" &&
                          orderDetailEntity!.order.orderStatus != "PENDING" &&
                          orderDetailEntity!.order.orderStatus != "PAID")
                      ? SizedBox.shrink()
                      : Expanded(
                          flex: 2,
                          child: FilledAppButton(
                            label: 'Accept Order',
                            onPressed: () {
                              _changeStatus(context, ref, 'ACCEPTED');
                            },
                          ),
                        ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _pendingBanner() => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: AppColors.orangeSoft,
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: const Color(0xFFF9D9AE)),
    ),
    child: Row(
      children: [
        const Icon(Icons.hourglass_top, color: AppColors.orange, size: 34),
        const Gap(12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                orderDetailEntity!.order.orderStatus.toLowerCase() == 'created'
                    ? 'Pending Acceptance'
                    : orderDetailEntity!.order.orderStatus.toUpperCase(),
                style: AppTheme.hind(15, w: FontWeight.w700, c: AppColors.orange),
              ),
              Text(
                orderDetailEntity!.order.orderStatus.toLowerCase() == 'created'
                    ? 'Please accept or reject this order\nwithin 1 hour.'
                    : 'Order',
                style: AppTheme.hind(12.5, c: AppColors.muted),
              ),
            ],
          ),
        ),
      ],
    ),
  );

  Widget _chatButton() => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
    decoration: BoxDecoration(
      color: AppColors.greenSoft,
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: AppColors.green.withValues(alpha: 0.4)),
    ),
    child: Row(
      children: [
        const Icon(Icons.chat_bubble_outline, size: 14, color: AppColors.green),
        const Gap(4),
        Text(
          'Chat',
          style: AppTheme.hind(12, w: FontWeight.w600, c: AppColors.green),
        ),
      ],
    ),
  );

  Widget _row(String label, Widget value, {bool last = false}) => Padding(
    padding: EdgeInsets.only(bottom: last ? 0 : 10),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 110,
          child: Text(label, style: AppTheme.hind(13, c: AppColors.muted)),
        ),
        Expanded(child: value),
      ],
    ),
  );
}

class _Txt extends StatelessWidget {
  const _Txt(this.text);
  final String text;
  @override
  Widget build(BuildContext context) => Text(text, style: AppTheme.hind(13.5));
}

class _Bold extends StatelessWidget {
  const _Bold(this.text);
  final String text;
  @override
  Widget build(BuildContext context) => Text(text, style: AppTheme.hind(14, w: FontWeight.w700));
}
