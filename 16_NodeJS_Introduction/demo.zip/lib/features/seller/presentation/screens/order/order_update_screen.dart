import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/app/router/app_router.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/domain/entities/order_status_history_entity.dart';
import 'package:society_seva/features/seller/domain/entities/seller_order_entity.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_order_provider.dart';
import 'package:society_seva/features/seller/presentation/widgets/dashboard/order_widget.dart';

// enum OrderStage { preparing, ready, outOfDelivery, completed }
enum OrderStage {
  paid('PAID'),
  accepted('ACCEPTED'),
  preparing('PREPARING'),
  ready('READY_FOR_PICKUP'),
  outOfDelivery('OUT_FOR_DELIVERY'),
  completed('COMPLETED'),
  cancelled('CANCELLED'),
  unknown('UNKNOWN');

  final String value;
  const OrderStage(this.value);

  static OrderStage orderStageFromApi(String? value) {
    return OrderStage.values.firstWhere(
      (s) => s.value == value?.toUpperCase(),
      orElse: () => OrderStage.unknown,
    );
  }
}

class UpdateOrderStatusScreen extends ConsumerStatefulWidget {
  const UpdateOrderStatusScreen({super.key, required this.orderArgs});
  final OrderStatusUpdateArgs orderArgs;

  @override
  ConsumerState<UpdateOrderStatusScreen> createState() => _UpdateOrderStatusScreenState();
}

class _UpdateOrderStatusScreenState extends ConsumerState<UpdateOrderStatusScreen> {
  late final TextEditingController _note;

  OrderStage get _currentStage => OrderStage.orderStageFromApi(widget.orderArgs.stage.newStatus);

  /// The stage this screen is about to apply.
  OrderStage? get _target {
    switch (_currentStage) {
      case OrderStage.paid:
        return OrderStage.accepted;
      case OrderStage.accepted:
        return OrderStage.preparing;
      case OrderStage.preparing:
        return OrderStage.ready;
      case OrderStage.ready:
        return OrderStage.outOfDelivery;
      case OrderStage.outOfDelivery:
        return OrderStage.completed;
      default:
        return null; // completed, cancelled, unknown
    }
  }

  int get _stepIndex {
    switch (_target) {
      case OrderStage.accepted:
        return 0;
      case OrderStage.preparing:
        return 1;
      case OrderStage.ready:
        return 2;
      case OrderStage.outOfDelivery:
        return 3;
      case OrderStage.completed:
        return 4;
      default:
        return 5; // everything done
    }
  }

  @override
  void initState() {
    super.initState();
    _note = TextEditingController(text: _stageUi[_target]?.defaultNote ?? '');
  }

  @override
  void dispose() {
    _note.dispose();
    super.dispose();
  }

  void _submit(OrderStage next, String note) async {
    final ok = await ref
        .read(sellerOrderActionProvider.notifier)
        .transition(
          sellerId: widget.orderArgs.order.sellerId,
          orderId: widget.orderArgs.stage.orderId.toString(),
          newStatus: next.value.toString(),
          note: note,
        );
    if (ok) {
      Navigator.popUntil(context, (r) => r.isFirst);
    }
  }

  @override
  Widget build(BuildContext context) {
    final target = _target;
    final ui = target == null ? null : _stageUi[target];

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.only(bottom: 20),
          children: [
            const OrderHeader(),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                children: [
                  Text('Update Order Status', style: AppTheme.hind(20, w: FontWeight.w700)),
                  const Gap(16),
                  _StatusStepper(current: _stepIndex),
                  const Gap(16),
                  if (ui == null)
                    AppCard(
                      padding: const EdgeInsets.all(16),
                      child: Text(
                        _currentStage == OrderStage.cancelled
                            ? 'This order was cancelled.'
                            : 'No further updates for this order.',
                        style: AppTheme.hind(14, c: AppColors.muted),
                      ),
                    )
                  else ...[
                    AppCard(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          Container(
                            width: 56,
                            height: 56,
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              color: AppColors.orangeSoft,
                            ),
                            child: HugeIcon(icon: ui.icon, size: 30, color: AppColors.orange),
                          ),
                          const Gap(10),
                          Text(ui.title, style: AppTheme.hind(18, w: FontWeight.w700)),
                          const Gap(4),
                          Text(
                            ui.description,
                            textAlign: TextAlign.center,
                            style: AppTheme.hind(13.5, c: AppColors.muted),
                          ),
                          const Gap(14),
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Text(
                              ui.noteLabel,
                              style: AppTheme.hind(12.5, w: FontWeight.w500),
                            ),
                          ),
                          const Gap(6),
                          TextField(
                            controller: _note,
                            maxLines: 3,
                            maxLength: 200,
                            style: AppTheme.hind(13.5),
                            decoration: InputDecoration(
                              counterStyle: AppTheme.hind(11, c: AppColors.muted),
                              contentPadding: const EdgeInsets.all(12),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8),
                                borderSide: const BorderSide(color: AppColors.border),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8),
                                borderSide: const BorderSide(color: AppColors.green),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Gap(16),
                    if (target == OrderStage.ready) ...[
                      FilledAppButton(
                        label: 'Ready for Pickup',
                        onPressed: () => _submit(OrderStage.ready, _note.text.trim()),
                      ),
                      const Gap(10),
                      OutlinedAppButton(
                        label: 'Ready for Delivery',
                        onPressed: () => _submit(OrderStage.outOfDelivery, _note.text.trim()),
                      ),
                    ] else
                      FilledAppButton(
                        label: ui.buttonLabel,
                        onPressed: () => _submit(target!, _note.text.trim()),
                      ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StageUi {
  final List<List<dynamic>> icon;
  final String title;
  final String description;
  final String noteLabel;
  final String defaultNote;
  final String buttonLabel;

  const _StageUi({
    required this.icon,
    required this.title,
    required this.description,
    required this.noteLabel,
    required this.defaultNote,
    required this.buttonLabel,
  });
}

final Map<OrderStage, _StageUi> _stageUi = {
  OrderStage.accepted: _StageUi(
    icon: HugeIcons.strokeRoundedCheckmarkCircle02,
    title: 'Accept Order',
    description: 'Confirm that you can fulfil\nthis order.',
    noteLabel: 'Add a note (Optional)',
    defaultNote: 'Your order has been accepted.',
    buttonLabel: 'Accept Order',
  ),
  OrderStage.preparing: _StageUi(
    icon: HugeIcons.strokeRoundedChefHat,
    title: 'Mark as Preparing',
    description: 'Confirm that you have started\npreparing the order.',
    noteLabel: 'Add a note (Optional)',
    defaultNote: 'Your order is being prepared.',
    buttonLabel: 'Mark as Preparing',
  ),
  OrderStage.ready: _StageUi(
    icon: HugeIcons.strokeRoundedShoppingBag01,
    title: 'Order Ready',
    description: 'Mark the order as ready for\npickup / dispatch.',
    noteLabel: 'Add a note to customer (Optional)',
    defaultNote: 'Your order is ready for pickup. Thank you!',
    buttonLabel: 'Ready for Pickup',
  ),
  OrderStage.outOfDelivery: _StageUi(
    icon: HugeIcons.strokeRoundedDeliveryTruck01,
    title: 'Out for Delivery',
    description: 'Confirm that the order has\nleft for delivery.',
    noteLabel: 'Add a note to customer (Optional)',
    defaultNote: 'Your order is out for delivery.',
    buttonLabel: 'Out for Delivery',
  ),
  OrderStage.completed: _StageUi(
    icon: HugeIcons.strokeRoundedCheckmarkBadge01,
    title: 'Complete Order',
    description: 'Confirm that the customer has\nreceived the order.',
    noteLabel: 'Add a note (Optional)',
    defaultNote: 'Order completed. Thank you!',
    buttonLabel: 'Mark as Completed',
  ),
};

class _StatusStepper extends StatelessWidget {
  const _StatusStepper({required this.current});
  final int current;

  static const _labels = ['Accepted', 'Preparing', 'Ready', 'Out for Delivery', 'Completed'];
  static final _icons = [
    HugeIcons.strokeRoundedTick02,
    HugeIcons.strokeRoundedChefHat,
    HugeIcons.strokeRoundedShoppingBag01,
    HugeIcons.strokeRoundedDeliveryTruck01,
    HugeIcons.strokeRoundedCheckmarkCircle02,
  ];

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        for (int i = 0; i < _labels.length; i++) ...[
          Column(
            children: [
              _circle(i),
              const Gap(4),
              Text(
                _labels[i],
                style: AppTheme.hind(
                  11.5,
                  w: i == current ? FontWeight.w700 : FontWeight.w400,
                  c: i <= current ? AppColors.ink : AppColors.muted,
                ),
              ),
            ],
          ),
          if (i != _labels.length - 1)
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(bottom: 18),
                child: Container(
                  height: 1.5,
                  color: i < current ? AppColors.green : AppColors.border,
                ),
              ),
            ),
        ],
      ],
    );
  }

  Widget _circle(int i) {
    final done = i < current;
    final active = i == current;
    return Container(
      width: 32,
      height: 32,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: done
            ? AppColors.green
            : active
            ? AppColors.ink
            : Colors.white,
        border: Border.all(
          color: done || active ? Colors.transparent : AppColors.border,
          width: 1.5,
        ),
      ),
      child: HugeIcon(
        icon: done ? HugeIcons.strokeRoundedTick02 : _icons[i],
        size: 17,
        color: done || active ? Colors.white : AppColors.muted,
      ),
    );
  }
}
