import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:intl/intl.dart';
import 'package:society_seva/app/router/app_router.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/domain/entities/order_status_history_entity.dart';
import 'package:society_seva/features/seller/domain/entities/seller_order_entity.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_order_provider.dart';
import 'package:society_seva/features/seller/presentation/widgets/dashboard/order_widget.dart';

class OrderAcceptedScreen extends ConsumerWidget {
  const OrderAcceptedScreen({super.key, this.order});

  final SellerOrderEntity? order;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final orderHistoryAsync = ref.watch(orderStatusHistoryProvider((order!.id.toString())));
    final currentOrder = order;
    final buyerNameProvider = ref.watch(buyerNameByUserIdProvider(order!.buyerId));

    return Scaffold(
      backgroundColor: Colors.white,
      body: orderHistoryAsync.when(
        data: (data) {
          return SafeArea(
            child: Column(
              children: [
                OrderHeader(),
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                    child: Column(
                      children: [
                        const Gap(10),
                        // Large circular green checkmark
                        Container(
                          width: 58,
                          height: 58,
                          decoration: const BoxDecoration(
                            color: AppColors.green,
                            shape: BoxShape.circle,
                          ),
                          child: const Center(
                            child: HugeIcon(
                              icon: HugeIcons.strokeRoundedCheck,
                              color: AppColors.bg,
                              size: 36,
                            ),
                          ),
                        ),
                        const Gap(14),
                        Text(
                          'Order Accepted',
                          style: AppTheme.display(20, w: FontWeight.w800, c: AppColors.ink),
                        ),
                        const Gap(8),
                        Text(
                          'You have accepted the order.\nNow prepare the order and mark it\nas ready when done.',
                          textAlign: TextAlign.center,
                          style: AppTheme.hind(14, c: AppColors.muted, h: 1.4),
                        ),
                        const Gap(28),
                        // Timeline steps container
                        // _buildTimelineCard(currentOrder!),
                        _buildStatusTimeline(data),
                        const Gap(20),
                        // Information tip banner
                        _buildInfoTipBanner(),
                      ],
                    ),
                  ),
                ),
                _buildBottomButtons(
                  context,
                  currentOrder!,
                  data.last,
                  buyerNameProvider.valueOrNull ?? 'Customer',
                  data.last.newStatus,
                ),
              ],
            ),
          );
        },
        error: (error, st) {
          return Text("Error $error and $st");
        },
        loading: () {
          return Center(child: CircularProgressIndicator());
        },
      ),
    );
  }

  Widget _buildVerticalStep({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String? subtitle,
    required bool isCompleted,
    required bool hasLineBelow,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          children: [
            Icon(icon, color: iconColor, size: 22),
            if (hasLineBelow)
              Container(
                width: 1.5,
                height: 38,
                color: isCompleted ? AppColors.green : AppColors.border,
              ),
          ],
        ),
        const Gap(14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: AppTheme.hind(
                  14,
                  w: isCompleted ? FontWeight.w700 : FontWeight.w500,
                  c: isCompleted ? AppColors.ink : AppColors.muted,
                ),
              ),
              if (subtitle != null) ...[
                const Gap(2),
                Text(subtitle, style: AppTheme.hind(12, c: AppColors.muted)),
              ],
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildInfoTipBanner() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.greenSoft,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.green.withValues(alpha: 0.3)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.info_outline_rounded, color: AppColors.green, size: 20),
          const Gap(10),
          Expanded(
            child: Text(
              "Please prepare the order and mark it as 'Ready for Pickup' when it is ready.",
              style: AppTheme.hind(13, c: AppColors.greenDeep, h: 1.3),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomButtons(
    BuildContext context,
    SellerOrderEntity order,
    OrderStatusHistoryEntity latestStatus,
    String name,
    String nextStep,
  ) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: AppColors.border)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: () {
                context.push(
                  '/modules/seller/orderDetails',
                  extra: OrderDetailsArgs(order: order, buyerName: name),
                );
              },
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: AppColors.border),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: Text(
                'View Order Details',
                style: AppTheme.hind(14, w: FontWeight.w600, c: AppColors.ink),
              ),
            ),
          ),
          const Gap(10),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                context.pop();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.green,
                foregroundColor: Colors.white,
                elevation: 0,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: Text(
                'Go to Orders',
                style: AppTheme.hind(14, w: FontWeight.w600, c: Colors.white),
              ),
            ),
          ),
          const Gap(6),
          TextButton(
            onPressed: () {
              context.push(
                '/modules/seller/orderUpdate',
                extra: OrderStatusUpdateArgs(order: order, stage: latestStatus),
              );
            },
            child: Text(
              'Change Order Status',
              style: AppTheme.hind(13, w: FontWeight.w600, c: AppColors.blue),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusTimeline(List<OrderStatusHistoryEntity> history) {
    final Map<String, OrderStatusHistoryEntity> byStatus = {};
    for (final h in history) {
      final existing = byStatus[h.newStatus];
      if (existing == null || h.createdAt.isAfter(existing.createdAt)) {
        byStatus[h.newStatus] = h;
      }
    }

    final dateFormat = DateFormat('dd MMM yyyy, hh:mm a');

    return Column(
      children: List.generate(_orderFlow.length, (index) {
        final step = _orderFlow[index];
        final entry = byStatus[step.status];
        final isCompleted = entry != null;

        return _buildVerticalStep(
          icon: isCompleted ? Icons.check_circle_rounded : Icons.circle_outlined,
          iconColor: isCompleted ? AppColors.green : AppColors.border,
          title: step.label,
          subtitle: isCompleted ? dateFormat.format(entry.createdAt) : null,
          isCompleted: isCompleted,
          hasLineBelow: index != _orderFlow.length - 1,
        );
      }),
    );
  }
}

class _StatusStep {
  final String status;
  final String label;
  const _StatusStep(this.status, this.label);
}

const List<_StatusStep> _orderFlow = [
  _StatusStep('CREATED', 'Order Placed'),
  _StatusStep('PAYMENT_PENDING', 'Payment Pending'),
  _StatusStep('PAID', 'Payment Successful'),
  _StatusStep('ACCEPTED', 'Order Accepted'),
  _StatusStep('PREPARING', 'Preparing'),
  _StatusStep('READY_FOR_PICKUP', 'Ready for Pickup'),
  _StatusStep('OUT_FOR_DELIVERY', 'Out for Delivery'),
  _StatusStep('COMPLETED', 'Completed'),
];
