// lib/features/seller/presentation/screens/dashboard/seller_orders_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:intl/intl.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/domain/entities/seller_order_entity.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_order_provider.dart';
import 'package:society_seva/features/seller/presentation/widgets/orders/order_card_item.dart';

const Color _kNavy = Color(0xFF0B2F6B);
const Color _kPageBg = Color(0xFFF6F8FB);
const Color _kBorderColor = Color(0xFFE2E8F0);

enum _OrderFilter {
  all('All'),
  pending('New Requests'),
  inProgress('In Progress'),
  completed('Completed'),
  rejected('Cancelled / Rejected');

  const _OrderFilter(this.label);
  final String label;
}

class SellerOrdersScreen extends ConsumerStatefulWidget {
  const SellerOrdersScreen({super.key});

  @override
  ConsumerState<SellerOrdersScreen> createState() => _SellerOrdersScreenState();
}

class _SellerOrdersScreenState extends ConsumerState<SellerOrdersScreen> {
  _OrderFilter _selectedFilter = _OrderFilter.all;
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  bool _matchesFilter(SellerOrderEntity order) {
    final status = order.orderStatus.toUpperCase();

    if (_searchQuery.isNotEmpty) {
      final query = _searchQuery.toLowerCase();
      final matchesNumber = order.orderNumber.toLowerCase().contains(query);
      final matchesBuyer = order.buyerId.toLowerCase().contains(query);
      final matchesItems = order.items.any(
        (item) => item.titleSnapshot.toLowerCase().contains(query),
      );
      if (!matchesNumber && !matchesBuyer && !matchesItems) {
        return false;
      }
    }

    switch (_selectedFilter) {
      case _OrderFilter.all:
        return true;
      case _OrderFilter.pending:
        return status == 'PAID' ||
            status == 'CREATED' ||
            status == 'PENDING' ||
            status == 'REQUESTED';
      case _OrderFilter.inProgress:
        return status == 'ACCEPTED' ||
            status == 'PREPARING' ||
            status == 'READY_FOR_PICKUP' ||
            status == 'OUT_FOR_DELIVERY' ||
            status == 'IN_SERVICE';
      case _OrderFilter.completed:
        return status == 'COMPLETED' || status == 'DELIVERED';
      case _OrderFilter.rejected:
        return status == 'REJECTED' || status == 'CANCELLED';
    }
  }

  @override
  Widget build(BuildContext context) {
    final sellerId = ref.watch(mySellerProfileProvider.select((s) => s.valueOrNull?.id));

    if (sellerId == null || sellerId.isEmpty) {
      return Scaffold(
        backgroundColor: _kPageBg,
        body: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.storefront_outlined, size: 54, color: AppColors.muted),
                const Gap(14),
                Text(
                  'Complete your seller profile to see incoming orders.',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.hind(fontSize: 16, fontWeight: FontWeight.w600, color: _kNavy),
                ),
              ],
            ),
          ),
        ),
      );
    }

    final ordersAsync = ref.watch(sellerOrdersProvider(sellerId));

    return Scaffold(
      backgroundColor: _kPageBg,
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: () async => ref.invalidate(sellerOrdersProvider(sellerId)),
          child: ordersAsync.when(
            loading: () => const Center(child: CircularProgressIndicator(color: AppColors.green)),
            error: (e, _) => _ErrorView(
              message: 'Could not load orders',
              details: e.toString(),
              onRetry: () => ref.invalidate(sellerOrdersProvider(sellerId)),
            ),
            data: (page) {
              final allOrders = page.content;
              final filteredOrders = allOrders.where(_matchesFilter).toList();

              final pendingCount = allOrders.where((o) {
                final s = o.orderStatus.toUpperCase();
                return s == 'PAID' || s == 'CREATED' || s == 'PENDING' || s == 'REQUESTED';
              }).length;

              final inProgressCount = allOrders.where((o) {
                final s = o.orderStatus.toUpperCase();
                return s == 'ACCEPTED' ||
                    s == 'PREPARING' ||
                    s == 'READY_FOR_PICKUP' ||
                    s == 'OUT_FOR_DELIVERY';
              }).length;

              final completedCount = allOrders.where((o) {
                final s = o.orderStatus.toUpperCase();
                return s == 'COMPLETED' || s == 'DELIVERED';
              }).length;

              return CustomScrollView(
                slivers: [
                  // Header section
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Orders',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: GoogleFonts.hind(
                                        fontSize: 22,
                                        fontWeight: FontWeight.w800,
                                        color: _kNavy,
                                      ),
                                    ),
                                    // Text(
                                    //   'Review, accept, and fulfill customer orders in real-time',
                                    //   maxLines: 2,
                                    //   overflow: TextOverflow.ellipsis,
                                    //   style: GoogleFonts.hind(
                                    //     fontSize: 12.5,
                                    //     color: const Color(0xFF64748B),
                                    //   ),
                                    // ),
                                  ],
                                ),
                              ),
                            ],
                          ),

                          const Gap(14),

                          // Search Bar
                          // _SearchBar(
                          //   controller: _searchController,
                          //   onChanged: (val) => setState(() => _searchQuery = val.trim()),
                          //   onClear: () {
                          //     _searchController.clear();
                          //     setState(() => _searchQuery = '');
                          //   },
                          // ),
                          // const Gap(12),

                          // Filter Chips Bar
                          SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: Row(
                              children: [
                                for (final filter in _OrderFilter.values)
                                  Padding(
                                    padding: const EdgeInsets.only(right: 8),
                                    child: ChoiceChip(
                                      label: Text(
                                        filter == _OrderFilter.pending && pendingCount > 0
                                            ? '${filter.label} ($pendingCount)'
                                            : filter.label,
                                      ),
                                      selected: _selectedFilter == filter,
                                      selectedColor: filter == _OrderFilter.pending
                                          ? const Color(0xFFF59E0B)
                                          : AppColors.green,
                                      labelStyle: TextStyle(
                                        fontSize: 12.5,
                                        fontWeight: FontWeight.w600,
                                        color: _selectedFilter == filter
                                            ? Colors.white
                                            : const Color(0xFF475569),
                                      ),
                                      backgroundColor: Colors.white,
                                      side: BorderSide(
                                        color: _selectedFilter == filter
                                            ? Colors.transparent
                                            : _kBorderColor,
                                      ),
                                      onSelected: (_) => setState(() => _selectedFilter = filter),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                          const Gap(12),
                        ],
                      ),
                    ),
                  ),

                  // Orders List
                  if (filteredOrders.isEmpty)
                    SliverFillRemaining(
                      hasScrollBody: false,
                      child: _EmptyOrdersView(
                        filter: _selectedFilter,
                        hasSearchQuery: _searchQuery.isNotEmpty,
                        onReset: () {
                          _searchController.clear();
                          setState(() {
                            _searchQuery = '';
                            _selectedFilter = _OrderFilter.all;
                          });
                        },
                      ),
                    )
                  else
                    SliverPadding(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 96),
                      sliver: SliverList(
                        delegate: SliverChildBuilderDelegate((context, index) {
                          final order = filteredOrders[index];

                          return Padding(
                            padding: const EdgeInsets.only(bottom: 12),
                            child: OrderCard(order: order),
                          );
                        }, childCount: filteredOrders.length),
                      ),
                    ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

class _EmptyOrdersView extends StatelessWidget {
  const _EmptyOrdersView({
    required this.filter,
    required this.hasSearchQuery,
    required this.onReset,
  });

  final _OrderFilter filter;
  final bool hasSearchQuery;
  final VoidCallback onReset;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: const BoxDecoration(color: Color(0xFFF1F5F9), shape: BoxShape.circle),
              child: const Icon(Icons.inbox_outlined, size: 48, color: Color(0xFF94A3B8)),
            ),
            const Gap(16),
            Text(
              hasSearchQuery ? 'No matching orders found' : 'No orders in "${filter.label}"',
              style: GoogleFonts.hind(fontSize: 16, fontWeight: FontWeight.w700, color: _kNavy),
            ),
            const Gap(6),
            Text(
              hasSearchQuery
                  ? 'Try searching with a different order number or keyword.'
                  : 'Orders matching this category will appear here.',
              textAlign: TextAlign.center,
              style: GoogleFonts.hind(fontSize: 13, color: const Color(0xFF64748B)),
            ),
            const Gap(16),
            if (hasSearchQuery || filter != _OrderFilter.all)
              OutlinedButton(
                onPressed: onReset,
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.green,
                  side: const BorderSide(color: AppColors.green),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: const Text('Show All Orders'),
              ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// ERROR VIEW
// ─────────────────────────────────────────────────────────────────────────────

class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.message, required this.details, required this.onRetry});

  final String message;
  final String details;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline, size: 48, color: AppColors.red),
            const Gap(12),
            Text(
              message,
              style: GoogleFonts.hind(fontSize: 16, fontWeight: FontWeight.w700, color: _kNavy),
            ),
            const Gap(6),
            Text(
              details,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: GoogleFonts.hind(fontSize: 12, color: AppColors.muted),
            ),
            const Gap(16),
            FilledButton.icon(
              onPressed: onRetry,
              icon: const Icon(Icons.refresh, size: 18),
              label: const Text('Retry'),
              style: FilledButton.styleFrom(backgroundColor: AppColors.green),
            ),
          ],
        ),
      ),
    );
  }
}
