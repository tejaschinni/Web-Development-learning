import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/core/providers/app_providers.dart';
import 'package:society_seva/features/seller/data/datasources/seller_category_remote_datasource.dart';
import 'package:society_seva/features/seller/domain/entities/seller_category_entity.dart';
import 'package:society_seva/features/seller/domain/repositories/seller_category_repository.dart';
import 'package:society_seva/features/shop/data/models/shop_category_model.dart';

final sellerCategoryRemoteDataSource = Provider<SellerCategoryRemoteDatasource>((ref) {
  return SellerCategoryRemoteDatasourceImpl(ref.watch(apiClientProvider));
});

final sellerCategoryRepository = Provider<SellerCategoryRepository>((ref) {
  return SellerCategoryRepositoryImpl(ref.watch(sellerCategoryRemoteDataSource));
});

final sellerCategoryListingProvider =
    FutureProvider.family<
      PageResponse<CategoriesEntity>,
      ({String? categoryType, String? parentCategoryId, bool? rootsOnly, String? search})
    >((ref, args) {
      return ref
          .watch(sellerCategoryRepository)
          .fetchCategoriesRepo(
            categoryType: args.categoryType,
            parentCategoryId: args.parentCategoryId,
            rootsOnly: args.rootsOnly,
            search: args.search,
          );
    });

final sellerCategoryTreeProvider =
    FutureProvider.family<List<ShopCategoryModel>, ({String? categoryType})>((ref, args) {
      return ref
          .watch(sellerCategoryRepository)
          .fetchCategoriesTreeRepo(categoryType: args.categoryType);
    });
