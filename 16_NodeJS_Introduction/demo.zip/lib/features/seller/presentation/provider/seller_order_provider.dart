import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/core/providers/app_providers.dart';
import 'package:society_seva/features/seller/data/datasources/seller_order_remote_data_source.dart';
import 'package:society_seva/features/seller/domain/entities/order_status_history_entity.dart';
import 'package:society_seva/features/seller/domain/entities/seller_order_entity.dart';
import 'package:society_seva/features/seller/domain/repositories/seller_order_repository.dart';

final sellerOrderRemoteDataSource = Provider<SellerOrderRemoteDataSource>((ref) {
  return SellerOrderRemoteDataSourceImpl(ref.watch(apiClientProvider));
});

final sellerOrderRepository = Provider<SellerOrderRepository>((ref) {
  return SellerOrderRepositoryImpl(ref.watch(sellerOrderRemoteDataSource));
});

final sellerOrdersProvider = FutureProvider.autoDispose
    .family<PageResponse<SellerOrderEntity>, String>((ref, sellerId) {
      return ref.watch(sellerOrderRepository).fetchSellerOrdersRepo(sellerId: sellerId);
    });

final orderStatusHistoryProvider = FutureProvider.autoDispose
    .family<List<OrderStatusHistoryEntity>, String>((ref, orderId) {
      return ref.watch(sellerOrderRepository).fetchOrderStatusHistoryRepo(orderID: orderId);
    });

final buyerNameByUserIdProvider = FutureProvider.family<String, String>((ref, id) {
  return ref.watch(sellerOrderRepository).fetchBuyerIdRepo(buyerId: id);
});

const kSellerOrderTransitions = <String>[
  'ACCEPTED',
  'REJECTED',
  'PREPARING',
  'READY_FOR_PICKUP',
  'OUT_FOR_DELIVERY',
  'IN_SERVICE',
  'COMPLETED',
];

class SellerOrderActionState {
  const SellerOrderActionState({this.busyOrderId, this.error});

  final String? busyOrderId;
  final Object? error;

  bool isBusy(String orderId) => busyOrderId == orderId;
}

final sellerOrderActionProvider =
    NotifierProvider<SellerOrderActionNotifier, SellerOrderActionState>(
      SellerOrderActionNotifier.new,
    );

class SellerOrderActionNotifier extends Notifier<SellerOrderActionState> {
  @override
  SellerOrderActionState build() => const SellerOrderActionState();

  Future<bool> transition({
    required String sellerId,
    required String orderId,
    required String newStatus,
    String? note,
  }) async {
    state = SellerOrderActionState(busyOrderId: orderId);
    try {
      await ref
          .read(sellerOrderRepository)
          .transitionOrderRepo(orderId: orderId, newStatus: newStatus, note: note);
      ref.invalidate(sellerOrdersProvider(sellerId));
      state = const SellerOrderActionState();
      return true;
    } catch (e) {
      state = SellerOrderActionState(error: e);
      return false;
    }
  }
}
