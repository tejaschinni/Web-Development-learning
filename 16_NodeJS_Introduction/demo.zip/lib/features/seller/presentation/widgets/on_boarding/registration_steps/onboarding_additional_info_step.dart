import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/domain/enum/seller_type_config.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/lable_widget.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/onboarding_availablitiy_step.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/onboarding_dropdown_list_widget.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/onboarding_lanugage_widget.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/onboarding_section_card_widget.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/onboarding_text_field_widget.dart';

class OnboardingAdditionalInfoStep extends ConsumerWidget {
  final SellerRegState s;
  final void Function(SellerRegState Function(SellerRegState s) f) onUpdate;
  final String sellerType;
  final ValueChanged<String?> onSellerTypeChanged;
  const OnboardingAdditionalInfoStep({
    super.key,
    required this.onUpdate,
    required this.s,
    required this.sellerType,
    required this.onSellerTypeChanged,
  });

  static const _foodType = 'FOOD_SELLER';

  bool get _isFood => sellerType == _foodType;

  bool get _showFssaiField => _isFood || s.hasFssai == true;
  bool get isValid {
    if (sellerType.isEmpty) return false;

    return true;
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final availability = ref.watch(sellerFormActionProvider.select((x) => x.availability));

    return Column(
      children: [
        OnboardingSectionCardWidget(
          color: AppColors.green.withValues(alpha: 150),
          icon: Icons.person,
          title: 'Additional Info',
          subtitle: 'Tell us about your business.',
          children: [
            if (sellerTypes.contains('FOOD') == false) ...[
              const Gap(12),
              const LableWidget('Do you have an FSSAI / license number?', required: true),
              OnboardingDropdownListWidget<bool>(
                key: ValueKey('hasFssai-$sellerType'),
                hint: 'Select Yes or No',
                icon: Icons.help_outline,
                value: s.hasFssai,
                items: const [true, false],
                labelBuilder: (b) => b ? 'Yes' : 'No',
                onChanged: (v) => onUpdate((x) => x.copyWith(hasFssai: v)),
              ),
            ],

            if (_showFssaiField) ...[
              const Gap(12),
              const LableWidget('FSSAI / license number', required: true),
              OnboardingTextFieldWidget(
                hint: 'Enter FSSAI / license number',
                icon: Icons.verified_outlined,
                initial: s.fssaiCertificateId,
                onChanged: (v) => onUpdate((x) => x.copyWith(fssaiCertificateId: v)),
              ),
            ],
            const Gap(12),
            const LableWidget('Website URL', required: false),
            OnboardingTextFieldWidget(
              hint: 'Website URL',
              icon: Icons.language,
              initial: s.websiteUrl,
              onChanged: (v) => onUpdate((x) => x.copyWith(websiteUrl: v)),
            ),
            const Gap(12),
            const LableWidget('Social Media Links', required: false),
            OnboardingTextFieldWidget(
              hint: 'Social Media Links',
              icon: Icons.share,
              initial: s.socialMediaLinks,
              onChanged: (v) => onUpdate((x) => x.copyWith(socialMediaLinks: v)),
            ),
            const Gap(12),
            const LableWidget('Legal Compliance', required: false),
            OnboardingTextFieldWidget(
              hint: 'Legal Compliance',
              icon: Icons.gavel,
              maxLineLength: 2,
              initial: s.legalCompliance,
              onChanged: (v) => onUpdate((x) => x.copyWith(legalCompliance: v)),
            ),
          ],
        ),

        OnboardingSectionCardWidget(
          color: AppColors.green.withValues(alpha: 150),
          icon: Icons.schedule,
          title: 'Preferences',
          subtitle: 'Tell us about your business availability.',
          children: [
            OnboardingLanugageWidget(
              language: s.language,
              onLanguageChanged: (lang) => onUpdate((cur) => cur.copyWith(language: lang)),
            ),
            const Gap(16),
            OnboardingAvailablitiyStep(
              value: availability,
              onChanged: (v) {
                ref.read(sellerFormActionProvider.notifier).setAvailability(v);
                onUpdate((x) => x.copyWith(days: v.days, from: v.from, to: v.to));
              },
            ),
            const Gap(16),
            const LableWidget('Additional Information (Optional)', required: false),
            OnboardingTextFieldWidget(
              hint: 'Tell us about your product or services, your experince, etc.',
              icon: Icons.info,
              initial: s.bio,
              maxLineLength: 3,
              maxLength: 300,
              onChanged: (v) => onUpdate((x) => x.copyWith(description: v)),
            ),
          ],
        ),
      ],
    );
  }
}
