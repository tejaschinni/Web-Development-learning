import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

// ─────────────────────────── Theme ───────────────────────────
const _green = Color(0xFF1B6B3A);
const _greenLight = Color(0xFFE8F3EC);
const _border = Color(0xFFE0E0E0);
const _textGrey = Color(0xFF6B6B6B);

// ─────────────────────────── State ───────────────────────────
enum SellerKind { individual, smallBusiness, registered, artist, workshop }

class SellerRegState {
  final int step; // 0..2

  // Step 1
  final String fullName, mobile, otp, email;
  final bool otpSent, otpVerified;
  final SellerKind? sellerKind;

  // Step 2
  final Set<String> categories; // Food / Art & Creative
  final String businessName, city, locality, pickupAddress, radius;

  // Step 3
  final String language;
  final Set<String> days;
  final TimeOfDay from, to;
  final String description;
  final Map<String, String?> documents; // docKey -> picked file name

  const SellerRegState({
    this.step = 0,
    this.fullName = '',
    this.mobile = '',
    this.otp = '',
    this.email = '',
    this.otpSent = false,
    this.otpVerified = false,
    this.sellerKind,
    this.categories = const {'Food'},
    this.businessName = '',
    this.city = 'Pune',
    this.locality = '',
    this.pickupAddress = '',
    this.radius = '',
    this.language = 'English',
    this.days = const {'Mon', 'Tue', 'Wed', 'Thu', 'Fri'},
    this.from = const TimeOfDay(hour: 9, minute: 0),
    this.to = const TimeOfDay(hour: 18, minute: 0),
    this.description = '',
    this.documents = const {},
  });

  SellerRegState copyWith({
    int? step,
    String? fullName,
    String? mobile,
    String? otp,
    String? email,
    bool? otpSent,
    bool? otpVerified,
    SellerKind? sellerKind,
    Set<String>? categories,
    String? businessName,
    String? city,
    String? locality,
    String? pickupAddress,
    String? radius,
    String? language,
    Set<String>? days,
    TimeOfDay? from,
    TimeOfDay? to,
    String? description,
    Map<String, String?>? documents,
  }) => SellerRegState(
    step: step ?? this.step,
    fullName: fullName ?? this.fullName,
    mobile: mobile ?? this.mobile,
    otp: otp ?? this.otp,
    email: email ?? this.email,
    otpSent: otpSent ?? this.otpSent,
    otpVerified: otpVerified ?? this.otpVerified,
    sellerKind: sellerKind ?? this.sellerKind,
    categories: categories ?? this.categories,
    businessName: businessName ?? this.businessName,
    city: city ?? this.city,
    locality: locality ?? this.locality,
    pickupAddress: pickupAddress ?? this.pickupAddress,
    radius: radius ?? this.radius,
    language: language ?? this.language,
    days: days ?? this.days,
    from: from ?? this.from,
    to: to ?? this.to,
    description: description ?? this.description,
    documents: documents ?? this.documents,
  );
}

class SellerRegNotifier extends Notifier<SellerRegState> {
  @override
  SellerRegState build() => const SellerRegState();

  void update(SellerRegState Function(SellerRegState s) f) => state = f(state);

  void next() {
    if (state.step < 2) state = state.copyWith(step: state.step + 1);
  }

  void back() {
    if (state.step > 0) state = state.copyWith(step: state.step - 1);
  }

  void toggleCategory(String c) {
    final set = {...state.categories};
    set.contains(c) ? set.remove(c) : set.add(c);
    if (set.isEmpty) return; // at least one
    state = state.copyWith(categories: set);
  }

  void toggleDay(String d) {
    final set = {...state.days};
    set.contains(d) ? set.remove(d) : set.add(d);
    state = state.copyWith(days: set);
  }

  void setDocument(String key, String? file) =>
      state = state.copyWith(documents: {...state.documents, key: file});

  Future<void> sendOtp() async => state = state.copyWith(otpSent: true);
  Future<void> verifyOtp() async => state = state.copyWith(otpVerified: true);
  Future<void> saveDraft() async {}
  Future<void> submit() async {}
}

final sellerRegProvider = NotifierProvider<SellerRegNotifier, SellerRegState>(
  SellerRegNotifier.new,
);

// ─────────────────────────── Screen ───────────────────────────
class SellerRegistrationScreen extends ConsumerWidget {
  const SellerRegistrationScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(sellerRegProvider);
    final n = ref.read(sellerRegProvider.notifier);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black87),
          onPressed: () => s.step == 0 ? Navigator.maybePop(context) : n.back(),
        ),
        titleSpacing: 0,
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Seller Registration',
              style: TextStyle(color: Colors.black87, fontSize: 17, fontWeight: FontWeight.w700),
            ),
            Text(
              'Create your seller account to list food and\nArt & Creative products or services',
              style: TextStyle(color: _textGrey, fontSize: 10.5),
            ),
          ],
        ),
        toolbarHeight: 64,
      ),
      body: Column(
        children: [
          _StepIndicator(current: s.step),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
              child: switch (s.step) {
                0 => _BasicDetailsStep(s: s, n: n),
                1 => _AddressStep(s: s, n: n),
                _ => _PreferencesStep(s: s, n: n),
              },
            ),
          ),
          _BottomBar(s: s, n: n),
        ],
      ),
    );
  }
}

// ─────────────────────────── Step indicator ───────────────────────────
class _StepIndicator extends StatelessWidget {
  final int current;
  const _StepIndicator({required this.current});

  @override
  Widget build(BuildContext context) {
    const labels = ['Basic Details', 'Address &\nService Area', 'Preferences\n& Submit'];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: List.generate(5, (i) {
          if (i.isOdd) {
            final done = current > i ~/ 2;
            return Expanded(
              child: Padding(
                padding: const EdgeInsets.only(top: 15),
                child: Divider(thickness: 2, color: done ? _green : _border, height: 2),
              ),
            );
          }
          final idx = i ~/ 2;
          final active = idx <= current;
          return SizedBox(
            width: 70,
            child: Column(
              children: [
                CircleAvatar(
                  radius: 15,
                  backgroundColor: active ? _green : Colors.white,
                  child: Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: active ? _green : _border, width: 1.5),
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      '${idx + 1}',
                      style: TextStyle(
                        color: active ? Colors.white : _textGrey,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  labels[idx],
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 10,
                    height: 1.2,
                    color: active ? _green : _textGrey,
                    fontWeight: active ? FontWeight.w600 : FontWeight.w400,
                  ),
                ),
              ],
            ),
          );
        }),
      ),
    );
  }
}

// ─────────────────────────── Step 1 ───────────────────────────
class _BasicDetailsStep extends StatelessWidget {
  final SellerRegState s;
  final SellerRegNotifier n;
  const _BasicDetailsStep({required this.s, required this.n});

  @override
  Widget build(BuildContext context) {
    return _SectionCard(
      color: _greenLight,
      icon: Icons.person,
      title: 'Basic Details',
      subtitle: 'Tell us about yourself.',
      children: [
        const _Label('Full Name', required: true),
        _Field(
          hint: 'Enter your full name',
          icon: Icons.person_outline,
          initial: s.fullName,
          onChanged: (v) => n.update((x) => x.copyWith(fullName: v)),
        ),
        const SizedBox(height: 12),
        const _Label('Mobile Number', required: true),
        Row(
          children: [
            Container(
              height: 44,
              padding: const EdgeInsets.symmetric(horizontal: 8),
              decoration: _boxDecoration(),
              child: const Row(
                children: [
                  Text('🇮🇳', style: TextStyle(fontSize: 16)),
                  SizedBox(width: 4),
                  Text('+91', style: TextStyle(fontSize: 13)),
                  Icon(Icons.keyboard_arrow_down, size: 16),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _Field(
                hint: 'Enter mobile number',
                keyboard: TextInputType.phone,
                maxLength: 10,
                formatters: [FilteringTextInputFormatter.digitsOnly],
                initial: s.mobile,
                onChanged: (v) => n.update((x) => x.copyWith(mobile: v)),
              ),
            ),
            const SizedBox(width: 8),
            _GreenButton(label: 'Send OTP', onTap: s.mobile.length == 10 ? n.sendOtp : null),
          ],
        ),
        const SizedBox(height: 12),
        const _Label('Enter OTP', required: true),
        Row(
          children: [
            Expanded(
              child: _OtpBoxes(
                length: 6,
                enabled: s.otpSent,
                onChanged: (v) => n.update((x) => x.copyWith(otp: v)),
              ),
            ),
            const SizedBox(width: 8),
            _GreenButton(
              label: s.otpVerified ? 'Verified' : 'Verify',
              onTap: s.otpSent && s.otp.length == 6 && !s.otpVerified ? n.verifyOtp : null,
            ),
          ],
        ),
        const SizedBox(height: 12),
        const _Label('Email Address'),
        _Field(
          hint: 'Enter your email address (optional)',
          icon: Icons.mail_outline,
          keyboard: TextInputType.emailAddress,
          initial: s.email,
          onChanged: (v) => n.update((x) => x.copyWith(email: v)),
        ),
        const SizedBox(height: 12),
        const _Label('Profile Photo', optional: true),
        Row(
          children: [
            InkWell(
              onTap: () {
                /* TODO: pick image */
              },
              child: Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _border),
                ),
                child: const Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.camera_alt, color: _green),
                    Text('Add Photo', style: TextStyle(fontSize: 9)),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 12),
            const Expanded(
              child: Text(
                '• Upload a clear photo of yourself\n• JPG or PNG (Max 2MB)',
                style: TextStyle(fontSize: 11, color: _textGrey, height: 1.5),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        const _Label('Seller Type', required: true),
        _SellerTypeGrid(
          selected: s.sellerKind,
          onSelect: (k) => n.update((x) => x.copyWith(sellerKind: k)),
        ),
      ],
    );
  }
}

class _SellerTypeGrid extends StatelessWidget {
  final SellerKind? selected;
  final ValueChanged<SellerKind> onSelect;
  const _SellerTypeGrid({required this.selected, required this.onSelect});

  @override
  Widget build(BuildContext context) {
    const items = <(SellerKind, IconData, String)>[
      (SellerKind.individual, Icons.home_work_outlined, 'Individual /\nHome-based seller'),
      (SellerKind.smallBusiness, Icons.storefront, 'Small business /\nShop'),
      (SellerKind.registered, Icons.business, 'Registered\nbusiness'),
      (SellerKind.artist, Icons.palette_outlined, 'Artist / Creator'),
      (SellerKind.workshop, Icons.groups_outlined, 'Workshop / Class\nprovider'),
    ];
    return LayoutBuilder(
      builder: (context, c) {
        final w = (c.maxWidth - 16) / 3;
        return Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (final (k, icon, label) in items)
              InkWell(
                onTap: () => onSelect(k),
                child: Container(
                  width: w,
                  height: 84,
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: selected == k ? _greenLight : Colors.white,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: selected == k ? _green : _border,
                      width: selected == k ? 1.5 : 1,
                    ),
                  ),
                  child: Stack(
                    children: [
                      Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(icon, color: Colors.orange.shade800, size: 28),
                            const SizedBox(height: 4),
                            Text(
                              label,
                              textAlign: TextAlign.center,
                              style: const TextStyle(fontSize: 10, height: 1.2),
                            ),
                          ],
                        ),
                      ),
                      if (selected == k)
                        const Positioned(
                          right: 0,
                          top: 0,
                          child: CircleAvatar(
                            radius: 8,
                            backgroundColor: _green,
                            child: Icon(Icons.check, size: 11, color: Colors.white),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
          ],
        );
      },
    );
  }
}

// ─────────────────────────── Step 2 ───────────────────────────
class _AddressStep extends StatelessWidget {
  final SellerRegState s;
  final SellerRegNotifier n;
  const _AddressStep({required this.s, required this.n});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _SectionCard(
          color: const Color(0xFFFCEFF3),
          icon: Icons.grid_view_rounded,
          iconColor: Colors.pink,
          title: 'Seller Category',
          subtitle: 'Select the categories you want to sell.',
          children: [
            Row(
              children: [
                Expanded(
                  child: _CategoryTile(
                    icon: Icons.restaurant,
                    title: 'Food',
                    sub: 'Homemade meals, snacks,\nbakery, sweets, etc.',
                    selected: s.categories.contains('Food'),
                    onTap: () => n.toggleCategory('Food'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _CategoryTile(
                    icon: Icons.palette,
                    title: 'Art & Creative',
                    sub: 'Handmade gifts, décor,\nclasses & more.',
                    selected: s.categories.contains('Art & Creative'),
                    onTap: () => n.toggleCategory('Art & Creative'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: _greenLight, borderRadius: BorderRadius.circular(8)),
              child: const Row(
                children: [
                  Icon(Icons.info, color: _green, size: 16),
                  SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      'You can choose both Food and Art & Creative under the same SEVA account and manage everything from a single dashboard.',
                      style: TextStyle(fontSize: 10, color: _green),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        _SectionCard(
          color: const Color(0xFFFFF6E5),
          icon: Icons.storefront,
          iconColor: Colors.orange,
          title: 'Business / Display Name',
          subtitle: 'This name will be visible to community members.',
          children: [
            const _Label('Business / Display Name', required: true),
            _Field(
              hint: 'Enter business or display name',
              initial: s.businessName,
              onChanged: (v) => n.update((x) => x.copyWith(businessName: v)),
            ),
            const SizedBox(height: 4),
            const Text(
              'Example: Anita\'s Kitchen, Yash Art Corner, Meera Gifts Studio',
              style: TextStyle(fontSize: 10, color: _textGrey),
            ),
          ],
        ),
        const SizedBox(height: 12),
        _SectionCard(
          color: const Color(0xFFE9F1FB),
          icon: Icons.location_on,
          iconColor: Colors.blue,
          title: 'Location & Service Area',
          subtitle: 'Set your address and delivery or service area.',
          children: [
            Row(
              children: [
                Expanded(
                  child: _Dropdown(
                    label: 'City',
                    required: true,
                    value: s.city,
                    items: const ['Pune', 'Mumbai', 'Nashik', 'Nagpur'],
                    onChanged: (v) => n.update((x) => x.copyWith(city: v)),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _Dropdown(
                    label: 'Locality',
                    required: true,
                    hint: 'Select locality',
                    value: s.locality.isEmpty ? null : s.locality,
                    items: const ['Kothrud', 'Baner', 'Hadapsar', 'Wakad'],
                    onChanged: (v) => n.update((x) => x.copyWith(locality: v)),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            const _Label('Pickup Address', required: true),
            Row(
              children: [
                Expanded(
                  child: _Field(
                    hint: 'Enter complete pickup address',
                    icon: Icons.location_on_outlined,
                    initial: s.pickupAddress,
                    onChanged: (v) => n.update((x) => x.copyWith(pickupAddress: v)),
                  ),
                ),
                const SizedBox(width: 8),
                OutlinedButton.icon(
                  onPressed: () {
                    /* TODO: current location + reverse geocode */
                  },
                  icon: const Icon(Icons.my_location, size: 14),
                  label: const Text('Use My Location', style: TextStyle(fontSize: 10)),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.blue,
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _Dropdown(
                        label: 'Service / Delivery Radius',
                        required: true,
                        hint: 'Select radius',
                        value: s.radius.isEmpty ? null : s.radius,
                        items: const ['1 km', '3 km', '5 km', '10 km', 'Custom'],
                        onChanged: (v) => n.update((x) => x.copyWith(radius: v)),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        'e.g. 1 km, 3 km, 5 km, 10 km or Custom',
                        style: TextStyle(fontSize: 10, color: _textGrey),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 10),
                // Map preview placeholder – replace with GoogleMap widget
                Container(
                  width: 120,
                  height: 90,
                  decoration: BoxDecoration(
                    color: const Color(0xFFDCEBDD),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  alignment: Alignment.center,
                  child: Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _green.withOpacity(.25),
                      border: Border.all(color: _green),
                    ),
                    child: const Icon(Icons.location_on, color: _green),
                  ),
                ),
              ],
            ),
          ],
        ),
      ],
    );
  }
}

class _CategoryTile extends StatelessWidget {
  final IconData icon;
  final String title, sub;
  final bool selected;
  final VoidCallback onTap;
  const _CategoryTile({
    required this.icon,
    required this.title,
    required this.sub,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: selected ? _greenLight : Colors.white,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: selected ? _green : _border, width: selected ? 1.5 : 1),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: selected ? _green : Colors.orange.shade800, size: 24),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
                  ),
                ),
                CircleAvatar(
                  radius: 8,
                  backgroundColor: selected ? _green : Colors.white,
                  child: selected
                      ? const Icon(Icons.check, size: 11, color: Colors.white)
                      : Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: _border),
                          ),
                        ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(sub, style: const TextStyle(fontSize: 9.5, color: _textGrey)),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────── Step 3 ───────────────────────────
class _PreferencesStep extends StatelessWidget {
  final SellerRegState s;
  final SellerRegNotifier n;
  const _PreferencesStep({required this.s, required this.n});

  static const _days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  static const _langs = ['English', 'Marathi', 'Hindi'];

  Future<void> _pickTime(BuildContext context, bool isFrom) async {
    final t = await showTimePicker(context: context, initialTime: isFrom ? s.from : s.to);
    if (t != null) {
      n.update((x) => isFrom ? x.copyWith(from: t) : x.copyWith(to: t));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _SectionCard(
          color: const Color(0xFFF3ECFA),
          icon: Icons.tune,
          iconColor: Colors.deepPurple,
          title: 'Preferences',
          subtitle: 'Set your preferences and additional information.',
          children: [
            const _Label('Preferred Language', optional: true),
            Row(
              children: [
                for (final l in _langs)
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ChoiceChip(
                        label: SizedBox(
                          width: double.infinity,
                          child: Text(l, textAlign: TextAlign.center),
                        ),
                        selected: s.language == l,
                        selectedColor: _greenLight,
                        side: BorderSide(color: s.language == l ? _green : _border),
                        labelStyle: TextStyle(
                          fontSize: 12,
                          color: s.language == l ? _green : Colors.black87,
                        ),
                        onSelected: (_) => n.update((x) => x.copyWith(language: l)),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            const _Label('Service Availability'),
            const Text(
              'Let buyers know when you are available.',
              style: TextStyle(fontSize: 10, color: _textGrey),
            ),
            const SizedBox(height: 6),
            Row(
              children: [
                for (final d in _days)
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(right: 4),
                      child: InkWell(
                        onTap: () => n.toggleDay(d),
                        child: Container(
                          height: 30,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: s.days.contains(d) ? _greenLight : Colors.white,
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(color: s.days.contains(d) ? _green : _border),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              if (s.days.contains(d))
                                const Icon(Icons.check, size: 9, color: _green),
                              Text(
                                d,
                                style: TextStyle(
                                  fontSize: 9.5,
                                  color: s.days.contains(d) ? _green : Colors.black87,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: _TimeField(
                    label: 'Available From',
                    value: s.from.format(context),
                    onTap: () => _pickTime(context, true),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _TimeField(
                    label: 'Available To',
                    value: s.to.format(context),
                    onTap: () => _pickTime(context, false),
                  ),
                ),
              ],
            ),
          ],
        ),
        const SizedBox(height: 12),
        _SectionCard(
          color: _greenLight,
          icon: Icons.info,
          title: 'Additional Information',
          subtitle: 'This helps buyers know about you.',
          children: [
            const _Label('Short Description', optional: true),
            TextFormField(
              initialValue: s.description,
              maxLines: 3,
              maxLength: 250,
              style: const TextStyle(fontSize: 13),
              decoration: _inputDecoration(
                hint: 'Tell us about your products or services. You can edit this later.',
              ),
              onChanged: (v) => n.update((x) => x.copyWith(description: v)),
            ),
          ],
        ),
        const SizedBox(height: 12),
        _SectionCard(
          color: const Color(0xFFFFF1E3),
          icon: Icons.verified_user,
          iconColor: Colors.deepOrange,
          title: 'Document Verification',
          subtitle: 'Upload required documents (mandatory for registered categories).',
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: const Color(0xFFE9F1FB),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Row(
                children: [
                  Icon(Icons.info, color: Colors.blue, size: 16),
                  SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      'For Food category, FSSAI or other required verification may be needed before you can accept orders. You can add them now or later.',
                      style: TextStyle(fontSize: 10, color: Colors.blue),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: _DocTile(
                    title: 'Identity Proof',
                    sub: '(Aadhaar / PAN)',
                    file: s.documents['identity'],
                    onUpload: () => n.setDocument('identity', 'identity_proof'),
                  ),
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: _DocTile(
                    title: 'Address Proof',
                    sub: '(If required)',
                    file: s.documents['address'],
                    onUpload: () => n.setDocument('address', 'address_proof'),
                  ),
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: _DocTile(
                    title: 'FSSAI License',
                    sub: '(Food category)',
                    file: s.documents['fssai'],
                    onUpload: () => n.setDocument('fssai', 'fssai_license'),
                  ),
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: _DocTile(
                    title: 'Other Documents',
                    sub: '(Optional)',
                    file: s.documents['other'],
                    onUpload: () => n.setDocument('other', 'other_document'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: _greenLight, borderRadius: BorderRadius.circular(8)),
              child: const Row(
                children: [
                  Icon(Icons.info, color: _green, size: 16),
                  SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      'You can save as Draft and complete later. After submission, your account will be reviewed and you will be notified about the status.',
                      style: TextStyle(fontSize: 10, color: _green),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _DocTile extends StatelessWidget {
  final String title, sub;
  final String? file;
  final VoidCallback onUpload;
  const _DocTile({
    required this.title,
    required this.sub,
    required this.file,
    required this.onUpload,
  });

  @override
  Widget build(BuildContext context) {
    final done = file != null;
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: done ? _green : _border),
      ),
      child: Column(
        children: [
          Text(
            title,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 9.5, fontWeight: FontWeight.w600),
          ),
          Text(
            sub,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 8.5, color: _textGrey),
          ),
          const SizedBox(height: 6),
          InkWell(
            onTap: onUpload, // TODO: file picker
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
              decoration: BoxDecoration(
                border: Border.all(color: _green),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Column(
                children: [
                  Icon(done ? Icons.check_circle : Icons.add, color: _green, size: 14),
                  Text(
                    done ? 'Added' : 'Upload',
                    style: const TextStyle(fontSize: 9, color: _green),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TimeField extends StatelessWidget {
  final String label, value;
  final VoidCallback onTap;
  const _TimeField({required this.label, required this.value, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _Label(label),
        InkWell(
          onTap: onTap,
          child: Container(
            height: 44,
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: _boxDecoration(),
            child: Row(
              children: [
                const Icon(Icons.access_time, size: 16, color: _textGrey),
                const SizedBox(width: 6),
                Expanded(child: Text(value, style: const TextStyle(fontSize: 13))),
                const Icon(Icons.keyboard_arrow_down, size: 18),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

// ─────────────────────────── Bottom bar ───────────────────────────
class _BottomBar extends StatelessWidget {
  final SellerRegState s;
  final SellerRegNotifier n;
  const _BottomBar({required this.s, required this.n});

  @override
  Widget build(BuildContext context) {
    final isLast = s.step == 2;
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
      decoration: const BoxDecoration(
        color: Colors.white,
        boxShadow: [BoxShadow(color: Color(0x14000000), blurRadius: 8, offset: Offset(0, -2))],
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            if (s.step > 0) ...[
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: n.back,
                  icon: const Icon(Icons.arrow_back, size: 16),
                  label: const Text('Back'),
                  style: _outlined(),
                ),
              ),
              const SizedBox(width: 8),
            ],
            if (isLast) ...[
              Expanded(
                child: OutlinedButton(
                  onPressed: n.saveDraft,
                  style: _outlined(),
                  child: const Text('Save as Draft'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                flex: 2,
                child: ElevatedButton(
                  onPressed: n.submit,
                  style: _filled(),
                  child: const Text('Submit Registration'),
                ),
              ),
            ] else
              Expanded(
                flex: 2,
                child: ElevatedButton(
                  onPressed: n.next,
                  style: _filled(),
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('Next'),
                      SizedBox(width: 6),
                      Icon(Icons.arrow_forward, size: 16),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  ButtonStyle _outlined() => OutlinedButton.styleFrom(
    foregroundColor: _green,
    side: const BorderSide(color: _green),
    minimumSize: const Size.fromHeight(46),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
  );

  ButtonStyle _filled() => ElevatedButton.styleFrom(
    backgroundColor: _green,
    foregroundColor: Colors.white,
    minimumSize: const Size.fromHeight(46),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
  );
}

// ─────────────────────────── Shared widgets ───────────────────────────
BoxDecoration _boxDecoration() => BoxDecoration(
  color: Colors.white,
  borderRadius: BorderRadius.circular(8),
  border: Border.all(color: _border),
);

InputDecoration _inputDecoration({String? hint, IconData? icon}) => InputDecoration(
  hintText: hint,
  hintStyle: const TextStyle(fontSize: 12, color: Color(0xFF9E9E9E)),
  prefixIcon: icon == null ? null : Icon(icon, size: 18, color: _textGrey),
  counterText: '',
  isDense: true,
  filled: true,
  fillColor: Colors.white,
  contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 13),
  border: OutlineInputBorder(
    borderRadius: BorderRadius.circular(8),
    borderSide: const BorderSide(color: _border),
  ),
  enabledBorder: OutlineInputBorder(
    borderRadius: BorderRadius.circular(8),
    borderSide: const BorderSide(color: _border),
  ),
  focusedBorder: OutlineInputBorder(
    borderRadius: BorderRadius.circular(8),
    borderSide: const BorderSide(color: _green),
  ),
);

class _SectionCard extends StatelessWidget {
  final Color color;
  final Color iconColor;
  final IconData icon;
  final String title, subtitle;
  final List<Widget> children;
  const _SectionCard({
    required this.color,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.children,
    this.iconColor = _green,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(.55),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 15,
                backgroundColor: iconColor,
                child: Icon(icon, size: 16, color: Colors.white),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                    Text(subtitle, style: const TextStyle(fontSize: 10.5, color: _textGrey)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ...children,
        ],
      ),
    );
  }
}

class _Label extends StatelessWidget {
  final String text;
  final bool required, optional;
  const _Label(this.text, {this.required = false, this.optional = false});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Text.rich(
        TextSpan(
          text: text,
          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
          children: [
            if (required)
              const TextSpan(
                text: ' *',
                style: TextStyle(color: Colors.red),
              ),
            if (optional)
              const TextSpan(
                text: ' (Optional)',
                style: TextStyle(fontWeight: FontWeight.w400, color: _textGrey, fontSize: 10),
              ),
          ],
        ),
      ),
    );
  }
}

class _Field extends StatelessWidget {
  final String hint;
  final IconData? icon;
  final String initial;
  final TextInputType? keyboard;
  final int? maxLength;
  final List<TextInputFormatter>? formatters;
  final ValueChanged<String> onChanged;
  const _Field({
    required this.hint,
    required this.onChanged,
    this.icon,
    this.initial = '',
    this.keyboard,
    this.maxLength,
    this.formatters,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 44,
      child: TextFormField(
        initialValue: initial,
        keyboardType: keyboard,
        maxLength: maxLength,
        inputFormatters: formatters,
        style: const TextStyle(fontSize: 13),
        decoration: _inputDecoration(hint: hint, icon: icon),
        onChanged: onChanged,
      ),
    );
  }
}

class _Dropdown extends StatelessWidget {
  final String label;
  final bool required;
  final String? hint, value;
  final List<String> items;
  final ValueChanged<String> onChanged;
  const _Dropdown({
    required this.label,
    required this.items,
    required this.onChanged,
    this.required = false,
    this.hint,
    this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _Label(label, required: required),
        SizedBox(
          height: 44,
          child: DropdownButtonFormField<String>(
            value: value,
            isExpanded: true,
            hint: Text(hint ?? '', style: const TextStyle(fontSize: 12)),
            decoration: _inputDecoration(),
            items: [
              for (final i in items)
                DropdownMenuItem(
                  value: i,
                  child: Text(i, style: const TextStyle(fontSize: 13)),
                ),
            ],
            onChanged: (v) => v == null ? null : onChanged(v),
          ),
        ),
      ],
    );
  }
}

class _GreenButton extends StatelessWidget {
  final String label;
  final VoidCallback? onTap;
  const _GreenButton({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 44,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: _green,
          foregroundColor: Colors.white,
          disabledBackgroundColor: const Color(0xFFE6E6E6),
          disabledForegroundColor: const Color(0xFF9E9E9E),
          padding: const EdgeInsets.symmetric(horizontal: 12),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
        child: Text(label, style: const TextStyle(fontSize: 12)),
      ),
    );
  }
}

class _OtpBoxes extends StatefulWidget {
  final int length;
  final bool enabled;
  final ValueChanged<String> onChanged;
  const _OtpBoxes({required this.length, required this.enabled, required this.onChanged});

  @override
  State<_OtpBoxes> createState() => _OtpBoxesState();
}

class _OtpBoxesState extends State<_OtpBoxes> {
  late final List<TextEditingController> _c = List.generate(
    widget.length,
    (_) => TextEditingController(),
  );
  late final List<FocusNode> _f = List.generate(widget.length, (_) => FocusNode());

  @override
  void dispose() {
    for (final c in _c) {
      c.dispose();
    }
    for (final f in _f) {
      f.dispose();
    }
    super.dispose();
  }

  void _changed(int i, String v) {
    if (v.isNotEmpty && i < widget.length - 1) _f[i + 1].requestFocus();
    if (v.isEmpty && i > 0) _f[i - 1].requestFocus();
    widget.onChanged(_c.map((e) => e.text).join());
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: List.generate(widget.length, (i) {
        return SizedBox(
          width: 32,
          height: 40,
          child: TextField(
            controller: _c[i],
            focusNode: _f[i],
            enabled: widget.enabled,
            textAlign: TextAlign.center,
            keyboardType: TextInputType.number,
            maxLength: 1,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
            decoration: _inputDecoration().copyWith(
              contentPadding: EdgeInsets.zero,
              fillColor: widget.enabled ? Colors.white : const Color(0xFFF5F5F5),
            ),
            onChanged: (v) => _changed(i, v),
          ),
        );
      }),
    );
  }
}
