import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:society_seva/app/theme/app_theme.dart';

class CapabilityOption {
  final String label;
  final IconData icon;
  final String? imageAsset;

  const CapabilityOption(this.label, this.icon, {this.imageAsset});
}

class CapabilitySection {
  final String title;
  final List<CapabilityOption> options;

  const CapabilitySection(this.title, this.options);
}

const capabilitySections = <String, CapabilitySection>{
  'FOOD_SELLER': CapabilitySection('Food Capabilities', [
    CapabilityOption('Homemade meals and tiffin', Icons.lunch_dining),
    CapabilityOption('Snacks and namkeen', Icons.fastfood),
    CapabilityOption('Cakes and bakery', Icons.cake),
    CapabilityOption('Sweets and seasonal desserts', Icons.icecream),
    CapabilityOption('Pickles, chutneys and homemade products', Icons.soup_kitchen),
    CapabilityOption('Festival and special-occasion food', Icons.celebration),
    CapabilityOption('Catering and bulk orders', Icons.room_service),
    CapabilityOption('Custom food orders', Icons.edit_note),
  ]),
  'ART_SELLER': CapabilitySection('Art & Creative Capabilities', [
    CapabilityOption('Handmade gifts', Icons.card_giftcard),
    CapabilityOption('Paintings and artwork', Icons.brush),
    CapabilityOption('Jewellery and accessories', Icons.diamond),
    CapabilityOption('Home decor', Icons.chair),
    CapabilityOption('Custom art orders', Icons.edit_note),
  ]),
};

String _key(String s) => s.trim().toLowerCase();

class OnboardingDeclaredCapabilitiesStep extends StatefulWidget {
  final List<String> sellerTypes;
  final List<String> selected;
  final ValueChanged<List<String>> onChanged;

  const OnboardingDeclaredCapabilitiesStep({
    super.key,
    required this.sellerTypes,
    required this.selected,
    required this.onChanged,
  });

  @override
  State<OnboardingDeclaredCapabilitiesStep> createState() =>
      _OnboardingDeclaredCapabilitiesStepState();
}

class _OnboardingDeclaredCapabilitiesStepState extends State<OnboardingDeclaredCapabilitiesStep> {
  final _search = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Set<String> get _knownKeys => {
    for (final sec in capabilitySections.values)
      for (final o in sec.options) _key(o.label),
  };

  bool _isSelected(String label) => widget.selected.any((s) => _key(s) == _key(label));

  void _toggle(String label) {
    final next = List<String>.from(widget.selected);
    if (_isSelected(label)) {
      next.removeWhere((s) => _key(s) == _key(label));
    } else {
      next.add(label);
    }
    widget.onChanged(next);
  }

  void _addCustom(String text) {
    final t = text.trim();
    if (t.isEmpty) return;
    String label = t;
    for (final sec in capabilitySections.values) {
      for (final o in sec.options) {
        if (_key(o.label) == _key(t)) label = o.label;
      }
    }
    if (!_isSelected(label)) widget.onChanged([...widget.selected, label]);
    _search.clear();
    setState(() => _query = '');
    FocusScope.of(context).unfocus();
  }

  bool _matches(CapabilityOption o) => _query.isEmpty || _key(o.label).contains(_key(_query));

  @override
  Widget build(BuildContext context) {
    final sections = [
      for (final t in widget.sellerTypes)
        if (capabilitySections[t] != null) capabilitySections[t]!,
    ];

    final known = _knownKeys;
    final customOptions = [
      for (final s in widget.selected)
        if (!known.contains(_key(s))) CapabilityOption(s, Icons.edit_outlined),
    ];

    final visibleCustom = customOptions.where(_matches).toList();
    final allKeys = {...known, ...customOptions.map((o) => _key(o.label))};
    final showAddTile = _query.trim().isNotEmpty && !allKeys.contains(_key(_query));

    return Column(
      crossAxisAlignment: .start,
      children: [
        const Gap(15),
        Text(
          'What can you provide?',
          style: GoogleFonts.hind(fontSize: 20, fontWeight: FontWeight.w700),
        ),
        const Gap(6),
        Text(
          'Select the items or services you are willing and able to provide. '
          'These are your declared capabilities and will be used to match you '
          'with relevant customer requests.',
          style: GoogleFonts.hind(fontSize: 12.5, color: AppColors.muted),
        ),
        const Gap(14),
        _buildSearch(),
        const Gap(8),
        if (showAddTile) _AddTile(text: _query.trim(), onTap: () => _addCustom(_query)),
        for (final sec in sections) ..._section(sec.title, sec.options.where(_matches).toList()),
        if (visibleCustom.isNotEmpty) ..._section('Your additions', visibleCustom),
        if (sections.isEmpty && visibleCustom.isEmpty && !showAddTile)
          Padding(
            padding: const EdgeInsets.only(top: 12),
            child: Text(
              'Type above to add what you provide.',
              style: GoogleFonts.hind(fontSize: 12.5, color: AppColors.muted),
            ),
          ),
      ],
    );
  }

  Widget _buildSearch() => TextField(
    controller: _search,
    textInputAction: TextInputAction.done,
    style: GoogleFonts.hind(fontSize: 13),
    onChanged: (v) => setState(() => _query = v),
    onSubmitted: _addCustom,
    decoration: InputDecoration(
      hintText: 'Search items or subcategories',
      hintStyle: GoogleFonts.hind(fontSize: 12, color: const Color(0xFF9E9E9E)),
      prefixIcon: Icon(Icons.search, size: 18, color: AppColors.muted),
      suffixIcon: _query.isEmpty
          ? null
          : IconButton(
              icon: const Icon(Icons.close, size: 18),
              onPressed: () {
                _search.clear();
                setState(() => _query = '');
              },
            ),
      isDense: true,
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 13),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide(color: AppColors.border),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide(color: AppColors.border),
      ),
      focusedBorder: const OutlineInputBorder(
        borderRadius: BorderRadius.all(Radius.circular(8)),
        borderSide: BorderSide(color: AppColors.green),
      ),
    ),
  );

  List<Widget> _section(String title, List<CapabilityOption> options) {
    if (options.isEmpty) return const [];
    return [
      const Gap(10),
      Row(
        children: [
          Expanded(
            child: Text(title, style: GoogleFonts.hind(fontSize: 15, fontWeight: FontWeight.w700)),
          ),
          Text(
            'Select all that apply',
            style: GoogleFonts.hind(fontSize: 11.5, color: AppColors.green),
          ),
        ],
      ),
      const Gap(8),
      LayoutBuilder(
        builder: (context, c) {
          final w = (c.maxWidth - 10) / 2;
          return Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              for (final o in options)
                SizedBox(
                  width: w,
                  child: _CapabilityCard(
                    option: o,
                    selected: _isSelected(o.label),
                    onTap: () => _toggle(o.label),
                  ),
                ),
            ],
          );
        },
      ),
    ];
  }
}

class _AddTile extends StatelessWidget {
  final String text;
  final VoidCallback onTap;

  const _AddTile({required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(8),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        decoration: BoxDecoration(
          color: AppColors.green.withValues(alpha: 0.06),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: AppColors.green),
        ),
        child: Row(
          children: [
            const Icon(Icons.add_circle_outline, size: 18, color: AppColors.green),
            const Gap(8),
            Expanded(
              child: Text(
                'Add "$text"',
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.hind(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: AppColors.green,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CapabilityCard extends StatelessWidget {
  final CapabilityOption option;
  final bool selected;
  final VoidCallback onTap;

  const _CapabilityCard({required this.option, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(8),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        constraints: const BoxConstraints(minHeight: 64),
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: selected ? AppColors.green.withValues(alpha: 0.06) : Colors.white,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: selected ? AppColors.green : AppColors.border,
            width: selected ? 1.5 : 1,
          ),
        ),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: option.imageAsset != null
                  ? Image.asset(option.imageAsset!, width: 44, height: 44, fit: BoxFit.cover)
                  : Container(
                      width: 44,
                      height: 44,
                      color: AppColors.green.withValues(alpha: 0.10),
                      child: Icon(option.icon, size: 22, color: AppColors.green),
                    ),
            ),
            const Gap(8),
            Expanded(
              child: Text(
                option.label,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.hind(
                  fontSize: 12,
                  height: 1.2,
                  fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
                ),
              ),
            ),
            const Gap(4),
            Icon(
              selected ? Icons.check_box : Icons.check_box_outline_blank,
              size: 20,
              color: selected ? AppColors.green : AppColors.muted,
            ),
          ],
        ),
      ),
    );
  }
}
