import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/onboarding_section_card_widget.dart';

class LanguageOption {
  final String value;
  final String label;

  const LanguageOption(this.value, this.label);
}

const preferredLanguages = <LanguageOption>[
  LanguageOption('ENGLISH', 'English'),
  LanguageOption('MARATHI', 'Marathi'),
  LanguageOption('HINDI', 'Hindi'),
];

class OnboardingLanugageWidget extends StatelessWidget {
  final String? language;
  final ValueChanged<String> onLanguageChanged;
  final List<LanguageOption> options;
  final List<Widget> children;

  const OnboardingLanugageWidget({
    super.key,
    required this.language,
    required this.onLanguageChanged,
    this.options = preferredLanguages,
    this.children = const [],
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: .start,
      crossAxisAlignment: .start,
      children: [
        RichText(
          text: TextSpan(
            style: GoogleFonts.hind(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: Colors.black87,
            ),
            children: [
              const TextSpan(text: 'Preferred Language '),
              TextSpan(
                text: '(Optional)',
                style: GoogleFonts.hind(
                  fontSize: 12,
                  fontWeight: FontWeight.w400,
                  color: AppColors.muted,
                ),
              ),
            ],
          ),
        ),
        const Gap(8),
        Row(
          children: [
            for (var i = 0; i < options.length; i++) ...[
              if (i > 0) const Gap(10),
              Expanded(
                child: _RadioCard(
                  label: options[i].label,
                  selected: language == options[i].value,
                  onTap: () => onLanguageChanged(options[i].value),
                ),
              ),
            ],
          ],
        ),
        ...children,
      ],
    );
  }
}

class _RadioCard extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _RadioCard({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(8),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
        decoration: BoxDecoration(
          color: selected ? AppColors.green.withValues(alpha: 0.08) : Colors.white,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: selected ? AppColors.green : AppColors.border,
            width: selected ? 1.5 : 1,
          ),
        ),
        child: Row(
          children: [
            Icon(
              selected ? Icons.radio_button_checked : Icons.radio_button_unchecked,
              size: 20,
              color: selected ? AppColors.green : AppColors.muted,
            ),
            const Gap(8),
            Expanded(
              child: Text(
                label,
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.hind(
                  fontSize: 13,
                  fontWeight: selected ? FontWeight.w600 : FontWeight.w400,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
