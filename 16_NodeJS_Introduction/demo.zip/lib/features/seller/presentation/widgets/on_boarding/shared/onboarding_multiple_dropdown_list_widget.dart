import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:society_seva/app/theme/app_theme.dart';

class OnboardingMultipleDropdownListWidget<T> extends StatelessWidget {
  final String hint;
  final IconData? icon;
  final List<T> values;
  final List<T> items;
  final ValueChanged<List<T>>? onChanged; // null => disabled
  final String Function(T item)? labelBuilder;
  final String? Function(List<T>)? validator;

  const OnboardingMultipleDropdownListWidget({
    super.key,
    required this.hint,
    required this.items,
    required this.onChanged,
    this.values = const [],
    this.icon,
    this.labelBuilder,
    this.validator,
  });

  String _label(T t) => labelBuilder?.call(t) ?? t.toString();

  InputDecoration _inputDecoration(String? errorText) => InputDecoration(
    hintText: hint,
    hintStyle: AppTheme.hind(12, c: const Color(0xFF9E9E9E)),
    prefixIcon: icon == null ? null : Icon(icon, size: 18, color: AppColors.muted),
    suffixIcon: const Icon(Icons.keyboard_arrow_down, size: 20),
    errorText: errorText,
    counterText: '',
    isDense: true,
    filled: true,
    fillColor: onChanged == null ? const Color(0xFFF5F5F5) : Colors.white,
    contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 13),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: BorderSide(color: AppColors.border),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: BorderSide(color: AppColors.border),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: const BorderSide(color: AppColors.border),
    ),
    disabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: BorderSide(color: AppColors.border),
    ),
  );

  Future<List<T>?> _openSheet(BuildContext context) {
    final temp = List<T>.from(values);
    return showModalBottomSheet<List<T>>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheetState) => SafeArea(
          child: ConstrainedBox(
            constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.7),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 12, 8, 8),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          hint,
                          style: GoogleFonts.hind(fontSize: 15, fontWeight: FontWeight.w600),
                        ),
                      ),
                      TextButton(
                        onPressed: () => setSheetState(temp.clear),
                        child: Text('Clear', style: GoogleFonts.hind(fontSize: 13)),
                      ),
                    ],
                  ),
                ),
                const Divider(height: 1),
                Flexible(
                  child: ListView(
                    shrinkWrap: true,
                    children: items.map((item) {
                      return CheckboxListTile(
                        dense: true,
                        value: temp.contains(item),
                        controlAffinity: ListTileControlAffinity.leading,
                        title: Text(_label(item), style: GoogleFonts.hind(fontSize: 13)),
                        onChanged: (v) => setSheetState(() {
                          if (v == true) {
                            temp.add(item);
                          } else {
                            temp.remove(item);
                          }
                        }),
                      );
                    }).toList(),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: () => Navigator.pop(ctx, temp),
                      child: Text(
                        'Done${temp.isEmpty ? '' : ' (${temp.length})'}',
                        style: GoogleFonts.hind(fontSize: 14),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Keep only values that exist in items (same guard as the dropdown).
    final current = values.where(items.contains).toList();

    return FormField<List<T>>(
      initialValue: current,
      validator: validator == null ? null : (v) => validator!(v ?? const []),
      builder: (state) {
        // Sync the form field with the parent's value.
        if (state.value != null && !_sameList(state.value!, current)) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (state.mounted) state.didChange(current);
          });
        }

        return InkWell(
          borderRadius: BorderRadius.circular(8),
          onTap: onChanged == null
              ? null
              : () async {
                  final result = await _openSheet(state.context);
                  if (result != null) {
                    state.didChange(result);
                    onChanged!(result);
                  }
                },
          child: InputDecorator(
            decoration: _inputDecoration(state.errorText),
            isEmpty: current.isEmpty,
            child: current.isEmpty
                ? null
                : Wrap(
                    spacing: 6,
                    runSpacing: 4,
                    children: current.map((v) {
                      return Chip(
                        label: Text(_label(v), style: GoogleFonts.hind(fontSize: 12)),
                        visualDensity: VisualDensity.compact,
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        backgroundColor: Colors.white,
                        side: BorderSide(color: AppColors.border),
                        onDeleted: onChanged == null
                            ? null
                            : () {
                                final next = current.where((e) => e != v).toList();
                                state.didChange(next);
                                onChanged!(next);
                              },
                      );
                    }).toList(),
                  ),
          ),
        );
      },
    );
  }

  static bool _sameList<E>(List<E> a, List<E> b) {
    if (a.length != b.length) return false;
    for (var i = 0; i < a.length; i++) {
      if (a[i] != b[i]) return false;
    }
    return true;
  }
}
