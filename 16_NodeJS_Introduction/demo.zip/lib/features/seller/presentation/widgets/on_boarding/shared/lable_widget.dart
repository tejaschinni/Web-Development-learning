import 'package:flutter/material.dart';
import 'package:society_seva/app/theme/app_theme.dart';

class LableWidget extends StatelessWidget {
  final String text;
  final bool required, optional;
  const LableWidget(this.text, {super.key, this.required = false, this.optional = false});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Text.rich(
        TextSpan(
          text: text,
          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
          children: [
            if (required)
              const TextSpan(
                text: ' *',
                style: TextStyle(color: Colors.red),
              ),
            if (optional)
              const TextSpan(
                text: ' (Optional)',
                style: TextStyle(fontWeight: FontWeight.w400, color: AppColors.muted, fontSize: 10),
              ),
          ],
        ),
      ),
    );
  }
}
