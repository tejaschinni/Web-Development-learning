import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:society_seva/app/theme/app_theme.dart';

class OnboardingSectionCardWidget extends StatelessWidget {
  final Color color;
  final Color iconColor;
  final IconData icon;
  final String title, subtitle;
  final List<Widget> children;
  const OnboardingSectionCardWidget({
    super.key,
    required this.color,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.children,
    this.iconColor = AppColors.green,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const .all(12),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(12)),
      child: Column(
        crossAxisAlignment: .start,
        children: [
          Container(
            padding: const .all(12),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.55),
              borderRadius: .circular(12),
            ),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 15,
                  backgroundColor: iconColor,
                  child: Icon(icon, size: 16, color: Colors.white),
                ),
                const Gap(12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: AppTheme.hind(15, w: FontWeight.w700, c: AppColors.bg),
                      ),
                      Text(subtitle, style: AppTheme.hind(10.5, c: AppColors.bg)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          ...children,
        ],
      ),
    );
  }
}
