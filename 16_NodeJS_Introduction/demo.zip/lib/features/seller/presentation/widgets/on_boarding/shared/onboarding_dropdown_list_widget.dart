import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:society_seva/app/theme/app_theme.dart';

class OnboardingDropdownListWidget<T> extends StatelessWidget {
  final String hint;
  final IconData? icon;
  final T? value;
  final List<T> items;
  final ValueChanged<T?>? onChanged; // null => disabled
  final String Function(T item)? labelBuilder;
  final String? Function(T?)? validator;

  const OnboardingDropdownListWidget({
    super.key,
    required this.hint,
    required this.items,
    required this.onChanged,
    this.value,
    this.icon,
    this.labelBuilder,
    this.validator,
  });

  InputDecoration _inputDecoration() => InputDecoration(
    hintText: hint,
    hintStyle: AppTheme.hind(12, c: const Color(0xFF9E9E9E)),
    prefixIcon: icon == null ? null : Icon(icon, size: 18, color: AppColors.muted),
    counterText: '',
    isDense: true,
    filled: true,
    fillColor: onChanged == null ? const Color(0xFFF5F5F5) : Colors.white,
    contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 13),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: BorderSide(color: AppColors.border),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: BorderSide(color: AppColors.border),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: const BorderSide(color: AppColors.border),
    ),
    disabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: BorderSide(color: AppColors.border),
    ),
  );

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<T>(
      initialValue: items.contains(value) ? value : null,
      isExpanded: true,
      icon: const Icon(Icons.keyboard_arrow_down, size: 20),
      style: GoogleFonts.hind(fontSize: 13, color: Colors.black87),
      decoration: _inputDecoration(),
      validator: validator,
      items: items
          .map(
            (t) => DropdownMenuItem<T>(
              value: t,
              child: Text(
                labelBuilder?.call(t) ?? t.toString(),
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.hind(fontSize: 13),
              ),
            ),
          )
          .toList(),
      onChanged: onChanged,
    );
  }
}
