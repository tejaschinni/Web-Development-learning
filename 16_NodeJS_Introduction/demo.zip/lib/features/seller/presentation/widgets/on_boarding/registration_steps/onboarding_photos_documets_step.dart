import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/domain/entities/certificate_entity.dart';
import 'package:society_seva/features/seller/domain/entities/kyc_document_entity.dart';
import 'package:society_seva/features/seller/domain/enum/certificate_type.dart';
import 'package:society_seva/features/seller/domain/enum/document_type.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/image_grid_widget.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/image_source_sheet.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/lable_widget.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/onboarding_dropdown_list_widget.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/onboarding_section_card_widget.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/onboarding_text_field_widget.dart';

class OnboardingPhotosDocumetsStep extends StatelessWidget {
  const OnboardingPhotosDocumetsStep({super.key, required this.sellerId});
  final String sellerId;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _PhotosSection(sellerId: sellerId),
        const Gap(12),
        _DocumentsSection(sellerId: sellerId),
        const Gap(12),
        _CertificatesSection(sellerId: sellerId),
      ],
    );
  }
}

String _sentence(String value) {
  final s = value.toLowerCase().replaceAll('_', ' ');
  return s.isEmpty ? s : '${s[0].toUpperCase()}${s.substring(1)}';
}

Color get _cardColor => AppColors.green.withValues(alpha: 0.15);

void _snack(BuildContext context, String message) {
  if (!context.mounted) return;
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(message)));
}

class _SubHeading extends StatelessWidget {
  const _SubHeading(this.text);
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(top: 16, bottom: 8),
    child: Text(text, style: GoogleFonts.hind(fontSize: 14, fontWeight: FontWeight.w700)),
  );
}

/// Bordered "tap to upload" tile. Turns green with a tick once a file is picked.
class _UploadTile extends StatelessWidget {
  const _UploadTile({required this.emptyLabel, required this.fileName, required this.onTap});
  final String emptyLabel;
  final String? fileName;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final done = fileName != null;
    return InkWell(
      borderRadius: BorderRadius.circular(8),
      onTap: onTap,
      child: Container(
        height: 48,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(
          color: done ? AppColors.green.withValues(alpha: 0.08) : Colors.white,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: done ? AppColors.green : AppColors.border),
        ),
        child: Row(
          children: [
            Icon(
              done ? Icons.check_circle : Icons.upload_file_outlined,
              size: 20,
              color: done ? AppColors.green : AppColors.muted,
            ),
            const Gap(10),
            Expanded(
              child: Text(
                fileName ?? emptyLabel,
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.hind(
                  fontSize: 13,
                  color: done ? AppColors.green : AppColors.muted,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DateField extends StatelessWidget {
  const _DateField({required this.label, required this.value, required this.onTap});
  final String label;
  final DateTime? value;
  final VoidCallback onTap;

  static final _format = DateFormat('dd MMM yyyy');

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        LableWidget(label, required: true),
        InkWell(
          borderRadius: BorderRadius.circular(8),
          onTap: onTap,
          child: Container(
            height: 44,
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppColors.border),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    value == null ? 'Select date' : _format.format(value!),
                    style: GoogleFonts.hind(
                      fontSize: 13,
                      color: value == null ? const Color(0xFF9E9E9E) : Colors.black87,
                    ),
                  ),
                ),
                Icon(Icons.calendar_today_outlined, size: 18, color: AppColors.muted),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _ItemTile extends StatelessWidget {
  const _ItemTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.trailing,
    this.iconColor,
  });
  final IconData icon;
  final Color? iconColor;
  final String title, subtitle;
  final Widget trailing;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Icon(icon, color: iconColor ?? AppColors.muted),
          const Gap(10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: GoogleFonts.hind(fontSize: 13, fontWeight: FontWeight.w600)),
                if (subtitle.isNotEmpty)
                  Text(subtitle, style: GoogleFonts.hind(fontSize: 11, color: AppColors.muted)),
              ],
            ),
          ),
          trailing,
        ],
      ),
    );
  }
}

class _PhotosSection extends ConsumerWidget {
  const _PhotosSection({required this.sellerId});
  final String sellerId;

  static final _picker = ImagePicker();

  Future<void> _onAddPhotosPressed(BuildContext context, WidgetRef ref) async {
    final source = await chooseImageSource(context);
    if (source == null) return; // dismissed

    final notifier = ref.read(sellerFormActionProvider.notifier);
    if (source == ImageSource.camera) {
      final file = await _picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 80,
        maxWidth: 1600,
        preferredCameraDevice: CameraDevice.rear,
      );
      if (file == null) return; // user cancelled
      notifier.addPendingImage(file);
    } else {
      final files = await _picker.pickMultiImage(imageQuality: 80, maxWidth: 1600);
      if (files.isEmpty) return; // user cancelled
      for (final file in files) {
        notifier.addPendingImage(file);
      }
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return OnboardingSectionCardWidget(
      color: _cardColor,
      icon: Icons.photo_library_outlined,
      title: 'Photos',
      subtitle: 'Show buyers your shop, work or products.',
      children: [
        Consumer(
          builder: (context, ref, _) {
            final isBusy = ref.watch(sellerFormActionProvider.select((s) => s.isBusy));
            final isUploading = ref.watch(
              sellerFormActionProvider.select((s) => s.isUploadingImages),
            );
            return SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: isBusy ? null : () => _onAddPhotosPressed(context, ref),
                icon: isUploading
                    ? const SizedBox(
                        height: 16,
                        width: 16,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.add_photo_alternate_outlined),
                label: Text('Add photos', style: GoogleFonts.hind()),
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.green,
                  side: BorderSide(color: AppColors.green),
                  minimumSize: const Size.fromHeight(44),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
              ),
            );
          },
        ),
        if (sellerId == '')
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              'Save as draft to enable photo upload',
              style: GoogleFonts.hind(fontSize: 11, color: AppColors.muted),
            ),
          ),
        const Gap(12),
        ImageGridWidget(sellerId: sellerId),
      ],
    );
  }
}

class _DocumentsSection extends ConsumerStatefulWidget {
  const _DocumentsSection({required this.sellerId});
  final String sellerId;

  @override
  ConsumerState<_DocumentsSection> createState() => _DocumentsSectionState();
}

class _DocumentsSectionState extends ConsumerState<_DocumentsSection> {
  final _formKey = GlobalKey<FormState>();
  final _docNumber = TextEditingController();
  DocumentType _docType = DocumentType.values.first;
  XFile? _docFile;

  @override
  void dispose() {
    _docNumber.dispose();
    super.dispose();
  }

  String? _validateDocNumber(String? v) {
    final value = (v ?? '').trim().toUpperCase();
    if (value.isEmpty) return 'Required';
    switch (_docType.type) {
      case 'AADHAAR':
        return RegExp(r'^\d{12}$').hasMatch(value) ? null : 'Enter a 12-digit Aadhaar number';
      case 'PAN':
        return RegExp(r'^[A-Z]{5}[0-9]{4}[A-Z]$').hasMatch(value)
            ? null
            : 'Enter a valid PAN (e.g. ABCDE1234F)';
      case 'GST_CERTIFICATE':
        return value.length == 15 ? null : 'GSTIN must be 15 characters';
      default:
        return null;
    }
  }

  Future<void> _pickDocumentFile() async {
    final source = await chooseImageSource(context);
    if (source == null) return;
    final picker = ImagePicker();
    final file = await picker.pickImage(source: source, imageQuality: 85, maxWidth: 2000);
    if (file == null) return;
    setState(() => _docFile = file);
  }

  void _addDocument() {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    if (_docFile == null) {
      _snack(context, 'Please upload the document');
      return;
    }

    ref
        .read(sellerFormActionProvider.notifier)
        .addPendingDocument(
          PendingDocument(
            type: _docType.type,
            number: _docNumber.text.trim().toUpperCase(),
            file: _docFile!,
          ),
        );

    setState(() {
      _docNumber.clear();
      _docFile = null;
    });
  }

  Future<void> _downloadDocument(KycDocumentEntity doc) async {
    try {
      final base64File = await ref
          .read(downloadKycDocumentFileUsecase)
          .call(sellerId: widget.sellerId, documentFileUrl: doc.documentFileUrl);
      if (!mounted) return;
      _snack(
        context,
        'Downloaded ${_sentence(doc.documentType)} (${base64File.length} chars, base64)',
      );
    } catch (e) {
      if (!mounted) return;
      _snack(context, 'Could not download document: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final pendingDocuments = ref.watch(sellerFormActionProvider.select((s) => s.pendingDocuments));
    final AsyncValue<List<KycDocumentEntity>>? uploaded = widget.sellerId == ''
        ? null
        : ref.watch(sellerDocumentProvider(widget.sellerId));

    return OnboardingSectionCardWidget(
      color: _cardColor,
      icon: Icons.badge_outlined,
      title: 'Documents',
      subtitle: 'Upload your identity and business documents.',
      children: [
        Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const LableWidget('Document type', required: true),
              OnboardingDropdownListWidget<DocumentType>(
                hint: 'Select document type',
                icon: Icons.description_outlined,
                value: _docType,
                items: DocumentType.values,
                labelBuilder: (d) => d.label, // "Aadhaar card"
                onChanged: (v) => setState(() {
                  _docType = v ?? _docType;
                  _docNumber.clear();
                }),
              ),
              const Gap(12),
              LableWidget('${_sentence(_docType.label)} number', required: true),
              OnboardingTextFieldWidget(
                hint: 'Enter ${_sentence(_docType.label).toLowerCase()} number',
                icon: Icons.numbers,
                // controller: _docNumber,
                // textCapitalization: TextCapitalization.characters,
                keyboard: _docType.type == 'AADHAAR' ? TextInputType.number : null,
                // validator: _validateDocNumber,
                onChanged: (_) {},
              ),
            ],
          ),
        ),
        const Gap(12),
        const LableWidget('Document file', required: true),
        _UploadTile(
          emptyLabel: 'Upload document',
          fileName: _docFile?.name,
          onTap: _pickDocumentFile,
        ),
        const Gap(12),
        Align(
          alignment: Alignment.centerRight,
          child: FilledButton.tonal(
            onPressed: _addDocument,
            child: Text('Add document', style: GoogleFonts.hind()),
          ),
        ),
        if (pendingDocuments.isNotEmpty) ...[
          const _SubHeading('Added documents'),
          for (final doc in pendingDocuments)
            _ItemTile(
              icon: Icons.description_outlined,
              title: _sentence(doc.type),
              subtitle: doc.number,
              trailing: IconButton(
                icon: const Icon(Icons.delete_outline),
                onPressed: () =>
                    ref.read(sellerFormActionProvider.notifier).removePendingDocument(doc),
              ),
            ),
        ],
        if (uploaded != null)
          uploaded.when(
            loading: () => const Padding(
              padding: EdgeInsets.symmetric(vertical: 16),
              child: Center(child: CircularProgressIndicator()),
            ),
            error: (e, st) {
              debugPrint('documents error: $e\n$st');
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Text('Could not load documents: $e'),
              );
            },
            data: (list) {
              if (list.isEmpty) return const SizedBox.shrink();
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const _SubHeading('Uploaded documents'),
                  for (final doc in list)
                    _ItemTile(
                      icon: Icons.verified,
                      iconColor: Colors.green,
                      title: _sentence(doc.documentType),
                      subtitle: doc.verificationStatus,
                      trailing: IconButton(
                        icon: const Icon(Icons.download_outlined),
                        tooltip: 'Download',
                        onPressed: () => _downloadDocument(doc),
                      ),
                    ),
                ],
              );
            },
          ),
      ],
    );
  }
}

// ───────────────────────── Certificates ─────────────────────────

class _CertificatesSection extends ConsumerStatefulWidget {
  const _CertificatesSection({required this.sellerId});
  final String sellerId;

  @override
  ConsumerState<_CertificatesSection> createState() => _CertificatesSectionState();
}

class _CertificatesSectionState extends ConsumerState<_CertificatesSection> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _certificateNumber = TextEditingController();
  final _issuingAuthority = TextEditingController();
  XFile? _file;
  DateTime? _issueDate;
  bool _hasExpiry = false;
  DateTime? _expiryDate;
  CertificateType selected = CertificateType.values.first;

  static final _dateFormat = DateFormat('dd MMM yyyy');

  @override
  void dispose() {
    _name.dispose();
    _certificateNumber.dispose();
    _issuingAuthority.dispose();
    super.dispose();
  }

  Future<void> _pickCertificateFile() async {
    final source = await chooseImageSource(context);
    if (source == null) return;
    final picker = ImagePicker();
    final file = await picker.pickImage(source: source, imageQuality: 85, maxWidth: 2000);
    if (file == null) return;
    setState(() => _file = XFile(file.path, name: file.name));
  }

  Future<void> _pickDate({required bool isExpiry}) async {
    final now = DateTime.now();
    final initial = isExpiry ? (_expiryDate ?? _issueDate ?? now) : (_issueDate ?? now);
    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(2000),
      lastDate: DateTime(now.year + 20),
    );
    if (picked == null) return;
    setState(() {
      if (isExpiry) {
        _expiryDate = picked;
      } else {
        _issueDate = picked;
      }
    });
  }

  void _addCertificate() {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    if (_file == null) {
      _snack(context, 'Please upload the certificate (image or PDF)');
      return;
    }
    final issueDate = _issueDate;
    if (issueDate == null) {
      _snack(context, 'Please select the certification date');
      return;
    }
    final expiryDate = _expiryDate;
    if (_hasExpiry) {
      if (expiryDate == null) {
        _snack(context, 'Please select the expiry date');
        return;
      }
      if (!expiryDate.isAfter(issueDate)) {
        _snack(context, 'Expiry date must be after the certification date');
        return;
      }
    }

    ref
        .read(sellerFormActionProvider.notifier)
        .addPendingCertificate(
          PendingCertificate(
            name: _name.text.trim(),
            file: _file!,
            certificateNumber: _certificateNumber.text.trim(),
            issuingAuthority: _issuingAuthority.text.trim(),
            type: selected.value,
            issueDate: issueDate,
            hasExpiry: _hasExpiry,
            expiryDate: _hasExpiry ? expiryDate : null,
          ),
        );

    setState(() {
      _name.clear();
      _certificateNumber.clear();
      _file = null;
      _issueDate = null;
      _hasExpiry = false;
      _expiryDate = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final pendingCertificates = ref.watch(
      sellerFormActionProvider.select((s) => s.pendingCertificates),
    );
    final AsyncValue<List<CertificateEntity>>? uploaded = widget.sellerId == ''
        ? null
        : ref.watch(sellerCertificatesProvider(widget.sellerId));

    return OnboardingSectionCardWidget(
      color: _cardColor,
      icon: Icons.workspace_premium_outlined,
      title: 'Certificates',
      subtitle: 'Add any certifications you have. This is optional.',
      children: [
        Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const LableWidget('Certificate type', required: true),
              OnboardingDropdownListWidget<CertificateType>(
                hint: 'Select certificate type',
                icon: Icons.workspace_premium_outlined,
                value: selected,
                items: CertificateType.values,
                labelBuilder: (t) => t.label,
                validator: (v) => v == null ? 'Select a certificate type' : null,
                onChanged: (v) => setState(() => selected = v ?? selected),
              ),
              const Gap(12),
              const LableWidget('Certificate name', required: true),
              OnboardingTextFieldWidget(
                hint: 'Certificate name',
                icon: Icons.badge_outlined,

                onChanged: (_) {},
              ),
              const Gap(12),
              const LableWidget('Certificate number'),
              OnboardingTextFieldWidget(
                hint: 'Certificate number',
                icon: Icons.numbers,

                onChanged: (_) {},
              ),
              const Gap(12),
              const LableWidget('Issuing authority'),
              OnboardingTextFieldWidget(
                hint: 'Issuing authority',
                icon: Icons.account_balance_outlined,

                onChanged: (_) {},
              ),
              const Gap(12),
              _DateField(
                label: 'Certification date',
                value: _issueDate,
                onTap: () => _pickDate(isExpiry: false),
              ),
              const Gap(4),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                activeThumbColor: AppColors.green,
                title: Text(
                  'This certificate has an expiry date',
                  style: GoogleFonts.hind(fontSize: 13),
                ),
                value: _hasExpiry,
                onChanged: (v) => setState(() {
                  _hasExpiry = v;
                  if (!v) _expiryDate = null;
                }),
              ),
              if (_hasExpiry) ...[
                const Gap(4),
                _DateField(
                  label: 'Expiry date',
                  value: _expiryDate,
                  onTap: () => _pickDate(isExpiry: true),
                ),
              ],
            ],
          ),
        ),
        const Gap(12),
        const LableWidget('Certificate file', required: true),
        _UploadTile(
          emptyLabel: 'Upload certificate (image or PDF)',
          fileName: _file?.name,
          onTap: _pickCertificateFile,
        ),
        const Gap(12),
        Align(
          alignment: Alignment.centerRight,
          child: FilledButton.tonal(
            onPressed: _addCertificate,
            child: Text('Add certificate', style: GoogleFonts.hind()),
          ),
        ),
        if (pendingCertificates.isNotEmpty) ...[
          const _SubHeading('Added certificates'),
          for (final cert in pendingCertificates)
            _ItemTile(
              icon: Icons.verified_outlined,
              title: cert.name,
              subtitle: cert.hasExpiry && cert.expiryDate != null
                  ? 'Issued ${_dateFormat.format(cert.issueDate)} · Expires ${_dateFormat.format(cert.expiryDate!)}'
                  : 'Issued ${_dateFormat.format(cert.issueDate)} · No expiry',
              trailing: IconButton(
                icon: const Icon(Icons.delete_outline),
                onPressed: () =>
                    ref.read(sellerFormActionProvider.notifier).removePendingCertificate(cert),
              ),
            ),
        ],
        if (uploaded != null)
          uploaded.when(
            loading: () => const Padding(
              padding: EdgeInsets.symmetric(vertical: 16),
              child: Center(child: CircularProgressIndicator()),
            ),
            error: (e, st) {
              debugPrint('certificates error: $e\n$st');
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Text('Could not load certificates: $e'),
              );
            },
            data: (list) {
              if (list.isEmpty) return const SizedBox.shrink();
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const _SubHeading('Uploaded certificates'),
                  for (final cert in list)
                    _ItemTile(
                      icon: Icons.verified,
                      iconColor: Colors.green,
                      title: cert.certificateName,
                      subtitle: '',
                      trailing: const SizedBox.shrink(),
                    ),
                ],
              );
            },
          ),
      ],
    );
  }
}
