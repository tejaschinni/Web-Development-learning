import 'dart:async';

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/core/mock/mock_data.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/lable_widget.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/onboarding_radius_slider_widget.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/onboarding_text_field_widget.dart';

class AddressSuggestion {
  final String title;
  final String address;
  final String city;
  final String state;
  final String country;
  final String pinCode;
  final LatLng? point;

  const AddressSuggestion({
    required this.title,
    required this.address,
    required this.city,
    required this.state,
    this.country = 'India',
    required this.pinCode,
    this.point,
  });
}

class OnboardingAddressStep extends StatefulWidget {
  const OnboardingAddressStep({
    super.key,
    required this.selected,
    required this.devicePoint,
    required this.hasLocationPermission,
    required this.locating,
    required this.permissionReady,
    required this.serviceDisabled,
    required this.permission,
    required this.geocoding,
    required this.locationError,
    required this.onMapCreated,
    required this.onMapTap,
    required this.onRequestLocation,
    required this.isActive,
    required this.addressController,
    required this.cityController,
    required this.stateController,
    required this.countryController,
    required this.pinCodeController,
    required this.deliveryRadius,
    required this.onRadiusChanged,
    required this.onAddressChanged,
    required this.onCityChanged,
    required this.onStateChanged,
    required this.onCountryChanged,
    required this.onPinCodeChanged,
    this.onSearchAddress,
    this.customSuggestions,
  });

  final bool isActive;
  final LatLng? selected;
  final LatLng? devicePoint;
  final bool hasLocationPermission;
  final bool locating;
  final bool permissionReady;
  final bool serviceDisabled;
  final LocationPermission permission;
  final bool geocoding;
  final String? locationError;
  final void Function(GoogleMapController controller) onMapCreated;
  final void Function(LatLng point) onMapTap;
  final VoidCallback onRequestLocation;

  final TextEditingController addressController;
  final TextEditingController cityController;
  final TextEditingController stateController;
  final TextEditingController countryController;
  final TextEditingController pinCodeController;
  final int? deliveryRadius;
  final ValueChanged<int?> onRadiusChanged;
  final ValueChanged<String> onAddressChanged;
  final ValueChanged<String> onCityChanged;
  final ValueChanged<String> onStateChanged;
  final ValueChanged<String> onCountryChanged;
  final ValueChanged<String> onPinCodeChanged;
  final VoidCallback? onSearchAddress;
  final List<AddressSuggestion>? customSuggestions;

  @override
  State<OnboardingAddressStep> createState() => _OnboardingAddressStepState();
}

class _OnboardingAddressStepState extends State<OnboardingAddressStep> {
  static const _fallbackPoint = LatLng(20.5937, 78.9629);

  static final Dio _searchDio = Dio(
    BaseOptions(
      connectTimeout: const Duration(seconds: 4),
      receiveTimeout: const Duration(seconds: 4),
      headers: {
        'User-Agent': 'SocietySevaApp/1.0',
        'Accept': 'application/json',
      },
    ),
  );

  bool _showSuggestions = false;
  bool _isLoadingSuggestions = false;
  List<AddressSuggestion> _dynamicSuggestions = [];
  Timer? _debounceTimer;

  @override
  void initState() {
    super.initState();
    widget.addressController.addListener(_onAddressControllerChanged);
  }

  @override
  void didUpdateWidget(covariant OnboardingAddressStep oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.addressController != widget.addressController) {
      oldWidget.addressController.removeListener(_onAddressControllerChanged);
      widget.addressController.addListener(_onAddressControllerChanged);
    }
  }

  @override
  void dispose() {
    _debounceTimer?.cancel();
    widget.addressController.removeListener(_onAddressControllerChanged);
    super.dispose();
  }

  void _onAddressControllerChanged() {
    if (mounted) setState(() {});
  }

  Future<List<AddressSuggestion>> _fetchDynamicSuggestions(String query) async {
    final trimmed = query.trim();
    if (trimmed.length < 2) return [];

    final results = <AddressSuggestion>[];

    // 1. First search dynamic geocoding via OpenStreetMap Nominatim
    try {
      final response = await _searchDio.get<dynamic>(
        'https://nominatim.openstreetmap.org/search',
        queryParameters: {
          'q': trimmed,
          'format': 'json',
          'addressdetails': '1',
          'limit': '6',
          'countrycodes': 'in',
        },
      );

      final data = response.data;
      if (data is List) {
        for (final item in data) {
          if (item is! Map) continue;
          final addr = item['address'] is Map ? item['address'] as Map : {};
          final displayName = (item['display_name'] ?? '').toString();
          final parts = displayName.split(',');
          final shortTitle = item['name']?.toString().isNotEmpty == true
              ? item['name'].toString()
              : (parts.isNotEmpty ? parts.first.trim() : trimmed);

          final road = addr['road']?.toString() ?? '';
          final suburb = (addr['suburb'] ?? addr['neighbourhood'] ?? addr['residential'])?.toString() ?? '';
          final city = (addr['city'] ?? addr['town'] ?? addr['village'] ?? addr['county'])?.toString() ?? '';
          final state = addr['state']?.toString() ?? '';
          final country = addr['country']?.toString() ?? 'India';
          final postcode = addr['postcode']?.toString() ?? '';

          final addressLines = [
            if (shortTitle.isNotEmpty) shortTitle,
            if (road.isNotEmpty && road != shortTitle) road,
            if (suburb.isNotEmpty && suburb != shortTitle && suburb != road) suburb,
          ].join(', ');

          final fullAddress = addressLines.isNotEmpty ? addressLines : displayName;
          final lat = double.tryParse(item['lat']?.toString() ?? '');
          final lon = double.tryParse(item['lon']?.toString() ?? '');

          results.add(
            AddressSuggestion(
              title: shortTitle,
              address: fullAddress,
              city: city,
              state: state,
              country: country,
              pinCode: postcode,
              point: (lat != null && lon != null) ? LatLng(lat, lon) : null,
            ),
          );
        }
      }
    } catch (_) {
      // Ignore network errors and continue to local fallback
    }

    // 2. Fallback to device geocoding package if online nominatim is empty
    if (results.isEmpty) {
      try {
        final locations = await Geocoding().locationFromAddress(trimmed);
        for (final loc in locations.take(3)) {
          try {
            final placemarks = await Geocoding().placemarkFromCoordinates(loc.latitude, loc.longitude);
            if (placemarks.isNotEmpty) {
              final p = placemarks.first;
              final title = [p.name, p.subLocality]
                  .whereType<String>()
                  .where((s) => s.isNotEmpty)
                  .join(', ');
              final addr = [p.street, p.subLocality, p.locality]
                  .whereType<String>()
                  .where((s) => s.isNotEmpty)
                  .join(', ');
              results.add(
                AddressSuggestion(
                  title: title.isNotEmpty ? title : trimmed,
                  address: addr.isNotEmpty ? addr : trimmed,
                  city: p.locality ?? p.subAdministrativeArea ?? '',
                  state: p.administrativeArea ?? '',
                  country: p.country ?? 'India',
                  pinCode: p.postalCode ?? '',
                  point: LatLng(loc.latitude, loc.longitude),
                ),
              );
            }
          } catch (_) {}
        }
      } catch (_) {}
    }

    // 3. Include any matching societies dynamically from MockData / Societies
    for (final s in MockData.societies) {
      if (s.name.toLowerCase().contains(trimmed.toLowerCase()) ||
          s.address.toLowerCase().contains(trimmed.toLowerCase()) ||
          s.city.toLowerCase().contains(trimmed.toLowerCase())) {
        results.insert(
          0,
          AddressSuggestion(
            title: s.name,
            address: s.address,
            city: s.city,
            state: s.state,
            country: s.country.isNotEmpty ? s.country : 'India',
            pinCode: s.pinCode,
            point: const LatLng(19.1176, 72.9060),
          ),
        );
      }
    }

    // 4. Deduplicate results
    final seen = <String>{};
    final unique = <AddressSuggestion>[];
    for (final r in results) {
      final key = '${r.title.toLowerCase()}_${r.address.toLowerCase()}';
      if (!seen.contains(key)) {
        seen.add(key);
        unique.add(r);
      }
    }
    return unique;
  }

  void _onAddressInputChanged(String val) {
    // Keep user-entered address
    widget.onAddressChanged(val);

    final query = val.trim();
    if (query.length < 2) {
      _debounceTimer?.cancel();
      setState(() {
        _dynamicSuggestions = [];
        _isLoadingSuggestions = false;
        _showSuggestions = false;
      });
      return;
    }

    setState(() {
      _showSuggestions = true;
      _isLoadingSuggestions = true;
    });

    _debounceTimer?.cancel();
    _debounceTimer = Timer(const Duration(milliseconds: 350), () async {
      final suggestions = await _fetchDynamicSuggestions(query);
      if (!mounted) return;
      setState(() {
        _dynamicSuggestions = suggestions;
        _isLoadingSuggestions = false;
      });
    });
  }

  void _toggleSuggestions() async {
    final willShow = !_showSuggestions;
    setState(() {
      _showSuggestions = willShow;
    });

    if (willShow && _dynamicSuggestions.isEmpty) {
      final query = widget.addressController.text.trim();
      final effectiveQuery = query.isNotEmpty
          ? query
          : (widget.cityController.text.trim().isNotEmpty ? widget.cityController.text.trim() : 'Mumbai');
      setState(() {
        _isLoadingSuggestions = true;
      });
      final suggestions = await _fetchDynamicSuggestions(effectiveQuery);
      if (mounted) {
        setState(() {
          _dynamicSuggestions = suggestions;
          _isLoadingSuggestions = false;
        });
      }
    }
  }

  void _selectSuggestion(AddressSuggestion item) {
    _debounceTimer?.cancel();
    widget.addressController.text = item.address;
    widget.onAddressChanged(item.address);

    if (item.city.isNotEmpty) {
      widget.cityController.text = item.city;
      widget.onCityChanged(item.city);
    }
    if (item.state.isNotEmpty) {
      widget.stateController.text = item.state;
      widget.onStateChanged(item.state);
    }
    if (item.country.isNotEmpty) {
      widget.countryController.text = item.country;
      widget.onCountryChanged(item.country);
    }
    if (item.pinCode.isNotEmpty) {
      widget.pinCodeController.text = item.pinCode;
      widget.onPinCodeChanged(item.pinCode);
    }

    if (item.point != null) {
      widget.onMapTap(item.point!);
    } else {
      widget.onSearchAddress?.call();
    }

    setState(() {
      _showSuggestions = false;
      _isLoadingSuggestions = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final point = widget.selected;
    final target = point ?? widget.devicePoint ?? _fallbackPoint;
    final zoom = (point != null || widget.devicePoint != null) ? 16.0 : 5.0;
    final currentAddressText = widget.addressController.text.trim();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Gap(8),

        if (widget.isActive)
          SizedBox(
            height: 300,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Stack(
                children: [
                  GoogleMap(
                    initialCameraPosition: CameraPosition(target: target, zoom: zoom),
                    gestureRecognizers: <Factory<OneSequenceGestureRecognizer>>{
                      Factory<OneSequenceGestureRecognizer>(() => EagerGestureRecognizer()),
                    },
                    myLocationEnabled: widget.hasLocationPermission,
                    myLocationButtonEnabled: false,
                    zoomControlsEnabled: false,
                    mapToolbarEnabled: false,
                    markers: point == null
                        ? const {}
                        : {Marker(markerId: const MarkerId('seller-location'), position: point)},
                    onMapCreated: widget.onMapCreated,
                    onTap: widget.onMapTap,
                  ),
                  Positioned(
                    right: 12,
                    top: 12,
                    child: Material(
                      color: Theme.of(context).colorScheme.surface,
                      shape: const CircleBorder(),
                      child: IconButton(
                        tooltip: 'Use my current location',
                        onPressed: widget.locating ? null : widget.onRequestLocation,
                        icon: widget.locating
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              )
                            : const Icon(Icons.my_location),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        const Gap(8),
        Text(
          widget.locationError ??
              (widget.permissionReady && !widget.hasLocationPermission
                  ? 'Location permission is off. You can still tap the map or type an address to choose your location.'
                  : point == null
                  ? 'Tap the map, click the location icon, or type your address below to set your location.'
                  : 'Location selected: (${point.latitude.toStringAsFixed(4)}, ${point.longitude.toStringAsFixed(4)}). Address details are auto-filled.'),
          style: GoogleFonts.hind(
            fontSize: 12,
            color: widget.locationError != null ? Colors.red : AppColors.muted,
          ),
        ),
        if (widget.serviceDisabled || (widget.permissionReady && !widget.hasLocationPermission))
          Align(
            alignment: Alignment.centerLeft,
            child: TextButton.icon(
              onPressed: widget.serviceDisabled
                  ? Geolocator.openLocationSettings
                  : widget.permission == LocationPermission.deniedForever
                  ? Geolocator.openAppSettings
                  : widget.onRequestLocation,
              icon: const Icon(Icons.location_searching),
              label: Text(
                widget.serviceDisabled
                    ? 'Open device location settings'
                    : widget.permission == LocationPermission.deniedForever
                    ? 'Open app settings'
                    : 'Allow location access',
              ),
            ),
          ),
        if (widget.geocoding) ...[
          const Gap(6),
          const LinearProgressIndicator(),
          const Gap(4),
          Text(
            'Searching address / coordinates...',
            style: GoogleFonts.hind(fontSize: 11, color: AppColors.muted),
          ),
        ],
        const Gap(16),

        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const LableWidget('Address', required: false),
            InkWell(
              onTap: _toggleSuggestions,
              borderRadius: BorderRadius.circular(4),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      _showSuggestions ? Icons.arrow_drop_up : Icons.arrow_drop_down,
                      size: 18,
                      color: AppColors.green,
                    ),
                    const Gap(2),
                    Text(
                      _showSuggestions ? 'Hide Suggestions' : 'Address Suggestions',
                      style: GoogleFonts.hind(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: AppColors.green,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),

        OnboardingTextFieldWidget(
          controller: widget.addressController,
          hint: 'Search or enter address (e.g. MG Road, Pune)',
          icon: Icons.home_work_outlined,
          maxLineLength: 2,
          suffixIcon: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (widget.addressController.text.isNotEmpty)
                IconButton(
                  tooltip: 'Clear',
                  icon: const Icon(Icons.clear, size: 18, color: AppColors.muted),
                  onPressed: () {
                    widget.addressController.clear();
                    widget.onAddressChanged('');
                    setState(() {
                      _showSuggestions = false;
                      _dynamicSuggestions = [];
                    });
                  },
                ),
              IconButton(
                tooltip: _showSuggestions ? 'Hide suggestions' : 'Show suggestions',
                icon: Icon(
                  _showSuggestions ? Icons.arrow_drop_up : Icons.arrow_drop_down,
                  size: 22,
                  color: AppColors.green,
                ),
                onPressed: _toggleSuggestions,
              ),
              IconButton(
                tooltip: 'Search location on map',
                icon: const Icon(Icons.search, size: 20, color: AppColors.green),
                onPressed: widget.onSearchAddress,
              ),
            ],
          ),
          onChanged: _onAddressInputChanged,
          onFieldSubmitted: (_) {
            setState(() => _showSuggestions = false);
            widget.onSearchAddress?.call();
          },
        ),

        // ── DYNAMIC SUGGESTIONS DROPDOWN SECTION ─────────────────────────
        if (_showSuggestions) ...[
          const Gap(8),
          Container(
            constraints: const BoxConstraints(maxHeight: 260),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.border),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.06),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    color: AppColors.bg,
                    child: Row(
                      children: [
                        const Icon(Icons.location_searching, size: 16, color: AppColors.green),
                        const Gap(8),
                        Text(
                          'Dynamic Suggestions',
                          style: GoogleFonts.hind(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: AppColors.green,
                          ),
                        ),
                        const Spacer(),
                        if (_isLoadingSuggestions)
                          const SizedBox(
                            width: 14,
                            height: 14,
                            child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.green),
                          )
                        else if (_dynamicSuggestions.isNotEmpty)
                          Text(
                            '${_dynamicSuggestions.length} found',
                            style: GoogleFonts.hind(fontSize: 11, color: AppColors.muted),
                          ),
                        const Gap(8),
                        InkWell(
                          onTap: () => setState(() => _showSuggestions = false),
                          child: const Icon(Icons.close, size: 16, color: AppColors.muted),
                        ),
                      ],
                    ),
                  ),
                  const Divider(height: 1, thickness: 1, color: AppColors.border),

                  Flexible(
                    child: _isLoadingSuggestions
                        ? Padding(
                            padding: const EdgeInsets.all(20),
                            child: Center(
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const SizedBox(
                                    width: 16,
                                    height: 16,
                                    child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.green),
                                  ),
                                  const Gap(10),
                                  Text(
                                    'Searching addresses dynamically...',
                                    style: GoogleFonts.hind(fontSize: 12, color: AppColors.muted),
                                  ),
                                ],
                              ),
                            ),
                          )
                        : _dynamicSuggestions.isNotEmpty
                        ? ListView.separated(
                            shrinkWrap: true,
                            padding: EdgeInsets.zero,
                            itemCount: _dynamicSuggestions.length,
                            separatorBuilder: (_, _) => const Divider(
                              height: 1,
                              thickness: 0.5,
                              color: AppColors.border,
                            ),
                            itemBuilder: (context, index) {
                              final item = _dynamicSuggestions[index];
                              return ListTile(
                                dense: true,
                                contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 12,
                                  vertical: 4,
                                ),
                                leading: CircleAvatar(
                                  radius: 14,
                                  backgroundColor: AppColors.greenSoft,
                                  child: const Icon(
                                    Icons.location_on_outlined,
                                    size: 16,
                                    color: AppColors.green,
                                  ),
                                ),
                                title: Text(
                                  item.title,
                                  style: GoogleFonts.hind(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w600,
                                    color: AppColors.ink,
                                  ),
                                ),
                                subtitle: Text(
                                  [
                                    if (item.address.isNotEmpty) item.address,
                                    if (item.city.isNotEmpty) item.city,
                                    if (item.pinCode.isNotEmpty) item.pinCode,
                                  ].join(', '),
                                  style: GoogleFonts.hind(
                                    fontSize: 11,
                                    color: AppColors.muted,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                trailing: const Icon(
                                  Icons.arrow_forward_ios,
                                  size: 12,
                                  color: AppColors.muted,
                                ),
                                onTap: () => _selectSuggestion(item),
                              );
                            },
                          )
                        : Padding(
                            padding: const EdgeInsets.all(14),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    const Icon(
                                      Icons.info_outline,
                                      size: 16,
                                      color: AppColors.orange,
                                    ),
                                    const Gap(8),
                                    Expanded(
                                      child: Text(
                                        'Address not found in suggestions.',
                                        style: GoogleFonts.hind(
                                          fontSize: 12,
                                          fontWeight: FontWeight.w600,
                                          color: AppColors.ink,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                const Gap(6),
                                Text(
                                  currentAddressText.isNotEmpty
                                      ? 'Keeping entered address: "$currentAddressText"'
                                      : 'You can type your full custom address above.',
                                  style: GoogleFonts.hind(
                                    fontSize: 12,
                                    color: AppColors.muted,
                                  ),
                                ),
                                if (currentAddressText.isNotEmpty) ...[
                                  const Gap(10),
                                  SizedBox(
                                    width: double.infinity,
                                    child: OutlinedButton.icon(
                                      style: OutlinedButton.styleFrom(
                                        foregroundColor: AppColors.green,
                                        side: const BorderSide(color: AppColors.green),
                                        padding: const EdgeInsets.symmetric(vertical: 8),
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(8),
                                        ),
                                      ),
                                      icon: const Icon(Icons.check_circle_outline, size: 16),
                                      label: Text(
                                        'Keep & Use Entered Address',
                                        style: GoogleFonts.hind(
                                          fontSize: 12,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                      onPressed: () {
                                        widget.onAddressChanged(widget.addressController.text);
                                        setState(() => _showSuggestions = false);
                                      },
                                    ),
                                  ),
                                ],
                              ],
                            ),
                          ),
                  ),
                ],
              ),
            ),
          ),
        ],

        const Gap(16),

        const LableWidget('City', required: false),
        OnboardingTextFieldWidget(
          controller: widget.cityController,
          hint: 'City',
          icon: Icons.location_city,
          maxLineLength: 1,
          onChanged: widget.onCityChanged,
          onFieldSubmitted: (_) => widget.onSearchAddress?.call(),
        ),
        const Gap(16),
        const LableWidget('State', required: false),
        OnboardingTextFieldWidget(
          controller: widget.stateController,
          hint: 'State',
          icon: Icons.map,
          maxLineLength: 1,
          onChanged: widget.onStateChanged,
        ),
        const Gap(16),
        const LableWidget('Country', required: false),
        OnboardingTextFieldWidget(
          controller: widget.countryController,
          hint: 'Country',
          icon: Icons.public,
          maxLineLength: 1,
          onChanged: widget.onCountryChanged,
        ),
        const Gap(16),
        const LableWidget('PinCode', required: false),
        OnboardingTextFieldWidget(
          controller: widget.pinCodeController,
          hint: 'PinCode',
          icon: Icons.pin_drop_outlined,
          keyboard: TextInputType.number,
          maxLineLength: 1,
          onChanged: widget.onPinCodeChanged,
          onFieldSubmitted: (_) => widget.onSearchAddress?.call(),
        ),
        const Gap(16),
        const LableWidget('Service / Delivery Radius', required: false),
        OnboardingRadiusSliderWidget(value: widget.deliveryRadius, onChanged: widget.onRadiusChanged),
      ],
    );
  }
}
