import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:society_seva/app/theme/app_theme.dart';

enum _RadiusUnit { m, km }

class OnboardingRadiusSliderWidget extends StatefulWidget {
  final int? value; // meters
  final ValueChanged<int?> onChanged; // meters
  final List<int> steps; // meters, ascending
  final int minRadius; // meters
  final int maxRadius; // meters

  const OnboardingRadiusSliderWidget({
    super.key,
    required this.value,
    required this.onChanged,
    this.steps = const [50, 100, 250, 500, 1000, 2000, 5000, 10000, 15000, 25000, 50000],
    this.minRadius = 50,
    this.maxRadius = 200000,
  });

  static String format(int meters) {
    if (meters < 1000) return '$meters m';
    final km = meters / 1000;
    return km == km.roundToDouble() ? '${km.round()} km' : '${km.toStringAsFixed(1)} km';
  }

  @override
  State<OnboardingRadiusSliderWidget> createState() => _OnboardingRadiusSliderWidgetState();
}

class _OnboardingRadiusSliderWidgetState extends State<OnboardingRadiusSliderWidget> {
  late bool _custom;
  late _RadiusUnit _unit;
  late final TextEditingController _ctrl;

  int _factor(_RadiusUnit u) => u == _RadiusUnit.km ? 1000 : 1;

  _RadiusUnit _unitFor(int? meters) =>
      meters != null && meters >= 1000 && meters % 1000 == 0 ? _RadiusUnit.km : _RadiusUnit.m;

  String _textFor(int? meters, _RadiusUnit u) => meters == null ? '' : '${meters ~/ _factor(u)}';

  @override
  void initState() {
    super.initState();
    _custom = widget.value != null && !widget.steps.contains(widget.value);
    _unit = _unitFor(widget.value);
    _ctrl = TextEditingController(text: _custom ? _textFor(widget.value, _unit) : '');
  }

  @override
  void didUpdateWidget(covariant OnboardingRadiusSliderWidget old) {
    super.didUpdateWidget(old);
    if (widget.value != old.value && widget.value != null) {
      final isStep = widget.steps.contains(widget.value);
      if (!isStep && !_custom) {
        _custom = true;
        _unit = _unitFor(widget.value);
      }
      if (_custom) {
        final typed = int.tryParse(_ctrl.text);
        if (typed == null || typed * _factor(_unit) != widget.value) {
          _ctrl.text = _textFor(widget.value, _unit);
        }
      }
    }
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  int get _sliderIndex {
    final v = widget.value;
    if (v == null) return 0;
    var best = 0;
    for (var k = 1; k < widget.steps.length; k++) {
      if ((widget.steps[k] - v).abs() < (widget.steps[best] - v).abs()) best = k;
    }
    return best;
  }

  int? get _typedMeters {
    final n = int.tryParse(_ctrl.text);
    return n == null ? null : n * _factor(_unit);
  }

  String? get _error {
    if (!_custom || _ctrl.text.isEmpty) return null;
    final m = _typedMeters;
    if (m == null || m < widget.minRadius || m > widget.maxRadius) {
      return 'Enter ${OnboardingRadiusSliderWidget.format(widget.minRadius)}'
          ' – ${OnboardingRadiusSliderWidget.format(widget.maxRadius)}';
    }
    return null;
  }

  void _toggleCustom(bool on) {
    setState(() => _custom = on);
    if (on) {
      _unit = _unitFor(widget.value);
      _ctrl.text = _textFor(widget.value, _unit);
      _onTyped(_ctrl.text);
    } else {
      widget.onChanged(widget.steps[_sliderIndex]);
    }
  }

  void _changeUnit(_RadiusUnit u) {
    if (u == _unit) return;
    final current = widget.value;
    setState(() {
      _unit = u;
      if (u == _RadiusUnit.km) {
        _ctrl.text = current != null && current % 1000 == 0 ? '${current ~/ 1000}' : '';
      } else {
        _ctrl.text = current?.toString() ?? '';
      }
    });
    _onTyped(_ctrl.text);
  }

  void _onTyped(String text) {
    final n = int.tryParse(text);
    final meters = n == null ? null : n * _factor(_unit);
    final ok = meters != null && meters >= widget.minRadius && meters <= widget.maxRadius;
    setState(() {});
    widget.onChanged(ok ? meters : null);
  }

  String _tick(int m) => m < 1000 ? '${m}m' : '${m ~/ 1000}km';

  Widget _unitChip(String label, _RadiusUnit u) {
    final selected = _unit == u;
    return ChoiceChip(
      label: Text(label, style: GoogleFonts.hind(fontSize: 12)),
      selected: selected,
      showCheckmark: false,
      visualDensity: VisualDensity.compact,
      selectedColor: AppColors.green.withValues(alpha: 0.15),
      side: BorderSide(color: selected ? AppColors.green : AppColors.border),
      onSelected: (_) => _changeUnit(u),
    );
  }

  @override
  Widget build(BuildContext context) {
    final steps = widget.steps;
    final idx = _sliderIndex;
    final v = widget.value;

    return Container(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Service / delivery radius',
                style: GoogleFonts.hind(fontSize: 12, color: AppColors.muted),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                decoration: BoxDecoration(
                  color: AppColors.green.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  v == null ? 'Not set' : OnboardingRadiusSliderWidget.format(v),
                  style: GoogleFonts.hind(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: AppColors.green,
                  ),
                ),
              ),
            ],
          ),

          Opacity(
            opacity: _custom ? 0.4 : 1,
            child: SliderTheme(
              data: SliderTheme.of(context).copyWith(
                activeTrackColor: AppColors.green,
                inactiveTrackColor: AppColors.border,
                thumbColor: AppColors.green,
                overlayColor: AppColors.green.withValues(alpha: 0.12),
                trackHeight: 4,
                activeTickMarkColor: Colors.white,
                inactiveTickMarkColor: AppColors.muted.withValues(alpha: 0.5),
              ),
              child: Slider(
                value: idx.toDouble(),
                min: 0,
                max: (steps.length - 1).toDouble(),
                divisions: steps.length - 1,
                label: OnboardingRadiusSliderWidget.format(steps[idx]),
                onChanged: _custom ? null : (x) => widget.onChanged(steps[x.round()]),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                for (var k = 0; k < steps.length; k++)
                  Text(
                    _tick(steps[k]),
                    style: GoogleFonts.hind(
                      fontSize: 9.5,
                      fontWeight: !_custom && v != null && k == idx
                          ? FontWeight.w700
                          : FontWeight.w400,
                      color: !_custom && v != null && k == idx ? AppColors.green : AppColors.muted,
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 8),

          // Custom toggle
          FilterChip(
            label: Text('Custom radius', style: GoogleFonts.hind(fontSize: 12)),
            selected: _custom,
            selectedColor: AppColors.green.withValues(alpha: 0.15),
            checkmarkColor: AppColors.green,
            side: BorderSide(color: _custom ? AppColors.green : AppColors.border),
            onSelected: _toggleCustom,
          ),

          if (_custom) ...[
            const SizedBox(height: 8),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: TextField(
                    controller: _ctrl,
                    keyboardType: TextInputType.number,
                    inputFormatters: [
                      FilteringTextInputFormatter.digitsOnly,
                      LengthLimitingTextInputFormatter(widget.maxRadius.toString().length),
                    ],
                    style: const TextStyle(fontSize: 13),
                    onChanged: _onTyped,
                    decoration: InputDecoration(
                      hintText: 'Enter radius',
                      hintStyle: AppTheme.hind(12, c: const Color(0xFF9E9E9E)),
                      errorText: _error,
                      isDense: true,
                      filled: true,
                      fillColor: Colors.white,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 13),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: BorderSide(color: AppColors.border),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: BorderSide(color: AppColors.border),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: const BorderSide(color: AppColors.green),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Padding(
                  padding: const EdgeInsets.only(top: 2),
                  child: Row(
                    children: [
                      _unitChip('m', _RadiusUnit.m),
                      const SizedBox(width: 6),
                      _unitChip('km', _RadiusUnit.km),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}
