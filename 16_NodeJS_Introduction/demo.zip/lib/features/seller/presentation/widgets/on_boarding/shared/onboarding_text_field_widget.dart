import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:society_seva/app/theme/app_theme.dart';

class OnboardingTextFieldWidget extends StatefulWidget {
  final String hint;
  final IconData? icon;
  final String initial;
  final TextEditingController? controller;
  final TextInputType? keyboard;
  final int? maxLength;
  final int? maxLineLength;
  final List<TextInputFormatter>? formatters;
  final ValueChanged<String>? onChanged;
  final Widget? suffixIcon;
  final ValueChanged<String>? onFieldSubmitted;
  final VoidCallback? onEditingComplete;

  const OnboardingTextFieldWidget({
    super.key,
    required this.hint,
    this.onChanged,
    this.icon,
    this.initial = '',
    this.controller,
    this.keyboard,
    this.maxLength,
    this.formatters,
    this.maxLineLength,
    this.suffixIcon,
    this.onFieldSubmitted,
    this.onEditingComplete,
  });

  @override
  State<OnboardingTextFieldWidget> createState() => _OnboardingTextFieldWidgetState();
}

class _OnboardingTextFieldWidgetState extends State<OnboardingTextFieldWidget> {
  TextEditingController? _internalController;
  TextEditingController get _effectiveController => widget.controller ?? _internalController!;

  @override
  void initState() {
    super.initState();
    if (widget.controller == null) {
      _internalController = TextEditingController(text: widget.initial);
    }
  }

  @override
  void didUpdateWidget(covariant OnboardingTextFieldWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.controller == null && _internalController != null) {
      if (oldWidget.initial != widget.initial && _internalController!.text != widget.initial) {
        if (_internalController!.text.isEmpty || oldWidget.initial.isEmpty) {
          _internalController!.text = widget.initial;
        }
      }
    }
  }

  @override
  void dispose() {
    _internalController?.dispose();
    super.dispose();
  }

  InputDecoration _inputDecoration({String? hint, IconData? icon, Widget? suffixIcon}) =>
      InputDecoration(
        hintText: hint,
        hintStyle: AppTheme.hind(12, c: const Color(0xFF9E9E9E)),
        prefixIcon: icon == null ? null : Icon(icon, size: 18, color: AppColors.muted),
        suffixIcon: suffixIcon,
        counterText: '',
        isDense: true,
        filled: true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 13),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: AppColors.border),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      // height: 44,
      child: TextFormField(
        controller: _effectiveController,
        keyboardType: widget.keyboard,
        maxLength: widget.maxLength,
        maxLines: widget.maxLineLength,
        inputFormatters: widget.formatters,
        style: const TextStyle(fontSize: 13),
        decoration: _inputDecoration(
          hint: widget.hint,
          icon: widget.icon,
          suffixIcon: widget.suffixIcon,
        ),
        onChanged: widget.onChanged,
        onFieldSubmitted: widget.onFieldSubmitted,
        onEditingComplete: widget.onEditingComplete,
      ),
    );
  }
}

BoxDecoration boxDecoration() => BoxDecoration(
  color: Colors.white,
  borderRadius: BorderRadius.circular(8),
  border: Border.all(color: AppColors.border),
);
