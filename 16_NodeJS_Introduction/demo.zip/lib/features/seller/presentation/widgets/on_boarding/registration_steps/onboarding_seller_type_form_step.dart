import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/domain/enum/seller_type_config.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';

class OnboardingSellerTypeFormStep extends ConsumerWidget {
  final SellerRegState s;
  final void Function(SellerRegState Function(SellerRegState s) f) onUpdate;

  final List<String> sellerTypes;

  final bool Function(String type) onToggle;

  const OnboardingSellerTypeFormStep({
    super.key,
    required this.onUpdate,
    required this.s,
    required this.sellerTypes,
    required this.onToggle,
  });

  static const _foodType = 'FOOD_SELLER';

  bool get isFood => sellerTypes.contains(_foodType);

  bool get isValid => sellerTypes.isNotEmpty;

  void _handleTap(BuildContext context, String type) {
    final ok = onToggle(type);
    if (!ok) {
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(const SnackBar(content: Text('Select at least one category')));
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Select Categories',
          style: GoogleFonts.hind(fontSize: 22, fontWeight: FontWeight.w700),
        ),
        const Gap(6),
        Text(
          'Choose the main categories you want to offer on SEVA. You can select multiple.',
          style: GoogleFonts.hind(fontSize: 13, color: AppColors.muted),
        ),
        const Gap(16),
        for (final cat in sellerCategories) ...[
          _CategoryCard(
            category: cat,
            selected: sellerTypes.contains(cat.sellerType),
            onTap: () => _handleTap(context, cat.sellerType),
          ),
          const Gap(12),
        ],
      ],
    );
  }
}

class _CategoryCard extends StatelessWidget {
  final SellerCategory category;
  final bool selected;
  final VoidCallback onTap;

  const _CategoryCard({required this.category, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: selected ? AppColors.green.withValues(alpha: 0.06) : Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: selected ? AppColors.green : AppColors.border,
            width: selected ? 1.6 : 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                color: AppColors.green.withValues(alpha: 0.10),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(category.icon, size: 30, color: AppColors.green),
            ),
            const Gap(12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    category.title,
                    style: GoogleFonts.hind(fontSize: 16, fontWeight: FontWeight.w700),
                  ),
                  const Gap(2),
                  Text(
                    category.description,
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.hind(fontSize: 12.5, color: AppColors.muted),
                  ),
                ],
              ),
            ),
            const Gap(8),
            Icon(
              selected ? Icons.check_box : Icons.check_box_outline_blank,
              color: selected ? AppColors.green : AppColors.muted,
            ),
          ],
        ),
      ),
    );
  }
}
