import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_listing_provider.dart';
import 'package:society_seva/features/seller/presentation/widgets/listing/listing_form_widgets.dart';

class ListingAdditionalInfoStep extends ConsumerWidget {
  const ListingAdditionalInfoStep({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final type = ref.watch(productListingProvider.select((s) => s.listingType));
    final s = ref.watch(productListingProvider);
    final n = ref.read(productListingProvider.notifier);
    final c = n.controllers;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      children: [
        StepHeader(
          title: 'Additional Information',
          subtitle: type.isFood
              ? 'Seller adds additional information. Fields will change based on category and subcategory.'
              : type.isService
              ? 'Tell buyers how your service works'
              : 'A few more details about your listing',
        ),
        const Gap(6),
        if (type.isFood) ...[
          const _FoodSpecificSection(),
          const Gap(18),
        ] else if (type.isService) ...[
          const _ServiceForm(),
          const Gap(18),
        ] else ...[
          const InfoBanner(
            'No additional details are needed for this listing type. '
            'Tap Next to add photos.',
          ),
          const Gap(18),
        ],

        // Tags Section
        const Text(
          'Tags (Search keywords)',
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: Color(0xFF344054),
          ),
        ),
        const Gap(8),

        if (s.tags.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Wrap(
              spacing: 8,
              runSpacing: 6,
              children: s.tags.map((tag) {
                return Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: const Color(0xFFEFF8FF),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFFB2DDFF)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        tag,
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                          color: Color(0xFF175CD3),
                        ),
                      ),
                      const SizedBox(width: 4),
                      InkWell(
                        onTap: () => n.removeTag(tag),
                        child: const Icon(Icons.close, size: 14, color: Color(0xFF175CD3)),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
          ),

        TextField(
          controller: c.tagInput,
          onSubmitted: (_) => n.addTagsFromInput(),
          style: const TextStyle(fontSize: 13, color: AppColors.ink),
          decoration: InputDecoration(
            hintText: 'Add tag',
            hintStyle: const TextStyle(color: Color(0xFF98A2B3), fontSize: 13),
            suffixIcon: IconButton(
              icon: const Icon(Icons.add, color: Color(0xFF12B76A)),
              onPressed: n.addTagsFromInput,
            ),
            filled: true,
            fillColor: Colors.white,
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: Color(0xFFD0D5DD)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: Color(0xFF12B76A), width: 1.5),
            ),
          ),
        ),

        if (type.isFood) ...[
          const Gap(24),
          const _OptionalFoodDetailsAccordion(),
        ],
      ],
    );
  }
}

/// Food Specific Information Section matching Mockup Screen 7
class _FoodSpecificSection extends ConsumerWidget {
  const _FoodSpecificSection();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(productListingProvider);
    final n = ref.read(productListingProvider.notifier);
    final c = n.controllers;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Food Specific Information',
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: Color(0xFF344054),
          ),
        ),
        const Gap(10),

        _FoodCheckboxTile(
          label: 'Contains Onion',
          value: s.containsOnion,
          onChanged: n.setContainsOnion,
        ),
        _FoodCheckboxTile(
          label: 'Contains Garlic',
          value: s.containsGarlic,
          onChanged: n.setContainsGarlic,
        ),
        _FoodCheckboxTile(
          label: 'Jain Food Available',
          value: s.jainFoodAvailable,
          onChanged: n.setJainFoodAvailable,
        ),
        _FoodCheckboxTile(
          label: 'Gluten Free',
          value: s.glutenFree,
          onChanged: n.setGlutenFree,
        ),
        _FoodCheckboxTile(
          label: 'Other (please specify)',
          value: s.otherDietary,
          onChanged: n.setOtherDietary,
        ),
        const Gap(6),

        TextField(
          controller: c.otherDietary,
          onTap: () {
            if (!s.otherDietary) n.setOtherDietary(true);
          },
          onChanged: (text) {
            if (text.isNotEmpty && !s.otherDietary) {
              n.setOtherDietary(true);
            }
          },
          style: const TextStyle(fontSize: 13, color: AppColors.ink),
          decoration: InputDecoration(
            hintText: 'e.g. No dairy, no nuts, etc.',
            hintStyle: const TextStyle(color: Color(0xFF98A2B3), fontSize: 13),
            filled: true,
            fillColor: Colors.white,
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: Color(0xFFD0D5DD)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: Color(0xFF12B76A), width: 1.5),
            ),
          ),
        ),
      ],
    );
  }
}

class _FoodCheckboxTile extends StatelessWidget {
  const _FoodCheckboxTile({
    required this.label,
    required this.value,
    required this.onChanged,
  });

  final String label;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => onChanged(!value),
      borderRadius: BorderRadius.circular(6),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(
          children: [
            Container(
              width: 20,
              height: 20,
              decoration: BoxDecoration(
                color: value ? const Color(0xFF12B76A) : Colors.white,
                borderRadius: BorderRadius.circular(4),
                border: Border.all(
                  color: value ? const Color(0xFF12B76A) : const Color(0xFFD0D5DD),
                  width: 1.5,
                ),
              ),
              child: value
                  ? const Icon(Icons.check, size: 14, color: Colors.white)
                  : null,
            ),
            const Gap(10),
            Text(
              label,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: Color(0xFF344054),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Optional expandable food details for preparation, compliance, etc.
class _OptionalFoodDetailsAccordion extends ConsumerWidget {
  const _OptionalFoodDetailsAccordion();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(productListingProvider);
    final n = ref.read(productListingProvider.notifier);
    final c = n.controllers;

    return Theme(
      data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
      child: Material(
        color: const Color(0xFFF9FAFB),
        clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: Color(0xFFEAECF0)),
        ),
        child: ExpansionTile(
          tilePadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
          childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
          title: const Text(
            'Preparation & Quality Details (Optional)',
            style: TextStyle(
              fontSize: 13.5,
              fontWeight: FontWeight.w600,
              color: Color(0xFF344054),
            ),
          ),
          subtitle: const Text(
            'Prep time, freshness declaration, spice level & compliance',
            style: TextStyle(fontSize: 11.5, color: Color(0xFF667085)),
          ),
          children: [
            const Gap(8),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: FormTextField(
                    label: 'Preparation time (min)',
                    controller: c.prepTime,
                    required: true,
                    hint: 'e.g. 30',
                    keyboardType: TextInputType.number,
                    inputFormatters: digitsOnly,
                  ),
                ),
              ],
            ),
            FormTextField(
              label: 'Freshness declaration',
              controller: c.freshness,
              hint: 'e.g. Freshly prepared on order',
              required: true,
            ),
            FormTextField(
              label: 'Ingredients',
              controller: c.ingredients,
              required: true,
              maxLines: 2,
              hint: 'Wheat flour, rice, dal, seasonal vegetables, spices, etc.',
            ),
            FormTextField(
              label: 'Allergens (optional)',
              controller: c.allergens,
              hint: 'e.g. nuts, gluten, dairy',
            ),
            DropdownField(
              label: 'Spice level',
              value: s.spiceLevel,
              items: {for (final k in kSpiceLevels.keys) k: k.replaceAll('_', ' ')},
              onChanged: n.setSpiceLevel,
            ),
            SwitchRow(title: 'Frozen item', value: s.frozen, onChanged: n.setFrozen),
            FormTextField(
              label: 'Storage instructions (optional)',
              controller: c.storage,
              hint: 'e.g. Consume within 4 hours',
            ),
            FormTextField(
              label: 'Packaging details (optional)',
              controller: c.packaging,
              hint: 'e.g. Eco-friendly container',
            ),
            _ExpiryPicker(value: s.expiryTime, onChanged: n.setExpiry),
            SwitchRow(
              title: 'FSSAI license required',
              value: s.fssaiRequired,
              onChanged: n.setFssaiRequired,
            ),
            if (s.fssaiRequired)
              FormTextField(label: 'FSSAI certificate ID', controller: c.fssaiId, required: true),
          ],
        ),
      ),
    );
  }
}

class _ExpiryPicker extends StatelessWidget {
  const _ExpiryPicker({required this.value, required this.onChanged});
  final DateTime? value;
  final ValueChanged<DateTime?> onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const FieldLabel('Expiry (optional)'),
          const Gap(6),
          InkWell(
            borderRadius: BorderRadius.circular(8),
            onTap: () async {
              final now = DateTime.now();
              final d = await showDatePicker(
                context: context,
                initialDate: value ?? now,
                firstDate: now,
                lastDate: now.add(const Duration(days: 365)),
              );
              if (d != null) onChanged(d);
            },
            child: InputDecorator(
              decoration: listingInputDecoration().copyWith(
                suffixIcon: value == null
                    ? const Icon(Icons.calendar_today, size: 18)
                    : IconButton(
                        icon: const Icon(Icons.close, size: 18),
                        onPressed: () => onChanged(null),
                      ),
              ),
              child: Text(
                value == null ? 'Not set' : ymd(value!),
                style: TextStyle(fontSize: 14, color: value == null ? AppColors.muted : null),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ServiceForm extends ConsumerWidget {
  const _ServiceForm();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(productListingProvider);
    final n = ref.read(productListingProvider.notifier);
    final c = n.controllers;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        FormTextField(
          label: 'Duration (minutes)',
          controller: c.duration,
          required: true,
          hint: 'e.g. 90',
          keyboardType: TextInputType.number,
          inputFormatters: digitsOnly,
        ),
        DropdownField(
          label: 'Service location',
          value: s.locationType,
          items: kLocationTypes,
          onChanged: n.setLocationType,
          required: true,
        ),
        SwitchRow(title: 'Home visit available', value: s.homeVisit, onChanged: n.setHomeVisit),
        SwitchRow(title: 'Online available', value: s.online, onChanged: n.setOnline),
        SwitchRow(
          title: 'Certificate required',
          value: s.certificateRequired,
          onChanged: n.setCertificateRequired,
        ),
        const Gap(8),
        FormTextField(
          label: 'Required materials (optional)',
          controller: c.requiredMaterials,
          maxLines: 3,
          hint: 'Anything the buyer needs to arrange',
        ),
        FormTextField(
          label: 'Cancellation policy (optional)',
          controller: c.cancellationPolicy,
          maxLines: 3,
          hint: 'e.g. Free cancellation up to 24 hours before',
        ),
      ],
    );
  }
}
