import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/domain/entities/seller_listing_entity.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_listing_provider.dart';
import 'package:society_seva/features/seller/presentation/screens/listing/seller_listing_screen.dart'
    hide ListingType;

enum _MenuAction { edit, toggle, outOfStock, delete }

String _fmt(double v) => v == v.roundToDouble() ? v.toInt().toString() : v.toStringAsFixed(2);

Color _statusBg(String s) => switch (s.toLowerCase()) {
  'approved' => const Color(0xFFDCFCE7),
  'published' => const Color(0xFFDCFCE7),
  'draft' => const Color(0xFFFEF3C7),
  _ => const Color(0xFFFEE2E2),
};

class MyListItemWidget extends ConsumerWidget {
  const MyListItemWidget({
    super.key,
    required this.item,
    required this.onToggle,
    required this.onEdit,
    required this.onOutOfStock,
    required this.onDelete,
  });
  final SellerListingEntity item;
  final ValueChanged<bool> onToggle;
  final VoidCallback onEdit;
  final VoidCallback onOutOfStock;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final status = fromApi(item.availabilityStatus);
    final isActive = status == ListingStatus.active;
    final imageUrl = ref
        .watch(sellerListingImagesProvider(item.id))
        .valueOrNull
        ?.where((image) => image.moderationStatus.toUpperCase() == 'APPROVED')
        .firstOrNull
        ?.imageUrl;

    final info = <String>[if (item.quantityAvailable != 0) 'Stock: ${item.quantityAvailable}'];
    final priceText = '\u20B9 ${_fmt(item.basePrice.toDouble())}';

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.border),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: _Thumb(url: imageUrl, type: ListingType.product),
          ),
          const Gap(12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        item.title,
                        overflow: TextOverflow.ellipsis,
                        style: AppTheme.display(16),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: _statusBg(item.approvalStatus),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(item.approvalStatus, style: AppTheme.display(10)),
                    ),
                  ],
                ),
                const Gap(2),
                Text(priceText.toString(), style: AppTheme.display(14)),
                Row(children: [Text('Stock: ${item.quantityAvailable}', style: AppTheme.hind(11))]),
              ],
            ),
          ),
          // const Icon(Icons.more_vert, size: 20, color: AppColors.muted),
          PopupMenuButton<_MenuAction>(
            padding: EdgeInsets.zero,
            icon: const Icon(Icons.more_vert, color: AppColors.muted, size: 20),
            onSelected: (a) {
              switch (a) {
                case _MenuAction.edit:
                  onEdit();
                case _MenuAction.toggle:
                  onToggle(false);
                case _MenuAction.outOfStock:
                  onOutOfStock();
                case _MenuAction.delete:
                  onDelete();
              }
            },
            itemBuilder: (_) => [
              const PopupMenuItem(value: _MenuAction.edit, child: Text('Edit')),
              PopupMenuItem(
                value: _MenuAction.toggle,
                child: Text(isActive ? 'Pause' : 'Activate'),
              ),
              if (status != ListingStatus.outOfStock)
                const PopupMenuItem(
                  value: _MenuAction.outOfStock,
                  child: Text('Mark out of stock'),
                ),
              const PopupMenuItem(value: _MenuAction.delete, child: Text('Delete')),
            ],
          ),
        ],
      ),
    );
  }
}

class _Thumb extends StatelessWidget {
  final String? url;
  final ListingType type;
  const _Thumb({required this.url, required this.type});

  @override
  Widget build(BuildContext context) {
    final fallback = Container(
      width: 76,
      height: 76,
      color: const Color(0xFFF1F3F6),
      child: Icon(
        type == ListingType.product ? Icons.shopping_basket_outlined : Icons.handyman_outlined,
        color: AppColors.muted,
      ),
    );
    if (url == null || url!.isEmpty) return fallback;
    return Image.network(
      url!,
      width: 76,
      height: 76,
      fit: BoxFit.cover,
      errorBuilder: (_, _, _) => fallback,
    );
  }
}
