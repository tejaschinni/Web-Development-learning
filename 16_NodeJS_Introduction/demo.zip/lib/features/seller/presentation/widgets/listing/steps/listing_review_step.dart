import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_category_provider.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_listing_provider.dart';
import 'package:society_seva/features/shop/data/models/shop_category_model.dart';

class ListingReviewStep extends ConsumerWidget {
  const ListingReviewStep({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(productListingProvider);
    final n = ref.read(productListingProvider.notifier);
    final c = n.controllers;

    final categories = ref.watch(sellerCategoryTreeProvider((categoryType: ''))).valueOrNull ?? [];
    ShopCategoryModel? mainCategory;
    for (final c in categories) {
      if (c.id == s.mainCategoryId ||
          (s.mainCategoryId == null &&
              (c.id == s.subcategoryId || c.subCategories.any((x) => x.id == s.subcategoryId)))) {
        mainCategory = c;
        break;
      }
    }

    final categoryName = mainCategory?.name ?? '—';

    final selectedIds = s.selectedSubcategoryIds;
    final subcategoryNames = mainCategory == null
        ? <String>[]
        : [
            for (final id in selectedIds)
              ...mainCategory.subCategories.where((x) => x.id == id).map((x) => x.name),
          ];
    final subcategoryName = subcategoryNames.isEmpty ? 'None' : subcategoryNames.join(', ');
    final title = c.title.text.trim().isNotEmpty ? c.title.text.trim() : '-';
    final description = c.description.text.trim().isNotEmpty ? c.description.text.trim() : '-';

    final price = c.basePrice.text.trim().isNotEmpty ? c.basePrice.text.trim() : '120';
    final stock = c.quantity.text.trim().isNotEmpty ? c.quantity.text.trim() : '10';

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      children: [
        Text(
          'Review Your Listing',
          style: AppTheme.display(18, w: FontWeight.w700, c: AppColors.ink),
        ),
        const SizedBox(height: 14),

        // 1. Preview Card
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border),
            boxShadow: const [
              BoxShadow(color: Color(0x08000000), blurRadius: 8, offset: Offset(0, 2)),
            ],
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(borderRadius: BorderRadius.circular(8), child: _buildThumbnail(s)),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: AppColors.ink,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      '$categoryName > $subcategoryName',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 11, color: AppColors.muted),
                    ),
                    if (s.listingType.isFood) ...[
                      const SizedBox(height: 6),
                      _buildDietaryBadge(s.foodType),
                    ],
                    const SizedBox(height: 6),
                    Text(
                      description,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 11.5, color: Color(0xFF4A5568)),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),

        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border),
          ),
          child: Column(
            children: [
              _buildDetailRow('Price', '₹ $price', isFirst: true),
              _buildDetailRow('Stock', stock),
              _buildDetailRow('Order Type', 'Immediate + Pre-order'),
              _buildDetailRow(
                'Preparation Time',
                '${c.prepTime.text.trim().isNotEmpty ? c.prepTime.text.trim() : '30'} minutes',
              ),
              _buildDetailRow('Available Days', 'Mon, Tue, Wed, Thu, Fri'),
              _buildDetailRow('Available Time', '10:00 AM - 9:00 PM'),
              if (s.slots.isNotEmpty) ...[
                _buildDetailRow('Available Slots', _slotsSummary(s.slots)),
              ],
              if (s.tags.isNotEmpty) _buildDetailRow('Tags', s.tags.join(', '), isLast: true),
            ],
          ),
        ),
      ],
    );
  }

  String _fmtTime(String hhmm) {
    final p = hhmm.split(':');
    return DateFormat('h:mm a').format(DateTime(2000, 1, 1, int.parse(p[0]), int.parse(p[1])));
  }

  String _slotsSummary(Map<String, List<SlotWindow>> slots) {
    final keys = slots.keys.where((k) => slots[k]!.isNotEmpty).toList()..sort();
    if (keys.isEmpty) return 'No slots added';

    return keys
        .map((k) {
          final day = DateFormat('EEE, dd MMM yyyy').format(DateTime.parse(k));
          final times = slots[k]!
              .map((w) => '${_fmtTime(w.startsAt)} – ${_fmtTime(w.endsAt)}')
              .join(', ');
          return '$day\n$times';
        })
        .join('\n\n');
  }

  Widget _buildThumbnail(ListingFormState s) {
    if (s.visibleRemoteImages.isNotEmpty) {
      return SafeListingImageView.remote(
        s.visibleRemoteImages.first.imageUrl,
        width: 80,
        height: 80,
        fit: BoxFit.cover,
      );
    }
    if (s.pendingImages.isNotEmpty) {
      return SafeListingImageView.pending(
        s.pendingImages.first,
        width: 80,
        height: 80,
        fit: BoxFit.cover,
      );
    }
    return Container(
      width: 80,
      height: 80,
      color: const Color(0xFFF2F4F7),
      child: const Icon(Icons.restaurant, size: 36, color: AppColors.muted),
    );
  }

  Widget _buildDietaryBadge(String type) {
    late final Color color;
    late final String label;

    switch (type) {
      case 'NON_VEG':
        color = const Color(0xFFD92D20);
        label = 'Non-Veg';
        break;
      case 'EGG':
        color = const Color(0xFFF79009);
        label = 'Egg';
        break;
      case 'EGGLESS':
        color = const Color(0xFF667085);
        label = 'Eggless';
        break;
      case 'VEG':
      default:
        color = const Color(0xFF027A48);
        label = 'Veg';
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: color.withValues(alpha: 0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(shape: BoxShape.circle, color: color),
          ),
          const SizedBox(width: 5),
          Text(
            label,
            style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: color),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(String label, String value, {bool isFirst = false, bool isLast = false}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
      decoration: BoxDecoration(
        border: Border(
          bottom: isLast ? BorderSide.none : const BorderSide(color: Color(0xFFF2F4F7)),
        ),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 130,
            child: Text(
              label,
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w500,
                color: AppColors.muted,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: AppColors.ink,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class SafeListingImageView extends StatelessWidget {
  const SafeListingImageView.pending(
    this.xFile, {
    super.key,
    this.fit = BoxFit.cover,
    this.width,
    this.height,
  }) : remoteUrl = null;

  const SafeListingImageView.remote(
    this.remoteUrl, {
    super.key,
    this.fit = BoxFit.cover,
    this.width,
    this.height,
  }) : xFile = null;

  final XFile? xFile;
  final String? remoteUrl;
  final BoxFit fit;
  final double? width;
  final double? height;

  String _resolveUrl(String raw) {
    if (raw.startsWith('http://') || raw.startsWith('https://')) {
      return raw;
    }
    // Prepend default API base path if relative URL
    return 'http://192.168.1.42:8080/society_rest/api/v1/listings/images/$raw';
  }

  @override
  Widget build(BuildContext context) {
    if (remoteUrl != null && remoteUrl!.isNotEmpty) {
      final resolved = _resolveUrl(remoteUrl!);
      return Image.network(
        resolved,
        fit: fit,
        width: width,
        height: height,
        loadingBuilder: (context, child, loadingProgress) {
          if (loadingProgress == null) return child;
          return Container(
            width: width,
            height: height,
            color: const Color(0xFFF1F3F6),
            child: const Center(
              child: SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.green),
              ),
            ),
          );
        },
        errorBuilder: (context, error, stackTrace) => _buildPlaceholder(),
      );
    }

    if (xFile != null) {
      if (kIsWeb) {
        return FutureBuilder<Uint8List>(
          future: xFile!.readAsBytes(),
          builder: (context, snapshot) {
            if (snapshot.hasData && snapshot.data != null) {
              return Image.memory(snapshot.data!, fit: fit, width: width, height: height);
            }
            if (snapshot.hasError) {
              return _buildPlaceholder();
            }
            return Container(
              width: width,
              height: height,
              color: const Color(0xFFF1F3F6),
              child: const Center(
                child: SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.green),
                ),
              ),
            );
          },
        );
      } else {
        return Image.file(
          File(xFile!.path),
          fit: fit,
          width: width,
          height: height,
          errorBuilder: (context, error, stackTrace) => _buildPlaceholder(),
        );
      }
    }

    return _buildPlaceholder();
  }

  Widget _buildPlaceholder() {
    return Container(
      width: width,
      height: height,
      color: const Color(0xFFF2F4F7),
      child: const Center(child: Icon(Icons.restaurant_rounded, color: AppColors.muted, size: 28)),
    );
  }
}
