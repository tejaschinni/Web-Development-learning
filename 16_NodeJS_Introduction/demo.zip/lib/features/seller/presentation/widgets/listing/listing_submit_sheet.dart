import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';

/// Full screen view presenting both Screen 9 (Submitted for Review) and
/// Screen 10 (Listing Published) with an interactive switcher and navigation options.
class ListingSubmissionResultScreen extends ConsumerStatefulWidget {
  const ListingSubmissionResultScreen({
    super.key,
    required this.listingTitle,
    required this.onGoToListings,
    required this.onCreateAnother,
    required this.onViewListing,
    this.initialTab = 0,
  });

  final String listingTitle;
  final VoidCallback onGoToListings;
  final VoidCallback onCreateAnother;
  final VoidCallback onViewListing;
  final int initialTab;

  @override
  ConsumerState<ListingSubmissionResultScreen> createState() =>
      _ListingSubmissionResultScreenState();
}

class _ListingSubmissionResultScreenState
    extends ConsumerState<ListingSubmissionResultScreen> {
  late int _selectedTab;

  @override
  void initState() {
    super.initState();
    _selectedTab = widget.initialTab;
  }

  @override
  Widget build(BuildContext context) {
    final sellerAsync = ref.watch(mySellerProfileProvider);
    final sellerName = sellerAsync.valueOrNull?.displayName ?? 'Meena Sharma';

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            // Top App Bar matching Screens 9 & 10 in mockup
            _ResultScreenHeader(
              sellerName: sellerName,
              onBack: () => Navigator.pop(context),
            ),

            // Tab switch between Screen 9 and Screen 10
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              child: Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: const Color(0xFFF2F4F7),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFFEAECF0)),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: _TabButton(
                        label: '9. Submitted for Review',
                        icon: Icons.assignment_turned_in_outlined,
                        isSelected: _selectedTab == 0,
                        activeColor: const Color(0xFF5B36F5),
                        onTap: () => setState(() => _selectedTab = 0),
                      ),
                    ),
                    const Gap(6),
                    Expanded(
                      child: _TabButton(
                        label: '10. Listing Published',
                        icon: Icons.check_circle_outline,
                        isSelected: _selectedTab == 1,
                        activeColor: const Color(0xFF027A48),
                        onTap: () => setState(() => _selectedTab = 1),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            Expanded(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 250),
                child: _selectedTab == 0
                    ? _SubmittedForReviewView(
                        key: const ValueKey(0),
                        onGoToListings: widget.onGoToListings,
                        onCreateAnother: widget.onCreateAnother,
                        onSwitchToPublished: () => setState(() => _selectedTab = 1),
                      )
                    : _ListingPublishedView(
                        key: const ValueKey(1),
                        listingTitle: widget.listingTitle,
                        onViewListing: widget.onViewListing,
                        onAddAnother: widget.onCreateAnother,
                        onSwitchToSubmitted: () => setState(() => _selectedTab = 0),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TabButton extends StatelessWidget {
  const _TabButton({
    required this.label,
    required this.icon,
    required this.isSelected,
    required this.activeColor,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final bool isSelected;
  final Color activeColor;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(9),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
        decoration: BoxDecoration(
          color: isSelected ? Colors.white : Colors.transparent,
          borderRadius: BorderRadius.circular(9),
          boxShadow: isSelected
              ? const [
                  BoxShadow(
                    color: Color(0x10000000),
                    blurRadius: 4,
                    offset: Offset(0, 1),
                  ),
                ]
              : null,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              size: 15,
              color: isSelected ? activeColor : const Color(0xFF667085),
            ),
            const Gap(5),
            Flexible(
              child: Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                  color: isSelected ? activeColor : const Color(0xFF667085),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Header matching Mockup Screens 6, 7, 8, 9, 10
class _ResultScreenHeader extends StatelessWidget {
  const _ResultScreenHeader({required this.sellerName, required this.onBack});
  final String sellerName;
  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 6, 16, 6),
      child: Row(
        children: [
          IconButton(
            onPressed: onBack,
            icon: const Icon(Icons.arrow_back, color: Color(0xFF344054)),
          ),
          const Gap(4),
          // Logo & App Name
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(4),
                decoration: const BoxDecoration(
                  color: Color(0xFFE6F3EA),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.eco, size: 16, color: Color(0xFF0E4D2F)),
              ),
              const Gap(6),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: const [
                  Text(
                    'Vasundhara SEVA',
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                      color: Color(0xFF0E4D2F),
                      letterSpacing: -0.3,
                    ),
                  ),
                  Text(
                    'Earn Together • Live Together',
                    style: TextStyle(
                      fontSize: 8.5,
                      fontWeight: FontWeight.w500,
                      color: Color(0xFF7A827D),
                    ),
                  ),
                ],
              ),
            ],
          ),
          const Spacer(),
          // Seller profile badge
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const CircleAvatar(
                radius: 15,
                backgroundColor: Color(0xFFFFEAD5),
                child: Icon(Icons.person, size: 18, color: Color(0xFFE04F16)),
              ),
              const Gap(6),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    sellerName,
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF1B1F1D),
                    ),
                  ),
                  const Text(
                    'Seller',
                    style: TextStyle(fontSize: 10, color: Color(0xFF7A827D)),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// Screen 9: Submitted for Review Content
class _SubmittedForReviewView extends StatelessWidget {
  const _SubmittedForReviewView({
    super.key,
    required this.onGoToListings,
    required this.onCreateAnother,
    required this.onSwitchToPublished,
  });

  final VoidCallback onGoToListings;
  final VoidCallback onCreateAnother;
  final VoidCallback onSwitchToPublished;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(24, 20, 24, 24),
      child: Column(
        children: [
          const Gap(10),

          // Heading
          const Text(
            'Listing Submitted!',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: Color(0xFF101828),
              letterSpacing: -0.4,
            ),
          ),
          const Gap(28),

          // Clipboard Illustration with checkmark
          const _ClipboardIllustration(),
          const Gap(32),

          // Subtitle
          const Text(
            'Your listing has been submitted\nfor review.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: Color(0xFF1D2939),
              height: 1.3,
            ),
          ),
          const Gap(12),

          // Body description
          const Text(
            'We will review your listing and notify you\nonce it is published. You can check the status\nin My Listings.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 13,
              color: Color(0xFF667085),
              height: 1.45,
            ),
          ),
          const Gap(32),

          // Primary button: Go to My Listings (Purple)
          SizedBox(
            width: double.infinity,
            height: 48,
            child: ElevatedButton(
              onPressed: onGoToListings,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF5B36F5),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                elevation: 0,
              ),
              child: const Text(
                'Go to My Listings',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
              ),
            ),
          ),
          const Gap(12),

          // Secondary button: Create Another Listing
          SizedBox(
            width: double.infinity,
            height: 48,
            child: OutlinedButton(
              onPressed: onCreateAnother,
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Color(0xFFD0D5DD)),
                foregroundColor: const Color(0xFF5B36F5),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: const Text(
                'Create Another Listing',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
              ),
            ),
          ),
          const Gap(20),

          // Option to view published screen
          InkWell(
            onTap: onSwitchToPublished,
            borderRadius: BorderRadius.circular(8),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: const Color(0xFFECFDF3),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: const Color(0xFFA6F4C5)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: const [
                  Icon(Icons.visibility_outlined, size: 16, color: Color(0xFF027A48)),
                  Gap(6),
                  Text(
                    'Preview Live Published Screen ➜',
                    style: TextStyle(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF027A48),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const Gap(16),

          // Footnote from mockup
          const Text(
            'Listing is submitted and sent for admin review.\nSeller can add another listing.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 11, color: Color(0xFF98A2B3)),
          ),
        ],
      ),
    );
  }
}

/// Screen 10: Listing Published Content
class _ListingPublishedView extends StatelessWidget {
  const _ListingPublishedView({
    super.key,
    required this.listingTitle,
    required this.onViewListing,
    required this.onAddAnother,
    required this.onSwitchToSubmitted,
  });

  final String listingTitle;
  final VoidCallback onViewListing;
  final VoidCallback onAddAnother;
  final VoidCallback onSwitchToSubmitted;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(24, 20, 24, 24),
      child: Column(
        children: [
          const Gap(10),

          // Heading
          const Text(
            'Listing Published!',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: Color(0xFF101828),
              letterSpacing: -0.4,
            ),
          ),
          const Gap(28),

          // Shopping Bag with Confetti Illustration
          const _PublishedBagIllustration(),
          const Gap(32),

          // Subtitle
          const Text(
            'Your listing is now live!',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.w700,
              color: Color(0xFF1D2939),
            ),
          ),
          const Gap(8),

          // Title & visibility message
          Text(
            '$listingTitle\nis published and visible to customers.',
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 13,
              color: Color(0xFF475467),
              height: 1.45,
            ),
          ),
          const Gap(32),

          // Primary button: View Listing (Green)
          SizedBox(
            width: double.infinity,
            height: 48,
            child: ElevatedButton(
              onPressed: onViewListing,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF027A48),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                elevation: 0,
              ),
              child: const Text(
                'View Listing',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
              ),
            ),
          ),
          const Gap(12),

          // Secondary button: Add Another Listing
          SizedBox(
            width: double.infinity,
            height: 48,
            child: OutlinedButton(
              onPressed: onAddAnother,
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Color(0xFF027A48)),
                foregroundColor: const Color(0xFF027A48),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: const Text(
                'Add Another Listing',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
              ),
            ),
          ),
          const Gap(20),

          // Option to view submitted for review screen
          InkWell(
            onTap: onSwitchToSubmitted,
            borderRadius: BorderRadius.circular(8),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: const Color(0xFFF4F3FF),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: const Color(0xFFD9D6FE)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: const [
                  Icon(Icons.assignment_outlined, size: 16, color: Color(0xFF5B36F5)),
                  Gap(6),
                  Text(
                    '📋 View Submitted for Review Screen',
                    style: TextStyle(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF5B36F5),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const Gap(16),

          // Footnote from mockup
          const Text(
            'After admin approval, the listing is published\nand visible to customers.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 11, color: Color(0xFF98A2B3)),
          ),
        ],
      ),
    );
  }
}

/// Clipboard illustration matching Screen 9
class _ClipboardIllustration extends StatelessWidget {
  const _ClipboardIllustration();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 140,
      height: 140,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Soft blue background glow circle
          Container(
            width: 130,
            height: 130,
            decoration: const BoxDecoration(
              color: Color(0xFFEFF8FF),
              shape: BoxShape.circle,
            ),
          ),

          // Clipboard body
          Container(
            width: 78,
            height: 98,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFF2E90FA), width: 2.2),
              boxShadow: const [
                BoxShadow(
                  color: Color(0x182E90FA),
                  blurRadius: 16,
                  offset: Offset(0, 8),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Clip at top
                Center(
                  child: Container(
                    width: 32,
                    height: 8,
                    decoration: const BoxDecoration(
                      color: Color(0xFF2E90FA),
                      borderRadius: BorderRadius.vertical(bottom: Radius.circular(4)),
                    ),
                  ),
                ),
                const Gap(14),

                // Checklist line 1
                _ChecklistLine(color: const Color(0xFF2E90FA)),
                const Gap(8),
                // Checklist line 2
                _ChecklistLine(color: const Color(0xFF2E90FA)),
                const Gap(8),
                // Checklist line 3
                _ChecklistLine(color: const Color(0xFFB2DDFF)),
              ],
            ),
          ),

          // Green checkmark badge at bottom right
          Positioned(
            right: 18,
            bottom: 14,
            child: Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: const Color(0xFF12B76A),
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 3),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0x2812B76A),
                    blurRadius: 8,
                    offset: Offset(0, 3),
                  ),
                ],
              ),
              child: const Icon(Icons.check, size: 20, color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }
}

class _ChecklistLine extends StatelessWidget {
  const _ChecklistLine({required this.color});
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Row(
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const Gap(6),
          Expanded(
            child: Container(
              height: 5,
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.6),
                borderRadius: BorderRadius.circular(3),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Shopping bag illustration with surrounding celebratory confetti matching Screen 10
class _PublishedBagIllustration extends StatelessWidget {
  const _PublishedBagIllustration();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 170,
      height: 150,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Surrounding Confetti Particles Custom Painted
          CustomPaint(
            size: const Size(170, 150),
            painter: const _ConfettiPainter(),
          ),

          // Shopping Bag Body
          Positioned(
            bottom: 12,
            child: Stack(
              clipBehavior: Clip.none,
              alignment: Alignment.center,
              children: [
                // Bag Handle
                Positioned(
                  top: -16,
                  child: Container(
                    width: 36,
                    height: 28,
                    decoration: BoxDecoration(
                      border: Border.all(color: const Color(0xFFF79009), width: 3.5),
                      borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
                    ),
                  ),
                ),

                // Bag Body (Warm Yellow / Orange)
                Container(
                  width: 86,
                  height: 94,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFEC84B), Color(0xFFF79009)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0x30F79009),
                        blurRadius: 18,
                        offset: Offset(0, 8),
                      ),
                    ],
                  ),
                  child: Center(
                    child: Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.25),
                        shape: BoxShape.circle,
                      ),
                    ),
                  ),
                ),

                // Big Green Checkmark Badge overlay
                Positioned(
                  child: Container(
                    width: 42,
                    height: 42,
                    decoration: BoxDecoration(
                      color: const Color(0xFF12B76A),
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white, width: 3),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0x3012B76A),
                          blurRadius: 10,
                          offset: Offset(0, 4),
                        ),
                      ],
                    ),
                    child: const Icon(Icons.check, size: 24, color: Colors.white),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Painter for colorful confetti dots and sparkles surrounding the shopping bag
class _ConfettiPainter extends CustomPainter {
  const _ConfettiPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..style = PaintingStyle.fill;

    // Confetti particles coordinates & colors
    final particles = [
      // Left side
      const _Particle(x: 24, y: 35, color: Color(0xFF1570EF), radius: 3.5, shape: 0),
      const _Particle(x: 32, y: 70, color: Color(0xFFF04438), radius: 4.0, shape: 1),
      const _Particle(x: 18, y: 105, color: Color(0xFF12B76A), radius: 3.0, shape: 0),
      const _Particle(x: 42, y: 25, color: Color(0xFFF79009), radius: 3.2, shape: 1),
      // Top side
      const _Particle(x: 65, y: 16, color: Color(0xFF7A5AF8), radius: 3.5, shape: 1),
      const _Particle(x: 85, y: 8, color: Color(0xFFF04438), radius: 4.2, shape: 0),
      const _Particle(x: 108, y: 18, color: Color(0xFF12B76A), radius: 3.8, shape: 1),
      // Right side
      const _Particle(x: 130, y: 32, color: Color(0xFFF79009), radius: 3.6, shape: 0),
      const _Particle(x: 148, y: 55, color: Color(0xFF1570EF), radius: 4.0, shape: 1),
      const _Particle(x: 142, y: 92, color: Color(0xFFF04438), radius: 3.2, shape: 0),
      const _Particle(x: 154, y: 118, color: Color(0xFF12B76A), radius: 3.5, shape: 1),
      // Bottom accents
      const _Particle(x: 28, y: 132, color: Color(0xFF7A5AF8), radius: 3.0, shape: 0),
      const _Particle(x: 138, y: 136, color: Color(0xFFF79009), radius: 3.4, shape: 0),
    ];

    for (final p in particles) {
      paint.color = p.color;
      if (p.shape == 0) {
        canvas.drawCircle(Offset(p.x, p.y), p.radius, paint);
      } else {
        // Draw small rotated rectangle/capsule
        canvas.save();
        canvas.translate(p.x, p.y);
        canvas.rotate(math.pi / 4);
        canvas.drawRRect(
          RRect.fromRectAndRadius(
            Rect.fromCenter(center: Offset.zero, width: p.radius * 2.2, height: p.radius * 1.2),
            const Radius.circular(2),
          ),
          paint,
        );
        canvas.restore();
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _Particle {
  const _Particle({
    required this.x,
    required this.y,
    required this.color,
    required this.radius,
    required this.shape,
  });

  final double x;
  final double y;
  final Color color;
  final double radius;
  final int shape; // 0 = circle, 1 = rect
}

/// Modal Bottom Sheet compatibility wrapper for existing callers
class ListingSubmittedSheet extends StatelessWidget {
  const ListingSubmittedSheet({
    super.key,
    required this.onGoToListings,
    required this.onCreateAnother,
    this.listingTitle = 'Homemade Veg Thali',
    this.onViewListing,
  });

  final VoidCallback onGoToListings;
  final VoidCallback onCreateAnother;
  final String listingTitle;
  final VoidCallback? onViewListing;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: const Color(0xFFE4E8E3),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const Gap(16),
          const Text(
            'Listing Submitted!',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w800,
              color: Color(0xFF101828),
            ),
          ),
          const Gap(20),
          const _ClipboardIllustration(),
          const Gap(20),
          const Text(
            'Your listing has been submitted for review.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w700,
              color: Color(0xFF1D2939),
            ),
          ),
          const Gap(8),
          const Text(
            'We will review your listing and notify you once it is published. You can check the status in My Listings.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 12.5, color: Color(0xFF667085), height: 1.4),
          ),
          const Gap(24),

          // Primary action
          SizedBox(
            width: double.infinity,
            height: 48,
            child: ElevatedButton(
              onPressed: onGoToListings,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF5B36F5),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                elevation: 0,
              ),
              child: const Text(
                'Go to My Listings',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
              ),
            ),
          ),
          const Gap(10),

          // Secondary action
          SizedBox(
            width: double.infinity,
            height: 48,
            child: OutlinedButton(
              onPressed: onCreateAnother,
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Color(0xFFD0D5DD)),
                foregroundColor: const Color(0xFF5B36F5),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: const Text(
                'Create Another Listing',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
              ),
            ),
          ),
          const Gap(12),

          // Option to view published state
          TextButton.icon(
            onPressed: () {
              Navigator.pop(context);
              showModalBottomSheet(
                context: context,
                isScrollControlled: true,
                backgroundColor: Colors.transparent,
                builder: (ctx) => ListingPublishedSheet(
                  listingTitle: listingTitle,
                  onViewListing: onViewListing ?? onGoToListings,
                  onAddAnother: onCreateAnother,
                ),
              );
            },
            icon: const Icon(Icons.check_circle_outline, size: 16, color: Color(0xFF027A48)),
            label: const Text(
              'View Live Published Screen ➜',
              style: TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w600,
                color: Color(0xFF027A48),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Modal Bottom Sheet compatibility wrapper for published screen
class ListingPublishedSheet extends StatelessWidget {
  const ListingPublishedSheet({
    super.key,
    required this.listingTitle,
    required this.onViewListing,
    required this.onAddAnother,
  });

  final String listingTitle;
  final VoidCallback onViewListing;
  final VoidCallback onAddAnother;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: const Color(0xFFE4E8E3),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const Gap(16),
          const Text(
            'Listing Published!',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w800,
              color: Color(0xFF101828),
            ),
          ),
          const Gap(20),
          const _PublishedBagIllustration(),
          const Gap(20),
          const Text(
            'Your listing is now live!',
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w700,
              color: Color(0xFF1D2939),
            ),
          ),
          const Gap(8),
          Text(
            '$listingTitle\nis published and visible to customers.',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 12.5, color: Color(0xFF667085), height: 1.4),
          ),
          const Gap(24),

          // Primary action
          SizedBox(
            width: double.infinity,
            height: 48,
            child: ElevatedButton(
              onPressed: onViewListing,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF027A48),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                elevation: 0,
              ),
              child: const Text(
                'View Listing',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
              ),
            ),
          ),
          const Gap(10),

          // Secondary action
          SizedBox(
            width: double.infinity,
            height: 48,
            child: OutlinedButton(
              onPressed: onAddAnother,
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Color(0xFF027A48)),
                foregroundColor: const Color(0xFF027A48),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: const Text(
                'Add Another Listing',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
