// lib/features/seller/presentation/widgets/listing/steps/listing_photos_step.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:image_picker/image_picker.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_listing_provider.dart';
import 'package:society_seva/features/seller/presentation/widgets/listing/listing_form_widgets.dart';
import 'package:society_seva/features/seller/presentation/widgets/listing/steps/listing_review_step.dart';

class ListingPhotosStep extends ConsumerStatefulWidget {
  const ListingPhotosStep({super.key});

  @override
  ConsumerState<ListingPhotosStep> createState() => _ListingPhotosStepState();
}

class _ListingPhotosStepState extends ConsumerState<ListingPhotosStep> {
  int _selectedIndex = 0;

  Future<void> _pick(ImageSource source) async {
    final picker = ImagePicker();
    final List<XFile> files;
    if (source == ImageSource.gallery) {
      files = await picker.pickMultiImage(imageQuality: 85, maxWidth: 1600);
    } else {
      final f = await picker.pickImage(source: source, imageQuality: 85, maxWidth: 1600);
      files = f == null ? [] : [f];
    }
    if (files.isEmpty || !mounted) return;

    final msg = await ref.read(productListingProvider.notifier).addPendingImages(files);
    if (msg != null && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
    }
  }

  void _chooseSource() {
    showModalBottomSheet<void>(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (sheetCtx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.photo_library_outlined, color: AppColors.green),
                title: Text('Choose from Gallery', style: AppTheme.hind(14, w: FontWeight.w600)),
                onTap: () {
                  Navigator.pop(sheetCtx);
                  _pick(ImageSource.gallery);
                },
              ),
              ListTile(
                leading: const Icon(Icons.photo_camera_outlined, color: AppColors.green),
                title: Text('Take a Photo', style: AppTheme.hind(14, w: FontWeight.w600)),
                onTap: () {
                  Navigator.pop(sheetCtx);
                  _pick(ImageSource.camera);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = ref.watch(productListingProvider);
    final n = ref.read(productListingProvider.notifier);

    final total = s.totalImageCount; // excludes images marked for deletion
    final atLimit = total >= kMaxListingImages;

    // One ordered list: server images first (including ones marked for
    // deletion, so they can be undone), then local pending files.
    final items = <_PhotoItem>[
      for (final img in s.remoteImages)
        () {
          final deleting = s.deletingImageIds.contains(img.id);
          return _PhotoItem(
            image: SafeListingImageView.remote(img.imageUrl, fit: BoxFit.cover),
            deleting: deleting,
            badge: (!deleting && img.moderationStatus == 'PENDING') ? 'In review' : null,
            onAction: () =>
                deleting ? n.unmarkRemoteForDelete(img.id) : n.markRemoteForDelete(img.id),
          );
        }(),
      for (final f in s.pendingImages)
        _PhotoItem(
          image: SafeListingImageView.pending(f, fit: BoxFit.cover),
          badge: 'Not uploaded',
          onAction: () => n.removePendingImage(f),
        ),
    ];

    // Cover = first photo that is not being deleted.
    final coverIndex = items.indexWhere((i) => !i.deleting);
    final selected = items.isEmpty ? 0 : _selectedIndex.clamp(0, items.length - 1);
    final busy = s.isBusy;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      children: [
        const StepHeader(
          title: 'Listing Photos',
          subtitle: 'Add clear photos. The first photo is your cover photo.',
        ),
        const Gap(8),

        if (s.isUploadingImages) ...[
          const LinearProgressIndicator(color: AppColors.green),
          const Gap(12),
        ],

        // header + count
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              'Photos',
              style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: AppColors.ink),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: total > 0 ? AppColors.greenSoft : Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.border),
              ),
              child: Text(
                '$total/$kMaxListingImages',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: total > 0 ? AppColors.greenDeep : AppColors.muted,
                ),
              ),
            ),
          ],
        ),
        const Gap(12),

        // ── horizontal reel ──
        if (items.isNotEmpty || !atLimit)
          SizedBox(
            height: 104,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                if (!atLimit)
                  Padding(
                    padding: const EdgeInsets.only(right: 12),
                    child: InkWell(
                      onTap: busy ? null : _chooseSource,
                      borderRadius: BorderRadius.circular(12),
                      child: Container(
                        width: 96,
                        height: 96,
                        decoration: BoxDecoration(
                          color: AppColors.greenSoft,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: AppColors.green, width: 1.5),
                        ),
                        child: const Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.add_photo_alternate_outlined,
                              color: AppColors.green,
                              size: 26,
                            ),
                            SizedBox(height: 4),
                            Text(
                              'Add Photo',
                              style: TextStyle(
                                fontSize: 11.5,
                                fontWeight: FontWeight.w600,
                                color: AppColors.greenDeep,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                for (var i = 0; i < items.length; i++)
                  Padding(
                    padding: const EdgeInsets.only(right: 12),
                    child: _PhotoCard(
                      item: items[i],
                      isSelected: selected == i,
                      isCover: i == coverIndex,
                      onTap: () => setState(() => _selectedIndex = i),
                    ),
                  ),
              ],
            ),
          ),
        const Gap(16),

        // ── large preview / empty state ──
        if (items.isNotEmpty) ...[
          Container(
            height: 220,
            width: double.infinity,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.border),
              color: Colors.white,
            ),
            child: Stack(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: SizedBox.expand(
                    child: Opacity(
                      opacity: items[selected].deleting ? .35 : 1,
                      child: items[selected].image,
                    ),
                  ),
                ),
                Positioned(
                  top: 10,
                  left: 10,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: items[selected].deleting
                          ? AppColors.red
                          : (selected == coverIndex
                                ? AppColors.green
                                : Colors.black.withValues(alpha: 0.65)),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (!items[selected].deleting && selected == coverIndex) ...[
                          const Icon(Icons.star, size: 12, color: Colors.white),
                          const SizedBox(width: 4),
                        ],
                        Text(
                          items[selected].deleting
                              ? 'Removed when you save'
                              : (selected == coverIndex
                                    ? 'Cover Photo'
                                    : 'Photo ${selected + 1} of ${items.length}'),
                          style: const TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                if (items[selected].badge != null && !items[selected].deleting)
                  Positioned(bottom: 10, left: 10, child: _Badge(items[selected].badge!)),
              ],
            ),
          ),
          const Gap(16),
        ] else
          InkWell(
            onTap: busy ? null : _chooseSource,
            borderRadius: BorderRadius.circular(14),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 16),
              decoration: BoxDecoration(
                color: AppColors.greenSoft,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppColors.green.withValues(alpha: 0.5), width: 1.5),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      color: AppColors.green.withValues(alpha: 0.12),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.cloud_upload_outlined,
                      color: AppColors.green,
                      size: 30,
                    ),
                  ),
                  const Gap(12),
                  const Text(
                    'Upload Photos',
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      color: AppColors.ink,
                    ),
                  ),
                  const Gap(4),
                  const Text(
                    'Tap to browse your gallery or take a picture',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 12, color: AppColors.muted),
                  ),
                  const Gap(16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _SourceButton(
                        icon: Icons.photo_library_outlined,
                        label: 'Gallery',
                        onPressed: busy ? null : () => _pick(ImageSource.gallery),
                      ),
                      const Gap(12),
                      _SourceButton(
                        icon: Icons.photo_camera_outlined,
                        label: 'Camera',
                        onPressed: busy ? null : () => _pick(ImageSource.camera),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

        if (items.isEmpty) const Gap(16),

        // ── info banner ──
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppColors.border),
          ),
          child: const Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(Icons.info_outline_rounded, color: AppColors.green, size: 18),
              Gap(8),
              Expanded(
                child: Text(
                  'Use clear, well-lit photos and show the actual item from a few angles.\n'
                  'JPG or PNG, up to 5 MB each. Photos upload when you tap Save or Submit.',
                  style: TextStyle(fontSize: 11.5, color: AppColors.muted, height: 1.35),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _PhotoItem {
  const _PhotoItem({
    required this.image,
    required this.onAction,
    this.deleting = false,
    this.badge,
  });

  final Widget image;
  final VoidCallback onAction; // remove, or undo when [deleting]
  final bool deleting;
  final String? badge;
}

class _PhotoCard extends StatelessWidget {
  const _PhotoCard({
    required this.item,
    required this.isSelected,
    required this.isCover,
    required this.onTap,
  });

  final _PhotoItem item;
  final bool isSelected;
  final bool isCover;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            width: 96,
            height: 96,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: isSelected ? AppColors.green : AppColors.border,
                width: isSelected ? 2.5 : 1,
              ),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Opacity(opacity: item.deleting ? .35 : 1, child: item.image),
            ),
          ),
          if (isCover)
            Positioned(
              bottom: 6,
              left: 6,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: AppColors.green,
                  borderRadius: BorderRadius.circular(4),
                ),
                child: const Text(
                  'Cover',
                  style: TextStyle(fontSize: 9, fontWeight: FontWeight.w700, color: Colors.white),
                ),
              ),
            )
          else if (item.badge != null)
            Positioned(bottom: 6, left: 6, child: _Badge(item.badge!, small: true)),
          Positioned(
            top: 4,
            right: 4,
            child: InkWell(
              onTap: item.onAction,
              child: Container(
                width: 22,
                height: 22,
                decoration: const BoxDecoration(color: Colors.black87, shape: BoxShape.circle),
                child: Center(
                  child: Icon(
                    item.deleting ? Icons.undo : Icons.close,
                    size: 13,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  const _Badge(this.text, {this.small = false});
  final String text;
  final bool small;

  @override
  Widget build(BuildContext context) => Container(
    padding: EdgeInsets.symmetric(horizontal: small ? 5 : 8, vertical: 2),
    decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(6)),
    child: Text(
      text,
      style: TextStyle(color: Colors.white, fontSize: small ? 9 : 11),
    ),
  );
}

class _SourceButton extends StatelessWidget {
  const _SourceButton({required this.icon, required this.label, required this.onPressed});
  final IconData icon;
  final String label;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) => OutlinedButton.icon(
    onPressed: onPressed,
    icon: Icon(icon, size: 16),
    label: Text(label, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
    style: OutlinedButton.styleFrom(
      foregroundColor: AppColors.green,
      side: const BorderSide(color: AppColors.green),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
    ),
  );
}
