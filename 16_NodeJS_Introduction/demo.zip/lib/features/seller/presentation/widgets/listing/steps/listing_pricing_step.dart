import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_listing_provider.dart';
import 'package:society_seva/features/seller/presentation/widgets/listing/listing_form_widgets.dart';
import 'package:society_seva/features/seller/presentation/widgets/listing/slot_section_widget.dart';

class ListingPricingStep extends ConsumerWidget {
  const ListingPricingStep({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(productListingProvider);
    final n = ref.read(productListingProvider.notifier);
    final c = n.controllers;
    final isFood = s.listingType.isFood;
    final isService = s.listingType.isService;
    final isProduct = !isFood && !isService;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      children: [
        Text(
          'Pricing & Availability',
          style: AppTheme.display(18, w: FontWeight.w700, c: AppColors.ink),
        ),
        const SizedBox(height: 16),
        SwitchRow(title: 'This listing is free', value: s.isFree, onChanged: n.setFree),
        if (isFood) ...[
          const SectionTitle('Serving sizes & prices'),
          const Padding(
            padding: EdgeInsets.only(bottom: 10),
            child: Text(
              'Each serving needs a unique size value + unit combination.',
              style: TextStyle(fontSize: 12.5, color: AppColors.muted),
            ),
          ),
          for (var i = 0; i < s.servings.length; i++)
            _ServingCard(
              key: ValueKey(s.servings[i]),
              index: i,
              draft: s.servings[i],
              canRemove: s.servings.length > 1,
              onRemove: () => n.removeServing(i),
              onAvailability: (v) => n.setServingAvailable(i, v),
            ),
          OutlinedButton.icon(
            onPressed: n.addServing,
            icon: const Icon(Icons.add),
            label: const Text('Add serving size'),
            style: OutlinedButton.styleFrom(
              foregroundColor: AppColors.green,
              side: const BorderSide(color: AppColors.green),
            ),
          ),
        ] else ...[
          const Gap(8),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: FormTextField(
                  label: 'Price per unit (₹)',
                  controller: c.basePrice,
                  prefix: '₹ ',
                  hint: '0.00',
                  required: !s.isFree,
                  enabled: !s.isFree,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  inputFormatters: decimalOnly,
                ),
              ),
              const Gap(14),
              Expanded(
                child: DropdownField(
                  label: 'Price unit',
                  value: s.priceUnit,
                  items: kPriceUnits,
                  onChanged: n.setPriceUnit,
                ),
              ),
            ],
          ),
        ],
        const Gap(8),
        if (isProduct) ...[
          const Gap(8),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: FormTextField(
                  label: 'Stock quantity',
                  controller: c.quantity,
                  hint: 'e.g. 10',
                  required: true,
                  keyboardType: TextInputType.number,
                  inputFormatters: digitsOnly,
                ),
              ),
              const Gap(14),
              Expanded(
                child: DropdownField(
                  label: 'Availability status',
                  value: s.availabilityStatus,
                  items: kAvailabilityStatuses,
                  onChanged: n.setAvailabilityStatus,
                ),
              ),
            ],
          ),
        ],
        if (isService) ...[const Gap(8), const SlotsSection()],
      ],
    );
  }
}

class _ServingCard extends StatelessWidget {
  const _ServingCard({
    super.key,
    required this.index,
    required this.draft,
    required this.canRemove,
    required this.onRemove,
    required this.onAvailability,
  });

  final int index;
  final ServingSizeDraft draft;
  final bool canRemove;
  final VoidCallback onRemove;
  final ValueChanged<bool> onAvailability;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.border),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'Serving ${index + 1}',
                style: const TextStyle(fontWeight: FontWeight.w700, color: kNavy),
              ),
              const Spacer(),
              if (canRemove)
                IconButton(
                  visualDensity: VisualDensity.compact,
                  onPressed: onRemove,
                  icon: const Icon(Icons.delete_outline, color: Colors.red),
                ),
            ],
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: FormTextField(
                  label: 'Size value',
                  controller: draft.sizeValue,
                  required: true,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  inputFormatters: decimalOnly,
                ),
              ),
              const Gap(10),
              Expanded(
                child: FormTextField(
                  label: 'Unit',
                  controller: draft.sizeUnit,
                  required: true,
                  hint: 'Plate / KG / Inch',
                ),
              ),
            ],
          ),
          FormTextField(
            label: 'Description',
            controller: draft.description,
            required: true,
            hint: 'e.g. Half plate',
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: FormTextField(
                  label: 'Price',
                  controller: draft.price,
                  prefix: '₹ ',
                  required: true,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  inputFormatters: decimalOnly,
                ),
              ),
              const Gap(10),
              Expanded(
                child: FormTextField(
                  label: 'Quantity',
                  controller: draft.quantity,
                  required: true,
                  keyboardType: TextInputType.number,
                  inputFormatters: digitsOnly,
                ),
              ),
            ],
          ),
          SwitchRow(title: 'Available', value: draft.isAvailable, onChanged: onAvailability),
        ],
      ),
    );
  }
}

class _DateBox extends StatelessWidget {
  const _DateBox({required this.label, required this.value, required this.onTap});

  final String label;
  final String value;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.ink),
        ),
        const SizedBox(height: 6),
        InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(8),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 13),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppColors.border),
            ),
            child: Row(
              children: [
                const Icon(Icons.calendar_today_rounded, size: 16, color: AppColors.muted),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(value, style: const TextStyle(fontSize: 13, color: AppColors.ink)),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
