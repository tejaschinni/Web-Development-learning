// lib/features/seller/presentation/widgets/listing/steps/listing_basic_info_step.dart

import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_listing_provider.dart';

const _foodTypeColors = <String, Color>{
  'VEG': Color(0xFF027A48),
  'NON_VEG': Color(0xFFD92D20),
  'VEGAN': Color(0xFF12B76A),
  'EGG': Color(0xFFF79009),
};

class ListingBasicInfoStep extends ConsumerWidget {
  const ListingBasicInfoStep({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(productListingProvider);
    final n = ref.read(productListingProvider.notifier);
    final c = n.controllers;

    final detailedLen = c.description.text.length;

    log(s.listingType.name);

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      children: [
        Text(
          'Add Product Details',
          style: AppTheme.display(18, w: FontWeight.w700, c: AppColors.ink),
        ),
        const SizedBox(height: 16),

        // 1. Product Name *
        _buildFieldLabel('Product Name', required: true),
        const SizedBox(height: 6),
        TextField(
          controller: c.title,
          style: const TextStyle(fontSize: 14, color: AppColors.ink),
          decoration: _inputDecoration(hintText: 'e.g., Homemade Veg Thali'),
        ),

        const SizedBox(height: 16),

        // 3. Detailed Description
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _buildFieldLabel('Description', required: true),
            Text('$detailedLen/1000', style: const TextStyle(fontSize: 11, color: AppColors.muted)),
          ],
        ),
        const SizedBox(height: 6),
        TextField(
          controller: c.description,
          maxLength: 1000,
          maxLines: 4,
          buildCounter: (_, {required currentLength, required isFocused, maxLength}) => null,
          style: const TextStyle(fontSize: 14, color: AppColors.ink),
          decoration: _inputDecoration(
            hintText: 'Hygienically prepared at home using fresh ingredients.',
          ),
        ),
        const SizedBox(height: 20),

        if (s.listingType.isFood) ...[
          _buildFieldLabel('Dietary Information', required: false),
          const SizedBox(height: 10),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                for (final entry in kFoodTypes.entries) ...[
                  _DietaryPill(
                    label: entry.value,
                    type: entry.key,
                    iconColor: _foodTypeColors[entry.key] ?? const Color(0xFF667085),
                    selected: s.foodType == entry.key,
                    onTap: () => n.setFoodType(entry.key),
                  ),
                  const SizedBox(width: 8),
                ],
              ],
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildFieldLabel(String label, {required bool required}) {
    return RichText(
      text: TextSpan(
        text: label,
        style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.ink),
        children: [
          if (required)
            const TextSpan(
              text: ' *',
              style: TextStyle(color: AppColors.red, fontWeight: FontWeight.bold),
            ),
        ],
      ),
    );
  }

  InputDecoration _inputDecoration({required String hintText}) {
    return InputDecoration(
      hintText: hintText,
      hintStyle: const TextStyle(color: AppColors.muted, fontSize: 13),
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: AppColors.border),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: AppColors.green, width: 1.5),
      ),
    );
  }
}

class _DietaryPill extends StatelessWidget {
  const _DietaryPill({
    required this.label,
    required this.type,
    required this.iconColor,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final String type;
  final Color iconColor;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFEBFDF2) : Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: selected ? AppColors.green : AppColors.border,
            width: selected ? 1.5 : 1.0,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 14,
              height: 14,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: selected ? AppColors.green : iconColor,
                  width: selected ? 4 : 1.5,
                ),
                color: selected ? Colors.white : Colors.transparent,
              ),
            ),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                fontSize: 13,
                fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                color: selected ? AppColors.green : AppColors.ink,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
