import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:society_seva/app/theme/app_theme.dart';

class OrderStepItem {
  const OrderStepItem({
    required this.title,
    required this.icon,
    this.isCompleted = false,
    this.isActive = false,
  });

  final String title;
  final IconData icon;
  final bool isCompleted;
  final bool isActive;
}

class SellerOrderStepper extends StatelessWidget {
  const SellerOrderStepper({super.key, required this.steps, this.activeColor = AppColors.blue});

  final List<OrderStepItem> steps;
  final Color activeColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          for (int i = 0; i < steps.length; i++) ...[
            Expanded(child: _buildStepNode(steps[i], i, steps.length)),
            if (i < steps.length - 1)
              Padding(
                padding: const EdgeInsets.only(top: 14),
                child: SizedBox(
                  width: 24,
                  child: Divider(
                    thickness: 1.5,
                    color: steps[i].isCompleted ? AppColors.green : AppColors.border,
                  ),
                ),
              ),
          ],
        ],
      ),
    );
  }

  Widget _buildStepNode(OrderStepItem step, int index, int total) {
    Color circleColor;
    Color iconColor;
    IconData displayIcon = step.icon;

    if (step.isCompleted) {
      circleColor = AppColors.green;
      iconColor = Colors.white;
      displayIcon = Icons.check_rounded;
    } else if (step.isActive) {
      circleColor = activeColor;
      iconColor = Colors.white;
    } else {
      circleColor = Colors.white;
      iconColor = AppColors.muted;
    }

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 28,
          height: 28,
          decoration: BoxDecoration(
            color: circleColor,
            shape: BoxShape.circle,
            border: Border.all(
              color: step.isCompleted
                  ? AppColors.green
                  : (step.isActive ? activeColor : AppColors.border),
              width: 1.5,
            ),
          ),
          child: Center(child: Icon(displayIcon, size: 16, color: iconColor)),
        ),
        const Gap(6),
        Text(
          step.title,
          textAlign: TextAlign.center,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: AppTheme.hind(
            11,
            w: step.isActive
                ? FontWeight.w700
                : (step.isCompleted ? FontWeight.w600 : FontWeight.w400),
            c: step.isActive
                ? activeColor
                : (step.isCompleted ? AppColors.greenDeep : AppColors.muted),
          ),
        ),
      ],
    );
  }
}
