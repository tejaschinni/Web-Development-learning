import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/core/utils/date_formatter.dart';
import 'package:society_seva/app/router/app_router.dart';
import 'package:society_seva/features/seller/domain/entities/seller_order_entity.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_order_provider.dart';
import 'package:society_seva/features/seller/presentation/widgets/dashboard/order_widget.dart';

class OrderCard extends ConsumerWidget {
  const OrderCard({super.key, required this.order});
  final SellerOrderEntity order;

  void _open(BuildContext context, String name) {
    if (order.orderStatus != "CREATED" &&
        order.orderStatus != "PENDING" &&
        order.orderStatus != "PAID") {
      context.push('/modules/seller/orderAccepted', extra: order);
    } else {
      context.push(
        '/modules/seller/orderDetails',
        extra: OrderDetailsArgs(order: order, buyerName: name),
      );
    }
  }

  Future<void> _accept(BuildContext context, WidgetRef ref) async {
    final ok = await ref
        .read(sellerOrderActionProvider.notifier)
        .transition(sellerId: order.sellerId, orderId: order.id, newStatus: 'ACCEPTED');

    if (!context.mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(ok ? 'Order accepted' : 'Could not accept order')));
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final buyerNameProvider = ref.watch(buyerNameByUserIdProvider(order.buyerId));
    final isBusy = ref.watch(sellerOrderActionProvider.select((s) => s.isBusy(order.id)));
    final isPending = const ['PENDING', 'CREATED'].contains(order.orderStatus);
    final isRejected = const ['REJECTED'].contains(order.orderStatus);
    final iscompleted = const ['COMPLETED'].contains(order.orderStatus);
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(order.orderNumber, style: AppTheme.hind(15, w: FontWeight.w700)),
                    Text(
                      formatOrderDate(order.createdAt),
                      style: AppTheme.hind(12, c: AppColors.muted),
                    ),
                  ],
                ),
              ),
              StatusBadge(
                label: isPending
                    ? 'Pending Acceptance'
                    : isRejected
                    ? 'Rejected'
                    : iscompleted
                    ? 'Completed'
                    : 'Accepted',
                icon: isPending
                    ? Icons.hourglass_top
                    : isRejected
                    ? Icons.cancel
                    : iscompleted
                    ? Icons.check_circle
                    : Icons.check_circle,
                background: isPending
                    ? AppColors.orange
                    : isRejected
                    ? AppColors.red
                    : iscompleted
                    ? AppColors.blue
                    : AppColors.green,
              ),
            ],
          ),
          const Gap(10),
          Row(
            children: [
              const CircleAvatar(
                radius: 20,
                backgroundColor: AppColors.greenSoft,
                child: Icon(Icons.person, color: AppColors.green),
              ),
              const Gap(10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      buyerNameProvider.when(
                        data: (name) => name.toString(),
                        loading: () => 'Loading...',
                        error: (_, _) => 'Customer',
                      ),
                      style: AppTheme.hind(14, w: FontWeight.w600),
                    ),
                    Text(order.items.first.titleSnapshot, style: AppTheme.hind(13)),
                  ],
                ),
              ),
              Text('\u20B9 ${order.totalAmount}', style: AppTheme.hind(15, w: FontWeight.w700)),
            ],
          ),
          const Gap(12),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    minimumSize: const Size(0, 40),
                    foregroundColor: AppColors.green,
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    side: const BorderSide(color: AppColors.green),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                  ),
                  onPressed: () {
                    _open(context, buyerNameProvider.valueOrNull ?? 'Customer');
                  },
                  child: Text('View'),
                ),
              ),
              const Gap(10),
              if (isPending) ...[
                const Gap(10),
                Expanded(
                  child: FilledButton(
                    style: FilledButton.styleFrom(
                      minimumSize: const Size(0, 40),
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                    ),
                    onPressed: isBusy ? () {} : () => _accept(context, ref),
                    child: Text(isBusy ? 'Accepting...' : 'Accept'),
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}
