import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:society_seva/app/theme/app_theme.dart';

/// Back arrow + logo (+ optional bell). Replace [_Logo] with your asset.
class OrderHeader extends StatelessWidget {
  const OrderHeader({super.key, this.showBell = false});
  final bool showBell;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 4, 12, 0),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back, color: AppColors.ink),
            onPressed: () => Navigator.maybePop(context),
          ),
          const Spacer(),
          const _Logo(),
          const Spacer(),
          showBell
              ? Stack(
                  clipBehavior: Clip.none,
                  children: [
                    const Icon(Icons.notifications_none_rounded, color: AppColors.orange, size: 28),
                    Positioned(
                      right: -2,
                      top: -2,
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: const BoxDecoration(
                          color: AppColors.red,
                          shape: BoxShape.circle,
                        ),
                        child: Text(
                          '3',
                          style: AppTheme.hind(9, w: FontWeight.w600, c: Colors.white),
                        ),
                      ),
                    ),
                  ],
                )
              : const Gap(40),
        ],
      ),
    );
  }
}

class _Logo extends StatelessWidget {
  const _Logo();
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Row(
        //   mainAxisSize: MainAxisSize.min,
        //   children: [
        //     Icon(Icons.eco, color: AppColors.green, size: 26),
        //     const Gap(4),
        //     Text(
        //       'Vasundhara',
        //       style: AppTheme.hind(20, w: FontWeight.w700, c: AppColors.green),
        //     ),
        //     Text(
        //       ' SEVA',
        //       style: AppTheme.hind(20, w: FontWeight.w700, c: AppColors.orange),
        //     ),
        //   ],
        // ),

        Image.asset(
          'assets/images/logo/h-logo.png',
          fit: BoxFit.scaleDown,
          height: 35,
          alignment: Alignment.centerLeft,
        ),
        Text('Earn Together  Live Together', style: AppTheme.hind(9, c: AppColors.muted)),
      ],
    );
  }
}

class AppCard extends StatelessWidget {
  const AppCard({super.key, required this.child, this.padding, this.color});
  final Widget child;
  final EdgeInsets? padding;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: padding ?? const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color ?? AppColors.bg,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: child,
    );
  }
}

class StatusBadge extends StatelessWidget {
  const StatusBadge({
    super.key,
    required this.label,
    this.icon,
    this.background = AppColors.orange,
    this.foreground = AppColors.orangeSoft,
  });
  final String label;
  final IconData? icon;
  final Color background;
  final Color foreground;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(color: background, borderRadius: BorderRadius.circular(20)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[Icon(icon, size: 14, color: foreground), const Gap(4)],
          Text(
            label,
            style: AppTheme.hind(12, w: FontWeight.w600, c: foreground),
          ),
        ],
      ),
    );
  }
}

class FilledAppButton extends StatelessWidget {
  const FilledAppButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.height = 46,
  });
  final String label;
  final VoidCallback onPressed;
  final double height;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: height,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.green,
          foregroundColor: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
        child: Text(
          label,
          style: AppTheme.hind(15, w: FontWeight.w600, c: Colors.white),
        ),
      ),
    );
  }
}

class OutlinedAppButton extends StatelessWidget {
  const OutlinedAppButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.color = AppColors.green,
    this.height = 46,
  });
  final String label;
  final VoidCallback onPressed;
  final Color color;
  final double height;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: height,
      child: OutlinedButton(
        onPressed: onPressed,
        style: OutlinedButton.styleFrom(
          foregroundColor: color,
          side: BorderSide(color: color, width: 1.2),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
        child: Text(
          label,
          style: AppTheme.hind(15, w: FontWeight.w600, c: color),
        ),
      ),
    );
  }
}
