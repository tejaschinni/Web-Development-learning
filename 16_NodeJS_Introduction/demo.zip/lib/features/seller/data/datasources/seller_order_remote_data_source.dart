
import 'package:society_seva/core/mock/mock_data.dart';
import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/core/network/request_logger.dart';
import 'package:society_seva/features/seller/data/models/order_status_history_model.dart';
import 'package:society_seva/features/seller/data/models/seller_order_model.dart';

abstract class SellerOrderRemoteDataSource {
  Future<PageResponse<SellerOrderModel>> fetchSellerOrdersDataSource({required String sellerId});

  Future<SellerOrderModel> transitionOrderDataSource({
    required String orderId,
    required String newStatus,
    String? note,
  });

  Future<String> fetchBuyerIdDataSource({required String buyerId});
  Future<List<OrderStatusHistoryModel>> fetchOrderStatusHistoryDataSource({
    required String orderID,
  });
}

class SellerOrderRemoteDataSourceImpl implements SellerOrderRemoteDataSource {
  SellerOrderRemoteDataSourceImpl(this._apiClient);

  final ApiClient _apiClient;
  final List<SellerOrderModel> _orders = List.of(MockData.sellerOrders);

  @override
  Future<PageResponse<SellerOrderModel>> fetchSellerOrdersDataSource({
    required String sellerId,
  }) async {
    try {
      final response = await _apiClient.get(
        ApiEndpoints.orders,
        queryParameters: {'sellerId': sellerId},
      );
      return PageResponse.fromJson(
        Map<String, dynamic>.from(response.data as Map),
        SellerOrderModel.fromJson,
      );
    } catch (_) {
      return PageResponse<SellerOrderModel>(
        content: _orders,
        totalElements: _orders.length,
        totalPages: 1,
        size: 50,
        page: 0,
        first: true,
        last: true,
      );
    }
  }

  @override
  Future<SellerOrderModel> transitionOrderDataSource({
    required String orderId,
    required String newStatus,
    String? note,
  }) async {
    final params = <String, dynamic>{
      'newStatus': newStatus,
      if (note != null && note.isNotEmpty) 'note': note,
    };
    RequestLogger.logPost(
      endpoint: ApiEndpoints.orderTransition(orderId),
      payload: params,
      method: 'POST',
    );

    try {
      final response = await _apiClient.post(
        ApiEndpoints.orderTransition(orderId),
        queryParameters: params,
      );
      return SellerOrderModel.fromJson(response.data as Map<String, dynamic>);
    } catch (_) {
      final index = _orders.indexWhere((o) => o.id == orderId);
      if (index != -1) {
        final existing = _orders[index];
        final updated = SellerOrderModel(
          id: existing.id,
          orderNumber: existing.orderNumber,
          buyerId: existing.buyerId,
          sellerId: existing.sellerId,
          orderType: existing.orderType,
          orderStatus: newStatus,
          subtotalAmount: existing.subtotalAmount,
          discountAmount: existing.discountAmount,
          platformCommission: existing.platformCommission,
          welfareFundAmount: existing.welfareFundAmount,
          sellerEarning: existing.sellerEarning,
          totalAmount: existing.totalAmount,
          paymentStatus: existing.paymentStatus,
          items: existing.items,
          createdAt: existing.createdAt,
        );
        _orders[index] = updated;
        return updated;
      }
      return _orders.first;
    }
  }

  @override
  Future<String> fetchBuyerIdDataSource({required String buyerId}) async {
    try {
      final response = await _apiClient.get(ApiEndpoints.fetchBuyerNameFromID(buyerId));
      if (response.statusCode == 200 && response.data != null) {
        return response.data['fullName'] ?? 'Aarav Mehta';
      }
    } catch (_) {}
    return 'Aarav Mehta (Tower A - 301)';
  }

  @override
  Future<List<OrderStatusHistoryModel>> fetchOrderStatusHistoryDataSource({
    required String orderID,
  }) async {
    try {
      final response = await _apiClient.get(ApiEndpoints.orderStatusHistory(orderID));
      final List<dynamic> data = response.data as List<dynamic>;
      return data
          .map((item) => OrderStatusHistoryModel.fromJson(item as Map<String, dynamic>))
          .toList();
    } catch (_) {
      return MockData.orderStatusHistory;
    }
  }
}
