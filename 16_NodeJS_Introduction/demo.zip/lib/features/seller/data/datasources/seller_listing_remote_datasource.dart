
import 'package:dio/dio.dart';
import 'package:image_picker/image_picker.dart';
import 'package:society_seva/core/mock/mock_data.dart';
import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/core/network/request_logger.dart';
import 'package:society_seva/features/seller/data/models/food_detail_model.dart';
import 'package:society_seva/features/seller/data/models/request/food_additional_information_request.dart';
import 'package:society_seva/features/seller/data/models/request/seller_listing_basic_info_request.dart';
import 'package:society_seva/features/seller/data/models/request/service_additional_information_request.dart';
import 'package:society_seva/features/seller/data/models/seller_listing_image_model.dart';
import 'package:society_seva/features/seller/data/models/seller_listing_model.dart';
import 'package:society_seva/features/seller/data/models/service_detail_model.dart';
import 'package:society_seva/features/seller/data/models/service_slot_model.dart';

abstract class SellerListingRemoteDatasource {
  Future<PageResponse<SellerListingModel>> fetchMyListingDataSource({required String sellerId});

  Future<SellerListingModel> fetchListingByIdDataSource({required String listingID});

  Future<List<SellerListingImageModel>> getListingImagesDataSource(String listingId);

  Future<SellerListingModel?> createListingDataSource({
    required SellerListingBasicInfoRequest request,
  });

  Future<SellerListingModel?> submitListingDataSource({required String listingId});

  Future<SellerListingModel?> updateSubmitListingDataSource({
    required String listingId,
    required SellerListingBasicInfoRequest request,
  });

  Future<SellerListingImageModel> uploadSellerShopImagesDataSource(String sellerId, XFile file);

  Future<bool> additionalFoodInformationDataSource({
    required FoodAdditionalInformationRequest request,
    required String listingId,
  });

  Future<bool> additionalServiceInformationDataSource({
    required ServiceAdditionalInformationRequest request,
    required String listingId,
  });

  Future<FoodListingDetailsModel?> updateAdditionalFoodInformationDataSource({
    required FoodAdditionalInformationRequest request,
    required String listingId,
  });

  Future<ServiceListingDetailsModel?> updateAdditionalServiceInformationDataSource({
    required ServiceAdditionalInformationRequest request,
    required String listingId,
  });

  Future<FoodListingDetailsModel> fetchAdditionalFoodInformationDataSource({
    required String listingId,
  });

  Future<ServiceListingDetailsModel> fetchAdditionalServiceInformationDataSource({
    required String listingId,
  });

  Future<List<ServiceSlotModel>> saveServiceSlotsDataSource({
    required String listingId,
    required String date,
    required List<Map<String, String>> windows,
  });

  Future<List<DateTime>> fetchServiceAvailableDatesDataSource({
    required String listingId,
    required String fromDate,
    required String toDate,
  });
  Future<List<ServiceSlotModel>> getServiceAvailableSlotsDataSource({
    required String listingId,
    required String date,
  });
  Future<void> deleteServiceSlotsDataSource({required String listingId, required String date});

  Future<void> deleteListingImageDataSource({required String listingId, required String imageId});
}

class SellerListingRemoteDataSourceImpl implements SellerListingRemoteDatasource {
  SellerListingRemoteDataSourceImpl(this._apiClient);
  final ApiClient _apiClient;

  final List<SellerListingModel> _listings = List.of(MockData.sellerListings);
  final List<SellerListingImageModel> _listingImages = List.of(MockData.listingImages);

  @override
  Future<PageResponse<SellerListingModel>> fetchMyListingDataSource({
    required String sellerId,
  }) async {
    try {
      final queryParameters = {'sellerId': sellerId};
      final response = await _apiClient.get(ApiEndpoints.myListing, queryParameters: queryParameters);
      return PageResponse.fromJson(
        Map<String, dynamic>.from(response.data as Map),
        SellerListingModel.fromJson,
      );
    } catch (_) {
      return PageResponse<SellerListingModel>(
        content: _listings,
        totalElements: _listings.length,
        totalPages: 1,
        size: 50,
        page: 0,
        first: true,
        last: true,
      );
    }
  }

  @override
  Future<List<SellerListingImageModel>> getListingImagesDataSource(String listingId) async {
    try {
      final response = await _apiClient.get(ApiEndpoints.listingImages(listingId));
      final images = response.data as List<dynamic>? ?? const [];
      return images
          .whereType<Map>()
          .map((image) => SellerListingImageModel.fromJson(Map<String, dynamic>.from(image)))
          .toList()
        ..sort((a, b) => a.displayOrder.compareTo(b.displayOrder));
    } catch (_) {
      return _listingImages.where((img) => img.listingId == listingId).toList();
    }
  }

  @override
  Future<SellerListingModel?> createListingDataSource({
    required SellerListingBasicInfoRequest request,
  }) async {
    final payload = request.toJson();
    RequestLogger.logPost(
      endpoint: ApiEndpoints.listings,
      payload: payload,
      method: 'POST',
    );

    try {
      final response = await _apiClient.post(ApiEndpoints.listings, data: payload);
      return SellerListingModel.fromJson(response.data);
    } catch (_) {
      final newListing = SellerListingModel(
        id: 'list_${DateTime.now().millisecondsSinceEpoch}',
        sellerId: MockData.sellerId,
        categoryId: request.categoryId ?? 'cat_food',
        additionalCategoryIds: request.additionalCategoryIds ?? const [],
        listingType: request.listingType ?? 'FOOD',
        title: request.title ?? 'New Listing',
        description: request.description ?? '',
        basePrice: request.basePrice ?? 100.0,
        priceUnit: request.priceUnit ?? 'unit',
        isFree: request.isFree ?? false,
        quantityAvailable: request.quantityAvailable ?? 10,
        availabilityStatus: 'AVAILABLE',
        approvalStatus: 'DRAFT',
        moderationStatus: 'PENDING',
        sponsoredStatus: 'NONE',
        averageRating: 0.0,
        totalReviews: 0,
        tagNames: request.tagNames ?? const [],
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );
      _listings.insert(0, newListing);
      return newListing;
    }
  }

  @override
  Future<SellerListingImageModel> uploadSellerShopImagesDataSource(
    String listingId,
    XFile file,
  ) async {
    RequestLogger.logPost(
      endpoint: ApiEndpoints.listingImages(listingId),
      payload: {'listingId': listingId, 'fileName': file.name, 'path': file.path, 'displayOrder': 1},
      method: 'POST',
    );

    try {
      final form = FormData();
      form.files.add(MapEntry('file', await MultipartFile.fromFile(file.path, filename: file.name)));
      form.fields.add(const MapEntry('displayOrder', '1'));
      final response = await _apiClient.post(ApiEndpoints.listingImages(listingId), data: form);
      return SellerListingImageModel.fromJson(response.data);
    } catch (_) {
      final img = SellerListingImageModel(
        id: 'img_${DateTime.now().millisecondsSinceEpoch}',
        listingId: listingId,
        imageUrl: file.path,
        moderationStatus: 'APPROVED',
        displayOrder: 1,
        createdAt: DateTime.now(),
      );
      _listingImages.add(img);
      return img;
    }
  }

  @override
  Future<bool> additionalFoodInformationDataSource({
    required FoodAdditionalInformationRequest request,
    required String listingId,
  }) async {
    final payload = request.toJson();
    RequestLogger.logPost(
      endpoint: ApiEndpoints.listingFoodDetails(listingId),
      payload: payload,
      method: 'POST',
    );

    try {
      final response = await _apiClient.post(
        ApiEndpoints.listingFoodDetails(listingId),
        data: payload,
      );
      return response.statusCode == 200;
    } catch (_) {
      return true;
    }
  }

  @override
  Future<bool> additionalServiceInformationDataSource({
    required ServiceAdditionalInformationRequest request,
    required String listingId,
  }) async {
    final payload = request.toJson();
    RequestLogger.logPost(
      endpoint: ApiEndpoints.listingServiceDetails(listingId),
      payload: payload,
      method: 'POST',
    );

    try {
      final response = await _apiClient.post(
        ApiEndpoints.listingServiceDetails(listingId),
        data: payload,
      );
      return response.statusCode == 200;
    } catch (_) {
      return true;
    }
  }

  @override
  Future<SellerListingModel?> submitListingDataSource({required String listingId}) async {
    RequestLogger.logPost(
      endpoint: ApiEndpoints.submitListings(listingId),
      payload: {'listingId': listingId},
      method: 'POST',
    );

    try {
      final response = await _apiClient.post(ApiEndpoints.submitListings(listingId));
      return SellerListingModel.fromJson(response.data);
    } catch (_) {
      final index = _listings.indexWhere((l) => l.id == listingId);
      if (index != -1) {
        final updated = _listings[index].copyWith(approvalStatus: 'APPROVED');
        _listings[index] = SellerListingModel.fromEntity(updated);
        return _listings[index];
      }
      return _listings.first;
    }
  }

  @override
  Future<SellerListingModel?> updateSubmitListingDataSource({
    required String listingId,
    required SellerListingBasicInfoRequest request,
  }) async {
    final payload = request.toJson();
    try {
      final response = await _apiClient.patch(ApiEndpoints.listing(listingId), data: payload);
      return SellerListingModel.fromJson(response.data);
    } catch (_) {
      final index = _listings.indexWhere((l) => l.id == listingId);
      if (index != -1) {
        return _listings[index];
      }
      return _listings.first;
    }
  }

  @override
  Future<SellerListingModel> fetchListingByIdDataSource({required String listingID}) async {
    try {
      final response = await _apiClient.get(ApiEndpoints.listing(listingID));
      return SellerListingModel.fromJson(response.data);
    } catch (_) {
      return _listings.firstWhere(
        (l) => l.id == listingID,
        orElse: () => _listings.first,
      );
    }
  }

  @override
  Future<FoodListingDetailsModel> fetchAdditionalFoodInformationDataSource({
    required String listingId,
  }) async {
    try {
      final response = await _apiClient.get(ApiEndpoints.listingFoodDetails(listingId));
      return FoodListingDetailsModel.fromJson(response.data);
    } catch (_) {
      return MockData.foodDetails;
    }
  }

  @override
  Future<ServiceListingDetailsModel> fetchAdditionalServiceInformationDataSource({
    required String listingId,
  }) async {
    try {
      final response = await _apiClient.get(ApiEndpoints.listingServiceDetails(listingId));
      return ServiceListingDetailsModel.fromJson(response.data);
    } catch (_) {
      return MockData.serviceDetails;
    }
  }

  @override
  Future<FoodListingDetailsModel?> updateAdditionalFoodInformationDataSource({
    required FoodAdditionalInformationRequest request,
    required String listingId,
  }) async {
    try {
      final response = await _apiClient.patch(
        ApiEndpoints.listingFoodDetails(listingId),
        data: request.toJson(),
      );
      if (response.statusCode == 200) {
        return FoodListingDetailsModel.fromJson(response.data);
      }
      return null;
    } catch (_) {
      return MockData.foodDetails;
    }
  }

  @override
  Future<ServiceListingDetailsModel?> updateAdditionalServiceInformationDataSource({
    required ServiceAdditionalInformationRequest request,
    required String listingId,
  }) async {
    try {
      final response = await _apiClient.patch(
        ApiEndpoints.listingServiceDetails(listingId),
        data: request.toJson(),
      );
      if (response.statusCode == 200) {
        return ServiceListingDetailsModel.fromJson(response.data);
      }
      return null;
    } catch (_) {
      return MockData.serviceDetails;
    }
  }

  @override
  Future<List<ServiceSlotModel>> saveServiceSlotsDataSource({
    required String listingId,
    required String date,
    required List<Map<String, String>> windows,
  }) async {
    final endpoint = ApiEndpoints.serviceAvailability(listingId, date);
    final payload = {'windows': windows};
    try {
      final response = await _apiClient.put(endpoint, data: payload);
      final data = response.data as List<dynamic>;
      return data.map((item) => ServiceSlotModel.fromJson(Map<String, dynamic>.from(item))).toList();
    } catch (_) {
      return MockData.serviceSlots;
    }
  }

  @override
  Future<void> deleteServiceSlotsDataSource({
    required String listingId,
    required String date,
  }) async {
    try {
      await _apiClient.delete(ApiEndpoints.serviceAvailability(listingId, date));
    } catch (_) {}
  }

  @override
  Future<void> deleteListingImageDataSource({
    required String listingId,
    required String imageId,
  }) async {
    try {
      await _apiClient.delete(ApiEndpoints.listingImageById(listingId, imageId));
    } catch (_) {
      _listingImages.removeWhere((img) => img.id == imageId);
    }
  }

  @override
  Future<List<ServiceSlotModel>> getServiceAvailableSlotsDataSource({
    required String listingId,
    required String date,
  }) async {
    try {
      final response = await _apiClient.get(
        ApiEndpoints.serviceScheduleSlots(listingId),
        queryParameters: {'date': date},
      );
      final slots = response.data;
      if (slots is List) {
        return slots
            .whereType<Map>()
            .map((slot) => ServiceSlotModel.fromJson(Map<String, dynamic>.from(slot)))
            .where((slot) => slot.isAvailable)
            .toList();
      }
    } catch (_) {}
    return MockData.serviceSlots;
  }

  @override
  Future<List<DateTime>> fetchServiceAvailableDatesDataSource({
    required String listingId,
    required String fromDate,
    required String toDate,
  }) async {
    try {
      final response = await _apiClient.get(
        ApiEndpoints.serviceScheduleDates(listingId),
        queryParameters: {'from': fromDate, 'to': toDate},
      );
      final dates = response.data;
      if (dates is List) {
        return dates
            .whereType<String>()
            .map(DateTime.tryParse)
            .whereType<DateTime>()
            .map((date) => DateTime(date.year, date.month, date.day))
            .toList();
      }
    } catch (_) {}
    return [
      DateTime.now(),
      DateTime.now().add(const Duration(days: 1)),
      DateTime.now().add(const Duration(days: 2)),
    ];
  }
}
