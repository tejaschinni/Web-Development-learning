import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:society_seva/core/mock/mock_data.dart';
import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/core/network/request_logger.dart';
import 'package:society_seva/features/seller/data/models/certificate_model.dart';
import 'package:society_seva/features/seller/data/models/kyc_document_model.dart';
import 'package:society_seva/features/seller/data/models/seller_availabledays_model.dart';
import 'package:society_seva/features/seller/data/models/seller_image_model.dart';
import 'package:society_seva/features/seller/data/models/seller_profile_model.dart';
import 'package:society_seva/features/seller/data/models/request/seller_profile_request.dart';

abstract class SellerOnboardingRemoteDataSource {
  Future<SellerProfileModel?> createAndSaveAsDraftDataSource({
    required SellerProfileRequest request,
  });
  Future<SellerProfileModel?> submitDartDataSource({required String sellerId});
  Future<void> uploadSellerShopImagesDataSource(String sellerId, XFile file);
  Future<List<SellerImageModel>> fetchSellerUploadedImagesDataSource(String sellerId);
  Future<SellerProfileModel?> mySellerProfileDataSource();
  Future<SellerProfileModel?> fetchSellerProfileByIDDataSource(String sellerID);
  Future<SellerProfileModel?> updateProfileDataSource({
    required SellerProfileRequest request,
    required String sellerID,
  });
  Future<void> deleteUploadedSellerImagesDataSource({
    required String sellerID,
    required String imageId,
  });

  Future<CertificateModel?> uploadCertificateDataSource({
    required String sellerId,
    required XFile file,
    required String certificateName,
    required String certificateType,
    required DateTime issueDate,
    required bool hasExpiry,
    required String issueAuthority,
    required String certificateNumber,
    DateTime? expiryDate,
  });

  Future<List<CertificateModel>> fetchCertificatesDataSource(String sellerId);

  Future<List<KycDocumentModel>> fetchKycDocumentDataSource(String sellerId);

  Future<bool> uploadKYCDocumentDataSource({
    required XFile file,
    required String documentType,
    required String documentNumber,
    required String sellerId,
  });

  Future<String> downloadKycDocumentFileDataSource({
    required String sellerId,
    required String documentFileUrl,
  });
  Future<AvailableDaysModel> fetchSellerAvailableDaysDataSource({required String sellerID});

  Future<AvailableDaysModel> updateSellerAvailableDaysDataSource({
    required String sellerID,
    required Map<String, dynamic> data,
  });
}

class SellerOnboardingRemoteDataSourceImpl implements SellerOnboardingRemoteDataSource {
  SellerOnboardingRemoteDataSourceImpl({required this.apiClient});

  final ApiClient apiClient;

  SellerProfileModel _sellerProfile = MockData.approvedSellerProfile;
  final List<SellerImageModel> _sellerImages = List.of(MockData.sellerImages);
  final List<CertificateModel> _certificates = List.of(MockData.certificates);
  final List<KycDocumentModel> _kycDocuments = List.of(MockData.kycDocuments);
  AvailableDaysModel _availableDays = MockData.sellerAvailableDays;

  @override
  Future<SellerProfileModel?> createAndSaveAsDraftDataSource({
    required SellerProfileRequest request,
  }) async {
    RequestLogger.logPost(
      endpoint: ApiEndpoints.createSellerProfile,
      payload: request.toJson(),
      method: 'POST',
    );

    try {
      final response = await apiClient.post(
        ApiEndpoints.createSellerProfile,
        data: request.toJson(),
      );
      return SellerProfileModel.fromJson(response.data);
    } catch (_) {
      _sellerProfile = MockData.approvedSellerProfile.copyWith(
        displayName: request.displayName.isNotEmpty ? request.displayName : _sellerProfile.displayName,
        businessName: request.businessName ?? _sellerProfile.businessName,
        bio: request.bio ?? _sellerProfile.bio,
      );
      return _sellerProfile;
    }
  }

  @override
  Future<void> deleteUploadedSellerImagesDataSource({
    required String sellerID,
    required String imageId,
  }) async {
    try {
      await apiClient.delete(ApiEndpoints.deleteImages(sellerID, imageId));
    } catch (_) {
      _sellerImages.removeWhere((img) => img.id == imageId);
    }
  }

  @override
  Future<SellerProfileModel?> fetchSellerProfileByIDDataSource(String sellerID) async {
    try {
      final response = await apiClient.get(ApiEndpoints.sellerByID(sellerID));
      return SellerProfileModel.fromJson(response.data);
    } catch (_) {
      return _sellerProfile;
    }
  }

  @override
  Future<List<SellerImageModel>> fetchSellerUploadedImagesDataSource(String sellerId) async {
    try {
      final response = await apiClient.get(ApiEndpoints.fetchSellerImages(sellerId));
      final List<dynamic> data = response.data as List<dynamic>;
      return data.map((item) => SellerImageModel.fromJson(item as Map<String, dynamic>)).toList();
    } catch (_) {
      return _sellerImages;
    }
  }

  @override
  Future<SellerProfileModel?> mySellerProfileDataSource() async {
    try {
      final response = await apiClient.get(ApiEndpoints.sellerProfile);
      return SellerProfileModel.fromJson(response.data);
    } catch (_) {
      return _sellerProfile;
    }
  }

  @override
  Future<SellerProfileModel?> submitDartDataSource({required String sellerId}) async {
    RequestLogger.logPost(
      endpoint: ApiEndpoints.submitSellerProfile(sellerId),
      payload: {'sellerId': sellerId},
      method: 'POST',
    );

    try {
      final response = await apiClient.post(ApiEndpoints.submitSellerProfile(sellerId));
      return SellerProfileModel.fromJson(response.data);
    } catch (_) {
      _sellerProfile = _sellerProfile.copyWith(approvalStatus: 'APPROVED');
      return _sellerProfile;
    }
  }

  @override
  Future<SellerProfileModel?> updateProfileDataSource({
    required SellerProfileRequest request,
    required String sellerID,
  }) async {
    try {
      final response = await apiClient.patch(
        '${ApiEndpoints.createSellerProfile}/$sellerID',
        data: request.toJson(),
      );
      return SellerProfileModel.fromJson(response.data);
    } catch (_) {
      _sellerProfile = _sellerProfile.copyWith(
        businessName: request.businessName ?? _sellerProfile.businessName,
        bio: request.bio ?? _sellerProfile.bio,
      );
      return _sellerProfile;
    }
  }

  @override
  Future<void> uploadSellerShopImagesDataSource(String sellerId, XFile file) async {
    RequestLogger.logPost(
      endpoint: ApiEndpoints.fetchSellerImages(sellerId),
      payload: {'fileName': file.name, 'path': file.path},
      method: 'POST',
    );

    try {
      final form = FormData();
      form.files.add(MapEntry('file', await MultipartFile.fromFile(file.path, filename: file.name)));
      await apiClient.post(ApiEndpoints.fetchSellerImages(sellerId), data: form);
    } catch (_) {
      _sellerImages.add(
        SellerImageModel(
          id: 'img_${DateTime.now().millisecondsSinceEpoch}',
          sellerId: sellerId,
          imageUrl: file.path,
          moderationStatus: 'APPROVED',
          displayOrder: _sellerImages.length + 1,
          createdAt: DateTime.now(),
          updatedAt: DateTime.now(),
        ),
      );
    }
  }

  @override
  Future<List<CertificateModel>> fetchCertificatesDataSource(String sellerId) async {
    try {
      final response = await apiClient.get(ApiEndpoints.certificate(sellerId));
      final List<dynamic> data = response.data as List<dynamic>;
      return data.map((item) => CertificateModel.fromJson(item as Map<String, dynamic>)).toList();
    } catch (_) {
      return _certificates;
    }
  }

  @override
  Future<CertificateModel?> uploadCertificateDataSource({
    required String sellerId,
    required XFile file,
    required String certificateName,
    required String certificateType,
    required DateTime issueDate,
    required bool hasExpiry,
    required String issueAuthority,
    required String certificateNumber,
    DateTime? expiryDate,
  }) async {
    RequestLogger.logPost(
      endpoint: ApiEndpoints.certificate(sellerId),
      payload: {
        'sellerId': sellerId,
        'certificateName': certificateName,
        'certificateType': certificateType,
        'certificateNumber': certificateNumber,
        'issueAuthority': issueAuthority,
        'issueDate': issueDate.toIso8601String(),
        'hasExpiry': hasExpiry,
        'expiryDate': expiryDate?.toIso8601String(),
        'fileName': file.name,
      },
      method: 'POST',
    );

    try {
      final dateFormate = DateFormat('yyyy-MM-dd');
      final formData = FormData.fromMap({
        'file': await MultipartFile.fromFile(file.path, filename: file.name),
        'certificateType': certificateType,
        'certificateName': certificateName,
        'certificateNumber': certificateNumber,
        'issuingAuthority': issueAuthority,
        'issueDate': dateFormate.format(issueDate),
        'expiryDate': hasExpiry && expiryDate != null ? dateFormate.format(expiryDate) : null,
      });

      final response = await apiClient.post(ApiEndpoints.certificate(sellerId), data: formData);
      if (response.statusCode == 200) {
        return CertificateModel.fromJson(response.data);
      }
    } catch (_) {
      // Fallback to mock model
    }

    final newCert = CertificateModel(
      id: 'cert_${DateTime.now().millisecondsSinceEpoch}',
      sellerId: sellerId,
      certificateType: certificateType,
      certificateName: certificateName,
      issuingAuthority: issueAuthority,
      certificateFileUrl: file.path,
      verificationStatus: 'VERIFIED',
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
    _certificates.add(newCert);
    return newCert;
  }

  @override
  Future<List<KycDocumentModel>> fetchKycDocumentDataSource(String sellerId) async {
    try {
      final response = await apiClient.get(ApiEndpoints.fetchKycDocument(sellerId));
      final List<dynamic> data = response.data as List<dynamic>;
      return data.map((item) => KycDocumentModel.fromJson(item as Map<String, dynamic>)).toList();
    } catch (_) {
      return _kycDocuments;
    }
  }

  @override
  Future<bool> uploadKYCDocumentDataSource({
    required XFile file,
    required String documentType,
    required String documentNumber,
    required String sellerId,
  }) async {
    RequestLogger.logPost(
      endpoint: ApiEndpoints.uploadKycDocument(sellerId),
      payload: {
        'sellerId': sellerId,
        'documentType': documentType,
        'documentNumber': documentNumber,
        'fileName': file.name,
      },
      method: 'POST',
    );

    try {
      final formData = FormData.fromMap({
        'file': await MultipartFile.fromFile(file.path, filename: file.name),
        'documentType': documentType,
        'documentNumber': documentNumber,
      });

      final response = await apiClient.post(
        ApiEndpoints.uploadKycDocument(sellerId),
        data: formData,
      );
      if (response.statusCode == 200) {
        return true;
      }
    } catch (_) {
      // Fallback mock success
    }

    _kycDocuments.add(
      KycDocumentModel(
        id: 'kyc_${DateTime.now().millisecondsSinceEpoch}',
        sellerId: sellerId,
        documentType: documentType,
        documentFileUrl: file.path,
        verificationStatus: 'VERIFIED',
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      ),
    );
    return true;
  }

  @override
  Future<String> downloadKycDocumentFileDataSource({
    required String sellerId,
    required String documentFileUrl,
  }) async {
    try {
      final response = await apiClient.get(ApiEndpoints.kycDocumentFile(sellerId, documentFileUrl));
      return response.data as String;
    } catch (_) {
      return documentFileUrl;
    }
  }

  @override
  Future<AvailableDaysModel> fetchSellerAvailableDaysDataSource({required String sellerID}) async {
    try {
      final response = await apiClient.get(ApiEndpoints.selleravailableDays(sellerID));
      return AvailableDaysModel.fromJson(response.data);
    } catch (_) {
      return _availableDays;
    }
  }

  @override
  Future<AvailableDaysModel> updateSellerAvailableDaysDataSource({
    required String sellerID,
    required Map<String, dynamic> data,
  }) async {
    try {
      final response = await apiClient.patch(
        ApiEndpoints.selleravailableDays(sellerID),
        data: jsonEncode(data),
      );
      return AvailableDaysModel.fromJson(response.data);
    } catch (_) {
      _availableDays = AvailableDaysModel.fromJson({
        'sellerId': sellerID,
        'daysType': data['daysType'] ?? _availableDays.daysType,
        'availableDays': data['availableDays'] ?? _availableDays.availableDays,
        'fromTime': data['fromTime'] ?? _availableDays.fromTime,
        'toTime': data['toTime'] ?? _availableDays.toTime,
      });
      return _availableDays;
    }
  }
}
