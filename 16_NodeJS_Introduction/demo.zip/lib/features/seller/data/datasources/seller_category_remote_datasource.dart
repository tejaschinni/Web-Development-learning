
import 'package:society_seva/core/mock/mock_data.dart';
import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/seller/data/models/seller_category_model.dart';
import 'package:society_seva/features/shop/data/models/shop_category_model.dart';

abstract class SellerCategoryRemoteDatasource {
  Future<PageResponse<CategoriesModel>> fetchCategoriesDataSource({
    String? categoryType,
    String? parentCategoryId,
    bool? rootsOnly,
    String? search,
  });

  Future<List<ShopCategoryModel>> fetchCategoriesTreeDataSource({String? categoryType});
}

class SellerCategoryRemoteDatasourceImpl implements SellerCategoryRemoteDatasource {
  SellerCategoryRemoteDatasourceImpl(this._apiClient);
  final ApiClient _apiClient;

  @override
  Future<PageResponse<CategoriesModel>> fetchCategoriesDataSource({
    String? categoryType,
    String? parentCategoryId,
    bool? rootsOnly,
    String? search,
  }) async {
    try {
      final response = await _apiClient.get(
        ApiEndpoints.allCategory,
        queryParameters: {
          'isActive': true,
          'categoryType': categoryType,
          'parentCategoryId': parentCategoryId,
          'rootsOnly': rootsOnly,
          'search': search,
        },
      );
      return PageResponse.fromJson(
        Map<String, dynamic>.from(response.data as Map),
        CategoriesModel.fromJson,
      );
    } catch (_) {
      final list = MockData.sellerCategories.where((c) {
        if (categoryType != null && c.categoryType != categoryType) return false;
        if (search != null && search.isNotEmpty) {
          return c.name.toLowerCase().contains(search.toLowerCase());
        }
        return true;
      }).toList();

      return PageResponse<CategoriesModel>(
        content: list,
        totalElements: list.length,
        totalPages: 1,
        size: 50,
        page: 0,
        first: true,
        last: true,
      );
    }
  }

  @override
  Future<List<ShopCategoryModel>> fetchCategoriesTreeDataSource({String? categoryType}) async {
    try {
      final response = await _apiClient.get(
        ApiEndpoints.categoryTree,
        queryParameters: {'isActive': true, 'categoryType': categoryType},
      );

      final data = response.data;
      if (data is List) {
        return data
            .whereType<Map>()
            .map((item) => ShopCategoryModel.fromJson(Map<String, dynamic>.from(item)))
            .toList(growable: false);
      }
    } catch (_) {}
    return MockData.shopCategoryTree;
  }
}
