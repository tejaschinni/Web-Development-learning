import 'dart:convert';

import 'package:society_seva/features/seller/domain/entities/order_status_history_entity.dart';

OrderStatusHistoryModel orderHistoryModelFromJson(String str) =>
    OrderStatusHistoryModel.fromJson(json.decode(str));

String orderHistoryModelToJson(OrderStatusHistoryModel data) => json.encode(data.toJson());

class OrderStatusHistoryModel extends OrderStatusHistoryEntity {
  const OrderStatusHistoryModel({
    required super.createdAt,
    required super.id,
    required super.newStatus,
    required super.note,
    required super.oldStatus,
    required super.orderId,
  });

  factory OrderStatusHistoryModel.fromJson(Map<String, dynamic> json) {
    return OrderStatusHistoryModel(
      createdAt: DateTime.parse(json['createdAt'] as String),
      id: json['id'] as String,
      newStatus: json['newStatus'] as String,
      note: json['note'] ?? '',
      oldStatus: json['oldStatus'] ?? '',
      orderId: json['orderId'] as String,
    );
  }

  factory OrderStatusHistoryModel.fromEntity(OrderStatusHistoryEntity entity) {
    return OrderStatusHistoryModel(
      createdAt: entity.createdAt,
      id: entity.id,
      newStatus: entity.newStatus,
      note: entity.note,
      oldStatus: entity.oldStatus,
      orderId: entity.orderId,
    );
  }

  OrderStatusHistoryEntity toEntity() {
    return OrderStatusHistoryEntity(
      createdAt: createdAt,
      id: id,
      newStatus: newStatus,
      note: note,
      oldStatus: oldStatus,
      orderId: orderId,
    );
  }

  Map<String, dynamic> toJson() => {
    'createdAt': createdAt.toIso8601String(),
    'id': id,
    'newStatus': newStatus,
    'note': note,
    'oldStatus': oldStatus,
    'orderId': orderId,
  };

  OrderStatusHistoryModel copyWith({
    DateTime? createdAt,
    String? id,
    String? newStatus,
    String? note,
    String? oldStatus,
    String? orderId,
  }) {
    return OrderStatusHistoryModel(
      createdAt: createdAt ?? this.createdAt,
      id: id ?? this.id,
      newStatus: newStatus ?? this.newStatus,
      note: note ?? this.note,
      oldStatus: oldStatus ?? this.oldStatus,
      orderId: orderId ?? this.orderId,
    );
  }
}
