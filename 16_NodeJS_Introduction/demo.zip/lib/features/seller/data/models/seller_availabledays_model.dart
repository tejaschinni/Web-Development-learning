import 'package:society_seva/features/seller/domain/entities/seller_availabledays_entity.dart';

class AvailableDaysModel extends AvailableDaysEntity {
  const AvailableDaysModel({
    required super.sellerId,
    required super.daysType,
    required super.availableDays,
    required super.fromTime,
    required super.toTime,
  });

  factory AvailableDaysModel.fromJson(Map<String, dynamic> json) {
    return AvailableDaysModel(
      sellerId: json['sellerId'] as String,
      daysType: json['daysType'] as String,
      availableDays: List<String>.from(json['availableDays'] ?? []),
      fromTime: json['fromTime'] as String,
      toTime: json['toTime'] as String,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'sellerId': sellerId,
      'daysType': daysType,
      'availableDays': availableDays,
      'fromTime': fromTime,
      'toTime': toTime,
    };
  }

  factory AvailableDaysModel.fromEntity(AvailableDaysEntity entity) {
    return AvailableDaysModel(
      sellerId: entity.sellerId,
      daysType: entity.daysType,
      availableDays: entity.availableDays,
      fromTime: entity.fromTime,
      toTime: entity.toTime,
    );
  }

  AvailableDaysEntity toEntity() => AvailableDaysEntity(
    sellerId: sellerId,
    daysType: daysType,
    availableDays: availableDays,
    fromTime: fromTime,
    toTime: toTime,
  );

  @override
  AvailableDaysModel copyWith({
    String? sellerId,
    String? daysType,
    List<String>? availableDays,
    String? fromTime,
    String? toTime,
  }) {
    return AvailableDaysModel(
      sellerId: sellerId ?? this.sellerId,
      daysType: daysType ?? this.daysType,
      availableDays: availableDays ?? this.availableDays,
      fromTime: fromTime ?? this.fromTime,
      toTime: toTime ?? this.toTime,
    );
  }
}
