class FoodAdditionalInformationRequest {
  final String? preparationTime;
  final String? expiryTime;
  final String? ingredients;
  final String? allergens;
  final String? foodType;
  final int? spiceLevel;
  final String? spiceLevelText;
  final String? freshnessDeclaration;
  final bool? isFrozenItem;
  final String? storageInstruction;
  final String? packagingDetails;
  final String? fssaiRequired;
  final String? fssaiCertificateId;
  final List<ServingSizeRequest>? servingSizes;

  const FoodAdditionalInformationRequest({
    this.preparationTime,
    this.expiryTime,
    this.ingredients,
    this.allergens,
    this.foodType,
    this.spiceLevel,
    this.spiceLevelText,
    this.freshnessDeclaration,
    this.isFrozenItem,
    this.storageInstruction,
    this.packagingDetails,
    this.fssaiRequired,
    this.fssaiCertificateId,
    this.servingSizes,
  });

  Map<String, dynamic> toJson() {
    return _removeEmptyValues({
      'preparationTime': int.parse(preparationTime ?? '0'),
      'expiryTime': expiryTime,
      'ingredients': ingredients,
      'allergens': allergens,
      'foodType': foodType,
      'spiceLevel': spiceLevel,
      'spiceLevelText': spiceLevelText,
      'freshnessDeclaration': freshnessDeclaration,
      'isFrozenItem': isFrozenItem,
      'storageInstruction': storageInstruction,
      'packagingDetails': packagingDetails,
      'fssaiRequired': fssaiRequired == "true" ? true : false,
      'fssaiCertificateId': fssaiCertificateId,
      'servingSizes': servingSizes?.map((item) => item.toJson()).toList(),
    });
  }
}

class ServingSizeRequest {
  final num? sizeValue;
  final String? sizeUnit;
  final String? description;
  final num? price;
  final int? quantityAvailable;
  final bool? isAvailable;

  const ServingSizeRequest({
    this.sizeValue,
    this.sizeUnit,
    this.description,
    this.price,
    this.quantityAvailable,
    this.isAvailable,
  });

  Map<String, dynamic> toJson() {
    return _removeEmptyValues({
      'sizeValue': sizeValue,
      'sizeUnit': sizeUnit,
      'description': description,
      'price': price,
      'quantityAvailable': quantityAvailable,
      'isAvailable': isAvailable,
    });
  }
}

Map<String, dynamic> _removeEmptyValues(Map<String, dynamic> json) {
  json.removeWhere((key, value) {
    if (value == null) return true;

    if (value is String) {
      final normalized = value.trim().toLowerCase();
      return normalized.isEmpty || normalized == 'null';
    }

    if (value is List) {
      return value.isEmpty;
    }

    if (value is Map) {
      return value.isEmpty;
    }

    return false;
  });

  return json;
}
