import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/core/network/api_exception.dart';
import 'package:society_seva/features/shop/data/models/shop_cart_seller_group.dart';
import 'package:society_seva/features/shop/domain/entities/shop_cart.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_cart_provider.dart';
import 'package:society_seva/features/shop/presentation/widgets/cart/price_row.dart';
import 'package:society_seva/features/shop/presentation/widgets/cart/seller_cart_section.dart';
import 'package:society_seva/features/shop/presentation/widgets/cart/shop_empty_cart_view.dart';

class ShopCartScreen extends ConsumerStatefulWidget {
  const ShopCartScreen({super.key});

  @override
  ConsumerState<ShopCartScreen> createState() => _ShopCartScreenState();
}

class _ShopCartScreenState extends ConsumerState<ShopCartScreen> {
  ShopCart? get _cart => ref.read(shopCartProvider).valueOrNull;

  List<CartSellerGroup> get _groups {
    final cart = _cart;
    return cart == null || cart.items.isEmpty ? [] : [CartSellerGroup.fromCart(cart)];
  }

  double get _subtotal => _cart?.subtotal ?? 0;

  int get _itemCount => _cart?.itemCount ?? 0;

  Future<void> _changeQuantity(String sellerId, String itemId, int delta) async {
    final cart = _cart;
    if (cart == null || cart.sellerId != sellerId) return;
    final item = cart.items.where((item) => item.id == itemId).firstOrNull;
    if (item == null) return;

    try {
      final quantity = item.quantity + delta;
      if (quantity < 1) {
        await ref.read(shopCartProvider.notifier).removeItem(itemId);
      } else {
        await ref
            .read(shopCartProvider.notifier)
            .updateQuantity(itemId: itemId, quantity: quantity);
      }
    } catch (error) {
      _showActionError(error);
    }
  }

  Future<void> _removeItem(String sellerId, String itemId) async {
    if (_cart?.sellerId != sellerId) return;
    try {
      await ref.read(shopCartProvider.notifier).removeItem(itemId);
    } catch (error) {
      _showActionError(error);
    }
  }

  Future<void> _clearCart() async {
    if (_cart == null) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete this cart?'),
        content: const Text('All items in this seller cart will be removed.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete')),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    try {
      await ref.read(shopCartProvider.notifier).clearCart();
    } catch (error) {
      _showActionError(error);
    }
  }

  void _showActionError(Object error) {
    if (!mounted) return;
    final message = error is ApiException ? error.message : 'Unable to update cart';
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  void _proceedToCheckout() {
    final cart = _cart;
    if (cart == null || cart.items.isEmpty) return;
    context.push('/shop/checkout', extra: cart);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final textTheme = GoogleFonts.hindTextTheme(theme.textTheme);
    final cartAsync = ref.watch(shopCartProvider);

    return Theme(
      data: theme.copyWith(textTheme: textTheme),
      child: Scaffold(
        backgroundColor: theme.colorScheme.surface,
        appBar: _buildAppBar(context),
        body: cartAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (error, stackTrace) => Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('Unable to load your cart'),
                TextButton.icon(
                  onPressed: () => ref.read(shopCartProvider.notifier).refresh(),
                  icon: const Icon(Icons.refresh),
                  label: const Text('Try again'),
                ),
              ],
            ),
          ),
          data: (cart) => cart == null || cart.items.isEmpty
              ? const EmptyCartView()
              : SafeArea(
                  child: Column(
                    children: [
                      Expanded(
                        child: CustomScrollView(
                          physics: const BouncingScrollPhysics(),
                          slivers: [
                            SliverToBoxAdapter(child: _buildHeader(context)),
                            SliverPadding(
                              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                              sliver: SliverList.separated(
                                itemCount: _groups.length,
                                separatorBuilder: (_, _) => const Gap(16),
                                itemBuilder: (context, index) {
                                  final group = _groups[index];
                                  return SellerCartSection(
                                    group: group,
                                    onIncrease: (itemId) =>
                                        _changeQuantity(group.sellerId, itemId, 1),
                                    onDecrease: (itemId) =>
                                        _changeQuantity(group.sellerId, itemId, -1),
                                    onRemove: (itemId) => _removeItem(group.sellerId, itemId),
                                  );
                                },
                              ),
                            ),
                            SliverToBoxAdapter(child: _buildServicesInfo(context)),
                            SliverToBoxAdapter(child: _buildPriceBreakdown(context)),
                            const SliverToBoxAdapter(child: Gap(24)),
                          ],
                        ),
                      ),
                      _buildBottomBar(context),
                    ],
                  ),
                ),
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context) {
    final theme = Theme.of(context);

    return AppBar(
      elevation: 0,
      scrolledUnderElevation: 0,
      backgroundColor: theme.colorScheme.surface,
      leading: IconButton(
        onPressed: () => Navigator.of(context).maybePop(),
        icon: HugeIcon(
          icon: HugeIcons.strokeRoundedArrowLeft01,
          size: 24,
          color: theme.colorScheme.onSurface,
        ),
      ),
      titleSpacing: 0,
      title: Text(
        'Cart',
        style: GoogleFonts.hind(
          fontSize: 22,
          fontWeight: FontWeight.w700,
          color: theme.colorScheme.onSurface,
        ),
      ),
      actions: [
        if (_itemCount > 0)
          IconButton(
            tooltip: 'Delete cart',
            onPressed: _clearCart,
            icon: const HugeIcon(icon: HugeIcons.strokeRoundedDelete02, size: 20),
          ),
        if (_itemCount > 0)
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Center(
              child: Text(
                '$_itemCount ${_itemCount == 1 ? 'item' : 'items'}',
                style: GoogleFonts.hind(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildHeader(BuildContext context) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: theme.colorScheme.primaryContainer.withValues(alpha: 0.38),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            HugeIcon(
              icon: HugeIcons.strokeRoundedShoppingCart02,
              size: 21,
              color: theme.colorScheme.primary,
            ),
            const Gap(10),
            Expanded(
              child: Text(
                'Your items are grouped by seller. '
                'At checkout, they will be placed as separate seller orders '
                'under one checkout.',
                style: GoogleFonts.hind(
                  fontSize: 13,
                  height: 1.4,
                  fontWeight: FontWeight.w500,
                  color: theme.colorScheme.onSurface,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildServicesInfo(BuildContext context) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: theme.colorScheme.surfaceContainerLow,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: theme.colorScheme.outlineVariant),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            HugeIcon(
              icon: HugeIcons.strokeRoundedInformationCircle,
              size: 20,
              color: theme.colorScheme.onSurfaceVariant,
            ),
            const Gap(10),
            Expanded(
              child: Text(
                'Services are booked separately and do not appear in your cart.',
                style: GoogleFonts.hind(
                  fontSize: 13,
                  height: 1.4,
                  fontWeight: FontWeight.w500,
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPriceBreakdown(BuildContext context) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: theme.colorScheme.surfaceContainerLow,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: theme.colorScheme.outlineVariant),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Bill summary',
              style: GoogleFonts.hind(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: theme.colorScheme.onSurface,
              ),
            ),
            const Gap(14),
            PriceRow(label: 'Item subtotal', value: _formatPrice(_subtotal)),
            const Padding(padding: EdgeInsets.symmetric(vertical: 14), child: Divider(height: 1)),
            PriceRow(label: 'Total', value: _formatPrice(_subtotal), isTotal: true),
          ],
        ),
      ),
    );
  }

  Widget _buildBottomBar(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        border: Border(top: BorderSide(color: theme.colorScheme.outlineVariant)),
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Total',
                    style: GoogleFonts.hind(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                  Text(
                    _formatPrice(_subtotal),
                    style: GoogleFonts.hind(
                      fontSize: 21,
                      fontWeight: FontWeight.w800,
                      color: theme.colorScheme.onSurface,
                    ),
                  ),
                ],
              ),
            ),
            const Gap(16),
            FilledButton(
              onPressed: _proceedToCheckout,
              style: FilledButton.styleFrom(
                minimumSize: const Size(0, 52),
                padding: const EdgeInsets.symmetric(horizontal: 20),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Proceed to checkout',
                    style: GoogleFonts.hind(fontSize: 15, fontWeight: FontWeight.w700),
                  ),
                  const Gap(8),
                  HugeIcon(
                    icon: HugeIcons.strokeRoundedArrowRight01,
                    size: 19,
                    color: theme.colorScheme.onPrimary,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _formatPrice(double value) {
    return '₹${value.toStringAsFixed(value % 1 == 0 ? 0 : 2)}';
  }
}
