import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:go_router/go_router.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/shop/domain/entities/shop_category.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing.dart';
import 'package:society_seva/features/shop/domain/enums/shop_category_type.dart';
import 'package:society_seva/features/shop/data/models/shop_checkout_models.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_cart_provider.dart';
import 'package:society_seva/features/shop/presentation/screens/shop_order_tracking_screen.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_category_provider.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_listing_provider.dart';
import 'package:society_seva/features/shop/presentation/widgets/category/shop_category_list_shimmer.dart';
import 'package:society_seva/features/shop/presentation/widgets/category/shop_category_load_error.dart';
import 'package:society_seva/features/shop/presentation/widgets/listing/shop_listing_card.dart';
import 'package:society_seva/features/shop/presentation/widgets/listing/shop_popular_listings_shimmer.dart';
import 'package:society_seva/features/shop/presentation/widgets/shop_header.dart';

final sevaNavProvider = StateProvider<int>((_) => 0);
final sevaFavsProvider = StateProvider<Set<String>>((_) => {});

const _u = 'https://images.unsplash.com/';
const _orange = Color(0xFFF26A1B);
const _green = Color(0xFF2E9B3E);
const _blue = Color(0xFF3B82F6);
const _forest = Color(0xFF0E5A34);

class SevaHomeScreen extends ConsumerWidget {
  const SevaHomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final activeOrders =
        (ref.watch(shopMyOrdersProvider).valueOrNull ?? const <ShopOrderResult>[])
            .where((order) => order.isActive)
            .toList()
          ..sort((first, second) {
            final firstCreated = DateTime.tryParse(first.createdAt ?? '') ?? DateTime(0);
            final secondCreated = DateTime.tryParse(second.createdAt ?? '') ?? DateTime(0);
            return secondCreated.compareTo(firstCreated);
          });

    return Scaffold(
      backgroundColor: const Color(0xFFFBFCFA),
      // bottomNavigationBar: const _SevaNav(),
      body: SafeArea(
        bottom: false,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Gap(2),
              ShopHeader(onCartTap: () => context.push('/shop/cart')),
              if (activeOrders.isNotEmpty) ...[
                Gap(12),
                _ActiveOrderBanner(order: activeOrders.first),
              ],
              Gap(12),
              SearchBar(onTap: () => context.push('/shop/search')),
              Gap(14),
              _IntentCards(),
              SectionTitle(
                title: 'Top Categories',
                onSeeAll: () {
                  context.push('/shop/categories' /* extra: societyId */);
                },
              ),
              Categories(
                onCategoryTap: (category) {
                  final listingType = category.categoryType == ShopCategoryType.service
                      ? 'service'
                      : 'product';

                  context.push(
                    '/shop/$listingType/category/${category.id}?name=${Uri.encodeComponent(category.name)}',
                    /* extra: societyId, */
                  );
                },
              ),
              Gap(16),
              _Banner(),
              SectionTitle(
                title: 'Popular near you',
                onSeeAll: () {
                  // TODO: Navigate to popular listing.
                  context.push('/shop/listings' /*, extra: societyId */);
                },
              ),
              Popular(),
              SectionTitle(title: 'Services near you'),
              Services(),
              SectionTitle(title: 'Recent needs from your community'),
              _Needs(),
            ],
          ),
        ),
      ),
    );
  }
}

class _ActiveOrderBanner extends ConsumerWidget {
  const _ActiveOrderBanner({required this.order});

  final ShopOrderResult order;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final firstItem = order.items.isEmpty ? null : order.items.first;
    final sellerIdShort = order.sellerId.length > 8
        ? order.sellerId.substring(0, 8)
        : order.sellerId;
    final sellerProfile = ref.watch(sellerProfileByIdProvider(order.sellerId)).valueOrNull;
    final sellerName = sellerProfile?.displayName.trim().isNotEmpty == true
        ? sellerProfile!.displayName.trim()
        : sellerProfile?.businessName?.trim().isNotEmpty == true
        ? sellerProfile!.businessName!.trim()
        : order.sellerName?.trim().isNotEmpty == true
        ? order.sellerName!.trim()
        : 'Seller $sellerIdShort';

    return Material(
      color: theme.colorScheme.primaryContainer.withValues(alpha: 0.58),
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: () =>
            context.push('/shop/orders/${order.id}', extra: ShopOrderTrackingData.fromOrder(order)),
        borderRadius: BorderRadius.circular(14),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              HugeIcon(
                icon: HugeIcons.strokeRoundedDeliveryTruck01,
                size: 24,
                color: theme.colorScheme.primary,
              ),
              const Gap(11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Order in progress · ${order.statusLabel}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: AppTheme.display(13, c: theme.colorScheme.onSurface),
                    ),
                    const Gap(2),
                    Text(
                      firstItem == null ? sellerName : '${firstItem.title} · $sellerName',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: AppTheme.hind(12, c: theme.colorScheme.onSurfaceVariant),
                    ),
                  ],
                ),
              ),
              const Gap(8),
              HugeIcon(
                icon: HugeIcons.strokeRoundedArrowRight01,
                size: 18,
                color: theme.colorScheme.primary,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ───────────── Top bar & search ─────────────
class _TopBar extends StatelessWidget {
  const _TopBar();
  @override
  Widget build(BuildContext context) => Row(
    children: [
      Image.asset(
        'assets/images/logo/h-logo.png',
        fit: BoxFit.scaleDown,
        height: 35,
        alignment: Alignment.centerLeft,
      ),
      const Spacer(),
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: const Color(0xFFE5F2E7),
          borderRadius: BorderRadius.circular(18),
        ),
        child: Row(
          children: [
            AppTheme.hi(HugeIcons.strokeRoundedLocation01, c: _forest, s: 24),
            const Gap(8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Gera World of Joy', style: AppTheme.display(13, c: _forest)),
                Row(
                  children: [
                    Text('Kharadi, Pune', style: AppTheme.hind(13, c: AppColors.muted)),
                    AppTheme.hi(HugeIcons.strokeRoundedArrowDown01, c: AppColors.muted, s: 14),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
      const Gap(14),
      Stack(
        clipBehavior: Clip.none,
        children: [
          AppTheme.hi(HugeIcons.strokeRoundedNotification01, s: 30),
          Positioned(
            right: -6,
            top: -6,
            child: Container(
              width: 18,
              height: 18,
              alignment: Alignment.center,
              decoration: const BoxDecoration(color: AppColors.red, shape: BoxShape.circle),
              child: Text('3', style: AppTheme.display(10, c: Colors.white)),
            ),
          ),
        ],
      ),
      const Gap(12),
      const CircleAvatar(
        radius: 26,
        backgroundColor: AppColors.orangeSoft,
        backgroundImage: NetworkImage('${_u}photo-1494790108377-be9c29b29330?w=150'),
      ),
    ],
  );
}

class SearchBar extends StatelessWidget {
  const SearchBar({super.key, required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(18),
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border, width: 1.4),
      ),
      child: Row(
        children: [
          AppTheme.hi(HugeIcons.strokeRoundedSearch01, s: 26),
          const Gap(12),
          Expanded(
            child: Text(
              'Search for food, services, products, people...',
              style: AppTheme.hind(15, c: AppColors.muted),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          Gap(8),
          AppTheme.hi(HugeIcons.strokeRoundedFilterHorizontal, s: 24),
        ],
      ),
    ),
  );
}

// ───────────── I need / I have / Match me ─────────────
class _IntentCards extends StatelessWidget {
  const _IntentCards();
  @override
  Widget build(BuildContext context) {
    Widget card(String t, String l1, String l2, Icn icon, Color c, Color bg) => Expanded(
      child: Container(
        padding: const EdgeInsets.fromLTRB(8, 10, 8, 10),
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(18)),
        child: Column(
          mainAxisAlignment: .center,
          crossAxisAlignment: .center,
          mainAxisSize: .min,
          children: [
            Container(
              width: 35,
              height: 35,
              decoration: BoxDecoration(color: c, shape: BoxShape.circle),
              child: Center(child: AppTheme.hi(icon, c: Colors.white, s: 20)),
            ),
            const Gap(8),
            Text(t, style: AppTheme.display(14), maxLines: 1),
            const Gap(2),
            Text('$l1\n$l2', style: AppTheme.hind(12, c: c, h: 1.2)),
          ],
        ),
      ),
    );
    return Row(
      children: [
        card(
          'I NEED',
          'Find what',
          'you need',
          HugeIcons.strokeRoundedShoppingCart02,
          _orange,
          const Color(0xFFFDEBDD),
        ),
        const Gap(8),
        card(
          'I HAVE',
          'Offer what',
          'you have',
          HugeIcons.strokeRoundedTag01,
          _green,
          const Color(0xFFE5F4E7),
        ),
        const Gap(8),
        card(
          'MATCH ME',
          'Connect with',
          'right people',
          HugeIcons.strokeRoundedUserGroup,
          _blue,
          const Color(0xFFE3EEFD),
        ),
      ],
    );
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle({super.key, required this.title, this.onSeeAll, this.size = 16});

  final String title;
  final double size;
  final VoidCallback? onSeeAll;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(top: 18, bottom: 10),
    child: Row(
      children: [
        Expanded(
          child: Text(title, style: AppTheme.display(size, w: FontWeight.w700)),
        ),

        if (onSeeAll != null)
          InkWell(
            onTap: onSeeAll,
            borderRadius: BorderRadius.circular(8),
            child: Row(
              children: [
                Text(
                  'See all',
                  style: AppTheme.hind(14, w: FontWeight.w700, c: _forest),
                ),
                const Gap(4),
                AppTheme.hi(HugeIcons.strokeRoundedArrowRight01, c: _forest, s: 18),
              ],
            ),
          ),
      ],
    ),
  );
}

// ───────────── Categories ─────────────
// class Categories extends StatelessWidget {
//   const Categories({super.key, required this.onCategoryTap});

//   final ValueChanged<ShopCategory> onCategoryTap;

//   static const _row1 = <(String, Icn, Color, Color)>[
//     ('Food', HugeIcons.strokeRoundedDish01, _orange, Color(0xFFFDEBDD)),
//     ('Health &\nFitness', HugeIcons.strokeRoundedDumbbell01, Color(0xFFE5334F), Color(0xFFFDE8EB)),
//     ('Beauty &\nCare', HugeIcons.strokeRoundedSparkles, Color(0xFFC026A8), Color(0xFFF6E7F6)),
//     ('Education &\nCareer', HugeIcons.strokeRoundedMortarboard01, _blue, Color(0xFFE3EEFD)),
//     ('Kids', HugeIcons.strokeRoundedBaby01, Color(0xFFF59E0B), Color(0xFFFFF1D6)),
//   ];
//   static const _row2 = <(String, Icn, Color, Color)>[
//     ('Events &\nOccasion', HugeIcons.strokeRoundedParty, Color(0xFFE5334F), Color(0xFFFDE8EB)),
//     ('Art &\nCreation', HugeIcons.strokeRoundedPaintBoard, Color(0xFF7C4DDB), Color(0xFFEDE7FA)),
//     ('Buy & Sell', HugeIcons.strokeRoundedShoppingBag01, _green, Color(0xFFE5F4E7)),
//     ('Services', HugeIcons.strokeRoundedWrench01, _blue, Color(0xFFE3EEFD)),
//     ('More', HugeIcons.strokeRoundedGridView, AppColors.ink, Color(0xFFEDEDED)),
//   ];

//   Widget _row(List<(String, Icn, Color, Color)> items) => Row(
//     children: [
//       for (final (i, e) in items.indexed) ...[
//         if (i > 0) const Gap(8),
//         Expanded(
//           child: Container(
//             height: 90,
//             decoration: BoxDecoration(color: e.$4, borderRadius: BorderRadius.circular(16)),
//             child: Column(
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: [
//                 AppTheme.hi(e.$2, c: e.$3, s: 30),
//                 const Gap(6),
//                 Text(
//                   e.$1,
//                   textAlign: TextAlign.center,
//                   style: AppTheme.hind(12, w: FontWeight.w600, h: 1.1),
//                 ),
//                 if (e.$1 == 'More')
//                   Text(
//                     'Property, Jobs,\nCommunity, Help & more',
//                     textAlign: TextAlign.center,
//                     style: AppTheme.hind(8, c: AppColors.muted, h: 1.1),
//                   ),
//               ],
//             ),
//           ),
//         ),
//       ],
//     ],
//   );

//   @override
//   Widget build(BuildContext context) => Column(children: [_row(_row1), const Gap(6), _row(_row2)]);
// }

class Categories extends ConsumerWidget {
  const Categories({super.key, required this.onCategoryTap});

  final ValueChanged<ShopCategory> onCategoryTap;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final categoriesAsync = ref.watch(shopCategoriesProvider);

    return categoriesAsync.when(
      loading: () => const CategoryListShimmer(),
      error: (error, stack) =>
          CategoryLoadError(onRetry: () => ref.invalidate(shopCategoriesProvider)),
      data: (categories) {
        final topLevelCategories =
            categories.where((category) => category.isActive && category.isTopLevel).toList()
              ..sort((a, b) => a.displayOrder.compareTo(b.displayOrder));

        if (topLevelCategories.isEmpty) {
          return const SizedBox.shrink();
        }

        // Keep the existing 2-row layout.
        // final row1 = topLevelCategories.take(5).toList();
        // final row2 = topLevelCategories.skip(5).take(5).toList();

        // return Column(
        //   children: [
        // _buildCategoryRow(row1),
        // const Gap(6),
        // if (row2.isNotEmpty) _buildCategoryRow(row2),
        //   ],
        // );

        return _buildCategoryRow(topLevelCategories);
      },
    );
  }

  Widget _buildCategoryRow(List<ShopCategory> categories) {
    // return Row(
    //   children: [
    //     for (final (index, category) in categories.indexed) ...[
    //       if (index > 0) const Gap(8),
    //       Expanded(child: _buildCategoryItem(category)),
    //     ],
    //   ],
    // );

    return SizedBox(
      height: 80,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: categories.length,
        separatorBuilder: (_, _) => const Gap(8),
        itemBuilder: (context, index) {
          final category = categories[index];

          return _buildCategoryItem(category);
        },
      ),
    );
  }

  Widget _buildCategoryItem(ShopCategory category) {
    final style = _categoryStyleFor(category);

    return InkWell(
      onTap: () => onCategoryTap(category),
      borderRadius: BorderRadius.circular(16),
      child: Container(
        height: 78,
        padding: .symmetric(horizontal: 18, vertical: 4),
        decoration: BoxDecoration(color: style.background, borderRadius: BorderRadius.circular(16)),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AppTheme.hi(style.icon, c: style.foreground, s: 30),
            const Gap(6),
            Text(
              style.label,
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: AppTheme.hind(12, w: FontWeight.w600, h: 1.1),
            ),
            if (category.slug.toLowerCase() == 'more')
              Text(
                'Property, Jobs,\nCommunity, Help & more',
                textAlign: TextAlign.center,
                style: AppTheme.hind(8, c: AppColors.muted, h: 1.1),
              ),
          ],
        ),
      ),
    );
  }
}

typedef _CategoryStyle = ({String label, Icn icon, Color foreground, Color background});

_CategoryStyle _categoryStyleFor(ShopCategory category) {
  final slug = category.slug.toLowerCase();

  switch (slug) {
    case 'food':
    case 'breakfast':
    case 'dinner':
      return (
        label: category.name,
        icon: HugeIcons.strokeRoundedDish01,
        foreground: _orange,
        background: const Color(0xFFFDEBDD),
      );

    case 'bake':
    case 'cake':
      return (
        label: category.name,
        icon: HugeIcons.strokeRoundedCake,
        foreground: _orange,
        background: const Color(0xFFFDEBDD),
      );

    case 'health-fitness':
    case 'health':
    case 'fitness':
    case 'fitness-trainer':
      return (
        label: 'Health &\nFitness',
        icon: HugeIcons.strokeRoundedDumbbell01,
        foreground: const Color(0xFFE5334F),
        background: const Color(0xFFFDE8EB),
      );

    case 'beauty-care':
    case 'beauty':
      return (
        label: 'Beauty &\nCare',
        icon: HugeIcons.strokeRoundedSparkles,
        foreground: const Color(0xFFC026A8),
        background: const Color(0xFFF6E7F6),
      );

    case 'education-career':
    case 'education':
    case 'tution-classes':
    case 'classes':
    case 'class':
      return (
        label: 'Education &\nCareer',
        icon: HugeIcons.strokeRoundedMortarboard01,
        foreground: _blue,
        background: const Color(0xFFE3EEFD),
      );

    case 'kids':
      return (
        label: category.name,
        icon: HugeIcons.strokeRoundedBaby01,
        foreground: const Color(0xFFF59E0B),
        background: const Color(0xFFFFF1D6),
      );

    case 'events-occasion':
    case 'events':
      return (
        label: 'Events &\nOccasion',
        icon: HugeIcons.strokeRoundedParty,
        foreground: const Color(0xFFE5334F),
        background: const Color(0xFFFDE8EB),
      );

    case 'art-creation':
    case 'art':
      return (
        label: 'Art &\nCreation',
        icon: HugeIcons.strokeRoundedPaintBoard,
        foreground: const Color(0xFF7C4DDB),
        background: const Color(0xFFEDE7FA),
      );

    case 'buy-sell':
      return (
        label: 'Buy & Sell',
        icon: HugeIcons.strokeRoundedShoppingBag01,
        foreground: _green,
        background: const Color(0xFFE5F4E7),
      );

    case 'services':
    case 'electric':
    case 'electrician':
    case 'repair':
      return (
        label: category.name,
        icon: HugeIcons.strokeRoundedWrench01,
        foreground: _blue,
        background: const Color(0xFFE3EEFD),
      );

    default:
      // Reuse the icon mapping from ExploreCategories.
      return (
        label: category.name,
        icon: _categoryIconFor(category),
        foreground: _blue,
        background: const Color(0xFFE3EEFD),
      );
  }
}

List<List<dynamic>> _categoryIconFor(ShopCategory category) {
  switch (category.slug.toLowerCase()) {
    case 'breakfast':
      return HugeIcons.strokeRoundedCoffee01;

    case 'dinner':
      return HugeIcons.strokeRoundedDish01;

    case 'electric':
    case 'electrician':
      return HugeIcons.strokeRoundedPlug01;

    case 'repair':
    case 'ran-repair':
      return HugeIcons.strokeRoundedTools;

    case 'classes':
      return HugeIcons.strokeRoundedBookOpen01;

    default:
      switch (category.categoryType) {
        case ShopCategoryType.food:
          return HugeIcons.strokeRoundedRestaurant01;

        case ShopCategoryType.service:
          return HugeIcons.strokeRoundedTools;

        case ShopCategoryType.product:
          return HugeIcons.strokeRoundedShoppingBag01;

        case ShopCategoryType.unknown:
          return HugeIcons.strokeRoundedGridView;
      }
  }
}

// ───────────── Banner ─────────────
class _Banner extends StatelessWidget {
  const _Banner();
  @override
  Widget build(BuildContext context) => Container(
    height: 150,
    clipBehavior: Clip.antiAlias,
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(22),
      gradient: const LinearGradient(colors: [Color(0xFFE6F3E3), Color(0xFFF4F9F1)]),
    ),
    child: Row(
      children: [
        Expanded(
          flex: 5,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 12, 0, 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Support Your\nNeighborhood',
                  style: AppTheme.display(16, w: FontWeight.w800, c: _forest, h: 1.05),
                ),
                const Gap(8),
                Text('Buy, Sell, Share and\nGrow Together', style: AppTheme.hind(12, h: 1.2)),
                const Spacer(),
                Container(
                  width: 38,
                  height: 38,
                  decoration: const BoxDecoration(color: _forest, shape: BoxShape.circle),
                  child: Center(
                    child: AppTheme.hi(HugeIcons.strokeRoundedArrowRight01, c: Colors.white, s: 24),
                  ),
                ),
              ],
            ),
          ),
        ),
        Expanded(
          flex: 5,
          child: Image.asset(
            'assets/images/h-dash-s.png',
            fit: BoxFit.fitHeight,
            alignment: Alignment.centerRight,
          ),
        ),
      ],
    ),
  );
}

class Popular extends ConsumerWidget {
  const Popular({super.key, this.societyId});

  final String? societyId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final listingsAsync = ref.watch(shopPopularListingsProvider(societyId ?? ''));

    return listingsAsync.when(
      loading: () => const PopularListingsShimmer(),
      error: (error, stack) => SizedBox(
        height: 226,
        child: Center(
          child: TextButton.icon(
            onPressed: () {
              ref.invalidate(shopPopularListingsProvider(societyId ?? ''));
            },
            icon: const Icon(Icons.refresh),
            label: const Text('Unable to load listings'),
          ),
        ),
      ),
      data: (state) {
        if (state.items.isEmpty) {
          return const SizedBox(
            height: 226,
            child: Center(child: Text('No popular listings available yet')),
          );
        }

        return SizedBox(
          height: 238,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: state.items.length,
            separatorBuilder: (_, _) => const Gap(10),
            itemBuilder: (context, index) {
              // return _PopularListingCard(listing: state.items[index], societyId: societyId);
              return ListingCard(listing: state.items[index]);
            },
          ),
        );
      },
    );
  }
}

class _PopularListingCard extends ConsumerWidget {
  const _PopularListingCard({required this.listing, required this.societyId});

  final ShopListing listing;
  final String? societyId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final favs = ref.watch(sevaFavsProvider);

    final favoriteKey = listing.title;
    final fav = favs.contains(favoriteKey);

    final imageUrl = ref
        .watch(shopListingImagesProvider(listing.id))
        .valueOrNull
        ?.where((image) => image.moderationStatus.toUpperCase() == 'APPROVED')
        .firstOrNull
        ?.imageUrl;

    final price = listing.isFree
        ? 'FREE'
        : listing.listingType.isService
        ? 'From ₹${_formatPopularPrice(listing.basePrice)}'
        : '₹${_formatPopularPrice(listing.basePrice)}';

    return Container(
      width: 176,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha((256 * 0.06).toInt()),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: 116,
            child: Stack(
              fit: StackFit.expand,
              children: [
                if (imageUrl != null)
                  Image.network(
                    imageUrl,
                    fit: BoxFit.cover,
                    errorBuilder: (_, _, _) => const SizedBox.shrink(),
                  )
                else
                  const ColoredBox(
                    color: Color(0xFFF2F2F2),
                    child: Center(child: Icon(Icons.image_outlined)),
                  ),

                Positioned(
                  right: 8,
                  top: 8,
                  child: GestureDetector(
                    onTap: () {
                      ref.read(sevaFavsProvider.notifier).state = fav
                          ? ({...favs}..remove(favoriteKey))
                          : {...favs, favoriteKey};
                    },
                    child: Container(
                      width: 34,
                      height: 34,
                      decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                      child: Center(
                        child: AppTheme.hi(
                          HugeIcons.strokeRoundedFavourite,
                          c: fav ? AppColors.red : AppColors.ink,
                          s: 20,
                        ),
                      ),
                    ),
                  ),
                ),

                Positioned(
                  left: 8,
                  bottom: 8,
                  child: Pill(price, const Color(0xFFD7F7E4), _forest),
                ),
              ],
            ),
          ),

          Padding(
            padding: const EdgeInsets.all(10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  listing.title,
                  style: AppTheme.hind(14, w: FontWeight.w700, h: 1.2),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const Gap(4),
                Row(
                  children: [
                    AppTheme.hi(HugeIcons.strokeRoundedLocation01, c: AppColors.muted, s: 14),
                    const Gap(3),
                    Expanded(
                      child: Text(
                        societyId != null && societyId!.isNotEmpty ? 'Your society' : 'Nearby',
                        style: AppTheme.hind(12, c: AppColors.muted),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

String _formatPopularPrice(double value) {
  if (value == value.roundToDouble()) {
    return value.toInt().toString();
  }

  return value.toStringAsFixed(2);
}

// ───────────── Services near you ─────────────
class Services extends StatelessWidget {
  const Services({super.key});

  // final String? societyId;

  static const _s = <(String, Icn, Color, Color)>[
    ('Home\nServices', HugeIcons.strokeRoundedHome07, _forest, Color(0xFFE5F4E7)),
    ('AC Repair', HugeIcons.strokeRoundedWrench01, _blue, Color(0xFFE3EEFD)),
    ('Painting', HugeIcons.strokeRoundedPaintBrush01, _orange, Color(0xFFFDEBDD)),
    ('Packers &\nMovers', HugeIcons.strokeRoundedTruck, _green, Color(0xFFE5F4E7)),
    ('Pet Care', HugeIcons.strokeRoundedPawPrint, _orange, Color(0xFFFDEBDD)),
    (
      'IT & Digital\nServices',
      HugeIcons.strokeRoundedComputerPhoneSync,
      Color(0xFF7C4DDB),
      Color(0xFFEDE7FA),
    ),
    (
      'Salon & Beauty\nServices',
      HugeIcons.strokeRoundedScissor01,
      Color(0xFFE5334F),
      Color(0xFFFDE8EB),
    ),
  ];
  @override
  Widget build(BuildContext context) => SizedBox(
    height: 104,
    child: Row(
      children: [
        Expanded(
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: _s.length,
            separatorBuilder: (_, _) => const Gap(14),
            itemBuilder: (_, i) => SizedBox(
              width: 60,
              child: Column(
                children: [
                  Container(
                    width: 54,
                    height: 54,
                    decoration: BoxDecoration(color: _s[i].$4, shape: BoxShape.circle),
                    child: Center(child: AppTheme.hi(_s[i].$2, c: _s[i].$3, s: 30)),
                  ),
                  const Gap(6),
                  Text(_s[i].$1, textAlign: TextAlign.center, style: AppTheme.hind(12, h: 1.15)),
                ],
              ),
            ),
          ),
        ),
        Container(
          width: 44,
          height: 44,
          margin: const EdgeInsets.only(left: 8, bottom: 30),
          decoration: BoxDecoration(
            color: Colors.white,
            shape: BoxShape.circle,
            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .1), blurRadius: 8)],
          ),
          child: Center(child: AppTheme.hi(HugeIcons.strokeRoundedArrowRight01, s: 22)),
        ),
      ],
    ),
  );
}

// ───────────── Recent needs ─────────────
class _Needs extends StatelessWidget {
  const _Needs();
  static const _n = [
    (
      'P',
      Color(0xFF7C4DDB),
      '2h ago',
      'Looking for Maths Tutor',
      'Class 5, in Gera World of Joy',
      'Respond',
    ),
    (
      'S',
      _blue,
      '3h ago',
      'Need Birthday Decorator',
      'For 25 people, this weekend',
      'View Details',
    ),
    ('A', _orange, '5h ago', 'Looking for Home Cook', 'Vegetarian, 5 days a week', 'Respond'),
  ];
  @override
  Widget build(BuildContext context) => SizedBox(
    height: 148,
    child: ListView.separated(
      scrollDirection: Axis.horizontal,
      itemCount: _n.length,
      separatorBuilder: (_, _) => const Gap(10),
      itemBuilder: (_, i) {
        final n = _n[i];
        return Container(
          width: 250,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: .06),
                blurRadius: 10,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    radius: 15,
                    backgroundColor: n.$2,
                    child: Text(n.$1, style: AppTheme.display(15, c: Colors.white)),
                  ),
                  const Gap(10),
                  Text(n.$3, style: AppTheme.hind(14, c: AppColors.muted)),
                ],
              ),
              const Gap(8),
              Text(n.$4, style: AppTheme.display(14, w: FontWeight.w800)),
              Text(n.$5, style: AppTheme.hind(12, c: AppColors.muted)),
              const Spacer(),
              Btn(n.$6, style: 1, pad: 8),
            ],
          ),
        );
      },
    ),
  );
}

// ───────────── Bottom nav with centre Post button ─────────────
class _SevaNav extends ConsumerWidget {
  const _SevaNav();
  static const _items = <(String, Icn?)>[
    ('Home', HugeIcons.strokeRoundedHome01),
    ('Explore', HugeIcons.strokeRoundedSearch01),
    ('Post', null),
    ('Chat', HugeIcons.strokeRoundedMessage01),
    ('Profile', HugeIcons.strokeRoundedUser),
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sel = ref.watch(sevaNavProvider);
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: .08),
            blurRadius: 16,
            offset: const Offset(0, -4),
          ),
        ],
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: SafeArea(
        child: SizedBox(
          height: 72,
          child: Row(
            children: List.generate(_items.length, (i) {
              final it = _items[i];
              final active = sel == i;
              final c = active ? _forest : AppColors.muted;
              return Expanded(
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => ref.read(sevaNavProvider.notifier).state = i,
                  child: it.$2 == null
                      ? Transform.translate(
                          offset: const Offset(0, -14),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                width: 62,
                                height: 62,
                                decoration: BoxDecoration(
                                  color: _forest,
                                  shape: BoxShape.circle,
                                  boxShadow: [
                                    BoxShadow(
                                      color: _forest.withValues(alpha: .35),
                                      blurRadius: 12,
                                      offset: const Offset(0, 4),
                                    ),
                                  ],
                                ),
                                child: Center(
                                  child: AppTheme.hi(
                                    HugeIcons.strokeRoundedAdd01,
                                    c: Colors.white,
                                    s: 32,
                                  ),
                                ),
                              ),
                              const Gap(2),
                              Text('Post', style: AppTheme.hind(14, c: AppColors.muted)),
                            ],
                          ),
                        )
                      : Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            AppTheme.hi(it.$2!, c: c, s: 28),
                            const Gap(2),
                            Text(
                              it.$1,
                              style: AppTheme.hind(
                                14,
                                w: active ? FontWeight.w700 : FontWeight.w400,
                                c: c,
                              ),
                            ),
                          ],
                        ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}

class _Placeholder extends StatelessWidget {
  const _Placeholder(this.title);
  final String title;
  @override
  Widget build(BuildContext context) => Center(child: Text(title, style: AppTheme.display(20)));
}

final appRouter = GoRouter(
  initialLocation: '/home',
  routes: [
    GoRoute(path: '/seva', builder: (_, _) => const SevaHomeScreen()),
    StatefulShellRoute.indexedStack(
      builder: (context, state, shell) => AppShell(shell: shell),
      branches: [
        // StatefulShellBranch(routes: [
        //   _r('/home', const HomeScreen(), routes: [
        //     _r('helpdesk', const HelpdeskScreen()),
        //     _r('polls', const PollsScreen()),
        //   ]),
        // ]),
        // StatefulShellBranch(routes: [
        //   _r('/market', const MarketplaceScreen(), routes: [_r('seller', const SellerProfileScreen())]),
        // ]),
        // StatefulShellBranch(routes: [_r('/community', const CommunityScreen())]),
        // StatefulShellBranch(routes: [
        //   _r('/orders', const OrderTrackingScreen(), routes: [_r('cart', const CartScreen())]),
        // ]),
        // StatefulShellBranch(routes: [_r('/profile', const _Placeholder('Profile'))]),
      ],
    ),
  ],
);

typedef Icn = List<List<dynamic>>;

// Widget AppTheme.hi(Icn i, {Color c = AppColors.ink, double s = 22}) => HugeIcon(icon: i, color: c, size: s);

BoxDecoration cardBox({
  Color color = Colors.white,
  Color border = AppColors.border,
  double r = 22,
}) => BoxDecoration(
  color: color,
  borderRadius: BorderRadius.circular(r),
  border: Border.all(color: border, width: 1.2),
);

class Pill extends StatelessWidget {
  const Pill(this.text, this.bg, this.fg, {super.key, this.icon});
  final String text;
  final Color bg, fg;
  final Icn? icon;
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
    decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (icon != null) ...[AppTheme.hi(icon!, c: fg, s: 14), const Gap(5)],
        Text(text, style: AppTheme.display(12, c: fg)),
      ],
    ),
  );
}

class NetImg extends StatelessWidget {
  const NetImg(this.url, {super.key, this.r = 0, this.w, this.h});
  final String url;
  final double r;
  final double? w, h;
  @override
  Widget build(BuildContext context) => ClipRRect(
    borderRadius: BorderRadius.circular(r),
    child: Image.network(
      url,
      width: w,
      height: h,
      fit: BoxFit.cover,
      errorBuilder: (_, _, _) => Container(width: w, height: h, color: AppColors.greenSoft),
    ),
  );
}

class Btn extends StatelessWidget {
  const Btn(
    this.label, {
    super.key,
    this.onTap,
    this.style = 0,
    this.icon,
    this.expand = true,
    this.pad = 14,
  });

  /// style: 0 = filled green, 1 = outlined, 2 = soft, 3 = orange
  final String label;
  final VoidCallback? onTap;
  final int style;
  final Icn? icon;
  final bool expand;
  final double pad;
  @override
  Widget build(BuildContext context) {
    final bg = [AppColors.green, Colors.white, const Color(0xFFEDF1EC), AppColors.orange][style];
    final fg = [Colors.white, AppColors.green, AppColors.green, AppColors.ink][style];
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: expand ? double.infinity : null,
        padding: EdgeInsets.symmetric(vertical: pad, horizontal: 18),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(16),
          border: style == 1 ? Border.all(color: AppColors.green, width: 1) : null,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (icon != null) ...[AppTheme.hi(icon!, c: fg, s: 20), const Gap(8)],
            Text(
              label,
              style: AppTheme.hind(16, w: FontWeight.w700, c: fg),
            ),
          ],
        ),
      ),
    );
  }
}

class SquareBtn extends StatelessWidget {
  const SquareBtn(
    this.icon, {
    super.key,
    this.bg,
    this.fg = Colors.white,
    this.badge,
    this.size = 52,
    this.onTap,
  });
  final Icn icon;
  final Color? bg;
  final Color fg;
  final String? badge;
  final double size;
  final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Stack(
      clipBehavior: Clip.none,
      children: [
        Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            color: bg ?? Colors.white.withValues(alpha: .14),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Center(child: AppTheme.hi(icon, c: fg, s: 24)),
        ),
        if (badge != null)
          Positioned(
            right: -5,
            top: -6,
            child: Container(
              width: 22,
              height: 22,
              alignment: Alignment.center,
              decoration: const BoxDecoration(color: AppColors.red, shape: BoxShape.circle),
              child: Text(badge!, style: AppTheme.display(11, c: Colors.white)),
            ),
          ),
      ],
    ),
  );
}

/// Dark-green header: society switcher + search + bell + voice search.
class AppHeader extends StatelessWidget {
  const AppHeader({super.key});
  @override
  Widget build(BuildContext context) => Container(
    padding: EdgeInsets.fromLTRB(16, MediaQuery.of(context).padding.top + 12, 16, 18),
    decoration: const BoxDecoration(
      color: AppColors.greenDeep,
      borderRadius: BorderRadius.vertical(bottom: Radius.circular(32)),
    ),
    child: Column(
      children: [
        Row(
          children: [
            Container(
              width: 52,
              height: 52,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: .14),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Text('G', style: AppTheme.display(20, c: Colors.white)),
            ),
            const Gap(14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text('Greenview Heights', style: AppTheme.display(18, c: Colors.white)),
                      const Gap(4),
                      AppTheme.hi(HugeIcons.strokeRoundedArrowDown01, c: Colors.white, s: 18),
                    ],
                  ),
                  Text('B Wing · 402', style: AppTheme.hind(13, c: Colors.white70)),
                ],
              ),
            ),
            const SquareBtn(HugeIcons.strokeRoundedSearch01),
            const Gap(10),
            const SquareBtn(
              HugeIcons.strokeRoundedNotification01,
              bg: AppColors.orange,
              fg: AppColors.greenDeep,
              badge: '3',
            ),
          ],
        ),
        const Gap(12),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
          child: Row(
            children: [
              AppTheme.hi(HugeIcons.strokeRoundedSearch01, c: AppColors.muted),
              const Gap(12),
              Expanded(
                child: Text(
                  'Search homemade food, services, neighbours…',
                  style: AppTheme.hind(14, c: AppColors.muted),
                ),
              ),
              Pill(
                'Voice',
                AppColors.greenSoft,
                AppColors.green,
                icon: HugeIcons.strokeRoundedMic01,
              ),
            ],
          ),
        ),
      ],
    ),
  );
}

/// Back-arrow header used by Marketplace / Order tracking.
class BackHeader extends StatelessWidget {
  const BackHeader({
    super.key,
    required this.eyebrow,
    required this.title,
    this.trailing,
    this.bottom,
    required this.onBack,
  });
  final String eyebrow, title;
  final Widget? trailing, bottom;
  final VoidCallback onBack;
  @override
  Widget build(BuildContext context) => Container(
    padding: EdgeInsets.fromLTRB(16, MediaQuery.of(context).padding.top + 14, 16, 18),
    decoration: const BoxDecoration(
      color: AppColors.greenDeep,
      borderRadius: BorderRadius.vertical(bottom: Radius.circular(36)),
    ),
    child: Column(
      children: [
        Row(
          children: [
            SquareBtn(HugeIcons.strokeRoundedArrowLeft01, size: 48, onTap: onBack),
            const Gap(14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(eyebrow, style: AppTheme.hind(14, c: Colors.white70)),
                  Text(title, style: AppTheme.display(24, c: Colors.white)),
                ],
              ),
            ),
            ?trailing,
          ],
        ),
        if (bottom != null) ...[const Gap(14), bottom!],
      ],
    ),
  );
}

class Heading extends StatelessWidget {
  const Heading(this.eyebrow, this.title, {super.key, this.trailing, this.sub});
  final String eyebrow, title;
  final String? sub;
  final Widget? trailing;
  @override
  Widget build(BuildContext context) => Row(
    crossAxisAlignment: CrossAxisAlignment.end,
    children: [
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              eyebrow.toUpperCase(),
              style: AppTheme.display(14, w: FontWeight.w700, c: AppColors.orange),
            ),
            Text(title, style: AppTheme.display(28)),
            if (sub != null) Text(sub!, style: AppTheme.hind(16, c: AppColors.muted)),
          ],
        ),
      ),
      ?trailing,
    ],
  );
}

/// Segmented pill tabs (Official Notices / Community / Events, Active / Voted / Results).
class SegTabs extends StatelessWidget {
  const SegTabs({super.key, required this.labels, required this.index, required this.onChanged});
  final List<String> labels;
  final int index;
  final ValueChanged<int> onChanged;
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(6),
    decoration: cardBox(r: 24),
    child: Row(
      children: List.generate(labels.length, (i) {
        final sel = i == index;
        return Expanded(
          child: GestureDetector(
            onTap: () => onChanged(i),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              padding: const EdgeInsets.symmetric(vertical: 13),
              decoration: BoxDecoration(
                color: sel ? AppColors.green : Colors.transparent,
                borderRadius: BorderRadius.circular(18),
              ),
              child: Center(
                child: Text(
                  labels[i],
                  style: AppTheme.hind(
                    15,
                    w: FontWeight.w700,
                    c: sel ? Colors.white : AppColors.muted,
                  ),
                ),
              ),
            ),
          ),
        );
      }),
    ),
  );
}

class QtyStepper extends StatelessWidget {
  const QtyStepper({
    super.key,
    required this.qty,
    required this.onInc,
    required this.onDec,
    this.compact = false,
  });
  final int qty;
  final VoidCallback onInc, onDec;
  final bool compact;
  @override
  Widget build(BuildContext context) {
    Widget b(Icn i, VoidCallback f) => GestureDetector(
      onTap: f,
      child: Container(
        width: compact ? 30 : 38,
        height: compact ? 30 : 38,
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: .18),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Center(child: AppTheme.hi(i, c: Colors.white, s: 18)),
      ),
    );
    return Container(
      padding: const EdgeInsets.all(5),
      decoration: BoxDecoration(color: AppColors.green, borderRadius: BorderRadius.circular(16)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          b(HugeIcons.strokeRoundedRemove01, onDec),
          SizedBox(
            width: 34,
            child: Center(
              child: Text('$qty', style: AppTheme.display(16, c: Colors.white)),
            ),
          ),
          b(HugeIcons.strokeRoundedAdd01, onInc),
        ],
      ),
    );
  }
}

GoRoute _r(String path, Widget w, {List<RouteBase> routes = const []}) =>
    GoRoute(path: path, builder: (_, _) => w, routes: routes);

/// Spread into your AppRouter:  routes: [ ...uiRoutes, ...your routes ]
final List<RouteBase> uiRoutes = [
  GoRoute(path: '/seva', builder: (_, _) => const SevaHomeScreen()),
  StatefulShellRoute.indexedStack(
    builder: (context, state, shell) => AppShell(shell: shell),
    branches: [
      // StatefulShellBranch(routes: [
      //   _r('/home', const HomeScreen(), routes: [
      //     _r('helpdesk', const HelpdeskScreen()),
      //     _r('polls', const PollsScreen()),
      //   ]),
      // ]),
      // StatefulShellBranch(routes: [
      //   _r('/market', const MarketplaceScreen(), routes: [_r('seller', const SellerProfileScreen())]),
      // ]),
      // StatefulShellBranch(routes: [_r('/community', const CommunityScreen())]),
      // StatefulShellBranch(routes: [
      //   _r('/orders', const OrderTrackingScreen(), routes: [_r('cart', const CartScreen())]),
      // ]),
    ],
  ),
];

/// Bottom bar. Profile (index 4) opens your existing '/profile' route.
class AppShell extends StatelessWidget {
  const AppShell({super.key, required this.shell});
  final StatefulNavigationShell shell;

  static const _items = <(String, Icn)>[
    ('Home', HugeIcons.strokeRoundedHome01),
    ('Market', HugeIcons.strokeRoundedStore01),
    ('Community', HugeIcons.strokeRoundedUserGroup),
    ('Orders', HugeIcons.strokeRoundedShoppingBag01),
    ('Profile', HugeIcons.strokeRoundedUser),
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
    body: shell,
    bottomNavigationBar: Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: AppColors.border)),
      ),
      child: SafeArea(
        child: SizedBox(
          height: 68,
          child: Row(
            children: List.generate(_items.length, (i) {
              final sel = i < 4 && shell.currentIndex == i;
              final color = sel ? AppColors.green : AppColors.muted;
              return Expanded(
                child: InkWell(
                  onTap: () => i == 4
                      ? context.push('/profile')
                      : shell.goBranch(i, initialLocation: i == shell.currentIndex),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Stack(
                        clipBehavior: Clip.none,
                        children: [
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 6),
                            decoration: BoxDecoration(
                              color: sel ? AppColors.greenSoft : Colors.transparent,
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: AppTheme.hi(_items[i].$2, c: color, s: 24),
                          ),
                          if (i == 3)
                            Positioned(
                              right: 10,
                              top: 2,
                              child: Container(
                                width: 8,
                                height: 8,
                                decoration: const BoxDecoration(
                                  color: AppColors.red,
                                  shape: BoxShape.circle,
                                ),
                              ),
                            ),
                        ],
                      ),
                      const Gap(2),
                      Text(
                        _items[i].$1,
                        style: AppTheme.hind(
                          12,
                          w: sel ? FontWeight.w700 : FontWeight.w500,
                          c: color,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    ),
  );
}
