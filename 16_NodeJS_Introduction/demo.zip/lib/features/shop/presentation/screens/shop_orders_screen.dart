import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/features/shop/data/models/shop_checkout_models.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_cart_provider.dart';

import 'shop_order_tracking_screen.dart';

// Navigator.of(context).push(
//   MaterialPageRoute(
//     builder: (_) => ShopServiceBookingDetailsScreen(
//       booking: bookingDetails,
//     ),
//   ),
// );

class ShopOrdersScreen extends ConsumerStatefulWidget {
  const ShopOrdersScreen({super.key, this.initialFilter = ShopOrdersFilter.all});

  final ShopOrdersFilter initialFilter;

  @override
  ConsumerState<ShopOrdersScreen> createState() => _ShopOrdersScreenState();
}

class _ShopOrdersScreenState extends ConsumerState<ShopOrdersScreen> {
  late ShopOrdersFilter _selectedFilter;

  @override
  void initState() {
    super.initState();
    _selectedFilter = widget.initialFilter;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final ordersAsync = ref.watch(shopMyOrdersProvider);

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      appBar: AppBar(
        backgroundColor: theme.colorScheme.surface,
        elevation: 0,
        automaticallyImplyLeading: false,
        title: Text(
          'Orders',
          style: GoogleFonts.hind(
            fontSize: 21,
            fontWeight: FontWeight.w700,
            color: theme.colorScheme.onSurface,
          ),
        ),
        actions: [
          IconButton(
            tooltip: 'Payment history',
            onPressed: () => context.push('/shop/payments'),
            icon: const HugeIcon(icon: HugeIcons.strokeRoundedWallet01, size: 21),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            _FilterTabs(
              selectedFilter: _selectedFilter,
              onChanged: (filter) {
                setState(() {
                  _selectedFilter = filter;
                });
              },
            ),
            Expanded(
              child: ordersAsync.when(
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (error, stackTrace) => Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text('Unable to load your orders'),
                      TextButton.icon(
                        onPressed: () => ref.invalidate(shopMyOrdersProvider),
                        icon: const Icon(Icons.refresh),
                        label: const Text('Try again'),
                      ),
                    ],
                  ),
                ),
                data: (results) {
                  final orders = results
                      .where((order) => _matchesFilterType(order))
                      .map((order) => _toListItem(context, order))
                      .toList();
                  if (orders.isEmpty) {
                    return _EmptyOrdersState(
                      filter: _selectedFilter,
                      onContinueShopping: () => context.go('/'),
                    );
                  }
                  return RefreshIndicator(
                    onRefresh: _refreshOrders,
                    child: ListView.separated(
                      physics: const AlwaysScrollableScrollPhysics(),
                      padding: const EdgeInsets.fromLTRB(20, 14, 20, 28),
                      itemCount: orders.length,
                      separatorBuilder: (_, _) => const Gap(12),
                      itemBuilder: (context, index) {
                        final order = orders[index];
                        return _OrderCard(
                          order: order,
                          onTap: () => _openOrder(context, order),
                          onPrimaryAction: () => _handlePrimaryAction(context, order),
                        );
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  bool _matchesFilterType(ShopOrderResult order) {
    switch (_selectedFilter) {
      case ShopOrdersFilter.all:
        return true;
      case ShopOrdersFilter.products:
        return !order.orderType.toUpperCase().contains('SERVICE') &&
            !order.orderType.toUpperCase().contains('CONSULTATION');
      case ShopOrdersFilter.services:
        return order.orderType.toUpperCase().contains('SERVICE') ||
            order.orderType.toUpperCase().contains('CONSULTATION');
    }
  }

  ShopOrderListItem _toListItem(BuildContext context, ShopOrderResult result) {
    final scheduledAt = DateTime.tryParse(result.scheduledAt ?? '')?.toLocal();
    final createdAt = DateTime.tryParse(result.createdAt ?? '')?.toLocal();
    final sellerId = result.sellerId;
    final sellerIdShort = sellerId.length > 8 ? sellerId.substring(0, 8) : sellerId;
    final orderType = result.orderType.toUpperCase();
    final rawStatus = result.orderStatus.toUpperCase();
    final status = switch (rawStatus) {
      'CREATED' || 'PAYMENT_PENDING' => ShopOrderStatus.placed,
      'PAID' || 'ACCEPTED' => ShopOrderStatus.confirmed,
      'PREPARING' || 'IN_SERVICE' => ShopOrderStatus.preparing,
      'READY' => ShopOrderStatus.ready,
      'READY_FOR_PICKUP' || 'READY_FOR_HANDOFF' => ShopOrderStatus.readyForPickup,
      'OUT_FOR_DELIVERY' => ShopOrderStatus.outForDelivery,
      'DELIVERED' => ShopOrderStatus.delivered,
      'PICKED_UP' => ShopOrderStatus.pickedUp,
      'COMPLETED' => ShopOrderStatus.completed,
      'REJECTED' || 'CANCELLED' || 'CANCELED' => ShopOrderStatus.cancelled,
      _ => ShopOrderStatus.placed,
    };
    final sellerName = result.sellerName?.trim().isNotEmpty == true
        ? result.sellerName!.trim()
        : 'Seller $sellerIdShort';
    final dateLabel = createdAt == null
        ? 'Order ${result.orderNumber}'
        : MaterialLocalizations.of(context).formatMediumDate(createdAt);
    final fulfillment = result.fulfillmentMethod.replaceAll('_', ' ');

    return ShopOrderListItem(
      id: result.id,
      reference: result.orderNumber.isNotEmpty ? result.orderNumber : result.id,
      type: orderType.contains('SERVICE') || orderType.contains('CONSULTATION')
          ? ShopOrderType.service
          : ShopOrderType.product,
      sellerId: sellerId,
      sellerName: sellerName,
      status: status,
      items: result.items
          .map((item) => ShopOrderListItemEntry(name: item.title, quantity: item.quantity))
          .toList(),
      totalAmount: result.totalAmount,
      dateLabel: dateLabel,
      fulfillmentLabel: fulfillment.isEmpty ? null : fulfillment,
      timeLabel: scheduledAt == null ? null : TimeOfDay.fromDateTime(scheduledAt).format(context),
      orderResult: result,
    );
  }

  Future<void> _refreshOrders() async {
    ref.invalidate(shopMyOrdersProvider);
    await ref.read(shopMyOrdersProvider.future);
  }

  void _openOrder(BuildContext context, ShopOrderListItem order) {
    final result = order.orderResult;
    if (result == null) return;
    context.push('/shop/orders/${result.id}', extra: ShopOrderTrackingData.fromOrder(result));
  }

  void _handlePrimaryAction(BuildContext context, ShopOrderListItem order) {
    if (order.type == ShopOrderType.product) {
      _openOrder(context, order);
      return;
    }

    _openOrder(context, order);
  }
}

// FILTER TABS
class _FilterTabs extends StatelessWidget {
  const _FilterTabs({required this.selectedFilter, required this.onChanged});

  final ShopOrdersFilter selectedFilter;
  final ValueChanged<ShopOrdersFilter> onChanged;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    const filters = [
      (filter: ShopOrdersFilter.all, label: 'All'),
      (filter: ShopOrdersFilter.products, label: 'Products'),
      (filter: ShopOrdersFilter.services, label: 'Services'),
    ];

    return SizedBox(
      height: 50,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        scrollDirection: Axis.horizontal,
        itemCount: filters.length,
        separatorBuilder: (_, _) => const Gap(8),
        itemBuilder: (context, index) {
          final item = filters[index];
          final selected = item.filter == selectedFilter;

          return Center(
            child: GestureDetector(
              onTap: () => onChanged(item.filter),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                padding: const EdgeInsets.symmetric(horizontal: 17, vertical: 8),
                decoration: BoxDecoration(
                  color: selected
                      ? theme.colorScheme.primary
                      : theme.colorScheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(22),
                ),
                child: Text(
                  item.label,
                  style: GoogleFonts.hind(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: selected
                        ? theme.colorScheme.onPrimary
                        : theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

// ORDER CARD
class _OrderCard extends StatelessWidget {
  const _OrderCard({required this.order, required this.onTap, required this.onPrimaryAction});

  final ShopOrderListItem order;
  final VoidCallback onTap;
  final VoidCallback onPrimaryAction;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Material(
      color: theme.colorScheme.surface,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: theme.colorScheme.outlineVariant.withValues(alpha: 0.7)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _OrderHeader(order: order),
              const Gap(14),
              _OrderItemsPreview(order: order),
              const Gap(14),
              Divider(height: 1, color: theme.colorScheme.outlineVariant.withValues(alpha: 0.65)),
              const Gap(13),
              _OrderMeta(order: order),
              const Gap(14),
              _OrderAction(order: order, onPressed: onPrimaryAction),
            ],
          ),
        ),
      ),
    );
  }
}

// ORDER HEADER
class _OrderHeader extends StatelessWidget {
  const _OrderHeader({required this.order});

  final ShopOrderListItem order;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: theme.colorScheme.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(13),
          ),
          child: HugeIcon(
            icon: order.type == ShopOrderType.product
                ? HugeIcons.strokeRoundedShoppingCart02
                : HugeIcons.strokeRoundedTools,
            size: 22,
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        const Gap(11),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                order.sellerName,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.hind(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: theme.colorScheme.onSurface,
                ),
              ),
              const Gap(1),
              Text(
                order.type == ShopOrderType.product
                    ? 'Order #${order.reference}'
                    : 'Booking #${order.reference}',
                style: GoogleFonts.hind(fontSize: 11.5, color: theme.colorScheme.onSurfaceVariant),
              ),
            ],
          ),
        ),
        const Gap(8),
        _StatusBadge(status: order.status),
      ],
    );
  }
}

// ITEMS PREVIEW
class _OrderItemsPreview extends StatelessWidget {
  const _OrderItemsPreview({required this.order});

  final ShopOrderListItem order;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ...order.items
            .take(2)
            .map(
              (item) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(
                  children: [
                    Container(
                      width: 34,
                      height: 34,
                      decoration: BoxDecoration(
                        color: theme.colorScheme.surfaceContainerHighest,
                        borderRadius: BorderRadius.circular(9),
                      ),
                      child: HugeIcon(
                        icon: HugeIcons.strokeRoundedImage01,
                        size: 16,
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                    const Gap(9),
                    Expanded(
                      child: Text(
                        item.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.hind(
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                          color: theme.colorScheme.onSurface,
                        ),
                      ),
                    ),
                    const Gap(10),
                    Text(
                      '×${item.quantity}',
                      style: GoogleFonts.hind(
                        fontSize: 12,
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
            ),
        if (order.items.length > 2)
          Padding(
            padding: const EdgeInsets.only(top: 1),
            child: Text(
              '+${order.items.length - 2} more item${order.items.length - 2 == 1 ? '' : 's'}',
              style: GoogleFonts.hind(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: theme.colorScheme.primary,
              ),
            ),
          ),
      ],
    );
  }
}

// ORDER META
class _OrderMeta extends StatelessWidget {
  const _OrderMeta({required this.order});

  final ShopOrderListItem order;

  @override
  Widget build(BuildContext context) {
    if (order.type == ShopOrderType.service) {
      return Row(
        children: [
          Expanded(
            child: _MetaItem(icon: HugeIcons.strokeRoundedCalendar03, label: order.dateLabel),
          ),
          Expanded(
            child: _MetaItem(icon: HugeIcons.strokeRoundedClock01, label: order.timeLabel ?? ''),
          ),
        ],
      );
    }

    return Row(
      children: [
        Expanded(
          child: _MetaItem(
            icon: HugeIcons.strokeRoundedLocation01,
            label: order.fulfillmentLabel ?? '',
          ),
        ),
        Expanded(
          child: _MetaItem(
            icon: HugeIcons.strokeRoundedWallet01,
            label: '₹${order.totalAmount.toStringAsFixed(0)}',
            bold: true,
          ),
        ),
      ],
    );
  }
}

class _MetaItem extends StatelessWidget {
  const _MetaItem({required this.icon, required this.label, this.bold = false});

  final dynamic icon;
  final String label;
  final bool bold;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Row(
      children: [
        HugeIcon(icon: icon, size: 17, color: theme.colorScheme.onSurfaceVariant),
        const Gap(7),
        Expanded(
          child: Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: GoogleFonts.hind(
              fontSize: 12,
              fontWeight: bold ? FontWeight.w700 : FontWeight.w500,
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ),
      ],
    );
  }
}

// STATUS
class _StatusBadge extends StatelessWidget {
  const _StatusBadge({required this.status});

  final ShopOrderStatus status;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    final isCancelled = status == ShopOrderStatus.cancelled;
    final isCompleted =
        status == ShopOrderStatus.delivered ||
        status == ShopOrderStatus.pickedUp ||
        status == ShopOrderStatus.completed;

    final backgroundColor = isCancelled
        ? theme.colorScheme.error.withValues(alpha: 0.08)
        : isCompleted
        ? theme.colorScheme.primary.withValues(alpha: 0.08)
        : theme.colorScheme.secondaryContainer;

    final textColor = isCancelled
        ? theme.colorScheme.error
        : isCompleted
        ? theme.colorScheme.primary
        : theme.colorScheme.onSecondaryContainer;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
      decoration: BoxDecoration(color: backgroundColor, borderRadius: BorderRadius.circular(20)),
      child: Text(
        status.label,
        style: GoogleFonts.hind(fontSize: 10.5, fontWeight: FontWeight.w700, color: textColor),
      ),
    );
  }
}

// ACTION
class _OrderAction extends StatelessWidget {
  const _OrderAction({required this.order, required this.onPressed});

  final ShopOrderListItem order;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    final label = _actionLabel(order);

    return SizedBox(
      width: double.infinity,
      height: 42,
      child: OutlinedButton(
        onPressed: onPressed,
        style: OutlinedButton.styleFrom(
          side: BorderSide(color: theme.colorScheme.outline.withValues(alpha: 0.8)),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(label, style: GoogleFonts.hind(fontSize: 12.5, fontWeight: FontWeight.w700)),
            const Gap(6),
            HugeIcon(
              icon: HugeIcons.strokeRoundedArrowRight01,
              size: 16,
              color: theme.colorScheme.primary,
            ),
          ],
        ),
      ),
    );
  }

  String _actionLabel(ShopOrderListItem order) {
    if (order.type == ShopOrderType.service) {
      switch (order.status) {
        case ShopOrderStatus.cancelled:
          return 'VIEW BOOKING';
        case ShopOrderStatus.completed:
          return 'VIEW BOOKING';
        default:
          return 'VIEW BOOKING';
      }
    }

    switch (order.status) {
      case ShopOrderStatus.delivered:
      case ShopOrderStatus.pickedUp:
      case ShopOrderStatus.completed:
        return 'VIEW ORDER';

      case ShopOrderStatus.cancelled:
        return 'VIEW ORDER';

      default:
        return 'TRACK ORDER';
    }
  }
}

// EMPTY STATE
class _EmptyOrdersState extends StatelessWidget {
  const _EmptyOrdersState({required this.filter, required this.onContinueShopping});

  final ShopOrdersFilter filter;
  final VoidCallback onContinueShopping;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    final title = switch (filter) {
      ShopOrdersFilter.all => 'No orders yet',
      ShopOrdersFilter.products => 'No product orders yet',
      ShopOrdersFilter.services => 'No service bookings yet',
    };

    final description = switch (filter) {
      ShopOrdersFilter.all => 'Your marketplace orders and service bookings will appear here.',
      ShopOrdersFilter.products =>
        'Products and food orders from your society marketplace will appear here.',
      ShopOrdersFilter.services =>
        'Your service bookings will appear here once you book a service.',
    };

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                color: theme.colorScheme.surfaceContainerHighest,
                shape: BoxShape.circle,
              ),
              child: HugeIcon(
                icon: filter == ShopOrdersFilter.services
                    ? HugeIcons.strokeRoundedTools
                    : HugeIcons.strokeRoundedShoppingCart02,
                size: 32,
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
            const Gap(18),
            Text(
              title,
              textAlign: TextAlign.center,
              style: GoogleFonts.hind(
                fontSize: 20,
                fontWeight: FontWeight.w700,
                color: theme.colorScheme.onSurface,
              ),
            ),
            const Gap(7),
            Text(
              description,
              textAlign: TextAlign.center,
              style: GoogleFonts.hind(
                fontSize: 13,
                height: 1.4,
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
            const Gap(20),
            SizedBox(
              height: 44,
              child: FilledButton(
                onPressed: onContinueShopping,
                style: FilledButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                child: Text(
                  'EXPLORE MARKETPLACE',
                  style: GoogleFonts.hind(fontSize: 12.5, fontWeight: FontWeight.w700),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// MODELS
enum ShopOrdersFilter { all, products, services }

enum ShopOrderType { product, service }

enum ShopOrderStatus {
  placed,
  confirmed,
  preparing,
  ready,
  outForDelivery,
  readyForPickup,
  delivered,
  pickedUp,
  completed,
  cancelled;

  String get label {
    switch (this) {
      case ShopOrderStatus.placed:
        return 'Placed';
      case ShopOrderStatus.confirmed:
        return 'Confirmed';
      case ShopOrderStatus.preparing:
        return 'Preparing';
      case ShopOrderStatus.ready:
        return 'Ready';
      case ShopOrderStatus.outForDelivery:
        return 'Out for delivery';
      case ShopOrderStatus.readyForPickup:
        return 'Ready for pickup';
      case ShopOrderStatus.delivered:
        return 'Delivered';
      case ShopOrderStatus.pickedUp:
        return 'Picked up';
      case ShopOrderStatus.completed:
        return 'Completed';
      case ShopOrderStatus.cancelled:
        return 'Cancelled';
    }
  }
}

class ShopOrderListItem {
  const ShopOrderListItem({
    required this.id,
    required this.reference,
    required this.type,
    required this.sellerId,
    required this.sellerName,
    required this.status,
    required this.items,
    required this.totalAmount,
    required this.dateLabel,
    this.fulfillmentLabel,
    this.timeLabel,
    this.orderResult,
  });

  final String id;
  final String reference;
  final ShopOrderType type;

  final String sellerId;
  final String sellerName;

  final ShopOrderStatus status;

  final List<ShopOrderListItemEntry> items;

  final double totalAmount;

  final String dateLabel;
  final String? timeLabel;
  final String? fulfillmentLabel;
  final ShopOrderResult? orderResult;
}

class ShopOrderListItemEntry {
  const ShopOrderListItemEntry({required this.name, required this.quantity});

  final String name;
  final int quantity;
}
