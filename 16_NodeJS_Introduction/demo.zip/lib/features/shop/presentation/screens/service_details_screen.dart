import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing_details.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_category_provider.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_listing_provider.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';

class ServiceDetailsScreen extends ConsumerStatefulWidget {
  const ServiceDetailsScreen({super.key, required this.serviceId, required this.listing});

  final String serviceId;
  final ShopListing? listing;

  @override
  ConsumerState<ServiceDetailsScreen> createState() => _ServiceDetailsScreenState();
}

class _ServiceDetailsScreenState extends ConsumerState<ServiceDetailsScreen> {
  ShopService get _service => ShopService(
    listing: widget.listing!,
    details: ref.read(shopServiceDetailsProvider(widget.serviceId)).valueOrNull,
  );

  DateTime? _selectedDate;
  ServiceScheduleSlot? _selectedSlot;
  ServiceLocationType _selectedLocation = ServiceLocationType.none;
  late final DateTime _scheduleFrom;
  late final DateTime _scheduleTo;

  @override
  void initState() {
    super.initState();
    _scheduleFrom = DateUtils.dateOnly(DateTime.now());
    _scheduleTo = _scheduleFrom.add(const Duration(days: 9));
  }

  bool get _canBook =>
      _selectedDate != null &&
      _selectedSlot != null &&
      _selectedLocation != ServiceLocationType.none;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final textTheme = GoogleFonts.hindTextTheme(theme.textTheme);
    final listing = widget.listing;
    if (listing == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Service details')),
        body: const Center(child: Text('Listing details are unavailable')),
      );
    }

    final detailsAsync = ref.watch(shopServiceDetailsProvider(widget.serviceId));
    final scheduleDatesArgs = (
      listingId: widget.serviceId,
      from: _formatScheduleDate(_scheduleFrom),
      to: _formatScheduleDate(_scheduleTo),
    );
    ref.listen(serviceScheduleDatesProvider(scheduleDatesArgs), (previous, next) {
      final dates = next.valueOrNull;
      if (dates == null || dates.isEmpty) return;
      if (_selectedDate != null && dates.any((date) => DateUtils.isSameDay(date, _selectedDate))) {
        return;
      }
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        setState(() {
          _selectedDate = dates.first;
          _selectedSlot = null;
        });
      });
    });
    final imagesAsync = ref.watch(shopListingImagesProvider(widget.serviceId));
    final imageUrl = imagesAsync.valueOrNull
        ?.where((image) => image.moderationStatus.toUpperCase() == 'APPROVED')
        .firstOrNull
        ?.imageUrl;

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      body: SafeArea(
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(child: _buildTopBar(context)),
            SliverToBoxAdapter(child: _buildServiceImage(context, imageUrl)),
            SliverToBoxAdapter(child: _buildServiceInfo(context, textTheme)),
            SliverToBoxAdapter(child: _buildDivider(context)),
            SliverToBoxAdapter(
              child: detailsAsync.when(
                loading: () => const Padding(
                  padding: EdgeInsets.all(20),
                  child: Center(child: CircularProgressIndicator()),
                ),
                error: (error, stackTrace) => TextButton.icon(
                  onPressed: () => ref.invalidate(shopServiceDetailsProvider(widget.serviceId)),
                  icon: const Icon(Icons.refresh),
                  label: const Text('Unable to load service details. Try again.'),
                ),
                data: (details) => _buildServiceAttributes(context, textTheme, details),
              ),
            ),
            SliverToBoxAdapter(child: _buildDivider(context)),
            SliverToBoxAdapter(child: _buildAboutSection(context, textTheme)),
            SliverToBoxAdapter(child: _buildDivider(context)),
            SliverToBoxAdapter(child: _buildSellerSection(context, textTheme)),
            SliverToBoxAdapter(child: _buildDivider(context)),
            SliverToBoxAdapter(child: _buildDateSection(context, textTheme)),
            SliverToBoxAdapter(child: _buildSlotSection(context, textTheme)),
            SliverToBoxAdapter(child: _buildLocationSection(context, textTheme)),
            const SliverToBoxAdapter(child: Gap(120)),
          ],
        ),
      ),
      bottomNavigationBar: _buildBottomBar(context, textTheme),
    );
  }

  // TOP BAR
  Widget _buildTopBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
      child: Row(
        children: [
          _CircleActionButton(
            icon: HugeIcons.strokeRoundedArrowLeft01,
            onTap: () {
              Navigator.of(context).pop();
            },
          ),
          const Spacer(),
          _CircleActionButton(
            icon: HugeIcons.strokeRoundedShare08,
            onTap: () {
              // TODO share service
            },
          ),
        ],
      ),
    );
  }

  // SERVICE IMAGE
  Widget _buildServiceImage(BuildContext context, String? imageUrl) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        height: 280,
        width: double.infinity,
        decoration: BoxDecoration(
          color: theme.colorScheme.secondaryContainer,
          borderRadius: BorderRadius.circular(26),
        ),
        child: imageUrl == null
            ? Center(
                child: HugeIcon(
                  icon: HugeIcons.strokeRoundedTools,
                  size: 70,
                  color: theme.colorScheme.onSecondaryContainer.withValues(alpha: 0.65),
                ),
              )
            : ClipRRect(
                borderRadius: BorderRadius.circular(26),
                child: Image.network(
                  imageUrl,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) => Center(
                    child: HugeIcon(
                      icon: HugeIcons.strokeRoundedTools,
                      size: 70,
                      color: theme.colorScheme.onSecondaryContainer.withValues(alpha: 0.65),
                    ),
                  ),
                ),
              ),
      ),
    );
  }

  Widget _buildServiceAttributes(
    BuildContext context,
    TextTheme textTheme,
    ShopServiceDetails details,
  ) {
    final theme = Theme.of(context);
    final attributes = <String>[
      if (details.serviceDurationMinutes > 0) '${details.serviceDurationMinutes} minute service',
      if (details.serviceLocationType.isNotEmpty)
        'Location: ${details.serviceLocationType.replaceAll('_', ' ').toLowerCase()}',
      if (details.homeVisitAvailable) 'Home visits available',
      if (details.onlineAvailable) 'Online service available',
      if (details.certificateRequired) 'Certificate required',
      if (details.requiredMaterials?.trim().isNotEmpty == true)
        'Required materials: ${details.requiredMaterials}',
      if (details.cancellationPolicy?.trim().isNotEmpty == true)
        'Cancellation policy: ${details.cancellationPolicy}',
    ];

    if (attributes.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Service details',
            style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800),
          ),
          const Gap(10),
          for (final attribute in attributes)
            Padding(
              padding: const EdgeInsets.only(bottom: 7),
              child: Row(
                children: [
                  HugeIcon(
                    icon: HugeIcons.strokeRoundedCheckmarkCircle02,
                    size: 17,
                    color: theme.colorScheme.primary,
                  ),
                  const Gap(8),
                  Expanded(child: Text(attribute, style: textTheme.bodyMedium)),
                ],
              ),
            ),
        ],
      ),
    );
  }

  // SERVICE INFORMATION
  Widget _buildServiceInfo(BuildContext context, TextTheme textTheme) {
    final theme = Theme.of(context);
    final category = ref.watch(categoryByIdProvider(_service.category)).valueOrNull;
    final categoryName = category?.name.trim().isNotEmpty == true
        ? category!.slug
        : _service.category;

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _service.name,
            style: textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800, height: 1.1),
          ),

          const Gap(5),

          Text(
            categoryName,
            style: textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
              fontWeight: FontWeight.w500,
            ),
          ),

          const Gap(13),

          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                decoration: BoxDecoration(
                  color: theme.colorScheme.primaryContainer,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    HugeIcon(
                      icon: HugeIcons.strokeRoundedStar,
                      size: 15,
                      color: theme.colorScheme.onPrimaryContainer,
                    ),
                    const Gap(4),
                    Text(
                      _service.rating.toStringAsFixed(1),
                      style: textTheme.labelLarge?.copyWith(
                        fontWeight: FontWeight.w800,
                        color: theme.colorScheme.onPrimaryContainer,
                      ),
                    ),
                  ],
                ),
              ),

              const Gap(8),

              Text(
                '${_service.reviewCount} reviews',
                style: textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),

          const Gap(16),

          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '₹${_service.startingPrice}',
                style: textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800),
              ),
              const Gap(7),
              Padding(
                padding: const EdgeInsets.only(bottom: 3),
                child: Text(
                  'starting price',
                  style: textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                ),
              ),
            ],
          ),

          const Gap(10),

          Row(
            children: [
              HugeIcon(
                icon: HugeIcons.strokeRoundedClock01,
                size: 17,
                color: theme.colorScheme.primary,
              ),
              const Gap(6),
              Text(
                '${_service.durationMinutes} min service',
                style: textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ABOUT
  Widget _buildAboutSection(BuildContext context, TextTheme textTheme) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'About this service',
            style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800),
          ),
          const Gap(8),
          Text(
            _service.description,
            style: textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
              height: 1.45,
            ),
          ),
          const Gap(14),
          ..._service.highlights.map(
            (highlight) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  HugeIcon(
                    icon: HugeIcons.strokeRoundedCheckmarkCircle02,
                    size: 18,
                    color: theme.colorScheme.primary,
                  ),
                  const Gap(8),
                  Expanded(
                    child: Text(highlight, style: textTheme.bodyMedium?.copyWith(height: 1.25)),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // SELLER
  Widget _buildSellerSection(BuildContext context, TextTheme textTheme) {
    final theme = Theme.of(context);
    final seller = ref.watch(sellerProfileByIdProvider(_service.sellerId)).valueOrNull;
    final sellerName = seller?.displayName.trim().isNotEmpty == true
        ? seller!.displayName
        : _service.sellerName;
    final sellerRating = seller?.averageRating ?? _service.sellerRating;
    final sellerReviewCount = seller?.totalReviews ?? _service.sellerReviewCount;

    return InkWell(
      onTap: () => context.push('/shop/seller/${_service.sellerId}'),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 18, 16, 18),
        child: Row(
          children: [
            Container(
              height: 54,
              width: 54,
              decoration: BoxDecoration(
                color: theme.colorScheme.secondaryContainer,
                borderRadius: BorderRadius.circular(16),
              ),
              child: HugeIcon(
                icon: HugeIcons.strokeRoundedStore01,
                size: 26,
                color: theme.colorScheme.onSecondaryContainer,
              ),
            ),

            const Gap(12),

            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Flexible(
                        child: Text(
                          sellerName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800),
                        ),
                      ),
                      const Gap(5),
                      HugeIcon(
                        icon: HugeIcons.strokeRoundedCheckmarkCircle02,
                        size: 16,
                        color: theme.colorScheme.primary,
                      ),
                    ],
                  ),
                  const Gap(2),
                  Row(
                    children: [
                      HugeIcon(
                        icon: HugeIcons.strokeRoundedStar,
                        size: 14,
                        color: theme.colorScheme.primary,
                      ),
                      const Gap(3),
                      Text(
                        '${sellerRating.toStringAsFixed(1)} · $sellerReviewCount reviews',
                        style: textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            HugeIcon(
              icon: HugeIcons.strokeRoundedArrowRight01,
              size: 20,
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ],
        ),
      ),
    );
  }

  // DATE
  Widget _buildDateSection(BuildContext context, TextTheme textTheme) {
    final theme = Theme.of(context);
    final datesAsync = ref.watch(
      serviceScheduleDatesProvider((
        listingId: widget.serviceId,
        from: _formatScheduleDate(_scheduleFrom),
        to: _formatScheduleDate(_scheduleTo),
      )),
    );

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 22, 16, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Choose a date',
            style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800),
          ),

          const Gap(4),

          Text(
            'Available dates are based on the seller\'s schedule.',
            style: textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant),
          ),

          const Gap(13),

          datesAsync.when(
            loading: () =>
                const SizedBox(height: 78, child: Center(child: CircularProgressIndicator())),
            error: (error, stackTrace) => SizedBox(
              height: 78,
              child: Center(
                child: TextButton.icon(
                  onPressed: () => ref.invalidate(
                    serviceScheduleDatesProvider((
                      listingId: widget.serviceId,
                      from: _formatScheduleDate(_scheduleFrom),
                      to: _formatScheduleDate(_scheduleTo),
                    )),
                  ),
                  icon: const Icon(Icons.refresh),
                  label: const Text('Unable to load available dates'),
                ),
              ),
            ),
            data: (dates) => dates.isEmpty
                ? const SizedBox(
                    height: 56,
                    child: Center(child: Text('No available dates in this period')),
                  )
                : SizedBox(
                    height: 78,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      physics: const BouncingScrollPhysics(),
                      itemCount: dates.length,
                      separatorBuilder: (_, _) => const Gap(9),
                      itemBuilder: (context, index) {
                        final date = dates[index];
                        return _DateOption(
                          date: date,
                          selected: _isSameDate(date, _selectedDate),
                          onTap: () {
                            setState(() {
                              _selectedDate = date;
                              _selectedSlot = null;
                            });
                          },
                        );
                      },
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  // SLOT
  Widget _buildSlotSection(BuildContext context, TextTheme textTheme) {
    final theme = Theme.of(context);

    if (_selectedDate == null) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(16, 22, 16, 8),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.55),
            borderRadius: BorderRadius.circular(14),
          ),
          child: Row(
            children: [
              HugeIcon(
                icon: HugeIcons.strokeRoundedCalendar03,
                size: 19,
                color: theme.colorScheme.onSurfaceVariant,
              ),
              const Gap(9),
              Expanded(
                child: Text(
                  'Select a date to see available time slots.',
                  style: textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                ),
              ),
            ],
          ),
        ),
      );
    }

    final args = (listingId: widget.serviceId, date: _formatScheduleDate(_selectedDate!));
    final slotsAsync = ref.watch(serviceScheduleSlotsProvider(args));

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 22, 16, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Choose a time',
            style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800),
          ),

          const Gap(12),

          slotsAsync.when(
            loading: () => const Padding(
              padding: EdgeInsets.symmetric(vertical: 8),
              child: Center(child: CircularProgressIndicator()),
            ),
            error: (error, stackTrace) => TextButton.icon(
              onPressed: () => ref.invalidate(serviceScheduleSlotsProvider(args)),
              icon: const Icon(Icons.refresh),
              label: const Text('Unable to load time slots'),
            ),
            data: (slots) => slots.isEmpty
                ? Text(
                    'No available time slots for this date.',
                    style: textTheme.bodyMedium?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  )
                : Wrap(
                    spacing: 9,
                    runSpacing: 9,
                    children: slots.map((slot) {
                      final selected = _selectedSlot?.startsAt == slot.startsAt;
                      return _SlotOption(
                        label: _formatScheduleSlot(context, slot),
                        selected: selected,
                        onTap: () => setState(() => _selectedSlot = slot),
                      );
                    }).toList(),
                  ),
          ),
        ],
      ),
    );
  }

  // LOCATION
  Widget _buildLocationSection(BuildContext context, TextTheme textTheme) {
    final detailsAsync = ref.watch(shopServiceDetailsProvider(widget.serviceId));
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 22, 16, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Service location',
            style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800),
          ),

          const Gap(12),
          detailsAsync.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (error, stackTrace) => TextButton.icon(
              onPressed: () => ref.invalidate(shopServiceDetailsProvider(widget.serviceId)),
              icon: const Icon(Icons.refresh),
              label: const Text('Unable to load service locations'),
            ),
            data: (details) {
              final options = _locationOptions(details);
              if (options.isEmpty) {
                return Text(
                  'No service location options are available.',
                  style: textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                );
              }
              return Column(
                children: [
                  for (final (index, option) in options.indexed) ...[
                    if (index > 0) const Gap(9),
                    _LocationOption(
                      icon: option.icon,
                      title: option.title,
                      subtitle: option.subtitle,
                      selected: _selectedLocation == option.value,
                      onTap: () => setState(() => _selectedLocation = option.value),
                    ),
                  ],
                ],
              );
            },
          ),
        ],
      ),
    );
  }

  // BOTTOM CTA
  Widget _buildBottomBar(BuildContext context, TextTheme textTheme) {
    final theme = Theme.of(context);
    final actionLabel = _selectedDate == null
        ? 'SELECT A DATE'
        : _selectedSlot == null
        ? 'SELECT A TIME'
        : _selectedLocation == ServiceLocationType.none
        ? 'SELECT A LOCATION'
        : 'CONTINUE BOOKING';

    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        border: Border(
          top: BorderSide(color: theme.colorScheme.outlineVariant.withValues(alpha: 0.5)),
        ),
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 11, 16, 10),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Starting from',
                      style: textTheme.labelSmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                    Text(
                      '₹${_service.startingPrice}',
                      style: textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800),
                    ),
                  ],
                ),
              ),

              const Gap(12),

              Expanded(
                flex: 2,
                child: SizedBox(
                  height: 50,
                  child: FilledButton(
                    onPressed: _canBook ? _continueBooking : null,
                    style: FilledButton.styleFrom(
                      backgroundColor: theme.colorScheme.primary,
                      disabledBackgroundColor: theme.colorScheme.surfaceContainerHighest,
                      foregroundColor: theme.colorScheme.onPrimary,
                      disabledForegroundColor: theme.colorScheme.onSurfaceVariant,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                    child: Text(
                      actionLabel,
                      style: textTheme.labelLarge?.copyWith(
                        fontWeight: FontWeight.w800,
                        color: _canBook
                            ? theme.colorScheme.onPrimary
                            : theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _continueBooking() {
    // At this point we have:
    //
    // serviceId
    // selectedDate
    // selectedSlot
    // selectedLocation
    //
    // Next screen:
    // Service Booking Confirmation
    //
    // TODO:
    // context.push(
    //   '/shop/service/${_service.id}/booking',
    //   extra: BookingSelection(...),
    // );
  }

  Widget _buildDivider(BuildContext context) {
    final theme = Theme.of(context);

    return Divider(
      height: 1,
      thickness: 1,
      color: theme.colorScheme.outlineVariant.withValues(alpha: 0.45),
    );
  }

  bool _isSameDate(DateTime? a, DateTime? b) {
    if (a == null || b == null) {
      return false;
    }

    return a.year == b.year && a.month == b.month && a.day == b.day;
  }
}

// DATE OPTION
class _DateOption extends StatelessWidget {
  const _DateOption({required this.date, required this.selected, required this.onTap});

  final DateTime date;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final textTheme = GoogleFonts.hindTextTheme(theme.textTheme);

    final weekdays = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        width: 64,
        decoration: BoxDecoration(
          color: selected ? theme.colorScheme.primary : theme.colorScheme.surface,
          borderRadius: BorderRadius.circular(15),
          border: Border.all(
            color: selected ? theme.colorScheme.primary : theme.colorScheme.outlineVariant,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              weekdays[date.weekday - 1],
              style: textTheme.labelSmall?.copyWith(
                fontWeight: FontWeight.w700,
                color: selected ? theme.colorScheme.onPrimary : theme.colorScheme.onSurfaceVariant,
              ),
            ),
            const Gap(3),
            Text(
              '${date.day}',
              style: textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w800,
                color: selected ? theme.colorScheme.onPrimary : theme.colorScheme.onSurface,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// SLOT OPTION
class _SlotOption extends StatelessWidget {
  const _SlotOption({required this.label, required this.selected, required this.onTap});

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final textTheme = GoogleFonts.hindTextTheme(theme.textTheme);

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
        decoration: BoxDecoration(
          color: selected ? theme.colorScheme.primaryContainer : theme.colorScheme.surface,
          borderRadius: BorderRadius.circular(11),
          border: Border.all(
            color: selected ? theme.colorScheme.primary : theme.colorScheme.outlineVariant,
          ),
        ),
        child: Text(
          label,
          style: textTheme.labelLarge?.copyWith(
            fontWeight: FontWeight.w700,
            color: selected ? theme.colorScheme.onPrimaryContainer : theme.colorScheme.onSurface,
          ),
        ),
      ),
    );
  }
}

// LOCATION OPTION
class _LocationOption extends StatelessWidget {
  const _LocationOption({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.selected,
    required this.onTap,
  });

  final dynamic icon;
  final String title;
  final String subtitle;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final textTheme = GoogleFonts.hindTextTheme(theme.textTheme);

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(
          color: selected
              ? theme.colorScheme.primaryContainer.withValues(alpha: 0.55)
              : theme.colorScheme.surface,
          borderRadius: BorderRadius.circular(15),
          border: Border.all(
            color: selected ? theme.colorScheme.primary : theme.colorScheme.outlineVariant,
          ),
        ),
        child: Row(
          children: [
            Container(
              height: 40,
              width: 40,
              decoration: BoxDecoration(
                color: selected
                    ? theme.colorScheme.primary
                    : theme.colorScheme.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(11),
              ),
              child: Center(
                child: HugeIcon(
                  icon: icon,
                  size: 19,
                  color: selected
                      ? theme.colorScheme.onPrimary
                      : theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ),

            const Gap(11),

            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800)),
                  Text(
                    subtitle,
                    style: textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                  ),
                ],
              ),
            ),

            Container(
              height: 21,
              width: 21,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: selected ? theme.colorScheme.primary : theme.colorScheme.outline,
                  width: 2,
                ),
              ),
              child: selected
                  ? Center(
                      child: Container(
                        height: 9,
                        width: 9,
                        decoration: BoxDecoration(
                          color: theme.colorScheme.primary,
                          shape: BoxShape.circle,
                        ),
                      ),
                    )
                  : null,
            ),
          ],
        ),
      ),
    );
  }
}

// TOP ACTION
class _CircleActionButton extends StatelessWidget {
  const _CircleActionButton({required this.icon, required this.onTap});

  final dynamic icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Material(
      color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.72),
      borderRadius: BorderRadius.circular(13),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(13),
        child: SizedBox(
          height: 42,
          width: 42,
          child: Center(
            child: HugeIcon(icon: icon, size: 21, color: theme.colorScheme.onSurface),
          ),
        ),
      ),
    );
  }
}

// LOCATION TYPE
enum ServiceLocationType { none, myFlat, commonLocation, sellerLocation, online, other }

List<({ServiceLocationType value, String title, String subtitle, dynamic icon})> _locationOptions(
  ShopServiceDetails details,
) {
  final locationType = details.serviceLocationType.trim().toUpperCase();
  final options = <({ServiceLocationType value, String title, String subtitle, dynamic icon})>[];

  void add(ServiceLocationType value, String title, String subtitle, dynamic icon) {
    if (options.any((option) => option.value == value)) return;
    options.add((value: value, title: title, subtitle: subtitle, icon: icon));
  }

  if (locationType == 'BUYER_FLAT' ||
      details.homeVisitAvailable ||
      locationType == 'ANYWHERE' ||
      locationType == 'FLEXIBLE') {
    add(
      ServiceLocationType.myFlat,
      'My flat',
      'The service provider visits your flat',
      HugeIcons.strokeRoundedHome01,
    );
  }
  if (locationType == 'COMMON_AREA' ||
      locationType == 'COMMON_LOCATION' ||
      locationType == 'ANYWHERE' ||
      locationType == 'FLEXIBLE') {
    add(
      ServiceLocationType.commonLocation,
      'Common location',
      'Meet the seller at a society location',
      HugeIcons.strokeRoundedLocation01,
    );
  }
  if (locationType == 'SELLER_LOCATION' || locationType == 'SELLER_PREMISES') {
    add(
      ServiceLocationType.sellerLocation,
      'Seller location',
      'Visit the service provider',
      HugeIcons.strokeRoundedStore01,
    );
  }
  if (details.onlineAvailable || locationType == 'ONLINE') {
    add(
      ServiceLocationType.online,
      'Online',
      'Connect with the service provider online',
      HugeIcons.strokeRoundedComputerPhoneSync,
    );
  }
  if (options.isEmpty && locationType.isNotEmpty) {
    final label = locationType.replaceAll('_', ' ').toLowerCase();
    add(ServiceLocationType.other, label, 'Service location', HugeIcons.strokeRoundedLocation01);
  }
  return options;
}

String _formatScheduleDate(DateTime date) =>
    '${date.year.toString().padLeft(4, '0')}-'
    '${date.month.toString().padLeft(2, '0')}-'
    '${date.day.toString().padLeft(2, '0')}';

String _formatScheduleSlot(BuildContext context, ServiceScheduleSlot slot) {
  final start = TimeOfDay.fromDateTime(slot.startsAt).format(context);
  final end = TimeOfDay.fromDateTime(slot.endsAt).format(context);
  return '$start - $end';
}

// Screen projection over the listing summary and service detail response.
class ShopService {
  const ShopService({required this.listing, this.details});

  final ShopListing listing;
  final ShopServiceDetails? details;

  String get id => listing.id;
  String get name => listing.title;
  String get category => listing.categoryId;
  String get description => listing.description;
  double get startingPrice => listing.basePrice;
  double get rating => listing.averageRating;
  int get reviewCount => listing.totalReviews;
  int get durationMinutes => details?.serviceDurationMinutes ?? 0;
  String get sellerId => listing.sellerId;
  String get sellerName => 'Seller';
  double get sellerRating => listing.averageRating;
  int get sellerReviewCount => listing.totalReviews;
  List<String> get highlights => [
    if (details?.homeVisitAvailable == true) 'Home visits available',
    if (details?.onlineAvailable == true) 'Online service available',
    if (details?.serviceLocationType.isNotEmpty == true)
      'Service location: ${details!.serviceLocationType.replaceAll('_', ' ').toLowerCase()}',
    if (details?.certificateRequired == true) 'Certificate required',
  ];
}
