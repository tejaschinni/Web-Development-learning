import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/shop/data/models/shop_checkout_models.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_cart_provider.dart';

class ShopOrderTrackingScreen extends ConsumerStatefulWidget {
  const ShopOrderTrackingScreen({super.key, required this.orderData});

  final ShopOrderTrackingData orderData;

  @override
  ConsumerState<ShopOrderTrackingScreen> createState() => _ShopOrderTrackingScreenState();
}

class _ShopOrderTrackingScreenState extends ConsumerState<ShopOrderTrackingScreen> {
  late Future<List<ShopOrderHistoryEntry>> _historyFuture;
  bool _confirmingReceipt = false;
  bool _receiptConfirmed = false;

  @override
  void initState() {
    super.initState();
    _historyFuture = ref
        .read(shopCheckoutRemoteDataSourceProvider)
        .getOrderHistory(widget.orderData.orderId);
  }

  Future<void> _confirmReceipt() async {
    setState(() => _confirmingReceipt = true);
    try {
      await ref.read(shopCheckoutRemoteDataSourceProvider).confirmReceipt(widget.orderData.orderId);
      if (!mounted) return;
      setState(() => _receiptConfirmed = true);
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Receipt confirmed. Thank you.')));
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Unable to confirm receipt: $error')));
    } finally {
      if (mounted) setState(() => _confirmingReceipt = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final orderData = widget.orderData;
    final sellerProfile = ref.watch(sellerProfileByIdProvider(orderData.sellerId)).valueOrNull;
    final sellerName = sellerProfile?.displayName.trim().isNotEmpty == true
        ? sellerProfile!.displayName.trim()
        : sellerProfile?.businessName?.trim().isNotEmpty == true
        ? sellerProfile!.businessName!.trim()
        : orderData.sellerName;
    final canConfirmReceipt =
        orderData.status == ShopOrderStatus.delivered &&
        orderData.paymentMethodLabel.toUpperCase().contains('CASH') &&
        !_receiptConfirmed;

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      appBar: AppBar(
        backgroundColor: theme.colorScheme.surface,
        elevation: 0,
        leading: IconButton(
          onPressed: () => Navigator.of(context).pop(),
          icon: HugeIcon(
            icon: HugeIcons.strokeRoundedArrowLeft01,
            size: 24,
            color: theme.colorScheme.onSurface,
          ),
        ),
        title: Text(
          'Track order',
          style: GoogleFonts.hind(
            fontSize: 20,
            fontWeight: FontWeight.w700,
            color: theme.colorScheme.onSurface,
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _OrderStatusHeader(orderData: orderData),
                    const Gap(20),
                    _OrderProgress(orderData: orderData),
                    const Gap(20),
                    _OrderHistoryCard(historyFuture: _historyFuture),
                    const Gap(20),
                    _FulfillmentCard(orderData: orderData),
                    const Gap(20),
                    _ItemsSection(orderData: orderData),
                    const Gap(20),
                    _PriceBreakdownCard(orderData: orderData),
                    const Gap(20),
                    _OrderSummaryCard(orderData: orderData, sellerName: sellerName),
                    const Gap(20),
                    _HelpCard(),
                  ],
                ),
              ),
            ),
            _BottomActions(
              onConfirmReceipt: canConfirmReceipt ? _confirmReceipt : null,
              confirmingReceipt: _confirmingReceipt,
              onViewDetails: () {
                // TODO:
                // Navigate to the existing order details screen.
                //
                // Example:
                // context.push(
                //   '/shop/orders/${orderData.orderId}',
                // );
              },
              onContact: () {
                // TODO:
                // Open the existing support/contact flow.
              },
            ),
          ],
        ),
      ),
    );
  }
}

// STATUS HEADER
class _OrderStatusHeader extends StatelessWidget {
  const _OrderStatusHeader({required this.orderData});

  final ShopOrderTrackingData orderData;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: theme.colorScheme.primary.withValues(alpha: 0.06),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: theme.colorScheme.primary.withValues(alpha: 0.12)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: theme.colorScheme.primary.withValues(alpha: 0.10),
              borderRadius: BorderRadius.circular(14),
            ),
            child: HugeIcon(
              icon: _statusIcon(orderData.status),
              size: 25,
              color: theme.colorScheme.primary,
            ),
          ),
          const Gap(13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  orderData.statusTitle,
                  style: GoogleFonts.hind(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: theme.colorScheme.onSurface,
                  ),
                ),
                const Gap(2),
                Text(
                  orderData.statusDescription,
                  style: GoogleFonts.hind(
                    fontSize: 13,
                    height: 1.35,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
                if (orderData.etaLabel != null) ...[
                  const Gap(9),
                  Text(
                    orderData.etaLabel!,
                    style: GoogleFonts.hind(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: theme.colorScheme.primary,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  dynamic _statusIcon(ShopOrderStatus status) {
    switch (status) {
      case ShopOrderStatus.placed:
        return HugeIcons.strokeRoundedCheckmarkCircle02;
      case ShopOrderStatus.confirmed:
        return HugeIcons.strokeRoundedCheckmarkCircle02;
      case ShopOrderStatus.preparing:
        return HugeIcons.strokeRoundedTimer01;
      case ShopOrderStatus.ready:
        return HugeIcons.strokeRoundedCheckmarkCircle02;
      case ShopOrderStatus.outForDelivery:
        return HugeIcons.strokeRoundedLocation01;
      case ShopOrderStatus.readyForPickup:
        return HugeIcons.strokeRoundedStore01;
      case ShopOrderStatus.delivered:
        return HugeIcons.strokeRoundedCheckmarkCircle02;
      case ShopOrderStatus.pickedUp:
        return HugeIcons.strokeRoundedCheckmarkCircle02;
      case ShopOrderStatus.cancelled:
        return HugeIcons.strokeRoundedInformationCircle;
    }
  }
}

// ORDER PROGRESS
class _OrderProgress extends StatelessWidget {
  const _OrderProgress({required this.orderData});

  final ShopOrderTrackingData orderData;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    final steps = _buildSteps(orderData);

    return _SectionCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Order progress',
            style: GoogleFonts.hind(
              fontSize: 17,
              fontWeight: FontWeight.w700,
              color: theme.colorScheme.onSurface,
            ),
          ),
          const Gap(18),
          ...List.generate(
            steps.length,
            (index) => _ProgressStep(step: steps[index], isLast: index == steps.length - 1),
          ),
        ],
      ),
    );
  }

  List<_ProgressStepData> _buildSteps(ShopOrderTrackingData data) {
    if (data.fulfillmentMethod == ShopTrackingFulfillmentMethod.pickup) {
      return [
        _ProgressStepData(
          title: 'Order placed',
          description: 'Your order has been received.',
          status: _stepStatus(0),
        ),
        _ProgressStepData(
          title: 'Order confirmed',
          description: 'The seller has confirmed your order.',
          status: _stepStatus(1),
        ),
        _ProgressStepData(
          title: 'Preparing your order',
          description: 'The seller is getting your order ready.',
          status: _stepStatus(2),
        ),
        _ProgressStepData(
          title: 'Ready for pickup',
          description: 'Your order is ready to collect.',
          status: _stepStatus(3),
        ),
        _ProgressStepData(
          title: 'Picked up',
          description: 'Order collected successfully.',
          status: _stepStatus(4),
        ),
      ];
    }

    return [
      _ProgressStepData(
        title: 'Order placed',
        description: 'Your order has been received.',
        status: _stepStatus(0),
      ),
      _ProgressStepData(
        title: 'Order confirmed',
        description: 'The seller has confirmed your order.',
        status: _stepStatus(1),
      ),
      _ProgressStepData(
        title: 'Preparing your order',
        description: 'The seller is getting your order ready.',
        status: _stepStatus(2),
      ),
      _ProgressStepData(
        title: 'Out for delivery',
        description: 'Your order is on its way.',
        status: _stepStatus(3),
      ),
      _ProgressStepData(
        title: 'Delivered',
        description: 'Order delivered successfully.',
        status: _stepStatus(4),
      ),
    ];
  }

  _ProgressStatus _stepStatus(int stepIndex) {
    final currentIndex = _currentProgressIndex(orderData.status);

    if (orderData.status == ShopOrderStatus.cancelled) {
      return _ProgressStatus.cancelled;
    }

    if (stepIndex < currentIndex) {
      return _ProgressStatus.completed;
    }

    if (stepIndex == currentIndex) {
      return _ProgressStatus.current;
    }

    return _ProgressStatus.upcoming;
  }

  int _currentProgressIndex(ShopOrderStatus status) {
    switch (status) {
      case ShopOrderStatus.placed:
        return 0;
      case ShopOrderStatus.confirmed:
        return 1;
      case ShopOrderStatus.preparing:
        return 2;
      case ShopOrderStatus.ready:
        return 3;
      case ShopOrderStatus.outForDelivery:
        return 3;
      case ShopOrderStatus.readyForPickup:
        return 3;
      case ShopOrderStatus.delivered:
        return 4;
      case ShopOrderStatus.pickedUp:
        return 4;
      case ShopOrderStatus.cancelled:
        return 0;
    }
  }
}

class _ProgressStep extends StatelessWidget {
  const _ProgressStep({required this.step, required this.isLast});

  final _ProgressStepData step;
  final bool isLast;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    final isCompleted = step.status == _ProgressStatus.completed;
    final isCurrent = step.status == _ProgressStatus.current;
    final isCancelled = step.status == _ProgressStatus.cancelled;

    final indicatorColor = isCancelled
        ? theme.colorScheme.error
        : (isCompleted || isCurrent ? theme.colorScheme.primary : theme.colorScheme.outlineVariant);

    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 28,
            child: Column(
              children: [
                Container(
                  width: isCurrent ? 17 : 14,
                  height: isCurrent ? 17 : 14,
                  decoration: BoxDecoration(
                    color: isCompleted ? indicatorColor : theme.colorScheme.surface,
                    border: Border.all(color: indicatorColor, width: isCurrent ? 2.5 : 2),
                    shape: BoxShape.circle,
                  ),
                  child: isCompleted
                      ? HugeIcon(
                          icon: HugeIcons.strokeRoundedCheckmarkCircle02,
                          size: 12,
                          color: theme.colorScheme.onPrimary,
                        )
                      : null,
                ),
                if (!isLast)
                  Expanded(
                    child: Container(
                      width: 1.5,
                      margin: const EdgeInsets.symmetric(vertical: 3),
                      color: isCompleted
                          ? theme.colorScheme.primary
                          : theme.colorScheme.outlineVariant,
                    ),
                  ),
              ],
            ),
          ),
          const Gap(12),
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(bottom: isLast ? 0 : 20, top: isCurrent ? 0 : 1),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    step.title,
                    style: GoogleFonts.hind(
                      fontSize: 14,
                      fontWeight: isCurrent || isCompleted ? FontWeight.w700 : FontWeight.w500,
                      color: isCancelled
                          ? theme.colorScheme.error
                          : (isCurrent || isCompleted
                                ? theme.colorScheme.onSurface
                                : theme.colorScheme.onSurfaceVariant),
                    ),
                  ),
                  const Gap(2),
                  Text(
                    step.description,
                    style: GoogleFonts.hind(
                      fontSize: 12,
                      height: 1.3,
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// FULFILLMENT
class _FulfillmentCard extends StatelessWidget {
  const _FulfillmentCard({required this.orderData});

  final ShopOrderTrackingData orderData;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return _SectionCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Fulfillment',
            style: GoogleFonts.hind(
              fontSize: 17,
              fontWeight: FontWeight.w700,
              color: theme.colorScheme.onSurface,
            ),
          ),
          const Gap(14),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              HugeIcon(
                icon: orderData.fulfillmentMethod == ShopTrackingFulfillmentMethod.pickup
                    ? HugeIcons.strokeRoundedStore01
                    : HugeIcons.strokeRoundedLocation01,
                size: 21,
                color: theme.colorScheme.primary,
              ),
              const Gap(10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      orderData.fulfillmentTitle,
                      style: GoogleFonts.hind(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: theme.colorScheme.onSurface,
                      ),
                    ),
                    const Gap(2),
                    Text(
                      orderData.fulfillmentDetail,
                      style: GoogleFonts.hind(
                        fontSize: 13,
                        height: 1.35,
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                    if (orderData.etaLabel != null) ...[
                      const Gap(7),
                      Text(
                        'Scheduled: ${orderData.etaLabel}',
                        style: GoogleFonts.hind(
                          fontSize: 12,
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                    if (orderData.deliveryInstructions?.trim().isNotEmpty == true) ...[
                      const Gap(7),
                      Text(
                        'Instructions: ${orderData.deliveryInstructions}',
                        style: GoogleFonts.hind(
                          fontSize: 12,
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ITEMS
class _ItemsSection extends StatelessWidget {
  const _ItemsSection({required this.orderData});

  final ShopOrderTrackingData orderData;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Items',
          style: GoogleFonts.hind(
            fontSize: 17,
            fontWeight: FontWeight.w700,
            color: theme.colorScheme.onSurface,
          ),
        ),
        const Gap(10),
        _SectionCard(
          child: Column(
            children: [
              ...orderData.items.map(
                (item) => Padding(
                  padding: const EdgeInsets.only(bottom: 14),
                  child: _OrderItemRow(item: item),
                ),
              ),
              if (orderData.items.isNotEmpty)
                Divider(height: 1, color: theme.colorScheme.outlineVariant),
              const Gap(12),
              Row(
                children: [
                  Text(
                    '${orderData.items.fold<int>(0, (sum, item) => sum + item.quantity)} items',
                    style: GoogleFonts.hind(
                      fontSize: 12,
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                  const Spacer(),
                  Text(
                    '₹${orderData.subtotal.toStringAsFixed(0)}',
                    style: GoogleFonts.hind(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      color: theme.colorScheme.onSurface,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _PriceBreakdownCard extends StatelessWidget {
  const _PriceBreakdownCard({required this.orderData});

  final ShopOrderTrackingData orderData;

  @override
  Widget build(BuildContext context) {
    String price(double amount) => '₹${amount.toStringAsFixed(amount % 1 == 0 ? 0 : 2)}';

    return _SectionCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Price breakdown',
            style: GoogleFonts.hind(fontSize: 17, fontWeight: FontWeight.w700),
          ),
          const Gap(14),
          _SummaryRow(label: 'Items subtotal', value: price(orderData.subtotal)),
          if (orderData.discountAmount > 0) ...[
            const Gap(8),
            _SummaryRow(label: 'Discount', value: '-${price(orderData.discountAmount)}'),
          ],
          const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Divider(height: 1)),
          _SummaryRow(label: 'Buyer total', value: price(orderData.totalAmount), isTotal: true),
          if (orderData.platformCommission > 0 ||
              orderData.welfareFundAmount > 0 ||
              orderData.sellerEarning > 0) ...[
            const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Divider(height: 1)),
            Text(
              'Seller settlement',
              style: GoogleFonts.hind(fontSize: 13, fontWeight: FontWeight.w700),
            ),
            if (orderData.platformCommission > 0) ...[
              const Gap(8),
              _SummaryRow(label: 'Platform commission', value: price(orderData.platformCommission)),
            ],
            if (orderData.welfareFundAmount > 0) ...[
              const Gap(8),
              _SummaryRow(label: 'Welfare fund', value: price(orderData.welfareFundAmount)),
            ],
            if (orderData.sellerEarning > 0) ...[
              const Gap(8),
              _SummaryRow(label: 'Seller earnings', value: price(orderData.sellerEarning)),
            ],
          ],
        ],
      ),
    );
  }
}

class _OrderItemRow extends StatelessWidget {
  const _OrderItemRow({required this.item});

  final ShopOrderTrackingItem item;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 52,
          height: 52,
          decoration: BoxDecoration(
            color: theme.colorScheme.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(12),
          ),
          child: HugeIcon(
            icon: HugeIcons.strokeRoundedImage01,
            size: 22,
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        const Gap(11),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                item.name,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.hind(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: theme.colorScheme.onSurface,
                ),
              ),
              if (item.variant != null) ...[
                const Gap(1),
                Text(
                  item.variant!,
                  style: GoogleFonts.hind(fontSize: 11, color: theme.colorScheme.onSurfaceVariant),
                ),
              ],
              const Gap(2),
              Text(
                'Qty ${item.quantity}',
                style: GoogleFonts.hind(fontSize: 11, color: theme.colorScheme.onSurfaceVariant),
              ),
            ],
          ),
        ),
        const Gap(10),
        Text(
          '₹${item.total.toStringAsFixed(0)}',
          style: GoogleFonts.hind(
            fontSize: 14,
            fontWeight: FontWeight.w700,
            color: theme.colorScheme.onSurface,
          ),
        ),
      ],
    );
  }
}

// ORDER SUMMARY
class _OrderSummaryCard extends StatelessWidget {
  const _OrderSummaryCard({required this.orderData, required this.sellerName});

  final ShopOrderTrackingData orderData;
  final String sellerName;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return _SectionCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Order summary',
            style: GoogleFonts.hind(
              fontSize: 17,
              fontWeight: FontWeight.w700,
              color: theme.colorScheme.onSurface,
            ),
          ),
          const Gap(14),
          _SummaryRow(label: 'Order ID', value: orderData.orderId),
          const Gap(8),
          _SummaryRow(label: 'Seller', value: sellerName),
          const Gap(8),
          _SummaryRow(label: 'Payment', value: orderData.paymentMethodLabel),
          const Gap(8),
          _SummaryRow(label: 'Payment status', value: orderData.paymentStatusLabel),
          const Gap(12),
          Divider(height: 1, color: theme.colorScheme.outlineVariant),
          const Gap(12),
          _SummaryRow(
            label: 'Order total',
            value: '₹${orderData.totalAmount.toStringAsFixed(0)}',
            isTotal: true,
          ),
        ],
      ),
    );
  }
}

class _SummaryRow extends StatelessWidget {
  const _SummaryRow({required this.label, required this.value, this.isTotal = false});

  final String label;
  final String value;
  final bool isTotal;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Row(
      children: [
        Expanded(
          child: Text(
            label,
            style: GoogleFonts.hind(
              fontSize: isTotal ? 14 : 12,
              fontWeight: isTotal ? FontWeight.w700 : FontWeight.w400,
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ),
        const Gap(12),
        Flexible(
          child: Text(
            value,
            textAlign: TextAlign.right,
            style: GoogleFonts.hind(
              fontSize: isTotal ? 16 : 12,
              fontWeight: FontWeight.w700,
              color: theme.colorScheme.onSurface,
            ),
          ),
        ),
      ],
    );
  }
}

// HELP
class _HelpCard extends StatelessWidget {
  const _HelpCard();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.55),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          HugeIcon(
            icon: HugeIcons.strokeRoundedInformationCircle,
            size: 19,
            color: theme.colorScheme.onSurfaceVariant,
          ),
          const Gap(9),
          Expanded(
            child: Text(
              'Need help with this order? You can contact support '
              'from the order details screen.',
              style: GoogleFonts.hind(
                fontSize: 12,
                height: 1.4,
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// BOTTOM ACTIONS
class _BottomActions extends StatelessWidget {
  const _BottomActions({
    required this.onViewDetails,
    required this.onContact,
    required this.onConfirmReceipt,
    required this.confirmingReceipt,
  });

  final VoidCallback onViewDetails;
  final VoidCallback onContact;
  final VoidCallback? onConfirmReceipt;
  final bool confirmingReceipt;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        border: Border(
          top: BorderSide(color: theme.colorScheme.outlineVariant.withValues(alpha: 0.55)),
        ),
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (onConfirmReceipt != null) ...[
              SizedBox(
                width: double.infinity,
                height: 48,
                child: FilledButton(
                  onPressed: confirmingReceipt ? null : onConfirmReceipt,
                  child: confirmingReceipt
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Text('Confirm receipt'),
                ),
              ),
              const Gap(10),
            ],
            Row(
              children: [
                Expanded(
                  child: SizedBox(
                    height: 48,
                    child: OutlinedButton(
                      onPressed: onContact,
                      style: OutlinedButton.styleFrom(
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      child: Text(
                        'HELP',
                        style: GoogleFonts.hind(fontSize: 13, fontWeight: FontWeight.w700),
                      ),
                    ),
                  ),
                ),
                const Gap(10),
                Expanded(
                  flex: 2,
                  child: SizedBox(
                    height: 48,
                    child: FilledButton(
                      onPressed: onViewDetails,
                      style: FilledButton.styleFrom(
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      child: Text(
                        'VIEW DETAILS',
                        style: GoogleFonts.hind(fontSize: 13, fontWeight: FontWeight.w700),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _OrderHistoryCard extends StatelessWidget {
  const _OrderHistoryCard({required this.historyFuture});

  final Future<List<ShopOrderHistoryEntry>> historyFuture;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return FutureBuilder<List<ShopOrderHistoryEntry>>(
      future: historyFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return const Text(
            'Order history is temporarily unavailable.',
            textAlign: TextAlign.center,
          );
        }
        final entries = snapshot.data ?? const [];
        return _SectionCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Order history',
                style: GoogleFonts.hind(fontSize: 17, fontWeight: FontWeight.w700),
              ),
              const Gap(12),
              if (entries.isEmpty)
                Text(
                  'No status changes yet.',
                  style: TextStyle(color: theme.colorScheme.onSurfaceVariant),
                )
              else
                ...entries.map(
                  (entry) => Padding(
                    padding: const EdgeInsets.only(bottom: 11),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        HugeIcon(
                          icon: HugeIcons.strokeRoundedCheckmarkCircle02,
                          size: 17,
                          color: theme.colorScheme.primary,
                        ),
                        const Gap(9),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                entry.newStatus.replaceAll('_', ' '),
                                style: GoogleFonts.hind(fontWeight: FontWeight.w700),
                              ),
                              if (entry.note != null && entry.note!.isNotEmpty)
                                Text(entry.note!, style: GoogleFonts.hind(fontSize: 12)),
                              if (entry.createdAt != null)
                                Text(
                                  DateTime.tryParse(entry.createdAt!)?.toLocal().toString() ??
                                      entry.createdAt!,
                                  style: GoogleFonts.hind(
                                    fontSize: 11,
                                    color: theme.colorScheme.onSurfaceVariant,
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

// SHARED CARD
class _SectionCard extends StatelessWidget {
  const _SectionCard({required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: theme.colorScheme.outlineVariant.withValues(alpha: 0.65)),
      ),
      child: child,
    );
  }
}

// MODELS
enum ShopOrderStatus {
  placed,
  confirmed,
  preparing,
  ready,
  outForDelivery,
  readyForPickup,
  delivered,
  pickedUp,
  cancelled,
}

enum ShopTrackingFulfillmentMethod {
  deliverToMyFlat,
  pickup,
  commonLocationMeetup,
  societyHelperDelivery,
}

enum _ProgressStatus { completed, current, upcoming, cancelled }

class _ProgressStepData {
  const _ProgressStepData({required this.title, required this.description, required this.status});

  final String title;
  final String description;
  final _ProgressStatus status;
}

class ShopOrderTrackingData {
  const ShopOrderTrackingData({
    required this.orderId,
    required this.sellerId,
    required this.sellerName,
    required this.status,
    required this.statusTitle,
    required this.statusDescription,
    required this.fulfillmentMethod,
    required this.fulfillmentTitle,
    required this.fulfillmentDetail,
    required this.items,
    required this.subtotal,
    required this.totalAmount,
    required this.paymentMethodLabel,
    required this.paymentStatusLabel,
    this.deliveryAddress,
    this.pickupAddress,
    this.deliveryInstructions,
    this.discountAmount = 0,
    this.platformCommission = 0,
    this.welfareFundAmount = 0,
    this.sellerEarning = 0,
    this.etaLabel,
  });

  factory ShopOrderTrackingData.fromOrder(ShopOrderResult order) {
    final rawStatus = order.orderStatus.toUpperCase();
    final status = switch (rawStatus) {
      'ACCEPTED' => ShopOrderStatus.confirmed,
      'PREPARING' || 'IN_SERVICE' => ShopOrderStatus.preparing,
      'READY' => ShopOrderStatus.ready,
      'READY_FOR_PICKUP' || 'READY_FOR_HANDOFF' => ShopOrderStatus.readyForPickup,
      'OUT_FOR_DELIVERY' => ShopOrderStatus.outForDelivery,
      'DELIVERED' || 'COMPLETED' => ShopOrderStatus.delivered,
      'PICKED_UP' => ShopOrderStatus.pickedUp,
      'REJECTED' || 'CANCELLED' || 'CANCELED' => ShopOrderStatus.cancelled,
      _ => ShopOrderStatus.placed,
    };
    final isPickup = order.fulfillmentMethod.toUpperCase() == 'PICKUP';
    final scheduledAt = DateTime.tryParse(order.scheduledAt ?? '')?.toLocal();
    final sellerIdShort = order.sellerId.length > 8
        ? order.sellerId.substring(0, 8)
        : order.sellerId;
    final sellerName = order.sellerName?.trim().isNotEmpty == true
        ? order.sellerName!.trim()
        : 'Seller $sellerIdShort';
    final fulfillmentTitle = switch (order.fulfillmentMethod.toUpperCase()) {
      'PICKUP' => 'Pickup from seller',
      'SCHEDULE_DELIVERY' => 'Scheduled delivery',
      'DELIVER_TO_ME' => 'Delivery to your address',
      _ => order.fulfillmentMethod.replaceAll('_', ' '),
    };

    return ShopOrderTrackingData(
      orderId: order.id,
      sellerId: order.sellerId,
      sellerName: sellerName,
      status: status,
      statusTitle: order.statusLabel,
      statusDescription: 'Latest update for order ${order.orderNumber}.',
      fulfillmentMethod: isPickup
          ? ShopTrackingFulfillmentMethod.pickup
          : ShopTrackingFulfillmentMethod.deliverToMyFlat,
      fulfillmentTitle: fulfillmentTitle,
      fulfillmentDetail: isPickup
          ? order.pickupAddress ?? fulfillmentTitle
          : order.deliveryAddress ?? fulfillmentTitle,
      deliveryAddress: order.deliveryAddress,
      pickupAddress: order.pickupAddress,
      deliveryInstructions: order.deliveryInstructions,
      items: order.items
          .map(
            (item) => ShopOrderTrackingItem(
              id: item.id,
              name: item.title,
              quantity: item.quantity,
              total: item.totalPrice,
            ),
          )
          .toList(),
      subtotal: order.subtotalAmount,
      discountAmount: order.discountAmount,
      platformCommission: order.platformCommission,
      welfareFundAmount: order.welfareFundAmount,
      sellerEarning: order.sellerEarning,
      totalAmount: order.totalAmount,
      paymentMethodLabel: order.paymentMethod ?? 'Cash',
      paymentStatusLabel: order.paymentStatus,
      etaLabel: scheduledAt?.toString(),
    );
  }

  final String orderId;
  final String sellerId;
  final String sellerName;

  final ShopOrderStatus status;

  final String statusTitle;
  final String statusDescription;
  final String? etaLabel;

  final ShopTrackingFulfillmentMethod fulfillmentMethod;
  final String fulfillmentTitle;
  final String fulfillmentDetail;
  final String? deliveryAddress;
  final String? pickupAddress;
  final String? deliveryInstructions;

  final List<ShopOrderTrackingItem> items;

  final double subtotal;
  final double discountAmount;
  final double platformCommission;
  final double welfareFundAmount;
  final double sellerEarning;
  final double totalAmount;

  final String paymentMethodLabel;
  final String paymentStatusLabel;
}

class ShopOrderTrackingItem {
  const ShopOrderTrackingItem({
    required this.id,
    required this.name,
    required this.quantity,
    required this.total,
    this.variant,
  });

  final String id;
  final String name;
  final String? variant;
  final int quantity;
  final double total;
}
