import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/features/seller/domain/entities/certificate_entity.dart';
import 'package:society_seva/features/seller/domain/entities/seller_image_entity.dart';
import 'package:society_seva/features/seller/domain/entities/seller_profile_entity.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing.dart';
import 'package:society_seva/features/shop/domain/enums/shop_listing_type.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_listing_provider.dart';
import 'package:society_seva/features/shop/presentation/widgets/category/shop_cart_actions.dart';

enum SellerStoreTab { all, food, services }

class SellerStoreScreen extends ConsumerStatefulWidget {
  const SellerStoreScreen({super.key, required this.sellerId});

  final String sellerId;

  @override
  ConsumerState<SellerStoreScreen> createState() => _SellerStoreScreenState();
}

class _SellerStoreScreenState extends ConsumerState<SellerStoreScreen> {
  SellerStoreTab _selectedTab = SellerStoreTab.all;

  late SellerStoreData _seller;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final textTheme = GoogleFonts.hindTextTheme(theme.textTheme);
    final sellerAsync = ref.watch(sellerProfileByIdProvider(widget.sellerId));
    final listingsAsync = ref.watch(shopSellerListingsProvider(widget.sellerId));
    final imagesAsync = ref.watch(fetchSellerUploadedImagesProvider(widget.sellerId));
    final certificatesAsync = ref.watch(sellerCertificatesProvider(widget.sellerId));
    final seller = sellerAsync.valueOrNull;

    if (seller == null) {
      if (sellerAsync.hasError) {
        return Scaffold(
          appBar: AppBar(title: const Text('Seller store')),
          body: Center(
            child: TextButton.icon(
              onPressed: () => ref.invalidate(sellerProfileByIdProvider(widget.sellerId)),
              icon: const Icon(Icons.refresh),
              label: const Text('Unable to load seller profile'),
            ),
          ),
        );
      }
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    if (seller.id.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: Text('Seller store')),
        body: const Center(child: Text('Seller profile not found')),
      );
    }

    final approvedImages =
        (imagesAsync.valueOrNull ?? const <SellerImageEntity>[])
            .where((image) => image.moderationStatus.toUpperCase() == 'APPROVED')
            .toList()
          ..sort((first, second) => first.displayOrder.compareTo(second.displayOrder));
    final certificates = certificatesAsync.valueOrNull ?? const <CertificateEntity>[];
    final listings = (listingsAsync.valueOrNull?.content ?? const <ShopListing>[])
        .where((listing) => listing.isApproved && listing.isAvailable)
        .toList();
    _seller = SellerStoreData.fromApi(
      profile: seller,
      listings: listings,
      images: approvedImages,
      certificates: certificates,
    );

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      body: SafeArea(
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(child: _buildTopBar(context, textTheme)),
            SliverToBoxAdapter(child: _buildSellerHeader(context, textTheme)),
            SliverToBoxAdapter(child: _buildStoreTabs(context, textTheme)),
            SliverToBoxAdapter(
              child: listingsAsync.when(
                loading: () =>
                    const SizedBox(height: 240, child: Center(child: CircularProgressIndicator())),
                error: (error, stackTrace) => Center(
                  child: TextButton.icon(
                    onPressed: () => ref.invalidate(shopSellerListingsProvider(widget.sellerId)),
                    icon: const Icon(Icons.refresh),
                    label: const Text('Unable to load seller listings'),
                  ),
                ),
                data: (_) => _buildContent(context, textTheme),
              ),
            ),
            const SliverToBoxAdapter(child: Gap(32)),
          ],
        ),
      ),
    );
  }

  Widget _buildTopBar(BuildContext context, TextTheme textTheme) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
      child: Row(
        children: [
          _CircleActionButton(
            icon: HugeIcons.strokeRoundedArrowLeft01,
            onTap: () => Navigator.of(context).pop(),
          ),
          const Gap(12),
          Expanded(
            child: Text(
              _seller.name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w700,
                color: theme.colorScheme.onSurface,
              ),
            ),
          ),
          const Gap(8),
          _CircleActionButton(
            icon: HugeIcons.strokeRoundedShoppingCart02,
            onTap: () => context.push('/shop/cart'),
          ),
        ],
      ),
    );
  }

  Widget _buildSellerHeader(BuildContext context, TextTheme textTheme) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Seller cover
          Container(
            height: 150,
            width: double.infinity,
            decoration: BoxDecoration(
              color: theme.colorScheme.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(24),
            ),
            child: Stack(
              children: [
                Positioned.fill(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(24),
                    child: _seller.coverImageUrl == null
                        ? _SellerImagePlaceholder(icon: HugeIcons.strokeRoundedStore01)
                        : Image.network(
                            _seller.coverImageUrl!,
                            fit: BoxFit.cover,
                            errorBuilder: (_, _, _) =>
                                _SellerImagePlaceholder(icon: HugeIcons.strokeRoundedStore01),
                          ),
                  ),
                ),

                // Society availability
                Positioned(
                  left: 14,
                  bottom: 14,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: theme.colorScheme.surface.withValues(alpha: 0.94),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        HugeIcon(
                          icon: HugeIcons.strokeRoundedLocation01,
                          size: 14,
                          color: theme.colorScheme.primary,
                        ),
                        const Gap(5),
                        Text(
                          _seller.locationLabel,
                          style: textTheme.labelMedium?.copyWith(
                            fontWeight: FontWeight.w600,
                            color: theme.colorScheme.onSurface,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          const Gap(16),

          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Seller avatar
              Container(
                height: 58,
                width: 58,
                decoration: BoxDecoration(
                  color: theme.colorScheme.primaryContainer,
                  borderRadius: BorderRadius.circular(18),
                ),
                child: HugeIcon(
                  icon: HugeIcons.strokeRoundedStore01,
                  size: 28,
                  color: theme.colorScheme.onPrimaryContainer,
                ),
              ),

              const Gap(12),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            _seller.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: textTheme.titleLarge?.copyWith(
                              fontWeight: FontWeight.w800,
                              color: theme.colorScheme.onSurface,
                            ),
                          ),
                        ),
                        const Gap(6),
                        HugeIcon(
                          icon: HugeIcons.strokeRoundedCheckmarkCircle02,
                          size: 18,
                          color: theme.colorScheme.primary,
                        ),
                      ],
                    ),
                    const Gap(3),
                    Text(
                      _seller.description,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: textTheme.bodyMedium?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                        height: 1.25,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const Gap(14),

          Row(
            children: [
              _SellerStat(
                icon: HugeIcons.strokeRoundedStar,
                value: _seller.rating.toStringAsFixed(1),
                label: '${_seller.reviewCount} reviews',
              ),
              _SellerStatDivider(),
              _SellerStat(
                icon: HugeIcons.strokeRoundedPackage,
                value: '${_seller.listingCount}',
                label: 'listings',
              ),
              _SellerStatDivider(),
              _SellerStat(
                icon: HugeIcons.strokeRoundedLocation01,
                value: _seller.deliveryRadius,
                label: 'delivery radius',
              ),
            ],
          ),
          if (_seller.certificates.isNotEmpty) ...[
            const Gap(14),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: _seller.certificates
                  .map((certificate) => _CertificateBadge(certificate: certificate))
                  .toList(),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildStoreTabs(BuildContext context, TextTheme textTheme) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 8),
      child: Container(
        height: 48,
        padding: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.65),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          children: [
            _StoreTab(
              label: 'All',
              selected: _selectedTab == SellerStoreTab.all,
              onTap: () {
                setState(() {
                  _selectedTab = SellerStoreTab.all;
                });
              },
            ),
            _StoreTab(
              label: 'Food',
              selected: _selectedTab == SellerStoreTab.food,
              onTap: () {
                setState(() {
                  _selectedTab = SellerStoreTab.food;
                });
              },
            ),
            _StoreTab(
              label: 'Services',
              selected: _selectedTab == SellerStoreTab.services,
              onTap: () {
                setState(() {
                  _selectedTab = SellerStoreTab.services;
                });
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContent(BuildContext context, TextTheme textTheme) {
    switch (_selectedTab) {
      case SellerStoreTab.all:
        return _buildAllContent(context, textTheme);

      case SellerStoreTab.food:
        return _buildFoodContent(context, textTheme);

      case SellerStoreTab.services:
        return _buildServicesContent(context, textTheme);
    }
  }

  Widget _buildAllContent(BuildContext context, TextTheme textTheme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Gap(18),

        _SectionHeader(
          title: 'Featured from ${_seller.name}',
          actionLabel: '${_seller.listingCount} listings',
        ),

        const Gap(12),

        SizedBox(
          height: 238,
          child: ListView.separated(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            itemCount: _seller.popularProducts.length,
            separatorBuilder: (_, _) => const Gap(12),
            itemBuilder: (context, index) {
              return _ProductCard(
                product: _seller.popularProducts[index],
                width: 170,
                onAdd: () => _addToCart(_seller.popularProducts[index]),
                onTap: () => _openListing(_seller.popularProducts[index].listing),
              );
            },
          ),
        ),

        const Gap(28),

        _SectionHeader(title: 'Food & products', actionLabel: '${_seller.products.length} items'),

        const Gap(12),

        _ProductGrid(
          products: _seller.products,
          onAdd: _addToCart,
          onTap: (product) => _openListing(product.listing),
        ),

        const Gap(28),

        _SectionHeader(title: 'Services', actionLabel: '${_seller.services.length} available'),

        const Gap(12),

        _ServiceList(
          services: _seller.services,
          onBook: (service) => _openListing(service.listing),
          onTap: (service) => _openListing(service.listing),
        ),
      ],
    );
  }

  Widget _buildFoodContent(BuildContext context, TextTheme textTheme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Gap(18),

        _SectionHeader(title: 'Food & products', actionLabel: '${_seller.products.length} items'),

        const Gap(12),

        _ProductGrid(
          products: _seller.products,
          onAdd: _addToCart,
          onTap: (product) => _openListing(product.listing),
        ),
      ],
    );
  }

  Widget _buildServicesContent(BuildContext context, TextTheme textTheme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Gap(18),

        _SectionHeader(title: 'Services', actionLabel: '${_seller.services.length} available'),

        const Gap(12),

        _ServiceList(
          services: _seller.services,
          onBook: (service) => _openListing(service.listing),
          onTap: (service) => _openListing(service.listing),
        ),
      ],
    );
  }

  Future<void> _addToCart(SellerProduct product) {
    return addListingToCart(context, ref, product.listing, quantity: 1);
  }

  void _openListing(ShopListing listing) {
    final path = listing.listingType.isService
        ? '/shop/service/${listing.id}'
        : '/shop/product/${listing.id}';
    context.push(path, extra: listing);
  }
}

// PRODUCT GRID
class _ProductGrid extends StatelessWidget {
  const _ProductGrid({required this.products, required this.onAdd, required this.onTap});

  final List<SellerProduct> products;
  final void Function(SellerProduct product) onAdd;
  final void Function(SellerProduct product) onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: products.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 12,
          mainAxisSpacing: 14,
          childAspectRatio: 0.70,
        ),
        itemBuilder: (context, index) {
          final product = products[index];

          return _ProductCard(
            product: product,
            onAdd: () => onAdd(product),
            onTap: () => onTap(product),
          );
        },
      ),
    );
  }
}

// PRODUCT CARD
class _ListingImage extends ConsumerWidget {
  const _ListingImage({required this.listing, required this.icon});

  final ShopListing listing;
  final dynamic icon;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final images = ref.watch(shopListingImagesProvider(listing.id)).valueOrNull;
    final imageUrl = images
        ?.where((image) => image.moderationStatus.toUpperCase() == 'APPROVED')
        .map((image) => image.imageUrl)
        .firstOrNull;

    if (imageUrl == null || imageUrl.isEmpty) {
      return _SellerImagePlaceholder(icon: icon);
    }

    return Image.network(
      imageUrl,
      fit: BoxFit.cover,
      errorBuilder: (_, _, _) => _SellerImagePlaceholder(icon: icon),
    );
  }
}

class _ProductCard extends ConsumerWidget {
  const _ProductCard({required this.product, required this.onAdd, required this.onTap, this.width});

  final SellerProduct product;
  final VoidCallback onAdd;
  final VoidCallback onTap;
  final double? width;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final textTheme = GoogleFonts.hindTextTheme(theme.textTheme);

    return SizedBox(
      width: width,
      child: Material(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: theme.colorScheme.outlineVariant.withValues(alpha: 0.55)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                AspectRatio(
                  aspectRatio: 1.15,
                  child: Container(
                    decoration: BoxDecoration(
                      color: theme.colorScheme.surfaceContainerHighest,
                      borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
                    ),
                    child: Stack(
                      children: [
                        Positioned.fill(
                          child: _ListingImage(
                            listing: product.listing,
                            icon: HugeIcons.strokeRoundedImage01,
                          ),
                        ),

                        if (product.isPopular)
                          Positioned(
                            top: 9,
                            left: 9,
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: theme.colorScheme.primary,
                                borderRadius: BorderRadius.circular(7),
                              ),
                              child: Text(
                                'POPULAR',
                                style: textTheme.labelSmall?.copyWith(
                                  fontWeight: FontWeight.w800,
                                  color: theme.colorScheme.onPrimary,
                                  letterSpacing: 0.3,
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),

                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(11, 9, 9, 9),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          product.name,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: textTheme.titleSmall?.copyWith(
                            fontWeight: FontWeight.w700,
                            height: 1.15,
                          ),
                        ),

                        const Gap(3),

                        Text(
                          product.variant,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: textTheme.bodySmall?.copyWith(
                            color: theme.colorScheme.onSurfaceVariant,
                          ),
                        ),

                        const Spacer(),

                        Row(
                          children: [
                            Text(
                              product.listing.isFree ? 'FREE' : '₹${_formatNumber(product.price)}',
                              style: textTheme.titleMedium?.copyWith(
                                fontWeight: FontWeight.w800,
                                color: theme.colorScheme.onSurface,
                              ),
                            ),
                            const Spacer(),
                            _AddButton(onTap: onAdd),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// SERVICE LIST
class _ServiceList extends StatelessWidget {
  const _ServiceList({required this.services, required this.onBook, required this.onTap});

  final List<SellerService> services;
  final void Function(SellerService service) onBook;
  final void Function(SellerService service) onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          for (var index = 0; index < services.length; index++) ...[
            _ServiceCard(
              service: services[index],
              onBook: () => onBook(services[index]),
              onTap: () => onTap(services[index]),
            ),
            if (index != services.length - 1) const Gap(12),
          ],
        ],
      ),
    );
  }
}

class _ServiceCard extends ConsumerWidget {
  const _ServiceCard({required this.service, required this.onBook, required this.onTap});

  final SellerService service;
  final VoidCallback onBook;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final textTheme = GoogleFonts.hindTextTheme(theme.textTheme);

    return Material(
      color: theme.colorScheme.surface,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: theme.colorScheme.outlineVariant.withValues(alpha: 0.55)),
          ),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: SizedBox(
                  height: 78,
                  width: 78,
                  child: _ListingImage(
                    listing: service.listing,
                    icon: HugeIcons.strokeRoundedTools,
                  ),
                ),
              ),

              const Gap(12),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      service.name,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w700,
                        height: 1.15,
                      ),
                    ),

                    const Gap(4),

                    Text(
                      service.description,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                        height: 1.2,
                      ),
                    ),

                    const Gap(7),

                    Row(
                      children: [
                        HugeIcon(
                          icon: HugeIcons.strokeRoundedStar,
                          size: 14,
                          color: theme.colorScheme.primary,
                        ),
                        const Gap(3),
                        Text(
                          service.rating.toStringAsFixed(1),
                          style: textTheme.labelMedium?.copyWith(fontWeight: FontWeight.w700),
                        ),
                        const Gap(8),
                        Text(
                          service.listing.isFree
                              ? 'Free'
                              : 'From ₹${_formatNumber(service.startingPrice)}',
                          style: textTheme.labelMedium?.copyWith(
                            fontWeight: FontWeight.w700,
                            color: theme.colorScheme.onSurface,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              const Gap(8),

              _BookButton(onTap: onBook),
            ],
          ),
        ),
      ),
    );
  }
}

// COMMON UI
class _SectionHeader extends StatelessWidget {
  const _SectionHeader({required this.title, this.actionLabel});

  final String title;
  final String? actionLabel;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final textTheme = GoogleFonts.hindTextTheme(theme.textTheme);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          Expanded(
            child: Text(
              title,
              style: textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w800,
                color: theme.colorScheme.onSurface,
              ),
            ),
          ),
          if (actionLabel != null)
            Text(
              actionLabel!,
              style: textTheme.labelLarge?.copyWith(
                fontWeight: FontWeight.w700,
                color: theme.colorScheme.primary,
              ),
            ),
        ],
      ),
    );
  }
}

class _StoreTab extends StatelessWidget {
  const _StoreTab({required this.label, required this.selected, required this.onTap});

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final textTheme = GoogleFonts.hindTextTheme(theme.textTheme);

    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          curve: Curves.easeOut,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: selected ? theme.colorScheme.surface : Colors.transparent,
            borderRadius: BorderRadius.circular(11),
            boxShadow: selected
                ? [
                    BoxShadow(
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                      color: theme.colorScheme.shadow.withValues(alpha: 0.08),
                    ),
                  ]
                : null,
          ),
          child: Text(
            label,
            style: textTheme.labelLarge?.copyWith(
              fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
              color: selected ? theme.colorScheme.onSurface : theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ),
      ),
    );
  }
}

class _CircleActionButton extends StatelessWidget {
  const _CircleActionButton({required this.icon, required this.onTap});

  final dynamic icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Stack(
      clipBehavior: Clip.none,
      children: [
        Material(
          color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.65),
          borderRadius: BorderRadius.circular(13),
          child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(13),
            child: SizedBox(
              height: 42,
              width: 42,
              child: Center(
                child: HugeIcon(icon: icon, size: 21, color: theme.colorScheme.onSurface),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _AddButton extends StatelessWidget {
  const _AddButton({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Material(
      color: theme.colorScheme.primary,
      borderRadius: BorderRadius.circular(9),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(9),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          child: Text(
            'ADD',
            style: GoogleFonts.hind(
              fontSize: 12,
              fontWeight: FontWeight.w800,
              color: theme.colorScheme.onPrimary,
              letterSpacing: 0.3,
            ),
          ),
        ),
      ),
    );
  }
}

class _BookButton extends StatelessWidget {
  const _BookButton({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Material(
      color: theme.colorScheme.primary,
      borderRadius: BorderRadius.circular(10),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
          child: Text(
            'VIEW',
            style: GoogleFonts.hind(
              fontSize: 12,
              fontWeight: FontWeight.w800,
              color: theme.colorScheme.onPrimary,
              letterSpacing: 0.3,
            ),
          ),
        ),
      ),
    );
  }
}

class _SellerStat extends StatelessWidget {
  const _SellerStat({required this.icon, required this.value, required this.label});

  final dynamic icon;
  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final textTheme = GoogleFonts.hindTextTheme(theme.textTheme);

    return Expanded(
      child: Row(
        children: [
          HugeIcon(icon: icon, size: 17, color: theme.colorScheme.primary),
          const Gap(6),
          Flexible(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(value, style: textTheme.labelLarge?.copyWith(fontWeight: FontWeight.w800)),
                Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: textTheme.labelSmall?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SellerStatDivider extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      height: 28,
      width: 1,
      margin: const EdgeInsets.symmetric(horizontal: 8),
      color: theme.colorScheme.outlineVariant.withValues(alpha: 0.6),
    );
  }
}

class _CertificateBadge extends StatelessWidget {
  const _CertificateBadge({required this.certificate});

  final CertificateEntity certificate;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isVerified = certificate.verificationStatus.toUpperCase() == 'APPROVED';
    final label = certificate.certificateName.trim().isNotEmpty
        ? certificate.certificateName
        : _sellerTypeLabel(certificate.certificateType);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: isVerified
            ? theme.colorScheme.primaryContainer
            : theme.colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            isVerified ? Icons.verified_outlined : Icons.pending_outlined,
            size: 15,
            color: isVerified ? theme.colorScheme.primary : theme.colorScheme.onSurfaceVariant,
          ),
          const Gap(5),
          Text(
            '$label · ${_sellerTypeLabel(certificate.verificationStatus)}',
            style: theme.textTheme.labelSmall?.copyWith(fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }
}

class _SellerImagePlaceholder extends StatelessWidget {
  const _SellerImagePlaceholder({required this.icon});

  final dynamic icon;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      color: theme.colorScheme.surfaceContainerHighest,
      child: Center(
        child: HugeIcon(
          icon: icon,
          size: 34,
          color: theme.colorScheme.onSurfaceVariant.withValues(alpha: 0.55),
        ),
      ),
    );
  }
}

class SellerStoreData {
  const SellerStoreData({
    required this.sellerId,
    required this.name,
    required this.description,
    required this.rating,
    required this.reviewCount,
    required this.listingCount,
    required this.deliveryRadius,
    required this.locationLabel,
    required this.coverImageUrl,
    required this.certificates,
    required this.popularProducts,
    required this.products,
    required this.services,
  });

  final String sellerId;
  final String name;
  final String description;
  final double rating;
  final int reviewCount;
  final int listingCount;
  final String deliveryRadius;
  final String locationLabel;
  final String? coverImageUrl;
  final List<CertificateEntity> certificates;

  final List<SellerProduct> popularProducts;
  final List<SellerProduct> products;
  final List<SellerService> services;

  factory SellerStoreData.fromApi({
    required SellerProfileEntity profile,
    required List<ShopListing> listings,
    required List<SellerImageEntity> images,
    required List<CertificateEntity> certificates,
  }) {
    final productListings = listings.where((listing) => !_isServiceListing(listing)).toList();
    final serviceListings = listings.where(_isServiceListing).toList();
    final products = productListings.map(SellerProduct.fromListing).toList();
    final services = serviceListings.map(SellerService.fromListing).toList();
    final businessDescription = [
      profile.businessName?.trim(),
      profile.bio?.trim(),
    ].whereType<String>().where((value) => value.isNotEmpty).toSet().join(' · ');
    final location = [
      profile.city,
      profile.state,
    ].where((value) => value.trim().isNotEmpty).join(', ');

    return SellerStoreData(
      sellerId: profile.id,
      name: profile.displayName,
      description: businessDescription.isEmpty
          ? _sellerTypeLabel(profile.sellerTypeList.first)
          : businessDescription,
      rating: profile.averageRating,
      reviewCount: profile.totalReviews,
      listingCount: profile.totalListings,
      deliveryRadius: profile.deliveryRadiusKm == null
          ? 'Not set'
          : '${_formatNumber(profile.deliveryRadiusKm!)} km',
      locationLabel: location.isEmpty ? 'Seller location' : location,
      coverImageUrl: images.isEmpty ? null : images.first.imageUrl,
      certificates: certificates,
      popularProducts: products.take(4).toList(),
      products: products,
      services: services,
    );
  }
}

class SellerProduct {
  const SellerProduct({required this.listing, required this.variant});

  final ShopListing listing;
  final String variant;

  String get name => listing.title;
  double get price => listing.basePrice;
  bool get isPopular => false;

  factory SellerProduct.fromListing(ShopListing listing) => SellerProduct(
    listing: listing,
    variant: [
      _listingTypeLabel(listing.listingType),
      if (listing.priceUnit?.trim().isNotEmpty == true) '/ ${listing.priceUnit}',
      if (listing.quantityAvailable != null) '${listing.quantityAvailable} available',
    ].join(' · '),
  );
}

class SellerService {
  const SellerService({required this.listing});

  final ShopListing listing;

  String get name => listing.title;
  String get description => listing.description;
  double get rating => listing.averageRating;
  double get startingPrice => listing.basePrice;

  factory SellerService.fromListing(ShopListing listing) => SellerService(listing: listing);
}

bool _isServiceListing(ShopListing listing) => switch (listing.listingType) {
  ShopListingType.service ||
  ShopListingType.class_ ||
  ShopListingType.consultation ||
  ShopListingType.eventSupport ||
  ShopListingType.help => true,
  _ => false,
};

String _listingTypeLabel(ShopListingType type) => switch (type) {
  ShopListingType.food => 'Food',
  ShopListingType.product => 'Product',
  ShopListingType.service => 'Service',
  ShopListingType.class_ => 'Class',
  ShopListingType.consultation => 'Consultation',
  ShopListingType.eventSupport => 'Event support',
  ShopListingType.help => 'Community help',
  ShopListingType.grocery => 'Grocery',
  ShopListingType.unknown => 'Listing',
};

String _sellerTypeLabel(String sellerType) => sellerType
    .replaceAll('_', ' ')
    .toLowerCase()
    .split(' ')
    .map((part) => part.isEmpty ? part : '${part[0].toUpperCase()}${part.substring(1)}')
    .join(' ');

String _formatNumber(double value) =>
    value == value.roundToDouble() ? value.toInt().toString() : value.toStringAsFixed(1);
