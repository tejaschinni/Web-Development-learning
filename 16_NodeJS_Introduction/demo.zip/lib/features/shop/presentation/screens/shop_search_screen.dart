import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:hugeicons/hugeicons.dart';

class ShopSearchScreen extends StatefulWidget {
  const ShopSearchScreen({super.key, this.initialQuery});

  final String? initialQuery;

  @override
  State<ShopSearchScreen> createState() => _ShopSearchScreenState();
}

class _ShopSearchScreenState extends State<ShopSearchScreen> {
  late final TextEditingController _searchController;
  final FocusNode _searchFocusNode = FocusNode();

  bool _hasQuery = false;

  final List<String> _recentSearches = [
    'Poha',
    'Electrician',
    'Birthday cake',
    'Math classes',
    'Idli',
  ];

  @override
  void initState() {
    super.initState();

    _searchController = TextEditingController(text: widget.initialQuery ?? '');

    _hasQuery = _searchController.text.trim().isNotEmpty;

    _searchController.addListener(_onSearchChanged);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _searchFocusNode.requestFocus();
    });
  }

  void _onSearchChanged() {
    final hasQuery = _searchController.text.trim().isNotEmpty;

    if (hasQuery != _hasQuery) {
      setState(() {
        _hasQuery = hasQuery;
      });
    }
  }

  @override
  void dispose() {
    _searchController
      ..removeListener(_onSearchChanged)
      ..dispose();

    _searchFocusNode.dispose();

    super.dispose();
  }

  void _removeRecentSearch(String value) {
    setState(() {
      _recentSearches.remove(value);
    });
  }

  void _clearRecentSearches() {
    setState(() {
      _recentSearches.clear();
    });
  }

  void _selectRecentSearch(String value) {
    _searchController.text = value;

    _searchController.selection = TextSelection.fromPosition(
      TextPosition(offset: _searchController.text.length),
    );
  }

  void _clearSearch() {
    _searchController.clear();
    _searchFocusNode.requestFocus();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      body: SafeArea(
        child: Column(
          children: [
            _SearchHeader(
              controller: _searchController,
              focusNode: _searchFocusNode,
              hasQuery: _hasQuery,
              onBack: () {
                Navigator.of(context).pop();
              },
              onClear: _clearSearch,
              onFilter: () {
                _showFilters(context);
              },
            ),

            Expanded(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 180),
                child: _hasQuery
                    ? _SearchResults(
                        key: const ValueKey('results'),
                        query: _searchController.text.trim(),
                      )
                    : _SearchEmptyState(
                        key: const ValueKey('empty'),
                        recentSearches: _recentSearches,
                        onRecentSearchTap: _selectRecentSearch,
                        onRecentSearchRemove: _removeRecentSearch,
                        onClearAll: _clearRecentSearches,
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showFilters(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (_) {
        return const _SearchFilterSheet();
      },
    );
  }
}

class _SearchHeader extends StatelessWidget {
  const _SearchHeader({
    required this.controller,
    required this.focusNode,
    required this.hasQuery,
    required this.onBack,
    required this.onClear,
    required this.onFilter,
  });

  final TextEditingController controller;
  final FocusNode focusNode;
  final bool hasQuery;
  final VoidCallback onBack;
  final VoidCallback onClear;
  final VoidCallback onFilter;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 16, 12),
      child: Row(
        children: [
          IconButton(
            onPressed: onBack,
            tooltip: 'Back',
            icon: HugeIcon(
              icon: HugeIcons.strokeRoundedArrowLeft01,
              size: 23,
              color: theme.colorScheme.onSurface,
            ),
          ),

          const Gap(2),

          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: theme.colorScheme.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(17),
              ),
              child: TextField(
                controller: controller,
                focusNode: focusNode,
                textInputAction: TextInputAction.search,
                autofocus: true,
                maxLines: 1,
                style: theme.textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w500),
                decoration: InputDecoration(
                  hintText: 'Search products, food & services',
                  hintStyle: theme.textTheme.bodyMedium?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                  prefixIcon: Padding(
                    padding: const EdgeInsets.all(13),
                    child: HugeIcon(
                      icon: HugeIcons.strokeRoundedSearch01,
                      size: 20,
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                  suffixIcon: hasQuery
                      ? IconButton(
                          onPressed: onClear,
                          tooltip: 'Clear',
                          icon: HugeIcon(
                            icon: HugeIcons.strokeRoundedCancel01,
                            size: 19,
                            color: theme.colorScheme.onSurfaceVariant,
                          ),
                        )
                      : null,
                  border: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 4),
                ),
              ),
            ),
          ),

          const Gap(8),

          Material(
            color: theme.colorScheme.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(15),
            child: InkWell(
              onTap: onFilter,
              borderRadius: BorderRadius.circular(15),
              child: const SizedBox(
                width: 46,
                height: 46,
                child: Center(child: HugeIcon(icon: HugeIcons.strokeRoundedFilter, size: 21)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SearchEmptyState extends StatelessWidget {
  const _SearchEmptyState({
    super.key,
    required this.recentSearches,
    required this.onRecentSearchTap,
    required this.onRecentSearchRemove,
    required this.onClearAll,
  });

  final List<String> recentSearches;
  final ValueChanged<String> onRecentSearchTap;
  final ValueChanged<String> onRecentSearchRemove;
  final VoidCallback onClearAll;

  @override
  Widget build(BuildContext context) {
    return ListView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
      children: [
        if (recentSearches.isNotEmpty) ...[
          _SearchSectionHeader(
            title: 'Recent searches',
            actionText: 'Clear all',
            onAction: onClearAll,
          ),
          const Gap(10),
          _RecentSearchList(
            searches: recentSearches,
            onTap: onRecentSearchTap,
            onRemove: onRecentSearchRemove,
          ),
          const Gap(30),
        ],

        const _SearchSectionHeader(title: 'Recommended for you'),

        const Gap(14),

        const _RecommendedSearchList(),
      ],
    );
  }
}

class _RecentSearchList extends StatelessWidget {
  const _RecentSearchList({required this.searches, required this.onTap, required this.onRemove});

  final List<String> searches;
  final ValueChanged<String> onTap;
  final ValueChanged<String> onRemove;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Column(
      children: searches.map((search) {
        return Padding(
          padding: const EdgeInsets.only(bottom: 4),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: () => onTap(search),
              borderRadius: BorderRadius.circular(12),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 11, horizontal: 4),
                child: Row(
                  children: [
                    HugeIcon(
                      icon: HugeIcons.strokeRoundedClock01,
                      size: 19,
                      color: theme.colorScheme.onSurfaceVariant,
                    ),

                    const Gap(12),

                    Expanded(
                      child: Text(
                        search,
                        style: theme.textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w500),
                      ),
                    ),

                    IconButton(
                      visualDensity: VisualDensity.compact,
                      onPressed: () => onRemove(search),
                      tooltip: 'Remove',
                      icon: HugeIcon(
                        icon: HugeIcons.strokeRoundedCancel01,
                        size: 17,
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}

class _RecommendedSearchList extends StatelessWidget {
  const _RecommendedSearchList();

  @override
  Widget build(BuildContext context) {
    final recommendations = [
      'Breakfast near me',
      'Home cooked food',
      'Electrician',
      'AC repair',
      'Math classes',
      'Birthday cake',
    ];

    final theme = Theme.of(context);

    return Wrap(
      spacing: 9,
      runSpacing: 10,
      children: recommendations.map((item) {
        return Material(
          color: theme.colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(12),
          child: InkWell(
            onTap: () {
              // TODO: Set search query.
            },
            borderRadius: BorderRadius.circular(12),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 10),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  HugeIcon(
                    icon: HugeIcons.strokeRoundedSearch01,
                    size: 15,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                  const Gap(7),
                  Text(
                    item,
                    style: theme.textTheme.labelMedium?.copyWith(fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}

class _SearchResults extends StatelessWidget {
  const _SearchResults({super.key, required this.query});

  final String query;

  @override
  Widget build(BuildContext context) {
    return ListView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
      children: [
        Text(
          'Results for "$query"',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
        ),

        const Gap(16),

        const _SearchResultTabs(),

        const Gap(22),

        const _ResultSection(title: 'Services', child: _ServiceSearchResultList()),

        const Gap(28),

        const _ResultSection(title: 'Products', child: _ProductSearchResultList()),

        const Gap(28),

        const _ResultSection(title: 'Sellers', child: _SellerSearchResultList()),
      ],
    );
  }
}

class _SearchResultTabs extends StatefulWidget {
  const _SearchResultTabs();

  @override
  State<_SearchResultTabs> createState() => _SearchResultTabsState();
}

class _SearchResultTabsState extends State<_SearchResultTabs> {
  int selectedIndex = 0;

  final tabs = const ['All', 'Products', 'Services', 'Sellers'];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return SizedBox(
      height: 40,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: tabs.length,
        separatorBuilder: (_, _) => const Gap(8),
        itemBuilder: (context, index) {
          final selected = selectedIndex == index;

          return Material(
            color: selected ? theme.colorScheme.primary : theme.colorScheme.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(12),
            child: InkWell(
              onTap: () {
                setState(() {
                  selectedIndex = index;
                });
              },
              borderRadius: BorderRadius.circular(12),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Center(
                  child: Text(
                    tabs[index],
                    style: theme.textTheme.labelMedium?.copyWith(
                      color: selected ? theme.colorScheme.onPrimary : theme.colorScheme.onSurface,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _ResultSection extends StatelessWidget {
  const _ResultSection({required this.title, required this.child});

  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
        const Gap(12),
        child,
      ],
    );
  }
}

class _ServiceSearchResultList extends StatelessWidget {
  const _ServiceSearchResultList();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: const [
        _ServiceSearchResult(
          title: 'Electrician',
          seller: 'Sagar Electrical',
          price: 'From ₹150',
          rating: 4.9,
        ),
        Gap(10),
        _ServiceSearchResult(
          title: 'Electrical Repair',
          seller: 'Raj Electrical Services',
          price: 'From ₹200',
          rating: 4.7,
        ),
      ],
    );
  }
}

class _ServiceSearchResult extends StatelessWidget {
  const _ServiceSearchResult({
    required this.title,
    required this.seller,
    required this.price,
    required this.rating,
  });

  final String title;
  final String seller;
  final String price;
  final double rating;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Material(
      color: theme.colorScheme.surfaceContainerLow,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: () {
          // TODO: ServiceDetailsScreen
        },
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Container(
                width: 62,
                height: 62,
                decoration: BoxDecoration(
                  color: theme.colorScheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Center(
                  child: HugeIcon(
                    icon: HugeIcons.strokeRoundedTools,
                    size: 26,
                    color: theme.colorScheme.primary,
                  ),
                ),
              ),

              const Gap(12),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: theme.textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w700),
                    ),
                    const Gap(3),
                    Text(
                      seller,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                    const Gap(5),
                    Row(
                      children: [
                        HugeIcon(
                          icon: HugeIcons.strokeRoundedStar,
                          size: 14,
                          color: theme.colorScheme.primary,
                        ),
                        const Gap(3),
                        Text(
                          rating.toStringAsFixed(1),
                          style: theme.textTheme.labelSmall?.copyWith(fontWeight: FontWeight.w700),
                        ),
                        const Gap(8),
                        Text(
                          price,
                          style: theme.textTheme.labelMedium?.copyWith(fontWeight: FontWeight.w700),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              const Gap(8),

              Container(
                padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 8),
                decoration: BoxDecoration(
                  color: theme.colorScheme.primary,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  'BOOK',
                  style: theme.textTheme.labelSmall?.copyWith(
                    color: theme.colorScheme.onPrimary,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ProductSearchResultList extends StatelessWidget {
  const _ProductSearchResultList();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: const [
        _ProductSearchResult(title: 'Extension Board', seller: 'Sagar Electricals', price: '₹450'),
        const Gap(10),
        _ProductSearchResult(title: 'Homemade Poha', seller: "Sagar's Kitchen", price: '₹80'),
      ],
    );
  }
}

class _ProductSearchResult extends StatelessWidget {
  const _ProductSearchResult({required this.title, required this.seller, required this.price});

  final String title;
  final String seller;
  final String price;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Material(
      color: theme.colorScheme.surfaceContainerLow,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: () {
          // TODO: ProductDetailsScreen
        },
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Container(
                width: 62,
                height: 62,
                decoration: BoxDecoration(
                  color: theme.colorScheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Center(
                  child: HugeIcon(
                    icon: HugeIcons.strokeRoundedImage01,
                    size: 26,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ),

              const Gap(12),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: theme.textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w700),
                    ),
                    const Gap(3),
                    Text(
                      seller,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                    const Gap(6),
                    Text(
                      price,
                      style: theme.textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w800),
                    ),
                  ],
                ),
              ),

              Container(
                padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 8),
                decoration: BoxDecoration(
                  border: Border.all(color: theme.colorScheme.primary),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  'ADD',
                  style: theme.textTheme.labelSmall?.copyWith(
                    color: theme.colorScheme.primary,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SellerSearchResultList extends StatelessWidget {
  const _SellerSearchResultList();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: const [
        _SellerSearchResult(
          name: 'Sagar Electricals',
          description: 'Electrical products & services',
          rating: 4.9,
          listings: 8,
        ),
        const Gap(10),
        _SellerSearchResult(
          name: "Sagar's Kitchen",
          description: 'Homemade food & snacks',
          rating: 4.8,
          listings: 12,
        ),
      ],
    );
  }
}

class _SellerSearchResult extends StatelessWidget {
  const _SellerSearchResult({
    required this.name,
    required this.description,
    required this.rating,
    required this.listings,
  });

  final String name;
  final String description;
  final double rating;
  final int listings;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Material(
      color: theme.colorScheme.surfaceContainerLow,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: () {
          // TODO: SellerStoreScreen
        },
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(13),
          child: Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: theme.colorScheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Center(
                  child: HugeIcon(
                    icon: HugeIcons.strokeRoundedStore01,
                    size: 24,
                    color: theme.colorScheme.primary,
                  ),
                ),
              ),

              const Gap(12),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      style: theme.textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w700),
                    ),
                    const Gap(3),
                    Text(
                      description,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                    const Gap(5),
                    Row(
                      children: [
                        HugeIcon(
                          icon: HugeIcons.strokeRoundedStar,
                          size: 14,
                          color: theme.colorScheme.primary,
                        ),
                        const Gap(3),
                        Text(
                          rating.toStringAsFixed(1),
                          style: theme.textTheme.labelSmall?.copyWith(fontWeight: FontWeight.w700),
                        ),
                        const Gap(8),
                        Text(
                          '$listings listings',
                          style: theme.textTheme.labelSmall?.copyWith(
                            color: theme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              HugeIcon(
                icon: HugeIcons.strokeRoundedArrowRight01,
                size: 20,
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SearchFilterSheet extends StatefulWidget {
  const _SearchFilterSheet();

  @override
  State<_SearchFilterSheet> createState() => _SearchFilterSheetState();
}

class _SearchFilterSheetState extends State<_SearchFilterSheet> {
  String selectedType = 'All';
  String selectedSort = 'Recommended';

  final types = const ['All', 'Products', 'Food', 'Services', 'Sellers'];

  final sorts = const ['Recommended', 'Price: Low to High', 'Price: High to Low', 'Rating'];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Filter results',
              style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700),
            ),

            const Gap(24),

            Text('Show', style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700)),

            const Gap(10),

            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: types.map((type) {
                return _FilterChip(
                  label: type,
                  selected: selectedType == type,
                  onTap: () {
                    setState(() {
                      selectedType = type;
                    });
                  },
                );
              }).toList(),
            ),

            const Gap(22),

            Text(
              'Sort by',
              style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
            ),

            const Gap(10),

            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: sorts.map((sort) {
                return _FilterChip(
                  label: sort,
                  selected: selectedSort == sort,
                  onTap: () {
                    setState(() {
                      selectedSort = sort;
                    });
                  },
                );
              }).toList(),
            ),

            const Gap(24),

            SizedBox(
              width: double.infinity,
              height: 50,
              child: FilledButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('Apply filters'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  const _FilterChip({required this.label, required this.selected, required this.onTap});

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Material(
      color: selected ? theme.colorScheme.primary : theme.colorScheme.surfaceContainerHighest,
      borderRadius: BorderRadius.circular(11),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(11),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
          child: Text(
            label,
            style: theme.textTheme.labelMedium?.copyWith(
              color: selected ? theme.colorScheme.onPrimary : theme.colorScheme.onSurface,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ),
    );
  }
}

class _SearchSectionHeader extends StatelessWidget {
  const _SearchSectionHeader({required this.title, this.actionText, this.onAction});

  final String title;
  final String? actionText;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Row(
      children: [
        Expanded(
          child: Text(
            title,
            style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
          ),
        ),
        if (actionText != null) TextButton(onPressed: onAction, child: Text(actionText!)),
      ],
    );
  }
}
