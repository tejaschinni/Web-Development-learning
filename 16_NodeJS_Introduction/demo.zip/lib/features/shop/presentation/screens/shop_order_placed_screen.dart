import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';

class ShopOrderPlacedScreen extends StatelessWidget {
  const ShopOrderPlacedScreen({super.key, required this.orderData});

  final ShopOrderPlacedData orderData;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: theme.colorScheme.surface,
        elevation: 0,
        centerTitle: false,
        title: Text(
          'Order placed',
          style: GoogleFonts.hind(
            fontSize: 20,
            fontWeight: FontWeight.w700,
            color: theme.colorScheme.onSurface,
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _SuccessHeader(orderData: orderData),
                    const Gap(24),
                    _OrderReferenceCard(orderData: orderData),
                    const Gap(16),
                    _SellerOrdersSection(orderData: orderData),
                    const Gap(16),
                    _PaymentCard(orderData: orderData),
                    const Gap(16),
                    _ImportantNote(),
                  ],
                ),
              ),
            ),
            _BottomActions(
              onViewOrders: () => context.go('/shop/orders'),
              onContinueShopping: () => context.go('/'),
            ),
          ],
        ),
      ),
    );
  }
}

// SUCCESS HEADER
class _SuccessHeader extends StatelessWidget {
  const _SuccessHeader({required this.orderData});

  final ShopOrderPlacedData orderData;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Center(
      child: Column(
        children: [
          Container(
            width: 76,
            height: 76,
            decoration: BoxDecoration(
              color: theme.colorScheme.primary.withValues(alpha: 0.10),
              shape: BoxShape.circle,
            ),
            child: HugeIcon(
              icon: HugeIcons.strokeRoundedCheckmarkCircle02,
              size: 42,
              color: theme.colorScheme.primary,
            ),
          ),
          const Gap(18),
          Text(
            'Order placed successfully',
            textAlign: TextAlign.center,
            style: GoogleFonts.hind(
              fontSize: 23,
              height: 1.15,
              fontWeight: FontWeight.w700,
              color: theme.colorScheme.onSurface,
            ),
          ),
          const Gap(7),
          Text(
            'Thanks for shopping from your society marketplace.',
            textAlign: TextAlign.center,
            style: GoogleFonts.hind(
              fontSize: 14,
              height: 1.4,
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          if (orderData.orderCount > 1) ...[
            const Gap(8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: BoxDecoration(
                color: theme.colorScheme.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                '${orderData.orderCount} seller orders created',
                style: GoogleFonts.hind(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

// ORDER REFERENCE
class _OrderReferenceCard extends StatelessWidget {
  const _OrderReferenceCard({required this.orderData});

  final ShopOrderPlacedData orderData;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return _SectionCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'Checkout reference',
                  style: GoogleFonts.hind(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
              HugeIcon(
                icon: HugeIcons.strokeRoundedInformationCircle,
                size: 19,
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ],
          ),
          const Gap(6),
          Text(
            orderData.checkoutId,
            style: GoogleFonts.hind(
              fontSize: 17,
              fontWeight: FontWeight.w700,
              color: theme.colorScheme.onSurface,
              letterSpacing: 0.3,
            ),
          ),
          const Gap(14),
          Divider(height: 1, color: theme.colorScheme.outlineVariant.withValues(alpha: 0.6)),
          const Gap(14),
          Row(
            children: [
              HugeIcon(
                icon: HugeIcons.strokeRoundedClock01,
                size: 18,
                color: theme.colorScheme.onSurfaceVariant,
              ),
              const Gap(8),
              Text(
                'Placed ${orderData.createdAtLabel}',
                style: GoogleFonts.hind(fontSize: 13, color: theme.colorScheme.onSurfaceVariant),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// SELLER ORDERS
class _SellerOrdersSection extends StatelessWidget {
  const _SellerOrdersSection({required this.orderData});

  final ShopOrderPlacedData orderData;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Your orders',
          style: GoogleFonts.hind(
            fontSize: 17,
            fontWeight: FontWeight.w700,
            color: theme.colorScheme.onSurface,
          ),
        ),
        const Gap(10),
        ...orderData.sellerOrders.map(
          (order) => Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: _SellerOrderCard(order: order),
          ),
        ),
      ],
    );
  }
}

class _SellerOrderCard extends StatelessWidget {
  const _SellerOrderCard({required this.order});

  final ShopSellerOrderPlaced order;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return _SectionCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: theme.colorScheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: HugeIcon(
                  icon: HugeIcons.strokeRoundedStore01,
                  size: 22,
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
              const Gap(12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      order.sellerName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.hind(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: theme.colorScheme.onSurface,
                      ),
                    ),
                    const Gap(1),
                    Text(
                      '${order.itemCount} ${order.itemCount == 1 ? 'item' : 'items'}',
                      style: GoogleFonts.hind(
                        fontSize: 12,
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              Text(
                '₹${order.total.toStringAsFixed(0)}',
                style: GoogleFonts.hind(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: theme.colorScheme.onSurface,
                ),
              ),
            ],
          ),
          const Gap(14),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.55),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                _InfoRow(
                  icon: HugeIcons.strokeRoundedCheckmarkCircle02,
                  label: 'Order',
                  value: order.orderId,
                ),
                const Gap(8),
                _InfoRow(
                  icon: HugeIcons.strokeRoundedLocation01,
                  label: order.fulfillmentLabel,
                  value: order.fulfillmentDetail,
                ),
                if (order.etaLabel != null) ...[
                  const Gap(8),
                  _InfoRow(
                    icon: HugeIcons.strokeRoundedClock01,
                    label: order.etaTitle ?? 'Expected',
                    value: order.etaLabel!,
                  ),
                ],
              ],
            ),
          ),
          if (order.statusLabel != null) ...[
            const Gap(12),
            Row(
              children: [
                Container(
                  width: 7,
                  height: 7,
                  decoration: BoxDecoration(
                    color: theme.colorScheme.primary,
                    shape: BoxShape.circle,
                  ),
                ),
                const Gap(7),
                Text(
                  order.statusLabel!,
                  style: GoogleFonts.hind(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: theme.colorScheme.primary,
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

// PAYMENT
class _PaymentCard extends StatelessWidget {
  const _PaymentCard({required this.orderData});

  final ShopOrderPlacedData orderData;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return _SectionCard(
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: theme.colorScheme.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(12),
            ),
            child: HugeIcon(
              icon: HugeIcons.strokeRoundedWallet01,
              size: 22,
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          const Gap(12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Payment',
                  style: GoogleFonts.hind(fontSize: 12, color: theme.colorScheme.onSurfaceVariant),
                ),
                const Gap(1),
                Text(
                  orderData.paymentMethodLabel,
                  style: GoogleFonts.hind(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: theme.colorScheme.onSurface,
                  ),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '₹${orderData.totalAmount.toStringAsFixed(0)}',
                style: GoogleFonts.hind(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: theme.colorScheme.onSurface,
                ),
              ),
              const Gap(1),
              Text(
                orderData.paymentStatusLabel,
                style: GoogleFonts.hind(
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  color: theme.colorScheme.primary,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// IMPORTANT NOTE
class _ImportantNote extends StatelessWidget {
  const _ImportantNote();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: theme.colorScheme.primary.withValues(alpha: 0.06),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: theme.colorScheme.primary.withValues(alpha: 0.12)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          HugeIcon(
            icon: HugeIcons.strokeRoundedInformationCircle,
            size: 19,
            color: theme.colorScheme.primary,
          ),
          const Gap(10),
          Expanded(
            child: Text(
              'You can track delivery, view order details, or manage your '
              'orders from Orders.',
              style: GoogleFonts.hind(
                fontSize: 12.5,
                height: 1.4,
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// BOTTOM ACTIONS
class _BottomActions extends StatelessWidget {
  const _BottomActions({required this.onViewOrders, required this.onContinueShopping});

  final VoidCallback onViewOrders;
  final VoidCallback onContinueShopping;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        border: Border(
          top: BorderSide(color: theme.colorScheme.outlineVariant.withValues(alpha: 0.55)),
        ),
      ),
      child: SafeArea(
        top: false,
        child: Column(
          children: [
            SizedBox(
              width: double.infinity,
              height: 50,
              child: FilledButton(
                onPressed: onViewOrders,
                style: FilledButton.styleFrom(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                child: Text(
                  'VIEW ORDERS',
                  style: GoogleFonts.hind(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.3,
                  ),
                ),
              ),
            ),
            const Gap(8),
            SizedBox(
              width: double.infinity,
              height: 46,
              child: TextButton(
                onPressed: onContinueShopping,
                style: TextButton.styleFrom(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                child: Text(
                  'CONTINUE SHOPPING',
                  style: GoogleFonts.hind(fontSize: 13, fontWeight: FontWeight.w700),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// SHARED UI
class _SectionCard extends StatelessWidget {
  const _SectionCard({required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: theme.colorScheme.outlineVariant.withValues(alpha: 0.65)),
      ),
      child: child,
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({required this.icon, required this.label, required this.value});

  final dynamic icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        HugeIcon(icon: icon, size: 16, color: theme.colorScheme.onSurfaceVariant),
        const Gap(8),
        Expanded(
          child: Text(
            label,
            style: GoogleFonts.hind(fontSize: 12, color: theme.colorScheme.onSurfaceVariant),
          ),
        ),
        const Gap(12),
        Flexible(
          child: Text(
            value,
            textAlign: TextAlign.right,
            style: GoogleFonts.hind(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: theme.colorScheme.onSurface,
            ),
          ),
        ),
      ],
    );
  }
}

// DOMAIN/UI RESULT MODEL
class ShopOrderPlacedData {
  const ShopOrderPlacedData({
    required this.checkoutId,
    required this.createdAtLabel,
    required this.sellerOrders,
    required this.totalAmount,
    required this.paymentMethodLabel,
    required this.paymentStatusLabel,
  });

  final String checkoutId;
  final String createdAtLabel;

  /// One checkout can contain multiple seller-specific orders.
  final List<ShopSellerOrderPlaced> sellerOrders;

  final double totalAmount;
  final String paymentMethodLabel;
  final String paymentStatusLabel;

  int get orderCount => sellerOrders.length;
}

class ShopSellerOrderPlaced {
  const ShopSellerOrderPlaced({
    required this.orderId,
    required this.sellerId,
    required this.sellerName,
    required this.itemCount,
    required this.total,
    required this.fulfillmentLabel,
    required this.fulfillmentDetail,
    this.etaLabel,
    this.etaTitle,
    this.statusLabel,
  });

  final String orderId;
  final String sellerId;
  final String sellerName;

  final int itemCount;
  final double total;

  final String fulfillmentLabel;
  final String fulfillmentDetail;

  final String? etaLabel;
  final String? etaTitle;
  final String? statusLabel;
}
