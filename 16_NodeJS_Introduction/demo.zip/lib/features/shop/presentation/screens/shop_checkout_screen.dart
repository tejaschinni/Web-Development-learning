import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/core/network/api_exception.dart';
import 'package:society_seva/features/location/data/models/saved_address.dart';
import 'package:society_seva/features/location/presentation/providers/location_provider.dart';
import 'package:society_seva/features/shop/data/models/shop_checkout_models.dart';
import 'package:society_seva/features/shop/domain/entities/shop_cart.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_cart_provider.dart';

class ShopCheckoutScreen extends ConsumerStatefulWidget {
  final ShopCart cart;

  const ShopCheckoutScreen({super.key, required this.cart});

  @override
  ConsumerState<ShopCheckoutScreen> createState() => _ShopCheckoutScreenState();
}

class _ShopCheckoutScreenState extends ConsumerState<ShopCheckoutScreen> {
  late List<ShopFulfillmentSellerGroup> _groups;
  ShopDeliveryOptions? _deliveryOptions;
  Object? _optionsError;
  SavedAddress? _selectedAddress;
  DateTime? _scheduledAt;
  FulfillmentMethod _selectedMethod = FulfillmentMethod.none;
  final TextEditingController _buyerNoteController = TextEditingController();
  bool _loadingOptions = true;
  bool _addressContextResolved = false;

  @override
  void initState() {
    super.initState();
    final cart = widget.cart;
    _groups = [
      ShopFulfillmentSellerGroup(
        sellerId: cart.sellerId,
        sellerName: cart.sellerName,
        itemCount: cart.itemCount,
        subtotal: cart.subtotal,
        registeredFlat: 'Select a delivery address',
      ),
    ];
    final locationContext = ref.read(locationContextProvider).valueOrNull;
    _addressContextResolved = locationContext != null;
    _selectedAddress = locationContext?.activeAddress;
    _loadDeliveryOptions(addressId: _selectedAddress?.id);
  }

  @override
  void dispose() {
    _buyerNoteController.dispose();
    super.dispose();
  }

  Future<void> _loadDeliveryOptions({String? addressId}) async {
    setState(() {
      _loadingOptions = true;
      _optionsError = null;
    });
    try {
      final options = await ref
          .read(shopCheckoutRemoteDataSourceProvider)
          .getDeliveryOptions(sellerId: widget.cart.sellerId, addressId: addressId);
      if (!mounted) return;
      setState(() {
        _deliveryOptions = options;
        _loadingOptions = false;
        final currentMethod = _selectedMethod.apiValue;
        if (!options.availableMethods.contains(currentMethod)) {
          _selectedMethod = FulfillmentMethod.none;
          _groups = _groups
              .map((group) => group.copyWith(selectedMethod: FulfillmentMethod.none))
              .toList();
        }
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _optionsError = error;
        _loadingOptions = false;
      });
    }
  }

  bool get _canContinue {
    if (_loadingOptions || _optionsError != null || _deliveryOptions == null) return false;
    if (_selectedMethod == FulfillmentMethod.none) return false;
    if (_selectedMethod != FulfillmentMethod.pickupFromSeller && _selectedAddress == null) {
      return false;
    }
    if (_selectedMethod == FulfillmentMethod.scheduleDelivery && _scheduledAt == null) return false;
    return true;
  }

  void _selectMethod(String sellerId, FulfillmentMethod method) {
    setState(() {
      final index = _groups.indexWhere((group) => group.sellerId == sellerId);

      if (index == -1) return;

      _selectedMethod = method;
      _groups[index] = _groups[index].copyWith(selectedMethod: method);
    });
  }

  void _selectAddress(String? addressId, List<SavedAddress> addresses) {
    final address = addresses.where((item) => item.id == addressId).firstOrNull;
    setState(() {
      _selectedAddress = address;
      _selectedMethod = FulfillmentMethod.none;
      _scheduledAt = null;
      _groups = _groups
          .map((group) => group.copyWith(selectedMethod: FulfillmentMethod.none))
          .toList();
    });
    _loadDeliveryOptions(addressId: address?.id);
  }

  Future<void> _chooseSchedule() async {
    final now = DateTime.now();
    final date = await showDatePicker(
      context: context,
      firstDate: now,
      lastDate: now.add(const Duration(days: 90)),
      initialDate: _scheduledAt ?? now,
    );
    if (date == null || !mounted) return;
    final time = await showTimePicker(
      context: context,
      initialTime: _scheduledAt == null
          ? TimeOfDay.fromDateTime(now.add(const Duration(hours: 1)))
          : TimeOfDay.fromDateTime(_scheduledAt!),
    );
    if (time == null || !mounted) return;
    setState(() {
      _scheduledAt = DateTime(date.year, date.month, date.day, time.hour, time.minute);
    });
  }

  void _continueToCheckout() {
    if (!_canContinue) return;
    final method = _selectedMethod;
    final location = method == FulfillmentMethod.pickupFromSeller
        ? _deliveryOptions?.pickupAddress ?? 'Pickup from seller'
        : _selectedAddress?.addressLine1 ?? 'Delivery address not selected';
    context.push(
      '/shop/checkout/review',
      extra: ShopCheckoutSubmission(
        cart: widget.cart,
        fulfillmentMethod: method,
        fulfillmentDetail: location,
        deliveryAddressId: _selectedMethod == FulfillmentMethod.pickupFromSeller
            ? null
            : _selectedAddress?.id,
        scheduledAt: _scheduledAt,
        buyerNote: _buyerNoteController.text.trim(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    ref.listen(locationContextProvider, (_, next) {
      final locationContext = next.valueOrNull;
      if (_addressContextResolved || locationContext == null) return;
      _addressContextResolved = true;
      final activeAddress = locationContext.activeAddress;
      if (activeAddress == null) return;
      setState(() => _selectedAddress = activeAddress);
      _loadDeliveryOptions(addressId: activeAddress.id);
    });
    final addressContext = ref.watch(locationContextProvider).valueOrNull;
    final availableMethods = (_deliveryOptions?.availableMethods ?? const <String>[])
        .map(FulfillmentMethodX.fromApiValue)
        .whereType<FulfillmentMethod>()
        .toList();

    return Theme(
      data: theme.copyWith(textTheme: GoogleFonts.hindTextTheme(theme.textTheme)),
      child: Scaffold(
        backgroundColor: theme.colorScheme.surface,
        appBar: _buildAppBar(context),
        body: _groups.isEmpty
            ? const _EmptyFulfillmentView()
            : SafeArea(
                child: Column(
                  children: [
                    Expanded(
                      child: CustomScrollView(
                        physics: const BouncingScrollPhysics(),
                        slivers: [
                          SliverToBoxAdapter(child: _buildIntro(context)),
                          SliverToBoxAdapter(
                            child: _buildAddressSelector(
                              context,
                              addressContext?.savedAddresses ?? const [],
                            ),
                          ),
                          if (_loadingOptions)
                            const SliverToBoxAdapter(
                              child: Padding(
                                padding: EdgeInsets.all(24),
                                child: Center(child: CircularProgressIndicator()),
                              ),
                            )
                          else if (_optionsError != null)
                            SliverToBoxAdapter(child: _buildOptionsError(context))
                          else
                            SliverToBoxAdapter(child: _buildDeliveryDetails(context)),
                          SliverPadding(
                            padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                            sliver: SliverList.separated(
                              itemCount: _loadingOptions || _optionsError != null
                                  ? 0
                                  : _groups.length,
                              separatorBuilder: (_, _) => const Gap(16),
                              itemBuilder: (context, index) {
                                final group = _groups[index];

                                return _SellerFulfillmentCard(
                                  group: group,
                                  availableMethods: availableMethods,
                                  pickupAddress: _deliveryOptions?.pickupAddress,
                                  scheduledAt: _scheduledAt,
                                  onChooseSchedule: _chooseSchedule,
                                  onMethodSelected: (method) {
                                    _selectMethod(group.sellerId, method);
                                  },
                                );
                              },
                            ),
                          ),
                          SliverToBoxAdapter(child: _buildBuyerNote(context)),
                          SliverToBoxAdapter(child: _buildImportantNote(context)),
                          const SliverToBoxAdapter(child: Gap(110)),
                        ],
                      ),
                    ),
                    _buildBottomBar(context),
                  ],
                ),
              ),
      ),
    );
  }

  Widget _buildAddressSelector(BuildContext context, List<SavedAddress> addresses) {
    final theme = Theme.of(context);
    final selectedAddressId = addresses.any((item) => item.id == _selectedAddress?.id)
        ? _selectedAddress?.id
        : null;

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Delivery address',
            style: GoogleFonts.hind(fontSize: 15, fontWeight: FontWeight.w700),
          ),
          const Gap(7),
          if (addresses.isEmpty)
            Text(
              'No saved address. Pickup may still be available.',
              style: GoogleFonts.hind(fontSize: 13, color: theme.colorScheme.onSurfaceVariant),
            )
          else
            DropdownButtonFormField<String>(
              isExpanded: true,
              initialValue: selectedAddressId,
              decoration: const InputDecoration(border: OutlineInputBorder()),
              hint: const Text('Choose an address'),
              items: addresses
                  .map(
                    (address) => DropdownMenuItem<String>(
                      value: address.id,
                      child: SizedBox(
                        width: double.infinity,
                        child: Text(
                          '${address.label}: ${address.addressLine1}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ),
                  )
                  .toList(),
              onChanged: (addressId) => _selectAddress(addressId, addresses),
            ),
        ],
      ),
    );
  }

  Widget _buildOptionsError(BuildContext context) {
    final message = _optionsError is ApiException
        ? (_optionsError as ApiException).message
        : 'Unable to load delivery options';
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          Text(message, textAlign: TextAlign.center),
          TextButton.icon(
            onPressed: () => _loadDeliveryOptions(addressId: _selectedAddress?.id),
            icon: const Icon(Icons.refresh),
            label: const Text('Try again'),
          ),
        ],
      ),
    );
  }

  Widget _buildDeliveryDetails(BuildContext context) {
    final options = _deliveryOptions;
    if (options == null) {
      return const SizedBox.shrink();
    }
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(
          color: theme.colorScheme.surfaceContainerLow,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: theme.colorScheme.outlineVariant),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              [
                if (options.pickupAvailable) 'Pickup available',
                if (options.sellerDeliveryAvailable) 'Seller delivery available',
                if (options.scheduleDeliveryAvailable) 'Scheduled delivery available',
                if (options.nearbyEligible) 'Nearby delivery eligible',
              ].join(' · '),
              style: GoogleFonts.hind(fontSize: 12, fontWeight: FontWeight.w600),
            ),
            if (options.pickupAddress != null) ...[
              const Gap(6),
              Text('Pickup address', style: GoogleFonts.hind(fontWeight: FontWeight.w700)),
              Text(options.pickupAddress!, style: GoogleFonts.hind(fontSize: 13)),
            ],
            if (options.reason != null) ...[
              const Gap(6),
              Text(
                options.reason!,
                style: GoogleFonts.hind(fontSize: 12, color: theme.colorScheme.onSurfaceVariant),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildBuyerNote(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      child: TextField(
        controller: _buyerNoteController,
        maxLength: 300,
        minLines: 1,
        maxLines: 3,
        decoration: const InputDecoration(
          labelText: 'Note for seller',
          hintText: 'Add delivery or handoff instructions',
          border: OutlineInputBorder(),
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context) {
    final theme = Theme.of(context);

    return AppBar(
      elevation: 0,
      scrolledUnderElevation: 0,
      backgroundColor: theme.colorScheme.surface,
      leading: IconButton(
        onPressed: () => Navigator.of(context).maybePop(),
        icon: HugeIcon(
          icon: HugeIcons.strokeRoundedArrowLeft01,
          size: 24,
          color: theme.colorScheme.onSurface,
        ),
      ),
      titleSpacing: 0,
      title: Text(
        'Fulfillment',
        style: GoogleFonts.hind(
          fontSize: 22,
          fontWeight: FontWeight.w700,
          color: theme.colorScheme.onSurface,
        ),
      ),
    );
  }

  Widget _buildIntro(BuildContext context) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: theme.colorScheme.surfaceContainerLow,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: theme.colorScheme.outlineVariant),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: theme.colorScheme.primaryContainer,
                borderRadius: BorderRadius.circular(12),
              ),
              child: HugeIcon(
                icon: HugeIcons.strokeRoundedLocation01,
                size: 21,
                color: theme.colorScheme.primary,
              ),
            ),
            const Gap(12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Choose how you’ll receive your items',
                    style: GoogleFonts.hind(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: theme.colorScheme.onSurface,
                    ),
                  ),
                  const Gap(3),
                  Text(
                    'Choose one of the delivery methods available for this seller.',
                    style: GoogleFonts.hind(
                      fontSize: 13,
                      height: 1.35,
                      fontWeight: FontWeight.w500,
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildImportantNote(BuildContext context) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          HugeIcon(
            icon: HugeIcons.strokeRoundedInformationCircle,
            size: 18,
            color: theme.colorScheme.onSurfaceVariant,
          ),
          const Gap(9),
          Expanded(
            child: Text(
              'Your selected fulfillment method and any applicable delivery '
              'charges will be shown again before payment.',
              style: GoogleFonts.hind(
                fontSize: 12,
                height: 1.45,
                fontWeight: FontWeight.w500,
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomBar(BuildContext context) {
    final theme = Theme.of(context);

    final completedCount = _groups
        .where((group) => group.selectedMethod != FulfillmentMethod.none)
        .length;

    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        border: Border(top: BorderSide(color: theme.colorScheme.outlineVariant)),
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '$completedCount of ${_groups.length} sellers selected',
                    style: GoogleFonts.hind(
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                  const Gap(2),
                  Text(
                    'Next: Checkout',
                    style: GoogleFonts.hind(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      color: theme.colorScheme.onSurface,
                    ),
                  ),
                ],
              ),
            ),
            const Gap(14),
            FilledButton(
              onPressed: _canContinue ? _continueToCheckout : null,
              style: FilledButton.styleFrom(
                minimumSize: const Size(0, 52),
                padding: const EdgeInsets.symmetric(horizontal: 20),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Continue',
                    style: GoogleFonts.hind(fontSize: 15, fontWeight: FontWeight.w700),
                  ),
                  const Gap(8),
                  HugeIcon(
                    icon: HugeIcons.strokeRoundedArrowRight01,
                    size: 19,
                    color: _canContinue
                        ? theme.colorScheme.onPrimary
                        : theme.colorScheme.onSurfaceVariant,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SellerFulfillmentCard extends StatelessWidget {
  final ShopFulfillmentSellerGroup group;
  final List<FulfillmentMethod> availableMethods;
  final String? pickupAddress;
  final DateTime? scheduledAt;
  final ValueChanged<FulfillmentMethod> onMethodSelected;
  final VoidCallback onChooseSchedule;

  const _SellerFulfillmentCard({
    required this.group,
    required this.availableMethods,
    required this.pickupAddress,
    required this.scheduledAt,
    required this.onMethodSelected,
    required this.onChooseSchedule,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: theme.colorScheme.outlineVariant),
      ),
      child: Column(
        children: [
          _buildSellerHeader(context),
          Divider(height: 1, color: theme.colorScheme.outlineVariant),
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'How would you like to receive it?',
                  style: GoogleFonts.hind(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: theme.colorScheme.onSurface,
                  ),
                ),
                const Gap(10),
                if (availableMethods.isEmpty)
                  Text(
                    'No delivery methods are currently available for this seller.',
                    style: GoogleFonts.hind(
                      fontSize: 13,
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ...availableMethods.map(
                  (method) => Padding(
                    padding: const EdgeInsets.only(bottom: 9),
                    child: _FulfillmentOption(
                      method: method,
                      selected: group.selectedMethod == method,
                      detail: method == FulfillmentMethod.pickupFromSeller ? pickupAddress : null,
                      scheduledAt: scheduledAt,
                      onTap: () {
                        onMethodSelected(method);
                      },
                      onChooseSchedule: method == FulfillmentMethod.scheduleDelivery
                          ? onChooseSchedule
                          : null,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSellerHeader(BuildContext context) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: theme.colorScheme.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(12),
            ),
            child: HugeIcon(
              icon: HugeIcons.strokeRoundedStore01,
              size: 20,
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          const Gap(11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  group.sellerName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.hind(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: theme.colorScheme.onSurface,
                  ),
                ),
                const Gap(1),
                Text(
                  '${group.itemCount} ${group.itemCount == 1 ? 'item' : 'items'} · ₹${group.subtotal.toStringAsFixed(0)}',
                  style: GoogleFonts.hind(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _FulfillmentOption extends StatelessWidget {
  final FulfillmentMethod method;
  final bool selected;
  final String? detail;
  final DateTime? scheduledAt;
  final VoidCallback onTap;
  final VoidCallback? onChooseSchedule;

  const _FulfillmentOption({
    required this.method,
    required this.selected,
    required this.detail,
    required this.scheduledAt,
    required this.onTap,
    required this.onChooseSchedule,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    final primary = theme.colorScheme.onSurface;
    final secondary = theme.colorScheme.onSurfaceVariant;

    return Material(
      color: selected
          ? theme.colorScheme.primaryContainer.withValues(alpha: 0.42)
          : theme.colorScheme.surface,
      borderRadius: BorderRadius.circular(15),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(15),
        child: Container(
          padding: const EdgeInsets.all(13),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            border: Border.all(
              color: selected ? theme.colorScheme.primary : theme.colorScheme.outlineVariant,
              width: selected ? 1.4 : 1,
            ),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _SelectionIndicator(selected: selected),
              const Gap(11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        HugeIcon(
                          icon: method.icon,
                          size: 19,
                          color: selected ? theme.colorScheme.primary : secondary,
                        ),
                        const Gap(8),
                        Expanded(
                          child: Text(
                            method.title,
                            style: GoogleFonts.hind(
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                              color: primary,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const Gap(3),
                    Text(
                      _description,
                      style: GoogleFonts.hind(
                        fontSize: 12,
                        height: 1.35,
                        fontWeight: FontWeight.w500,
                        color: secondary,
                      ),
                    ),
                    if (selected && detail != null) ...[
                      const Gap(7),
                      _DetailChip(icon: method.icon, text: detail!),
                    ],
                    if (selected && method == FulfillmentMethod.scheduleDelivery) ...[
                      const Gap(8),
                      OutlinedButton.icon(
                        onPressed: onChooseSchedule,
                        style: OutlinedButton.styleFrom(
                          minimumSize: const Size(0, 40),
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                        ),
                        icon: HugeIcon(
                          icon: HugeIcons.strokeRoundedCalendar03,
                          size: 16,
                          color: theme.colorScheme.primary,
                        ),
                        label: Text(
                          scheduledAt == null
                              ? 'Choose date and time'
                              : '${MaterialLocalizations.of(context).formatMediumDate(scheduledAt!)} · ${TimeOfDay.fromDateTime(scheduledAt!).format(context)}',
                          style: GoogleFonts.hind(fontSize: 12, fontWeight: FontWeight.w600),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String get _description {
    switch (method) {
      case FulfillmentMethod.deliverToMyFlat:
        return 'Delivered to your registered flat.';
      case FulfillmentMethod.pickupFromSeller:
        return 'Collect your items directly from the seller.';
      case FulfillmentMethod.scheduleDelivery:
        return 'Choose a date and time for delivery.';
      case FulfillmentMethod.commonLocationMeetup:
        return 'Meet the seller at a common society location.';
      case FulfillmentMethod.societyHelperDelivery:
        return 'A society helper delivers the items to your flat.';
      case FulfillmentMethod.none:
        return '';
    }
  }
}

class _SelectionIndicator extends StatelessWidget {
  final bool selected;

  const _SelectionIndicator({required this.selected});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      width: 22,
      height: 22,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(
          color: selected ? theme.colorScheme.primary : theme.colorScheme.outline,
          width: selected ? 6 : 1.5,
        ),
      ),
    );
  }
}

class _DetailChip extends StatelessWidget {
  final dynamic icon;
  final String text;

  const _DetailChip({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(9),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          HugeIcon(icon: icon, size: 15, color: theme.colorScheme.onSurfaceVariant),
          const Gap(6),
          Flexible(
            child: Text(
              text,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: GoogleFonts.hind(
                fontSize: 11,
                fontWeight: FontWeight.w600,
                color: theme.colorScheme.onSurface,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _EmptyFulfillmentView extends StatelessWidget {
  const _EmptyFulfillmentView();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return SafeArea(
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              HugeIcon(
                icon: HugeIcons.strokeRoundedShoppingCart02,
                size: 42,
                color: theme.colorScheme.onSurfaceVariant,
              ),
              const Gap(18),
              Text(
                'Nothing to fulfil',
                style: GoogleFonts.hind(
                  fontSize: 21,
                  fontWeight: FontWeight.w800,
                  color: theme.colorScheme.onSurface,
                ),
              ),
              const Gap(6),
              Text(
                'Your cart does not contain any items.',
                textAlign: TextAlign.center,
                style: GoogleFonts.hind(fontSize: 14, color: theme.colorScheme.onSurfaceVariant),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

enum FulfillmentMethod {
  none,
  deliverToMyFlat,
  pickupFromSeller,
  scheduleDelivery,
  commonLocationMeetup,
  societyHelperDelivery,
}

extension FulfillmentMethodX on FulfillmentMethod {
  String get apiValue {
    switch (this) {
      case FulfillmentMethod.deliverToMyFlat:
        return 'DELIVER_TO_ME';
      case FulfillmentMethod.pickupFromSeller:
        return 'PICKUP';
      case FulfillmentMethod.scheduleDelivery:
        return 'SCHEDULE_DELIVERY';
      case FulfillmentMethod.none:
      case FulfillmentMethod.commonLocationMeetup:
      case FulfillmentMethod.societyHelperDelivery:
        return '';
    }
  }

  static FulfillmentMethod? fromApiValue(String value) {
    switch (value) {
      case 'DELIVER_TO_ME':
        return FulfillmentMethod.deliverToMyFlat;
      case 'PICKUP':
        return FulfillmentMethod.pickupFromSeller;
      case 'SCHEDULE_DELIVERY':
        return FulfillmentMethod.scheduleDelivery;
      default:
        return null;
    }
  }

  String get title {
    switch (this) {
      case FulfillmentMethod.deliverToMyFlat:
        return 'Deliver to my flat';
      case FulfillmentMethod.pickupFromSeller:
        return 'Pick up from seller';
      case FulfillmentMethod.scheduleDelivery:
        return 'Schedule delivery';
      case FulfillmentMethod.commonLocationMeetup:
        return 'Common location meetup';
      case FulfillmentMethod.societyHelperDelivery:
        return 'Society helper delivery';
      case FulfillmentMethod.none:
        return '';
    }
  }

  dynamic get icon {
    switch (this) {
      case FulfillmentMethod.deliverToMyFlat:
        return HugeIcons.strokeRoundedHome01;
      case FulfillmentMethod.pickupFromSeller:
        return HugeIcons.strokeRoundedStore01;
      case FulfillmentMethod.scheduleDelivery:
        return HugeIcons.strokeRoundedCalendar03;
      case FulfillmentMethod.commonLocationMeetup:
        return HugeIcons.strokeRoundedLocation01;
      case FulfillmentMethod.societyHelperDelivery:
        return HugeIcons.strokeRoundedDeliveryTruck01;
      case FulfillmentMethod.none:
        return HugeIcons.strokeRoundedLocation01;
    }
  }
}

class ShopCheckoutSubmission {
  const ShopCheckoutSubmission({
    required this.cart,
    required this.fulfillmentMethod,
    required this.fulfillmentDetail,
    required this.deliveryAddressId,
    required this.scheduledAt,
    required this.buyerNote,
  });

  final ShopCart cart;
  final FulfillmentMethod fulfillmentMethod;
  final String fulfillmentDetail;
  final String? deliveryAddressId;
  final DateTime? scheduledAt;
  final String buyerNote;
}

class ShopFulfillmentSellerGroup {
  final String sellerId;
  final String sellerName;
  final int itemCount;
  final double subtotal;
  final String registeredFlat;
  final FulfillmentMethod selectedMethod;
  final String? meetupLocation;

  const ShopFulfillmentSellerGroup({
    required this.sellerId,
    required this.sellerName,
    required this.itemCount,
    required this.subtotal,
    required this.registeredFlat,
    this.selectedMethod = FulfillmentMethod.none,
    this.meetupLocation,
  });

  ShopFulfillmentSellerGroup copyWith({FulfillmentMethod? selectedMethod, String? meetupLocation}) {
    return ShopFulfillmentSellerGroup(
      sellerId: sellerId,
      sellerName: sellerName,
      itemCount: itemCount,
      subtotal: subtotal,
      registeredFlat: registeredFlat,
      selectedMethod: selectedMethod ?? this.selectedMethod,
      meetupLocation: meetupLocation,
    );
  }
}

class ShopFulfillmentMockData {
  static const groups = [
    ShopFulfillmentSellerGroup(
      sellerId: 'seller_sagar',
      sellerName: "Sagar's Kitchen",
      itemCount: 2,
      subtotal: 240,
      registeredFlat: 'Flat B-1204',
    ),
    ShopFulfillmentSellerGroup(
      sellerId: 'seller_neha',
      sellerName: "Neha's Bakery",
      itemCount: 1,
      subtotal: 420,
      registeredFlat: 'Flat B-1204',
    ),
  ];
}
