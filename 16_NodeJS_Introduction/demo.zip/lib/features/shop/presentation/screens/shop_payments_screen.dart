import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/features/shop/data/models/shop_checkout_models.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_cart_provider.dart';

class ShopPaymentsScreen extends ConsumerStatefulWidget {
  const ShopPaymentsScreen({super.key});

  @override
  ConsumerState<ShopPaymentsScreen> createState() => _ShopPaymentsScreenState();
}

class _ShopPaymentsScreenState extends ConsumerState<ShopPaymentsScreen> {
  late Future<List<ShopPaymentResult>> _paymentsFuture;

  @override
  void initState() {
    super.initState();
    _loadPayments();
  }

  void _loadPayments() {
    _paymentsFuture = ref.read(shopCheckoutRemoteDataSourceProvider).getMyPayments();
  }

  Future<void> _refresh() async {
    setState(_loadPayments);
    await _paymentsFuture;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      appBar: AppBar(
        backgroundColor: theme.colorScheme.surface,
        title: Text('Payments', style: GoogleFonts.hind(fontSize: 21, fontWeight: FontWeight.w700)),
      ),
      body: FutureBuilder<List<ShopPaymentResult>>(
        future: _paymentsFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('Unable to load payment history'),
                  TextButton.icon(
                    onPressed: () => setState(_loadPayments),
                    icon: const Icon(Icons.refresh),
                    label: const Text('Try again'),
                  ),
                ],
              ),
            );
          }
          final payments = snapshot.data ?? const [];
          if (payments.isEmpty) {
            return const Center(child: Text('No payments yet'));
          }
          return RefreshIndicator(
            onRefresh: _refresh,
            child: ListView.separated(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.all(16),
              itemCount: payments.length,
              separatorBuilder: (_, _) => const Gap(10),
              itemBuilder: (context, index) => _PaymentTile(payment: payments[index]),
            ),
          );
        },
      ),
    );
  }
}

class _PaymentTile extends StatelessWidget {
  const _PaymentTile({required this.payment});

  final ShopPaymentResult payment;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final createdAt = DateTime.tryParse(payment.createdAt ?? '')?.toLocal();
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        border: Border.all(color: theme.colorScheme.outlineVariant),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          HugeIcon(
            icon: HugeIcons.strokeRoundedMoney03,
            size: 22,
            color: theme.colorScheme.primary,
          ),
          const Gap(12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${payment.paymentMethod} · ${payment.paymentStatus.replaceAll('_', ' ')}',
                  style: GoogleFonts.hind(fontSize: 14, fontWeight: FontWeight.w700),
                ),
                const Gap(2),
                Text(
                  'Order ${payment.orderId}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.hind(fontSize: 11, color: theme.colorScheme.onSurfaceVariant),
                ),
                if (createdAt != null)
                  Text(
                    MaterialLocalizations.of(context).formatMediumDate(createdAt),
                    style: GoogleFonts.hind(
                      fontSize: 11,
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
              ],
            ),
          ),
          const Gap(8),
          Text(
            '₹${payment.amount.toStringAsFixed(payment.amount % 1 == 0 ? 0 : 2)}',
            style: GoogleFonts.hind(fontSize: 15, fontWeight: FontWeight.w800),
          ),
        ],
      ),
    );
  }
}
