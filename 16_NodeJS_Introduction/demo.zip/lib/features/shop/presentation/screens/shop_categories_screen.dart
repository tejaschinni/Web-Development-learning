import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/features/shop/domain/entities/shop_category.dart';
import 'package:society_seva/features/shop/domain/enums/shop_category_type.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_category_provider.dart';

class ShopCategoriesScreen extends ConsumerWidget {
  const ShopCategoriesScreen({super.key, required this.societyId});

  final String? societyId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final categoriesAsync = ref.watch(shopCategoriesProvider);

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      appBar: AppBar(
        title: Text('Explore', style: GoogleFonts.hind(fontWeight: FontWeight.w700)),
      ),
      body: categoriesAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, _) =>
            Center(child: Text('Unable to load categories', style: theme.textTheme.bodyMedium)),
        data: (categories) {
          final visibleCategories =
              categories.where((category) => category.isActive && category.isTopLevel).toList()
                ..sort((a, b) => a.displayOrder.compareTo(b.displayOrder));

          if (visibleCategories.isEmpty) {
            return Center(
              child: Text('No categories available', style: theme.textTheme.bodyMedium),
            );
          }

          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 32),
            itemCount: visibleCategories.length,
            separatorBuilder: (_, _) => const Gap(12),
            itemBuilder: (context, index) {
              final category = visibleCategories[index];

              return _CategoryTile(
                category: category,
                onTap: () {
                  final listingType = category.categoryType == ShopCategoryType.service
                      ? 'service'
                      : 'product';

                  context.push(
                    '/shop/$listingType/category/${category.id}?name=${Uri.encodeComponent(category.name)}',
                    extra: societyId,
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}

class _CategoryTile extends StatelessWidget {
  const _CategoryTile({required this.category, required this.onTap});

  final ShopCategory category;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Material(
      color: theme.colorScheme.surfaceContainerHighest,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: theme.colorScheme.surface,
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Center(
                  child: HugeIcon(
                    icon: _categoryIconFor(category),
                    size: 24,
                    color: theme.colorScheme.primary,
                  ),
                ),
              ),
              const Gap(14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      category.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
                    ),
                    const Gap(2),
                    Text(
                      category.isService ? 'Services' : 'Products',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              HugeIcon(
                icon: HugeIcons.strokeRoundedArrowRight01,
                size: 20,
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

List<List<dynamic>> _categoryIconFor(ShopCategory category) {
  switch (category.slug.toLowerCase()) {
    case 'breakfast':
      return HugeIcons.strokeRoundedCoffee01;

    case 'dinner':
      return HugeIcons.strokeRoundedDish01;

    case 'electric':
    case 'electrician':
    case 'elec':
      return HugeIcons.strokeRoundedPlug01;

    case 'repair':
    case 'ran-repair':
      return HugeIcons.strokeRoundedTools;

    case 'classes':
      return HugeIcons.strokeRoundedBookOpen01;

    default:
      switch (category.categoryType) {
        case ShopCategoryType.food:
          return HugeIcons.strokeRoundedRestaurant01;

        case ShopCategoryType.service:
          return HugeIcons.strokeRoundedTools;

        case ShopCategoryType.product:
          return HugeIcons.strokeRoundedShoppingBag01;

        case ShopCategoryType.unknown:
          return HugeIcons.strokeRoundedGridView;
      }
  }
}
