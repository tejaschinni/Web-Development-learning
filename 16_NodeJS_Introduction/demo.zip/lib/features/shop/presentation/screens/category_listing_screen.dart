import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_listing_provider.dart';
import 'package:society_seva/features/shop/presentation/widgets/category/shop_category_header.dart';
import 'package:society_seva/features/shop/presentation/widgets/category/shop_category_search_bar.dart';
import 'package:society_seva/features/shop/presentation/widgets/category/shop_filter_bar.dart';
import 'package:society_seva/features/shop/presentation/widgets/category/shop_product_grid.dart';
import 'package:society_seva/features/shop/presentation/widgets/category/shop_service_listing.dart';

enum ShopListingType { product, service }

class CategoryListingScreen extends ConsumerStatefulWidget {
  const CategoryListingScreen({
    super.key,
    required this.categoryId,
    required this.categoryName,
    required this.societyId,
    this.listingType = ShopListingType.product,
  });

  final String categoryId;
  final String categoryName;
  final String? societyId;
  final ShopListingType listingType;

  @override
  ConsumerState<CategoryListingScreen> createState() =>
      _CategoryListingScreenState();
}

class _CategoryListingScreenState extends ConsumerState<CategoryListingScreen> {
  String selectedSort = 'Recommended';

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    final isService = widget.listingType == ShopListingType.service;
    final societyId = widget.societyId ?? '';
    final listingsAsync = ref.watch(
      shopCategoryListingsProvider((
        categoryId: widget.categoryId,
        societyId: societyId,
      )),
    );
    final totalElements = listingsAsync.valueOrNull?.totalElements;

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      body: SafeArea(
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(
              child: CategoryHeader(
                title: widget.categoryName,
                onBack: () {
                  Navigator.of(context).pop();
                },
                onCartTap: () => context.push('/shop/cart'),
              ),
            ),

            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
              sliver: SliverToBoxAdapter(
                child: CategorySearchBar(
                  categoryName: widget.categoryName,
                  onTap: () {
                    // TODO: Open category-scoped search.
                    // context.push(
                    //   '/shop/category/$category?listingType=product',
                    // );
                  },
                ),
              ),
            ),

            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 0),
              sliver: SliverToBoxAdapter(
                child: FilterBar(
                  selectedSort: selectedSort,
                  onSortChanged: (value) {
                    setState(() {
                      selectedSort = value;
                    });
                  },
                  isService: isService,
                ),
              ),
            ),

            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
              sliver: SliverToBoxAdapter(
                child: Row(
                  children: [
                    Text(
                      isService
                          ? totalElements == null
                                ? 'Available services'
                                : 'Available services ($totalElements)'
                          : totalElements == null
                          ? 'Listings'
                          : '$totalElements results',
                      style: theme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 14, 20, 32),
              sliver: SliverToBoxAdapter(
                child: _buildListingContent(context, listingsAsync),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildListingContent(
    BuildContext context,
    AsyncValue<PageResponse<ShopListing>> listingsAsync,
  ) {
    final societyId = widget.societyId ?? '';

    final providerArgs = (categoryId: widget.categoryId, societyId: societyId);
    return listingsAsync.when(
      loading: () => const Padding(
        padding: EdgeInsets.symmetric(vertical: 48),
        child: Center(child: CircularProgressIndicator()),
      ),
      error: (error, stackTrace) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 32),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Unable to load listings'),
              const Gap(12),
              TextButton.icon(
                onPressed: () =>
                    ref.invalidate(shopCategoryListingsProvider(providerArgs)),
                icon: const Icon(Icons.refresh),
                label: const Text('Try again'),
              ),
            ],
          ),
        ),
      ),
      data: (page) {
        if (page.content.isEmpty) {
          return const Padding(
            padding: EdgeInsets.symmetric(vertical: 48),
            child: Center(child: Text('No listings found in this category')),
          );
        }

        final listings = [...page.content];
        final comparator = switch (selectedSort) {
          'Price: Low to High' => (
            ShopListing a,
            ShopListing b,
          ) => a.basePrice.compareTo(b.basePrice),
          'Price: High to Low' => (
            ShopListing a,
            ShopListing b,
          ) => b.basePrice.compareTo(a.basePrice),
          'Rating' => (
            ShopListing a,
            ShopListing b,
          ) => b.averageRating.compareTo(a.averageRating),
          _ => null,
        };
        if (comparator != null) listings.sort(comparator);

        return widget.listingType == ShopListingType.service
            ? ServiceListing(listings: listings)
            : ProductGrid(listings: listings);
      },
    );
  }
}
