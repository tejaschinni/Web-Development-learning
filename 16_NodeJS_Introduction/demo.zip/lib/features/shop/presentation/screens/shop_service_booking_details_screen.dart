import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';

/// Resident-facing service booking details / management screen.
///
/// This screen is opened from:
/// Shop → Orders → Services → View Booking
///
/// IMPORTANT:
/// - Opening this screen does NOT call any mutation API.
/// - Reschedule / Cancel are intentionally represented as UI actions only.
/// - Replace mock data with the repository/Riverpod state when API integration
///   is connected.
///
/// Expected backend source:
/// GET /api/v1/orders/{bookingId}
/// or a dedicated service-booking endpoint when finalized.
class ShopServiceBookingDetailsScreen extends StatefulWidget {
  const ShopServiceBookingDetailsScreen({super.key, required this.booking});

  final ShopServiceBookingDetails booking;

  @override
  State<ShopServiceBookingDetailsScreen> createState() => _ShopServiceBookingDetailsScreenState();
}

class _ShopServiceBookingDetailsScreenState extends State<ShopServiceBookingDetailsScreen> {
  Future<void> _showCancelConfirmation() async {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final confirmed = await showModalBottomSheet<bool>(
      context: context,
      backgroundColor: colorScheme.surface,
      isScrollControlled: true,
      builder: (context) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 42,
                  height: 4,
                  decoration: BoxDecoration(
                    color: colorScheme.outlineVariant,
                    borderRadius: BorderRadius.circular(99),
                  ),
                ),
                const Gap(24),
                _IconCircle(
                  icon: HugeIcons.strokeRoundedInformationCircle,
                  backgroundColor: colorScheme.errorContainer,
                  iconColor: colorScheme.onErrorContainer,
                ),
                const Gap(16),
                Text(
                  'Cancel this booking?',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.hind(
                    fontSize: 21,
                    fontWeight: FontWeight.w700,
                    color: colorScheme.onSurface,
                  ),
                ),
                const Gap(8),
                Text(
                  'You can cancel this booking only if it is still within the seller\'s cancellation window.',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.hind(
                    fontSize: 14,
                    height: 1.45,
                    color: colorScheme.onSurfaceVariant,
                  ),
                ),
                const Gap(22),
                Row(
                  children: [
                    Expanded(
                      child: _SecondaryButton(
                        label: 'Keep booking',
                        onPressed: () => Navigator.of(context).pop(false),
                      ),
                    ),
                    const Gap(12),
                    Expanded(
                      child: _PrimaryButton(
                        label: 'Cancel booking',
                        backgroundColor: colorScheme.error,
                        foregroundColor: colorScheme.onError,
                        onPressed: () => Navigator.of(context).pop(true),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );

    if (confirmed != true || !mounted) {
      return;
    }

    // TODO:
    // Call the cancellation API here.
    //
    // Example future flow:
    // await ref.read(serviceBookingControllerProvider.notifier)
    //     .cancelBooking(widget.booking.bookingId);
    //
    // Do NOT mutate booking state locally as if cancellation succeeded.
    // Refresh from backend after the API confirms success.

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Cancellation will be connected to the booking API.',
          style: GoogleFonts.hind(),
        ),
      ),
    );
  }

  Future<void> _showRescheduleSheet() async {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: colorScheme.surface,
      isScrollControlled: true,
      builder: (context) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 42,
                    height: 4,
                    decoration: BoxDecoration(
                      color: colorScheme.outlineVariant,
                      borderRadius: BorderRadius.circular(99),
                    ),
                  ),
                ),
                const Gap(22),
                Text(
                  'Reschedule booking',
                  style: GoogleFonts.hind(
                    fontSize: 21,
                    fontWeight: FontWeight.w700,
                    color: colorScheme.onSurface,
                  ),
                ),
                const Gap(6),
                Text(
                  'Choose a new date and time from the seller\'s available slots.',
                  style: GoogleFonts.hind(
                    fontSize: 14,
                    height: 1.45,
                    color: colorScheme.onSurfaceVariant,
                  ),
                ),
                const Gap(20),
                _InfoNotice(
                  icon: HugeIcons.strokeRoundedCalendar03,
                  title: 'Availability is seller-controlled',
                  message: 'Only slots returned by the backend should be shown here.',
                ),
                const Gap(20),
                SizedBox(
                  width: double.infinity,
                  child: _PrimaryButton(
                    label: 'Choose new slot',
                    icon: HugeIcons.strokeRoundedArrowRight01,
                    onPressed: () {
                      Navigator.of(context).pop();

                      // TODO:
                      // Navigate to the rescheduling flow using the
                      // existing app router.
                      //
                      // Do not create a new booking here.
                      // Rescheduling should update the existing booking.
                    },
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _contactSeller() {
    // TODO:
    // Connect to the communication/contact flow once the backend
    // capabilities are finalized.
    //
    // Do not expose a phone number from the UI unless the backend
    // explicitly provides/permits it.

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Seller contact will be connected here.', style: GoogleFonts.hind())),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Theme(
      data: theme.copyWith(textTheme: GoogleFonts.hindTextTheme(theme.textTheme)),
      child: Scaffold(
        backgroundColor: colorScheme.surface,
        appBar: AppBar(
          backgroundColor: colorScheme.surface,
          elevation: 0,
          scrolledUnderElevation: 0,
          leading: IconButton(
            onPressed: () => Navigator.of(context).pop(),
            icon: HugeIcon(
              icon: HugeIcons.strokeRoundedArrowLeft01,
              color: colorScheme.onSurface,
              size: 22,
            ),
            tooltip: 'Back',
          ),
          title: Text(
            'Booking Details',
            style: GoogleFonts.hind(
              fontSize: 20,
              fontWeight: FontWeight.w700,
              color: colorScheme.onSurface,
            ),
          ),
          centerTitle: false,
        ),
        body: SafeArea(
          child: RefreshIndicator(
            onRefresh: _refreshBooking,
            child: CustomScrollView(
              physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
              slivers: [
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
                  sliver: SliverList(
                    delegate: SliverChildListDelegate([
                      _BookingHeaderCard(booking: widget.booking),
                      const Gap(16),
                      _SectionCard(
                        title: 'Appointment',
                        child: Column(
                          children: [
                            _DetailRow(
                              icon: HugeIcons.strokeRoundedCalendar03,
                              label: 'Date',
                              value: widget.booking.dateLabel,
                            ),
                            const Gap(16),
                            _DetailRow(
                              icon: HugeIcons.strokeRoundedClock01,
                              label: 'Time',
                              value: widget.booking.timeSlot,
                            ),
                            const Gap(16),
                            _DetailRow(
                              icon: HugeIcons.strokeRoundedTimer01,
                              label: 'Duration',
                              value: widget.booking.durationLabel,
                            ),
                          ],
                        ),
                      ),
                      const Gap(16),
                      _SectionCard(
                        title: 'Service location',
                        child: _LocationCard(booking: widget.booking),
                      ),
                      const Gap(16),
                      _SectionCard(
                        title: 'Price',
                        child: _PriceSection(booking: widget.booking),
                      ),
                      const Gap(16),
                      _SectionCard(
                        title: 'Booking timeline',
                        child: _BookingTimeline(events: widget.booking.timeline),
                      ),
                      const Gap(16),
                      _SellerCard(booking: widget.booking, onContact: _contactSeller),
                      const Gap(16),
                      _InfoNotice(
                        icon: HugeIcons.strokeRoundedInformationCircle,
                        title: 'Need to make a change?',
                        message: 'Rescheduling and cancellation are subject to the seller\'s availability and booking policy.',
                      ),
                      const Gap(20),
                      if (widget.booking.canReschedule || widget.booking.canCancel)
                        Row(
                          children: [
                            if (widget.booking.canReschedule)
                              Expanded(
                                child: _SecondaryButton(
                                  label: 'Reschedule',
                                  icon: HugeIcons.strokeRoundedCalendar03,
                                  onPressed: _showRescheduleSheet,
                                ),
                              ),
                            if (widget.booking.canReschedule && widget.booking.canCancel)
                              const Gap(12),
                            if (widget.booking.canCancel)
                              Expanded(
                                child: _SecondaryButton(
                                  label: 'Cancel',
                                  icon: HugeIcons.strokeRoundedRemove01,
                                  foregroundColor: colorScheme.error,
                                  borderColor: colorScheme.error.withValues(alpha: 0.45),
                                  onPressed: _showCancelConfirmation,
                                ),
                              ),
                          ],
                        ),
                      const Gap(8),
                    ]),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _refreshBooking() async {
    // TODO:
    // Replace this with:
    //
    // await ref
    //     .read(serviceBookingDetailsControllerProvider(
    //       widget.booking.bookingId,
    //     ).notifier)
    //     .refresh();
    //
    // Keeping this screen Stateful for now allows us to integrate
    // Riverpod cleanly once the backend response contract is finalized.
    await Future<void>.delayed(const Duration(milliseconds: 400));
  }
}

// HEADER
class _BookingHeaderCard extends StatelessWidget {
  const _BookingHeaderCard({required this.booking});

  final ShopServiceBookingDetails booking;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: colorScheme.surfaceContainerLow,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: colorScheme.outlineVariant.withValues(alpha: 0.55)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 58,
                height: 58,
                decoration: BoxDecoration(
                  color: colorScheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: HugeIcon(
                  icon: HugeIcons.strokeRoundedTools,
                  color: colorScheme.onSurfaceVariant,
                  size: 27,
                ),
              ),
              const Gap(14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      booking.serviceName,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.hind(
                        fontSize: 18,
                        height: 1.2,
                        fontWeight: FontWeight.w700,
                        color: colorScheme.onSurface,
                      ),
                    ),
                    const Gap(4),
                    Text(
                      booking.sellerName,
                      style: GoogleFonts.hind(fontSize: 14, color: colorScheme.onSurfaceVariant),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const Gap(18),
          Row(
            children: [
              _StatusPill(label: booking.status.label, status: booking.status),
              const Spacer(),
              Text(
                booking.bookingId,
                style: GoogleFonts.hind(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// LOCATION
class _LocationCard extends StatelessWidget {
  const _LocationCard({required this.booking});

  final ShopServiceBookingDetails booking;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: colorScheme.surfaceContainerLow,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _IconCircle(
            icon: HugeIcons.strokeRoundedLocation01,
            backgroundColor: colorScheme.primaryContainer,
            iconColor: colorScheme.onPrimaryContainer,
            size: 42,
            iconSize: 20,
          ),
          const Gap(12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  booking.locationType.label,
                  style: GoogleFonts.hind(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: colorScheme.onSurface,
                  ),
                ),
                const Gap(2),
                Text(
                  booking.locationDetail,
                  style: GoogleFonts.hind(
                    fontSize: 13,
                    height: 1.35,
                    color: colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// PRICE
class _PriceSection extends StatelessWidget {
  const _PriceSection({required this.booking});

  final ShopServiceBookingDetails booking;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Column(
      children: [
        _AmountRow(label: booking.priceLabel, amount: booking.price, emphasized: true),
        if (booking.priceStatusMessage != null) ...[
          const Gap(10),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              HugeIcon(
                icon: HugeIcons.strokeRoundedInformationCircle,
                color: colorScheme.onSurfaceVariant,
                size: 17,
              ),
              const Gap(7),
              Expanded(
                child: Text(
                  booking.priceStatusMessage!,
                  style: GoogleFonts.hind(
                    fontSize: 12,
                    height: 1.4,
                    color: colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
            ],
          ),
        ],
      ],
    );
  }
}

// TIMELINE
class _BookingTimeline extends StatelessWidget {
  const _BookingTimeline({required this.events});

  final List<ShopBookingTimelineEvent> events;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        for (var index = 0; index < events.length; index++)
          _TimelineItem(event: events[index], isLast: index == events.length - 1),
      ],
    );
  }
}

class _TimelineItem extends StatelessWidget {
  const _TimelineItem({required this.event, required this.isLast});

  final ShopBookingTimelineEvent event;
  final bool isLast;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 28,
            child: Column(
              children: [
                Container(
                  width: 18,
                  height: 18,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: event.isCompleted
                        ? colorScheme.primary
                        : colorScheme.surfaceContainerHighest,
                    border: Border.all(
                      color: event.isCompleted ? colorScheme.primary : colorScheme.outlineVariant,
                    ),
                  ),
                  child: event.isCompleted
                      ? HugeIcon(
                          icon: HugeIcons.strokeRoundedCheckmarkCircle02,
                          color: colorScheme.onPrimary,
                          size: 16,
                        )
                      : null,
                ),
                if (!isLast)
                  Expanded(
                    child: Container(
                      width: 1,
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      color: event.isCompleted
                          ? colorScheme.primary.withValues(alpha: 0.35)
                          : colorScheme.outlineVariant,
                    ),
                  ),
              ],
            ),
          ),
          const Gap(10),
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(bottom: isLast ? 0 : 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    event.title,
                    style: GoogleFonts.hind(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: event.isCompleted
                          ? colorScheme.onSurface
                          : colorScheme.onSurfaceVariant,
                    ),
                  ),
                  if (event.description != null) ...[
                    const Gap(2),
                    Text(
                      event.description!,
                      style: GoogleFonts.hind(
                        fontSize: 12,
                        height: 1.35,
                        color: colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                  if (event.timeLabel != null) ...[
                    const Gap(3),
                    Text(
                      event.timeLabel!,
                      style: GoogleFonts.hind(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// SELLER
class _SellerCard extends StatelessWidget {
  const _SellerCard({required this.booking, required this.onContact});

  final ShopServiceBookingDetails booking;
  final VoidCallback onContact;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return _SectionCard(
      title: 'Service provider',
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: colorScheme.surfaceContainerHighest,
                  shape: BoxShape.circle,
                ),
                child: HugeIcon(
                  icon: HugeIcons.strokeRoundedStore01,
                  color: colorScheme.onSurfaceVariant,
                  size: 23,
                ),
              ),
              const Gap(12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      booking.sellerName,
                      style: GoogleFonts.hind(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: colorScheme.onSurface,
                      ),
                    ),
                    const Gap(2),
                    Row(
                      children: [
                        HugeIcon(
                          icon: HugeIcons.strokeRoundedStar,
                          color: colorScheme.onSurfaceVariant,
                          size: 15,
                        ),
                        const Gap(4),
                        Text(
                          '${booking.sellerRating.toStringAsFixed(1)} · ${booking.sellerReviewCount} reviews',
                          style: GoogleFonts.hind(
                            fontSize: 12,
                            color: colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const Gap(14),
          SizedBox(
            width: double.infinity,
            child: _SecondaryButton(
              label: 'Contact seller',
              icon: HugeIcons.strokeRoundedMessage01,
              onPressed: onContact,
            ),
          ),
        ],
      ),
    );
  }
}

// SHARED UI
class _SectionCard extends StatelessWidget {
  const _SectionCard({required this.title, required this.child});

  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: colorScheme.outlineVariant.withValues(alpha: 0.55)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: GoogleFonts.hind(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: colorScheme.onSurface,
            ),
          ),
          const Gap(14),
          child,
        ],
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  const _DetailRow({required this.icon, required this.label, required this.value});

  final dynamic icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        HugeIcon(icon: icon, color: colorScheme.onSurfaceVariant, size: 20),
        const Gap(12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: GoogleFonts.hind(fontSize: 12, color: colorScheme.onSurfaceVariant),
              ),
              const Gap(1),
              Text(
                value,
                style: GoogleFonts.hind(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: colorScheme.onSurface,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _AmountRow extends StatelessWidget {
  const _AmountRow({required this.label, required this.amount, this.emphasized = false});

  final String label;
  final double amount;
  final bool emphasized;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Row(
      children: [
        Expanded(
          child: Text(
            label,
            style: GoogleFonts.hind(
              fontSize: emphasized ? 14 : 13,
              fontWeight: emphasized ? FontWeight.w700 : FontWeight.w500,
              color: colorScheme.onSurface,
            ),
          ),
        ),
        Text(
          '₹${amount.toStringAsFixed(0)}',
          style: GoogleFonts.hind(
            fontSize: emphasized ? 18 : 14,
            fontWeight: FontWeight.w700,
            color: colorScheme.onSurface,
          ),
        ),
      ],
    );
  }
}

class _StatusPill extends StatelessWidget {
  const _StatusPill({required this.label, required this.status});

  final String label;
  final ShopServiceBookingStatus status;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final background = switch (status) {
      ShopServiceBookingStatus.confirmed => colorScheme.primaryContainer,
      ShopServiceBookingStatus.inProgress => colorScheme.secondaryContainer,
      ShopServiceBookingStatus.completed => colorScheme.primaryContainer,
      ShopServiceBookingStatus.cancelled => colorScheme.errorContainer,
      ShopServiceBookingStatus.rescheduleRequested => colorScheme.tertiaryContainer,
      ShopServiceBookingStatus.pending => colorScheme.surfaceContainerHighest,
    };

    final foreground = switch (status) {
      ShopServiceBookingStatus.confirmed => colorScheme.onPrimaryContainer,
      ShopServiceBookingStatus.inProgress => colorScheme.onSecondaryContainer,
      ShopServiceBookingStatus.completed => colorScheme.onPrimaryContainer,
      ShopServiceBookingStatus.cancelled => colorScheme.onErrorContainer,
      ShopServiceBookingStatus.rescheduleRequested => colorScheme.onTertiaryContainer,
      ShopServiceBookingStatus.pending => colorScheme.onSurfaceVariant,
    };

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(color: background, borderRadius: BorderRadius.circular(99)),
      child: Text(
        label,
        style: GoogleFonts.hind(fontSize: 12, fontWeight: FontWeight.w700, color: foreground),
      ),
    );
  }
}

class _InfoNotice extends StatelessWidget {
  const _InfoNotice({required this.icon, required this.title, required this.message});

  final dynamic icon;
  final String title;
  final String message;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: colorScheme.surfaceContainerLow,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: colorScheme.outlineVariant.withValues(alpha: 0.5)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          HugeIcon(icon: icon, color: colorScheme.onSurfaceVariant, size: 19),
          const Gap(10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.hind(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: colorScheme.onSurface,
                  ),
                ),
                const Gap(2),
                Text(
                  message,
                  style: GoogleFonts.hind(
                    fontSize: 12,
                    height: 1.4,
                    color: colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _IconCircle extends StatelessWidget {
  const _IconCircle({
    required this.icon,
    required this.backgroundColor,
    required this.iconColor,
    this.size = 48,
    this.iconSize = 22,
  });

  final dynamic icon;
  final Color backgroundColor;
  final Color iconColor;
  final double size;
  final double iconSize;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(color: backgroundColor, shape: BoxShape.circle),
      child: Center(
        child: HugeIcon(icon: icon, color: iconColor, size: iconSize),
      ),
    );
  }
}

class _PrimaryButton extends StatelessWidget {
  const _PrimaryButton({
    required this.label,
    required this.onPressed,
    this.icon,
    this.backgroundColor,
    this.foregroundColor,
  });

  final String label;
  final VoidCallback onPressed;
  final dynamic icon;
  final Color? backgroundColor;
  final Color? foregroundColor;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final bg = backgroundColor ?? colorScheme.primary;
    final fg = foregroundColor ?? colorScheme.onPrimary;

    return Material(
      color: bg,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          height: 50,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                label,
                style: GoogleFonts.hind(fontSize: 14, fontWeight: FontWeight.w700, color: fg),
              ),
              if (icon != null) ...[const Gap(7), HugeIcon(icon: icon, color: fg, size: 18)],
            ],
          ),
        ),
      ),
    );
  }
}

class _SecondaryButton extends StatelessWidget {
  const _SecondaryButton({
    required this.label,
    required this.onPressed,
    this.icon,
    this.foregroundColor,
    this.borderColor,
  });

  final String label;
  final VoidCallback onPressed;
  final dynamic icon;
  final Color? foregroundColor;
  final Color? borderColor;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final fg = foregroundColor ?? colorScheme.onSurface;
    final border = borderColor ?? colorScheme.outlineVariant;

    return Material(
      color: colorScheme.surface,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          height: 50,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: border),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (icon != null) ...[HugeIcon(icon: icon, color: fg, size: 17), const Gap(7)],
              Flexible(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.hind(fontSize: 13, fontWeight: FontWeight.w700, color: fg),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// DOMAIN-READY TEMPORARY MODELS//
// These are deliberately kept outside the widget so they can later be
// replaced by your actual marketplace/service domain models without
// redesigning the screen.
//

enum ShopServiceBookingStatus {
  pending,
  confirmed,
  inProgress,
  completed,
  cancelled,
  rescheduleRequested;

  String get label {
    switch (this) {
      case ShopServiceBookingStatus.pending:
        return 'Pending';
      case ShopServiceBookingStatus.confirmed:
        return 'Confirmed';
      case ShopServiceBookingStatus.inProgress:
        return 'In progress';
      case ShopServiceBookingStatus.completed:
        return 'Completed';
      case ShopServiceBookingStatus.cancelled:
        return 'Cancelled';
      case ShopServiceBookingStatus.rescheduleRequested:
        return 'Reschedule requested';
    }
  }
}

enum ShopServiceBookingLocationType {
  myFlat,
  commonLocation;

  String get label {
    switch (this) {
      case ShopServiceBookingLocationType.myFlat:
        return 'My flat';
      case ShopServiceBookingLocationType.commonLocation:
        return 'Common location';
    }
  }
}

class ShopBookingTimelineEvent {
  const ShopBookingTimelineEvent({
    required this.title,
    required this.isCompleted,
    this.description,
    this.timeLabel,
  });

  final String title;
  final bool isCompleted;
  final String? description;
  final String? timeLabel;
}

class ShopServiceBookingDetails {
  const ShopServiceBookingDetails({
    required this.bookingId,
    required this.serviceId,
    required this.serviceName,
    required this.sellerId,
    required this.sellerName,
    required this.sellerRating,
    required this.sellerReviewCount,
    required this.status,
    required this.dateLabel,
    required this.timeSlot,
    required this.durationLabel,
    required this.locationType,
    required this.locationDetail,
    required this.price,
    required this.priceLabel,
    required this.timeline,
    required this.canReschedule,
    required this.canCancel,
    this.priceStatusMessage,
  });

  final String bookingId;
  final String serviceId;

  final String serviceName;

  final String sellerId;
  final String sellerName;
  final double sellerRating;
  final int sellerReviewCount;

  final ShopServiceBookingStatus status;

  final String dateLabel;
  final String timeSlot;
  final String durationLabel;

  final ShopServiceBookingLocationType locationType;
  final String locationDetail;

  final double price;
  final String priceLabel;
  final String? priceStatusMessage;

  final List<ShopBookingTimelineEvent> timeline;

  final bool canReschedule;
  final bool canCancel;

  factory ShopServiceBookingDetails.mock({String? bookingId}) {
    return ShopServiceBookingDetails(
      bookingId: bookingId ?? 'SS-BKG-20417',
      serviceId: 'service-ceiling-fan-installation',
      serviceName: 'Ceiling Fan Installation',
      sellerId: 'seller-raj-electricals',
      sellerName: 'Raj Electricals',
      sellerRating: 4.8,
      sellerReviewCount: 126,
      status: ShopServiceBookingStatus.confirmed,
      dateLabel: 'Tomorrow',
      timeSlot: '10:00 AM – 11:00 AM',
      durationLabel: '60 minutes',
      locationType: ShopServiceBookingLocationType.myFlat,
      locationDetail: 'Flat B-1204 · Your registered flat',
      price: 450,
      priceLabel: 'Service price',
      priceStatusMessage: 'Final price is confirmed. Any additional work should be approved before extra charges are added.',
      timeline: const [
        ShopBookingTimelineEvent(
          title: 'Booking confirmed',
          description: 'Raj Electricals accepted your booking.',
          timeLabel: 'Today · 11:42 AM',
          isCompleted: true,
        ),
        ShopBookingTimelineEvent(
          title: 'Service appointment',
          description: 'The service is scheduled for tomorrow.',
          timeLabel: 'Tomorrow · 10:00 AM',
          isCompleted: false,
        ),
        ShopBookingTimelineEvent(
          title: 'Service completed',
          description: 'Booking will be marked completed after the service.',
          isCompleted: false,
        ),
      ],
      canReschedule: true,
      canCancel: true,
    );
  }
}
