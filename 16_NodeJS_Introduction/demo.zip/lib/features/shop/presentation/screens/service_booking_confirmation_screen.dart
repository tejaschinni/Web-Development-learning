import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';

class ServiceBookingConfirmationScreen extends StatelessWidget {
  const ServiceBookingConfirmationScreen({
    super.key,
    required this.serviceId,
    required this.serviceName,
    required this.sellerName,
    required this.date,
    required this.slot,
    required this.location,
    required this.startingPrice,
    required this.durationMinutes,
  });

  final String serviceId;
  final String serviceName;
  final String sellerName;
  final DateTime date;
  final String slot;
  final ServiceBookingLocation location;
  final int startingPrice;
  final int durationMinutes;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final textTheme = GoogleFonts.hindTextTheme(theme.textTheme);

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      body: SafeArea(
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(child: _buildHeader(context, textTheme)),
            SliverToBoxAdapter(child: _buildServiceSummary(context, textTheme)),
            SliverToBoxAdapter(child: _buildDivider(context)),
            SliverToBoxAdapter(child: _buildAppointmentSection(context, textTheme)),
            SliverToBoxAdapter(child: _buildDivider(context)),
            SliverToBoxAdapter(child: _buildLocationSection(context, textTheme)),
            SliverToBoxAdapter(child: _buildDivider(context)),
            SliverToBoxAdapter(child: _buildPriceSection(context, textTheme)),
            SliverToBoxAdapter(child: _buildImportantNote(context, textTheme)),
            const SliverToBoxAdapter(child: Gap(120)),
          ],
        ),
      ),
      bottomNavigationBar: _buildBottomBar(context, textTheme),
    );
  }

  // HEADER
  Widget _buildHeader(BuildContext context, TextTheme textTheme) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
      child: Row(
        children: [
          _CircleButton(
            icon: HugeIcons.strokeRoundedArrowLeft01,
            onTap: () {
              Navigator.of(context).pop();
            },
          ),
          const Gap(14),
          Text(
            'Confirm booking',
            style: textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w800,
              color: theme.colorScheme.onSurface,
            ),
          ),
        ],
      ),
    );
  }

  // SERVICE SUMMARY
  Widget _buildServiceSummary(BuildContext context, TextTheme textTheme) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.55),
          borderRadius: BorderRadius.circular(18),
        ),
        child: Row(
          children: [
            Container(
              height: 74,
              width: 74,
              decoration: BoxDecoration(
                color: theme.colorScheme.secondaryContainer,
                borderRadius: BorderRadius.circular(15),
              ),
              child: HugeIcon(
                icon: HugeIcons.strokeRoundedTools,
                size: 31,
                color: theme.colorScheme.onSecondaryContainer,
              ),
            ),

            const Gap(13),

            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    serviceName,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800),
                  ),

                  const Gap(3),

                  Text(
                    sellerName,
                    style: textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                  ),

                  const Gap(5),

                  Row(
                    children: [
                      HugeIcon(
                        icon: HugeIcons.strokeRoundedClock01,
                        size: 14,
                        color: theme.colorScheme.primary,
                      ),
                      const Gap(4),
                      Text(
                        '$durationMinutes min',
                        style: textTheme.labelMedium?.copyWith(fontWeight: FontWeight.w700),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // APPOINTMENT
  Widget _buildAppointmentSection(BuildContext context, TextTheme textTheme) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Appointment', style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),

          const Gap(13),

          _DetailRow(
            icon: HugeIcons.strokeRoundedCalendar03,
            label: 'Date',
            value: _formatDate(date),
          ),

          const Gap(12),

          _DetailRow(icon: HugeIcons.strokeRoundedClock01, label: 'Time', value: slot),

          const Gap(12),

          _DetailRow(
            icon: HugeIcons.strokeRoundedTimer01,
            label: 'Duration',
            value: '$durationMinutes minutes',
          ),
        ],
      ),
    );
  }

  // LOCATION
  Widget _buildLocationSection(BuildContext context, TextTheme textTheme) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Service location',
            style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800),
          ),

          const Gap(12),

          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: theme.colorScheme.surface,
              borderRadius: BorderRadius.circular(15),
              border: Border.all(color: theme.colorScheme.outlineVariant),
            ),
            child: Row(
              children: [
                Container(
                  height: 42,
                  width: 42,
                  decoration: BoxDecoration(
                    color: theme.colorScheme.primaryContainer,
                    borderRadius: BorderRadius.circular(11),
                  ),
                  child: HugeIcon(
                    icon: location.type == ServiceBookingLocationType.myFlat
                        ? HugeIcons.strokeRoundedHome01
                        : HugeIcons.strokeRoundedLocation01,
                    size: 20,
                    color: theme.colorScheme.onPrimaryContainer,
                  ),
                ),

                const Gap(11),

                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        location.title,
                        style: textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800),
                      ),
                      const Gap(2),
                      Text(
                        location.subtitle,
                        style: textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // PRICE
  Widget _buildPriceSection(BuildContext context, TextTheme textTheme) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Price', style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),

          const Gap(12),

          Row(
            children: [
              Expanded(
                child: Text(
                  'Service starting price',
                  style: textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                ),
              ),
              Text(
                '₹$startingPrice',
                style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800),
              ),
            ],
          ),

          const Gap(9),

          Container(
            padding: const EdgeInsets.all(11),
            decoration: BoxDecoration(
              color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
              borderRadius: BorderRadius.circular(11),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                HugeIcon(
                  icon: HugeIcons.strokeRoundedInformationCircle,
                  size: 17,
                  color: theme.colorScheme.onSurfaceVariant,
                ),
                const Gap(7),
                Expanded(
                  child: Text(
                    'The final price may vary if the seller '
                    'needs to provide a customised quote after '
                    'reviewing the service requirements.',
                    style: textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                      height: 1.3,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // IMPORTANT NOTE
  Widget _buildImportantNote(BuildContext context, TextTheme textTheme) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
      child: Container(
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(
          color: theme.colorScheme.primaryContainer.withValues(alpha: 0.4),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            HugeIcon(
              icon: HugeIcons.strokeRoundedInformationCircle,
              size: 19,
              color: theme.colorScheme.primary,
            ),
            const Gap(9),
            Expanded(
              child: Text(
                'You can manage or cancel this booking from '
                'your Orders & Bookings section after confirmation.',
                style: textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onSurface,
                  height: 1.35,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // BOTTOM BAR
  Widget _buildBottomBar(BuildContext context, TextTheme textTheme) {
    final theme = Theme.of(context);

    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        border: Border(
          top: BorderSide(color: theme.colorScheme.outlineVariant.withValues(alpha: 0.5)),
        ),
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 11, 16, 10),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Starting from',
                      style: textTheme.labelSmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                    Text(
                      '₹$startingPrice',
                      style: textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800),
                    ),
                  ],
                ),
              ),

              const Gap(12),

              Expanded(
                flex: 2,
                child: SizedBox(
                  height: 50,
                  child: FilledButton(
                    onPressed: _confirmBooking,
                    style: FilledButton.styleFrom(
                      backgroundColor: theme.colorScheme.primary,
                      foregroundColor: theme.colorScheme.onPrimary,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                    child: Text(
                      'CONFIRM BOOKING',
                      style: textTheme.labelLarge?.copyWith(
                        fontWeight: FontWeight.w800,
                        color: theme.colorScheme.onPrimary,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _confirmBooking() {
    // IMPORTANT:
    //
    // This is where the actual booking API should be called.
    //
    // Example architecture:
    //
    // ref.read(serviceBookingControllerProvider.notifier)
    //     .createBooking(
    //       serviceId: serviceId,
    //       date: date,
    //       slot: slot,
    //       location: location,
    //     );
    //
    // The API should return the created booking.
    //
    // Then navigate to:
    //
    // Service Booking Created
  }

  Widget _buildDivider(BuildContext context) {
    final theme = Theme.of(context);

    return Divider(
      height: 1,
      thickness: 1,
      color: theme.colorScheme.outlineVariant.withValues(alpha: 0.45),
    );
  }

  String _formatDate(DateTime value) {
    const months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];

    return '${value.day} ${months[value.month - 1]} '
        '${value.year}';
  }
}

// DETAIL ROW
class _DetailRow extends StatelessWidget {
  const _DetailRow({required this.icon, required this.label, required this.value});

  final dynamic icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final textTheme = GoogleFonts.hindTextTheme(theme.textTheme);

    return Row(
      children: [
        Container(
          height: 38,
          width: 38,
          decoration: BoxDecoration(
            color: theme.colorScheme.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Center(
            child: HugeIcon(icon: icon, size: 18, color: theme.colorScheme.primary),
          ),
        ),

        const Gap(11),

        Expanded(
          child: Text(
            label,
            style: textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant),
          ),
        ),

        Text(value, style: textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w800)),
      ],
    );
  }
}

// CIRCLE BUTTON
class _CircleButton extends StatelessWidget {
  const _CircleButton({required this.icon, required this.onTap});

  final dynamic icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Material(
      color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.72),
      borderRadius: BorderRadius.circular(13),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(13),
        child: SizedBox(
          height: 42,
          width: 42,
          child: Center(
            child: HugeIcon(icon: icon, size: 21, color: theme.colorScheme.onSurface),
          ),
        ),
      ),
    );
  }
}

// BOOKING LOCATION
class ServiceBookingLocation {
  const ServiceBookingLocation({required this.type, required this.title, required this.subtitle});

  final ServiceBookingLocationType type;
  final String title;
  final String subtitle;

  static const myFlat = ServiceBookingLocation(
    type: ServiceBookingLocationType.myFlat,
    title: 'Your registered flat',
    subtitle: 'Service will be provided at your flat',
  );

  static const commonLocation = ServiceBookingLocation(
    type: ServiceBookingLocationType.commonLocation,
    title: 'Society common location',
    subtitle: 'Meet the seller at the selected location',
  );
}

enum ServiceBookingLocationType { myFlat, commonLocation }
