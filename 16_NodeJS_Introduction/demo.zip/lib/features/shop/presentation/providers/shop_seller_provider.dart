import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/core/providers/app_providers.dart';
import 'package:society_seva/features/shop/data/datasources/shop_seller_remote_data_source.dart';
import 'package:society_seva/features/shop/data/repositories/shop_seller_repository_impl.dart';
import 'package:society_seva/features/shop/domain/entities/shop_seller.dart';
import 'package:society_seva/features/shop/domain/repositories/shop_seller_repository.dart';

final shopSellerRemoteDataSourceProvider = Provider<ShopSellerRemoteDataSource>((ref) {
  return ShopSellerRemoteDataSource(apiClient: ref.watch(apiClientProvider));
});

final shopSellerRepositoryProvider = Provider<ShopSellerRepository>((ref) {
  return ShopSellerRepositoryImpl(remoteDataSource: ref.watch(shopSellerRemoteDataSourceProvider));
});

class ShopSellersState {
  const ShopSellersState({
    required this.items,
    required this.currentPage,
    required this.totalPages,
    required this.totalElements,
    required this.isLoadingMore,
  });

  final List<ShopSeller> items;
  final int currentPage;
  final int totalPages;
  final int totalElements;
  final bool isLoadingMore;

  bool get hasNextPage => currentPage + 1 < totalPages;

  ShopSellersState copyWith({
    List<ShopSeller>? items,
    int? currentPage,
    int? totalPages,
    int? totalElements,
    bool? isLoadingMore,
  }) {
    return ShopSellersState(
      items: items ?? this.items,
      currentPage: currentPage ?? this.currentPage,
      totalPages: totalPages ?? this.totalPages,
      totalElements: totalElements ?? this.totalElements,
      isLoadingMore: isLoadingMore ?? this.isLoadingMore,
    );
  }
}

final shopPopularSellersProvider =
    AsyncNotifierProvider.family<ShopPopularSellersNotifier, ShopSellersState, String>(
      ShopPopularSellersNotifier.new,
    );

class ShopPopularSellersNotifier extends FamilyAsyncNotifier<ShopSellersState, String> {
  static const int _pageSize = 20;

  late String _societyId;

  ShopSellerRepository get _repository => ref.read(shopSellerRepositoryProvider);

  @override
  Future<ShopSellersState> build(String societyId) async {
    _societyId = societyId;

    final page = await _repository.getSellers(
      societyId: societyId,
      pageable: const PageableQuery(page: 0, size: _pageSize),
    );

    return _stateFromPage(page);
  }

  ShopSellersState _stateFromPage(PageResponse<ShopSeller> page) {
    return ShopSellersState(
      items: page.content,
      currentPage: page.page,
      totalPages: page.totalPages,
      totalElements: page.totalElements,
      isLoadingMore: false,
    );
  }

  Future<void> loadNextPage() async {
    final current = state.valueOrNull;

    if (current == null) return;

    // Prevent duplicate requests.
    if (current.isLoadingMore) return;

    // No more pages.
    if (!current.hasNextPage) return;

    state = AsyncData(current.copyWith(isLoadingMore: true));

    try {
      final nextPageNumber = current.currentPage + 1;

      final page = await _repository.getSellers(
        societyId: _societyId,
        pageable: PageableQuery(page: nextPageNumber, size: _pageSize),
      );

      final combinedItems = [...current.items, ...page.content];

      state = AsyncData(
        ShopSellersState(
          items: combinedItems,
          currentPage: page.page,
          totalPages: page.totalPages,
          totalElements: page.totalElements,
          isLoadingMore: false,
        ),
      );
    } catch (_) {
      // Keep already loaded listings visible.
      state = AsyncData(current.copyWith(isLoadingMore: false));
    }
  }

  Future<void> refresh() async {
    state = const AsyncLoading();

    try {
      final page = await _repository.getSellers(
        societyId: _societyId,
        pageable: const PageableQuery(page: 0, size: _pageSize),
      );

      state = AsyncData(_stateFromPage(page));
    } catch (error, stackTrace) {
      state = AsyncError(error, stackTrace);
    }
  }
}
