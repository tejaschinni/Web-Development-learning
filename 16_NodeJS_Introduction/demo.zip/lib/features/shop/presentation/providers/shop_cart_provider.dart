import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/core/providers/app_providers.dart';
import 'package:society_seva/features/shop/data/datasources/shop_cart_remote_data_source.dart';
import 'package:society_seva/features/shop/data/datasources/shop_checkout_remote_data_source.dart';
import 'package:society_seva/features/shop/data/repositories/shop_cart_repository_impl.dart';
import 'package:society_seva/features/shop/data/models/shop_checkout_models.dart';
import 'package:society_seva/features/shop/domain/entities/shop_cart.dart';
import 'package:society_seva/features/shop/domain/repositories/shop_cart_repository.dart';

final shopCheckoutRemoteDataSourceProvider = Provider<ShopCheckoutRemoteDataSource>((ref) {
  return ShopCheckoutRemoteDataSource(apiClient: ref.watch(apiClientProvider));
});

final shopMyOrdersProvider = FutureProvider.autoDispose<List<ShopOrderResult>>((ref) {
  return ref.watch(shopCheckoutRemoteDataSourceProvider).getMyOrders();
});

final shopCartRemoteDataSourceProvider = Provider<ShopCartRemoteDataSource>((ref) {
  return ShopCartRemoteDataSource(apiClient: ref.watch(apiClientProvider));
});

final shopCartRepositoryProvider = Provider<ShopCartRepository>((ref) {
  return ShopCartRepositoryImpl(remoteDataSource: ref.watch(shopCartRemoteDataSourceProvider));
});

final shopCartProvider = AsyncNotifierProvider<ShopCartNotifier, ShopCart?>(ShopCartNotifier.new);

class ShopCartNotifier extends AsyncNotifier<ShopCart?> {
  ShopCartRepository get _repository => ref.read(shopCartRepositoryProvider);

  @override
  Future<ShopCart?> build() => _repository.getCart();

  Future<ShopCart> addItem({
    required String listingId,
    required int quantity,
    required bool replaceExistingCart,
    String? foodServingSizeId,
  }) async {
    final cart = await _repository.addItem(
      listingId: listingId,
      quantity: quantity,
      replaceExistingCart: replaceExistingCart,
      foodServingSizeId: foodServingSizeId,
    );
    state = AsyncData(cart);
    return cart;
  }

  Future<void> updateQuantity({required String itemId, required int quantity}) async {
    final cart = await _repository.updateItemQuantity(itemId: itemId, quantity: quantity);
    state = AsyncData(cart);
  }

  Future<void> removeItem(String itemId) async {
    await _repository.deleteItem(itemId);
    state = AsyncData(await _repository.getCart());
  }

  Future<void> clearCart() async {
    await _repository.deleteCart();
    state = const AsyncData(null);
  }

  Future<void> refresh() async {
    state = const AsyncLoading();
    try {
      state = AsyncData(await _repository.getCart());
    } catch (error, stackTrace) {
      state = AsyncError(error, stackTrace);
    }
  }
}
