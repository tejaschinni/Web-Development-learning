import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/core/providers/app_providers.dart';
import 'package:society_seva/features/shop/data/datasources/shop_listing_remote_data_source.dart';
import 'package:society_seva/features/shop/data/repositories/shop_listing_repository_impl.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing_details.dart';
import 'package:society_seva/features/shop/domain/repositories/shop_listing_repository.dart';

final shopListingRemoteDataSourceProvider = Provider<ShopListingRemoteDataSource>((ref) {
  return ShopListingRemoteDataSource(apiClient: ref.watch(apiClientProvider));
});

final shopListingRepositoryProvider = Provider<ShopListingRepository>((ref) {
  return ShopListingRepositoryImpl(
    remoteDataSource: ref.watch(shopListingRemoteDataSourceProvider),
  );
});

final shopListingProvider = FutureProvider.family<ShopListing, String>((ref, id) {
  return ref.watch(shopListingRepositoryProvider).getListing(id);
});

final shopSellerListingsProvider = FutureProvider.family<PageResponse<ShopListing>, String>((
  ref,
  sellerId,
) {
  return ref
      .watch(shopListingRemoteDataSourceProvider)
      .getSellerListings(sellerId: sellerId, pageable: const PageableQuery(page: 0, size: 50));
});

final shopListingImagesProvider = FutureProvider.family<List<ShopListingImage>, String>((ref, id) {
  return ref.watch(shopListingRepositoryProvider).getListingImages(id);
});

final shopFoodDetailsProvider = FutureProvider.family<ShopFoodDetails, String>((ref, id) {
  return ref.watch(shopListingRepositoryProvider).getFoodDetails(id);
});

final shopServiceDetailsProvider = FutureProvider.family<ShopServiceDetails, String>((ref, id) {
  return ref.watch(shopListingRepositoryProvider).getServiceDetails(id);
});

final serviceScheduleDatesProvider =
    FutureProvider.family<List<DateTime>, ({String listingId, String from, String to})>((
      ref,
      args,
    ) {
      return ref
          .watch(shopListingRemoteDataSourceProvider)
          .getServiceAvailableDates(listingId: args.listingId, from: args.from, to: args.to);
    });

final serviceScheduleSlotsProvider =
    FutureProvider.family<List<ServiceScheduleSlot>, ({String listingId, String date})>((
      ref,
      args,
    ) {
      return ref
          .watch(shopListingRemoteDataSourceProvider)
          .getServiceAvailableSlots(listingId: args.listingId, date: args.date);
    });

final shopCategoryListingsProvider =
    FutureProvider.family<PageResponse<ShopListing>, ({String categoryId, String societyId})>((
      ref,
      args,
    ) {
      return ref
          .watch(shopListingRepositoryProvider)
          .getCategoryListings(
            categoryId: args.categoryId,
            societyId: args.societyId,
            pageable: const PageableQuery(page: 0, size: 20),
          );
    });

class ShopListingsState {
  const ShopListingsState({
    required this.items,
    required this.currentPage,
    required this.totalPages,
    required this.totalElements,
    required this.isLoadingMore,
  });

  final List<ShopListing> items;
  final int currentPage;
  final int totalPages;
  final int totalElements;
  final bool isLoadingMore;

  bool get hasNextPage => currentPage + 1 < totalPages;

  ShopListingsState copyWith({
    List<ShopListing>? items,
    int? currentPage,
    int? totalPages,
    int? totalElements,
    bool? isLoadingMore,
  }) {
    return ShopListingsState(
      items: items ?? this.items,
      currentPage: currentPage ?? this.currentPage,
      totalPages: totalPages ?? this.totalPages,
      totalElements: totalElements ?? this.totalElements,
      isLoadingMore: isLoadingMore ?? this.isLoadingMore,
    );
  }
}

final shopPopularListingsProvider =
    AsyncNotifierProvider.family<ShopPopularListingsNotifier, ShopListingsState, String>(
      ShopPopularListingsNotifier.new,
    );

class ShopPopularListingsNotifier extends FamilyAsyncNotifier<ShopListingsState, String> {
  static const int _pageSize = 20;

  late String _societyId;

  ShopListingRepository get _repository => ref.read(shopListingRepositoryProvider);

  @override
  Future<ShopListingsState> build(String societyId) async {
    _societyId = societyId;
    debugPrint("Building shop listings for society: $societyId");
    final page = await _repository.getListings(
      societyId: societyId,
      pageable: const PageableQuery(page: 0, size: _pageSize),
    );
    debugPrint("Fetched ${page.content.length} listings for society: $societyId");
    return _stateFromPage(page);
  }

  ShopListingsState _stateFromPage(PageResponse<ShopListing> page) {
    debugPrint(
      "Creating ShopListingsState from page: ${page.page}, totalPages: ${page.totalPages}, totalElements: ${page.totalElements}",
    );
    return ShopListingsState(
      items: page.content,
      currentPage: page.page,
      totalPages: page.totalPages,
      totalElements: page.totalElements,
      isLoadingMore: false,
    );
  }

  Future<void> loadNextPage() async {
    debugPrint("Loading next page for society: $_societyId");
    final current = state.valueOrNull;

    if (current == null) return;

    // Prevent duplicate requests.
    if (current.isLoadingMore) return;

    // No more pages.
    if (!current.hasNextPage) return;

    state = AsyncData(current.copyWith(isLoadingMore: true));
    debugPrint("Fetching page ${current.currentPage + 1} for society: $_societyId");
    try {
      final nextPageNumber = current.currentPage + 1;

      final page = await _repository.getListings(
        societyId: _societyId,
        pageable: PageableQuery(page: nextPageNumber, size: _pageSize),
      );

      final combinedItems = [...current.items, ...page.content];

      state = AsyncData(
        ShopListingsState(
          items: combinedItems,
          currentPage: page.page,
          totalPages: page.totalPages,
          totalElements: page.totalElements,
          isLoadingMore: false,
        ),
      );
    } catch (_) {
      // Keep already loaded listings visible.
      state = AsyncData(current.copyWith(isLoadingMore: false));
    }
  }

  Future<void> refresh() async {
    debugPrint("Refreshing shop listings for society: $_societyId");
    state = const AsyncLoading();

    try {
      final page = await _repository.getListings(
        societyId: _societyId,
        pageable: const PageableQuery(page: 0, size: _pageSize),
      );
      debugPrint("Refreshed and fetched ${page.content.length} listings for society: $_societyId");
      state = AsyncData(_stateFromPage(page));
    } catch (error, stackTrace) {
      state = AsyncError(error, stackTrace);
    }
  }
}
