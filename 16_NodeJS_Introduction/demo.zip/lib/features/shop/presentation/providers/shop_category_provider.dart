import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/core/providers/app_providers.dart';
import 'package:society_seva/core/storage/local_cache.dart';
import 'package:society_seva/features/shop/data/datasources/shop_category_local_datasource.dart';
import 'package:society_seva/features/shop/data/datasources/shop_category_remote_datasource.dart';
import 'package:society_seva/features/shop/data/repositories/shop_category_repository_impl.dart';
import 'package:society_seva/features/shop/domain/entities/shop_category.dart';
import 'package:society_seva/features/shop/domain/repositories/shop_category_repository.dart';

final shopCategoryRemoteDataSourceProvider = Provider<ShopCategoryRemoteDataSource>((ref) {
  return ShopCategoryRemoteDataSource(apiClient: ref.watch(apiClientProvider));
});

final shopCategoryLocalDataSourceProvider = Provider<ShopCategoryLocalDataSource>((ref) {
  return ShopCategoryLocalDataSource(localCache: LocalCache.instance);
});

final shopCategoryRepositoryProvider = Provider<ShopCategoryRepository>((ref) {
  return ShopCategoryRepositoryImpl(
    remoteDataSource: ref.watch(shopCategoryRemoteDataSourceProvider),
    localDataSource: ref.watch(shopCategoryLocalDataSourceProvider),
  );
});

final shopCategoriesProvider = AsyncNotifierProvider<ShopCategoriesNotifier, List<ShopCategory>>(
  ShopCategoriesNotifier.new,
);

class ShopCategoriesNotifier extends AsyncNotifier<List<ShopCategory>> {
  ShopCategoryRepository get _repository => ref.read(shopCategoryRepositoryProvider);

  @override
  Future<List<ShopCategory>> build() async {
    final cached = await _repository.getCachedCategories();

    if (cached != null) {
      // Return cached data immediately.
      // Freshness check happens in the background.
      unawaited(_refreshIfStale());

      return cached;
    }
    return _repository.refreshCategories();
  }

  Future<void> refresh() async {
    await LocalCache.instance.delete('shop:categories:tree');

    final result = await AsyncValue.guard(_repository.refreshCategories);

    state = result;
  }

  Future<void> _refreshIfStale() async {
    try {
      final isStale = await _repository.isCacheStale();

      if (!isStale) {
        return;
      }

      final categories = await _repository.refreshCategories();

      state = AsyncData(categories);
    } catch (e, stack) {
      debugPrint(stack.toString());
    }
  }
}

final fetchCategoryByIdUsecase = Provider<FetchCategoryByIdUsecase>((ref) {
  return FetchCategoryByIdUsecase(ref.watch(shopCategoryRepositoryProvider));
});

final categoryByIdProvider = FutureProvider.autoDispose.family<ShopCategory?, String>((
  ref,
  sellerId,
) {
  return ref.read(fetchCategoryByIdUsecase).call(sellerId);
});

class FetchCategoryByIdUsecase {
  FetchCategoryByIdUsecase(this._repository);

  final ShopCategoryRepository _repository;

  Future<ShopCategory?> call(String categoryId) => _repository.getCategoryById(categoryId);
}
