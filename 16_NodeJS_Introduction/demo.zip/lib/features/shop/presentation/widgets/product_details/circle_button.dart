import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';

// CIRCLE BUTTON
class CircleButton extends StatelessWidget {
  const CircleButton({super.key, required this.icon, required this.onTap, this.badgeCount});

  final dynamic icon;
  final VoidCallback onTap;
  final int? badgeCount;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Stack(
      clipBehavior: Clip.none,
      children: [
        Material(
          color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.72),
          borderRadius: BorderRadius.circular(13),
          child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(13),
            child: SizedBox(
              height: 42,
              width: 42,
              child: Center(
                child: HugeIcon(icon: icon, size: 21, color: theme.colorScheme.onSurface),
              ),
            ),
          ),
        ),

        if (badgeCount != null && badgeCount! > 0)
          Positioned(
            right: -3,
            top: -4,
            child: Container(
              constraints: const BoxConstraints(minWidth: 18, minHeight: 18),
              padding: const EdgeInsets.symmetric(horizontal: 4),
              decoration: BoxDecoration(
                color: theme.colorScheme.primary,
                shape: BoxShape.circle,
                border: Border.all(color: theme.colorScheme.surface, width: 2),
              ),
              child: Center(
                child: Text(
                  '$badgeCount',
                  style: GoogleFonts.hind(
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    color: theme.colorScheme.onPrimary,
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}
