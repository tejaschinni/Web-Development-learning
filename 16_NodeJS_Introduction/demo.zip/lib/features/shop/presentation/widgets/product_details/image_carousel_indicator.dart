import 'package:flutter/material.dart';

class ImageCarouselIndicator extends StatefulWidget {
  const ImageCarouselIndicator({super.key, required this.count});

  final int count;

  @override
  State<ImageCarouselIndicator> createState() => _ImageCarouselIndicatorState();
}

class _ImageCarouselIndicatorState extends State<ImageCarouselIndicator> {
  final PageController _controller = PageController();
  // int _currentPage = 0;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // final theme = Theme.of(context);

    return Stack(
      alignment: Alignment.bottomCenter,
      children: [
        // The indicator listens to the same page position as the carousel.
        const SizedBox.shrink(),
      ],
    );
  }
}
