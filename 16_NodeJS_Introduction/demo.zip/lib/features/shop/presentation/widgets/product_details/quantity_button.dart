import 'package:flutter/material.dart';
import 'package:hugeicons/hugeicons.dart';

class QuantityButton extends StatelessWidget {
  const QuantityButton({super.key, required this.icon, required this.onTap});

  final dynamic icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: SizedBox(
          width: 36,
          height: 48,
          child: Center(
            child: HugeIcon(icon: icon, size: 18, color: theme.colorScheme.onSurface),
          ),
        ),
      ),
    );
  }
}
