import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_seller_provider.dart';
import 'package:society_seva/features/shop/presentation/widgets/shop_loading_more_card.dart';
import 'package:society_seva/features/shop/presentation/widgets/seller/shop_seller_card.dart';

class ShopAllSellersList extends ConsumerStatefulWidget {
  const ShopAllSellersList({super.key, required this.societyId});

  final String? societyId;

  @override
  ConsumerState<ShopAllSellersList> createState() => _ShopAllSellersListState();
}

class _ShopAllSellersListState extends ConsumerState<ShopAllSellersList> {
  late final ScrollController _scrollController;

  @override
  void initState() {
    super.initState();

    _scrollController = ScrollController();
    _scrollController.addListener(_onScroll);
  }

  void _onScroll() {
    if (!_scrollController.hasClients) return;

    final position = _scrollController.position;

    // Start loading before the user actually reaches the end.
    if (position.pixels >= position.maxScrollExtent - 300) {
      ref
          .read(shopPopularSellersProvider(widget.societyId ?? '').notifier)
          .loadNextPage();
    }
  }

  @override
  void dispose() {
    _scrollController
      ..removeListener(_onScroll)
      ..dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final societyId = widget.societyId ?? '';

    final sellersAsync = ref.watch(shopPopularSellersProvider(societyId));

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      appBar: AppBar(
        title: Text(
          'Explore sellers',
          style: GoogleFonts.hind(fontWeight: FontWeight.w700),
        ),
      ),
      body: sellersAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, _) => Center(
          child: TextButton.icon(
            onPressed: () => ref
                .read(shopPopularSellersProvider(societyId).notifier)
                .refresh(),
            icon: HugeIcon(
              icon: HugeIcons.strokeRoundedRefresh,
              size: 18,
              color: theme.colorScheme.primary,
            ),
            label: const Text('Unable to load sellers. Retry'),
          ),
        ),
        data: (state) {
          final visibleSellers = state.items
              .where((seller) => seller.isAvailable && seller.isApproved)
              .toList();

          if (visibleSellers.isEmpty) {
            return Center(
              child: state.hasNextPage
                  ? TextButton(
                      onPressed: state.isLoadingMore
                          ? null
                          : () => ref
                                .read(
                                  shopPopularSellersProvider(societyId)
                                      .notifier,
                                )
                                .loadNextPage(),
                      child: Text(
                        state.isLoadingMore
                            ? 'Loading sellers...'
                            : 'Load more sellers',
                        style: theme.textTheme.bodyMedium,
                      ),
                    )
                  : Text(
                      'No sellers available',
                      style: theme.textTheme.bodyMedium,
                    ),
            );
          }

          return ListView.separated(
            controller: _scrollController,
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 32),
            itemCount:
                visibleSellers.length +
                (state.hasNextPage || state.isLoadingMore ? 1 : 0),
            separatorBuilder: (_, _) => const Gap(12),
            itemBuilder: (context, index) {
              if (index >= visibleSellers.length) {
                if (state.isLoadingMore) return const LoadingMoreCard();

                return TextButton(
                  onPressed: () => ref
                      .read(shopPopularSellersProvider(societyId).notifier)
                      .loadNextPage(),
                  child: const Text('Load more sellers'),
                );
              }

              final seller = visibleSellers[index];

              return SellerCard(
                name: seller.displayName,
                description: seller.bio != null
                    ? (seller.bio!.length > 25
                          ? '${seller.bio!.substring(0, 25)}...'
                          : seller.bio!)
                    : '',
                rating: seller.averageRating,
                itemCount: seller.totalListings,
                onTap: () => context.push('/shop/seller/${seller.id}'),
              );
            },
          );
        },
      ),
    );
  }
}
