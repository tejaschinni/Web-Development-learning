import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_seller_provider.dart';
import 'package:society_seva/features/shop/presentation/widgets/listing/shop_popular_listings_shimmer.dart';
import 'package:society_seva/features/shop/presentation/widgets/seller/shop_seller_card.dart';

class SellerList extends ConsumerWidget {
  const SellerList({super.key, required this.societyId});

  final String? societyId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final societyId = this.societyId ?? '';

    final sellersAsync = ref.watch(shopPopularSellersProvider(societyId));

    return sellersAsync.when(
      loading: () => const PopularListingsShimmer(),

      error: (error, stack) {
        return SizedBox(
          height: 250,
          child: Center(
            child: InkWell(
              onTap: () {
                ref.invalidate(shopPopularSellersProvider(societyId));
              },
              borderRadius: BorderRadius.circular(14),
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 10,
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    HugeIcon(
                      icon: HugeIcons.strokeRoundedRefresh,
                      size: 18,
                      color: theme.colorScheme.primary,
                    ),
                    const Gap(8),
                    Text(
                      'Unable to load listings',
                      style: GoogleFonts.hind(
                        textStyle: theme.textTheme.labelLarge?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },

      data: (state) {
        final visibleSellers = state.items
            .where((seller) => seller.isAvailable && seller.isApproved)
            .take(3)
            .toList();

        if (visibleSellers.isEmpty) {
          return SizedBox(
            height: 250,
            child: Center(
              child: Text(
                'No listings available yet',
                style: GoogleFonts.hind(
                  textStyle: theme.textTheme.bodyMedium?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
            ),
          );
        }

        return SizedBox(
          height: 250,
          child: ListView.separated(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            physics: const BouncingScrollPhysics(),
            itemCount: visibleSellers.length,
            separatorBuilder: (_, _) => const Gap(12),
            itemBuilder: (context, index) {
              final seller = visibleSellers[index];
              return SellerCard(
                name: seller.displayName,
                description: seller.bio != null
                    ? (seller.bio!.length > 25
                          ? '${seller.bio!.substring(0, 25)}...'
                          : seller.bio!)
                    : "",
                rating: seller.averageRating,
                itemCount: seller.totalListings,
                onTap: () => context.push('/shop/seller/${seller.id}'),
              );
            },
          ),
        );
      },
    );
  }
}
