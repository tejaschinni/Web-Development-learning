import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing.dart';
import 'package:society_seva/features/shop/domain/enums/shop_listing_type.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_listing_provider.dart';
import 'package:society_seva/features/shop/presentation/widgets/category/shop_cart_actions.dart';

class ListingCard extends ConsumerWidget {
  const ListingCard({super.key, required this.listing});

  final ShopListing listing;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final isService = listing.listingType.isService;
    final imageUrl = ref
        .watch(shopListingImagesProvider(listing.id))
        .valueOrNull
        ?.where((image) => image.moderationStatus.toUpperCase() == 'APPROVED')
        .firstOrNull
        ?.imageUrl;

    return SizedBox(
      width: 174,
      child: Material(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(20),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () => context.push(
            isService ? '/shop/service/${listing.id}' : '/shop/product/${listing.id}',
            extra: listing,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: 128,
                width: double.infinity,
                color: theme.colorScheme.surfaceContainerHighest,
                child: Stack(
                  children: [
                    if (imageUrl != null)
                      Positioned.fill(
                        child: Image.network(
                          imageUrl,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) => const SizedBox.shrink(),
                        ),
                      ),
                    if (imageUrl == null)
                      Center(
                        child: HugeIcon(
                          icon: isService
                              ? HugeIcons.strokeRoundedService
                              : listing.listingType == ShopListingType.food
                              ? HugeIcons.strokeRoundedRestaurant01
                              : HugeIcons.strokeRoundedImage01,
                          size: 36,
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),

                    Positioned(
                      left: 10,
                      top: 10,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
                        decoration: BoxDecoration(
                          color: theme.colorScheme.surface,
                          borderRadius: BorderRadius.circular(7),
                        ),
                        child: Text(
                          _listingTypeLabel(listing.listingType),
                          style: GoogleFonts.hind(
                            textStyle: theme.textTheme.labelSmall?.copyWith(
                              fontWeight: FontWeight.w800,
                              fontSize: 9,
                            ),
                          ),
                        ),
                      ),
                    ),

                    if (!isService && listing.isAvailable)
                      Positioned(
                        right: 10,
                        bottom: 10,
                        child: Material(
                          color: theme.colorScheme.surface,
                          borderRadius: BorderRadius.circular(12),
                          child: InkWell(
                            onTap: () {
                              if (listing.listingType == ShopListingType.food) {
                                context.push('/shop/product/${listing.id}', extra: listing);
                              } else {
                                addListingToCart(context, ref, listing, quantity: 1);
                              }
                            },
                            borderRadius: BorderRadius.circular(12),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                              child: Text(
                                'ADD',
                                style: GoogleFonts.hind(
                                  textStyle: theme.textTheme.labelMedium?.copyWith(
                                    color: theme.colorScheme.primary,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),

              Padding(
                padding: const EdgeInsets.fromLTRB(12, 11, 12, 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      listing.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.hind(
                        textStyle: theme.textTheme.bodyMedium?.copyWith(
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),

                    const Gap(4),

                    Text(
                      listing.description.isEmpty
                          ? _listingTypeLabel(listing.listingType)
                          : listing.description,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.hind(
                        textStyle: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ),

                    const Gap(7),

                    Row(
                      children: [
                        HugeIcon(
                          icon: HugeIcons.strokeRoundedStar,
                          size: 14,
                          color: theme.colorScheme.primary,
                        ),
                        const Gap(3),
                        Text(
                          listing.averageRating.toStringAsFixed(1),
                          style: GoogleFonts.hind(
                            textStyle: theme.textTheme.labelSmall?.copyWith(
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        const Spacer(),
                        Text(
                          _priceText(listing),
                          style: GoogleFonts.hind(
                            textStyle: theme.textTheme.bodyMedium?.copyWith(
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                      ],
                    ),

                    const Gap(2),

                    Text(
                      listing.totalReviews == 0
                          ? 'No reviews yet'
                          : '${listing.totalReviews} reviews',
                      style: GoogleFonts.hind(
                        textStyle: theme.textTheme.labelSmall?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _priceText(ShopListing listing) {
    if (listing.isFree) {
      return 'FREE';
    }

    if (listing.listingType.isService) {
      return 'From ₹${_formatPrice(listing.basePrice)}';
    }

    return '₹${_formatPrice(listing.basePrice)}';
  }

  String _formatPrice(double value) {
    if (value == value.roundToDouble()) {
      return value.toInt().toString();
    }

    return value.toStringAsFixed(2);
  }

  String _listingTypeLabel(ShopListingType type) {
    switch (type) {
      case ShopListingType.food:
        return 'FOOD';
      case ShopListingType.product:
        return 'PRODUCT';
      case ShopListingType.service:
        return 'SERVICE';
      case ShopListingType.class_:
        return 'CLASS';
      case ShopListingType.consultation:
        return 'CONSULTATION';
      case ShopListingType.eventSupport:
        return 'EVENT_SUPPORT';
      case ShopListingType.help:
        return 'HELP';
      case ShopListingType.grocery:
        return 'GROCERY';
      case ShopListingType.unknown:
        return 'LISTING';
    }
  }
}
