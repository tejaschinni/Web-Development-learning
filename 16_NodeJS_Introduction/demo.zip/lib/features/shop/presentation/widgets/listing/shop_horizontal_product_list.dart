import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_listing_provider.dart';
import 'package:society_seva/features/shop/presentation/widgets/listing/shop_listing_card.dart';
import 'package:society_seva/features/shop/presentation/widgets/listing/shop_popular_listings_shimmer.dart';
import 'package:society_seva/features/shop/presentation/widgets/shop_loading_more_card.dart';

class HorizontalProductList extends ConsumerStatefulWidget {
  const HorizontalProductList({super.key, required this.societyId});

  final String? societyId;

  @override
  ConsumerState<HorizontalProductList> createState() =>
      _HorizontalProductListState();
}

class _HorizontalProductListState extends ConsumerState<HorizontalProductList> {
  late final ScrollController _scrollController;

  @override
  void initState() {
    super.initState();

    _scrollController = ScrollController();
    _scrollController.addListener(_onScroll);
  }

  void _onScroll() {
    if (!_scrollController.hasClients) return;

    final position = _scrollController.position;

    // Start loading before the user actually reaches the end.
    if (position.pixels >= position.maxScrollExtent - 300) {
      ref
          .read(shopPopularListingsProvider(widget.societyId ?? '').notifier)
          .loadNextPage();
    }
  }

  @override
  void dispose() {
    _scrollController
      ..removeListener(_onScroll)
      ..dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final societyId = widget.societyId ?? '';

    final listingsAsync = ref.watch(shopPopularListingsProvider(societyId));

    return listingsAsync.when(
      loading: () => const PopularListingsShimmer(),

      error: (error, stack) {
        return SizedBox(
          height: 250,
          child: Center(
            child: InkWell(
              onTap: () {
                ref.invalidate(shopPopularListingsProvider(societyId));
              },
              borderRadius: BorderRadius.circular(14),
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 10,
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    HugeIcon(
                      icon: HugeIcons.strokeRoundedRefresh,
                      size: 18,
                      color: theme.colorScheme.primary,
                    ),
                    const Gap(8),
                    Text(
                      'Unable to load listings',
                      style: GoogleFonts.hind(
                        textStyle: theme.textTheme.labelLarge?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },

      data: (state) {
        if (state.items.isEmpty) {
          return SizedBox(
            height: 250,
            child: Center(
              child: Text(
                'No listings available yet',
                style: GoogleFonts.hind(
                  textStyle: theme.textTheme.bodyMedium?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
            ),
          );
        }

        return SizedBox(
          height: 250,
          child: ListView.separated(
            controller: _scrollController,
            padding: const EdgeInsets.symmetric(horizontal: 20),
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            itemCount: state.items.length + (state.isLoadingMore ? 1 : 0),
            separatorBuilder: (_, _) => const Gap(14),
            itemBuilder: (context, index) {
              if (index >= state.items.length) {
                return const LoadingMoreCard();
              }

              return ListingCard(listing: state.items[index]);
            },
          ),
        );
      },
    );
  }
}
