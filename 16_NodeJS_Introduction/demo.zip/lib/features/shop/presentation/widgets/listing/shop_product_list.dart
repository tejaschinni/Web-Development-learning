import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_listing_provider.dart';
import 'package:society_seva/features/shop/presentation/widgets/listing/shop_listing_card.dart';
import 'package:society_seva/features/shop/presentation/widgets/listing/shop_popular_listings_shimmer.dart';
import 'package:society_seva/features/shop/presentation/widgets/shop_loading_more_card.dart';

class ProductList extends ConsumerStatefulWidget {
  const ProductList({super.key, required this.societyId});

  final String? societyId;

  @override
  ConsumerState<ProductList> createState() => _ProductListState();
}

class _ProductListState extends ConsumerState<ProductList> {
  late final ScrollController _scrollController;

  @override
  void initState() {
    super.initState();

    _scrollController = ScrollController();
    _scrollController.addListener(_onScroll);
  }

  void _onScroll() {
    if (!_scrollController.hasClients) return;

    final position = _scrollController.position;

    // Start loading before the user actually reaches the end.
    if (position.pixels >= position.maxScrollExtent - 300) {
      ref
          .read(shopPopularListingsProvider(widget.societyId ?? '').notifier)
          .loadNextPage();
    }
  }

  @override
  void dispose() {
    _scrollController
      ..removeListener(_onScroll)
      ..dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final societyId = widget.societyId ?? '';

    final listingsAsync = ref.watch(shopPopularListingsProvider(societyId));

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      appBar: AppBar(
        title: Text(
          'Explore listings',
          style: GoogleFonts.hind(fontWeight: FontWeight.w700),
        ),
      ),
      body: listingsAsync.when(
        loading: () => const Center(child: PopularListingsShimmer()),

        error: (error, stack) {
          return SizedBox(
            height: 250,
            child: Center(
              child: InkWell(
                onTap: () {
                  ref.invalidate(shopPopularListingsProvider(societyId));
                },
                borderRadius: BorderRadius.circular(14),
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 10,
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      HugeIcon(
                        icon: HugeIcons.strokeRoundedRefresh,
                        size: 18,
                        color: theme.colorScheme.primary,
                      ),
                      const Gap(8),
                      Text(
                        'Unable to load listings',
                        style: GoogleFonts.hind(
                          textStyle: theme.textTheme.labelLarge?.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },

        data: (state) {
          final visibleListings = state.items
              .where((listing) => listing.isAvailable && listing.isApproved)
              .toList();

          if (visibleListings.isEmpty) {
            return Center(
              child: state.hasNextPage
                  ? TextButton(
                      onPressed: state.isLoadingMore
                          ? null
                          : () => ref
                                .read(
                                  shopPopularListingsProvider(societyId)
                                      .notifier,
                                )
                                .loadNextPage(),
                      child: Text(
                        state.isLoadingMore
                            ? 'Loading listings...'
                            : 'Load more listings',
                        style: theme.textTheme.bodyMedium,
                      ),
                    )
                  : Text(
                      'No listings available yet',
                      style: GoogleFonts.hind(
                        textStyle: theme.textTheme.bodyMedium?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ),
            );
          }

          return GridView.builder(
            controller: _scrollController,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            padding: EdgeInsets.fromLTRB(20, 14, 20, 32),
            itemCount:
                visibleListings.length +
                (state.hasNextPage || state.isLoadingMore ? 1 : 0),

            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 14,
              childAspectRatio: 0.68,
            ),
            itemBuilder: (context, index) {
              if (index >= visibleListings.length) {
                if (state.isLoadingMore) return const LoadingMoreCard();

                return TextButton(
                  onPressed: () => ref
                      .read(shopPopularListingsProvider(societyId).notifier)
                      .loadNextPage(),
                  child: const Text('Load more listings'),
                );
              }
              final listing = visibleListings[index];

              return ListingCard(listing: listing);
            },
          );
        },
      ),
    );
  }
}
