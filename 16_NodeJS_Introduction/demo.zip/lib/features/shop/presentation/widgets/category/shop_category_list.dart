import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:society_seva/features/shop/domain/entities/shop_category.dart';
import 'package:society_seva/features/shop/presentation/widgets/category/shop_category_item.dart';

class CategoryList extends StatelessWidget {
  const CategoryList({super.key, required this.categories, required this.onCategoryTap});

  final List<ShopCategory> categories;
  final ValueChanged<ShopCategory> onCategoryTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 104,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: categories.length,
        separatorBuilder: (_, _) => const Gap(14),
        itemBuilder: (context, index) {
          final category = categories[index];

          return CategoryItem(category: category, onTap: () => onCategoryTap(category));
        },
      ),
    );
  }
}
