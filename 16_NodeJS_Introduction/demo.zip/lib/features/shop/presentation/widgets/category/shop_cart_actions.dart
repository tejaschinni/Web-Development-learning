import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:society_seva/core/network/api_exception.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing_details.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_cart_provider.dart';

Future<void> addListingToCart(
  BuildContext context,
  WidgetRef ref,
  ShopListing listing, {
  required int quantity,
  ShopFoodServingSize? servingSize,
}) async {
  if (!listing.isApproved || !listing.isAvailable) {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('This listing is not available to order')));
    return;
  }

  try {
    final cart = await ref.read(shopCartProvider.future);
    var replaceExistingCart = false;
    if (cart != null && cart.sellerId != listing.sellerId) {
      replaceExistingCart =
          await showDialog<bool>(
            context: context,
            builder: (dialogContext) => AlertDialog(
              title: const Text('Replace current cart?'),
              content: const Text(
                'Your cart contains items from another seller. Replacing it will remove those items.',
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext, false),
                  child: const Text('Keep cart'),
                ),
                FilledButton(
                  onPressed: () => Navigator.pop(dialogContext, true),
                  child: const Text('Replace cart'),
                ),
              ],
            ),
          ) ??
          false;
      if (!replaceExistingCart) return;
    }

    await ref
        .read(shopCartProvider.notifier)
        .addItem(
          listingId: listing.id,
          quantity: quantity,
          foodServingSizeId: servingSize?.id,
          replaceExistingCart: replaceExistingCart,
        );
    if (!context.mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: const Text('Added to cart'),
          action: SnackBarAction(label: 'View cart', onPressed: () => context.push('/shop/cart')),
        ),
      );
  } catch (error) {
    if (!context.mounted) return;
    final message = error is ApiException ? error.message : 'Unable to add this listing to cart';
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }
}
