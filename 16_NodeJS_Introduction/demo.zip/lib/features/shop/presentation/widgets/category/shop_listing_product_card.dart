import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing.dart';
import 'package:society_seva/features/shop/domain/enums/shop_listing_type.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_listing_provider.dart';
import 'package:society_seva/features/shop/presentation/widgets/category/shop_add_button.dart';
import 'package:society_seva/features/shop/presentation/widgets/category/shop_cart_actions.dart';

class ListingProductCard extends ConsumerWidget {
  const ListingProductCard({super.key, required this.listing});

  final ShopListing listing;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final images = ref.watch(shopListingImagesProvider(listing.id)).valueOrNull;
    final imageUrl = images
        ?.where((image) => image.moderationStatus.toUpperCase() == 'APPROVED')
        .firstOrNull
        ?.imageUrl;

    return Material(
      color: theme.colorScheme.surface,
      borderRadius: BorderRadius.circular(18),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => context.push('/shop/product/${listing.id}', extra: listing),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              flex: 6,
              child: Stack(
                children: [
                  Positioned.fill(
                    child: imageUrl == null
                        ? Container(
                            color: theme.colorScheme.surfaceContainerHighest,
                            child: Center(
                              child: HugeIcon(
                                icon: HugeIcons.strokeRoundedImage01,
                                size: 34,
                                color: theme.colorScheme.onSurfaceVariant,
                              ),
                            ),
                          )
                        : Image.network(
                            imageUrl,
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) => Container(
                              color: theme.colorScheme.surfaceContainerHighest,
                              child: Center(
                                child: HugeIcon(
                                  icon: HugeIcons.strokeRoundedImage01,
                                  size: 34,
                                  color: theme.colorScheme.onSurfaceVariant,
                                ),
                              ),
                            ),
                          ),
                  ),

                  Positioned(
                    right: 9,
                    bottom: 9,
                    child: AddButton(
                      onTap: () {
                        if (listing.listingType == ShopListingType.food) {
                          context.push('/shop/product/${listing.id}', extra: listing);
                        } else {
                          addListingToCart(context, ref, listing, quantity: 1);
                        }
                      },
                    ),
                  ),
                ],
              ),
            ),

            Expanded(
              flex: 5,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(11, 10, 11, 11),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      listing.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w700),
                    ),

                    const Gap(3),

                    Text(
                      listing.description,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),

                    const Spacer(),

                    Row(
                      children: [
                        HugeIcon(
                          icon: HugeIcons.strokeRoundedStar,
                          size: 14,
                          color: theme.colorScheme.primary,
                        ),
                        const Gap(3),
                        Text(
                          listing.averageRating.toStringAsFixed(1),
                          style: theme.textTheme.labelSmall?.copyWith(fontWeight: FontWeight.w700),
                        ),
                        const Spacer(),
                        Text(
                          listing.isFree ? 'Free' : '₹${listing.basePrice.toStringAsFixed(0)}',
                          style: theme.textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w800),
                        ),
                      ],
                    ),

                    const Gap(2),

                    Text(
                      listing.quantityAvailable == null
                          ? 'Available'
                          : '${listing.quantityAvailable} available',
                      style: theme.textTheme.labelSmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
