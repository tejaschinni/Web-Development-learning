import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/features/shop/domain/entities/shop_category.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_category_provider.dart';
import 'package:society_seva/features/shop/presentation/widgets/category/shop_category_list.dart';
import 'package:society_seva/features/shop/presentation/widgets/category/shop_category_list_shimmer.dart';
import 'package:society_seva/features/shop/presentation/widgets/category/shop_category_load_error.dart';

class ExploreCategories extends ConsumerWidget {
  const ExploreCategories({super.key, required this.onCategoryTap});

  final ValueChanged<ShopCategory> onCategoryTap;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final categoriesAsync = ref.watch(shopCategoriesProvider);

    return categoriesAsync.when(
      loading: () => const CategoryListShimmer(),

      error: (error, stack) => CategoryLoadError(
        onRetry: () {
          ref.invalidate(shopCategoriesProvider);
        },
      ),
      data: (categories) {
        final topLevelCategories =
            categories.where((category) => category.isActive && category.isTopLevel).toList()
              ..sort((a, b) => a.displayOrder.compareTo(b.displayOrder));

        if (topLevelCategories.isEmpty) {
          return const SizedBox.shrink();
        }

        return CategoryList(categories: topLevelCategories, onCategoryTap: onCategoryTap);
      },
    );
  }
}
