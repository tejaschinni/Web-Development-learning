import 'package:flutter/material.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing.dart';
import 'package:society_seva/features/shop/presentation/widgets/category/shop_listing_product_card.dart';

class ProductGrid extends StatelessWidget {
  const ProductGrid({super.key, required this.listings});

  final List<ShopListing> listings;

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: listings.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 14,
        childAspectRatio: 0.68,
      ),
      itemBuilder: (context, index) {
        return ListingProductCard(listing: listings[index]);
      },
    );
  }
}
