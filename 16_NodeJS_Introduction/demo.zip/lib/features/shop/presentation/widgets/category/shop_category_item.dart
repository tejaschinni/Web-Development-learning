import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/features/shop/domain/entities/shop_category.dart';
import 'package:society_seva/features/shop/domain/enums/shop_category_type.dart';

class CategoryItem extends StatelessWidget {
  const CategoryItem({super.key, required this.category, required this.onTap});

  final ShopCategory category;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return SizedBox(
      width: 72,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Column(
          children: [
            Container(
              width: 58,
              height: 58,
              decoration: BoxDecoration(
                color: theme.colorScheme.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(18),
              ),
              child: Center(
                child: HugeIcon(
                  icon: _categoryIconFor(category),
                  size: 25,
                  color: theme.colorScheme.primary,
                ),
              ),
            ),
            const Gap(8),
            Text(
              category.name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: GoogleFonts.hind(
                textStyle: theme.textTheme.labelMedium?.copyWith(fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

List<List<dynamic>> _categoryIconFor(ShopCategory category) {
  switch (category.slug.toLowerCase()) {
    case 'breakfast':
      return HugeIcons.strokeRoundedCoffee01;

    case 'dinner':
      return HugeIcons.strokeRoundedDish01;

    case 'electric':
    case 'electrician':
    case 'elec':
      return HugeIcons.strokeRoundedPlug01;

    case 'repair':
    case 'ran-repair':
      return HugeIcons.strokeRoundedTools;

    case 'classes':
      return HugeIcons.strokeRoundedBookOpen01;

    default:
      switch (category.categoryType) {
        case ShopCategoryType.food:
          return HugeIcons.strokeRoundedRestaurant01;

        case ShopCategoryType.service:
          return HugeIcons.strokeRoundedTools;

        case ShopCategoryType.product:
          return HugeIcons.strokeRoundedShoppingBag01;

        case ShopCategoryType.unknown:
          return HugeIcons.strokeRoundedGridView;
      }
  }
}
