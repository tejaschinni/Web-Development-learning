import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/features/shop/presentation/widgets/category/shop_filter_button.dart';

class FilterBar extends StatelessWidget {
  const FilterBar({
    super.key,
    required this.selectedSort,
    required this.onSortChanged,
    required this.isService,
  });

  final String selectedSort;
  final ValueChanged<String> onSortChanged;
  final bool isService;

  @override
  Widget build(BuildContext context) {
    // final theme = Theme.of(context);

    return SizedBox(
      height: 38,
      child: ListView(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        children: [
          FilterButton(
            icon: HugeIcons.strokeRoundedSorting05,
            label: selectedSort,
            onTap: () {
              _showSortSheet(context);
            },
          ),

          const Gap(8),

          if (!isService) ...[
            FilterButton(
              label: 'Under ₹200',
              onTap: () {
                // TODO: Price filter.
              },
            ),

            const Gap(8),

            FilterButton(
              label: 'Veg',
              icon: HugeIcons.strokeRoundedLeaf01,
              onTap: () {
                // TODO: Food preference filter.
              },
            ),

            const Gap(8),
          ],

          FilterButton(
            icon: HugeIcons.strokeRoundedFilter,
            label: 'Filters',
            onTap: () {
              // TODO: Open full filter sheet.
            },
          ),
        ],
      ),
    );
  }

  void _showSortSheet(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (context) {
        final theme = Theme.of(context);

        const options = ['Recommended', 'Price: Low to High', 'Price: High to Low', 'Rating'];

        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Sort by',
                  style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700),
                ),
                const Gap(12),
                ...options.map(
                  (option) => RadioListTile<String>(
                    value: option,
                    groupValue: selectedSort,
                    title: Text(option),
                    contentPadding: EdgeInsets.zero,
                    onChanged: (value) {
                      if (value != null) {
                        onSortChanged(value);
                        Navigator.of(context).pop();
                      }
                    },
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
