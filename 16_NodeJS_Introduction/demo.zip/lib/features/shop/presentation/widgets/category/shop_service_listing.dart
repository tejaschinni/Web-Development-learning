import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing.dart';
import 'package:society_seva/features/shop/presentation/widgets/category/shop_service_card.dart';

class ServiceListing extends StatelessWidget {
  const ServiceListing({super.key, required this.listings});

  final List<ShopListing> listings;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        for (var index = 0; index < listings.length; index++) ...[
          if (index > 0) const Gap(12),
          ServiceCard(listing: listings[index]),
        ],
      ],
    );
  }
}
