import 'package:flutter/material.dart';

class LoadingMoreCard extends StatelessWidget {
  const LoadingMoreCard({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return SizedBox(
      width: 70,
      child: Center(
        child: SizedBox(
          width: 22,
          height: 22,
          child: CircularProgressIndicator(strokeWidth: 2.2, color: theme.colorScheme.primary),
        ),
      ),
    );
  }
}
