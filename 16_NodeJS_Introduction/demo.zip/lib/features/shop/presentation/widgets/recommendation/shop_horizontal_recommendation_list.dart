import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:society_seva/features/shop/presentation/widgets/recommendation/shop_recommendation_card.dart';

class HorizontalRecommendationList extends StatelessWidget {
  const HorizontalRecommendationList({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 250,
      child: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        children: const [
          RecommendationCard(
            title: 'Birthday Cake',
            subtitle: "Riya's Bakery",
            price: '₹450',
            type: 'PRODUCT',
          ),
          Gap(14),
          RecommendationCard(
            title: 'Electrician',
            subtitle: 'Sagar Electrical',
            price: 'From ₹150',
            type: 'SERVICE',
          ),
          Gap(14),
          RecommendationCard(
            title: 'Math Classes',
            subtitle: 'Amit Tutorials',
            price: '₹300 / class',
            type: 'SERVICE',
          ),
        ],
      ),
    );
  }
}
