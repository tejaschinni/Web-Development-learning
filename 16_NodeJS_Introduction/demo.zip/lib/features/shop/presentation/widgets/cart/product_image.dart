import 'package:flutter/material.dart';
import 'package:hugeicons/hugeicons.dart';

class ProductImage extends StatelessWidget {
  final bool isFood;
  final String? imageUrl;

  const ProductImage({super.key, required this.imageUrl, required this.isFood});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      width: 82,
      height: 82,
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(14),
      ),
      child: imageUrl == null
          ? HugeIcon(
              icon: isFood ? HugeIcons.strokeRoundedRestaurant02 : HugeIcons.strokeRoundedImage01,
              size: 28,
              color: theme.colorScheme.onSurfaceVariant,
            )
          : ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: Image.network(
                imageUrl!,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) => HugeIcon(
                  icon: isFood
                      ? HugeIcons.strokeRoundedRestaurant02
                      : HugeIcons.strokeRoundedImage01,
                  size: 28,
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ),
    );
  }
}
