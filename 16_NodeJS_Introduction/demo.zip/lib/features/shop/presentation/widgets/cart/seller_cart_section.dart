import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/features/shop/data/models/shop_cart_seller_group.dart';
import 'package:society_seva/features/shop/presentation/widgets/cart/cart_item_tile.dart';

class SellerCartSection extends StatelessWidget {
  final CartSellerGroup group;
  final ValueChanged<String> onIncrease;
  final ValueChanged<String> onDecrease;
  final ValueChanged<String> onRemove;

  const SellerCartSection({
    super.key,
    required this.group,
    required this.onIncrease,
    required this.onDecrease,
    required this.onRemove,
  });

  double get _sellerSubtotal {
    return group.items.fold(0, (total, item) => total + item.lineTotal);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: theme.colorScheme.outlineVariant),
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
            child: Row(
              children: [
                Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(
                    color: theme.colorScheme.surfaceContainerHighest,
                    borderRadius: BorderRadius.circular(11),
                  ),
                  child: HugeIcon(
                    icon: HugeIcons.strokeRoundedStore01,
                    size: 20,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
                const Gap(11),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        group.sellerName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.hind(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: theme.colorScheme.onSurface,
                        ),
                      ),
                      const Gap(1),
                      Text(
                        '${group.items.length} ${group.items.length == 1 ? 'item' : 'items'}',
                        style: GoogleFonts.hind(
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
                Text(
                  '₹${_sellerSubtotal.toStringAsFixed(0)}',
                  style: GoogleFonts.hind(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: theme.colorScheme.onSurface,
                  ),
                ),
              ],
            ),
          ),
          Divider(height: 1, color: theme.colorScheme.outlineVariant),
          ...group.items.map(
            (item) => CartItemTile(
              item: item,
              onIncrease: () => onIncrease(item.id),
              onDecrease: () => onDecrease(item.id),
              onRemove: () => onRemove(item.id),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 2, 16, 14),
            child: Align(
              alignment: Alignment.centerLeft,
              child: TextButton.icon(
                onPressed: () {
                  // TODO:
                  // Navigate to this seller's storefront.
                },
                style: TextButton.styleFrom(
                  padding: EdgeInsets.zero,
                  minimumSize: const Size(44, 44),
                ),
                icon: HugeIcon(
                  icon: HugeIcons.strokeRoundedStore01,
                  size: 17,
                  color: theme.colorScheme.primary,
                ),
                label: Text(
                  'View seller store',
                  style: GoogleFonts.hind(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: theme.colorScheme.primary,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
