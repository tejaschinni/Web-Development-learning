import 'package:flutter/foundation.dart';

@immutable
class ShopListingImage {
  const ShopListingImage({
    required this.id,
    required this.listingId,
    required this.imageUrl,
    required this.moderationStatus,
    required this.displayOrder,
    required this.createdAt,
  });

  final String id;
  final String listingId;
  final String imageUrl;
  final String moderationStatus;
  final int displayOrder;
  final DateTime? createdAt;

  factory ShopListingImage.fromJson(Map<String, dynamic> json) {
    return ShopListingImage(
      id: json['id']?.toString() ?? '',
      listingId: json['listingId']?.toString() ?? '',
      imageUrl: json['imageUrl']?.toString() ?? '',
      moderationStatus: json['moderationStatus']?.toString() ?? '',
      displayOrder: (json['displayOrder'] as num?)?.toInt() ?? 0,
      createdAt: DateTime.tryParse(json['createdAt']?.toString() ?? ''),
    );
  }
}

@immutable
class ShopFoodServingSize {
  const ShopFoodServingSize({
    required this.id,
    required this.sizeValue,
    required this.sizeUnit,
    required this.description,
    required this.price,
    required this.quantityAvailable,
    required this.isAvailable,
  });

  final String id;
  final double sizeValue;
  final String sizeUnit;
  final String description;
  final double price;
  final int quantityAvailable;
  final bool isAvailable;

  factory ShopFoodServingSize.fromJson(Map<String, dynamic> json) {
    return ShopFoodServingSize(
      id: json['id']?.toString() ?? '',
      sizeValue: (json['sizeValue'] as num?)?.toDouble() ?? 0,
      sizeUnit: json['sizeUnit']?.toString() ?? '',
      description: json['description']?.toString() ?? '',
      price: (json['price'] as num?)?.toDouble() ?? 0,
      quantityAvailable: (json['quantityAvailable'] as num?)?.toInt() ?? 0,
      isAvailable: json['isAvailable'] as bool? ?? false,
    );
  }
}

@immutable
class ShopFoodDetails {
  const ShopFoodDetails({
    required this.id,
    required this.listingId,
    required this.preparationTime,
    required this.spiceLevel,
    required this.spiceLevelText,
    required this.freshnessDeclaration,
    required this.isFrozenItem,
    required this.fssaiRequired,
    required this.servingSizes,
  });

  final String id;
  final String listingId;
  final DateTime? preparationTime;
  final int spiceLevel;
  final String spiceLevelText;
  final String freshnessDeclaration;
  final bool isFrozenItem;
  final bool fssaiRequired;
  final List<ShopFoodServingSize> servingSizes;

  factory ShopFoodDetails.fromJson(Map<String, dynamic> json) {
    final servingSizes = json['servingSizes'] as List<dynamic>? ?? const [];
    return ShopFoodDetails(
      id: json['id']?.toString() ?? '',
      listingId: json['listingId']?.toString() ?? '',
      preparationTime: DateTime.tryParse(json['preparationTime']?.toString() ?? ''),
      spiceLevel: (json['spiceLevel'] as num?)?.toInt() ?? 0,
      spiceLevelText: json['spiceLevelText']?.toString() ?? '',
      freshnessDeclaration: json['freshnessDeclaration']?.toString() ?? '',
      isFrozenItem: json['isFrozenItem'] as bool? ?? false,
      fssaiRequired: json['fssaiRequired'] as bool? ?? false,
      servingSizes: servingSizes
          .whereType<Map>()
          .map((item) => ShopFoodServingSize.fromJson(Map<String, dynamic>.from(item)))
          .toList(),
    );
  }
}

@immutable
class ShopServiceDetails {
  const ShopServiceDetails({
    required this.id,
    required this.listingId,
    required this.serviceDurationMinutes,
    required this.serviceLocationType,
    required this.homeVisitAvailable,
    required this.onlineAvailable,
    required this.certificateRequired,
    this.requiredMaterials,
    this.cancellationPolicy,
  });

  final String id;
  final String listingId;
  final int serviceDurationMinutes;
  final String serviceLocationType;
  final bool homeVisitAvailable;
  final bool onlineAvailable;
  final bool certificateRequired;
  final String? requiredMaterials;
  final String? cancellationPolicy;

  factory ShopServiceDetails.fromJson(Map<String, dynamic> json) {
    return ShopServiceDetails(
      id: json['id']?.toString() ?? '',
      listingId: json['listingId']?.toString() ?? '',
      serviceDurationMinutes: (json['serviceDurationMinutes'] as num?)?.toInt() ?? 0,
      serviceLocationType: json['serviceLocationType']?.toString() ?? '',
      homeVisitAvailable: json['homeVisitAvailable'] as bool? ?? false,
      onlineAvailable: json['onlineAvailable'] as bool? ?? false,
      certificateRequired: json['certificateRequired'] as bool? ?? false,
      requiredMaterials: json['requiredMaterials']?.toString(),
      cancellationPolicy: json['cancellationPolicy']?.toString(),
    );
  }
}

@immutable
class ServiceScheduleSlot {
  const ServiceScheduleSlot({
    required this.startsAt,
    required this.endsAt,
    required this.durationMinutes,
    required this.timeZone,
    required this.status,
  });

  final DateTime startsAt;
  final DateTime endsAt;
  final int durationMinutes;
  final String timeZone;
  final String status;

  bool get isAvailable => status.toUpperCase() == 'AVAILABLE';

  factory ServiceScheduleSlot.fromJson(Map<String, dynamic> json) => ServiceScheduleSlot(
    startsAt: DateTime.parse(json['startsAt'].toString()),
    endsAt: DateTime.parse(json['endsAt'].toString()),
    durationMinutes: (json['durationMinutes'] as num?)?.toInt() ?? 0,
    timeZone: json['timeZone']?.toString() ?? '',
    status: json['status']?.toString() ?? '',
  );
}
