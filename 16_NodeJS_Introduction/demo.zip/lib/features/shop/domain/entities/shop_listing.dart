import 'package:flutter/foundation.dart';
import 'package:society_seva/features/shop/domain/enums/shop_listing_approval_status.dart';
import 'package:society_seva/features/shop/domain/enums/shop_listing_availability_status.dart';
import 'package:society_seva/features/shop/domain/enums/shop_listing_moderation_status.dart';
import 'package:society_seva/features/shop/domain/enums/shop_listing_sponsored_status.dart';
import 'package:society_seva/features/shop/domain/enums/shop_listing_type.dart';

@immutable
class ShopListing {
  const ShopListing({
    required this.id,
    required this.sellerId,
    required this.societyId,
    required this.categoryId,
    required this.additionalCategoryIds,
    required this.listingType,
    required this.title,
    required this.description,
    required this.basePrice,
    this.priceUnit,
    required this.isFree,
    required this.quantityAvailable,
    required this.availabilityStatus,
    required this.approvalStatus,
    required this.moderationStatus,
    required this.sponsoredStatus,
    required this.averageRating,
    required this.totalReviews,
    required this.tagNames,
    required this.createdAt,
    required this.updatedAt,
  });

  final String id;
  final String sellerId;
  final String societyId;
  final String categoryId;
  final List<String> additionalCategoryIds;

  final ShopListingType listingType;

  final String title;
  final String description;

  final double basePrice;
  final String? priceUnit;
  final bool isFree;

  final int? quantityAvailable;

  final ShopListingAvailabilityStatus availabilityStatus;
  final ShopListingApprovalStatus approvalStatus;
  final ShopListingModerationStatus moderationStatus;
  final ShopListingSponsoredStatus sponsoredStatus;

  final double averageRating;
  final int totalReviews;

  final List<String> tagNames;

  final DateTime? createdAt;
  final DateTime? updatedAt;

  bool get isAvailable => availabilityStatus == ShopListingAvailabilityStatus.available;

  bool get isApproved => approvalStatus == ShopListingApprovalStatus.approved;

  factory ShopListing.fromJson(Map<String, dynamic> json) {
    return ShopListing(
      id: json['id']?.toString() ?? '',
      sellerId: json['sellerId']?.toString() ?? '',
      societyId: json['societyId']?.toString() ?? '',
      categoryId: json['categoryId']?.toString() ?? '',
      additionalCategoryIds:
          (json['additionalCategoryIds'] as List<dynamic>?)?.map((e) => e.toString()).toList() ??
          const [],

      listingType: ShopListingType.fromJson(json['listingType']?.toString()),

      title: json['title']?.toString() ?? '',
      description: json['description']?.toString() ?? '',

      basePrice: (json['basePrice'] as num?)?.toDouble() ?? 0,
      priceUnit: json['priceUnit']?.toString(),
      isFree: json['isFree'] as bool? ?? false,

      quantityAvailable: (json['quantityAvailable'] as num?)?.toInt(),

      availabilityStatus: ShopListingAvailabilityStatus.fromJson(
        json['availabilityStatus']?.toString(),
      ),

      approvalStatus: ShopListingApprovalStatus.fromJson(json['approvalStatus']?.toString()),

      moderationStatus: ShopListingModerationStatus.fromJson(json['moderationStatus']?.toString()),

      sponsoredStatus: ShopListingSponsoredStatus.fromJson(json['sponsoredStatus']?.toString()),

      averageRating: (json['averageRating'] as num?)?.toDouble() ?? 0,
      totalReviews: (json['totalReviews'] as num?)?.toInt() ?? 0,

      tagNames: (json['tagNames'] as List<dynamic>?)?.map((e) => e.toString()).toList() ?? const [],

      createdAt: DateTime.tryParse(json['createdAt']?.toString() ?? ''),

      updatedAt: DateTime.tryParse(json['updatedAt']?.toString() ?? ''),
    );
  }
}
