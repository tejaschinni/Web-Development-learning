import 'package:flutter/foundation.dart';

@immutable
class ShopCartItem {
  const ShopCartItem({
    required this.id,
    required this.listingId,
    required this.quantity,
    required this.unitPriceSnapshot,
    required this.lineTotal,
    required this.listingName,
    this.sellerName,
    this.isFood = false,
  });

  final String id;
  final String listingId;
  final int quantity;
  final double unitPriceSnapshot;
  final double lineTotal;
  final String listingName;
  final String? sellerName;
  final bool isFood;

  factory ShopCartItem.fromJson(Map<String, dynamic> json) {
    final quantity = (json['quantity'] as num?)?.toInt() ?? 0;
    final unitPrice = (json['unitPriceSnapshot'] as num?)?.toDouble() ?? 0;
    return ShopCartItem(
      id: json['id']?.toString() ?? '',
      listingId: json['listingId']?.toString() ?? '',
      quantity: quantity,
      unitPriceSnapshot: unitPrice,
      lineTotal: (json['lineTotal'] as num?)?.toDouble() ?? unitPrice * quantity,
      listingName: json['listingName']?.toString() ?? '',
      sellerName: json['sellerName']?.toString(),
      isFood: json['listingType']?.toString().toUpperCase() == 'FOOD',
    );
  }
}

@immutable
class ShopCart {
  const ShopCart({
    required this.id,
    required this.buyerId,
    required this.sellerId,
    required this.sellerName,
    required this.status,
    required this.items,
    required this.subtotal,
  });

  final String id;
  final String buyerId;
  final String sellerId;
  final String sellerName;
  final String status;
  final List<ShopCartItem> items;
  final double subtotal;

  int get itemCount => items.fold(0, (total, item) => total + item.quantity);

  factory ShopCart.fromJson(Map<String, dynamic> json) {
    final items = json['items'] as List<dynamic>? ?? const [];
    return ShopCart(
      id: json['id']?.toString() ?? '',
      buyerId: json['buyerId']?.toString() ?? '',
      sellerId: json['sellerId']?.toString() ?? '',
      sellerName: json['sellerName']?.toString() ?? '',
      status: json['status']?.toString() ?? '',
      items: items
          .whereType<Map>()
          .map((item) => ShopCartItem.fromJson(Map<String, dynamic>.from(item)))
          .toList(),
      subtotal: (json['subtotal'] as num?)?.toDouble() ?? 0,
    );
  }
}
