import 'package:flutter/foundation.dart';
import 'package:society_seva/features/shop/domain/enums/shop_seller_approval_status.dart';
import 'package:society_seva/features/shop/domain/enums/shop_seller_availability_status.dart';
import 'package:society_seva/features/shop/domain/enums/shop_seller_fssai_status.dart';
import 'package:society_seva/features/shop/domain/enums/shop_seller_renewal_status.dart';
import 'package:society_seva/features/shop/domain/enums/shop_seller_type.dart';

@immutable
class ShopSeller {
  const ShopSeller({
    required this.id,
    required this.userId,
    required this.societyId,
    required this.displayName,
    this.businessName,
    required this.sellerType,
    this.bio,
    required this.availabilityStatus,
    required this.approvalStatus,
    required this.fssaiStatus,
    required this.fssaiRequired,
    required this.renewalStatus,
    required this.totalListings,
    required this.averageRating,
    required this.rejectedOrders,
    required this.cancelledOrders,
    required this.totalOrders,
    required this.totalReviews,
    required this.createdAt,
    required this.updatedAt,
  });

  final String id;
  final String userId;
  final String societyId;
  final String displayName;
  final String? businessName;
  final ShopSellerType sellerType;
  final String? bio;
  final ShopSellerAvailabilityStatus availabilityStatus;
  final ShopSellerApprovalStatus approvalStatus;
  final ShopSellerFssaiStatus fssaiStatus;
  final bool fssaiRequired;
  final ShopSellerRenewalStatus renewalStatus;
  final int totalListings;
  final double averageRating;
  final int rejectedOrders;
  final int cancelledOrders;
  final int totalOrders;
  final int totalReviews;
  final DateTime createdAt;
  final DateTime updatedAt;

  bool get isAvailable => availabilityStatus == ShopSellerAvailabilityStatus.available;

  bool get isApproved => approvalStatus == ShopSellerApprovalStatus.approved;

  factory ShopSeller.fromJson(Map<String, dynamic> json) {
    return ShopSeller(
      id: json['id']?.toString() ?? '',
      userId: json["userId"]?.toString() ?? '',
      societyId: json['societyId']?.toString() ?? '',
      displayName: json["displayName"]?.toString() ?? '',
      sellerType: ShopSellerType.fromJson(json['sellerType']?.toString()),
      bio: json['bio']?.toString() ?? '',
      availabilityStatus: ShopSellerAvailabilityStatus.fromJson(
        json['availabilityStatus']?.toString(),
      ),
      approvalStatus: ShopSellerApprovalStatus.fromJson(json['approvalStatus']?.toString()),

      fssaiStatus: ShopSellerFssaiStatus.fromJson(json['fssaiStatus']?.toString()),
      fssaiRequired: json['fssaiRequired'] as bool? ?? false,
      renewalStatus: ShopSellerRenewalStatus.fromJson(json['renewalStatus']?.toString()),

      totalListings: json["totalListings"],
      averageRating: (json['averageRating'] as num?)?.toDouble() ?? 0,

      rejectedOrders: json["rejectedOrders"],
      cancelledOrders: json["cancelledOrders"],
      totalOrders: json["totalOrders"],

      totalReviews: (json['totalReviews'] as num?)?.toInt() ?? 0,
      createdAt: DateTime.parse(json["createdAt"]),
      updatedAt: DateTime.parse(json["updatedAt"]),
    );
  }

  factory ShopSeller.fromJson2(Map<String, dynamic> json) => ShopSeller(
    id: json["id"],
    userId: json["userId"],
    societyId: json["societyId"],
    displayName: json["displayName"],
    sellerType: json["sellerType"],
    bio: json["bio"],
    availabilityStatus: json["availabilityStatus"],
    approvalStatus: json["approvalStatus"],

    fssaiStatus: json["fssaiStatus"],
    fssaiRequired: json["fssaiRequired"],
    renewalStatus: json["renewalStatus"],

    totalListings: json["totalListings"],

    averageRating: json["averageRating"]?.toDouble(),
    rejectedOrders: json["rejectedOrders"],
    cancelledOrders: json["cancelledOrders"],
    totalOrders: json["totalOrders"],
    totalReviews: json["totalReviews"],
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "userId": userId,
    "societyId": societyId,
    "displayName": displayName,
    "sellerType": sellerType,
    "bio": bio,
    "availabilityStatus": availabilityStatus,
    "approvalStatus": approvalStatus,
    "fssaiStatus": fssaiStatus,
    "fssaiRequired": fssaiRequired,
    "renewalStatus": renewalStatus,
    "totalListings": totalListings,
    "averageRating": averageRating,
    "rejectedOrders": rejectedOrders,
    "cancelledOrders": cancelledOrders,
    "totalOrders": totalOrders,
    "totalReviews": totalReviews,
    "createdAt": createdAt.toIso8601String(),
    "updatedAt": updatedAt.toIso8601String(),
  };
}
