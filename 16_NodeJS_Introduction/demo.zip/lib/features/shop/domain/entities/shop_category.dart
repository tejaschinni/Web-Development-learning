import 'package:flutter/foundation.dart';
import 'package:society_seva/features/shop/domain/enums/shop_category_type.dart';

@immutable
class ShopCategory {
  const ShopCategory({
    required this.id,
    this.parentCategoryId,
    required this.name,
    required this.slug,
    required this.categoryType,
    required this.requiresCertificate,
    required this.isActive,
    required this.displayOrder,
    required this.subCategories,
  });

  final String id;
  final String? parentCategoryId;
  final String name;
  final String slug;
  final ShopCategoryType categoryType;
  final bool requiresCertificate;
  final bool isActive;
  final int displayOrder;
  final List<ShopCategory> subCategories;

  bool get isTopLevel => parentCategoryId == null;

  bool get hasSubCategories => subCategories.isNotEmpty;

  bool get isFood => categoryType == ShopCategoryType.food;

  bool get isService => categoryType == ShopCategoryType.service;

  bool get isProduct => categoryType == ShopCategoryType.product;

  @override
  String toString() {
    return 'ShopCategory('
        'id: $id, '
        'name: $name, '
        'slug: $slug, '
        'categoryType: $categoryType, '
        'isActive: $isActive, '
        'subCategories: ${subCategories.length}'
        ')';
  }
}
