import 'package:society_seva/features/shop/domain/entities/shop_category.dart';

abstract interface class ShopCategoryRepository {
  /// Returns cached categories immediately when available.
  ///
  /// If [forceRefresh] is true, the remote API is used and
  /// the local cache is replaced with the latest data.
  Future<List<ShopCategory>> getCategories({bool forceRefresh = false});

  /// Returns categories only from local cache.
  ///
  /// Returns null when no cache exists.
  Future<List<ShopCategory>?> getCachedCategories();

  /// Fetches the latest categories from the backend and
  /// updates the local cache.
  Future<List<ShopCategory>> refreshCategories();

  Future<bool> isCacheStale();

  Future<ShopCategory> getCategoryById(String categoryId);
}
