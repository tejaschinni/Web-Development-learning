import 'package:society_seva/features/shop/domain/entities/shop_cart.dart';

abstract class ShopCartRepository {
  Future<ShopCart?> getCart();

  Future<ShopCart> addItem({
    required String listingId,
    required int quantity,
    required bool replaceExistingCart,
    String? foodServingSizeId,
  });

  Future<ShopCart> updateItemQuantity({required String itemId, required int quantity});

  Future<void> deleteItem(String itemId);

  Future<void> deleteCart();
}
