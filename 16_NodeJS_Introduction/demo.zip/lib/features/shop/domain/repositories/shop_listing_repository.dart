import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing_details.dart';

abstract class ShopListingRepository {
  Future<PageResponse<ShopListing>> getListings({
    required String societyId,
    required PageableQuery pageable,
  });

  Future<PageResponse<ShopListing>> getCategoryListings({
    required String categoryId,
    required String societyId,
    required PageableQuery pageable,
  });


  Future<ShopListing> getListing(String listingId);

  Future<List<ShopListingImage>> getListingImages(String listingId);

  Future<ShopFoodDetails> getFoodDetails(String listingId);

  Future<ShopServiceDetails> getServiceDetails(String listingId);
}
