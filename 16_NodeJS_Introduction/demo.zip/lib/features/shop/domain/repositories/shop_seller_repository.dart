import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/shop/domain/entities/shop_seller.dart';

abstract class ShopSellerRepository {
  Future<PageResponse<ShopSeller>> getSellers({
    required String societyId,
    required PageableQuery pageable,
  });
}
