enum ShopListingType {
  food,
  product,
  service,
  class_,
  consultation,
  eventSupport,
  help,
  grocery,
  unknown;

  static ShopListingType fromJson(String? value) {
    switch (value?.toUpperCase()) {
      case 'FOOD':
        return ShopListingType.food;
      case 'PRODUCT':
        return ShopListingType.product;
      case 'SERVICE':
        return ShopListingType.service;
      case 'CLASS':
        return ShopListingType.class_;
      case 'CONSULTATION':
        return ShopListingType.consultation;
      case 'EVENT_SUPPORT':
        return ShopListingType.eventSupport;
      case 'HELP':
        return ShopListingType.help;
      case 'GROCERY':
        return ShopListingType.grocery;
      default:
        return ShopListingType.unknown;
    }
  }

  String get apiValue {
    switch (this) {
      case ShopListingType.food:
        return 'FOOD';
      case ShopListingType.product:
        return 'PRODUCT';
      case ShopListingType.service:
        return 'SERVICE';
      case ShopListingType.class_:
        return 'CLASS';
      case ShopListingType.consultation:
        return 'CONSULTATION';
      case ShopListingType.eventSupport:
        return 'EVENT_SUPPORT';
      case ShopListingType.help:
        return 'HELP';
      case ShopListingType.grocery:
        return 'GROCERY';
      case ShopListingType.unknown:
        return 'UNKNOWN';
    }
  }

  bool get isService => this == ShopListingType.service;

  bool get isProductLike => this == ShopListingType.product || this == ShopListingType.food;
}
