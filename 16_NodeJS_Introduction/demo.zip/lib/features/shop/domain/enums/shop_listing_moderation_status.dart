enum ShopListingModerationStatus {
  pending,
  approved,
  rejected,
  unknown;

  static ShopListingModerationStatus fromJson(String? value) {
    switch (value?.toUpperCase()) {
      case 'PENDING':
        return ShopListingModerationStatus.pending;
      case 'APPROVED':
        return ShopListingModerationStatus.approved;
      case 'REJECTED':
        return ShopListingModerationStatus.rejected;
      default:
        return ShopListingModerationStatus.unknown;
    }
  }
}
