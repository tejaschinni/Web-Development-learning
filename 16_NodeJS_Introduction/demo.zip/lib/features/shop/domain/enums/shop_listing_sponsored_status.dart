enum ShopListingSponsoredStatus {
  sponsored,
  notSponsored,
  unknown;

  static ShopListingSponsoredStatus fromJson(String? value) {
    switch (value?.toUpperCase()) {
      case 'SPONSORED':
        return ShopListingSponsoredStatus.sponsored;
      case 'NOT_SPONSORED':
        return ShopListingSponsoredStatus.notSponsored;
      default:
        return ShopListingSponsoredStatus.unknown;
    }
  }
}
