enum ShopListingApprovalStatus {
  approved,
  pending,
  rejected,
  unknown;

  static ShopListingApprovalStatus fromJson(String? value) {
    switch (value?.toUpperCase()) {
      case 'APPROVED':
        return ShopListingApprovalStatus.approved;
      case 'PENDING':
        return ShopListingApprovalStatus.pending;
      case 'REJECTED':
        return ShopListingApprovalStatus.rejected;
      default:
        return ShopListingApprovalStatus.unknown;
    }
  }
}
