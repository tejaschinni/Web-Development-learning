enum ShopSellerType {
  foodSeller,
  serviceProvider,
  productSeller,
  consultant,
  trainer,
  freeHelpProvider,
  mixed,
  unknown;

  static ShopSellerType fromJson(String? value) {
    switch (value?.toUpperCase()) {
      case 'FOOD_SELLER':
        return ShopSellerType.foodSeller;
      case 'SERVICE_PROVIDER':
        return ShopSellerType.serviceProvider;
      case 'PRODUCT_SELLER':
        return ShopSellerType.productSeller;
      case 'CONSULTANT':
        return ShopSellerType.consultant;
      case 'TRAINER':
        return ShopSellerType.trainer;
      case 'FREE_HELP_PROVIDER':
        return ShopSellerType.freeHelpProvider;
      case 'MIXED':
        return ShopSellerType.mixed;
      default:
        return ShopSellerType.unknown;
    }
  }
}
