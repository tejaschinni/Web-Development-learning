enum ShopSellerAvailabilityStatus {
  available,
  busy,
  onBreak,
  unavailable,
  unknown;

  static ShopSellerAvailabilityStatus fromJson(String? value) {
    switch (value?.toUpperCase()) {
      case 'AVAILABLE':
        return ShopSellerAvailabilityStatus.available;
      case 'BUSY':
        return ShopSellerAvailabilityStatus.busy;
      case 'ON_BREAK':
        return ShopSellerAvailabilityStatus.onBreak;
      case 'UNAVAILABLE':
        return ShopSellerAvailabilityStatus.unavailable;
      default:
        return ShopSellerAvailabilityStatus.unknown;
    }
  }
}
