enum ShopCategoryType {
  food,
  service,
  product,
  unknown;

  static ShopCategoryType fromApiValue(String? value) {
    switch (value?.toUpperCase()) {
      case 'FOOD':
        return ShopCategoryType.food;
      case 'SERVICE':
        return ShopCategoryType.service;
      case 'PRODUCT':
        return ShopCategoryType.product;
      default:
        return ShopCategoryType.unknown;
    }
  }
}
