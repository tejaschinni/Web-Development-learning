enum ShopSellerFssaiStatus {
  available,
  unavailable,
  notRequired,
  uploaded,
  pending,
  verified,
  unknown;

  static ShopSellerFssaiStatus fromJson(String? value) {
    switch (value?.toUpperCase()) {
      case 'AVAILABLE':
        return ShopSellerFssaiStatus.available;
      case 'UNAVAILABLE':
        return ShopSellerFssaiStatus.unavailable;
      case 'NOT_REQUIRED':
        return ShopSellerFssaiStatus.notRequired;
      case 'UPLOADED':
        return ShopSellerFssaiStatus.uploaded;
      case 'PENDING':
        return ShopSellerFssaiStatus.pending;
      case 'VERIFIED':
        return ShopSellerFssaiStatus.verified;
      default:
        return ShopSellerFssaiStatus.unknown;
    }
  }
}
