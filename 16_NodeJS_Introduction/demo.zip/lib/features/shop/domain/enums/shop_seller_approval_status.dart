enum ShopSellerApprovalStatus {
  draft,
  submitted,
  underReview,
  approved,
  rejected,
  needsMoreInfo,
  suspended,
  unknown;

  static ShopSellerApprovalStatus fromJson(String? value) {
    switch (value?.toUpperCase()) {
      case 'DRAFT':
        return ShopSellerApprovalStatus.draft;
      case 'SUBMITTED':
        return ShopSellerApprovalStatus.submitted;
      case 'UNDER_REVIEW':
        return ShopSellerApprovalStatus.underReview;
      case 'APPROVED':
        return ShopSellerApprovalStatus.approved;
      case 'REJECTED':
        return ShopSellerApprovalStatus.rejected;
      case 'NEEDS_MORE_INFO':
        return ShopSellerApprovalStatus.needsMoreInfo;
      case 'SUSPENDED':
        return ShopSellerApprovalStatus.suspended;
      default:
        return ShopSellerApprovalStatus.unknown;
    }
  }
}
