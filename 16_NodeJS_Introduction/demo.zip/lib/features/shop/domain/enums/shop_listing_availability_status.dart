enum ShopListingAvailabilityStatus {
  available,
  unavailable,
  unknown;

  static ShopListingAvailabilityStatus fromJson(String? value) {
    switch (value?.toUpperCase()) {
      case 'AVAILABLE':
        return ShopListingAvailabilityStatus.available;
      case 'UNAVAILABLE':
        return ShopListingAvailabilityStatus.unavailable;
      default:
        return ShopListingAvailabilityStatus.unknown;
    }
  }
}
