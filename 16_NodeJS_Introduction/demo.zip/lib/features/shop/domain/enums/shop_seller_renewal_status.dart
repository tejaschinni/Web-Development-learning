enum ShopSellerRenewalStatus {
  na,
  initial,
  newSeller,
  renewed,
  expired,
  unknown;

  static ShopSellerRenewalStatus fromJson(String? value) {
    switch (value?.toUpperCase()) {
      case 'NA':
        return ShopSellerRenewalStatus.na;
      case 'INITIAL':
        return ShopSellerRenewalStatus.initial;
      case 'NEW':
        return ShopSellerRenewalStatus.newSeller;
      case 'RENEWED':
        return ShopSellerRenewalStatus.renewed;
      case 'EXPIRED':
        return ShopSellerRenewalStatus.expired;
      default:
        return ShopSellerRenewalStatus.unknown;
    }
  }
}
