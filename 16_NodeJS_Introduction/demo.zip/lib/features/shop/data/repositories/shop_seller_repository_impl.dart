import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/shop/data/datasources/shop_seller_remote_data_source.dart';
import 'package:society_seva/features/shop/domain/entities/shop_seller.dart';
import 'package:society_seva/features/shop/domain/repositories/shop_seller_repository.dart';

class ShopSellerRepositoryImpl implements ShopSellerRepository {
  const ShopSellerRepositoryImpl({required this.remoteDataSource});

  final ShopSellerRemoteDataSource remoteDataSource;

  @override
  Future<PageResponse<ShopSeller>> getSellers({
    required String societyId,
    required PageableQuery pageable,
  }) {
    return remoteDataSource.getSellers(societyId: societyId, pageable: pageable);
  }
}
