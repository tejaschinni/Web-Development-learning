import 'package:society_seva/core/network/api_exception.dart';
import 'package:society_seva/features/shop/data/datasources/shop_cart_remote_data_source.dart';
import 'package:society_seva/features/shop/domain/entities/shop_cart.dart';
import 'package:society_seva/features/shop/domain/repositories/shop_cart_repository.dart';

class ShopCartRepositoryImpl implements ShopCartRepository {
  const ShopCartRepositoryImpl({required this.remoteDataSource});

  final ShopCartRemoteDataSource remoteDataSource;

  @override
  Future<ShopCart?> getCart() async {
    try {
      return await remoteDataSource.getCart();
    } on ApiException catch (error) {
      if (error.statusCode == 404) return null;
      rethrow;
    }
  }

  @override
  Future<ShopCart> addItem({
    required String listingId,
    required int quantity,
    required bool replaceExistingCart,
    String? foodServingSizeId,
  }) {
    return remoteDataSource.addItem(
      listingId: listingId,
      quantity: quantity,
      replaceExistingCart: replaceExistingCart,
      foodServingSizeId: foodServingSizeId,
    );
  }

  @override
  Future<ShopCart> updateItemQuantity({required String itemId, required int quantity}) {
    return remoteDataSource.updateItemQuantity(itemId: itemId, quantity: quantity);
  }

  @override
  Future<void> deleteItem(String itemId) => remoteDataSource.deleteItem(itemId);

  @override
  Future<void> deleteCart() => remoteDataSource.deleteCart();
}
