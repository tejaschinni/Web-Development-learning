import 'package:society_seva/features/shop/data/datasources/shop_category_local_datasource.dart';
import 'package:society_seva/features/shop/data/datasources/shop_category_remote_datasource.dart';
import 'package:society_seva/features/shop/domain/entities/shop_category.dart';
import 'package:society_seva/features/shop/domain/repositories/shop_category_repository.dart';

class ShopCategoryRepositoryImpl implements ShopCategoryRepository {
  ShopCategoryRepositoryImpl({required this._remoteDataSource, required this._localDataSource});

  final ShopCategoryRemoteDataSource _remoteDataSource;
  final ShopCategoryLocalDataSource _localDataSource;

  /// Categories are configuration data, so a 24-hour freshness window
  /// is sufficient for normal usage.
  static const Duration cacheDuration = Duration(hours: 1);

  @override
  Future<List<ShopCategory>> getCategories({bool forceRefresh = false}) async {
    if (forceRefresh) {
      return refreshCategories();
    }

    final cached = await getCachedCategories();

    if (cached != null) {
      return cached;
    }

    return refreshCategories();
  }

  @override
  Future<List<ShopCategory>?> getCachedCategories() async {
    return _localDataSource.getCategories();
  }

  @override
  Future<List<ShopCategory>> refreshCategories() async {
    final categories = await _remoteDataSource.fetchCategoryTree();

    await _localDataSource.saveCategories(categories);

    return categories;
  }

  @override
  Future<bool> isCacheStale() async {
    final fetchedAt = await _localDataSource.getFetchedAt();

    if (fetchedAt == null) {
      return true;
    }

    final age = DateTime.now().toUtc().difference(fetchedAt.toUtc());

    return age >= cacheDuration;
  }

  @override
  Future<ShopCategory> getCategoryById(String categoryId) async {
    return await _remoteDataSource.fetchCategoryById(categoryId);
  }
}
