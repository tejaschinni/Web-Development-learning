import 'package:society_seva/features/shop/data/models/shop_cart_item.dart';
import 'package:society_seva/features/shop/domain/entities/shop_cart.dart';

class CartSellerGroup {
  final String sellerId;
  final String sellerName;
  final List<CartItem> items;

  CartSellerGroup({required this.sellerId, required this.sellerName, required this.items});

  factory CartSellerGroup.fromCart(ShopCart cart) {
    final fallbackSellerId = cart.sellerId.length > 8
        ? cart.sellerId.substring(0, 8)
        : cart.sellerId;
    return CartSellerGroup(
      sellerId: cart.sellerId,
      sellerName: cart.sellerName.isNotEmpty == true
          ? cart.sellerName
          : 'Seller $fallbackSellerId',
      items: cart.items.map(CartItem.fromCartItem).toList(),
    );
  }
}

