// Screen projection over the listing summary and optional serving selection.
import 'package:society_seva/features/shop/domain/entities/shop_listing.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing_details.dart';

class ShopProduct {
  const ShopProduct({required this.listing, this.servingSize});

  final ShopListing listing;
  final ShopFoodServingSize? servingSize;

  String get id => listing.id;
  String get name => listing.title;
  String get variant => servingSize?.description ?? '';
  double get price => servingSize?.price ?? listing.basePrice;
  int? get originalPrice => null;
  String get description => listing.description;
  double get rating => listing.averageRating;
  int get reviewCount => listing.totalReviews;
  String get sellerId => listing.sellerId;
  String get sellerName => 'Seller';
  double get sellerRating => listing.averageRating;
  int get sellerReviewCount => listing.totalReviews;
  bool get isPopular => listing.sponsoredStatus.name == 'sponsored';
  bool get isVeg => false;
}
