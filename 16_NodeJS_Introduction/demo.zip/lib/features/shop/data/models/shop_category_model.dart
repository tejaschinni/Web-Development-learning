import 'package:society_seva/features/shop/domain/entities/shop_category.dart';
import 'package:society_seva/features/shop/domain/enums/shop_category_type.dart';

class ShopCategoryModel extends ShopCategory {
  const ShopCategoryModel({
    required super.id,
    super.parentCategoryId,
    required super.name,
    required super.slug,
    required super.categoryType,
    required super.requiresCertificate,
    required super.isActive,
    required super.displayOrder,
    required super.subCategories,
  });

  factory ShopCategoryModel.fromJson(Map<String, dynamic> json) {
    final rawSubCategories = json['subCategories'];

    final subCategories = rawSubCategories is List
        ? rawSubCategories
              .whereType<Map>()
              .map((item) => ShopCategoryModel.fromJson(Map<String, dynamic>.from(item)))
              .toList(growable: false)
        : const <ShopCategoryModel>[];

    return ShopCategoryModel(
      id: _requiredString(json['id']),
      parentCategoryId: _nullableString(json['parentCategoryId']),
      name: _requiredString(json['name']),
      slug: _requiredString(json['slug']),
      categoryType: ShopCategoryType.fromApiValue(_nullableString(json['categoryType'])),
      requiresCertificate: _boolValue(json['requiresCertificate']),
      isActive: _boolValue(json['isActive']),
      displayOrder: _intValue(json['displayOrder']),
      subCategories: subCategories,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'parentCategoryId': parentCategoryId,
      'name': name,
      'slug': slug,
      'categoryType': _categoryTypeToApiValue(categoryType),
      'requiresCertificate': requiresCertificate,
      'isActive': isActive,
      'displayOrder': displayOrder,
      'subCategories': subCategories
          .map((category) => ShopCategoryModel.fromEntity(category).toJson())
          .toList(growable: false),
    };
  }

  factory ShopCategoryModel.fromEntity(ShopCategory category) {
    return ShopCategoryModel(
      id: category.id,
      parentCategoryId: category.parentCategoryId,
      name: category.name,
      slug: category.slug,
      categoryType: category.categoryType,
      requiresCertificate: category.requiresCertificate,
      isActive: category.isActive,
      displayOrder: category.displayOrder,
      subCategories: category.subCategories
          .map(ShopCategoryModel.fromEntity)
          .toList(growable: false),
    );
  }

  static String _requiredString(dynamic value) {
    if (value is String && value.trim().isNotEmpty) {
      return value;
    }

    throw const FormatException('Invalid category response: required string is missing.');
  }

  static String? _nullableString(dynamic value) {
    if (value is String && value.trim().isNotEmpty) {
      return value;
    }

    return null;
  }

  static bool _boolValue(dynamic value) {
    if (value is bool) {
      return value;
    }

    return false;
  }

  static int _intValue(dynamic value) {
    if (value is int) {
      return value;
    }

    if (value is num) {
      return value.toInt();
    }

    if (value is String) {
      return int.tryParse(value) ?? 0;
    }

    return 0;
  }

  static String _categoryTypeToApiValue(ShopCategoryType type) {
    switch (type) {
      case ShopCategoryType.food:
        return 'FOOD';
      case ShopCategoryType.service:
        return 'SERVICE';
      case ShopCategoryType.product:
        return 'PRODUCT';
      case ShopCategoryType.unknown:
        return 'UNKNOWN';
    }
  }
}

class CategoryData {
  const CategoryData({required this.title, required this.icon});

  final String title;
  final List<List> icon;
}
