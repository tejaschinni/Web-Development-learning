import 'package:society_seva/features/shop/domain/entities/shop_cart.dart';

class CartItem {
  final String id;
  final String listingId;
  final String name;
  final String? variant;
  final double price;
  final double lineTotal;
  final int quantity;
  final bool isFood;

  const CartItem({
    required this.id,
    required this.listingId,
    required this.name,
    required this.variant,
    required this.price,
    required this.lineTotal,
    required this.quantity,
    required this.isFood,
  });

  factory CartItem.fromCartItem(ShopCartItem item) {
    final fallbackListingId = item.listingId.length > 8
        ? item.listingId.substring(0, 8)
        : item.listingId;
    return CartItem(
      id: item.id,
      listingId: item.listingId,
      name: item.listingName.isNotEmpty == true ? item.listingName : 'Listing $fallbackListingId',
      variant: null,
      price: item.unitPriceSnapshot,
      lineTotal: item.lineTotal,
      quantity: item.quantity,
      isFood: item.isFood,
    );
  }
}
