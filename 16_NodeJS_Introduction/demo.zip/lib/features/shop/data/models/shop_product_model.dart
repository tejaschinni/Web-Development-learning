class ShopProductModel {
  const ShopProductModel({
    required this.title,
    required this.seller,
    required this.price,
    required this.variant,
    required this.rating,
  });

  final String title;
  final String seller;
  final double price;
  final String variant;
  final double rating;
}
