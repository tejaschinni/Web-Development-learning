class ListingProduct {
  const ListingProduct({
    required this.title,
    required this.seller,
    required this.price,
    required this.unit,
    required this.rating,
  });

  final String title;
  final String seller;
  final double price;
  final String unit;
  final double rating;
}
