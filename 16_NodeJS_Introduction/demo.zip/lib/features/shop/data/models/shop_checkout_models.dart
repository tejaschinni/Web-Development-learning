class ShopDeliveryOptions {
  const ShopDeliveryOptions({
    required this.availableMethods,
    required this.pickupAvailable,
    required this.sellerDeliveryAvailable,
    required this.scheduleDeliveryAvailable,
    required this.nearbyEligible,
    this.pickupAddress,
    this.reason,
  });

  final List<String> availableMethods;
  final bool pickupAvailable;
  final bool sellerDeliveryAvailable;
  final bool scheduleDeliveryAvailable;
  final bool nearbyEligible;
  final String? pickupAddress;
  final String? reason;

  factory ShopDeliveryOptions.fromJson(Map<String, dynamic> json) => ShopDeliveryOptions(
    availableMethods: (json['availableMethods'] as List? ?? const [])
        .map((method) => method.toString())
        .toList(),
    pickupAvailable: json['pickupAvailable'] as bool? ?? false,
    sellerDeliveryAvailable: json['sellerDeliveryAvailable'] as bool? ?? false,
    scheduleDeliveryAvailable: json['scheduleDeliveryAvailable'] as bool? ?? false,
    nearbyEligible: json['nearbyEligible'] as bool? ?? false,
    pickupAddress: json['pickupAddress'] as String?,
    reason: json['reason'] as String?,
  );
}

class ShopOrderResult {
  const ShopOrderResult({
    required this.id,
    required this.orderNumber,
    required this.sellerId,
    required this.orderType,
    required this.orderStatus,
    required this.subtotalAmount,
    required this.totalAmount,
    required this.paymentStatus,
    required this.fulfillmentMethod,
    required this.items,
    this.discountAmount = 0,
    this.platformCommission = 0,
    this.welfareFundAmount = 0,
    this.sellerEarning = 0,
    this.sellerName,
    this.paymentMethod,
    this.scheduledAt,
    this.buyerNote,
    this.deliveryAddress,
    this.pickupAddress,
    this.deliveryInstructions,
    this.createdAt,
  });

  final String id;
  final String orderNumber;
  final String sellerId;
  final String orderType;
  final String orderStatus;
  final double subtotalAmount;
  final double totalAmount;
  final String paymentStatus;
  final String fulfillmentMethod;
  final List<ShopOrderResultItem> items;
  final double discountAmount;
  final double platformCommission;
  final double welfareFundAmount;
  final double sellerEarning;
  final String? sellerName;
  final String? paymentMethod;
  final String? scheduledAt;
  final String? buyerNote;
  final String? deliveryAddress;
  final String? pickupAddress;
  final String? deliveryInstructions;
  final String? createdAt;

  factory ShopOrderResult.fromJson(Map<String, dynamic> json) {
    final deliveryDetails = json['deliveryDetails'];
    final nestedDelivery = deliveryDetails is Map
        ? Map<String, dynamic>.from(deliveryDetails)
        : const <String, dynamic>{};
    return ShopOrderResult(
      id: json['id']?.toString() ?? '',
      orderNumber: json['orderNumber']?.toString() ?? '',
      sellerId: json['sellerId']?.toString() ?? '',
      orderType: json['orderType']?.toString() ?? '',
      orderStatus: json['orderStatus']?.toString() ?? '',
      subtotalAmount: (json['subtotalAmount'] as num?)?.toDouble() ?? 0,
      totalAmount: (json['totalAmount'] as num?)?.toDouble() ?? 0,
      paymentStatus: json['paymentStatus']?.toString() ?? '',
      fulfillmentMethod: json['fulfillmentMethod']?.toString() ?? '',
      items: (json['items'] as List? ?? const [])
          .whereType<Map>()
          .map((item) => ShopOrderResultItem.fromJson(Map<String, dynamic>.from(item)))
          .toList(),
      discountAmount: (json['discountAmount'] as num?)?.toDouble() ?? 0,
      platformCommission: (json['platformCommission'] as num?)?.toDouble() ?? 0,
      welfareFundAmount: (json['welfareFundAmount'] as num?)?.toDouble() ?? 0,
      sellerEarning: (json['sellerEarning'] as num?)?.toDouble() ?? 0,
      sellerName: json['sellerName']?.toString(),
      paymentMethod: json['paymentMethod']?.toString(),
      scheduledAt: json['scheduledAt']?.toString(),
      buyerNote: json['buyerNote']?.toString(),
      deliveryAddress: _orderAddressText(
        json['deliveryAddress'] ??
            json['deliveryAddressSnapshot'] ??
            nestedDelivery['deliveryAddress'],
      ),
      pickupAddress: _orderAddressText(
        json['pickupAddress'] ?? json['pickupAddressSnapshot'] ?? nestedDelivery['pickupAddress'],
      ),
      deliveryInstructions:
          json['deliveryInstructions']?.toString() ??
          nestedDelivery['deliveryInstructions']?.toString() ??
          json['buyerNote']?.toString(),
      createdAt: json['createdAt']?.toString(),
    );
  }

  int get itemCount => items.fold(0, (sum, item) => sum + item.quantity);

  bool get isActive => !const {
    'DELIVERED',
    'PICKED_UP',
    'COMPLETED',
    'CANCELLED',
    'CANCELED',
    'REJECTED',
  }.contains(orderStatus.toUpperCase());

  String get statusLabel => orderStatus
      .replaceAll('_', ' ')
      .toLowerCase()
      .split(' ')
      .map((part) => part.isEmpty ? part : '${part[0].toUpperCase()}${part.substring(1)}')
      .join(' ');
}

String? _orderAddressText(dynamic address) {
  if (address == null) return null;
  if (address is String) return address.trim().isEmpty ? null : address.trim();
  if (address is! Map) return null;
  final fields = Map<String, dynamic>.from(address);
  final parts =
      [
            fields['label'],
            fields['addressLine1'],
            fields['addressLine2'],
            fields['flatNumber'],
            fields['buildingName'],
            fields['city'],
            fields['pinCode'],
          ]
          .where((part) => part != null && part.toString().trim().isNotEmpty)
          .map((part) => part.toString());
  final text = parts.toSet().join(', ');
  return text.isEmpty ? null : text;
}

class ShopOrderResultItem {
  const ShopOrderResultItem({
    required this.id,
    required this.listingId,
    required this.title,
    required this.quantity,
    required this.unitPrice,
    required this.totalPrice,
  });

  final String id;
  final String listingId;
  final String title;
  final int quantity;
  final double unitPrice;
  final double totalPrice;

  factory ShopOrderResultItem.fromJson(Map<String, dynamic> json) => ShopOrderResultItem(
    id: json['id']?.toString() ?? '',
    listingId: json['listingId']?.toString() ?? '',
    title: json['titleSnapshot']?.toString() ?? '',
    quantity: (json['quantity'] as num?)?.toInt() ?? 0,
    unitPrice: (json['unitPrice'] as num?)?.toDouble() ?? 0,
    totalPrice: (json['totalPrice'] as num?)?.toDouble() ?? 0,
  );
}

class ShopPaymentResult {
  const ShopPaymentResult({
    required this.id,
    required this.orderId,
    required this.amount,
    required this.currency,
    required this.paymentStatus,
    required this.paymentMethod,
    required this.attemptNumber,
    required this.createdAt,
    this.paidAt,
    this.updatedAt,
  });

  final String id;
  final String orderId;
  final double amount;
  final String currency;
  final String paymentStatus;
  final String paymentMethod;
  final int attemptNumber;
  final String? createdAt;
  final String? paidAt;
  final String? updatedAt;

  factory ShopPaymentResult.fromJson(Map<String, dynamic> json) => ShopPaymentResult(
    id: json['id']?.toString() ?? '',
    orderId: json['orderId']?.toString() ?? '',
    amount: (json['amount'] as num?)?.toDouble() ?? 0,
    currency: json['currency']?.toString() ?? 'INR',
    paymentStatus: json['paymentStatus']?.toString() ?? '',
    paymentMethod: json['paymentMethod']?.toString() ?? '',
    attemptNumber: (json['attemptNumber'] as num?)?.toInt() ?? 0,
    createdAt: json['createdAt']?.toString(),
    paidAt: json['paidAt']?.toString(),
    updatedAt: json['updatedAt']?.toString(),
  );
}

class ShopOrderHistoryEntry {
  const ShopOrderHistoryEntry({
    required this.id,
    required this.orderId,
    required this.newStatus,
    required this.createdAt,
    this.oldStatus,
    this.note,
  });

  final String id;
  final String orderId;
  final String newStatus;
  final String? oldStatus;
  final String? note;
  final String? createdAt;

  factory ShopOrderHistoryEntry.fromJson(Map<String, dynamic> json) => ShopOrderHistoryEntry(
    id: json['id']?.toString() ?? '',
    orderId: json['orderId']?.toString() ?? '',
    newStatus: json['newStatus']?.toString() ?? '',
    oldStatus: json['oldStatus']?.toString(),
    note: json['note']?.toString(),
    createdAt: json['createdAt']?.toString(),
  );
}

class ShopDeliveryReceipt {
  const ShopDeliveryReceipt({
    required this.id,
    required this.orderId,
    required this.fulfillmentStatus,
    this.buyerConfirmedAt,
  });

  final String id;
  final String orderId;
  final String fulfillmentStatus;
  final String? buyerConfirmedAt;

  factory ShopDeliveryReceipt.fromJson(Map<String, dynamic> json) => ShopDeliveryReceipt(
    id: json['id']?.toString() ?? '',
    orderId: json['orderId']?.toString() ?? '',
    fulfillmentStatus: json['fulfillmentStatus']?.toString() ?? '',
    buyerConfirmedAt: json['buyerConfirmedAt']?.toString(),
  );
}
