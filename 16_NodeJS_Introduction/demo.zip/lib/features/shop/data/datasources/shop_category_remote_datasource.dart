import 'dart:convert';

import 'package:society_seva/core/mock/mock_data.dart';
import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/features/shop/data/models/shop_category_model.dart';

class ShopCategoryRemoteDataSource {
  ShopCategoryRemoteDataSource({required ApiClient apiClient}) : _apiClient = apiClient;

  final ApiClient _apiClient;

  Future<List<ShopCategoryModel>> fetchCategoryTree() async {
    try {
      final response = await _apiClient.get(ApiEndpoints.categoryTree);
      final data = response.data;
      if (data is List) {
        return data
            .whereType<Map>()
            .map((item) => ShopCategoryModel.fromJson(Map<String, dynamic>.from(item)))
            .toList(growable: false);
      }
    } catch (_) {}
    return MockData.shopCategoryTree;
  }

  Future<ShopCategoryModel> fetchCategoryById(String categoryId) async {
    try {
      final response = await _apiClient.get("${ApiEndpoints.allCategory}/$categoryId");
      final data = response.data;
      return ShopCategoryModel.fromJson(data);
    } catch (_) {
      return MockData.shopCategoryTree.firstWhere(
        (c) => c.id == categoryId,
        orElse: () => MockData.shopCategoryTree.first,
      );
    }
  }
}
