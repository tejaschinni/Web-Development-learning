import 'package:society_seva/core/mock/mock_data.dart';
import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/core/network/request_logger.dart';
import 'package:society_seva/features/shop/domain/entities/shop_cart.dart';
import 'package:society_seva/features/shop/domain/enums/shop_listing_type.dart';

class ShopCartRemoteDataSource {
  ShopCartRemoteDataSource({required this.apiClient});

  final ApiClient apiClient;
  ShopCart _cart = MockData.mockCart;

  Future<ShopCart> getCart() async {
    try {
      final response = await apiClient.get(ApiEndpoints.cart);
      _cart = ShopCart.fromJson(Map<String, dynamic>.from(response.data as Map));
      return _cart;
    } catch (_) {
      return _cart;
    }
  }

  Future<ShopCart> addItem({
    required String listingId,
    required int quantity,
    required bool replaceExistingCart,
    String? foodServingSizeId,
  }) async {
    final body = <String, dynamic>{
      'listingId': listingId,
      'quantity': quantity,
      'replaceExistingCart': replaceExistingCart ? 'true' : 'false',
      'foodServingSizeId': foodServingSizeId,
    };

    RequestLogger.logPost(
      endpoint: ApiEndpoints.cartItems,
      payload: body,
      method: 'POST',
    );

    try {
      final response = await apiClient.post(ApiEndpoints.cartItems, data: body);
      _cart = ShopCart.fromJson(Map<String, dynamic>.from(response.data as Map));
      return _cart;
    } catch (_) {
      final listing = MockData.shopListings.firstWhere(
        (l) => l.id == listingId,
        orElse: () => MockData.shopListings.first,
      );

      final items = List<ShopCartItem>.from(_cart.items);
      final existingIndex = items.indexWhere((i) => i.listingId == listingId);

      if (existingIndex != -1) {
        final existing = items[existingIndex];
        final newQuantity = existing.quantity + quantity;
        items[existingIndex] = ShopCartItem(
          id: existing.id,
          listingId: existing.listingId,
          quantity: newQuantity,
          unitPriceSnapshot: existing.unitPriceSnapshot,
          lineTotal: existing.unitPriceSnapshot * newQuantity,
          listingName: existing.listingName,
          sellerName: existing.sellerName,
          isFood: existing.isFood,
        );
      } else {
        items.add(
          ShopCartItem(
            id: 'cart_item_${DateTime.now().millisecondsSinceEpoch}',
            listingId: listingId,
            quantity: quantity,
            unitPriceSnapshot: listing.basePrice,
            lineTotal: listing.basePrice * quantity,
            listingName: listing.title,
            sellerName: 'Priya Homemade Delights & Crafts',
            isFood: listing.listingType == ShopListingType.food,
          ),
        );
      }

      final subtotal = items.fold<double>(0, (sum, item) => sum + item.lineTotal);
      _cart = ShopCart(
        id: _cart.id,
        buyerId: _cart.buyerId,
        sellerId: _cart.sellerId,
        sellerName: _cart.sellerName,
        status: 'ACTIVE',
        items: items,
        subtotal: subtotal,
      );
      return _cart;
    }
  }

  Future<ShopCart> updateItemQuantity({required String itemId, required int quantity}) async {
    try {
      final response = await apiClient.patch(
        ApiEndpoints.cartItem(itemId),
        data: {'quantity': quantity.toString()},
      );
      _cart = ShopCart.fromJson(Map<String, dynamic>.from(response.data as Map));
      return _cart;
    } catch (_) {
      final items = List<ShopCartItem>.from(_cart.items);
      final index = items.indexWhere((i) => i.id == itemId);
      if (index != -1) {
        if (quantity <= 0) {
          items.removeAt(index);
        } else {
          final existing = items[index];
          items[index] = ShopCartItem(
            id: existing.id,
            listingId: existing.listingId,
            quantity: quantity,
            unitPriceSnapshot: existing.unitPriceSnapshot,
            lineTotal: existing.unitPriceSnapshot * quantity,
            listingName: existing.listingName,
            sellerName: existing.sellerName,
            isFood: existing.isFood,
          );
        }
      }
      final subtotal = items.fold<double>(0, (sum, item) => sum + item.lineTotal);
      _cart = ShopCart(
        id: _cart.id,
        buyerId: _cart.buyerId,
        sellerId: _cart.sellerId,
        sellerName: _cart.sellerName,
        status: 'ACTIVE',
        items: items,
        subtotal: subtotal,
      );
      return _cart;
    }
  }

  Future<void> deleteItem(String itemId) async {
    try {
      await apiClient.delete(ApiEndpoints.cartItem(itemId));
    } catch (_) {
      final items = _cart.items.where((i) => i.id != itemId).toList();
      final subtotal = items.fold<double>(0, (sum, item) => sum + item.lineTotal);
      _cart = ShopCart(
        id: _cart.id,
        buyerId: _cart.buyerId,
        sellerId: _cart.sellerId,
        sellerName: _cart.sellerName,
        status: 'ACTIVE',
        items: items,
        subtotal: subtotal,
      );
    }
  }

  Future<void> deleteCart() async {
    try {
      await apiClient.delete(ApiEndpoints.cart);
    } catch (_) {
      _cart = ShopCart(
        id: _cart.id,
        buyerId: _cart.buyerId,
        sellerId: _cart.sellerId,
        sellerName: _cart.sellerName,
        status: 'EMPTY',
        items: const [],
        subtotal: 0,
      );
    }
  }
}
