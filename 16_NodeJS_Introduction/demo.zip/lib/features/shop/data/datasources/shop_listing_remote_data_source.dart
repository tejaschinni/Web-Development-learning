import 'package:society_seva/core/mock/mock_data.dart';
import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing_details.dart';

class ShopListingRemoteDataSource {
  const ShopListingRemoteDataSource({required this.apiClient});

  final ApiClient apiClient;

  Future<PageResponse<ShopListing>> getListings({
    required String societyId,
    required PageableQuery pageable,
  }) async {
    try {
      final response = await apiClient.get(
        ApiEndpoints.listings,
        queryParameters: {
          if (societyId.isNotEmpty) 'societyId': societyId,
          ...pageable.toQueryParameters(),
        },
      );

      return PageResponse.fromJson(
        Map<String, dynamic>.from(response.data as Map),
        ShopListing.fromJson,
      );
    } catch (_) {
      final list = MockData.shopListings;
      return PageResponse<ShopListing>(
        content: list,
        totalElements: list.length,
        totalPages: 1,
        size: 50,
        page: 0,
        first: true,
        last: true,
      );
    }
  }

  Future<PageResponse<ShopListing>> getCategoryListings({
    required String categoryId,
    required String societyId,
    required PageableQuery pageable,
  }) async {
    try {
      final response = await apiClient.get(
        ApiEndpoints.discoverListings(categoryId),
        queryParameters: {
          if (societyId.isNotEmpty) 'societyId': societyId,
          ...pageable.toQueryParameters(),
        },
      );

      return PageResponse.fromJson(
        Map<String, dynamic>.from(response.data as Map),
        ShopListing.fromJson,
      );
    } catch (_) {
      final list = MockData.shopListings.where((l) {
        return l.categoryId == categoryId || l.additionalCategoryIds.contains(categoryId);
      }).toList();
      final effectiveList = list.isEmpty ? MockData.shopListings : list;

      return PageResponse<ShopListing>(
        content: effectiveList,
        totalElements: effectiveList.length,
        totalPages: 1,
        size: 50,
        page: 0,
        first: true,
        last: true,
      );
    }
  }

  Future<ShopListing> getListing({required String listingId}) async {
    try {
      final response = await apiClient.get(ApiEndpoints.listing(listingId));
      return ShopListing.fromJson(Map<String, dynamic>.from(response.data as Map));
    } catch (_) {
      return MockData.shopListings.firstWhere(
        (l) => l.id == listingId,
        orElse: () => MockData.shopListings.first,
      );
    }
  }

  Future<PageResponse<ShopListing>> getSellerListings({
    required String sellerId,
    required PageableQuery pageable,
  }) async {
    try {
      final response = await apiClient.get(
        ApiEndpoints.sellerListings(sellerId),
        queryParameters: pageable.toQueryParameters(),
      );
      return PageResponse.fromJson(
        Map<String, dynamic>.from(response.data as Map),
        ShopListing.fromJson,
      );
    } catch (_) {
      final list = MockData.shopListings;
      return PageResponse<ShopListing>(
        content: list,
        totalElements: list.length,
        totalPages: 1,
        size: 50,
        page: 0,
        first: true,
        last: true,
      );
    }
  }

  Future<List<ShopListingImage>> getListingImages(String listingId) async {
    try {
      final response = await apiClient.get(ApiEndpoints.listingImages(listingId));
      final images = response.data as List<dynamic>? ?? const [];
      return images
          .whereType<Map>()
          .map((image) => ShopListingImage.fromJson(Map<String, dynamic>.from(image)))
          .toList()
        ..sort((a, b) => a.displayOrder.compareTo(b.displayOrder));
    } catch (_) {
      return MockData.listingImages
          .where((img) => img.listingId == listingId)
          .map(
            (img) => ShopListingImage(
              id: img.id,
              listingId: img.listingId,
              imageUrl: img.imageUrl,
              moderationStatus: img.moderationStatus,
              displayOrder: img.displayOrder,
              createdAt: img.createdAt,
            ),
          )
          .toList();
    }
  }

  Future<ShopFoodDetails> getFoodDetails(String listingId) async {
    try {
      final response = await apiClient.get(ApiEndpoints.listingFoodDetails(listingId));
      return ShopFoodDetails.fromJson(Map<String, dynamic>.from(response.data as Map));
    } catch (_) {
      final food = MockData.foodDetails;
      return ShopFoodDetails(
        id: food.id,
        listingId: listingId,
        preparationTime: DateTime.now().add(const Duration(minutes: 45)),
        spiceLevel: food.spiceLevel ?? 2,
        spiceLevelText: food.spiceLevelText ?? 'Medium',
        freshnessDeclaration: food.freshnessDeclaration ?? 'Freshly prepared',
        isFrozenItem: food.isFrozenItem ?? false,
        fssaiRequired: food.fssaiRequired ?? true,
        servingSizes: food.servingSizes
            .map(
              (s) => ShopFoodServingSize(
                id: s.id,
                sizeValue: s.sizeValue.toDouble(),
                sizeUnit: s.sizeUnit,
                description: s.description,
                price: s.price.toDouble(),
                quantityAvailable: s.quantityAvailable,
                isAvailable: s.isAvailable,
              ),
            )
            .toList(),
      );
    }
  }

  Future<ShopServiceDetails> getServiceDetails(String listingId) async {
    try {
      final response = await apiClient.get(ApiEndpoints.listingServiceDetails(listingId));
      return ShopServiceDetails.fromJson(Map<String, dynamic>.from(response.data as Map));
    } catch (_) {
      final s = MockData.serviceDetails;
      return ShopServiceDetails(
        id: s.id,
        listingId: listingId,
        serviceDurationMinutes: s.serviceDurationMinutes ?? 120,
        serviceLocationType: s.serviceLocationType ?? 'BUYER_LOCATION',
        homeVisitAvailable: s.homeVisitAvailable ?? true,
        onlineAvailable: s.onlineAvailable ?? false,
        certificateRequired: s.certificateRequired ?? false,
        requiredMaterials: s.requiredMaterials,
        cancellationPolicy: s.cancellationPolicy,
      );
    }
  }

  Future<List<DateTime>> getServiceAvailableDates({
    required String listingId,
    required String from,
    required String to,
  }) async {
    try {
      final response = await apiClient.get(
        ApiEndpoints.serviceScheduleDates(listingId),
        queryParameters: {'from': from, 'to': to},
      );
      final dates = response.data;
      if (dates is List) {
        return dates
            .whereType<String>()
            .map(DateTime.tryParse)
            .whereType<DateTime>()
            .map((date) => DateTime(date.year, date.month, date.day))
            .toList();
      }
    } catch (_) {}
    return [
      DateTime.now(),
      DateTime.now().add(const Duration(days: 1)),
      DateTime.now().add(const Duration(days: 2)),
    ];
  }

  Future<List<ServiceScheduleSlot>> getServiceAvailableSlots({
    required String listingId,
    required String date,
  }) async {
    try {
      final response = await apiClient.get(
        ApiEndpoints.serviceScheduleSlots(listingId),
        queryParameters: {'date': date},
      );
      final slots = response.data;
      if (slots is List) {
        return slots
            .whereType<Map>()
            .map((slot) => ServiceScheduleSlot.fromJson(Map<String, dynamic>.from(slot)))
            .where((slot) => slot.isAvailable)
            .toList()
          ..sort((first, second) => first.startsAt.compareTo(second.startsAt));
      }
    } catch (_) {}
    return MockData.serviceSlots
        .map(
          (s) => ServiceScheduleSlot(
            startsAt: s.startsAt,
            endsAt: s.endsAt,
            durationMinutes: s.durationMinutes,
            timeZone: s.timeZone,
            status: s.status,
          ),
        )
        .toList();
  }
}
