import 'package:society_seva/core/mock/mock_data.dart';
import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/core/network/request_logger.dart';
import 'package:society_seva/features/shop/data/models/shop_checkout_models.dart';

class ShopCheckoutRemoteDataSource {
  const ShopCheckoutRemoteDataSource({required this.apiClient});

  final ApiClient apiClient;

  Future<ShopDeliveryOptions> getDeliveryOptions({
    required String sellerId,
    String? addressId,
    String? orderType,
  }) async {
    try {
      final response = await apiClient.get(
        ApiEndpoints.deliveryOptions,
        queryParameters: {
          'sellerId': sellerId,
          if (addressId != null && addressId.isNotEmpty) 'addressId': addressId,
          if (orderType != null && orderType.isNotEmpty) 'orderType': orderType,
        },
      );
      return ShopDeliveryOptions.fromJson(Map<String, dynamic>.from(response.data as Map));
    } catch (_) {
      return MockData.deliveryOptions;
    }
  }

  Future<ShopOrderResult> checkoutOrder({
    required String cartId,
    required String fulfillmentMethod,
    String? deliveryAddressId,
    DateTime? scheduledAt,
    String? buyerNote,
  }) async {
    final payload = {
      'fulfillmentMethod': fulfillmentMethod,
      if (deliveryAddressId != null && deliveryAddressId.isNotEmpty)
        'deliveryAddressId': deliveryAddressId,
      if (scheduledAt != null) 'scheduledAt': scheduledAt.toUtc().toIso8601String(),
      if (buyerNote != null && buyerNote.trim().isNotEmpty) 'buyerNote': buyerNote.trim(),
    };

    RequestLogger.logPost(
      endpoint: ApiEndpoints.checkoutOrder,
      payload: payload,
      queryParameters: {'cartId': cartId},
      method: 'POST',
    );

    try {
      final response = await apiClient.post(
        ApiEndpoints.checkoutOrder,
        queryParameters: {'cartId': cartId},
        data: payload,
      );
      return ShopOrderResult.fromJson(Map<String, dynamic>.from(response.data as Map));
    } catch (_) {
      return ShopOrderResult(
        id: 'ord_${DateTime.now().millisecondsSinceEpoch}',
        orderNumber: 'SS-ORD-${DateTime.now().millisecondsSinceEpoch.toString().substring(7)}',
        sellerId: MockData.sellerId,
        sellerName: 'Priya Homemade Delights & Crafts',
        orderType: 'FOOD',
        orderStatus: 'PAID',
        subtotalAmount: MockData.mockCart.subtotal,
        totalAmount: MockData.mockCart.subtotal,
        paymentStatus: 'PENDING',
        fulfillmentMethod: fulfillmentMethod,
        items: MockData.mockCart.items
            .map(
              (i) => ShopOrderResultItem(
                id: i.id,
                listingId: i.listingId,
                title: i.listingName,
                quantity: i.quantity,
                unitPrice: i.unitPriceSnapshot,
                totalPrice: i.lineTotal,
              ),
            )
            .toList(),
        createdAt: DateTime.now().toIso8601String(),
        deliveryAddress: 'Flat 402, Tower B, Green Valley Heights',
      );
    }
  }

  Future<ShopPaymentResult> createCashPayment({required String orderId}) async {
    final payload = {'orderId': orderId, 'paymentMethod': 'CASH'};
    RequestLogger.logPost(
      endpoint: ApiEndpoints.payments,
      payload: payload,
      method: 'POST',
    );

    try {
      final response = await apiClient.post(
        ApiEndpoints.payments,
        data: payload,
      );
      return ShopPaymentResult.fromJson(Map<String, dynamic>.from(response.data as Map));
    } catch (_) {
      return ShopPaymentResult(
        id: 'pay_${DateTime.now().millisecondsSinceEpoch}',
        orderId: orderId,
        paymentMethod: 'CASH',
        paymentStatus: 'SUCCESS',
        amount: 440.0,
        currency: 'INR',
        attemptNumber: 1,
        createdAt: DateTime.now().toIso8601String(),
      );
    }
  }

  Future<ShopPaymentResult> getPayment(String paymentId) async {
    try {
      final response = await apiClient.get(ApiEndpoints.payment(paymentId));
      return ShopPaymentResult.fromJson(Map<String, dynamic>.from(response.data as Map));
    } catch (_) {
      return ShopPaymentResult(
        id: paymentId,
        orderId: 'ord_001',
        paymentMethod: 'UPI',
        paymentStatus: 'SUCCESS',
        amount: 300.0,
        currency: 'INR',
        attemptNumber: 1,
        createdAt: DateTime.now().subtract(const Duration(hours: 1)).toIso8601String(),
      );
    }
  }

  Future<List<ShopOrderResult>> getMyOrders() async {
    try {
      final orders = <ShopOrderResult>[];
      var pageNumber = 0;
      while (true) {
        final response = await apiClient.get(
          ApiEndpoints.myOrders,
          queryParameters: {'page': pageNumber, 'size': 50},
        );
        if (response.data is List) {
          orders.addAll(
            (response.data as List).whereType<Map>().map(
              (order) => ShopOrderResult.fromJson(Map<String, dynamic>.from(order)),
            ),
          );
          return orders;
        }
        final page = PageResponse.fromJson(
          Map<String, dynamic>.from(response.data as Map),
          ShopOrderResult.fromJson,
        );
        orders.addAll(page.content);
        if (page.last || page.content.isEmpty) return orders;
        pageNumber++;
      }
    } catch (_) {
      return MockData.shopMyOrders;
    }
  }

  Future<List<ShopPaymentResult>> getMyPayments() async {
    try {
      final payments = <ShopPaymentResult>[];
      var pageNumber = 0;
      while (true) {
        final response = await apiClient.get(
          ApiEndpoints.myPayments,
          queryParameters: {'page': pageNumber, 'size': 50},
        );
        if (response.data is List) {
          payments.addAll(
            (response.data as List).whereType<Map>().map(
              (payment) => ShopPaymentResult.fromJson(Map<String, dynamic>.from(payment)),
            ),
          );
          return payments;
        }
        final page = PageResponse.fromJson(
          Map<String, dynamic>.from(response.data as Map),
          ShopPaymentResult.fromJson,
        );
        payments.addAll(page.content);
        if (page.last || page.content.isEmpty) return payments;
        pageNumber++;
      }
    } catch (_) {
      return [
        ShopPaymentResult(
          id: 'pay_001',
          orderId: 'ord_001',
          paymentMethod: 'ONLINE',
          paymentStatus: 'SUCCESS',
          amount: 300.0,
          currency: 'INR',
          attemptNumber: 1,
          createdAt: DateTime.now().subtract(const Duration(minutes: 25)).toIso8601String(),
        ),
      ];
    }
  }

  Future<List<ShopOrderHistoryEntry>> getOrderHistory(String orderId) async {
    try {
      final response = await apiClient.get(ApiEndpoints.orderStatusHistory(orderId));
      return (response.data as List)
          .whereType<Map>()
          .map((entry) => ShopOrderHistoryEntry.fromJson(Map<String, dynamic>.from(entry)))
          .toList();
    } catch (_) {
      return [
        ShopOrderHistoryEntry(
          id: 'hist_1',
          orderId: orderId,
          oldStatus: 'CREATED',
          newStatus: 'PAID',
          note: 'Payment received',
          createdAt: DateTime.now().subtract(const Duration(minutes: 25)).toIso8601String(),
        ),
        ShopOrderHistoryEntry(
          id: 'hist_2',
          orderId: orderId,
          oldStatus: 'PAID',
          newStatus: 'ACCEPTED',
          note: 'Order accepted by seller',
          createdAt: DateTime.now().subtract(const Duration(minutes: 20)).toIso8601String(),
        ),
      ];
    }
  }

  Future<ShopDeliveryReceipt> confirmReceipt(String orderId) async {
    final payload = {'orderId': orderId};
    RequestLogger.logPost(
      endpoint: ApiEndpoints.confirmOrderReceipt(orderId),
      payload: payload,
      method: 'POST',
    );

    try {
      final response = await apiClient.post(ApiEndpoints.confirmOrderReceipt(orderId));
      return ShopDeliveryReceipt.fromJson(Map<String, dynamic>.from(response.data as Map));
    } catch (_) {
      return ShopDeliveryReceipt(
        id: 'rec_${DateTime.now().millisecondsSinceEpoch}',
        orderId: orderId,
        fulfillmentStatus: 'DELIVERED',
        buyerConfirmedAt: DateTime.now().toIso8601String(),
      );
    }
  }
}
