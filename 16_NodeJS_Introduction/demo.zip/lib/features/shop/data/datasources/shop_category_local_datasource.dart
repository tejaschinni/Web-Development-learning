import 'package:society_seva/core/mock/mock_data.dart';
import 'package:society_seva/core/storage/local_cache.dart';
import 'package:society_seva/features/shop/data/models/shop_category_model.dart';

class ShopCategoryLocalDataSource {
  ShopCategoryLocalDataSource({required this._localCache});

  final LocalCache _localCache;

  static const String _cacheKey = 'shop:categories:tree';

  Future<List<ShopCategoryModel>?> getCategories() async {
    final cached = await _localCache.readJson(_cacheKey);

    if (cached == null) {
      return MockData.shopCategoryTree;
    }

    final categoriesJson = cached['categories'];

    if (categoriesJson is! List) {
      return null;
    }

    try {
      return categoriesJson
          .whereType<Map>()
          .map(
            (item) =>
                ShopCategoryModel.fromJson(Map<String, dynamic>.from(item)),
          )
          .toList(growable: false);
    } on FormatException {
      return null;
    }
  }

  Future<DateTime?> getFetchedAt() async {
    final cached = await _localCache.readJson(_cacheKey);

    if (cached == null) {
      return null;
    }

    final value = cached['fetchedAt'];

    if (value is! String || value.isEmpty) {
      return null;
    }

    return DateTime.tryParse(value);
  }

  Future<void> saveCategories(List<ShopCategoryModel> categories) async {
    await _localCache.writeJson(_cacheKey, {
      'fetchedAt': DateTime.now().toUtc().toIso8601String(),
      'categories': categories
          .map((category) => category.toJson())
          .toList(growable: false),
    });
  }

  Future<void> clearCategories() async {
    await _localCache.delete(_cacheKey);
  }
}
