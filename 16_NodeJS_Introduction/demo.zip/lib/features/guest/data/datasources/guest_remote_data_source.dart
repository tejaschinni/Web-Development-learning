import 'package:society_seva/core/mock/mock_data.dart';
import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/core/network/request_logger.dart';
import 'package:society_seva/features/guest/data/models/guest_session.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing.dart';

class GuestRemoteDataSource {
  const GuestRemoteDataSource({required this.apiClient});

  final ApiClient apiClient;

  Future<GuestSession> startSession(GuestSessionRequest request) async {
    RequestLogger.logPost(
      endpoint: ApiEndpoints.guestSession,
      payload: request.toJson(),
      method: 'POST',
    );

    try {
      final response = await apiClient.post(ApiEndpoints.guestSession, data: request.toJson());
      return GuestSession.fromJson(Map<String, dynamic>.from(response.data as Map));
    } catch (_) {
      return MockData.guestSession;
    }
  }

  Future<PageResponse<ShopListing>> getListings({
    String? societyId,
    String? query,
    String? categoryId,
    String? listingType,
    required PageableQuery pageable,
  }) async {
    try {
      final response = await apiClient.get(
        ApiEndpoints.guestListings,
        queryParameters: {
          if (societyId != null && societyId.isNotEmpty) 'societyId': societyId,
          if (query != null && query.isNotEmpty) 'query': query,
          if (categoryId != null && categoryId.isNotEmpty) 'categoryId': categoryId,
          if (listingType != null && listingType.isNotEmpty) 'listingType': listingType,
          ...pageable.toQueryParameters(),
        },
      );
      return PageResponse.fromJson(Map<String, dynamic>.from(response.data as Map), _listingFromJson);
    } catch (_) {
      final list = MockData.shopListings.where((l) {
        if (query != null && query.isNotEmpty) {
          return l.title.toLowerCase().contains(query.toLowerCase());
        }
        if (categoryId != null && categoryId.isNotEmpty) {
          return l.categoryId == categoryId || l.additionalCategoryIds.contains(categoryId);
        }
        return true;
      }).toList();

      return PageResponse<ShopListing>(
        content: list.isEmpty ? MockData.shopListings : list,
        totalElements: list.isEmpty ? MockData.shopListings.length : list.length,
        totalPages: 1,
        size: 50,
        page: 0,
        first: true,
        last: true,
      );
    }
  }

  Future<ShopListing> getListing(String listingId) async {
    try {
      final response = await apiClient.get(ApiEndpoints.guestListing(listingId));
      return _listingFromJson(Map<String, dynamic>.from(response.data as Map));
    } catch (_) {
      return MockData.shopListings.firstWhere(
        (l) => l.id == listingId,
        orElse: () => MockData.shopListings.first,
      );
    }
  }

  Future<List<ShopListing>> getTrending({String? societyId, int limit = 10}) async {
    try {
      final response = await apiClient.get(
        ApiEndpoints.guestTrending,
        queryParameters: {
          if (societyId != null && societyId.isNotEmpty) 'societyId': societyId,
          'limit': limit,
        },
      );
      final data = response.data;
      if (data is List) {
        return data.whereType<Map>().map((entry) {
          final listing = entry['listing'];
          return _listingFromJson(Map<String, dynamic>.from(listing is Map ? listing : entry));
        }).toList();
      }
    } catch (_) {}
    return MockData.shopListings.take(limit).toList();
  }

  Future<void> recordSearch({
    required String searchQuery,
    String? category,
    double? latitude,
    double? longitude,
    required int resultCount,
  }) async {
    final payload = {
      'searchQuery': searchQuery,
      'category': category,
      'latitude': latitude,
      'longitude': longitude,
      'resultCount': resultCount,
    };
    RequestLogger.logPost(
      endpoint: ApiEndpoints.guestSearchActivity,
      payload: payload,
      method: 'POST',
    );

    try {
      await apiClient.post(
        ApiEndpoints.guestSearchActivity,
        data: payload,
      );
    } catch (_) {}
  }

  Future<void> recordView({required String listingId, required bool isTrending}) async {
    final payload = {'listingId': listingId, 'isTrending': isTrending};
    RequestLogger.logPost(
      endpoint: ApiEndpoints.guestViewActivity,
      payload: payload,
      method: 'POST',
    );

    try {
      await apiClient.post(
        ApiEndpoints.guestViewActivity,
        data: payload,
      );
    } catch (_) {}
  }

  static ShopListing _listingFromJson(Map<String, dynamic> json) {
    return ShopListing.fromJson({
      ...json,
      'id': json['listingId'] ?? json['id'],
      'title': json['title'] ?? json['name'],
      'approvalStatus': json['approvalStatus'] ?? 'APPROVED',
      'availabilityStatus': json['availabilityStatus'] ?? 'AVAILABLE',
    });
  }
}
