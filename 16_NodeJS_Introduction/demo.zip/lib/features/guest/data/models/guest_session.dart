import 'package:flutter/foundation.dart';

@immutable
class GuestSessionRequest {
  const GuestSessionRequest({
    required this.deviceId,
    this.latitude,
    this.longitude,
    this.city,
    this.pinCode,
    this.fcmToken,
    this.deviceModel,
    this.osVersion,
    this.appVersion,
    this.societyId,
  });

  final String deviceId;
  final double? latitude;
  final double? longitude;
  final String? city;
  final String? pinCode;
  final String? fcmToken;
  final String? deviceModel;
  final String? osVersion;
  final String? appVersion;
  final String? societyId;

  Map<String, dynamic> toJson() => {
    'deviceId': deviceId,
    if (latitude != null) 'latitude': latitude,
    if (longitude != null) 'longitude': longitude,
    if (city != null) 'city': city,
    if (pinCode != null) 'pinCode': pinCode,
    if (fcmToken != null) 'fcmToken': fcmToken,
    if (deviceModel != null) 'deviceModel': deviceModel,
    if (osVersion != null) 'osVersion': osVersion,
    if (appVersion != null) 'appVersion': appVersion,
    if (societyId != null) 'societyId': societyId,
  };
}

@immutable
class GuestSession {
  const GuestSession({
    required this.guestId,
    required this.accessToken,
    required this.tokenType,
    required this.expiresIn,
    this.nearestSocietyId,
    this.sessionTime,
  });

  final String guestId;
  final String accessToken;
  final String tokenType;
  final int expiresIn;
  final String? nearestSocietyId;
  final DateTime? sessionTime;

  factory GuestSession.fromJson(Map<String, dynamic> json) => GuestSession(
    guestId: json['guestId']?.toString() ?? '',
    accessToken: json['accessToken']?.toString() ?? '',
    tokenType: json['tokenType']?.toString() ?? 'Bearer',
    expiresIn: (json['expiresIn'] as num?)?.toInt() ?? 0,
    nearestSocietyId: json['nearestSocietyId']?.toString(),
    sessionTime: DateTime.tryParse(json['sessionTime']?.toString() ?? ''),
  );
}
