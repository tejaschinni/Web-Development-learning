import 'dart:math';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/core/providers/app_providers.dart';
import 'package:society_seva/core/storage/secure_storage.dart';
import 'package:society_seva/features/guest/data/datasources/guest_remote_data_source.dart';
import 'package:society_seva/features/guest/data/models/guest_session.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing.dart';

final guestRemoteDataSourceProvider = Provider<GuestRemoteDataSource>((ref) {
  return GuestRemoteDataSource(apiClient: ref.watch(apiClientProvider));
});

final guestAccessProvider = StateNotifierProvider<GuestAccessController, GuestAccessState>((ref) {
  return GuestAccessController(ref);
});

class GuestAccessState {
  const GuestAccessState({this.isLoading = false, this.session});

  final bool isLoading;
  final GuestSession? session;

  bool get isActive => session != null;
}

class GuestAccessController extends StateNotifier<GuestAccessState> {
  GuestAccessController(this._ref) : super(const GuestAccessState());

  final Ref _ref;

  Future<GuestSession> startSession() async {
    state = const GuestAccessState(isLoading: true);
    try {
      final storage = AppSecureStorage();
      var deviceId = await storage.readGuestDeviceId();
      if (deviceId == null || deviceId.isEmpty) {
        deviceId = _newDeviceId();
        await storage.saveGuestDeviceId(deviceId);
      }

      final location = await _availableLocation();
      final request = GuestSessionRequest(
        deviceId: deviceId,
        latitude: location.latitude,
        longitude: location.longitude,
        city: location.city,
        pinCode: location.pinCode,
        appVersion: const String.fromEnvironment('APP_VERSION', defaultValue: '1.0.0+1'),
      );
      final session = await _ref.read(guestRemoteDataSourceProvider).startSession(request);
      if (session.accessToken.isEmpty || session.guestId.isEmpty) {
        throw const FormatException('Guest session response is missing its identity or token.');
      }

      await storage.saveGuestSession(accessToken: session.accessToken, guestId: session.guestId);
      state = GuestAccessState(session: session);
      return session;
    } catch (_) {
      state = const GuestAccessState();
      rethrow;
    }
  }

  Future<void> endSession() async {
    await AppSecureStorage().clearGuestSession();
    state = const GuestAccessState();
  }

  String _newDeviceId() {
    final random = Random.secure();
    final segments = List.generate(4, (_) => random.nextInt(0x100000000).toRadixString(16));
    return 'guest-${segments.join('-')}';
  }

  Future<({double? latitude, double? longitude, String? city, String? pinCode})>
  _availableLocation() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        return (latitude: null, longitude: null, city: null, pinCode: null);
      }
      final permission = await Geolocator.checkPermission();
      if (permission != LocationPermission.whileInUse && permission != LocationPermission.always) {
        return (latitude: null, longitude: null, city: null, pinCode: null);
      }
      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.medium,
          timeLimit: Duration(seconds: 4),
        ),
      );
      final placemarks = await Geocoding().placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      );
      final place = placemarks.firstOrNull;
      final city = [place?.locality, place?.subAdministrativeArea, place?.administrativeArea]
          .whereType<String>()
          .map((value) => value.trim())
          .firstWhere((value) => value.isNotEmpty, orElse: () => '');
      return (
        latitude: position.latitude,
        longitude: position.longitude,
        city: city.isEmpty ? null : city,
        pinCode: place?.postalCode,
      );
    } catch (_) {
      return (latitude: null, longitude: null, city: null, pinCode: null);
    }
  }
}

final guestListingsProvider =
    FutureProvider.family<
      PageResponse<ShopListing>,
      ({
        String? societyId,
        String? query,
        String? categoryId,
        String? listingType,
        int page,
        int size,
      })
    >((ref, args) {
      return ref
          .watch(guestRemoteDataSourceProvider)
          .getListings(
            societyId: args.societyId,
            query: args.query,
            categoryId: args.categoryId,
            listingType: args.listingType,
            pageable: PageableQuery(page: args.page, size: args.size),
          );
    });

final guestListingProvider =
    FutureProvider.family<ShopListing, ({String listingId, bool isTrending})>((ref, args) async {
      final dataSource = ref.watch(guestRemoteDataSourceProvider);
      final listing = await dataSource.getListing(args.listingId);
      await dataSource.recordView(listingId: args.listingId, isTrending: args.isTrending);
      return listing;
    });

final guestTrendingProvider =
    FutureProvider.family<List<ShopListing>, ({String? societyId, int limit})>(
      (ref, args) => ref
          .watch(guestRemoteDataSourceProvider)
          .getTrending(societyId: args.societyId, limit: args.limit),
    );
