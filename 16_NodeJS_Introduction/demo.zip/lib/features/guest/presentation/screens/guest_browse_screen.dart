import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/guest/presentation/providers/guest_provider.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing.dart';

class GuestBrowseScreen extends ConsumerStatefulWidget {
  const GuestBrowseScreen({super.key, this.societyId});

  final String? societyId;

  @override
  ConsumerState<GuestBrowseScreen> createState() => _GuestBrowseScreenState();
}

class _GuestBrowseScreenState extends ConsumerState<GuestBrowseScreen> {
  final _searchController = TextEditingController();
  List<ShopListing>? _searchResults;
  bool _isSearching = false;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _search() async {
    final query = _searchController.text.trim();
    if (query.isEmpty) {
      setState(() => _searchResults = null);
      return;
    }

    setState(() => _isSearching = true);
    try {
      final page = await ref
          .read(guestRemoteDataSourceProvider)
          .getListings(
            societyId: widget.societyId,
            query: query,
            pageable: const PageableQuery(page: 0, size: 20),
          );
      await ref
          .read(guestRemoteDataSourceProvider)
          .recordSearch(searchQuery: query, resultCount: page.content.length);
      if (!mounted) return;
      setState(() => _searchResults = page.content);
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Search failed: $error')));
    } finally {
      if (mounted) setState(() => _isSearching = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final listings = ref.watch(
      guestListingsProvider((
        societyId: widget.societyId,
        query: null,
        categoryId: null,
        listingType: null,
        page: 0,
        size: 20,
      )),
    );
    final trending = ref.watch(guestTrendingProvider((societyId: widget.societyId, limit: 10)));
    final isShowingSearch = _searchResults != null;

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAF7),
      appBar: AppBar(
        title: Text('Explore as guest', style: GoogleFonts.hind(fontWeight: FontWeight.w700)),
        actions: [TextButton(onPressed: () => context.go('/login'), child: const Text('Sign in'))],
      ),
      body: SafeArea(
        top: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
              child: TextField(
                controller: _searchController,
                textInputAction: TextInputAction.search,
                onSubmitted: (_) => _search(),
                decoration: InputDecoration(
                  hintText: 'Search products and services',
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: IconButton(
                    tooltip: 'Search',
                    onPressed: _isSearching ? null : _search,
                    icon: _isSearching
                        ? const SizedBox.square(
                            dimension: 20,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.arrow_forward),
                  ),
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                ),
              ),
            ),
            Expanded(
              child: isShowingSearch
                  ? SingleChildScrollView(
                      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                      child: _ListingResults(
                        listings: _searchResults!,
                        emptyText: 'No matching listings',
                      ),
                    )
                  : RefreshIndicator(
                      onRefresh: () async {
                        ref.invalidate(
                          guestListingsProvider((
                            societyId: widget.societyId,
                            query: null,
                            categoryId: null,
                            listingType: null,
                            page: 0,
                            size: 20,
                          )),
                        );
                        ref.invalidate(
                          guestTrendingProvider((societyId: widget.societyId, limit: 10)),
                        );
                      },
                      child: ListView(
                        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                        children: [
                          _Section(
                            title: 'Trending near you',
                            child: trending.when(
                              loading: () => const _LoadingRow(),
                              error: (error, stack) => _RetryText(
                                message: 'Trending items unavailable',
                                onRetry: () => ref.invalidate(
                                  guestTrendingProvider((societyId: widget.societyId, limit: 10)),
                                ),
                              ),
                              data: (items) => items.isEmpty
                                  ? const Text('No trending items yet')
                                  : _HorizontalListings(items: items),
                            ),
                          ),
                          const Gap(24),
                          _Section(
                            title: 'Published listings',
                            child: listings.when(
                              loading: () => const _LoadingRow(),
                              error: (error, stack) => _RetryText(
                                message: 'Listings unavailable',
                                onRetry: () => ref.invalidate(
                                  guestListingsProvider((
                                    societyId: widget.societyId,
                                    query: null,
                                    categoryId: null,
                                    listingType: null,
                                    page: 0,
                                    size: 20,
                                  )),
                                ),
                              ),
                              data: (page) => page.content.isEmpty
                                  ? const Text('No published listings yet')
                                  : _ListingResults(listings: page.content),
                            ),
                          ),
                          const Gap(20),
                          const Text(
                            'Browsing only. Sign in to contact sellers, book services, or purchase items.',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Color(0xFF647067)),
                          ),
                        ],
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class GuestListingDetailsScreen extends ConsumerWidget {
  const GuestListingDetailsScreen({super.key, required this.listingId, this.isTrending = false});

  final String listingId;
  final bool isTrending;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final args = (listingId: listingId, isTrending: isTrending);
    final listing = ref.watch(guestListingProvider(args));
    return Scaffold(
      appBar: AppBar(title: const Text('Listing details')),
      body: listing.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, stack) => Center(
          child: TextButton.icon(
            onPressed: () => ref.invalidate(guestListingProvider(args)),
            icon: const Icon(Icons.refresh),
            label: const Text('Unable to load listing'),
          ),
        ),
        data: (item) => ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Container(
              height: 220,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: const Color(0xFFE7F0E8),
                borderRadius: BorderRadius.circular(18),
              ),
              child: Icon(
                item.listingType.isService ? Icons.home_repair_service : Icons.storefront,
                size: 68,
                color: const Color(0xFF287148),
              ),
            ),
            const Gap(20),
            Text(item.title, style: Theme.of(context).textTheme.headlineSmall),
            const Gap(8),
            Text(_price(item), style: Theme.of(context).textTheme.titleLarge),
            const Gap(8),
            Text('${item.availabilityStatus.name} · ${item.listingType.name}'),
            if (item.quantityAvailable != null) ...[
              const Gap(6),
              Text('${item.quantityAvailable} available'),
            ],
            const Gap(28),
            FilledButton.icon(
              onPressed: () => context.go('/login'),
              icon: const Icon(Icons.person_add_alt_1),
              label: Text(
                item.listingType.isService ? 'Sign in to contact seller' : 'Sign in to purchase',
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Section extends StatelessWidget {
  const _Section({required this.title, required this.child});

  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(
        title,
        style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
      ),
      const Gap(12),
      child,
    ],
  );
}

class _HorizontalListings extends StatelessWidget {
  const _HorizontalListings({required this.items});

  final List<ShopListing> items;

  @override
  Widget build(BuildContext context) => SizedBox(
    height: 170,
    child: ListView.separated(
      scrollDirection: Axis.horizontal,
      itemCount: items.length,
      separatorBuilder: (_, _) => const Gap(10),
      itemBuilder: (context, index) =>
          SizedBox(width: 190, child: _GuestListingTile(listing: items[index], isTrending: true)),
    ),
  );
}

class _ListingResults extends StatelessWidget {
  const _ListingResults({required this.listings, this.emptyText = 'No listings available'});

  final List<ShopListing> listings;
  final String emptyText;

  @override
  Widget build(BuildContext context) {
    if (listings.isEmpty) return Center(child: Text(emptyText));
    return Column(
      children: [
        for (final (index, listing) in listings.indexed) ...[
          if (index > 0) const Gap(10),
          _GuestListingTile(listing: listing),
        ],
      ],
    );
  }
}

class _GuestListingTile extends StatelessWidget {
  const _GuestListingTile({required this.listing, this.isTrending = false});

  final ShopListing listing;
  final bool isTrending;

  @override
  Widget build(BuildContext context) => Material(
    color: Colors.white,
    borderRadius: BorderRadius.circular(14),
    child: InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: () => context.push('/guest/listings/${listing.id}', extra: isTrending),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                color: const Color(0xFFE7F0E8),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                listing.listingType.isService ? Icons.home_repair_service : Icons.storefront,
                color: const Color(0xFF287148),
              ),
            ),
            const Gap(12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    listing.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                  const Gap(4),
                  Text(listing.listingType.name, style: const TextStyle(color: Color(0xFF647067))),
                ],
              ),
            ),
            const Gap(8),
            Text(_price(listing), style: const TextStyle(fontWeight: FontWeight.w700)),
          ],
        ),
      ),
    ),
  );
}

class _LoadingRow extends StatelessWidget {
  const _LoadingRow();

  @override
  Widget build(BuildContext context) =>
      const SizedBox(height: 120, child: Center(child: CircularProgressIndicator()));
}

class _RetryText extends StatelessWidget {
  const _RetryText({required this.message, required this.onRetry});

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) =>
      TextButton.icon(onPressed: onRetry, icon: const Icon(Icons.refresh), label: Text(message));
}

String _price(ShopListing listing) {
  if (listing.isFree) return 'FREE';
  final amount = listing.basePrice == listing.basePrice.roundToDouble()
      ? listing.basePrice.toInt().toString()
      : listing.basePrice.toStringAsFixed(2);
  return '₹$amount';
}
