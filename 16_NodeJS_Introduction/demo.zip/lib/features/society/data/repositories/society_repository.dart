import 'package:society_seva/features/society/data/models/membership_models.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/society/data/models/society_models.dart';

abstract class SocietyRepository {
  Future<PageResponse<Flat>> getCurrentUserFlats(PageableQuery query);

  Future<PageResponse<SocietyMembershipSummary>> getCurrentUserMemberships(
    PageableQuery query,
  );

  Future<PageResponse<Society>> getActiveSocieties(PageableQuery query);

  Future<PageResponse<Building>> getBuildings(
    String societyId,
    PageableQuery query,
  );

  Future<PageResponse<Floor>> getFloors(
    String societyId,
    String buildingId,
    PageableQuery query,
  );

  Future<PageResponse<Flat>> getFlats(String societyId, PageableQuery query);

  Future<PageResponse<Flat>> getFlatsByBuilding(
    String societyId,
    String buildingId,
    PageableQuery query,
  );

  Future<PageResponse<SocietyImage>> getImages(
    String societyId,
    PageableQuery query,
  );

  Future<List<SocietyWorker>> getWorkers(String societyId);

  Future<SocietyMember> createMember(
    String societyId,
    CreateSocietyMemberRequest request,
  );

  Future<SocietyMember> getMember(String societyId, String memberId);

  Future<SocietyMember> updateMember(
    String societyId,
    String memberId,
    UpdateSocietyMemberRequest request,
  );
  Future<void> cancelMemberRequest({
    required String societyId,
    required String userId,
    required String memberId,
  });
}
