import 'package:society_seva/core/mock/mock_data.dart';
import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/core/network/request_logger.dart';
import 'package:society_seva/features/society/data/models/membership_models.dart';
import 'package:society_seva/features/society/data/models/society_models.dart';
import 'package:society_seva/features/society/data/repositories/society_repository.dart';

class SocietyRepositoryImpl implements SocietyRepository {
  SocietyRepositoryImpl(this._apiClient);

  final ApiClient _apiClient;

  @override
  Future<PageResponse<Flat>> getCurrentUserFlats(PageableQuery query) async {
    try {
      return await _getPage(ApiEndpoints.currentUserFlats, query, Flat.fromJson);
    } catch (_) {
      return PageResponse<Flat>(
        content: MockData.flats,
        totalElements: MockData.flats.length,
        totalPages: 1,
        size: 50,
        page: 0,
        first: true,
        last: true,
      );
    }
  }

  @override
  Future<PageResponse<SocietyMembershipSummary>> getCurrentUserMemberships(PageableQuery query) async {
    try {
      return await _getPage(ApiEndpoints.currentUserMemberships, query, SocietyMembershipSummary.fromJson);
    } catch (_) {
      return PageResponse<SocietyMembershipSummary>(
        content: MockData.memberships,
        totalElements: MockData.memberships.length,
        totalPages: 1,
        size: 50,
        page: 0,
        first: true,
        last: true,
      );
    }
  }

  @override
  Future<PageResponse<Society>> getActiveSocieties(PageableQuery query) async {
    try {
      return await _getPage(ApiEndpoints.activeSocieties, query, Society.fromJson);
    } catch (_) {
      return PageResponse<Society>(
        content: MockData.societies,
        totalElements: MockData.societies.length,
        totalPages: 1,
        size: 50,
        page: 0,
        first: true,
        last: true,
      );
    }
  }

  @override
  Future<PageResponse<Building>> getBuildings(String societyId, PageableQuery query) async {
    try {
      return await _getPage(ApiEndpoints.societyBuildings(societyId), query, Building.fromJson);
    } catch (_) {
      final buildings = [
        Building(id: 'bld_a', societyId: societyId, buildingName: 'Tower A', totalFloors: 14, status: 'ACTIVE'),
        Building(id: 'bld_b', societyId: societyId, buildingName: 'Tower B', totalFloors: 14, status: 'ACTIVE'),
      ];
      return PageResponse<Building>(
        content: buildings,
        totalElements: buildings.length,
        totalPages: 1,
        size: 50,
        page: 0,
        first: true,
        last: true,
      );
    }
  }

  @override
  Future<PageResponse<Floor>> getFloors(String societyId, String buildingId, PageableQuery query) async {
    try {
      return await _getPage(ApiEndpoints.societyFloors(societyId, buildingId), query, Floor.fromJson);
    } catch (_) {
      final floors = List.generate(
        14,
        (i) => Floor(
          id: 'flr_${i + 1}',
          buildingId: buildingId,
          floorNumber: i + 1,
          status: 'ACTIVE',
        ),
      );
      return PageResponse<Floor>(
        content: floors,
        totalElements: floors.length,
        totalPages: 1,
        size: 50,
        page: 0,
        first: true,
        last: true,
      );
    }
  }

  @override
  Future<PageResponse<Flat>> getFlats(String societyId, PageableQuery query) async {
    try {
      return await _getPage(ApiEndpoints.societyFlats(societyId), query, Flat.fromJson);
    } catch (_) {
      return PageResponse<Flat>(
        content: MockData.flats,
        totalElements: MockData.flats.length,
        totalPages: 1,
        size: 50,
        page: 0,
        first: true,
        last: true,
      );
    }
  }

  @override
  Future<PageResponse<Flat>> getFlatsByBuilding(
    String societyId,
    String buildingId,
    PageableQuery query,
  ) async {
    try {
      return await _getPage(
        ApiEndpoints.societyFlatsByBuilding(societyId, buildingId),
        query,
        Flat.fromJson,
      );
    } catch (_) {
      return PageResponse<Flat>(
        content: MockData.flats,
        totalElements: MockData.flats.length,
        totalPages: 1,
        size: 50,
        page: 0,
        first: true,
        last: true,
      );
    }
  }

  @override
  Future<PageResponse<SocietyImage>> getImages(String societyId, PageableQuery query) async {
    try {
      return await _getPage(ApiEndpoints.societyImages(societyId), query, SocietyImage.fromJson);
    } catch (_) {
      return const PageResponse<SocietyImage>(
        content: [],
        totalElements: 0,
        totalPages: 1,
        size: 50,
        page: 0,
        first: true,
        last: true,
      );
    }
  }

  @override
  Future<List<SocietyWorker>> getWorkers(String societyId) async {
    try {
      final response = await _apiClient.get(ApiEndpoints.societyWorkers(societyId));
      final data = response.data;
      if (data is List) {
        return data
            .whereType<Map>()
            .map((item) => SocietyWorker.fromJson(Map<String, dynamic>.from(item)))
            .toList();
      }
    } catch (_) {}
    return const [];
  }

  @override
  Future<SocietyMember> createMember(String societyId, CreateSocietyMemberRequest request) async {
    final payload = request.toJson();
    RequestLogger.logPost(
      endpoint: ApiEndpoints.societyMembers(societyId),
      payload: payload,
      method: 'POST',
    );

    try {
      final response = await _apiClient.post(
        ApiEndpoints.societyMembers(societyId),
        data: payload,
      );
      return SocietyMember.fromJson(response.data as Map<String, dynamic>);
    } catch (_) {
      return SocietyMember(
        id: 'mem_${DateTime.now().millisecondsSinceEpoch}',
        societyId: societyId,
        flatId: request.flatId,
        userId: request.userId,
        memberType: request.memberType,
        relationshipToFlat: request.relationshipToFlat,
        verificationStatus: 'PENDING',
        moveInDate: request.moveInDate,
        isActive: true,
        createdAt: DateTime.now().toIso8601String(),
      );
    }
  }

  @override
  Future<SocietyMember> getMember(String societyId, String memberId) async {
    try {
      final response = await _apiClient.get(ApiEndpoints.societyMember(societyId, memberId));
      return SocietyMember.fromJson(response.data as Map<String, dynamic>);
    } catch (_) {
      return SocietyMember(
        id: memberId,
        societyId: societyId,
        flatId: 'flat_402',
        userId: MockData.sellerUserId,
        memberType: 'OWNER',
        relationshipToFlat: 'SELF',
        verificationStatus: 'APPROVED',
        moveInDate: '2025-01-01',
        isActive: true,
        createdAt: DateTime.now().subtract(const Duration(days: 60)).toIso8601String(),
      );
    }
  }

  @override
  Future<SocietyMember> updateMember(
    String societyId,
    String memberId,
    UpdateSocietyMemberRequest request,
  ) async {
    try {
      final response = await _apiClient.patch(
        ApiEndpoints.societyMember(societyId, memberId),
        data: request.toJson(),
      );
      return SocietyMember.fromJson(response.data as Map<String, dynamic>);
    } catch (_) {
      return SocietyMember(
        id: memberId,
        societyId: societyId,
        flatId: 'flat_402',
        userId: MockData.sellerUserId,
        memberType: request.memberType,
        relationshipToFlat: request.relationshipToFlat,
        verificationStatus: 'APPROVED',
        moveInDate: request.moveInDate,
        isActive: true,
        createdAt: DateTime.now().subtract(const Duration(days: 60)).toIso8601String(),
      );
    }
  }

  @override
  Future<void> cancelMemberRequest({
    required String societyId,
    required String userId,
    required String memberId,
  }) async {
    try {
      await _apiClient.delete(
        ApiEndpoints.cancelSocietyMemberRequest(societyId),
        data: {'userId': userId, 'memberId': memberId},
      );
    } catch (_) {}
  }

  Future<PageResponse<T>> _getPage<T>(
    String path,
    PageableQuery query,
    T Function(Map<String, dynamic>) fromJson,
  ) async {
    final response = await _apiClient.get(path, queryParameters: query.toQueryParameters());
    return PageResponse.fromJson(response.data as Map<String, dynamic>, fromJson);
  }
}
