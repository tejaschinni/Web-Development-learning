class Society {
  const Society({
    required this.id,
    required this.name,
    required this.address,
    required this.city,
    required this.state,
    required this.country,
    required this.pinCode,
    required this.numberOfBuildings,
    required this.numberOfFloors,
    required this.totalFlats,
    required this.status,
  });

  final String id;
  final String name;
  final String address;
  final String city;
  final String state;
  final String country;
  final String pinCode;
  final int numberOfBuildings;
  final int numberOfFloors;
  final int totalFlats;
  final String status;

  factory Society.fromJson(Map<String, dynamic> json) => Society(
    id: json['id'] as String? ?? '',
    name: json['name'] as String? ?? '',
    address: json['address'] as String? ?? '',
    city: json['city'] as String? ?? '',
    state: json['state'] as String? ?? '',
    country: json['country'] as String? ?? '',
    pinCode: json['pinCode'] as String? ?? '',
    numberOfBuildings: (json['numberOfBuildings'] as num?)?.toInt() ?? 0,
    numberOfFloors: (json['numberOfFloors'] as num?)?.toInt() ?? 0,
    totalFlats: (json['totalFlats'] as num?)?.toInt() ?? 0,
    status: json['societyStatus'] as String? ?? 'ACTIVE',
  );
}

class Building {
  const Building({
    required this.id,
    required this.societyId,
    required this.buildingName,
    required this.totalFloors,
    required this.status,
  });

  final String id;
  final String societyId;
  final String buildingName;
  final int totalFloors;
  final String status;

  factory Building.fromJson(Map<String, dynamic> json) => Building(
    id: json['id'] as String? ?? '',
    societyId: json['societyId'] as String? ?? '',
    buildingName: json['buildingName'] as String? ?? '',
    totalFloors: (json['totalFloors'] as num?)?.toInt() ?? 0,
    status: json['status'] as String? ?? 'ACTIVE',
  );
}

class Floor {
  const Floor({
    required this.id,
    required this.buildingId,
    required this.floorNumber,
    required this.status,
  });

  final String id;
  final String buildingId;
  final int floorNumber;
  final String status;

  factory Floor.fromJson(Map<String, dynamic> json) => Floor(
    id: json['id'] as String? ?? '',
    buildingId: json['buildingId'] as String? ?? '',
    floorNumber: (json['floorNumber'] as num?)?.toInt() ?? 0,
    status: json['status'] as String? ?? 'ACTIVE',
  );
}

class Flat {
  const Flat({
    required this.id,
    required this.societyId,
    required this.buildingId,
    required this.floorId,
    required this.flatNumber,
    required this.ownerName,
    required this.residentType,
    required this.occupancyStatus,
    required this.status,
  });

  final String id;
  final String societyId;
  final String buildingId;
  final String floorId;
  final String flatNumber;
  final String ownerName;
  final String residentType;
  final String occupancyStatus;
  final String status;

  factory Flat.fromJson(Map<String, dynamic> json) => Flat(
    id: json['id'] as String? ?? '',
    societyId: json['societyId'] as String? ?? '',
    buildingId: json['buildingId'] as String? ?? '',
    floorId: json['floorId'] as String? ?? '',
    flatNumber: json['flatNumber'] as String? ?? '',
    ownerName: json['ownerName'] as String? ?? '',
    residentType: json['residentType'] as String? ?? '',
    occupancyStatus: json['occupancyStatus'] as String? ?? '',
    status: json['status'] as String? ?? 'ACTIVE',
  );
}

class SocietyImage {
  const SocietyImage({
    required this.id,
    required this.societyId,
    required this.imageUrl,
    required this.description,
    required this.moderationStatus,
    required this.displayOrder,
  });

  final String id;
  final String societyId;
  final String imageUrl;
  final String description;
  final String moderationStatus;
  final int displayOrder;

  factory SocietyImage.fromJson(Map<String, dynamic> json) => SocietyImage(
    id: json['id'] as String? ?? '',
    societyId: json['societyId'] as String? ?? '',
    imageUrl: json['imageUrl'] as String? ?? '',
    description: json['description'] as String? ?? '',
    moderationStatus: json['moderationStatus'] as String? ?? '',
    displayOrder: (json['displayOrder'] as num?)?.toInt() ?? 0,
  );
}

class SocietyWorker {
  const SocietyWorker({
    required this.id,
    required this.societyId,
    required this.userId,
    required this.designation,
    required this.startDate,
    required this.active,
    required this.status,
    required this.extraDetails,
  });

  final String id;
  final String societyId;
  final String userId;
  final String designation;
  final String startDate;
  final bool active;
  final String status;
  final String extraDetails;

  factory SocietyWorker.fromJson(Map<String, dynamic> json) => SocietyWorker(
    id: json['id'] as String? ?? '',
    societyId: json['societyId'] as String? ?? '',
    userId: json['userId'] as String? ?? '',
    designation: json['designation'] as String? ?? '',
    startDate: json['startDate'] as String? ?? '',
    active: json['active'] as bool? ?? false,
    status: json['status'] as String? ?? 'INACTIVE',
    extraDetails: json['extraDetails'] as String? ?? '',
  );
}
