class SocietyMembershipSummary {
  const SocietyMembershipSummary({
    required this.id,
    required this.societyId,
    required this.societyName,
    required this.flatId,
    required this.memberType,
    required this.verificationStatus,
    required this.isActive,
  });

  final String id;
  final String societyId;
  final String societyName;
  final String flatId;
  final String memberType;
  final String verificationStatus;
  final bool isActive;

  factory SocietyMembershipSummary.fromJson(Map<String, dynamic> json) {
    return SocietyMembershipSummary(
      id: json['id'] as String? ?? '',
      societyId: json['societyId'] as String? ?? '',
      societyName: json['societyName'] as String? ?? '',
      flatId: json['flatId'] as String? ?? '',
      memberType: json['memberType'] as String? ?? '',
      verificationStatus: json['verificationStatus'] as String? ?? 'PENDING',
      isActive: json['isActive'] as bool? ?? false,
    );
  }
}

class SocietyMember {
  const SocietyMember({
    required this.id,
    required this.societyId,
    required this.flatId,
    required this.userId,
    required this.memberType,
    required this.relationshipToFlat,
    required this.verificationStatus,
    required this.moveInDate,
    required this.isActive,
    this.createdAt,
    this.verifiedBy,
    this.verifiedAt,
  });

  final String id;
  final String societyId;
  final String flatId;
  final String userId;
  final String memberType;
  final String relationshipToFlat;
  final String verificationStatus;
  final String moveInDate;
  final bool isActive;
  final String? createdAt;
  final String? verifiedBy;
  final String? verifiedAt;

  factory SocietyMember.fromJson(Map<String, dynamic> json) => SocietyMember(
    id: json['id'] as String? ?? '',
    societyId: json['societyId'] as String? ?? '',
    flatId: json['flatId'] as String? ?? '',
    userId: json['userId'] as String? ?? '',
    memberType: json['memberType'] as String? ?? '',
    relationshipToFlat: json['relationshipToFlat'] as String? ?? '',
    verificationStatus: json['verificationStatus'] as String? ?? 'PENDING',
    moveInDate: json['moveInDate'] as String? ?? '',
    isActive: json['isActive'] as bool? ?? false,
    createdAt: json['createdAt'] as String?,
    verifiedBy: json['verifiedBy'] as String?,
    verifiedAt: json['verifiedAt'] as String?,
  );
}

class CreateSocietyMemberRequest {
  const CreateSocietyMemberRequest({
    required this.userId,
    required this.flatId,
    required this.memberType,
    required this.relationshipToFlat,
    required this.moveInDate,
  });

  final String userId;
  final String flatId;
  final String memberType;
  final String relationshipToFlat;
  final String moveInDate;

  Map<String, dynamic> toJson() => {
    'userId': userId,
    'flatId': flatId,
    'memberType': memberType,
    'relationshipToFlat': relationshipToFlat,
    'moveInDate': moveInDate,
  };
}

class UpdateSocietyMemberRequest {
  const UpdateSocietyMemberRequest({
    required this.memberType,
    required this.relationshipToFlat,
    required this.moveInDate,
  });

  final String memberType;
  final String relationshipToFlat;
  final String moveInDate;

  Map<String, dynamic> toJson() => {
    'memberType': memberType,
    'relationshipToFlat': relationshipToFlat,
    'moveInDate': moveInDate,
  };
}
