import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/core/storage/local_cache.dart';
import 'package:society_seva/features/society/data/models/membership_models.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/society/data/models/society_models.dart';
import 'package:society_seva/features/society/data/repositories/society_repository.dart';
import 'package:society_seva/features/society/presentation/providers/society_provider.dart';

final societyOnboardingProvider =
    StateNotifierProvider.family<
      SocietyOnboardingController,
      SocietyOnboardingState,
      SocietyOnboardingArgs
    >((ref, args) {
      return SocietyOnboardingController(ref.watch(societyRepositoryProvider), args);
    });

class SocietyOnboardingArgs {
  const SocietyOnboardingArgs({required this.userId, required this.isAdmin});

  final String userId;
  final bool isAdmin;

  @override
  bool operator ==(Object other) {
    return other is SocietyOnboardingArgs && other.userId == userId && other.isAdmin == isAdmin;
  }

  @override
  int get hashCode => Object.hash(userId, isAdmin);
}

enum SocietyOnboardingStatus {
  initial,
  loading,
  ready,
  submitting,
  canceling,
  refreshingMember,
  pendingApproval,
  approved,
  needsMoreInfo,
  error,
}

class SocietyOnboardingState {
  const SocietyOnboardingState({
    this.status = SocietyOnboardingStatus.initial,
    this.societies = const [],
    this.currentUserFlats = const [],
    this.buildings = const [],
    this.flats = const [],
    this.selectedSociety,
    this.selectedBuilding,
    this.selectedFlat,
    this.member,
    this.errorMessage,
    this.initialized = false,
  });

  final SocietyOnboardingStatus status;
  final List<Society> societies;
  final List<Flat> currentUserFlats;
  final List<Building> buildings;
  final List<Flat> flats;
  final Society? selectedSociety;
  final Building? selectedBuilding;
  final Flat? selectedFlat;
  final SocietyMember? member;
  final String? errorMessage;
  final bool initialized;

  SocietyOnboardingState copyWith({
    SocietyOnboardingStatus? status,
    List<Society>? societies,
    List<Flat>? currentUserFlats,
    List<Building>? buildings,
    List<Flat>? flats,
    Society? selectedSociety,
    Building? selectedBuilding,
    Flat? selectedFlat,
    SocietyMember? member,
    String? errorMessage,
    bool? initialized,
    bool clearBuilding = false,
    bool clearFlat = false,
    bool clearMember = false,
    bool clearError = false,
  }) {
    return SocietyOnboardingState(
      status: status ?? this.status,
      societies: societies ?? this.societies,
      currentUserFlats: currentUserFlats ?? this.currentUserFlats,
      buildings: buildings ?? this.buildings,
      flats: flats ?? this.flats,
      selectedSociety: selectedSociety ?? this.selectedSociety,
      selectedBuilding: clearBuilding ? null : selectedBuilding ?? this.selectedBuilding,
      selectedFlat: clearFlat ? null : selectedFlat ?? this.selectedFlat,
      member: clearMember ? null : member ?? this.member,
      errorMessage: clearError ? null : errorMessage ?? this.errorMessage,
      initialized: initialized ?? this.initialized,
    );
  }
}

class SocietyOnboardingController extends StateNotifier<SocietyOnboardingState> {
  SocietyOnboardingController(this._repository, this.args) : super(const SocietyOnboardingState()) {
    loadSocieties();
  }

  final SocietyRepository _repository;
  final SocietyOnboardingArgs args;

  String get _cacheKey => 'user:${args.userId}:onboarding';

  Future<void> loadSocieties() async {
    state = state.copyWith(status: SocietyOnboardingStatus.loading, clearError: true);
    try {
      final societies = await _loadAll<Society>((query) => _repository.getActiveSocieties(query));
      state = state.copyWith(
        status: SocietyOnboardingStatus.ready,
        societies: _selectable(societies),
      );
      final currentUserFlats = await _loadAll<Flat>(
        (query) => _repository.getCurrentUserFlats(query),
      );
      state = state.copyWith(currentUserFlats: _selectable(currentUserFlats));
      await _restoreSelection(restoreMember: false);
      final memberships = await _loadAll<SocietyMembershipSummary>(
        (query) => _repository.getCurrentUserMemberships(query),
      );
      await _applyCurrentMembership(memberships);
      state = state.copyWith(initialized: true);
    } catch (error) {
      state = state.copyWith(
        status: SocietyOnboardingStatus.error,
        errorMessage: error.toString(),
        initialized: true,
      );
    }
  }

  Future<void> selectSociety(Society society) async {
    state = state.copyWith(
      selectedSociety: society,
      buildings: const [],
      flats: const [],
      clearBuilding: true,
      clearFlat: true,
      clearMember: true,
      status: SocietyOnboardingStatus.loading,
      clearError: true,
    );
    try {
      final buildings = _selectable(
        await _loadAll<Building>((query) => _repository.getBuildings(society.id, query)),
      );
      state = state.copyWith(buildings: buildings, status: SocietyOnboardingStatus.ready);
      if (buildings.length == 1) {
        await selectBuilding(buildings.single);
      }
      await _persistSelection();
    } catch (error) {
      _setError(error);
    }
  }

  Future<void> selectBuilding(Building building) async {
    final society = state.selectedSociety;
    if (society == null) return;
    state = state.copyWith(
      selectedBuilding: building,
      flats: const [],
      clearFlat: true,
      status: SocietyOnboardingStatus.loading,
      clearError: true,
    );
    try {
      final flats = _selectable(
        await _loadAll<Flat>(
          (query) => _repository.getFlatsByBuilding(society.id, building.id, query),
        ),
      );
      state = state.copyWith(flats: flats, status: SocietyOnboardingStatus.ready);
      await _persistSelection();
    } catch (error) {
      _setError(error);
    }
  }

  Future<void> selectFlat(Flat flat) async {
    state = state.copyWith(selectedFlat: flat, clearError: true);
    await _persistSelection();
  }

  Future<void> selectCurrentUserFlat(Flat flat) async {
    final society = state.societies.where((item) => item.id == flat.societyId).firstOrNull;
    if (society == null) return;

    await selectSociety(society);
    final building = state.buildings.where((item) => item.id == flat.buildingId).firstOrNull;
    if (building != null) {
      await selectBuilding(building);
    }
    final loadedFlat = state.flats.where((item) => item.id == flat.id).firstOrNull;
    await selectFlat(loadedFlat ?? flat);
  }

  Future<void> submitMember({
    required String memberType,
    required String relationshipToFlat,
    required String moveInDate,
  }) async {
    final society = state.selectedSociety;
    final flat = state.selectedFlat;
    if (society == null || flat == null) return;
    state = state.copyWith(status: SocietyOnboardingStatus.submitting, clearError: true);
    try {
      final member = await _repository.createMember(
        society.id,
        CreateSocietyMemberRequest(
          userId: args.userId,
          flatId: flat.id,
          memberType: memberType,
          relationshipToFlat: relationshipToFlat,
          moveInDate: moveInDate,
        ),
      );
      state = state.copyWith(member: member, status: _statusFor(member.verificationStatus));
      await _persistSelection();
    } catch (error) {
      _setError(error);
    }
  }

  Future<void> refreshMember() async {
    final member = state.member;
    final society = state.selectedSociety;
    if (member == null || society == null) return;
    state = state.copyWith(status: SocietyOnboardingStatus.refreshingMember, clearError: true);
    try {
      final updated = await _repository.getMember(society.id, member.id);
      state = state.copyWith(member: updated, status: _statusFor(updated.verificationStatus));
      await _persistSelection();
    } catch (error) {
      _setError(error);
    }
  }

  Future<void> cancelMemberRequest() async {
    final member = state.member;
    final society = state.selectedSociety;
    if (member == null || society == null) return;
    state = state.copyWith(status: SocietyOnboardingStatus.canceling, clearError: true);
    try {
      await _repository.cancelMemberRequest(
        societyId: society.id,
        userId: args.userId,
        memberId: member.id,
      );
      state = state.copyWith(
        status: SocietyOnboardingStatus.ready,
        clearMember: true,
        clearError: true,
      );
      await _persistSelection();
    } catch (error) {
      _setError(error);
    }
  }

  Future<bool> updateMember({
    required String memberType,
    required String relationshipToFlat,
    required String moveInDate,
  }) async {
    final member = state.member;
    final society = state.selectedSociety;
    if (member == null || society == null) return false;
    state = state.copyWith(status: SocietyOnboardingStatus.submitting, clearError: true);
    try {
      final updated = await _repository.updateMember(
        society.id,
        member.id,
        UpdateSocietyMemberRequest(
          memberType: memberType,
          relationshipToFlat: relationshipToFlat,
          moveInDate: moveInDate,
        ),
      );
      state = state.copyWith(member: updated, status: _statusFor(updated.verificationStatus));
      await _persistSelection();
      return true;
    } catch (error) {
      _setError(error);
      return false;
    }
  }

  SocietyOnboardingStatus _statusFor(String value) {
    switch (value.toUpperCase()) {
      case 'APPROVED':
        return SocietyOnboardingStatus.approved;
      case 'NEEDS_MORE_INFO':
        return SocietyOnboardingStatus.needsMoreInfo;
      case 'REJECTED':
      case 'PENDING':
      default:
        return SocietyOnboardingStatus.pendingApproval;
    }
  }

  List<T> _selectable<T>(List<T> items) {
    if (args.isAdmin) return items;
    return items.where((item) {
      final status = switch (item) {
        Society value => value.status,
        Building value => value.status,
        Floor value => value.status,
        Flat value => value.status,
        _ => 'ACTIVE',
      };
      return status == 'ACTIVE';
    }).toList();
  }

  Future<List<T>> _loadAll<T>(Future<PageResponse<T>> Function(PageableQuery query) fetch) async {
    final items = <T>[];
    var page = 0;
    var last = false;
    while (!last) {
      final response = await fetch(PageableQuery(page: page));
      items.addAll(response.content);
      last = response.last || response.content.isEmpty;
      page++;
    }
    return items;
  }

  Future<void> _applyCurrentMembership(List<SocietyMembershipSummary> memberships) async {
    final activeMemberships = memberships.where((membership) => membership.isActive).toList();
    if (activeMemberships.isEmpty) return;

    activeMemberships.sort((left, right) {
      final leftApproved = left.verificationStatus.toUpperCase() == 'APPROVED';
      final rightApproved = right.verificationStatus.toUpperCase() == 'APPROVED';
      return (rightApproved ? 1 : 0) - (leftApproved ? 1 : 0);
    });
    final summary = activeMemberships.first;
    final society = state.societies.where((item) => item.id == summary.societyId).firstOrNull;
    final summaryMember = SocietyMember(
      id: summary.id,
      societyId: summary.societyId,
      flatId: summary.flatId,
      userId: args.userId,
      memberType: summary.memberType,
      relationshipToFlat: 'NA',
      verificationStatus: summary.verificationStatus,
      moveInDate: '',
      isActive: summary.isActive,
    );
    state = state.copyWith(
      selectedSociety: society,
      member: summaryMember,
      status: _statusFor(summary.verificationStatus),
    );

    try {
      final member = await _repository.getMember(summary.societyId, summary.id);
      state = state.copyWith(member: member, status: _statusFor(member.verificationStatus));
      await _persistSelection();
    } catch (_) {}
  }

  Future<void> _persistSelection() async {
    await LocalCache.instance.writeJson(_cacheKey, {
      'societyId': state.selectedSociety?.id,
      'buildingId': state.selectedBuilding?.id,
      'flatId': state.selectedFlat?.id,
      'member': state.member == null
          ? null
          : {
              'id': state.member!.id,
              'societyId': state.member!.societyId,
              'flatId': state.member!.flatId,
              'userId': state.member!.userId,
              'memberType': state.member!.memberType,
              'relationshipToFlat': state.member!.relationshipToFlat,
              'verificationStatus': state.member!.verificationStatus,
              'moveInDate': state.member!.moveInDate,
              'isActive': state.member!.isActive,
              'createdAt': state.member!.createdAt,
            },
    });
  }

  Future<void> _restoreSelection({bool restoreMember = true}) async {
    final saved = await LocalCache.instance.readJson(_cacheKey);
    if (saved == null) return;
    final societyId = saved['societyId'];
    final society = state.societies.where((item) => item.id == societyId).firstOrNull;
    if (society != null) {
      await selectSociety(society);
      state = state.copyWith(
        selectedSociety: society,
        buildings: const [],
        flats: const [],
        clearBuilding: true,
        clearFlat: true,
        status: SocietyOnboardingStatus.loading,
        clearError: true,
      );
      try {
        final buildings = _selectable(
          await _loadAll<Building>((query) => _repository.getBuildings(society.id, query)),
        );
        state = state.copyWith(buildings: buildings);
      } catch (error) {
        _setError(error);
        return;
      }
      final buildingId = saved['buildingId'];
      final building = state.buildings.where((item) => item.id == buildingId).firstOrNull;
      if (building != null) {
        await selectBuilding(building);
      }

      final flatId = saved['flatId'];
      final flat = state.flats.where((item) => item.id == flatId).firstOrNull;
      if (flat != null) {
        await selectFlat(flat);
      }
    }

    if (!restoreMember) return;

    final memberJson = saved['member'];
    final savedSocietyId = saved['societyId'];
    if (memberJson is Map && savedSocietyId is String) {
      final cachedMember = SocietyMember.fromJson(Map<String, dynamic>.from(memberJson));
      if (cachedMember.id.isNotEmpty) {
        try {
          final member = await _repository.getMember(savedSocietyId, cachedMember.id);
          state = state.copyWith(member: member, status: _statusFor(member.verificationStatus));
          await _persistSelection();
        } catch (error) {
          _setError(error);
        }
      }
    }
  }

  void _setError(Object error) {
    state = state.copyWith(status: SocietyOnboardingStatus.error, errorMessage: error.toString());
  }
}
