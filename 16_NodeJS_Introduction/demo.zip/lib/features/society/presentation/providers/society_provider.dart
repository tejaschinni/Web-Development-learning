import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/core/providers/app_providers.dart';
import 'package:society_seva/features/society/data/repositories/society_repository.dart';
import 'package:society_seva/features/society/data/repositories/society_repository_impl.dart';

final societyRepositoryProvider = Provider<SocietyRepository>((ref) {
  return SocietyRepositoryImpl(ref.watch(apiClientProvider));
});
