import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/society/data/models/society_models.dart';
import 'package:society_seva/features/society/presentation/providers/society_provider.dart';

class SocietyDetailsScreen extends ConsumerStatefulWidget {
  const SocietyDetailsScreen({super.key, required this.societyId});
  final String? societyId;

  @override
  ConsumerState<SocietyDetailsScreen> createState() => _SocietyDetailsScreenState();
}

class _SocietyDetailsScreenState extends ConsumerState<SocietyDetailsScreen> {
  List<SocietyImage> _images = const [];
  List<SocietyWorker> _workers = const [];
  Object? _error;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant SocietyDetailsScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.societyId != widget.societyId) _load();
  }

  Future<void> _load() async {
    final societyId = widget.societyId;
    if (societyId == null) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final repository = ref.read(societyRepositoryProvider);
      final images = await repository.getImages(societyId, const PageableQuery());
      final workers = await repository.getWorkers(societyId);
      if (!mounted) return;
      setState(() {
        _images = images.content;
        _workers = workers;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error;
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.societyId == null) {
      return Center(
        child: Text('Select a society to view its details.', style: GoogleFonts.hind()),
      );
    }
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) {
      return Center(
        child: OutlinedButton.icon(
          onPressed: _load,
          icon: const HugeIcon(icon: HugeIcons.strokeRoundedRefresh01),
          label: Text('Retry society details', style: GoogleFonts.hind()),
        ),
      );
    }
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          Text(
            'Society details',
            style: GoogleFonts.hind(textStyle: Theme.of(context).textTheme.headlineSmall),
          ),
          const Gap(16),
          if (_images.isEmpty)
            Text('No society images available.', style: GoogleFonts.hind())
          else
            SizedBox(
              height: 180,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: _images.length,
                separatorBuilder: (_, _) => const Gap(12),
                itemBuilder: (context, index) => Image.network(
                  _images[index].imageUrl,
                  width: 240,
                  fit: BoxFit.cover,
                  errorBuilder: (_, _, _) => const SizedBox(
                    width: 240,
                    child: Center(child: HugeIcon(icon: HugeIcons.strokeRoundedImageDelete02)),
                  ),
                ),
              ),
            ),
          const Gap(24),
          Text(
            'Society workers',
            style: GoogleFonts.hind(textStyle: Theme.of(context).textTheme.titleLarge),
          ),
          if (_workers.isEmpty)
            ListTile(title: Text('No worker details available.', style: GoogleFonts.hind()))
          else
            ..._workers.map(
              (worker) => ListTile(
                leading: const HugeIcon(icon: HugeIcons.strokeRoundedIdCard),
                title: Text(worker.designation, style: GoogleFonts.hind()),
                subtitle: Text(worker.extraDetails, style: GoogleFonts.hind()),
                trailing: Text(worker.status, style: GoogleFonts.hind()),
              ),
            ),
        ],
      ),
    );
  }
}
