import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/features/profile/presentation/providers/profile_provider.dart';
import 'package:society_seva/features/society/data/models/membership_models.dart';
import 'package:society_seva/features/society/data/models/society_models.dart';
import 'package:society_seva/features/society/presentation/providers/society_onboarding_provider.dart';

class SocietyOnboardingScreen extends ConsumerStatefulWidget {
  const SocietyOnboardingScreen({super.key});

  @override
  ConsumerState<SocietyOnboardingScreen> createState() => _SocietyOnboardingScreenState();
}

class _SocietyOnboardingScreenState extends ConsumerState<SocietyOnboardingScreen> {
  String _memberType = 'TENANT';
  final String _relationship = 'NA';
  DateTime _moveInDate = DateTime.now();
  bool _editingDetails = false;

  @override
  Widget build(BuildContext context) {
    final profile = ref.watch(profileControllerProvider).profile;
    if (profile == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final isAdmin = _isAdmin(profile.roles);
    final args = SocietyOnboardingArgs(userId: profile.id, isAdmin: isAdmin);
    final state = ref.watch(societyOnboardingProvider(args));
    final controller = ref.read(societyOnboardingProvider(args).notifier);
    final hasMemberRequest = state.member != null;
    final isSubmitting = state.status == SocietyOnboardingStatus.submitting;
    final isCanceling = state.status == SocietyOnboardingStatus.canceling;
    final isRefreshing = state.status == SocietyOnboardingStatus.refreshingMember;
    final canEditDetails = !hasMemberRequest || _editingDetails;

    if (state.status == SocietyOnboardingStatus.approved) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) context.go('/dashboard');
      });
    }

    return Scaffold(
      appBar: AppBar(title: Text('Choose your society', style: GoogleFonts.hind())),
      body: RefreshIndicator(
        onRefresh: controller.loadSocieties,
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            Text(
              'Society membership',
              style: GoogleFonts.hind(fontSize: 26, fontWeight: FontWeight.w700),
            ),
            const Gap(8),
            Text(
              'Select your society and home details to request committee approval.',
              style: GoogleFonts.hind(),
            ),
            const Gap(24),
            if (state.errorMessage != null) ...[
              Text(state.errorMessage!, style: GoogleFonts.hind(color: Colors.red.shade700)),
              const Gap(16),
            ],
            if (state.status == SocietyOnboardingStatus.loading && state.societies.isEmpty)
              const Center(child: CircularProgressIndicator())
            else ...[
              _dropdown<Society>(
                label: 'Society',
                value: state.selectedSociety,
                items: state.societies,
                enabled: !hasMemberRequest,
                itemLabel: (value) => value.name,
                onChanged: (value) {
                  if (value != null) controller.selectSociety(value);
                },
              ),
              if (state.selectedSociety != null &&
                  (state.buildings.length > 1 || state.selectedBuilding == null))
                _dropdown<Building>(
                  label: 'Building',
                  value: state.selectedBuilding,
                  items: state.buildings,
                  enabled: !hasMemberRequest,
                  itemLabel: (value) => value.buildingName,
                  onChanged: (value) {
                    if (value != null) controller.selectBuilding(value);
                  },
                ),
              if (state.selectedBuilding != null)
                _dropdown<Flat>(
                  label: 'Flat number',
                  value: state.selectedFlat,
                  items: state.flats,
                  enabled: !hasMemberRequest,
                  itemLabel: (value) => value.flatNumber,
                  onChanged: (value) {
                    if (value != null) controller.selectFlat(value);
                  },
                ),
              if (state.selectedFlat != null && canEditDetails) ...[
                _enumDropdown(
                  label: 'You are',
                  value: _memberType,
                  values: const ['OWNER', 'TENANT', 'FAMILY_MEMBER'],
                  onChanged: (value) => setState(() => _memberType = value),
                ),
                // _enumDropdown(
                //   label: 'Relationship to flat',
                //   value: _relationship,
                //   values: const ['NA', 'OWNER', 'TENANT'],
                //   onChanged: (value) => setState(() => _relationship = value),
                // ),
                _dateSelector(context),
                const Gap(8),
                FilledButton(
                  onPressed: isSubmitting || isCanceling
                      ? null
                      : () async {
                          if (hasMemberRequest) {
                            final updated = await controller.updateMember(
                              memberType: _memberType,
                              relationshipToFlat: _relationship,
                              moveInDate: _formatDate(_moveInDate),
                            );
                            if (mounted && updated) {
                              setState(() => _editingDetails = false);
                            }
                          } else {
                            await controller.submitMember(
                              memberType: _memberType,
                              relationshipToFlat: _relationship,
                              moveInDate: _formatDate(_moveInDate),
                            );
                          }
                        },
                  child: Text(
                    hasMemberRequest
                        ? 'Save updated details'
                        : 'Send approval request to society committee',
                    style: GoogleFonts.hind(),
                  ),
                ),
                if (hasMemberRequest)
                  TextButton(
                    onPressed: isSubmitting ? null : () => setState(() => _editingDetails = false),
                    child: Text('Cancel editing', style: GoogleFonts.hind()),
                  ),
              ],
              if (state.member != null) ...[
                const Gap(24),
                _MembershipStatusCard(
                  status: state.member!.verificationStatus,
                  createdAt: state.member!.createdAt,
                  isRefreshing: isRefreshing,
                  onRefresh: controller.refreshMember,
                  onCancel: state.member!.verificationStatus == 'APPROVED'
                      ? null
                      : isCanceling
                      ? null
                      : controller.cancelMemberRequest,
                  onEdit: state.member!.verificationStatus == 'NEEDS_MORE_INFO' && !_editingDetails
                      ? () => _startEditing(state.member!)
                      : null,
                ),
              ],
            ],
          ],
        ),
      ),
    );
  }

  void _startEditing(SocietyMember member) {
    final parsedMoveInDate = DateTime.tryParse(member.moveInDate);
    setState(() {
      _editingDetails = true;
      _memberType = const ['OWNER', 'TENANT', 'FAMILY_MEMBER'].contains(member.memberType)
          ? member.memberType
          : 'TENANT';
      if (parsedMoveInDate != null) {
        _moveInDate = parsedMoveInDate;
      }
    });
  }

  Widget _dropdown<T>({
    required String label,
    required T? value,
    required List<T> items,
    bool enabled = true,
    required String Function(T) itemLabel,
    required ValueChanged<T?> onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: DropdownButtonFormField<T>(
        initialValue: value,
        isExpanded: true,
        decoration: InputDecoration(labelText: label),
        items: items
            .map(
              (item) => DropdownMenuItem<T>(
                value: item,
                child: Text(itemLabel(item), style: GoogleFonts.hind()),
              ),
            )
            .toList(),
        onChanged: enabled ? onChanged : null,
      ),
    );
  }

  Widget _dateSelector(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: ListTile(
        contentPadding: EdgeInsets.zero,
        title: Text('Move-in date', style: GoogleFonts.hind()),
        subtitle: Text(_formatDate(_moveInDate), style: GoogleFonts.hind()),
        trailing: const HugeIcon(icon: HugeIcons.strokeRoundedCalendar03),
        onTap: () async {
          final today = DateTime.now();
          final selected = await showDatePicker(
            context: context,
            initialDate: _moveInDate,
            firstDate: DateTime(1900),
            lastDate: DateTime(today.year, today.month, today.day),
          );
          if (selected != null) {
            setState(() => _moveInDate = selected);
          }
        },
      ),
    );
  }

  Widget _enumDropdown({
    required String label,
    required String value,
    required List<String> values,
    required ValueChanged<String> onChanged,
  }) {
    return DropdownButtonFormField<String>(
      initialValue: value,
      decoration: InputDecoration(labelText: label),
      items: values
          .map(
            (item) => DropdownMenuItem(
              value: item,
              child: Text(item, style: GoogleFonts.hind()),
            ),
          )
          .toList(),
      onChanged: (item) {
        if (item != null) onChanged(item);
      },
    );
  }
}

class _MembershipStatusCard extends StatelessWidget {
  const _MembershipStatusCard({
    required this.status,
    required this.createdAt,
    required this.isRefreshing,
    required this.onRefresh,
    this.onCancel,
    this.onEdit,
  });

  final String status;
  final String? createdAt;
  final bool isRefreshing;
  final VoidCallback onRefresh;
  final VoidCallback? onCancel;
  final VoidCallback? onEdit;

  @override
  Widget build(BuildContext context) {
    final approved = status == 'APPROVED';
    final message = switch (status) {
      'APPROVED' => 'Your membership is approved.',
      'NEEDS_MORE_INFO' => 'The committee requested more information.',
      'REJECTED' => 'Your request was rejected. Contact the committee.',
      _ => 'Your request is awaiting society committee approval.',
    };

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(message, style: GoogleFonts.hind()),
            if (createdAt != null && createdAt!.isNotEmpty) ...[
              const Gap(8),
              Text('Requested on ${_formatRequestDate(createdAt!)}', style: GoogleFonts.hind()),
            ],
            const Gap(12),
            if (onEdit != null)
              OutlinedButton(
                onPressed: onEdit,
                child: Text('Update details', style: GoogleFonts.hind()),
              ),
            if (onCancel != null)
              OutlinedButton(
                onPressed: onCancel,
                child: Text('Cancel request', style: GoogleFonts.hind()),
              ),
            if (!approved)
              TextButton.icon(
                onPressed: isRefreshing ? null : onRefresh,
                icon: isRefreshing
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const HugeIcon(icon: HugeIcons.strokeRoundedRefresh01),
                label: Text(
                  isRefreshing ? 'Checking status...' : 'Check status',
                  style: GoogleFonts.hind(),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

String _formatRequestDate(String value) {
  final parsed = DateTime.tryParse(value)?.toLocal();
  if (parsed == null) return value;
  final date = _formatDate(parsed);
  final hour = parsed.hour % 12 == 0 ? 12 : parsed.hour % 12;
  final minute = parsed.minute.toString().padLeft(2, '0');
  final period = parsed.hour >= 12 ? 'PM' : 'AM';
  return '$date, $hour:$minute $period';
}

String _formatDate(DateTime date) =>
    '${date.year.toString().padLeft(4, '0')}-'
    '${date.month.toString().padLeft(2, '0')}-'
    '${date.day.toString().padLeft(2, '0')}';

bool _isAdmin(List<String> roles) {
  final normalized = roles
      .map((role) => role.trim().toUpperCase().replaceFirst('ROLE_', ''))
      .toSet();
  return normalized.contains('SOCIETY_ADMIN') ||
      normalized.contains('SUPER_ADMIN') ||
      normalized.contains('ADMIN');
}
