import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';

class CommonModulesScreen extends StatelessWidget {
  const CommonModulesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const ModulePlaceholderScreen(
      title: 'Common / Buyer',
      modules: [
        'Create new society',
        'Profile and account',
        'Society information and amenities',
        'Buildings, floors, committee members, and workers',
        'My flats and flat members',
        'Categories, tags, sellers, and marketplace',
        'Cart and checkout',
        'Orders and refunds',
        'Payments and wallet',
        'Reviews',
        'Community posts and chats',
        'Events and polls',
      ],
    );
  }
}

class ModulePlaceholderScreen extends StatelessWidget {
  const ModulePlaceholderScreen({super.key, required this.title, required this.modules});

  final String title;
  final List<String> modules;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title, style: GoogleFonts.hind())),
      body: ListView.separated(
        padding: const EdgeInsets.all(24),
        itemCount: modules.length,
        separatorBuilder: (_, _) => const Gap(8),
        itemBuilder: (context, index) => Card(
          child: ListTile(
            leading: const HugeIcon(icon: HugeIcons.strokeRoundedCircleCheck),
            title: Text(modules[index], style: GoogleFonts.hind()),
            subtitle: Text(
              'Placeholder module. API integration will be added later.',
              style: GoogleFonts.hind(),
            ),
            trailing: const HugeIcon(icon: HugeIcons.strokeRoundedArrowRight01, size: 16),
            onTap: () {},
          ),
        ),
      ),
    );
  }
}
