import 'package:society_seva/features/auth/data/models/auth_tokens.dart';
import 'package:society_seva/features/auth/data/models/registration.dart';

abstract class AuthRepository {
  Future<AuthOtpSent> sendAuthOtp({required String mobileNumber});

  Future<AuthOtpVerification> verifyAuthOtp({
    required String registrationToken,
    required String otp,
  });

  Future<AuthOtpVerification> completeProfile(CompleteProfileRequest request);

  Future<AuthTokens> refresh({required String refreshToken});

  Future<void> logout({required String refreshToken});

  Future<AuthTokens> googleLogin({required String idToken});

}
