import 'package:society_seva/features/auth/data/models/auth_tokens.dart';
import 'package:society_seva/features/auth/domain/repositories/auth_repository.dart';

class GoogleLoginUseCase {
  const GoogleLoginUseCase(this.repository);

  final AuthRepository repository;

  Future<AuthTokens> call({required String idToken}) {
    return repository.googleLogin(idToken: idToken);
  }
}
