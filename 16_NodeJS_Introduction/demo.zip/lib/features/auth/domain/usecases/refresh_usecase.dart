import 'package:society_seva/features/auth/data/models/auth_tokens.dart';
import 'package:society_seva/features/auth/domain/repositories/auth_repository.dart';

class RefreshUseCase {
  const RefreshUseCase(this.repository);

  final AuthRepository repository;

  Future<AuthTokens> call({required String refreshToken}) {
    return repository.refresh(refreshToken: refreshToken);
  }
}
