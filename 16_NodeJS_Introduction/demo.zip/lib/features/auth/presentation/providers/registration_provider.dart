import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:smart_auth/smart_auth.dart';
import 'package:society_seva/core/config/app_config.dart';
import 'package:society_seva/core/providers/app_providers.dart';
import 'package:society_seva/core/storage/secure_storage.dart';
import 'package:society_seva/features/auth/data/models/registration.dart';
import 'package:society_seva/features/auth/presentation/providers/auth_provider.dart';

final registrationControllerProvider =
    StateNotifierProvider<RegistrationController, AsyncValue<PendingRegistration?>>((ref) {
      return RegistrationController(ref);
    });

class RegistrationController extends StateNotifier<AsyncValue<PendingRegistration?>> {
  RegistrationController(this._ref) : super(const AsyncValue.loading()) {
    _restore();
  }

  final Ref _ref;
  int _smsCaptureGeneration = 0;

  AppSecureStorage get _storage => _ref.read(secureStorageProvider);

  bool get _supportsSmsConsent => !kIsWeb && Platform.isAndroid;

  @override
  void dispose() {
    _smsCaptureGeneration++;
    if (_supportsSmsConsent) {
      unawaited(SmartAuth.instance.removeUserConsentApiListener());
    }
    super.dispose();
  }

  Future<void> _restore() async {
    state = await AsyncValue.guard(_storage.readPendingRegistration);
  }

  Future<void> sendOtp({required String mobileNumber}) async {
    final previous = AsyncData<PendingRegistration?>(state.valueOrNull);
    state = AsyncLoading<PendingRegistration?>().copyWithPrevious(previous);
    final generation = ++_smsCaptureGeneration;
    Future<String?>? smsCodeFuture;

    if (_supportsSmsConsent) {
      await SmartAuth.instance.removeUserConsentApiListener();
      smsCodeFuture = SmartAuth.instance.getSmsWithUserConsentApi().then((result) {
        return result.hasData ? result.requireData.code : null;
      });
    }

    final nextState = await AsyncValue.guard<PendingRegistration?>(() async {
      final result = await _ref
          .read(authRepositoryProvider)
          .sendAuthOtp(mobileNumber: mobileNumber);
      if (result.registrationToken.isEmpty) {
        throw StateError('The OTP response did not contain a registration token.');
      }

      final pending = PendingRegistration(
        registrationToken: result.registrationToken,
        mobileNumber: mobileNumber,
        developmentOtp: _ref.read(appConfigProvider).environment == AppEnvironment.development
            ? result.otp
            : null,
        expiresIn: result.expiresIn,
      );
      await _storage.savePendingRegistration(pending);
      return pending;
    });
    state = nextState.copyWithPrevious(previous);

    if (nextState.hasError || smsCodeFuture == null) {
      _smsCaptureGeneration++;
      if (_supportsSmsConsent) {
        unawaited(SmartAuth.instance.removeUserConsentApiListener());
      }
      return;
    }

    unawaited(_applyCapturedSmsCode(smsCodeFuture, generation));
  }

  Future<void> _applyCapturedSmsCode(Future<String?> smsCodeFuture, int generation) async {
    final code = await smsCodeFuture;
    if (code == null || code.isEmpty || generation != _smsCaptureGeneration) {
      return;
    }

    final pending = state.valueOrNull;
    if (pending == null || pending.profileCompletionRequired) {
      return;
    }

    state = AsyncValue.data(pending.copyWith(smsOtp: code));
  }

  void _stopSmsCapture() {
    _smsCaptureGeneration++;
    if (_supportsSmsConsent) {
      unawaited(SmartAuth.instance.removeUserConsentApiListener());
    }
  }

  Future<void> verifyOtp(String otp) async {
    final registration = state.valueOrNull;
    if (registration == null) {
      return;
    }
    _stopSmsCapture();

    final previous = AsyncData<PendingRegistration?>(registration);
    state = AsyncLoading<PendingRegistration?>().copyWithPrevious(previous);
    state = (await AsyncValue.guard<PendingRegistration?>(() async {
      final result = await _ref
          .read(authRepositoryProvider)
          .verifyAuthOtp(registrationToken: registration.registrationToken, otp: otp);

      if (result.nextStep == 'HOME') {
        final tokens = result.authTokens;
        if (tokens == null) {
          throw StateError('The authentication response did not contain tokens.');
        }
        await _ref.read(authControllerProvider.notifier).authenticate(tokens);
        await _storage.clearPendingRegistration();
        return null;
      }

      if (result.nextStep != 'COMPLETE_PROFILE' ||
          result.registrationToken == null ||
          result.registrationToken!.isEmpty) {
        throw StateError('The OTP verification response was not recognized.');
      }

      final updated = registration.copyWith(
        registrationToken: result.registrationToken,
        clearOtp: true,
        profileCompletionRequired: true,
        expiresIn: result.registrationExpiresIn,
      );
      await _storage.savePendingRegistration(updated);
      return updated;
    })).copyWithPrevious(previous);
  }

  Future<void> resendOtp() async {
    final registration = state.valueOrNull;
    if (registration == null) {
      return;
    }

    await sendOtp(mobileNumber: registration.mobileNumber);
  }

  Future<void> completeProfile({
    required String fullName,
    required String gender,
    required String preferredLanguage,
    required String email,
    required String dateOfBirth,
  }) async {
    final registration = state.valueOrNull;
    if (registration == null || !registration.profileCompletionRequired) {
      return;
    }
    _stopSmsCapture();

    final previous = AsyncData<PendingRegistration?>(registration);
    state = AsyncLoading<PendingRegistration?>().copyWithPrevious(previous);
    state = (await AsyncValue.guard<PendingRegistration?>(() async {
      final result = await _ref
          .read(authRepositoryProvider)
          .completeProfile(
            CompleteProfileRequest(
              registrationToken: registration.registrationToken,
              fullName: fullName,
              gender: gender,
              preferredLanguage: preferredLanguage,
              email: email,
              dateOfBirth: dateOfBirth,
            ),
          );
      final tokens = result.authTokens;
      if (result.nextStep != 'HOME' || tokens == null) {
        throw StateError('Profile completion did not return an authenticated session.');
      }
      await _ref.read(authControllerProvider.notifier).authenticate(tokens);
      await _storage.clearPendingRegistration();
      return null;
    })).copyWithPrevious(previous);
  }
}
