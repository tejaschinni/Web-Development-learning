import 'package:animated_custom_dropdown/custom_dropdown.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/core/localization/app_locale_provider.dart';
import 'package:society_seva/l10n/generated/app_localizations.dart';

class _C {
  static const ink = Color(0xFF0F3D2E);
  static const muted = Color(0xFF6B7A72);
  static const border = Color(0xFFD5DDD8);
  static const orange = Color(0xFFF58B5E);
  static const green = Color(0xFF3F9A3C);
  static const blue = Color(0xFFA9C4F2);
  static const blueS = Color.fromARGB(255, 237, 246, 255);
  static const blueIcon = Color(0xFF2F5BB7);
}

class FirstRunIntroScreen extends ConsumerWidget {
  const FirstRunIntroScreen({super.key, required this.onGetStarted});

  final Future<void> Function() onGetStarted;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final strings = AppLocalizations.of(context);
    final textTheme = GoogleFonts.hindTextTheme(Theme.of(context).textTheme);
    final foreground = const Color(0xFF173B31);
    final locale = ref.watch(appLocaleProvider);

    return Scaffold(
      backgroundColor: _C.blueS,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Background
          Image.asset(
            'assets/images/intro-bg.png',
            fit: BoxFit.fitWidth,
            alignment: Alignment.topCenter,
          ),

          SafeArea(
            child: GestureDetector(
              behavior: HitTestBehavior.translucent,
              onTap: () => FocusScope.of(context).unfocus(),
              // child: SingleChildScrollView(
              //   keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
              //   padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Align(
                    alignment: Alignment.centerRight,
                    child: _languagePicker(context, textTheme, foreground, locale, ref),
                  ),
                  _buildHeader(strings),

                  const Gap(16),
                  const _FeatureStrip(),
                  Expanded(child: SizedBox.shrink()),
                  const Gap(16),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 18),
                    alignment: Alignment.bottomCenter,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(30),
                        topRight: Radius.circular(30),
                      ),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Gap(22),
                        const Gap(22),
                        Text(
                          strings.introBrowse,
                          textAlign: TextAlign.center,
                          style: textTheme.titleMedium?.copyWith(
                            color: foreground,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const Gap(8),
                        Text(
                          strings.introMotto,
                          textAlign: TextAlign.center,
                          style: textTheme.bodyMedium?.copyWith(color: const Color(0xFF45675B)),
                        ),
                        const Gap(22),

                        const Gap(22),
                        SizedBox(
                          width: double.infinity,
                          height: 54,
                          child: FilledButton(
                            onPressed: onGetStarted,
                            style: FilledButton.styleFrom(
                              backgroundColor: const Color(0xFF177A50),
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                            ),
                            child: Text(
                              strings.introGetStarted,
                              style: textTheme.titleMedium?.copyWith(
                                color: Colors.white,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ),
                        const Gap(10),

                        const Gap(22),
                        const Gap(22),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          // ),
        ],
      ),
    );
  }

  // Widget _languagePicker(
  //   TextTheme textTheme,
  //   Color foreground,
  //   Locale selectedLocale,
  //   WidgetRef ref,
  // ) {
  //   return DropdownFlutter<String>(
  //     items: AppLocalizations.supportedLocales.map((locale) {
  //       return appLanguageNames[locale.languageCode]!;
  //     }).toList(),
  //     initialItem: selectedLocale.countryCode,
  //     decoration: CustomDropdownDecoration(
  //       prefixIcon: HugeIcon(icon: HugeIcons.strokeRoundedLanguages),
  //       closedFillColor: const Color(0xFFD4E4D6),
  //       closedBorderRadius: BorderRadius.circular(100),
  //       // headerStyle: TextStyle(color: Colors.green.shade900),
  //     ),
  //     onChanged: print,
  //
  //     // )
  //
  //     //   DropdownButtonHideUnderline(
  //     //     child: DropdownButton<Locale>(
  //     //       value: selectedLocale,
  //     //       icon: const Icon(Icons.keyboard_arrow_down, size: 18),
  //     //       style: textTheme.labelLarge?.copyWith(color: foreground, fontWeight: FontWeight.w600),
  //     //       items: AppLocalizations.supportedLocales.map((locale) {
  //     //         return DropdownMenuItem(
  //     //           value: locale,
  //     //           child: Row(
  //     //             mainAxisSize: MainAxisSize.min,
  //     //             children: [
  //     //               HugeIcon(icon: HugeIcons.strokeRoundedLanguages),
  //     //               const Gap(8),
  //     //               Text(appLanguageNames[locale.languageCode]!),
  //     //             ],
  //     //           ),
  //     //         );
  //     //       }).toList(),
  //     //       onChanged: (locale) {
  //     //         if (locale != null) {
  //     //           ref.read(appLocaleProvider.notifier).setLocale(locale);
  //     //         }
  //     //       },
  //     // ),
  //   );
  // }

  Widget _languagePicker(
    BuildContext context,
    TextTheme textTheme,
    Color foreground,
    Locale selectedLocale,
    WidgetRef ref,
  ) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    // Theme-aware color palette
    final surfaceColor = isDark ? const Color(0xFF1E293B) : const Color(0xFFF1F5F9);
    final borderColor = isDark
        ? Colors.white.withValues(alpha: 0.1)
        : Colors.black.withValues(alpha: 0.06);
    final activeTextColor = isDark ? const Color(0xFFF8FAFC) : const Color(0xFF0F172A);

    final List<Locale> locales = AppLocalizations.supportedLocales;

    return SizedBox(
      width: 175,
      child: CustomDropdown<Locale>(
        items: locales,
        initialItem: locales.firstWhere(
          (l) => l.languageCode == selectedLocale.languageCode,
          orElse: () => locales.first,
        ),
        headerBuilder: (context, selectedItem, enabled) {
          return Row(
            children: [
              HugeIcon(
                icon: HugeIcons.strokeRoundedLanguages,
                color: activeTextColor.withValues(alpha: 0.8),
                size: 18.0,
              ),
              const Gap(10),
              Expanded(
                child: Text(
                  appLanguageNames[selectedItem.languageCode] ??
                      selectedItem.languageCode.toUpperCase(),
                  style: textTheme.labelMedium?.copyWith(
                    color: activeTextColor,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.2,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          );
        },
        listItemBuilder: (context, item, isSelected, onItemSelect) {
          return Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: isSelected
                  ? Theme.of(context).primaryColor.withValues(alpha: 0.1)
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                HugeIcon(icon: HugeIcons.strokeRoundedLanguages),
                const Gap(10),
                Expanded(
                  child: Text(
                    appLanguageNames[item.languageCode] ?? item.languageCode,
                    style: textTheme.bodyMedium?.copyWith(
                      color: isSelected ? Theme.of(context).primaryColor : activeTextColor,
                      fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                    ),
                  ),
                ),
                if (isSelected)
                  Icon(Icons.check_circle_rounded, size: 16, color: Theme.of(context).primaryColor),
              ],
            ),
          );
        },
        decoration: CustomDropdownDecoration(
          closedFillColor: surfaceColor,
          expandedFillColor: isDark ? const Color(0xFF1E293B) : Colors.white,
          closedBorderRadius: BorderRadius.circular(30),
          expandedBorderRadius: BorderRadius.circular(20),
          closedBorder: Border.all(color: borderColor, width: 1),
          expandedBorder: Border.all(color: borderColor, width: 1),
          closedShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.04),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
          expandedShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.12),
              blurRadius: 20,
              offset: const Offset(0, 8),
            ),
          ],
          closedSuffixIcon: HugeIcon(
            icon: HugeIcons.strokeRoundedArrowDown01,
            color: activeTextColor.withValues(alpha: 0.6),
            size: 16.0,
          ),
          expandedSuffixIcon: HugeIcon(
            icon: HugeIcons.strokeRoundedArrowUp01,
            color: Theme.of(context).primaryColor,
            size: 16.0,
          ),
        ),
        onChanged: (locale) {
          if (locale != null) {
            ref.read(appLocaleProvider.notifier).setLocale(locale);
          }
        },
      ),
    );
  }

  Widget _buildHeader(AppLocalizations strings) {
    return Column(
      children: [
        Image.asset('assets/images/logo/logo.png', height: 150, fit: BoxFit.contain),
        const Gap(4),
        Text(
          strings.introTagline,
          textAlign: TextAlign.center,
          style: GoogleFonts.hind(
            fontSize: 17,
            fontWeight: FontWeight.w500,
            color: const Color(0xFF1B3A5C),
          ),
        ),
      ],
    );
  }
}

// I NEED / I HAVE / MATCH ME
class _FeatureStrip extends StatelessWidget {
  const _FeatureStrip();

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 18, vertical: 8),
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.55),
        borderRadius: BorderRadius.circular(20),
      ),
      child: IntrinsicHeight(
        child: Row(
          children: [
            const Expanded(
              child: _FeatureItem(
                title: 'I NEED',
                subtitle: 'Find what\nyou need',
                icon: HugeIcons.strokeRoundedShoppingCart02,
                circleColor: _C.orange,
                iconColor: Colors.white,
              ),
            ),
            _divider(),
            const Expanded(
              child: _FeatureItem(
                title: 'I HAVE',
                subtitle: 'Offer what\nyou have',
                icon: HugeIcons.strokeRoundedTag01,
                circleColor: _C.green,
                iconColor: Colors.white,
              ),
            ),
            _divider(),
            const Expanded(
              child: _FeatureItem(
                title: 'MATCH ME',
                subtitle: 'Connect with\nthe right person',
                icon: HugeIcons.strokeRoundedUserGroup,
                circleColor: _C.blue,
                iconColor: _C.blueIcon,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _divider() =>
      VerticalDivider(width: 1, thickness: 1, color: _C.border.withValues(alpha: 0.9));
}

class _FeatureItem extends StatelessWidget {
  const _FeatureItem({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.circleColor,
    required this.iconColor,
  });

  final String title;
  final String subtitle;
  final List<List<dynamic>> icon;
  final Color circleColor;
  final Color iconColor;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 60,
          height: 60,
          decoration: BoxDecoration(
            color: circleColor,
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: circleColor.withValues(alpha: 0.35),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          alignment: Alignment.center,
          child: HugeIcon(icon: icon, color: iconColor, size: 28),
        ),
        const Gap(8),
        Text(
          title,
          style: GoogleFonts.hind(fontSize: 16, fontWeight: FontWeight.w700, color: _C.ink),
        ),
        const Gap(2),
        Text(
          subtitle,
          textAlign: TextAlign.center,
          style: GoogleFonts.hind(fontSize: 13, height: 1.25, color: _C.muted),
        ),
      ],
    );
  }
}
