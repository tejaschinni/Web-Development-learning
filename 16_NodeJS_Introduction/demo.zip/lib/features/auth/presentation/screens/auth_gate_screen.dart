import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/core/storage/local_cache.dart';
import 'package:society_seva/features/auth/data/services/google_auth_service.dart';
import 'package:society_seva/features/auth/presentation/providers/auth_provider.dart';
import 'package:society_seva/features/auth/presentation/providers/registration_provider.dart';
import 'package:society_seva/features/auth/presentation/screens/first_run_intro_screen.dart';
import 'package:society_seva/features/profile/presentation/providers/profile_provider.dart';

class AuthGateScreen extends ConsumerStatefulWidget {
  const AuthGateScreen({super.key});

  @override
  ConsumerState<AuthGateScreen> createState() => _AuthGateScreenState();
}

class _AuthGateScreenState extends ConsumerState<AuthGateScreen> {
  static const _introKey = 'app:intro';

  bool? _hasSeenIntro;

  @override
  void initState() {
    super.initState();
    _hasSeenIntro = LocalCache.instance.readJsonSync(_introKey)?['seen'] == true;
  }

  Future<void> _finishIntro() async {
    unawaited(_persistIntroStatus());
    setState(() => _hasSeenIntro = true);
    context.go('/login');
  }

  Future<void> _persistIntroStatus() async {
    try {
      await LocalCache.instance.writeJson(_introKey, {'seen': true});
    } catch (_) {
      // The intro will be shown again if local persistence is unavailable.
    }
  }

  @override
  Widget build(BuildContext context) {
    final authState = ref.watch(authControllerProvider);
    final registrationState = ref.watch(registrationControllerProvider);
    final pending = registrationState.valueOrNull;
    final isLoading = authState.isLoading;

    if (!_hasSeenIntro!) {
      return FirstRunIntroScreen(onGetStarted: _finishIntro);
    }

    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const HugeIcon(
                    icon: HugeIcons.strokeRoundedUserSquare,
                    size: 72,
                    color: Colors.green,
                  ),
                  const Gap(24),
                  Text(
                    'Welcome back',
                    textAlign: TextAlign.center,
                    style: GoogleFonts.hind(fontSize: 28, fontWeight: FontWeight.w700),
                  ),
                  const Gap(12),
                  Text(
                    'Sign in to continue to Society Seva.',
                    textAlign: TextAlign.center,
                    style: GoogleFonts.hind(textStyle: Theme.of(context).textTheme.bodyLarge),
                  ),
                  const Gap(32),
                  FilledButton.icon(
                    onPressed: isLoading
                        ? null
                        : () {
                            ref.read(authControllerProvider.notifier).clearError();
                            context.go('/login');
                          },
                    icon: const HugeIcon(icon: HugeIcons.strokeRoundedLogin02),
                    label: Text('Login', style: GoogleFonts.hind()),
                  ),
                  const Gap(16),
                  if (pending != null) ...[
                    const Gap(16),
                    Text(
                      'Sign-in in progress for ${pending.mobileNumber}',
                      textAlign: TextAlign.center,
                      style: GoogleFonts.hind(),
                    ),
                    const Gap(8),
                    TextButton(
                      onPressed: isLoading
                          ? null
                          : () {
                              context.go(
                                pending.profileCompletionRequired
                                    ? '/complete-profile'
                                    : '/verify-otp',
                              );
                            },
                      child: Text('Resume registration', style: GoogleFonts.hind()),
                    ),
                  ],
                  const Gap(16),
                  OutlinedButton.icon(
                    onPressed: isLoading ? null : () => _googleLogin(context, ref),
                    icon: const HugeIcon(icon: HugeIcons.strokeRoundedGoogle),
                    label: Text('Continue with Google', style: GoogleFonts.hind()),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _googleLogin(BuildContext context, WidgetRef ref) async {
    try {
      final service = GoogleAuthService();
      final idToken = await service.signIn();

      if (idToken == null || !context.mounted) {
        return;
      }

      await ref.read(authControllerProvider.notifier).googleLogin(idToken: idToken);

      if (context.mounted &&
          ref.read(authControllerProvider).valueOrNull?.isAuthenticated == true) {
        try {
          final profile = await ref.read(profileRepositoryProvider).getCurrentUser();
          if (!context.mounted) {
            return;
          }
          context.go(profile.mobileNumber.trim().isEmpty ? '/phone-number' : '/');
        } catch (error) {
          if (!context.mounted) {
            return;
          }
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Unable to load your profile: $error', style: GoogleFonts.hind()),
            ),
          );
          context.go('/');
        }
      }
    } catch (error) {
      if (!context.mounted) {
        return;
      }

      final message = error.toString().contains('canceled')
          ? 'Google sign-in was cancelled.'
          : 'Google sign-in failed. Please try again.';
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(message, style: GoogleFonts.hind())));
    }
  }
}
