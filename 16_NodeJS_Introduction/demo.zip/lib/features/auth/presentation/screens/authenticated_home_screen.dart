import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/features/auth/presentation/providers/auth_provider.dart';
import 'package:society_seva/features/dashboard/presentation/screens/dashboard_home_screen.dart';
import 'package:society_seva/features/dashboard/presentation/screens/profile_load_error_screen.dart';
import 'package:society_seva/features/dashboard/presentation/screens/services_placeholder_screen.dart';
import 'package:society_seva/features/profile/presentation/providers/profile_provider.dart';
import 'package:society_seva/features/profile/presentation/screens/profile_screen.dart';
import 'package:society_seva/features/profile/presentation/widgets/seller_mode_app_bar_action.dart';
import 'package:society_seva/features/shop/presentation/screens/seva_home_screen.dart';
import 'package:society_seva/features/location/presentation/widgets/location_header_button.dart';
import 'package:society_seva/features/location/presentation/providers/location_provider.dart';

class AuthenticatedHomeScreen extends ConsumerStatefulWidget {
  const AuthenticatedHomeScreen({super.key, this.bypassResidentGate = false});

  final bool bypassResidentGate;

  @override
  ConsumerState<AuthenticatedHomeScreen> createState() => _AuthenticatedHomeScreenState();
}

class _AuthenticatedHomeScreenState extends ConsumerState<AuthenticatedHomeScreen> {
  int _selectedTab = 0;
  bool _locationRedirectScheduled = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        ref.read(profileControllerProvider.notifier).load(force: true);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final profileState = ref.watch(profileControllerProvider);
    final locationState = ref.watch(locationContextProvider);
    if (locationState.hasValue &&
        locationState.value!.activeAddress == null &&
        !_locationRedirectScheduled) {
      _locationRedirectScheduled = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) context.push('/locations');
      });
    }
    if (locationState.valueOrNull?.activeAddress != null) {
      _locationRedirectScheduled = false;
    }
    final pages = [
      SevaHomeScreen(),
      _homeDashboard(profileState),
      const ServicesPlaceholderScreen(),
      // const SocietyDetailsScreen(societyId: null),
      ProfileScreen(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Image.asset(
              'assets/images/logo/v-logo-big.png',
              fit: BoxFit.scaleDown,
              height: 35,
              alignment: Alignment.centerLeft,
            ),
            const Gap(10),
            Flexible(child: LocationHeaderButton(compact: true)),
          ],
        ),
        actions: [
          const SellerModeAppBarAction(),
          IconButton(
            onPressed: () {},
            icon: const HugeIcon(icon: HugeIcons.strokeRoundedNotification01),
            tooltip: 'Notification',
          ),
          IconButton(
            onPressed: _logout,
            icon: const HugeIcon(icon: HugeIcons.strokeRoundedLogout02),
            tooltip: 'Logout',
          ),
        ],
      ),
      body: pages[_selectedTab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedTab,
        onDestinationSelected: (index) => setState(() => _selectedTab = index),
        destinations: const [
          NavigationDestination(
            icon: HugeIcon(icon: HugeIcons.strokeRoundedStore03),
            label: 'Home',
          ),
          NavigationDestination(
            icon: HugeIcon(icon: HugeIcons.strokeRoundedSearch01),
            label: 'Explore',
          ),
          NavigationDestination(
            icon: HugeIcon(icon: HugeIcons.strokeRoundedComment03),
            label: 'Chat',
          ),
          NavigationDestination(
            icon: HugeIcon(icon: HugeIcons.strokeRoundedUser),
            label: 'Profile',
          ),
        ],
      ),
    );
  }

  Widget _homeDashboard(ProfileState profileState) {
    if (profileState.status == ProfileStatus.loading ||
        profileState.status == ProfileStatus.initial) {
      return const Center(child: CircularProgressIndicator());
    }
    if (profileState.profile == null) {
      return ProfileLoadErrorScreen(
        message: profileState.errorMessage ?? 'Unable to load profile.',
        onRetry: () => ref.read(profileControllerProvider.notifier).load(force: true),
      );
    }
    return DashboardHomeScreen(
      fullName: profileState.profile!.fullName,
      roles: profileState.profile!.roles,
    );
  }

  Future<void> _logout() async {
    final shouldLogout = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Log out?', style: GoogleFonts.hind()),
        content: Text('Are you sure you want to logout?', style: GoogleFonts.hind()),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: Text('Cancel', style: GoogleFonts.hind()),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: Text('Logout', style: GoogleFonts.hind()),
          ),
        ],
      ),
    );
    if (shouldLogout != true || !mounted) return;
    final failureMessage = await ref.read(authControllerProvider.notifier).logout();
    if (failureMessage != null && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Signed out locally, but server logout failed: $failureMessage',
            style: GoogleFonts.hind(),
          ),
        ),
      );
    }
  }
}
