import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';

import 'package:society_seva/core/storage/local_cache.dart';
import 'package:society_seva/features/auth/data/services/google_auth_service.dart';
import 'package:society_seva/features/auth/data/models/registration.dart';
import 'package:society_seva/features/auth/presentation/providers/auth_provider.dart';
import 'package:society_seva/features/auth/presentation/providers/registration_provider.dart';
import 'package:society_seva/features/auth/presentation/screens/first_run_intro_screen.dart';
import 'package:society_seva/features/guest/presentation/providers/guest_provider.dart';
import 'package:society_seva/features/profile/presentation/providers/profile_provider.dart';

// Design tokens
class _C {
  static const bg = Color(0xFFE6F0E8);
  static const ink = Color(0xFF0F3D2E);
  static const muted = Color(0xFF6B7A72);
  static const primary = Color(0xFF14735A);
  static const border = Color(0xFFD5DDD8);
  static const orange = Color(0xFFF58B5E);
  static const green = Color(0xFF3F9A3C);
  static const blue = Color(0xFFA9C4F2);
  static const blueIcon = Color(0xFF2F5BB7);
  static const link = Color(0xFF14735A);
}

class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});

  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  final _phoneNumberController = TextEditingController();
  static const _introKey = 'app:intro';

  bool? _hasSeenIntro;

  @override
  void initState() {
    super.initState();
    _hasSeenIntro = LocalCache.instance.readJsonSync(_introKey)?['seen'] == true;
  }

  Future<void> _finishIntro() async {
    unawaited(_persistIntroStatus());
    setState(() => _hasSeenIntro = true);
    context.go('/login');
  }

  Future<void> _persistIntroStatus() async {
    try {
      await LocalCache.instance.writeJson(_introKey, {'seen': true});
    } catch (_) {
      // The intro will be shown again if local persistence is unavailable.
    }
  }

  @override
  void dispose() {
    _phoneNumberController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authState = ref.watch(authControllerProvider);
    final registrationState = ref.watch(registrationControllerProvider);
    ref.listen(registrationControllerProvider, (previous, next) {
      final pending = next.valueOrNull;
      if (pending == null || previous?.valueOrNull != null) {
        return;
      }
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) {
          return;
        }
        context.go(pending.profileCompletionRequired ? '/complete-profile' : '/verify-otp');
      });
    });
    final isLoading = authState.isLoading || registrationState.isLoading;

    if (!_hasSeenIntro!) {
      return FirstRunIntroScreen(onGetStarted: _finishIntro);
    }

    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Background
          Image.asset(
            'assets/images/nav-bg.png',
            fit: BoxFit.fitWidth,
            alignment: Alignment.bottomCenter,
          ),
          SafeArea(
            child: GestureDetector(
              behavior: HitTestBehavior.translucent,
              onTap: () => FocusScope.of(context).unfocus(),
              child: SingleChildScrollView(
                keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _buildBackButton(context),
                    _buildHeader(),
                    const Gap(14),
                    const _FeatureStrip(),
                    const Gap(14),
                    _buildLoginCard(authState, registrationState, isLoading),
                    const Gap(14),
                    _ExploreCard(onTap: _startGuestSession),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Sections
  Widget _buildBackButton(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: IconButton(
        onPressed: () {
          if (context.canPop()) context.pop();
        },
        icon: const HugeIcon(icon: HugeIcons.strokeRoundedArrowLeft01, color: _C.ink, size: 26),
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      children: [
        Image.asset('assets/images/logo/logo.png', height: 110, fit: BoxFit.contain),
        const Gap(12),
        Text(
          'Your Community. Your Marketplace.',
          textAlign: TextAlign.center,
          style: GoogleFonts.hind(
            fontSize: 17,
            fontWeight: FontWeight.w500,
            color: const Color(0xFF1B3A5C),
          ),
        ),
      ],
    );
  }

  Widget _buildLoginCard(
    AsyncValue<dynamic> authState,
    AsyncValue<PendingRegistration?> registrationState,
    bool isLoading,
  ) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 16),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.82),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 20,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        children: [
          Text(
            'Continue with mobile',
            style: GoogleFonts.hind(fontSize: 20, fontWeight: FontWeight.w700, color: _C.ink),
          ),
          const Gap(2),
          Text(
            'Enter your mobile number to continue',
            style: GoogleFonts.hind(fontSize: 12, color: _C.muted),
          ),
          const Gap(12),
          _PhoneField(controller: _phoneNumberController, enabled: !isLoading),
          if (registrationState.hasError || authState.hasError) ...[
            const Gap(10),
            Text(
              (registrationState.error ?? authState.error).toString(),
              textAlign: TextAlign.center,
              style: GoogleFonts.hind(color: Colors.red.shade700, fontSize: 13),
            ),
          ],
          const Gap(14),
          SizedBox(
            height: 44,
            child: FilledButton(
              onPressed: isLoading ? null : _login,
              style: FilledButton.styleFrom(
                backgroundColor: _C.primary,
                disabledBackgroundColor: _C.primary.withValues(alpha: 0.6),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              child: isLoading
                  ? const SizedBox(
                      height: 22,
                      width: 22,
                      child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white),
                    )
                  : Text(
                      'Send OTP',
                      style: GoogleFonts.hind(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
            ),
          ),
          const Gap(12),
          _buildOrDivider(),
          const Gap(12),
          Row(
            children: [
              Expanded(
                child: _SocialButton(
                  label: 'Google',
                  icon: HugeIcons.strokeRoundedGoogle,
                  onPressed: isLoading ? null : _googleLogin,
                ),
              ),
            ],
          ),
          const Gap(12),
          _buildTerms(),
        ],
      ),
    );
  }

  Widget _buildOrDivider() {
    return Row(
      children: [
        const Expanded(child: Divider(color: _C.border, thickness: 1)),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Text('OR', style: GoogleFonts.hind(color: _C.muted, fontSize: 14)),
        ),
        const Expanded(child: Divider(color: _C.border, thickness: 1)),
      ],
    );
  }

  Widget _buildTerms() {
    final base = GoogleFonts.hind(fontSize: 14, color: _C.muted);
    final link = GoogleFonts.hind(fontSize: 14, color: _C.link, fontWeight: FontWeight.w600);
    return Text.rich(
      textAlign: TextAlign.center,
      TextSpan(
        style: base,
        children: [
          const TextSpan(text: 'By continuing, you agree to our\n'),
          TextSpan(text: 'Terms of Service', style: link),
          const TextSpan(text: ' and '),
          TextSpan(text: 'Privacy Policy', style: link),
        ],
      ),
    );
  }

  // Auth logic
  Future<void> _login() async {
    await ref.read(guestAccessProvider.notifier).endSession();
    await ref
        .read(registrationControllerProvider.notifier)
        .sendOtp(mobileNumber: _phoneNumberController.text.trim());
  }

  Future<void> _googleLogin() async {
    try {
      await ref.read(guestAccessProvider.notifier).endSession();
      final idToken = await GoogleAuthService().signIn();

      if (idToken == null || !mounted) {
        return;
      }

      await ref.read(authControllerProvider.notifier).googleLogin(idToken: idToken);

      if (!mounted) {
        return;
      }

      if (ref.read(authControllerProvider).valueOrNull?.isAuthenticated == true) {
        try {
          final profile = await ref.read(profileRepositoryProvider).getCurrentUser();
          if (!mounted) {
            return;
          }
          context.go(profile.mobileNumber.trim().isEmpty ? '/phone-number' : '/');
        } catch (error) {
          if (!mounted) {
            return;
          }
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Unable to load your profile: $error', style: GoogleFonts.hind()),
            ),
          );
          context.go('/');
        }
      }
    } catch (error) {
      if (!mounted) {
        return;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Google sign-in failed: $error', style: GoogleFonts.hind())),
      );
    }
  }

  Future<void> _startGuestSession() async {
    try {
      final session = await ref.read(guestAccessProvider.notifier).startSession();
      if (!mounted) return;
      context.go('/guest', extra: session.nearestSocietyId);
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Unable to start guest browsing: $error', style: GoogleFonts.hind()),
        ),
      );
    }
  }
}

// I NEED / I HAVE / MATCH ME
class _FeatureStrip extends StatelessWidget {
  const _FeatureStrip();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.35),
        borderRadius: BorderRadius.circular(20),
      ),
      child: IntrinsicHeight(
        child: Row(
          children: [
            const Expanded(
              child: _FeatureItem(
                title: 'I NEED',
                subtitle: 'Find what\nyou need',
                icon: HugeIcons.strokeRoundedShoppingCart02,
                circleColor: _C.orange,
                iconColor: Colors.white,
              ),
            ),
            _divider(),
            const Expanded(
              child: _FeatureItem(
                title: 'I HAVE',
                subtitle: 'Offer what\nyou have',
                icon: HugeIcons.strokeRoundedTag01,
                circleColor: _C.green,
                iconColor: Colors.white,
              ),
            ),
            _divider(),
            const Expanded(
              child: _FeatureItem(
                title: 'MATCH ME',
                subtitle: 'Connect with\nthe right person',
                icon: HugeIcons.strokeRoundedUserGroup,
                circleColor: _C.blue,
                iconColor: _C.blueIcon,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _divider() =>
      VerticalDivider(width: 1, thickness: 1, color: _C.border.withValues(alpha: 0.9));
}

class _FeatureItem extends StatelessWidget {
  const _FeatureItem({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.circleColor,
    required this.iconColor,
  });

  final String title;
  final String subtitle;
  final List<List<dynamic>> icon;
  final Color circleColor;
  final Color iconColor;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: circleColor,
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: circleColor.withValues(alpha: 0.35),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          alignment: Alignment.center,
          child: HugeIcon(icon: icon, color: iconColor, size: 22),
        ),
        const Gap(8),
        Text(
          title,
          style: GoogleFonts.hind(fontSize: 14, fontWeight: FontWeight.w700, color: _C.ink),
        ),
        const Gap(2),
        Text(
          subtitle,
          textAlign: TextAlign.center,
          style: GoogleFonts.hind(fontSize: 11, height: 1.25, color: _C.muted),
        ),
      ],
    );
  }
}

// Phone field with country selector
class _PhoneField extends StatelessWidget {
  const _PhoneField({required this.controller, required this.enabled});

  final TextEditingController controller;
  final bool enabled;

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      enabled: enabled,
      keyboardType: TextInputType.phone,
      autofillHints: const [AutofillHints.telephoneNumberNational],
      inputFormatters: [
        FilteringTextInputFormatter.digitsOnly,
        LengthLimitingTextInputFormatter(10),
      ],
      style: GoogleFonts.hind(fontSize: 18, color: _C.ink),
      decoration: InputDecoration(
        floatingLabelBehavior:
            FloatingLabelBehavior.always, // Forces prefix to stay visible when unfocused
        hintText: '98765 43210',
        hintStyle: GoogleFonts.hind(fontSize: 18, color: const Color(0xFF9AA5A0)),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
        prefixIcon: Padding(
          padding: const EdgeInsets.only(left: 16, right: 8),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                '+91',
                style: GoogleFonts.hind(
                  fontSize: 18,
                  color: const Color.fromARGB(255, 110, 117, 114),
                ),
              ),
            ],
          ),
        ),
        prefixIconConstraints: const BoxConstraints(minWidth: 0, minHeight: 0),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16),
      ),
    );
  }
}

// Social button
class _SocialButton extends StatelessWidget {
  const _SocialButton({required this.label, required this.icon, required this.onPressed});

  final String label;
  final List<List<dynamic>> icon;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 48,
      child: OutlinedButton(
        onPressed: onPressed,
        style: OutlinedButton.styleFrom(
          padding: const EdgeInsets.symmetric(horizontal: 6),
          backgroundColor: Colors.white,
          side: const BorderSide(color: _C.border),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            HugeIcon(icon: icon, color: _C.ink, size: 22),
            const Gap(6),
            Flexible(
              child: Text(
                label,
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.hind(fontSize: 15, fontWeight: FontWeight.w500, color: _C.ink),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Explore without signing in
class _ExploreCard extends StatelessWidget {
  const _ExploreCard({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withValues(alpha: 0.55),
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      'Explore without signing in',
                      style: GoogleFonts.hind(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: _C.ink,
                      ),
                    ),
                  ),
                  const HugeIcon(
                    icon: HugeIcons.strokeRoundedArrowRight01,
                    color: _C.ink,
                    size: 22,
                  ),
                ],
              ),
              const Gap(2),
              Text(
                'Browse products, services and people near you',
                style: GoogleFonts.hind(fontSize: 14, height: 1.3, color: _C.muted),
              ),
              const Gap(10),
              const Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  _Chip(label: 'View listings', icon: HugeIcons.strokeRoundedSearch01),
                  _Chip(label: 'Check prices', icon: HugeIcons.strokeRoundedLocation01),
                  _Chip(
                    label: 'Explore categories',
                    icon: HugeIcons.strokeRoundedDashboardSquare01,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  const _Chip({required this.label, required this.icon});

  final String label;
  final List<List<dynamic>> icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.85),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _C.border),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          HugeIcon(icon: icon, color: _C.ink, size: 16),
          const Gap(5),
          Text(label, style: GoogleFonts.hind(fontSize: 12, color: _C.ink)),
        ],
      ),
    );
  }
}
