import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';

class AppStartupScreen extends StatelessWidget {
  const AppStartupScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: const Color(0xFFF5F8F2),
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Image.asset('assets/images/logo/v-logo-big.png', height: 76, fit: BoxFit.contain),
                const Gap(20),
                Text(
                  'Your community, closer.',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.hind(
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                    color: theme.colorScheme.primary,
                  ),
                ),
                const Gap(8),
                Text(
                  'Getting your Society Seva ready',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.hind(fontSize: 14, color: theme.colorScheme.onSurfaceVariant),
                ),
                const Gap(22),
                SizedBox(
                  width: 148,
                  child: LinearProgressIndicator(
                    minHeight: 4,
                    borderRadius: BorderRadius.circular(8),
                    backgroundColor: const Color(0xFFDDE8DD),
                    color: theme.colorScheme.primary,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
