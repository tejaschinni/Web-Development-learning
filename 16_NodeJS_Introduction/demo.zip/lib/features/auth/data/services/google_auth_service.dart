import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:google_sign_in/google_sign_in.dart';

const _defaultGoogleServerClientId =
    '1011725688131-m2q71polapnqtnlbesbc15nre3o3o73m.apps.googleusercontent.com';

class GoogleAuthService {
  GoogleAuthService();

  final GoogleSignIn _googleSignIn = GoogleSignIn.instance;
  bool _initialized = false;

  Future<void> _ensureInitialized() async {
    if (!_initialized) {
      final serverClientId = dotenv.isInitialized
          ? dotenv.env['GOOGLE_SERVER_CLIENT_ID']?.trim()
          : null;
      await _googleSignIn.initialize(
        serverClientId: serverClientId == null || serverClientId.isEmpty
            ? const String.fromEnvironment(
                'GOOGLE_SERVER_CLIENT_ID',
                defaultValue: _defaultGoogleServerClientId,
              )
            : serverClientId,
      );
      _initialized = true;
    }
  }

  Future<String?> signIn() async {
    await _ensureInitialized();

    await _googleSignIn.signOut();
    final account = await _googleSignIn.authenticate();
    final authentication = account.authentication;
    return authentication.idToken;
  }

  Future<void> signOut() async {
    await _ensureInitialized();
    await _googleSignIn.signOut();
  }
}
