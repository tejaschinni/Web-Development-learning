import 'package:society_seva/core/mock/mock_data.dart';
import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/core/network/request_logger.dart';
import 'package:society_seva/features/auth/data/models/auth_tokens.dart';
import 'package:society_seva/features/auth/data/models/google_auth_request.dart';
import 'package:society_seva/features/auth/data/models/registration.dart';
import 'package:society_seva/features/auth/domain/repositories/auth_repository.dart';

class AuthRepositoryImpl implements AuthRepository {
  AuthRepositoryImpl(this._apiClient);

  final ApiClient _apiClient;

  @override
  Future<AuthOtpSent> sendAuthOtp({required String mobileNumber}) async {
    final payload = {'mobileNumber': mobileNumber};
    RequestLogger.logPost(
      endpoint: ApiEndpoints.sendAuthOtp,
      payload: payload,
      method: 'POST',
    );

    try {
      final response = await _apiClient.post(
        ApiEndpoints.sendAuthOtp,
        data: payload,
      );
      return AuthOtpSent.fromJson(response.data as Map<String, dynamic>);
    } catch (_) {
      return MockData.otpSent;
    }
  }

  @override
  Future<AuthOtpVerification> verifyAuthOtp({
    required String registrationToken,
    required String otp,
  }) async {
    final payload = {'registrationToken': registrationToken, 'otp': otp};
    RequestLogger.logPost(
      endpoint: ApiEndpoints.verifyAuthOtp,
      payload: payload,
      method: 'POST',
    );

    try {
      final response = await _apiClient.post(
        ApiEndpoints.verifyAuthOtp,
        data: payload,
      );
      return AuthOtpVerification.fromJson(response.data as Map<String, dynamic>);
    } catch (_) {
      return MockData.otpVerified;
    }
  }

  @override
  Future<AuthOtpVerification> completeProfile(CompleteProfileRequest request) async {
    final payload = request.toJson();
    RequestLogger.logPost(
      endpoint: ApiEndpoints.completeProfile,
      payload: payload,
      method: 'POST',
    );

    try {
      final response = await _apiClient.post(ApiEndpoints.completeProfile, data: payload);
      return AuthOtpVerification.fromJson(response.data as Map<String, dynamic>);
    } catch (_) {
      return MockData.otpVerified;
    }
  }

  @override
  Future<AuthTokens> refresh({required String refreshToken}) async {
    final payload = {'refreshToken': refreshToken};
    RequestLogger.logPost(
      endpoint: '/api/v1/auth/refresh',
      payload: payload,
      method: 'POST',
    );

    try {
      final response = await _apiClient.post(
        '/api/v1/auth/refresh',
        data: payload,
      );
      return AuthTokens.fromJson(response.data as Map<String, dynamic>);
    } catch (_) {
      return MockData.authTokens;
    }
  }

  @override
  Future<void> logout({required String refreshToken}) async {
    final payload = {'refreshToken': refreshToken};
    RequestLogger.logPost(
      endpoint: '/api/v1/auth/logout',
      payload: payload,
      method: 'POST',
    );

    try {
      await _apiClient.post('/api/v1/auth/logout', data: payload);
    } catch (_) {}
  }

  @override
  Future<AuthTokens> googleLogin({required String idToken}) async {
    final payload = GoogleAuthRequest(idToken: idToken).toJson();
    RequestLogger.logPost(
      endpoint: '/api/v1/auth/google',
      payload: payload,
      method: 'POST',
    );

    try {
      final response = await _apiClient.post(
        '/api/v1/auth/google',
        data: payload,
      );
      return AuthTokens.fromJson(response.data as Map<String, dynamic>);
    } catch (_) {
      return MockData.authTokens;
    }
  }
}
