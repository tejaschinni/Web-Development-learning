class GoogleAuthRequest {
  const GoogleAuthRequest({required this.idToken});

  final String idToken;

  Map<String, dynamic> toJson() => {'idToken': idToken};
}
