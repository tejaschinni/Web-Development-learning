import 'package:society_seva/features/auth/data/models/auth_tokens.dart';

class PendingRegistration {
  const PendingRegistration({
    required this.registrationToken,
    required this.mobileNumber,
    this.developmentOtp,
    this.smsOtp,
    this.profileCompletionRequired = false,
    this.expiresIn = 0,
  });

  final String registrationToken;
  final String mobileNumber;
  final String? developmentOtp;
  final String? smsOtp;
  final bool profileCompletionRequired;
  final int expiresIn;

  PendingRegistration copyWith({
    String? registrationToken,
    String? developmentOtp,
    String? smsOtp,
    bool clearOtp = false,
    bool? profileCompletionRequired,
    int? expiresIn,
  }) {
    return PendingRegistration(
      registrationToken: registrationToken ?? this.registrationToken,
      mobileNumber: mobileNumber,
      developmentOtp: clearOtp ? null : developmentOtp ?? this.developmentOtp,
      smsOtp: clearOtp ? null : smsOtp ?? this.smsOtp,
      profileCompletionRequired: profileCompletionRequired ?? this.profileCompletionRequired,
      expiresIn: expiresIn ?? this.expiresIn,
    );
  }

  Map<String, dynamic> toJson() => {
    'registrationToken': registrationToken,
    'mobileNumber': mobileNumber,
    if (developmentOtp != null) 'developmentOtp': developmentOtp,
    'profileCompletionRequired': profileCompletionRequired,
    'expiresIn': expiresIn,
  };

  factory PendingRegistration.fromJson(Map<String, dynamic> json) {
    return PendingRegistration(
      registrationToken: json['registrationToken'] as String? ?? '',
      mobileNumber: json['mobileNumber'] as String? ?? '',
      developmentOtp: json['developmentOtp'] as String?,
      profileCompletionRequired: json['profileCompletionRequired'] as bool? ?? false,
      expiresIn: json['expiresIn'] as int? ?? 0,
    );
  }
}

class AuthOtpSent {
  const AuthOtpSent({required this.registrationToken, required this.expiresIn, this.otp});

  final String registrationToken;
  final int expiresIn;
  final String? otp;

  factory AuthOtpSent.fromJson(Map<String, dynamic> json) {
    return AuthOtpSent(
      registrationToken: json['registrationToken'] as String? ?? '',
      expiresIn: json['expiresIn'] as int? ?? 0,
      otp: json['otp'] as String?,
    );
  }
}

class AuthOtpVerification {
  const AuthOtpVerification({
    required this.nextStep,
    this.registrationToken,
    this.registrationExpiresIn = 0,
    this.authTokens,
  });

  final String nextStep;
  final String? registrationToken;
  final int registrationExpiresIn;
  final AuthTokens? authTokens;

  factory AuthOtpVerification.fromJson(Map<String, dynamic> json) {
    final auth = json['auth'];
    return AuthOtpVerification(
      nextStep: json['nextStep'] as String? ?? '',
      registrationToken: json['registrationToken'] as String?,
      registrationExpiresIn: json['registrationExpiresIn'] as int? ?? 0,
      authTokens: auth is Map ? AuthTokens.fromJson(Map<String, dynamic>.from(auth)) : null,
    );
  }
}

class CompleteProfileRequest {
  const CompleteProfileRequest({
    required this.registrationToken,
    required this.fullName,
    required this.gender,
    required this.preferredLanguage,
    required this.email,
    required this.dateOfBirth,
  });

  final String registrationToken;
  final String fullName;
  final String gender;
  final String preferredLanguage;
  final String email;
  final String dateOfBirth;

  Map<String, dynamic> toJson() => {
    'registrationToken': registrationToken,
    'fullName': fullName,
    'gender': gender,
    'preferredLanguage': preferredLanguage,
    'email': email,
    'dateOfBirth': dateOfBirth,
  };
}
