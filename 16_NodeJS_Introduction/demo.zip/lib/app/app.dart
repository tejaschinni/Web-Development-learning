import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/app/router/app_router.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/core/config/app_config.dart';
import 'package:society_seva/core/localization/app_locale_provider.dart';
import 'package:society_seva/core/network/request_logger.dart';
import 'package:society_seva/core/providers/app_providers.dart';
import 'package:society_seva/core/providers/user_session_reset.dart';
import 'package:society_seva/features/auth/presentation/providers/auth_provider.dart';
import 'package:society_seva/features/auth/presentation/providers/session_provider.dart';
import 'package:society_seva/features/profile/presentation/providers/user_mode_provider.dart';
import 'package:society_seva/l10n/generated/app_localizations.dart';

class SocietySevaApp extends StatelessWidget {
  const SocietySevaApp({super.key, required this.config, required this.initialMode});

  final AppConfig config;
  final UserMode initialMode;

  @override
  Widget build(BuildContext context) {
    return ProviderScope(
      overrides: [
        initialAppModeProvider.overrideWithValue(initialMode),
        appConfigProvider.overrideWithValue(config),
      ],
      child: _SocietySevaRouterApp(config: config),
    );
  }
}

class _SocietySevaRouterApp extends ConsumerStatefulWidget {
  const _SocietySevaRouterApp({required this.config});

  final AppConfig config;

  @override
  ConsumerState<_SocietySevaRouterApp> createState() => _SocietySevaRouterAppState();
}

class _SocietySevaRouterAppState extends ConsumerState<_SocietySevaRouterApp> {
  bool _hasObservedAuthState = false;
  String? _lastUserIdentity;

  @override
  Widget build(BuildContext context) {
    final currentAuth = ref.read(authControllerProvider).valueOrNull;
    if (currentAuth != null && !_hasObservedAuthState) {
      _lastUserIdentity = currentAuth.isAuthenticated ? _identityOf(currentAuth) : null;
      _hasObservedAuthState = true;
    }

    ref.listen(authControllerProvider, (_, next) {
      final sessionState = next.valueOrNull;
      if (sessionState != null) {
        final nextIdentity = sessionState.isAuthenticated ? _identityOf(sessionState) : null;
        if (_hasObservedAuthState && nextIdentity != _lastUserIdentity) {
          resetUserSessionState(ref);
        }
        _lastUserIdentity = nextIdentity;
        _hasObservedAuthState = true;
      }
      AppRouter.router.refresh();
    });
    final locale = ref.watch(appLocaleProvider);

    return MaterialApp.router(
      scaffoldMessengerKey: RequestLogger.scaffoldMessengerKey,
      title: widget.config.name,
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: ThemeMode.light,
      locale: locale,
      supportedLocales: AppLocalizations.supportedLocales,
      localizationsDelegates: const [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      routerConfig: AppRouter.router,
    );
  }

  String? _identityOf(AuthSessionState sessionState) {
    final token = sessionState.session?.accessToken;
    if (token == null || token.isEmpty) return null;
    final parts = token.split('.');
    if (parts.length < 2) return token;

    try {
      final payload = jsonDecode(utf8.decode(base64Url.decode(base64Url.normalize(parts[1]))));
      if (payload is Map) {
        final identity = payload['userId'] ?? payload['sub'] ?? payload['user_id'];
        if (identity != null && identity.toString().isNotEmpty) return identity.toString();
      }
    } catch (_) {
      return token;
    }
    return token;
  }
}
