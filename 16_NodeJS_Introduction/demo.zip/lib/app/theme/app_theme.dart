import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';

class AppColors {
  static const green = Color(0xFF0E4D2F);
  static const greenDeep = Color(0xFF0A3D24);
  static const greenSoft = Color(0xFFE6F3EA);
  static const orange = Color(0xFFF9A21B);
  static const orangeSoft = Color(0xFFFFF1D6);
  static const red = Color(0xFFE5342B);
  static const redSoft = Color(0xFFFDE6E4);
  static const blueSoft = Color(0xFFE3ECFB);
  static const blue = Color(0xFF3C6BDB);
  static const bg = Color(0xFFF7F8F4);
  static const ink = Color(0xFF1B1F1D);
  static const muted = Color(0xFF7A827D);
  static const border = Color(0xFFE4E8E3);
  static const navy = Color(0xFF0B2F6B);
}

typedef Icn = List<List<dynamic>>;

class AppTheme {
  /// Hind = primary text.
  static TextStyle hind(
    double size, {
    FontWeight w = FontWeight.w400,
    Color c = AppColors.ink,
    double? h,
  }) => GoogleFonts.hind(fontSize: size, fontWeight: w, color: c, height: h);

  static HugeIcon hi(Icn i, {Color c = AppColors.ink, double s = 22}) =>
      HugeIcon(icon: i, color: c, size: s);

  /// Plus Jakarta Sans = headings, prices, badges.
  static TextStyle display(
    double size, {
    FontWeight w = FontWeight.w700,
    Color c = AppColors.ink,
    double? h,
  }) => GoogleFonts.plusJakartaSans(fontSize: size, fontWeight: w, color: c, height: h);

  static ThemeData light() {
    final colorScheme = ColorScheme.fromSeed(
      seedColor: const Color(0xFF1E8E7A),
      brightness: Brightness.light,
    );

    return ThemeData(
      useMaterial3: true,
      colorScheme: colorScheme,
      textTheme: GoogleFonts.hindTextTheme(), // <- added
      scaffoldBackgroundColor: const Color(0xFFF5F8F6),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.white,
        foregroundColor: Color(0xFF153B35),
        elevation: 0,
        centerTitle: true,
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Color(0xFFD8E4E1)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Color(0xFFD8E4E1)),
        ),
      ),
    );
  }

  static ThemeData dark() {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: ColorScheme.fromSeed(
        seedColor: const Color(0xFF1E8E7A),
        brightness: Brightness.dark,
      ),
    );
  }
}
