// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get introTagline => 'Your Community, Your Marketplace';

  @override
  String get introNeedTitle => 'I Need';

  @override
  String get introNeedDetail => 'Find what you need';

  @override
  String get introHaveTitle => 'I Have';

  @override
  String get introHaveDetail => 'Offer what you have';

  @override
  String get introMatchTitle => 'Match Me';

  @override
  String get introMatchDetail => 'Connect with the right person';

  @override
  String get introBrowse => 'Browse products, services and people near you';

  @override
  String get introMotto => 'A better neighborhood begins with one connection.';

  @override
  String get introGetStarted => 'Get Started';
}
