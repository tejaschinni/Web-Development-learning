// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Telugu (`te`).
class AppLocalizationsTe extends AppLocalizations {
  AppLocalizationsTe([String locale = 'te']) : super(locale);

  @override
  String get introTagline => 'మీ సంఘం, మీ మార్కెట్‌ప్లేస్';

  @override
  String get introNeedTitle => 'నాకు కావాలి';

  @override
  String get introNeedDetail => 'మీకు కావలసినది కనుగొనండి';

  @override
  String get introHaveTitle => 'నా దగ్గర ఉంది';

  @override
  String get introHaveDetail => 'మీ దగ్గర ఉన్నదాన్ని అందించండి';

  @override
  String get introMatchTitle => 'నన్ను జత చేయండి';

  @override
  String get introMatchDetail => 'సరైన వ్యక్తితో కలవండి';

  @override
  String get introBrowse =>
      'మీకు దగ్గరలోని వస్తువులు, సేవలు మరియు వ్యక్తులను చూడండి';

  @override
  String get introMotto => 'మెరుగైన పొరుగు బంధం ఒక కొత్త పరిచయంతో మొదలవుతుంది.';

  @override
  String get introGetStarted => 'ప్రారంభించండి';
}
