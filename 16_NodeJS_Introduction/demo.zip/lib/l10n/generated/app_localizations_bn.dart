// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Bengali Bangla (`bn`).
class AppLocalizationsBn extends AppLocalizations {
  AppLocalizationsBn([String locale = 'bn']) : super(locale);

  @override
  String get introTagline => 'আপনার সম্প্রদায়, আপনার বাজার';

  @override
  String get introNeedTitle => 'আমার দরকার';

  @override
  String get introNeedDetail => 'আপনার প্রয়োজনীয় জিনিস খুঁজুন';

  @override
  String get introHaveTitle => 'আমার কাছে আছে';

  @override
  String get introHaveDetail => 'আপনার কাছে যা আছে তা দিন';

  @override
  String get introMatchTitle => 'আমাকে মেলান';

  @override
  String get introMatchDetail => 'সঠিক ব্যক্তির সঙ্গে যুক্ত হন';

  @override
  String get introBrowse => 'আপনার কাছের পণ্য, পরিষেবা ও মানুষ খুঁজুন';

  @override
  String get introMotto => 'একটি ভালো পাড়া শুরু হয় একটি নতুন সংযোগ দিয়ে।';

  @override
  String get introGetStarted => 'শুরু করুন';
}
