// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Marathi (`mr`).
class AppLocalizationsMr extends AppLocalizations {
  AppLocalizationsMr([String locale = 'mr']) : super(locale);

  @override
  String get introTagline => 'तुमचा समुदाय, तुमचा बाजार';

  @override
  String get introNeedTitle => 'मला हवे';

  @override
  String get introNeedDetail => 'तुम्हाला हवे ते शोधा';

  @override
  String get introHaveTitle => 'माझ्याकडे आहे';

  @override
  String get introHaveDetail => 'तुमच्याकडे असलेली वस्तू किंवा सेवा द्या';

  @override
  String get introMatchTitle => 'मला जोडा';

  @override
  String get introMatchDetail => 'योग्य व्यक्तीशी जोडा';

  @override
  String get introBrowse => 'तुमच्या जवळील उत्पादने, सेवा आणि लोक शोधा';

  @override
  String get introMotto => 'एक चांगला परिसर नव्या नात्याने सुरू होतो.';

  @override
  String get introGetStarted => 'सुरू करा';
}
