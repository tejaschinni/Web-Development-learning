// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Tamil (`ta`).
class AppLocalizationsTa extends AppLocalizations {
  AppLocalizationsTa([String locale = 'ta']) : super(locale);

  @override
  String get introTagline => 'உங்கள் சமூகம், உங்கள் சந்தை';

  @override
  String get introNeedTitle => 'எனக்குத் தேவை';

  @override
  String get introNeedDetail => 'உங்களுக்குத் தேவையானதைக் கண்டறியுங்கள்';

  @override
  String get introHaveTitle => 'என்னிடம் உள்ளது';

  @override
  String get introHaveDetail => 'உங்களிடம் உள்ளதை வழங்குங்கள்';

  @override
  String get introMatchTitle => 'என்னை இணைக்கவும்';

  @override
  String get introMatchDetail => 'சரியான நபருடன் இணையுங்கள்';

  @override
  String get introBrowse =>
      'அருகிலுள்ள பொருட்கள், சேவைகள் மற்றும் நபர்களைப் பாருங்கள்';

  @override
  String get introMotto =>
      'ஒரு சிறந்த அக்கம் ஒரு புதிய இணைப்பில் தொடங்குகிறது.';

  @override
  String get introGetStarted => 'தொடங்குங்கள்';
}
