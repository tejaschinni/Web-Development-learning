// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Hindi (`hi`).
class AppLocalizationsHi extends AppLocalizations {
  AppLocalizationsHi([String locale = 'hi']) : super(locale);

  @override
  String get introTagline => 'आपका समुदाय, आपका बाज़ार';

  @override
  String get introNeedTitle => 'मुझे चाहिए';

  @override
  String get introNeedDetail => 'अपनी ज़रूरत की चीज़ खोजें';

  @override
  String get introHaveTitle => 'मेरे पास है';

  @override
  String get introHaveDetail => 'अपनी चीज़ या सेवा दें';

  @override
  String get introMatchTitle => 'मुझे जोड़ें';

  @override
  String get introMatchDetail => 'सही व्यक्ति से जुड़ें';

  @override
  String get introBrowse => 'अपने आस-पास के उत्पाद, सेवाएँ और लोग खोजें';

  @override
  String get introMotto => 'एक बेहतर पड़ोस, एक नए जुड़ाव से शुरू होता है।';

  @override
  String get introGetStarted => 'शुरू करें';
}
