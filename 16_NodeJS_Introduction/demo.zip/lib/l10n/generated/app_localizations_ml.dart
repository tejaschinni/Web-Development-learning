// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Malayalam (`ml`).
class AppLocalizationsMl extends AppLocalizations {
  AppLocalizationsMl([String locale = 'ml']) : super(locale);

  @override
  String get introTagline => 'നിങ്ങളുടെ സമൂഹം, നിങ്ങളുടെ വിപണിസ്ഥലം';

  @override
  String get introNeedTitle => 'എനിക്ക് വേണം';

  @override
  String get introNeedDetail => 'നിങ്ങൾക്ക് വേണ്ടത് കണ്ടെത്തൂ';

  @override
  String get introHaveTitle => 'എന്റെ കൈവശമുണ്ട്';

  @override
  String get introHaveDetail => 'നിങ്ങളുടെ കൈവശമുള്ളത് നൽകൂ';

  @override
  String get introMatchTitle => 'എന്നെ ബന്ധിപ്പിക്കൂ';

  @override
  String get introMatchDetail => 'ശരിയായ വ്യക്തിയുമായി ബന്ധപ്പെടൂ';

  @override
  String get introBrowse =>
      'നിങ്ങൾക്ക് സമീപമുള്ള ഉൽപ്പന്നങ്ങളും സേവനങ്ങളും ആളുകളെയും കാണൂ';

  @override
  String get introMotto =>
      'ഒരു മികച്ച അയൽക്കൂട്ടം ഒരു പുതിയ ബന്ധത്തിൽ തുടങ്ങുന്നു.';

  @override
  String get introGetStarted => 'തുടങ്ങാം';
}
