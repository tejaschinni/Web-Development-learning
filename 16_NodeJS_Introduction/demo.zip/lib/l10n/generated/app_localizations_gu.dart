// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Gujarati (`gu`).
class AppLocalizationsGu extends AppLocalizations {
  AppLocalizationsGu([String locale = 'gu']) : super(locale);

  @override
  String get introTagline => 'તમારો સમુદાય, તમારું બજાર';

  @override
  String get introNeedTitle => 'મારે જોઈએ';

  @override
  String get introNeedDetail => 'તમને જે જોઈએ તે શોધો';

  @override
  String get introHaveTitle => 'મારી પાસે છે';

  @override
  String get introHaveDetail => 'તમારી વસ્તુ કે સેવા આપો';

  @override
  String get introMatchTitle => 'મને જોડો';

  @override
  String get introMatchDetail => 'યોગ્ય વ્યક્તિ સાથે જોડાઓ';

  @override
  String get introBrowse => 'તમારી નજીકનાં ઉત્પાદનો, સેવાઓ અને લોકો શોધો';

  @override
  String get introMotto => 'વધુ સારો પડોશ એક નવા જોડાણથી શરૂ થાય છે.';

  @override
  String get introGetStarted => 'શરૂ કરો';
}
