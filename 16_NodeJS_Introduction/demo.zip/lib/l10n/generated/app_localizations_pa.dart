// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Panjabi Punjabi (`pa`).
class AppLocalizationsPa extends AppLocalizations {
  AppLocalizationsPa([String locale = 'pa']) : super(locale);

  @override
  String get introTagline => 'ਤੁਹਾਡਾ ਭਾਈਚਾਰਾ, ਤੁਹਾਡਾ ਬਾਜ਼ਾਰ';

  @override
  String get introNeedTitle => 'ਮੈਨੂੰ ਚਾਹੀਦਾ ਹੈ';

  @override
  String get introNeedDetail => 'ਆਪਣੀ ਲੋੜ ਦੀ ਚੀਜ਼ ਲੱਭੋ';

  @override
  String get introHaveTitle => 'ਮੇਰੇ ਕੋਲ ਹੈ';

  @override
  String get introHaveDetail => 'ਆਪਣੀ ਚੀਜ਼ ਜਾਂ ਸੇਵਾ ਪੇਸ਼ ਕਰੋ';

  @override
  String get introMatchTitle => 'ਮੈਨੂੰ ਮਿਲਾਓ';

  @override
  String get introMatchDetail => 'ਸਹੀ ਵਿਅਕਤੀ ਨਾਲ ਜੁੜੋ';

  @override
  String get introBrowse => 'ਆਪਣੇ ਨੇੜੇ ਉਤਪਾਦ, ਸੇਵਾਵਾਂ ਅਤੇ ਲੋਕ ਵੇਖੋ';

  @override
  String get introMotto =>
      'ਇੱਕ ਚੰਗਾ ਆਂਢ-ਗੁਆਂਢ ਇੱਕ ਨਵੇਂ ਰਿਸ਼ਤੇ ਨਾਲ ਸ਼ੁਰੂ ਹੁੰਦਾ ਹੈ।';

  @override
  String get introGetStarted => 'ਸ਼ੁਰੂ ਕਰੋ';
}
