// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Kannada (`kn`).
class AppLocalizationsKn extends AppLocalizations {
  AppLocalizationsKn([String locale = 'kn']) : super(locale);

  @override
  String get introTagline => 'ನಿಮ್ಮ ಸಮುದಾಯ, ನಿಮ್ಮ ಮಾರುಕಟ್ಟೆ';

  @override
  String get introNeedTitle => 'ನನಗೆ ಬೇಕು';

  @override
  String get introNeedDetail => 'ನಿಮಗೆ ಬೇಕಾದುದನ್ನು ಹುಡುಕಿ';

  @override
  String get introHaveTitle => 'ನನ್ನ ಬಳಿ ಇದೆ';

  @override
  String get introHaveDetail => 'ನಿಮ್ಮಲ್ಲಿರುವುದನ್ನು ಒದಗಿಸಿ';

  @override
  String get introMatchTitle => 'ನನ್ನನ್ನು ಹೊಂದಿಸಿ';

  @override
  String get introMatchDetail => 'ಸರಿಯಾದ ವ್ಯಕ್ತಿಯೊಂದಿಗೆ ಸಂಪರ್ಕಿಸಿ';

  @override
  String get introBrowse =>
      'ನಿಮ್ಮ ಹತ್ತಿರದ ಉತ್ಪನ್ನಗಳು, ಸೇವೆಗಳು ಮತ್ತು ಜನರನ್ನು ನೋಡಿ';

  @override
  String get introMotto => 'ಉತ್ತಮ ನೆರೆಹೊರೆಯು ಹೊಸ ಸಂಪರ್ಕದಿಂದ ಆರಂಭವಾಗುತ್ತದೆ.';

  @override
  String get introGetStarted => 'ಪ್ರಾರಂಭಿಸಿ';
}
