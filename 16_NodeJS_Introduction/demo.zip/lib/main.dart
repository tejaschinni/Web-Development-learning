import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:society_seva/app/app.dart';
import 'package:society_seva/core/config/app_config.dart';
import 'package:society_seva/core/mock/mock_data.dart';
import 'package:society_seva/core/storage/local_cache.dart';
import 'package:society_seva/core/storage/secure_storage.dart';
import 'package:society_seva/features/profile/presentation/providers/user_mode_provider.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await dotenv.load(fileName: '.env', isOptional: true);
  await LocalCache.instance.initialize();

  final config = AppConfig.environmentFor(null);
  final storage = AppSecureStorage();

  // Seed default authentication session for mock seller profile
  final session = await storage.readSession();
  if (session['accessToken'] == null || session['accessToken']!.isEmpty) {
    await storage.saveTokens(
      accessToken: MockData.authTokens.accessToken,
      refreshToken: MockData.authTokens.refreshToken,
    );
  }

  // Set default mode as seller as requested
  final savedMode = await storage.readUserMode();
  if (savedMode == null) {
    await storage.saveUserMode(userMode: UserMode.seller.name);
  }

  final initialMode = UserMode.values.firstWhere(
    (m) => m.name == (savedMode ?? UserMode.seller.name),
    orElse: () => UserMode.seller,
  );

  runApp(SocietySevaApp(config: config, initialMode: initialMode));
}
