import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/core/storage/local_cache.dart';
import 'package:society_seva/l10n/generated/app_localizations.dart';

const appLanguageNames = <String, String>{
  'en': 'English',
  'hi': 'हिन्दी',
  'mr': 'मराठी',
  'gu': 'ગુજરાતી',
  'bn': 'বাংলা',
  'ta': 'தமிழ்',
  'te': 'తెలుగు',
  'kn': 'ಕನ್ನಡ',
  'ml': 'മലയാളം',
  'pa': 'ਪੰਜਾਬੀ',
};

final appLocaleProvider = StateNotifierProvider<AppLocaleController, Locale>(
  (ref) => AppLocaleController(),
);

class AppLocaleController extends StateNotifier<Locale> {
  AppLocaleController() : super(_savedLocale());

  static const _localeKey = 'app:locale';

  static Locale _savedLocale() {
    final languageCode = LocalCache.instance.readJsonSync(_localeKey)?['languageCode'];
    for (final locale in AppLocalizations.supportedLocales) {
      if (locale.languageCode == languageCode) {
        return locale;
      }
    }

    final deviceLanguageCode = WidgetsBinding.instance.platformDispatcher.locale.languageCode;
    for (final locale in AppLocalizations.supportedLocales) {
      if (locale.languageCode == deviceLanguageCode) {
        return locale;
      }
    }
    return const Locale('en');
  }

  void setLocale(Locale locale) {
    if (!AppLocalizations.supportedLocales.contains(locale)) {
      return;
    }
    state = locale;
    unawaited(_saveLocale(locale));
  }

  Future<void> _saveLocale(Locale locale) async {
    try {
      await LocalCache.instance.writeJson(_localeKey, {'languageCode': locale.languageCode});
    } catch (_) {
      // Keep the selection for this run if local persistence is unavailable.
    }
  }
}
