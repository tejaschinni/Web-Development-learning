import 'package:flutter/foundation.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

enum AppEnvironment { development, staging, production }

class AppConfig {
  const AppConfig({
    required this.environment,
    required this.apiBaseUrl,
    required this.apiKey,
    required this.name,
  });

  final AppEnvironment environment;
  final String apiBaseUrl;
  final String apiKey;
  final String name;

  factory AppConfig.environmentFor(String? environmentName) {
    const buildEnvironment = String.fromEnvironment('APP_ENVIRONMENT');
    final env = _parseEnvironment(
      _envValue('APP_ENVIRONMENT') ??
          environmentName ??
          (buildEnvironment.isNotEmpty
              ? buildEnvironment
              : kReleaseMode
              ? 'production'
              : 'development'),
    );

    return AppConfig(
      environment: env,
      apiBaseUrl: _envValue('API_BASE_URL') ?? _defaultApiBaseUrl(env),
      apiKey: _envValue('APP_API_KEY') ?? _defaultApiKey(env),
      name: 'Society Seva',
    );
  }

  static String? _envValue(String key) {
    if (!dotenv.isInitialized) {
      return null;
    }

    final value = dotenv.env[key]?.trim();
    return value == null || value.isEmpty ? null : value;
  }

  static AppEnvironment _parseEnvironment(String? value) {
    switch ((value ?? 'development').toLowerCase()) {
      case 'staging':
        return AppEnvironment.staging;
      case 'production':
        return AppEnvironment.production;
      case 'development':
      default:
        return AppEnvironment.development;
    }
  }

  static String _defaultApiBaseUrl(AppEnvironment environment) {
    switch (environment) {
      case AppEnvironment.development:
        return const String.fromEnvironment(
          'API_BASE_URL',
          defaultValue: 'http://192.168.1.42:8080/society_rest',
        );
      case AppEnvironment.staging:
        return const String.fromEnvironment(
          'API_BASE_URL',
          defaultValue: 'https://staging-api.societyseva.com',
        );
      case AppEnvironment.production:
        return const String.fromEnvironment(
          'API_BASE_URL',
          defaultValue: 'https://api.societyseva.com',
        );
    }
  }

  static String _defaultApiKey(AppEnvironment environment) {
    switch (environment) {
      case AppEnvironment.development:
        return const String.fromEnvironment('APP_API_KEY', defaultValue: 'development-api-key');
      case AppEnvironment.staging:
        return const String.fromEnvironment('APP_API_KEY', defaultValue: 'staging-api-key');
      case AppEnvironment.production:
        return const String.fromEnvironment('APP_API_KEY', defaultValue: 'production-api-key');
    }
  }
}
