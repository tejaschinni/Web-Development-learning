import 'dart:async';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

class AuroraBackground extends StatefulWidget {
  const AuroraBackground({super.key, this.opacity = 1.0});

  final double opacity;

  @override
  State<AuroraBackground> createState() => _AuroraBackgroundState();
}

class _AuroraBackgroundState extends State<AuroraBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController _animationController;

  Future<ui.FragmentProgram>? _programFuture;

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 20),
    )..repeat();

    _programFuture = _loadShader();
  }

  Future<ui.FragmentProgram> _loadShader() {
    return ui.FragmentProgram.fromAsset('shaders/aurora.frag');
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<ui.FragmentProgram>(
      future: _programFuture,
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const ColoredBox(color: Color(0xFF040711));
        }

        final program = snapshot.data!;

        return RepaintBoundary(
          child: AnimatedBuilder(
            animation: _animationController,
            builder: (context, child) {
              return CustomPaint(
                painter: _AuroraPainter(
                  shader: program.fragmentShader(),
                  time: _animationController.value * 20.0,
                  opacity: widget.opacity,
                ),
                child: const SizedBox.expand(),
              );
            },
          ),
        );
      },
    );
  }
}

class _AuroraPainter extends CustomPainter {
  _AuroraPainter({
    required this.shader,
    required this.time,
    required this.opacity,
  });

  final ui.FragmentShader shader;
  final double time;
  final double opacity;

  @override
  void paint(Canvas canvas, Size size) {
    shader
      ..setFloat(0, size.width)
      ..setFloat(1, size.height)
      ..setFloat(2, time)
      ..setFloat(3, opacity.clamp(0.0, 1.0));

    final paint = Paint()..shader = shader;

    canvas.drawRect(Offset.zero & size, paint);
  }

  @override
  bool shouldRepaint(_AuroraPainter oldDelegate) {
    return oldDelegate.time != time ||
        oldDelegate.opacity != opacity ||
        oldDelegate.shader != shader;
  }
}
