import 'package:society_seva/features/auth/data/models/auth_tokens.dart';
import 'package:society_seva/features/auth/data/models/registration.dart';
import 'package:society_seva/features/guest/data/models/guest_session.dart';
import 'package:society_seva/features/location/data/models/saved_address.dart';
import 'package:society_seva/features/profile/data/models/user_profile_model.dart';
import 'package:society_seva/features/seller/data/models/certificate_model.dart';
import 'package:society_seva/features/seller/data/models/food_detail_model.dart';
import 'package:society_seva/features/seller/data/models/kyc_document_model.dart';
import 'package:society_seva/features/seller/data/models/order_status_history_model.dart';
import 'package:society_seva/features/seller/data/models/seller_availabledays_model.dart';
import 'package:society_seva/features/seller/data/models/seller_category_model.dart';
import 'package:society_seva/features/seller/data/models/seller_image_model.dart';
import 'package:society_seva/features/seller/data/models/seller_listing_image_model.dart';
import 'package:society_seva/features/seller/data/models/seller_listing_model.dart';
import 'package:society_seva/features/seller/data/models/seller_order_model.dart';
import 'package:society_seva/features/seller/data/models/seller_profile_model.dart';
import 'package:society_seva/features/seller/data/models/service_detail_model.dart';
import 'package:society_seva/features/seller/data/models/service_slot_model.dart';
import 'package:society_seva/features/shop/data/models/shop_category_model.dart';
import 'package:society_seva/features/shop/data/models/shop_checkout_models.dart';
import 'package:society_seva/features/shop/domain/entities/shop_cart.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing.dart';
import 'package:society_seva/features/shop/domain/entities/shop_seller.dart';
import 'package:society_seva/features/shop/domain/enums/shop_category_type.dart';
import 'package:society_seva/features/shop/domain/enums/shop_listing_approval_status.dart';
import 'package:society_seva/features/shop/domain/enums/shop_listing_availability_status.dart';
import 'package:society_seva/features/shop/domain/enums/shop_listing_moderation_status.dart';
import 'package:society_seva/features/shop/domain/enums/shop_listing_sponsored_status.dart';
import 'package:society_seva/features/shop/domain/enums/shop_listing_type.dart';
import 'package:society_seva/features/shop/domain/enums/shop_seller_approval_status.dart';
import 'package:society_seva/features/shop/domain/enums/shop_seller_availability_status.dart';
import 'package:society_seva/features/shop/domain/enums/shop_seller_fssai_status.dart';
import 'package:society_seva/features/shop/domain/enums/shop_seller_renewal_status.dart';
import 'package:society_seva/features/shop/domain/enums/shop_seller_type.dart';
import 'package:society_seva/features/society/data/models/membership_models.dart';
import 'package:society_seva/features/society/data/models/society_models.dart';
import 'package:society_seva/features/system/data/models/system_health_model.dart';

class MockData {
  // ── USER PROFILE AS SELLER ──────────────────────────────────────────────
  static const String sellerUserId = 'usr_seller_001';
  static const String sellerId = 'seller_001';
  static const String societyId = 'soc_green_valley_01';

  static final UserProfileModel sellerUserProfile = UserProfileModel(
    id: sellerUserId,
    fullName: 'Priya Sharma',
    gender: 'Female',
    dateOfBirth: '1992-05-15',
    mobileNumber: '+91 98765 43210',
    email: 'priya.seller@societyseva.com',
    emailVerified: true,
    preferredLanguage: 'English',
    accountStatus: 'ACTIVE',
    profilePhotoUrl:
        'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=400&q=80',
    roles: const ['SELLER', 'USER'],
  );

  // ── SELLER PROFILE (APPROVED) ───────────────────────────────────────────
  static final SellerProfileModel approvedSellerProfile = SellerProfileModel(
    id: sellerId,
    userId: sellerUserId,
    displayName: 'Priya Sharma',
    businessName: 'Priya Homemade Delights & Crafts',
    bio:
        'Fresh, authentic home-cooked meals, regional savouries, festive treats, and handmade society home decor made with love.',
    sellerTypeList: const ['FOOD', 'SERVICE', 'PRODUCT'],
    availabilityStatus: 'AVAILABLE',
    approvalStatus: 'APPROVED',
    fssaiStatus: 'VERIFIED',
    fssaiRequired: true,
    renewalStatus: 'ACTIVE',
    totalListings: 6,
    averageRating: 4.9,
    rejectedOrders: 0,
    cancelledOrders: 1,
    totalOrders: 48,
    totalReviews: 32,
    address: 'Flat 402, Tower B, Green Valley Heights',
    city: 'Mumbai',
    state: 'Maharashtra',
    country: 'India',
    pinCode: '400076',
    deliveryRadiusKm: 5.0,
    fssaiCertificateId: 'FSSAI-21423010001234',
    latitude: 19.1176,
    longitude: 72.9060,
    socialMediaLinks: 'https://instagram.com/priyahomemade',
    societyId: societyId,
    targetArea: 'Powai and surrounding societies',
    websiteUrl: 'https://priyadelights.societyseva.com',
    legalCompliance: 'Complied with Society By-laws & Food Safety Regulations',
    createdAt: '2026-01-10T10:00:00Z',
    updatedAt: '2026-10-20T14:30:00Z',
  );

  // ── SELLER AVAILABLE DAYS ───────────────────────────────────────────────
  static final AvailableDaysModel sellerAvailableDays = AvailableDaysModel(
    sellerId: sellerId,
    daysType: 'CUSTOM_DAYS',
    availableDays: const [
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday',
    ],
    fromTime: '09:00',
    toTime: '20:00',
  );

  // ── CATEGORIES ──────────────────────────────────────────────────────────
  static final List<CategoriesModel> sellerCategories = [
    CategoriesModel(
      id: 'cat_food',
      name: 'Home Food & Tiffin',
      slug: 'home-food',
      categoryType: 'FOOD',
      requiresCertificate: true,
      isActive: true,
      displayOrder: 1,
      createdAt: DateTime(2026, 1, 1),
      updatedAt: DateTime(2026, 1, 1),
    ),
    CategoriesModel(
      id: 'cat_bakery',
      name: 'Bakes & Desserts',
      slug: 'bakes-desserts',
      categoryType: 'FOOD',
      requiresCertificate: true,
      isActive: true,
      displayOrder: 2,
      createdAt: DateTime(2026, 1, 1),
      updatedAt: DateTime(2026, 1, 1),
    ),
    CategoriesModel(
      id: 'cat_services',
      name: 'Home Services & Repairs',
      slug: 'home-services',
      categoryType: 'SERVICE',
      requiresCertificate: false,
      isActive: true,
      displayOrder: 3,
      createdAt: DateTime(2026, 1, 1),
      updatedAt: DateTime(2026, 1, 1),
    ),
    CategoriesModel(
      id: 'cat_crafts',
      name: 'Handicrafts & Decor',
      slug: 'handicrafts-decor',
      categoryType: 'PRODUCT',
      requiresCertificate: false,
      isActive: true,
      displayOrder: 4,
      createdAt: DateTime(2026, 1, 1),
      updatedAt: DateTime(2026, 1, 1),
    ),
    CategoriesModel(
      id: 'cat_groceries',
      name: 'Organic & Farm Fresh',
      slug: 'organic-produce',
      categoryType: 'PRODUCT',
      requiresCertificate: false,
      isActive: true,
      displayOrder: 5,
      createdAt: DateTime(2026, 1, 1),
      updatedAt: DateTime(2026, 1, 1),
    ),
  ];

  static final List<ShopCategoryModel> shopCategoryTree = [
    ShopCategoryModel(
      id: 'cat_food',
      name: 'Home Food & Kitchen',
      slug: 'home-food',
      categoryType: ShopCategoryType.food,
      requiresCertificate: true,
      isActive: true,
      displayOrder: 1,
      subCategories: [
        ShopCategoryModel(
          id: 'cat_food_thali',
          parentCategoryId: 'cat_food',
          name: 'Veg & Non-Veg Thalis',
          slug: 'thalis',
          categoryType: ShopCategoryType.food,
          requiresCertificate: true,
          isActive: true,
          displayOrder: 1,
          subCategories: const [],
        ),
        ShopCategoryModel(
          id: 'cat_food_snacks',
          parentCategoryId: 'cat_food',
          name: 'Evening Snacks & Chaat',
          slug: 'snacks',
          categoryType: ShopCategoryType.food,
          requiresCertificate: true,
          isActive: true,
          displayOrder: 2,
          subCategories: const [],
        ),
      ],
    ),
    ShopCategoryModel(
      id: 'cat_services',
      name: 'Local Services',
      slug: 'local-services',
      categoryType: ShopCategoryType.service,
      requiresCertificate: false,
      isActive: true,
      displayOrder: 2,
      subCategories: [
        ShopCategoryModel(
          id: 'cat_service_cleaning',
          parentCategoryId: 'cat_services',
          name: 'Deep Cleaning & Sanitization',
          slug: 'cleaning',
          categoryType: ShopCategoryType.service,
          requiresCertificate: false,
          isActive: true,
          displayOrder: 1,
          subCategories: const [],
        ),
        ShopCategoryModel(
          id: 'cat_service_appliance',
          parentCategoryId: 'cat_services',
          name: 'Appliance & AC Care',
          slug: 'appliances',
          categoryType: ShopCategoryType.service,
          requiresCertificate: false,
          isActive: true,
          displayOrder: 2,
          subCategories: const [],
        ),
      ],
    ),
    ShopCategoryModel(
      id: 'cat_crafts',
      name: 'Handmade & Craft',
      slug: 'handmade-craft',
      categoryType: ShopCategoryType.product,
      requiresCertificate: false,
      isActive: true,
      displayOrder: 3,
      subCategories: const [],
    ),
  ];

  // ── SELLER LISTINGS ─────────────────────────────────────────────────────
  static final List<SellerListingModel> sellerListings = [
    SellerListingModel(
      id: 'list_001',
      sellerId: sellerId,
      categoryId: 'cat_food',
      additionalCategoryIds: const ['cat_food_thali'],
      listingType: 'FOOD',
      title: 'Authentic Maharashtrian Veg Thali',
      description:
          'Wholesome home meal with 3 Phulkas, Steamed Rice, Dal Tadka, Paneer Bhurji, Salad & Sweet Gulab Jamun.',
      basePrice: 160.0,
      priceUnit: 'thali',
      isFree: false,
      quantityAvailable: 15,
      availabilityStatus: 'AVAILABLE',
      approvalStatus: 'APPROVED',
      moderationStatus: 'APPROVED',
      sponsoredStatus: 'ACTIVE',
      averageRating: 4.9,
      totalReviews: 24,
      tagNames: const ['Thali', 'Veg', 'HomeCooked', 'Fresh'],
      createdAt: DateTime.now().subtract(const Duration(days: 30)),
      updatedAt: DateTime.now().subtract(const Duration(hours: 2)),
    ),
    SellerListingModel(
      id: 'list_002',
      sellerId: sellerId,
      categoryId: 'cat_food',
      additionalCategoryIds: const ['cat_food_snacks'],
      listingType: 'FOOD',
      title: 'Crispy Samosa Platter (6 Pcs)',
      description:
          'Crispy golden pastry stuffed with spiced potato & peas, served with mint-coriander chutney & tamarind dip.',
      basePrice: 120.0,
      priceUnit: 'plate',
      isFree: false,
      quantityAvailable: 25,
      availabilityStatus: 'AVAILABLE',
      approvalStatus: 'APPROVED',
      moderationStatus: 'APPROVED',
      sponsoredStatus: 'NONE',
      averageRating: 4.8,
      totalReviews: 18,
      tagNames: const ['Snacks', 'TeaTime', 'Crispy'],
      createdAt: DateTime.now().subtract(const Duration(days: 20)),
      updatedAt: DateTime.now().subtract(const Duration(hours: 1)),
    ),
    SellerListingModel(
      id: 'list_003',
      sellerId: sellerId,
      categoryId: 'cat_services',
      additionalCategoryIds: const ['cat_service_cleaning'],
      listingType: 'SERVICE',
      title: 'Kitchen & Chimney Deep Cleaning',
      description:
          'Complete degreasing, sanitization, cabinet cleaning, tiles scrubbing, and stove sparkling service.',
      basePrice: 799.0,
      priceUnit: 'session',
      isFree: false,
      quantityAvailable: 4,
      availabilityStatus: 'AVAILABLE',
      approvalStatus: 'APPROVED',
      moderationStatus: 'APPROVED',
      sponsoredStatus: 'ACTIVE',
      averageRating: 5.0,
      totalReviews: 12,
      tagNames: const ['Cleaning', 'Kitchen', 'HomeService'],
      createdAt: DateTime.now().subtract(const Duration(days: 15)),
      updatedAt: DateTime.now().subtract(const Duration(days: 1)),
    ),
    SellerListingModel(
      id: 'list_004',
      sellerId: sellerId,
      categoryId: 'cat_crafts',
      additionalCategoryIds: const [],
      listingType: 'PRODUCT',
      title: 'Handmade Aromatherapy Soy Wax Candles',
      description:
          'Set of 3 scented glass jar candles (Lavender, Vanilla Bean, Sandalwood) made from 100% natural organic soy wax.',
      basePrice: 450.0,
      priceUnit: 'box',
      isFree: false,
      quantityAvailable: 10,
      availabilityStatus: 'AVAILABLE',
      approvalStatus: 'APPROVED',
      moderationStatus: 'APPROVED',
      sponsoredStatus: 'NONE',
      averageRating: 4.9,
      totalReviews: 9,
      tagNames: const ['Handmade', 'Candles', 'Decor', 'Organic'],
      createdAt: DateTime.now().subtract(const Duration(days: 10)),
      updatedAt: DateTime.now().subtract(const Duration(days: 2)),
    ),
    SellerListingModel(
      id: 'list_005',
      sellerId: sellerId,
      categoryId: 'cat_food',
      additionalCategoryIds: const [],
      listingType: 'FOOD',
      title: 'Special Hyderabadi Dum Biryani (Veg/Paneer)',
      description:
          'Slow-cooked aromatic basmati rice layered with marinated paneer, saffron, fried onions, and whole spices.',
      basePrice: 220.0,
      priceUnit: 'box',
      isFree: false,
      quantityAvailable: 12,
      availabilityStatus: 'AVAILABLE',
      approvalStatus: 'APPROVED',
      moderationStatus: 'APPROVED',
      sponsoredStatus: 'NONE',
      averageRating: 4.9,
      totalReviews: 29,
      tagNames: const ['Biryani', 'Special', 'Dinner'],
      createdAt: DateTime.now().subtract(const Duration(days: 8)),
      updatedAt: DateTime.now().subtract(const Duration(hours: 3)),
    ),
    SellerListingModel(
      id: 'list_006',
      sellerId: sellerId,
      categoryId: 'cat_crafts',
      additionalCategoryIds: const [],
      listingType: 'PRODUCT',
      title: 'Hand-painted Ceramic Planters (Set of 2)',
      description:
          'Beautiful indoor planters with drainage hole, painted in terracotta and bohemian motifs.',
      basePrice: 380.0,
      priceUnit: 'pair',
      isFree: false,
      quantityAvailable: 5,
      availabilityStatus: 'AVAILABLE',
      approvalStatus: 'APPROVED',
      moderationStatus: 'APPROVED',
      sponsoredStatus: 'NONE',
      averageRating: 4.7,
      totalReviews: 6,
      tagNames: const ['Handmade', 'Planters', 'Garden'],
      createdAt: DateTime.now().subtract(const Duration(days: 5)),
      updatedAt: DateTime.now().subtract(const Duration(days: 1)),
    ),
  ];

  // ── SHOP LISTINGS (Domain Entity representation) ────────────────────────
  static List<ShopListing> get shopListings => sellerListings
      .map(
        (l) => ShopListing(
          id: l.id,
          sellerId: l.sellerId,
          societyId: societyId,
          categoryId: l.categoryId,
          additionalCategoryIds: l.additionalCategoryIds,
          listingType: l.listingType == 'SERVICE'
              ? ShopListingType.service
              : ShopListingType.product,
          title: l.title,
          description: l.description,
          basePrice: l.basePrice,
          priceUnit: l.priceUnit,
          isFree: l.isFree,
          quantityAvailable: l.quantityAvailable,
          availabilityStatus: ShopListingAvailabilityStatus.available,
          approvalStatus: ShopListingApprovalStatus.approved,
          moderationStatus: ShopListingModerationStatus.approved,
          sponsoredStatus: l.sponsoredStatus == 'ACTIVE'
              ? ShopListingSponsoredStatus.sponsored
              : ShopListingSponsoredStatus.notSponsored,
          averageRating: l.averageRating,
          totalReviews: l.totalReviews,
          tagNames: l.tagNames,
          createdAt: l.createdAt,
          updatedAt: l.updatedAt,
        ),
      )
      .toList();

  // ── SELLER ORDERS ───────────────────────────────────────────────────────
  static final List<SellerOrderModel> sellerOrders = [
    SellerOrderModel(
      id: 'ord_001',
      orderNumber: 'SS-ORD-9021',
      buyerId: 'usr_buyer_101',
      sellerId: sellerId,
      orderType: 'FOOD',
      orderStatus: 'PAID',
      subtotalAmount: 320.0,
      discountAmount: 20.0,
      platformCommission: 15.0,
      welfareFundAmount: 5.0,
      sellerEarning: 280.0,
      totalAmount: 300.0,
      paymentStatus: 'COMPLETED',
      items: const [
        SellerOrderItemModel(
          id: 'item_101',
          listingId: 'list_001',
          titleSnapshot: 'Authentic Maharashtrian Veg Thali',
          quantity: 2,
          unitPrice: 160.0,
          totalPrice: 320.0,
        ),
      ],
      createdAt: DateTime.now().subtract(const Duration(minutes: 25)),
    ),
    SellerOrderModel(
      id: 'ord_002',
      orderNumber: 'SS-ORD-9020',
      buyerId: 'usr_buyer_102',
      sellerId: sellerId,
      orderType: 'FOOD',
      orderStatus: 'PREPARING',
      subtotalAmount: 240.0,
      discountAmount: 0.0,
      platformCommission: 12.0,
      welfareFundAmount: 4.0,
      sellerEarning: 224.0,
      totalAmount: 240.0,
      paymentStatus: 'COMPLETED',
      items: const [
        SellerOrderItemModel(
          id: 'item_102',
          listingId: 'list_002',
          titleSnapshot: 'Crispy Samosa Platter (6 Pcs)',
          quantity: 2,
          unitPrice: 120.0,
          totalPrice: 240.0,
        ),
      ],
      createdAt: DateTime.now().subtract(const Duration(hours: 1, minutes: 15)),
    ),
    SellerOrderModel(
      id: 'ord_003',
      orderNumber: 'SS-ORD-9019',
      buyerId: 'usr_buyer_103',
      sellerId: sellerId,
      orderType: 'SERVICE',
      orderStatus: 'ACCEPTED',
      subtotalAmount: 799.0,
      discountAmount: 50.0,
      platformCommission: 40.0,
      welfareFundAmount: 10.0,
      sellerEarning: 699.0,
      totalAmount: 749.0,
      paymentStatus: 'COMPLETED',
      items: const [
        SellerOrderItemModel(
          id: 'item_103',
          listingId: 'list_003',
          titleSnapshot: 'Kitchen & Chimney Deep Cleaning',
          quantity: 1,
          unitPrice: 799.0,
          totalPrice: 799.0,
        ),
      ],
      createdAt: DateTime.now().subtract(const Duration(hours: 3)),
    ),
    SellerOrderModel(
      id: 'ord_004',
      orderNumber: 'SS-ORD-9018',
      buyerId: 'usr_buyer_104',
      sellerId: sellerId,
      orderType: 'PRODUCT',
      orderStatus: 'OUT_FOR_DELIVERY',
      subtotalAmount: 450.0,
      discountAmount: 0.0,
      platformCommission: 22.0,
      welfareFundAmount: 8.0,
      sellerEarning: 420.0,
      totalAmount: 450.0,
      paymentStatus: 'COMPLETED',
      items: const [
        SellerOrderItemModel(
          id: 'item_104',
          listingId: 'list_004',
          titleSnapshot: 'Handmade Aromatherapy Soy Wax Candles',
          quantity: 1,
          unitPrice: 450.0,
          totalPrice: 450.0,
        ),
      ],
      createdAt: DateTime.now().subtract(const Duration(hours: 5)),
    ),
    SellerOrderModel(
      id: 'ord_005',
      orderNumber: 'SS-ORD-9015',
      buyerId: 'usr_buyer_105',
      sellerId: sellerId,
      orderType: 'FOOD',
      orderStatus: 'COMPLETED',
      subtotalAmount: 440.0,
      discountAmount: 40.0,
      platformCommission: 20.0,
      welfareFundAmount: 5.0,
      sellerEarning: 375.0,
      totalAmount: 400.0,
      paymentStatus: 'COMPLETED',
      items: const [
        SellerOrderItemModel(
          id: 'item_105',
          listingId: 'list_005',
          titleSnapshot: 'Special Hyderabadi Dum Biryani',
          quantity: 2,
          unitPrice: 220.0,
          totalPrice: 440.0,
        ),
      ],
      createdAt: DateTime.now().subtract(const Duration(days: 1)),
    ),
  ];

  // ── BUYER ORDERS (ShopOrderResult) ──────────────────────────────────────
  static final List<ShopOrderResult> shopMyOrders = [
    ShopOrderResult(
      id: 'ord_001',
      orderNumber: 'SS-ORD-9021',
      sellerId: sellerId,
      sellerName: 'Priya Homemade Delights & Crafts',
      orderType: 'FOOD',
      orderStatus: 'PAID',
      subtotalAmount: 320.0,
      totalAmount: 300.0,
      paymentStatus: 'COMPLETED',
      paymentMethod: 'ONLINE',
      fulfillmentMethod: 'DOORSTEP_DELIVERY',
      deliveryAddress: 'Flat 301, Tower A, Green Valley Heights',
      createdAt: DateTime.now().subtract(const Duration(minutes: 25)).toIso8601String(),
      items: const [
        ShopOrderResultItem(
          id: 'item_101',
          listingId: 'list_001',
          title: 'Authentic Maharashtrian Veg Thali',
          quantity: 2,
          unitPrice: 160.0,
          totalPrice: 320.0,
        ),
      ],
    ),
    ShopOrderResult(
      id: 'ord_005',
      orderNumber: 'SS-ORD-9015',
      sellerId: sellerId,
      sellerName: 'Priya Homemade Delights & Crafts',
      orderType: 'FOOD',
      orderStatus: 'DELIVERED',
      subtotalAmount: 440.0,
      totalAmount: 400.0,
      paymentStatus: 'COMPLETED',
      paymentMethod: 'CASH',
      fulfillmentMethod: 'DOORSTEP_DELIVERY',
      deliveryAddress: 'Flat 301, Tower A, Green Valley Heights',
      createdAt: DateTime.now().subtract(const Duration(days: 1)).toIso8601String(),
      items: const [
        ShopOrderResultItem(
          id: 'item_105',
          listingId: 'list_005',
          title: 'Special Hyderabadi Dum Biryani',
          quantity: 2,
          unitPrice: 220.0,
          totalPrice: 440.0,
        ),
      ],
    ),
  ];

  // ── CART ────────────────────────────────────────────────────────────────
  static final ShopCart mockCart = ShopCart(
    id: 'cart_001',
    buyerId: sellerUserId,
    sellerId: sellerId,
    sellerName: 'Priya Homemade Delights & Crafts',
    status: 'ACTIVE',
    items: const [
      ShopCartItem(
        id: 'cart_item_1',
        listingId: 'list_001',
        quantity: 2,
        unitPriceSnapshot: 160.0,
        lineTotal: 320.0,
        listingName: 'Authentic Maharashtrian Veg Thali',
        sellerName: 'Priya Homemade Delights & Crafts',
        isFood: true,
      ),
      ShopCartItem(
        id: 'cart_item_2',
        listingId: 'list_002',
        quantity: 1,
        unitPriceSnapshot: 120.0,
        lineTotal: 120.0,
        listingName: 'Crispy Samosa Platter (6 Pcs)',
        sellerName: 'Priya Homemade Delights & Crafts',
        isFood: true,
      ),
    ],
    subtotal: 440.0,
  );

  // ── DELIVERY OPTIONS ────────────────────────────────────────────────────
  static const ShopDeliveryOptions deliveryOptions = ShopDeliveryOptions(
    availableMethods: ['DELIVERY_TO_FLAT', 'SOCIETY_GATE_PICKUP', 'SELLER_FLAT_PICKUP'],
    pickupAvailable: true,
    sellerDeliveryAvailable: true,
    scheduleDeliveryAvailable: true,
    nearbyEligible: true,
    pickupAddress: 'Flat 402, Tower B, Green Valley Heights',
  );

  // ── SHOP SELLERS ────────────────────────────────────────────────────────
  static final List<ShopSeller> shopSellers = [
    ShopSeller(
      id: sellerId,
      userId: sellerUserId,
      societyId: societyId,
      displayName: 'Priya Sharma',
      businessName: 'Priya Homemade Delights & Crafts',
      sellerType: ShopSellerType.foodSeller,
      bio: 'Authentic home food, festive sweets, and homemade aroma candles.',
      availabilityStatus: ShopSellerAvailabilityStatus.available,
      approvalStatus: ShopSellerApprovalStatus.approved,
      fssaiStatus: ShopSellerFssaiStatus.verified,
      fssaiRequired: true,
      renewalStatus: ShopSellerRenewalStatus.renewed,
      totalListings: 6,
      averageRating: 4.9,
      rejectedOrders: 0,
      cancelledOrders: 1,
      totalOrders: 48,
      totalReviews: 32,
      createdAt: DateTime(2026, 1, 10),
      updatedAt: DateTime(2026, 10, 20),
    ),
    ShopSeller(
      id: 'seller_002',
      userId: 'usr_seller_002',
      societyId: societyId,
      displayName: 'Rajesh Verma',
      businessName: 'Verma Electric & AC Solutions',
      sellerType: ShopSellerType.serviceProvider,
      bio: 'Certified technician for all AC servicing, wiring, and appliance repairs.',
      availabilityStatus: ShopSellerAvailabilityStatus.available,
      approvalStatus: ShopSellerApprovalStatus.approved,
      fssaiStatus: ShopSellerFssaiStatus.notRequired,
      fssaiRequired: false,
      renewalStatus: ShopSellerRenewalStatus.renewed,
      totalListings: 4,
      averageRating: 4.8,
      rejectedOrders: 1,
      cancelledOrders: 0,
      totalOrders: 35,
      totalReviews: 28,
      createdAt: DateTime(2026, 2, 5),
      updatedAt: DateTime(2026, 10, 18),
    ),
    ShopSeller(
      id: 'seller_003',
      userId: 'usr_seller_003',
      societyId: societyId,
      displayName: 'Meera Deshmukh',
      businessName: 'Meera Organic Bakery',
      sellerType: ShopSellerType.foodSeller,
      bio: 'Sugar-free cookies, gluten-free artisan sourdough bread, and birthday cakes.',
      availabilityStatus: ShopSellerAvailabilityStatus.available,
      approvalStatus: ShopSellerApprovalStatus.approved,
      fssaiStatus: ShopSellerFssaiStatus.verified,
      fssaiRequired: true,
      renewalStatus: ShopSellerRenewalStatus.renewed,
      totalListings: 5,
      averageRating: 4.7,
      rejectedOrders: 0,
      cancelledOrders: 2,
      totalOrders: 22,
      totalReviews: 19,
      createdAt: DateTime(2026, 3, 12),
      updatedAt: DateTime(2026, 10, 22),
    ),
  ];

  // ── CERTIFICATES & KYC ──────────────────────────────────────────────────
  static final List<CertificateModel> certificates = [
    CertificateModel(
      id: 'cert_001',
      sellerId: sellerId,
      certificateType: 'FSSAI',
      certificateName: 'Food Safety and Standards Registration',
      issuingAuthority: 'Food Safety and Standards Authority of India',
      certificateFileUrl: 'https://societyseva.com/docs/fssai_cert_001.pdf',
      verificationStatus: 'VERIFIED',
      createdAt: DateTime(2026, 1, 15),
      updatedAt: DateTime(2026, 1, 15),
    ),
  ];

  static final List<KycDocumentModel> kycDocuments = [
    KycDocumentModel(
      id: 'kyc_001',
      sellerId: sellerId,
      documentType: 'AADHAAR',
      documentFileUrl: 'https://societyseva.com/docs/kyc_aadhaar_001.pdf',
      verificationStatus: 'VERIFIED',
      createdAt: DateTime(2026, 1, 12),
      updatedAt: DateTime(2026, 1, 12),
    ),
  ];

  static final List<SellerImageModel> sellerImages = [
    SellerImageModel(
      id: 'img_seller_1',
      sellerId: sellerId,
      imageUrl:
          'https://images.unsplash.com/photo-1556910103-1c02745aae4d?auto=format&fit=crop&w=600&q=80',
      moderationStatus: 'APPROVED',
      displayOrder: 1,
      createdAt: DateTime(2026, 1, 15),
      updatedAt: DateTime(2026, 1, 15),
    ),
  ];

  static final List<SellerListingImageModel> listingImages = [
    SellerListingImageModel(
      id: 'img_list_1',
      listingId: 'list_001',
      imageUrl:
          'https://images.unsplash.com/photo-1610057099443-fde8c4d50f91?auto=format&fit=crop&w=600&q=80',
      moderationStatus: 'APPROVED',
      displayOrder: 1,
      createdAt: DateTime(2026, 1, 15),
    ),
    SellerListingImageModel(
      id: 'img_list_2',
      listingId: 'list_002',
      imageUrl:
          'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=600&q=80',
      moderationStatus: 'APPROVED',
      displayOrder: 1,
      createdAt: DateTime(2026, 1, 15),
    ),
    SellerListingImageModel(
      id: 'img_list_3',
      listingId: 'list_003',
      imageUrl:
          'https://images.unsplash.com/photo-1581578731548-c64695cc6952?auto=format&fit=crop&w=600&q=80',
      moderationStatus: 'APPROVED',
      displayOrder: 1,
      createdAt: DateTime(2026, 1, 15),
    ),
    SellerListingImageModel(
      id: 'img_list_4',
      listingId: 'list_004',
      imageUrl:
          'https://images.unsplash.com/photo-1603006905003-be475563bc59?auto=format&fit=crop&w=600&q=80',
      moderationStatus: 'APPROVED',
      displayOrder: 1,
      createdAt: DateTime(2026, 1, 15),
    ),
  ];

  // ── FOOD & SERVICE DETAILS ──────────────────────────────────────────────
  static final FoodListingDetailsModel foodDetails = FoodListingDetailsModel(
    id: 'food_det_001',
    listingId: 'list_001',
    preparationTime: '45 mins',
    spiceLevel: 2,
    spiceLevelText: 'Medium Spice',
    freshnessDeclaration: 'Cooked fresh on order with pure sunflower oil and home-ground spices.',
    isFrozenItem: false,
    fssaiRequired: true,
    foodType: 'VEGETARIAN',
    ingredients: 'Wheat flour, Basmati Rice, Toor Dal, Paneer, Fresh Vegetables, Ghee, Spices',
    allergens: 'Dairy, Gluten',
    storageInstruction: 'Consume within 4 hours of delivery. Keep warm.',
    servingSizes: const [
      ServingSizeModel(
        id: 'size_std',
        sizeValue: 1,
        sizeUnit: 'Thali',
        description: 'Standard single person complete meal',
        price: 160.0,
        quantityAvailable: 15,
        isAvailable: true,
      ),
      ServingSizeModel(
        id: 'size_xl',
        sizeValue: 2,
        sizeUnit: 'Couple Thali',
        description: 'Double portion with extra paneer & sweets',
        price: 300.0,
        quantityAvailable: 8,
        isAvailable: true,
      ),
    ],
  );

  static final ServiceListingDetailsModel serviceDetails = ServiceListingDetailsModel(
    id: 'serv_det_001',
    listingId: 'list_003',
    serviceDurationMinutes: 120,
    serviceLocationType: 'BUYER_LOCATION',
    homeVisitAvailable: true,
    onlineAvailable: false,
    requiredMaterials: 'All cleaning liquids, scrubber pads, and safety gear provided by technician.',
    cancellationPolicy: 'Free cancellation up to 2 hours before scheduled time.',
    certificateRequired: false,
  );

  // ── SERVICE SLOTS ───────────────────────────────────────────────────────
  static final List<ServiceSlotModel> serviceSlots = [
    ServiceSlotModel(
      startsAt: DateTime.now().add(const Duration(hours: 2)),
      endsAt: DateTime.now().add(const Duration(hours: 4)),
      durationMinutes: 120,
      timeZone: 'Asia/Kolkata',
      status: 'AVAILABLE',
    ),
    ServiceSlotModel(
      startsAt: DateTime.now().add(const Duration(hours: 5)),
      endsAt: DateTime.now().add(const Duration(hours: 7)),
      durationMinutes: 120,
      timeZone: 'Asia/Kolkata',
      status: 'AVAILABLE',
    ),
  ];

  // ── ORDER STATUS HISTORY ────────────────────────────────────────────────
  static final List<OrderStatusHistoryModel> orderStatusHistory = [
    OrderStatusHistoryModel(
      id: 'hist_1',
      orderId: 'ord_001',
      oldStatus: 'CREATED',
      newStatus: 'PAID',
      note: 'Payment received via UPI',
      createdAt: DateTime.now().subtract(const Duration(minutes: 24)),
    ),
    OrderStatusHistoryModel(
      id: 'hist_2',
      orderId: 'ord_001',
      oldStatus: 'PAID',
      newStatus: 'ACCEPTED',
      note: 'Order confirmed by seller',
      createdAt: DateTime.now().subtract(const Duration(minutes: 20)),
    ),
  ];

  // ── GUEST SESSION ───────────────────────────────────────────────────────
  static final GuestSession guestSession = GuestSession(
    guestId: 'guest_998877',
    accessToken: 'guest_mock_access_token_123',
    tokenType: 'Bearer',
    expiresIn: 86400,
    nearestSocietyId: societyId,
    sessionTime: DateTime.now(),
  );

  // ── LOCATION CONTEXT & ADDRESSES ────────────────────────────────────────
  static final SavedAddress primaryAddress = SavedAddress(
    id: 'addr_001',
    label: 'Home (Flat 402)',
    addressLine1: 'Flat 402, Tower B, Green Valley Heights',
    city: 'Mumbai',
    country: 'India',
    pinCode: '400076',
    latitude: 19.1176,
    longitude: 72.9060,
    isDefault: true,
  );

  static final LocationContext locationContext = LocationContext(
    activeAddress: primaryAddress,
    discoveryMode: 'NEARBY',
    radiusKm: 5,
    savedAddresses: [primaryAddress],
  );

  // ── SOCIETIES & FLATS ───────────────────────────────────────────────────
  static final List<Society> societies = [
    Society(
      id: societyId,
      name: 'Green Valley Heights',
      address: 'Central Avenue, Powai, Mumbai - 400076',
      city: 'Mumbai',
      state: 'Maharashtra',
      country: 'India',
      pinCode: '400076',
      numberOfBuildings: 4,
      numberOfFloors: 14,
      totalFlats: 320,
      status: 'ACTIVE',
    ),
  ];

  static final List<Flat> flats = [
    Flat(
      id: 'flat_402',
      societyId: societyId,
      buildingId: 'bld_b',
      floorId: 'flr_4',
      flatNumber: 'B-402',
      ownerName: 'Priya Sharma',
      residentType: 'OWNER',
      occupancyStatus: 'OCCUPIED',
      status: 'ACTIVE',
    ),
  ];

  static final List<SocietyMembershipSummary> memberships = [
    SocietyMembershipSummary(
      id: 'mem_001',
      societyId: societyId,
      societyName: 'Green Valley Heights',
      flatId: 'flat_402',
      memberType: 'OWNER',
      verificationStatus: 'APPROVED',
      isActive: true,
    ),
  ];

  // ── AUTH TOKENS ─────────────────────────────────────────────────────────
  static final AuthTokens authTokens = AuthTokens(
    accessToken: 'mock_jwt_access_token_seller_society_seva',
    refreshToken: 'mock_jwt_refresh_token_seller_society_seva',
    tokenType: 'Bearer',
    expiresIn: 86400,
    userId: sellerUserId,
  );

  static final AuthOtpSent otpSent = AuthOtpSent(
    registrationToken: 'mock_reg_token_123456',
    otp: '123456',
    expiresIn: 300,
  );

  static final AuthOtpVerification otpVerified = AuthOtpVerification(
    nextStep: 'HOME',
    authTokens: authTokens,
  );

  // ── SYSTEM HEALTH ───────────────────────────────────────────────────────
  static const SystemHealth systemHealth = SystemHealth(
    success: true,
    data: HealthData(
      version: '1.0.0',
      timestamp: '2026-10-25T21:00:00Z',
      buildTime: '2026-10-25T21:00:00Z',
      artifact: 'society_seva_backend',
    ),
    message: 'System is healthy',
    requestId: 'req_health_mock_001',
  );
}
