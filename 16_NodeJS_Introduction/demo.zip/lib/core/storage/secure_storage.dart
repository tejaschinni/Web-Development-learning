import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:society_seva/features/auth/data/models/registration.dart';

class AppSecureStorage {
  AppSecureStorage._();

  static final AppSecureStorage _instance = AppSecureStorage._();

  factory AppSecureStorage() => _instance;

  static const _accessTokenKey = 'society_seva_access_token';
  static const _refreshTokenKey = 'society_seva_refresh_token';
  static const _pendingRegistrationKey = 'society_seva_pending_registration';
  static const _userModelKey = "userModel";
  static const _guestAccessTokenKey = 'society_seva_guest_access_token';
  static const _guestDeviceIdKey = 'society_seva_guest_device_id';

  final FlutterSecureStorage _storage = const FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
    iOptions: IOSOptions(accessibility: KeychainAccessibility.first_unlock_this_device),
  );

  Future<void> saveTokens({required String accessToken, required String refreshToken}) async {
    await _storage.write(key: _accessTokenKey, value: accessToken);
    await _storage.write(key: _refreshTokenKey, value: refreshToken);
  }

  Future<void> saveUserMode({required String userMode}) async {
    await _storage.write(key: _userModelKey, value: userMode);
  }

  Future<void> clearUserMode() => _storage.delete(key: _userModelKey);

  Future<String?> readUserMode() => _storage.read(key: _userModelKey);

  Future<String?> readAccessToken() => _storage.read(key: _accessTokenKey);

  Future<void> saveGuestSession({required String accessToken, required String guestId}) async {
    await _storage.write(key: _guestAccessTokenKey, value: accessToken);
    await _storage.write(key: 'society_seva_guest_id', value: guestId);
  }

  Future<String?> readGuestAccessToken() => _storage.read(key: _guestAccessTokenKey);

  Future<String?> readGuestDeviceId() => _storage.read(key: _guestDeviceIdKey);

  Future<void> saveGuestDeviceId(String deviceId) =>
      _storage.write(key: _guestDeviceIdKey, value: deviceId);

  Future<void> clearGuestSession() async {
    await _storage.delete(key: _guestAccessTokenKey);
    await _storage.delete(key: 'society_seva_guest_id');
  }

  Future<String?> readRefreshToken() => _storage.read(key: _refreshTokenKey);

  Future<Map<String, String?>> readSession() async {
    final accessToken = await readAccessToken();
    final refreshToken = await readRefreshToken();

    return {'accessToken': accessToken, 'refreshToken': refreshToken};
  }

  Future<void> clearSession() async {
    await _storage.delete(key: _accessTokenKey);
    await _storage.delete(key: _refreshTokenKey);
    await _storage.delete(key: _userModelKey);
    await clearGuestSession();
  }

  Future<void> savePendingRegistration(PendingRegistration registration) {
    return _storage.write(key: _pendingRegistrationKey, value: jsonEncode(registration.toJson()));
  }

  Future<PendingRegistration?> readPendingRegistration() async {
    final value = await _storage.read(key: _pendingRegistrationKey);
    if (value == null || value.isEmpty) {
      return null;
    }

    try {
      final json = jsonDecode(value);
      if (json is! Map) {
        return null;
      }
      final registration = PendingRegistration.fromJson(Map<String, dynamic>.from(json));
      return registration.registrationToken.isEmpty ? null : registration;
    } on FormatException {
      return null;
    }
  }

  Future<void> clearPendingRegistration() {
    return _storage.delete(key: _pendingRegistrationKey);
  }
}
