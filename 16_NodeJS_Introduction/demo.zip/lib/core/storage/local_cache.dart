import 'dart:convert';
import 'dart:math';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:hive_ce_flutter/hive_flutter.dart';

class LocalCache {
  LocalCache._();

  static final LocalCache instance = LocalCache._();

  static const _encryptionKeyName = 'society_seva_local_cache_key';
  static const _boxName = 'society_seva_cache';

  final FlutterSecureStorage _secureStorage = const FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
    iOptions: IOSOptions(accessibility: KeychainAccessibility.first_unlock_this_device),
  );

  Box<String>? _box;

  Future<void> initialize() async {
    if (_box != null) {
      return;
    }

    await Hive.initFlutter();
    final encryptionKey = await _encryptionKey();
    _box = await Hive.openBox<String>(_boxName, encryptionCipher: HiveAesCipher(encryptionKey));
  }

  Future<void> writeJson(String key, Map<String, dynamic> value) async {
    await initialize();
    await _box!.put(key, jsonEncode(value));
  }

  Future<Map<String, dynamic>?> readJson(String key) async {
    await initialize();
    return readJsonSync(key);
  }

  Map<String, dynamic>? readJsonSync(String key) {
    if (_box == null) {
      return null;
    }
    final value = _box!.get(key);
    if (value == null) {
      return null;
    }

    final decoded = jsonDecode(value);
    return decoded is Map ? Map<String, dynamic>.from(decoded) : null;
  }

  Future<void> delete(String key) async {
    await initialize();
    await _box!.delete(key);
  }

  Future<void> clearUser(String userId) async {
    await initialize();
    final prefix = 'user:$userId:';
    final keys = _box!.keys.where((key) => key.toString().startsWith(prefix));
    await _box!.deleteAll(keys);
  }

  Future<void> clearAll() async {
    await initialize();
    await _box!.clear();
  }

  Future<void> clearSessionData() async {
    await initialize();
    final appData = <dynamic, String>{};
    for (final key in _box!.keys) {
      if (key is String && key.startsWith('app:')) {
        final value = _box!.get(key);
        if (value != null) {
          appData[key] = value;
        }
      }
    }

    await _box!.clear();
    await _box!.putAll(appData);
  }

  Future<List<int>> _encryptionKey() async {
    final saved = await _secureStorage.read(key: _encryptionKeyName);
    if (saved != null && saved.isNotEmpty) {
      return base64Url.decode(saved);
    }

    final random = Random.secure();
    final key = List<int>.generate(32, (_) => random.nextInt(256));
    await _secureStorage.write(key: _encryptionKeyName, value: base64UrlEncode(key));
    return key;
  }
}
