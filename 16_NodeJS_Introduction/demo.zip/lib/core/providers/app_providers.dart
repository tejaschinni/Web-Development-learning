import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/core/config/app_config.dart';
import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/storage/secure_storage.dart';

final appConfigProvider = Provider<AppConfig>((ref) {
  return AppConfig.environmentFor('development');
});

final secureStorageProvider = Provider<AppSecureStorage>((ref) {
  return AppSecureStorage();
});

final apiClientProvider = Provider<ApiClient>((ref) {
  final config = ref.watch(appConfigProvider);
  return ApiClient(config: config);
});
