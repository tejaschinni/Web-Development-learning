import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/features/auth/presentation/providers/session_provider.dart';
import 'package:society_seva/features/auth/presentation/providers/registration_provider.dart';
import 'package:society_seva/features/location/presentation/providers/location_provider.dart';
import 'package:society_seva/features/profile/presentation/providers/profile_provider.dart';
import 'package:society_seva/features/profile/presentation/providers/user_mode_provider.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_listing_provider.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_cart_provider.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_listing_provider.dart'
    hide serviceScheduleDatesProvider, serviceScheduleSlotsProvider;
import 'package:society_seva/features/shop/presentation/providers/shop_seller_provider.dart';
import 'package:society_seva/features/shop/presentation/screens/seva_home_screen.dart';

void resetUserSessionState(WidgetRef ref) {
  ref.invalidate(appSessionProvider);
  ref.invalidate(registrationControllerProvider);
  ref.invalidate(locationContextProvider);
  ref.invalidate(profileControllerProvider);
  ref.invalidate(shopCartProvider);
  ref.invalidate(shopCategoryListingsProvider);
  ref.invalidate(shopListingProvider);
  ref.invalidate(shopListingImagesProvider);
  ref.invalidate(shopFoodDetailsProvider);
  ref.invalidate(shopServiceDetailsProvider);
  ref.invalidate(serviceScheduleDatesProvider);
  ref.invalidate(serviceScheduleSlotsProvider);
  ref.invalidate(shopSellerListingsProvider);
  ref.invalidate(shopPopularListingsProvider);
  ref.invalidate(shopPopularSellersProvider);
  ref.invalidate(sevaFavsProvider);
  ref.invalidate(sevaNavProvider);
  ref.invalidate(sellerProfileByIdProvider);
  ref.invalidate(mySellerProfileProvider);
  ref.invalidate(fetchSellerUploadedImagesProvider);
  ref.invalidate(sellerCertificatesProvider);
  ref.invalidate(sellerDocumentProvider);
  ref.invalidate(sellerListingProvider);
  ref.invalidate(sellerListingImagesProvider);
  unawaited(ref.read(userModeProvider.notifier).reset());
}
