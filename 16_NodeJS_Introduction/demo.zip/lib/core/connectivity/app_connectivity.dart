import 'package:connectivity_plus/connectivity_plus.dart';

class AppConnectivity {
  AppConnectivity._();

  static final AppConnectivity _instance = AppConnectivity._();

  factory AppConnectivity() => _instance;

  final Connectivity _connectivity = Connectivity();

  Future<bool> get hasConnection async {
    final result = await _connectivity.checkConnectivity();
    return result.isNotEmpty && !result.contains(ConnectivityResult.none);
  }

  Stream<bool> get onConnectivityChanged =>
      _connectivity.onConnectivityChanged.map(
        (event) => event.isNotEmpty && !event.contains(ConnectivityResult.none),
      );
}
