class ApiException implements Exception {
  const ApiException({
    required this.message,
    this.statusCode,
    this.requestId,
    this.isNetwork = false,
  });

  final String message;
  final int? statusCode;
  final String? requestId;
  final bool isNetwork;

  @override
  String toString() {
    if (requestId == null || requestId!.isEmpty) {
      return message;
    }

    return '$message (Request ID: $requestId)';
  }
}
