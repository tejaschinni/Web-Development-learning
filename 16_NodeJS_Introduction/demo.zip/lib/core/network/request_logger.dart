import 'dart:convert';
import 'package:flutter/material.dart';

class RequestLogger {
  static final GlobalKey<ScaffoldMessengerState> scaffoldMessengerKey =
      GlobalKey<ScaffoldMessengerState>();

  static void logPost({
    required String endpoint,
    Object? payload,
    Map<String, dynamic>? queryParameters,
    String method = 'POST',
  }) {
    final payloadString = _formatPayload(payload ?? queryParameters);

    const divider = '═════════════════════════════════════════════════════════════════';
    debugPrint('\n$divider');
    debugPrint('🚀 [API REQUEST] Method: $method');
    debugPrint('🔗 Endpoint:     $endpoint');
    debugPrint('📦 Payload:      $payloadString');
    if (queryParameters != null && payload != null) {
      debugPrint('🔍 Query Params: ${jsonEncode(queryParameters)}');
    }
    debugPrint('$divider\n');

    try {
      final messenger = scaffoldMessengerKey.currentState;
      if (messenger != null) {
        messenger.hideCurrentSnackBar();
        messenger.showSnackBar(
          SnackBar(
            behavior: SnackBarBehavior.floating,
            duration: const Duration(seconds: 4),
            backgroundColor: const Color(0xFF1E293B),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: const Color(0xFF10B981),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        method,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 11,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        endpoint,
                        style: const TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 13,
                          color: Colors.white,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  'Payload: $payloadString',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 11,
                    color: Color(0xFF94A3B8),
                  ),
                ),
              ],
            ),
          ),
        );
      }
    } catch (_) {
      // Ignore UI notification error if context/messenger isn't active
    }
  }

  static String _formatPayload(Object? payload) {
    if (payload == null) return 'null';
    try {
      if (payload is Map || payload is List) {
        return jsonEncode(payload);
      }
      return payload.toString();
    } catch (_) {
      return payload.toString();
    }
  }
}
