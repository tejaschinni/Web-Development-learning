import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:society_seva/core/config/app_config.dart';
import 'package:society_seva/core/network/api_exception.dart';
import 'package:society_seva/core/network/request_logger.dart';
import 'package:society_seva/core/storage/secure_storage.dart';

class ApiClient {
  ApiClient({required AppConfig config})
    : _config = config,
      _dio = Dio(
        BaseOptions(
          baseUrl: config.apiBaseUrl,
          connectTimeout: const Duration(seconds: 20),
          receiveTimeout: const Duration(seconds: 20),
          sendTimeout: const Duration(seconds: 20),
          headers: {'Accept': 'application/json', 'Content-Type': 'application/json'},
        ),
      ) {
    _dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) async {
          options.headers['X-API-Key'] = _config.apiKey;

          final storage = AppSecureStorage();
          final accessToken =
              await storage.readAccessToken() ?? await storage.readGuestAccessToken();
          if (accessToken != null && accessToken.isNotEmpty) {
            options.headers['Authorization'] = 'Bearer $accessToken';
          }

          handler.next(options);
        },
        onError: (error, handler) async {
          if (_canRefreshRequest(error.requestOptions) && error.response?.statusCode == 401) {
            final refreshed = await _refreshTokenIfPossible();
            if (refreshed) {
              final retryRequest = await _retry(error.requestOptions);
              return handler.resolve(retryRequest);
            }
          }

          return handler.next(error);
        },
      ),
    );

    _addDebugLogging(_dio);
  }

  final AppConfig _config;
  final Dio _dio;
  final AppSecureStorage _storage = AppSecureStorage();
  bool _isRefreshing = false;
  Completer<bool> _refreshCompleter = Completer<bool>();

  Future<Response<dynamic>> get(String path, {Map<String, dynamic>? queryParameters}) async {
    try {
      final response = await _dio.get(path, queryParameters: queryParameters);
      return response;
    } on DioException catch (error) {
      throw _mapDioError(error);
    }
  }

  Future<Response<dynamic>> post(
    String path, {
    Object? data,
    Map<String, dynamic>? queryParameters,
  }) async {
    RequestLogger.logPost(
      endpoint: path,
      payload: data,
      queryParameters: queryParameters,
      method: 'POST',
    );
    try {
      final response = await _dio.post(path, data: data, queryParameters: queryParameters);
      return response;
    } on DioException catch (error) {
      throw _mapDioError(error);
    }
  }

  Future<Response<dynamic>> put(String path, {Object? data}) async {
    try {
      final response = await _dio.put(path, data: data);
      return response;
    } on DioException catch (error) {
      throw _mapDioError(error);
    }
  }

  Future<Response<dynamic>> patch(String path, {Object? data}) async {
    try {
      final response = await _dio.patch(path, data: data);
      return response;
    } on DioException catch (error) {
      throw _mapDioError(error);
    }
  }

  Future<Response<dynamic>> delete(String path, {Object? data}) async {
    try {
      final response = await _dio.delete(path, data: data);
      return response;
    } on DioException catch (error) {
      throw _mapDioError(error);
    }
  }

  Future<bool> _refreshTokenIfPossible() async {
    if (_isRefreshing) {
      return _refreshCompleter.future;
    }

    _isRefreshing = true;
    _refreshCompleter = Completer<bool>();
    var refreshed = false;

    try {
      final refreshToken = await _storage.readRefreshToken();
      if (refreshToken == null || refreshToken.isEmpty) {
        await _storage.clearSession();
        return false;
      }

      final refreshDio = Dio(
        BaseOptions(
          baseUrl: _config.apiBaseUrl,
          connectTimeout: const Duration(seconds: 20),
          receiveTimeout: const Duration(seconds: 20),
          sendTimeout: const Duration(seconds: 20),
        ),
      );
      _addDebugLogging(refreshDio);

      final response = await refreshDio.post(
        '/api/v1/auth/refresh',
        data: {'refreshToken': refreshToken},
        options: Options(headers: {'X-API-Key': _config.apiKey}),
      );

      if (response.statusCode == 200 && response.data is Map) {
        final map = response.data as Map<String, dynamic>;
        final nextAccessToken = map['accessToken'] as String?;
        final nextRefreshToken = map['refreshToken'] as String?;

        if (nextAccessToken != null && nextRefreshToken != null) {
          await _storage.saveTokens(accessToken: nextAccessToken, refreshToken: nextRefreshToken);
          refreshed = true;
          return true;
        }
      }

      await _storage.clearSession();
      return false;
    } catch (_) {
      await _storage.clearSession();
      return false;
    } finally {
      _isRefreshing = false;
      if (!_refreshCompleter.isCompleted) {
        _refreshCompleter.complete(refreshed);
      }
    }
  }

  bool _canRefreshRequest(RequestOptions requestOptions) {
    if (requestOptions.extra['authRetry'] == true) {
      return false;
    }

    final path = requestOptions.path;
    return !path.contains('/api/v1/auth/') &&
        !path.contains('/api/auth/') &&
        !path.contains('/api/v1/guest/');
  }

  Future<Response<dynamic>> _retry(RequestOptions requestOptions) async {
    final accessToken = await _storage.readAccessToken();
    final options = Options(
      method: requestOptions.method,
      extra: {...requestOptions.extra, 'authRetry': true},
      headers: {...requestOptions.headers, 'Authorization': 'Bearer $accessToken'},
    );

    return _dio.request(
      requestOptions.path,
      data: requestOptions.data,
      queryParameters: requestOptions.queryParameters,
      options: options,
    );
  }

  ApiException _mapDioError(DioException error) {
    if (error.type == DioExceptionType.connectionError ||
        error.type == DioExceptionType.connectionTimeout ||
        error.type == DioExceptionType.receiveTimeout ||
        error.type == DioExceptionType.sendTimeout) {
      return const ApiException(
        message: "You're offline. Please check your connection and try again.",
        isNetwork: true,
      );
    }

    if (error.error is SocketException) {
      return const ApiException(
        message: "You're offline. Please check your connection and try again.",
        isNetwork: true,
      );
    }

    final statusCode = error.response?.statusCode;
    final responseData = error.response?.data;
    final message = _extractMessage(responseData, statusCode);
    final requestId = _extractRequestId(responseData);

    if (statusCode == 401) {
      return ApiException(
        message: message ?? 'Your session has expired. Please sign in again.',
        statusCode: 401,
        requestId: requestId,
      );
    }

    if (statusCode == 403) {
      return ApiException(
        message: message ?? "You don't have permission to perform this action.",
        statusCode: 403,
        requestId: requestId,
      );
    }

    if (statusCode == 404) {
      return ApiException(
        message: message ?? 'The requested resource could not be found.',
        statusCode: 404,
        requestId: requestId,
      );
    }

    if (statusCode == 409) {
      return ApiException(
        message: message ?? 'This action conflicts with the current state.',
        statusCode: 409,
        requestId: requestId,
      );
    }

    if (statusCode == 422) {
      return ApiException(
        message: message ?? 'The submitted data is invalid.',
        statusCode: 422,
        requestId: requestId,
      );
    }

    if (statusCode == 429) {
      return ApiException(
        message: message ?? 'Too many requests. Please try again in a moment.',
        statusCode: 429,
        requestId: requestId,
      );
    }

    if (statusCode != null && statusCode >= 500) {
      return ApiException(
        message: message ?? 'Something went wrong on the server. Please try again soon.',
        statusCode: statusCode,
        requestId: requestId,
      );
    }

    return ApiException(
      message: message ?? 'An unexpected error occurred. Please try again.',
      statusCode: statusCode,
      requestId: requestId,
    );
  }

  void _addDebugLogging(Dio dio) {
    if (!kDebugMode || _config.environment != AppEnvironment.development) {
      return;
    }

    dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) {
          debugPrint(
            '[API][REQUEST] ${options.method} ${options.uri}\n'
            'body: ${_formatDebugValue(options.data)}',
          );
          handler.next(options);
        },
        onResponse: (response, handler) {
          debugPrint(
            '[API][RESPONSE] ${response.requestOptions.method} '
            '${response.requestOptions.uri}\n'
            'status: ${response.statusCode}\n'
            'body: ${_formatDebugValue(response.data)}',
          );
          handler.next(response);
        },
        onError: (error, handler) {
          debugPrint(
            '[API][ERROR] ${error.requestOptions.method} '
            '${error.requestOptions.uri}\n'
            'status: ${error.response?.statusCode ?? 'no response'}\n'
            'body: ${_formatDebugValue(error.response?.data)}',
          );
          handler.next(error);
        },
      ),
    );
  }

  String _formatDebugValue(dynamic value) {
    if (value == null) {
      return 'null';
    }

    try {
      return jsonEncode(_redactDebugValue(value));
    } catch (_) {
      return value.toString();
    }
  }

  dynamic _redactDebugValue(dynamic value) {
    if (value is Map) {
      return value.map(
        (key, nestedValue) => MapEntry(
          key,
          _isSensitiveKey(key.toString()) ? '<redacted>' : _redactDebugValue(nestedValue),
        ),
      );
    }

    if (value is Iterable) {
      return value.map(_redactDebugValue).toList();
    }

    return value;
  }

  bool _isSensitiveKey(String key) {
    final normalized = key.toLowerCase().replaceAll('_', '').replaceAll('-', '');
    return normalized.contains('token') ||
        normalized.contains('authorization') ||
        normalized.contains('apikey') ||
        normalized.contains('clientsecret');
  }

  String? _extractMessage(dynamic responseData, int? statusCode) {
    if (responseData is Map<String, dynamic>) {
      final successMessage = responseData['message'];
      if (successMessage is String && successMessage.isNotEmpty) {
        return successMessage;
      }

      final detail = responseData['detail'];
      if (detail is String && detail.isNotEmpty) {
        return detail;
      }
    }

    if (responseData is Map) {
      final messageValue = responseData['message'];
      if (messageValue is String && messageValue.isNotEmpty) {
        return messageValue;
      }
    }

    if (statusCode == 400) {
      return 'The submitted information is invalid.';
    }

    return null;
  }

  String? _extractRequestId(dynamic responseData) {
    if (responseData is Map) {
      final requestId = responseData['requestId'];
      return requestId is String && requestId.isNotEmpty ? requestId : null;
    }

    return null;
  }
}
