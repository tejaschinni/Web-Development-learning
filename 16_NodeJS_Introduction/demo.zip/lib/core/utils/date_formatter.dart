import 'package:intl/intl.dart';

extension DateTimeFormatter on DateTime {
  String toOrderDate() {
    final date = toLocal();
    final now = DateTime.now();
    final isToday = date.year == now.year && date.month == now.month && date.day == now.day;
    final time = DateFormat('hh:mm a').format(date);

    return isToday ? 'Today, $time' : '${DateFormat('d MMM yyyy').format(date)}, $time';
  }
}

String formatOrderDate(DateTime? dateTime) {
  if (dateTime == null) return '-';

  final date = dateTime.toLocal();
  final now = DateTime.now();

  final isToday = date.year == now.year && date.month == now.month && date.day == now.day;

  final time = DateFormat('hh:mm a').format(date);

  return isToday ? 'Today, $time' : '${DateFormat('d MMM yyyy').format(date)}, $time';
}

int? minutesFromEpochString(String? iso) {
  if (iso == null || iso.isEmpty) return null;
  final dt = DateTime.tryParse(iso);
  if (dt == null) return null;
  // the backend stores the entered minutes as epoch seconds
  return dt.toUtc().difference(DateTime.utc(1970)).inSeconds;
}
