import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:society_seva/features/auth/presentation/providers/auth_provider.dart';
import 'package:society_seva/features/auth/presentation/providers/registration_provider.dart';
import 'package:society_seva/features/auth/presentation/screens/authenticated_home_screen.dart';
import 'package:society_seva/features/auth/presentation/screens/app_startup_screen.dart';
import 'package:society_seva/features/auth/presentation/screens/login_screen.dart';
import 'package:society_seva/features/auth/presentation/screens/otp_flow_screens.dart';
import 'package:society_seva/features/guest/presentation/providers/guest_provider.dart';
import 'package:society_seva/features/guest/presentation/screens/guest_browse_screen.dart';
import 'package:society_seva/features/profile/presentation/providers/user_mode_provider.dart';
import 'package:society_seva/features/profile/presentation/screens/edit_profile_screen.dart';
import 'package:society_seva/features/profile/presentation/screens/profile_screen.dart';
import 'package:society_seva/features/profile/presentation/screens/phone_number_verification_screen.dart';
import 'package:society_seva/features/location/presentation/screens/location_picker_screen.dart';
import 'package:society_seva/features/seller/domain/entities/order_status_history_entity.dart';
import 'package:society_seva/features/seller/domain/entities/seller_order_entity.dart';
import 'package:society_seva/features/seller/presentation/screens/dashboard/seller_dashboard_screen.dart';
import 'package:society_seva/features/seller/presentation/screens/listing/add_seller_listing_screen.dart';
import 'package:society_seva/features/seller/presentation/screens/on_boarding/seller_onboarding_screen.dart';
import 'package:society_seva/features/seller/presentation/screens/order/order_accepted_screen.dart';
import 'package:society_seva/features/seller/presentation/screens/order/order_update_screen.dart';
import 'package:society_seva/features/seller/presentation/screens/order/seller_order_detail_screen.dart';
import 'package:society_seva/features/shop/presentation/screens/seva_home_screen.dart';
import 'package:society_seva/features/shop/presentation/screens/shop_categories_screen.dart';
import 'package:society_seva/features/shop/presentation/widgets/listing/shop_product_list.dart';
import 'package:society_seva/features/shop/presentation/widgets/seller/shop_all_sellers_list.dart';
import 'package:society_seva/features/society/presentation/screens/society_onboarding_screen.dart';
import 'package:society_seva/features/common/presentation/screens/common_modules_screen.dart';
import 'package:society_seva/features/seller/presentation/screens/on_boarding/seller_modules_screen.dart';
import 'package:society_seva/features/society_admin/presentation/screens/society_admin_modules_screen.dart';
import 'package:society_seva/features/super_admin/presentation/screens/super_admin_modules_screen.dart';
import 'package:society_seva/features/shop/presentation/screens/shop_search_screen.dart';
import 'package:society_seva/features/shop/presentation/screens/category_listing_screen.dart';
import 'package:society_seva/features/shop/presentation/screens/seller_store_screen.dart';
import 'package:society_seva/features/shop/presentation/screens/product_details_screen.dart';
import 'package:society_seva/features/shop/presentation/screens/service_details_screen.dart';
import 'package:society_seva/features/shop/presentation/screens/shop_cart_screen.dart';
import 'package:society_seva/features/shop/presentation/screens/shop_checkout_screen.dart';
import 'package:society_seva/features/shop/presentation/screens/shop_checkout_confirmation_screen.dart';
import 'package:society_seva/features/shop/presentation/screens/shop_order_placed_screen.dart';
import 'package:society_seva/features/shop/presentation/screens/shop_orders_screen.dart';
import 'package:society_seva/features/shop/presentation/screens/shop_payments_screen.dart';
import 'package:society_seva/features/shop/presentation/screens/shop_order_tracking_screen.dart'
    as order_tracking;
import 'package:society_seva/features/shop/presentation/screens/shop_service_booking_details_screen.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing.dart';
import 'package:society_seva/features/shop/domain/entities/shop_cart.dart';

class AppRouter {
  static final GoRouter router = GoRouter(
    initialLocation: '/startup',
    redirect: (context, state) {
      final container = ProviderScope.containerOf(context);
      final authState = container.read(authControllerProvider);

      return authState.when(
        data: (sessionState) {
          final isAuthenticated = sessionState.isAuthenticated;

          if (state.matchedLocation == '/startup' || state.matchedLocation == '/login') {
            return '/modules/seller/sellerDashboard';
          }

          if (state.matchedLocation == '/' &&
              container.read(userModeProvider) == UserMode.seller) {
            return '/modules/seller/sellerDashboard';
          }

          final pending = container.read(registrationControllerProvider).valueOrNull;
          if (pending != null && !isAuthenticated) {
            return pending.profileCompletionRequired ? '/complete-profile' : '/verify-otp';
          }

          if (state.matchedLocation == '/guest' || state.matchedLocation.startsWith('/guest/')) {
            return container.read(guestAccessProvider).isActive ? null : '/modules/seller/sellerDashboard';
          }

          const protectedLocations = {
            '/',
            '/dashboard',
            '/society-onboarding',
            '/profile',
            '/profile/edit',
            '/phone-number',
            '/locations',
            '/modules/seller/sellerDashboard',
            '/modules/common',
            '/modules/seller',
            '/modules/society-admin',
            '/modules/super-admin',
          };

          if (isAuthenticated && protectedLocations.contains(state.matchedLocation)) {
            return null;
          }

          if (state.matchedLocation == '/shop' || state.matchedLocation.startsWith('/shop/')) {
            return null;
          }

          if (!isAuthenticated && protectedLocations.contains(state.matchedLocation)) {
            return '/modules/seller/sellerDashboard';
          }

          return null;
        },
        loading: () => state.matchedLocation == '/startup' ? null : '/startup',
        error: (_, _) {
          return '/modules/seller/sellerDashboard';
        },
      );
    },
    routes: [
      GoRoute(path: '/startup', builder: (context, state) => const AppStartupScreen()),

      GoRoute(path: '/', builder: (context, state) => const AuthenticatedHomeScreen()),

      GoRoute(
        path: '/dashboard',
        builder: (context, state) => const AuthenticatedHomeScreen(bypassResidentGate: true),
      ),

      GoRoute(path: '/login', builder: (context, state) => const LoginScreen()),

      GoRoute(
        path: '/guest',
        builder: (context, state) =>
            GuestBrowseScreen(societyId: state.extra is String ? state.extra as String : null),
      ),

      GoRoute(
        path: '/guest/listings/:listingId',
        builder: (context, state) => GuestListingDetailsScreen(
          listingId: state.pathParameters['listingId']!,
          isTrending: state.extra == true,
        ),
      ),

      GoRoute(path: '/verify-otp', builder: (context, state) => const OtpVerificationScreen()),

      GoRoute(
        path: '/complete-profile',
        builder: (context, state) => const CompleteProfileScreen(),
      ),

      GoRoute(path: '/profile', builder: (context, state) => const ProfileScreen()),

      GoRoute(path: '/locations', builder: (context, state) => const LocationPickerScreen()),

      GoRoute(path: '/profile/edit', builder: (context, state) => const EditProfileScreen()),

      GoRoute(
        path: '/phone-number',
        builder: (context, state) => const PhoneNumberVerificationScreen(),
      ),

      GoRoute(
        path: '/society-onboarding',
        builder: (context, state) => const SocietyOnboardingScreen(),
      ),

      GoRoute(path: '/modules/common', builder: (context, state) => const CommonModulesScreen()),

      GoRoute(path: '/modules/seller', builder: (context, state) => const SellerModulesScreen()),

      GoRoute(
        path: '/modules/society-admin',
        builder: (context, state) => const SocietyAdminModulesScreen(),
      ),

      GoRoute(
        path: '/modules/super-admin',
        builder: (context, state) => const SuperAdminModulesScreen(),
      ),

      GoRoute(path: '/shop', builder: (context, state) => const SevaHomeScreen()),

      GoRoute(
        path: '/shop/search',
        builder: (context, state) => ShopSearchScreen(initialQuery: state.uri.queryParameters['q']),
      ),

      GoRoute(
        path: '/shop/:listingType/category/:categoryId',
        builder: (context, state) {
          final categoryId = state.pathParameters['categoryId']!;
          final listingType = state.pathParameters['listingType']!;
          final societyId = state.extra is String ? state.extra as String : null;

          return CategoryListingScreen(
            categoryId: categoryId,
            categoryName: state.uri.queryParameters['name'] ?? categoryId,
            societyId: societyId,
            listingType: listingType == 'service'
                ? ShopListingType.service
                : ShopListingType.product,
          );
        },
      ),

      GoRoute(
        path: '/shop/categories',
        builder: (context, state) {
          final societyId = state.extra is String ? state.extra as String : null;
          return ShopCategoriesScreen(societyId: societyId);
        },
      ),

      GoRoute(
        path: '/shop/listings',
        builder: (context, state) {
          return ProductList(societyId: state.extra as String?);
        },
      ),

      GoRoute(
        path: '/shop/sellers',
        builder: (context, state) {
          return ShopAllSellersList(societyId: state.extra as String?);
        },
      ),

      GoRoute(
        path: '/shop/seller/:sellerId',
        builder: (context, state) {
          final sellerId = state.pathParameters['sellerId']!;
          return SellerStoreScreen(sellerId: sellerId);
        },
      ),

      GoRoute(
        path: '/shop/product/:productId',
        builder: (context, state) => ProductDetailsScreen(
          productId: state.pathParameters['productId']!,
          listing: state.extra is ShopListing ? state.extra as ShopListing : null,
        ),
      ),

      GoRoute(
        path: '/shop/service/:serviceId',
        builder: (context, state) => ServiceDetailsScreen(
          serviceId: state.pathParameters['serviceId']!,
          listing: state.extra is ShopListing ? state.extra as ShopListing : null,
        ),
      ),

      GoRoute(path: '/shop/cart', builder: (context, state) => const ShopCartScreen()),

      GoRoute(
        path: '/shop/checkout',
        builder: (context, state) {
          final cart = state.extra is ShopCart ? state.extra as ShopCart : null;
          return cart == null ? const ShopCartScreen() : ShopCheckoutScreen(cart: cart);
        },
      ),

      GoRoute(
        path: '/shop/checkout/review',
        builder: (context, state) {
          final submission = state.extra;
          return submission is ShopCheckoutSubmission
              ? ShopCheckoutConfirmationScreen(submission: submission)
              : const ShopCartScreen();
        },
      ),

      GoRoute(
        path: '/shop/order-placed',
        builder: (context, state) {
          final orderData = state.extra;
          return orderData is ShopOrderPlacedData
              ? ShopOrderPlacedScreen(orderData: orderData)
              : const ShopOrdersScreen();
        },
      ),

      GoRoute(path: '/shop/orders', builder: (context, state) => const ShopOrdersScreen()),

      GoRoute(path: '/shop/payments', builder: (context, state) => const ShopPaymentsScreen()),

      GoRoute(
        path: '/shop/orders/:orderId',
        builder: (context, state) {
          final orderId = state.pathParameters['orderId']!;
          final extra = state.extra;
          return order_tracking.ShopOrderTrackingScreen(
            orderData: extra is order_tracking.ShopOrderTrackingData
                ? extra
                : order_tracking.ShopOrderTrackingData(
                    orderId: orderId,
                    sellerId: '',
                    sellerName: 'Seller',
                    status: order_tracking.ShopOrderStatus.confirmed,
                    statusTitle: 'Order confirmed',
                    statusDescription: 'Your order has been confirmed.',
                    fulfillmentMethod: order_tracking.ShopTrackingFulfillmentMethod.deliverToMyFlat,
                    fulfillmentTitle: 'Delivery to your flat',
                    fulfillmentDetail: 'Your registered address',
                    items: const [],
                    subtotal: 0,
                    totalAmount: 0,
                    paymentMethodLabel: 'Payment pending',
                    paymentStatusLabel: 'Pending',
                  ),
          );
        },
      ),

      GoRoute(
        path: '/shop/bookings/:bookingId',
        builder: (context, state) {
          final extra = state.extra;
          return ShopServiceBookingDetailsScreen(
            booking: extra is ShopServiceBookingDetails
                ? extra
                : ShopServiceBookingDetails.mock(bookingId: state.pathParameters['bookingId']),
          );
        },
      ),

      GoRoute(
        path: '/modules/seller/onboarding',
        builder: (context, state) {
          final isEdit = state.extra as bool? ?? false;
          return SellerOnboardingScreen(isEdit: isEdit);
        },
      ),

      GoRoute(
        path: '/modules/seller/sellerDashboard',
        builder: (context, state) {
          return SellerDashboardScreen();
        },
      ),
      GoRoute(
        path: '/modules/seller/addListing',
        builder: (context, state) {
          final extra = state.extra as Map<String, dynamic>? ?? {};
          final bool isEdit = extra['isEdit'] as bool? ?? false;
          final String? listingId = extra['listingId'] as String?;
          return AddSellerListingScreen(isEdit: isEdit, listingId: listingId);
        },
      ),

      GoRoute(
        path: '/modules/seller/orderDetails',
        builder: (context, state) {
          final extra = state.extra as OrderDetailsArgs?;
          return OrderDetailsScreen(orderDetailEntity: extra);
        },
      ),

      GoRoute(
        path: '/modules/seller/orderAccepted',
        builder: (context, state) {
          final extra = state.extra as SellerOrderEntity?;
          return OrderAcceptedScreen(order: extra);
        },
      ),

      GoRoute(
        path: '/modules/seller/orderUpdate',
        builder: (context, state) {
          final extra = state.extra as OrderStatusUpdateArgs?;
          return UpdateOrderStatusScreen(orderArgs: extra!);
        },
      ),
    ],
  );
}

class OrderStatusUpdateArgs {
  final OrderStatusHistoryEntity stage;
  final SellerOrderEntity order;
  const OrderStatusUpdateArgs({required this.order, required this.stage});
}

class OrderDetailsArgs {
  const OrderDetailsArgs({required this.order, required this.buyerName});

  final SellerOrderEntity order;
  final String buyerName;
}
