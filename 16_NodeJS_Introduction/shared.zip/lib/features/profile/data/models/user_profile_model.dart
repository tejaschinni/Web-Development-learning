import 'package:society_seva/features/profile/domain/entities/user_profile.dart';

class UserProfileModel {
  const UserProfileModel({
    required this.id,
    required this.fullName,
    required this.gender,
    required this.dateOfBirth,
    required this.mobileNumber,
    required this.email,
    required this.emailVerified,
    this.profilePhotoUrl,
    required this.preferredLanguage,
    required this.accountStatus,
    required this.roles,
  });

  factory UserProfileModel.fromJson(Map<String, dynamic> json) {
    final rawRoles = json['roles'];
    return UserProfileModel(
      id: json['id'] as String? ?? '',
      fullName: json['fullName'] as String? ?? '',
      gender: json['gender'] as String? ?? '',
      dateOfBirth: json['dateOfBirth'] as String? ?? '',
      mobileNumber: (json['mobileNumberMasked'] ?? json['mobileNumber']) as String? ?? '',
      email: (json['emailMasked'] ?? json['email']) as String? ?? '',
      emailVerified: json['emailVerified'] as bool? ?? false,
      profilePhotoUrl: json['profilePhotoUrl'] as String?,
      preferredLanguage: json['preferredLanguage'] as String? ?? '',
      accountStatus: json['accountStatus'] as String? ?? '',
      roles: rawRoles is List
          ? rawRoles.map((role) => role.toString()).toList(growable: false)
          : const [],
    );
  }

  final String id;
  final String fullName;
  final String gender;
  final String dateOfBirth;
  final String mobileNumber;
  final String email;
  final bool emailVerified;
  final String preferredLanguage;
  final String accountStatus;
  final List<String> roles;
  final String? profilePhotoUrl;

  UserProfile toEntity() {
    return UserProfile(
      id: id,
      fullName: fullName,
      gender: gender,
      dateOfBirth: dateOfBirth,
      mobileNumber: mobileNumber,
      email: email,
      emailVerified: emailVerified,
      preferredLanguage: preferredLanguage,
      accountStatus: accountStatus,
      roles: roles,
      profilePhotoUrl: profilePhotoUrl,
    );
  }
}
