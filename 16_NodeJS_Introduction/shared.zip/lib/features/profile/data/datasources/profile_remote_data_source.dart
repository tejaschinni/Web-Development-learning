import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/core/network/api_exception.dart';
import 'package:society_seva/features/profile/data/models/update_profile_request.dart';
import 'package:society_seva/features/profile/data/models/phone_number_requests.dart';
import 'package:society_seva/features/profile/data/models/user_profile_model.dart';

abstract class ProfileRemoteDataSource {
  Future<UserProfileModel> getCurrentUser();

  Future<UserProfileModel> updateProfile(UpdateProfileRequest request);

  Future<void> deleteAccount();

  Future<Map<String, dynamic>> sendPhoneNumberOtp(
    SendPhoneNumberOtpRequest request,
  );

  Future<UserProfileModel> verifyPhoneNumberOtp(
    VerifyPhoneNumberOtpRequest request,
  );
}

class ProfileRemoteDataSourceImpl implements ProfileRemoteDataSource {
  ProfileRemoteDataSourceImpl(this._apiClient);

  final ApiClient _apiClient;

  static const _mockUserProfile = UserProfileModel(
    id: 'fcfa719a-e112-4ab2-876d-cdedac6da02a',
    fullName: 'Rajesh Sharma',
    gender: 'MALE',
    dateOfBirth: '1990-01-01',
    mobileNumber: '+91 98765 43210',
    email: 'rajesh.sharma@example.com',
    emailVerified: true,
    preferredLanguage: 'English',
    accountStatus: 'ACTIVE',
    roles: ['SELLER', 'RESIDENT'],
  );

  @override
  Future<UserProfileModel> getCurrentUser() async {
    try {
      final response = await _apiClient.get(ApiEndpoints.currentUser);
      return UserProfileModel.fromJson(response.data as Map<String, dynamic>);
    } catch (_) {
      return _mockUserProfile;
    }
  }

  @override
  Future<UserProfileModel> updateProfile(UpdateProfileRequest request) async {
    // Offline mode: print log
    print('[OFFLINE] PUT ${ApiEndpoints.currentUser} payload: ${request.toJson()}');
    return _mockUserProfile;
  }

  @override
  Future<void> deleteAccount() async {
    print('[OFFLINE] DELETE ${ApiEndpoints.currentUser}');
  }

  @override
  Future<Map<String, dynamic>> sendPhoneNumberOtp(
    SendPhoneNumberOtpRequest request,
  ) async {
    final response = await _apiClient.post(
      ApiEndpoints.sendPhoneNumberOtp,
      data: request.toJson(),
    );
    final data = _mapResponse(response.data);
    _throwForEmbeddedError(data);
    return data;
  }

  @override
  Future<UserProfileModel> verifyPhoneNumberOtp(
    VerifyPhoneNumberOtpRequest request,
  ) async {
    final response = await _apiClient.put(
      ApiEndpoints.verifyPhoneNumberOtp,
      data: request.toJson(),
    );
    final data = _mapResponse(response.data);
    _throwForEmbeddedError(data);
    return UserProfileModel.fromJson(data);
  }

  Map<String, dynamic> _mapResponse(Object? data) {
    if (data is! Map) {
      throw const ApiException(
        message: 'The server returned an invalid response.',
      );
    }
    return Map<String, dynamic>.from(data);
  }

  void _throwForEmbeddedError(Map<String, dynamic> data) {
    final status = data['status'];
    final success = data['success'];
    if ((status is num && status >= 400) || success == false) {
      throw ApiException(
        message:
            (data['message'] ?? data['detail'] ?? 'Phone verification failed.')
                .toString(),
        statusCode: status is num ? status.toInt() : null,
        requestId: data['requestId']?.toString(),
      );
    }
  }
}
