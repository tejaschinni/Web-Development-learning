const sellerTypes = [
  'FOOD_SELLER',
  'SERVICE_PROVIDER',
  'PRODUCT_SELLER',
  'ART_SELLER',
  'CONSULTANT',
  'TRAINER',
  'FREE_HELP_PROVIDER',
  'MIXED',
];

const isFassaiRequiredOptions = [true, false];

class SellerTypeConfig {
  const SellerTypeConfig({
    required this.description,
    this.fssai = false,
    this.delivery = false,
    this.deliveryRequired = false,
    this.deliveryLabel = 'Delivery Radius (km)',
    this.targetArea = false,
    this.targetAreaRequired = false,
    this.targetAreaLabel = 'Target Area',
    this.social = false,
    this.website = false,
    this.legal = false,
  });

  final String description;
  final bool fssai;
  final bool delivery;
  final bool deliveryRequired;
  final String deliveryLabel;
  final bool targetArea;
  final bool targetAreaRequired;
  final String targetAreaLabel;
  final bool social;
  final bool website;
  final bool legal;
}

/// Adjust these to change which fields each seller type shows.
const Map<String, SellerTypeConfig> sellerTypeConfigs = {
  'FOOD_SELLER': SellerTypeConfig(
    description: 'Home kitchens, bakers, tiffin and other food sellers',
    fssai: true,
    delivery: true,
    deliveryRequired: true,
    targetArea: true,
    targetAreaRequired: true,
    social: true,
    website: true,
    legal: true,
  ),
  'PRODUCT_SELLER': SellerTypeConfig(
    description: 'Sell physical products',
    delivery: true,
    deliveryRequired: true,
    targetArea: true,
    targetAreaRequired: true,
    social: true,
    website: true,
    legal: true,
  ),
  'ART_SELLER': SellerTypeConfig(
    description: 'Paintings, crafts, handmade and custom artwork',
    delivery: true,
    targetArea: true,
    targetAreaRequired: true,
    social: true,
    website: true,
    legal: true,
  ),
  'SERVICE_PROVIDER': SellerTypeConfig(
    description: 'Repairs, cleaning and other on-site services',
    delivery: true,
    deliveryLabel: 'Service Radius (km)',
    targetArea: true,
    targetAreaRequired: true,
    targetAreaLabel: 'Service Area',
    social: true,
    website: true,
    legal: true,
  ),
  'CONSULTANT': SellerTypeConfig(
    description: 'Paid advice or consultation',
    social: true,
    website: true,
    legal: true,
  ),
  'TRAINER': SellerTypeConfig(
    description: 'Classes, coaching and training',
    targetArea: true,
    targetAreaRequired: true,
    targetAreaLabel: 'Training Area',
    social: true,
    website: true,
    legal: true,
  ),
  'FREE_HELP_PROVIDER': SellerTypeConfig(
    description: 'Help the community for free',
    targetArea: true,
    targetAreaRequired: true,
    targetAreaLabel: 'Area You Can Help In',
    social: true,
  ),
  'MIXED': SellerTypeConfig(
    description: 'A mix of products and services',
    fssai: true,
    delivery: true,
    targetArea: true,
    targetAreaRequired: true,
    social: true,
    website: true,
    legal: true,
  ),
};
