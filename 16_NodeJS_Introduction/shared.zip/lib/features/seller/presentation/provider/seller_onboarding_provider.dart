import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/register_availablitiy_step.dart';
import 'package:society_seva/core/providers/app_providers.dart';
import 'package:society_seva/features/seller/data/datasources/seller_onboarding_remote_data_source.dart';
import 'package:society_seva/features/seller/data/models/request/seller_profile_request.dart';
import 'package:society_seva/features/seller/domain/entities/certificate_entity.dart';
import 'package:society_seva/features/seller/domain/entities/kyc_document_entity.dart';
import 'package:society_seva/features/seller/domain/entities/seller_availabledays_entity.dart';
import 'package:society_seva/features/seller/domain/entities/seller_image_entity.dart';
import 'package:society_seva/features/seller/domain/entities/seller_profile_entity.dart';
import 'package:society_seva/features/seller/domain/repositories/seller_onboarding_repository.dart';
import 'package:society_seva/features/seller/domain/usecase/on_boarding/create_seller_and_daft_usecase.dart';
import 'package:society_seva/features/seller/domain/usecase/on_boarding/delete_seller_image_by_id_use_case.dart';
import 'package:society_seva/features/seller/domain/usecase/on_boarding/download_kyc_document_file_usecase.dart';
import 'package:society_seva/features/seller/domain/usecase/on_boarding/fetch_images_by_seller_id_usecase.dart';
import 'package:society_seva/features/seller/domain/usecase/on_boarding/fetch_seller_profile_by_id_usecase.dart';
import 'package:society_seva/features/seller/domain/usecase/on_boarding/my_seller_profile_usecase.dart';
import 'package:society_seva/features/seller/domain/usecase/on_boarding/submit_seller_usecase.dart';
import 'package:society_seva/features/seller/domain/usecase/on_boarding/update_seller_profile_by_id_use_case.dart';
import 'package:society_seva/features/seller/domain/usecase/on_boarding/upload_images_by_seller_id_usecase.dart';

final sellerOnBoardingRemoteDataSource = Provider<SellerOnboardingRemoteDataSource>((ref) {
  return SellerOnboardingRemoteDataSourceImpl(apiClient: ref.watch(apiClientProvider));
});

final sellerOnBoardingRepository = Provider<SellerOnboardingRepository>((ref) {
  return SellerOnboardingRepositoryImpl(
    sellerOnboardingRemoteDataSource: ref.watch(sellerOnBoardingRemoteDataSource),
  );
});

final mySellerProfileUseCase = Provider<MySellerProfileUsecase>((ref) {
  return MySellerProfileUsecase(ref.watch(sellerOnBoardingRepository));
});

final fetchSellerProfileByIdUsecase = Provider<FetchSellerProfileByIdUsecase>((ref) {
  return FetchSellerProfileByIdUsecase(ref.watch(sellerOnBoardingRepository));
});

final createAndDraftSellerUsecase = Provider<CreateSellerAndDaftUsecase>((ref) {
  return CreateSellerAndDaftUsecase(ref.watch(sellerOnBoardingRepository));
});

final submitSellerProfileUsecase = Provider<SubmitSellerUseCase>((ref) {
  return SubmitSellerUseCase(ref.watch(sellerOnBoardingRepository));
});

final updateSellerProfileUseCase = Provider<UpdateSellerProfileByIdUseCase>((ref) {
  return UpdateSellerProfileByIdUseCase(ref.watch(sellerOnBoardingRepository));
});

final uploadImagesBySellerIdUsecase = Provider<UploadImagesBySellerIdUsecase>((ref) {
  return UploadImagesBySellerIdUsecase(ref.watch(sellerOnBoardingRepository));
});

final deleteSellerImagesByIDUsecase = Provider<DeleteSellerImageByIdUseCase>((ref) {
  return DeleteSellerImageByIdUseCase(ref.watch(sellerOnBoardingRepository));
});

final fetchSellerImagesByIDUsecase = Provider<FetchImagesBySellerIdUsecase>((ref) {
  return FetchImagesBySellerIdUsecase(ref.watch(sellerOnBoardingRepository));
});

final downloadKycDocumentFileUsecase = Provider<DownloadKycDocumentFileUsecase>((ref) {
  return DownloadKycDocumentFileUsecase(ref.watch(sellerOnBoardingRepository));
});

final sellerCertificatesProvider = FutureProvider.autoDispose
    .family<List<CertificateEntity>, String>((ref, sellerId) {
      return ref.read(sellerOnBoardingRepository).fetchCertificatesRepo(sellerId);
    });
final sellerDocumentProvider = FutureProvider.autoDispose.family<List<KycDocumentEntity>, String>((
  ref,
  sellerId,
) {
  return ref.read(sellerOnBoardingRepository).fetchKYCDocumentRepo(sellerId);
});

final sellerAvailableDaysProvider = FutureProvider.autoDispose.family<AvailableDaysEntity, String>((
  ref,
  sellerId,
) {
  return ref.read(sellerOnBoardingRepository).fetchSellerAvailableDaysRepo(sellerID: sellerId);
});

final fetchSellerUploadedImagesProvider =
    AsyncNotifierProvider.family<FetchImagesBySellerIDNotifier, List<SellerImageEntity>?, String>(
      FetchImagesBySellerIDNotifier.new,
    );

class FetchImagesBySellerIDNotifier extends FamilyAsyncNotifier<List<SellerImageEntity>?, String> {
  late FetchImagesBySellerIdUsecase _useCase;

  @override
  Future<List<SellerImageEntity>?> build(String sellerId) async {
    _useCase = ref.read(fetchSellerImagesByIDUsecase);

    return await _useCase.call(sellerId: sellerId);
  }

  Future<List<SellerImageEntity>?> fetchSellerImages() async {
    state = const AsyncLoading();

    state = await AsyncValue.guard(() => _useCase.call(sellerId: arg));
    return state.value;
  }
}

final mySellerProfileProvider =
    AsyncNotifierProvider<MySellerProfileNotifier, SellerProfileEntity?>(
      MySellerProfileNotifier.new,
    );

final sellerProfileByIdProvider = FutureProvider.autoDispose.family<SellerProfileEntity?, String>((
  ref,
  sellerId,
) {
  return ref.read(fetchSellerProfileByIdUsecase).call(sellerId);
});

class MySellerProfileNotifier extends AsyncNotifier<SellerProfileEntity?> {
  late MySellerProfileUsecase _useCase;

  @override
  Future<SellerProfileEntity?> build() async {
    _useCase = ref.read(mySellerProfileUseCase);
    return fetchMySellerProfile();
  }

  Future<SellerProfileEntity?> fetchMySellerProfile() async {
    state = const AsyncLoading();

    state = await AsyncValue.guard(() async {
      return await _useCase.call();
    });

    return state.value;
  }

  Future<SellerProfileEntity?> refresh() => fetchMySellerProfile();
}

enum SellerKind { individual, smallBusiness, registered, artist, workshop }

class SellerRegState {
  final int step;

  final String fullName, mobile, otp, email;
  final bool otpSent, otpVerified;
  final SellerKind? sellerKind;
  final bool? hasFssai;
  final String fssaiCertificateId;
  final String websiteUrl;
  final String socialMediaLinks;
  final String legalCompliance;

  final Set<String> categories;
  final String businessName, city, locality, pickupAddress, radius;
  final String stateName, country, pinCode;
  final double? latitude, longitude;

  // Step 3
  final String language;
  final Set<String> days;
  final TimeOfDay from, to;
  final String description;
  final Map<String, String?> documents; // docKey -> picked file name

  const SellerRegState({
    this.step = 0,
    this.fullName = '',
    this.mobile = '',
    this.otp = '',
    this.email = '',
    this.otpSent = false,
    this.otpVerified = false,
    this.sellerKind,
    this.categories = const {'Food'},
    this.businessName = '',
    this.city = 'Pune',
    this.locality = '',
    this.pickupAddress = '',
    this.radius = '50',
    this.stateName = 'Maharashtra',
    this.country = 'India',
    this.pinCode = '',
    this.latitude,
    this.longitude,
    this.language = 'English',
    this.days = const {'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY'},
    this.from = const TimeOfDay(hour: 9, minute: 0),
    this.to = const TimeOfDay(hour: 18, minute: 0),
    this.description = '',
    this.documents = const {},
    this.hasFssai = false,
    this.fssaiCertificateId = '',
    this.websiteUrl = '',
    this.socialMediaLinks = '',
    this.legalCompliance = '',
  });

  SellerRegState copyWith({
    int? step,
    String? fullName,
    String? mobile,
    String? otp,
    String? email,
    bool? otpSent,
    bool? otpVerified,
    SellerKind? sellerKind,
    Set<String>? categories,
    String? businessName,
    String? city,
    String? locality,
    String? pickupAddress,
    String? radius,
    String? stateName,
    String? country,
    String? pinCode,
    double? latitude,
    double? longitude,
    String? language,
    Set<String>? days,
    bool? hasFssai,
    String? fssaiCertificateId,
    String? websiteUrl,
    String? socialMediaLinks,
    String? legalCompliance,
    TimeOfDay? from,
    TimeOfDay? to,
    String? description,
    Map<String, String?>? documents,
  }) => SellerRegState(
    step: step ?? this.step,
    fullName: fullName ?? this.fullName,
    mobile: mobile ?? this.mobile,
    otp: otp ?? this.otp,
    email: email ?? this.email,
    otpSent: otpSent ?? this.otpSent,
    otpVerified: otpVerified ?? this.otpVerified,
    sellerKind: sellerKind ?? this.sellerKind,
    categories: categories ?? this.categories,
    businessName: businessName ?? this.businessName,
    city: city ?? this.city,
    locality: locality ?? this.locality,
    pickupAddress: pickupAddress ?? this.pickupAddress,
    radius: radius ?? this.radius,
    stateName: stateName ?? this.stateName,
    country: country ?? this.country,
    pinCode: pinCode ?? this.pinCode,
    latitude: latitude ?? this.latitude,
    longitude: longitude ?? this.longitude,
    language: language ?? this.language,
    days: days ?? this.days,
    from: from ?? this.from,
    to: to ?? this.to,
    description: description ?? this.description,
    documents: documents ?? this.documents,
    hasFssai: hasFssai ?? this.hasFssai,
    fssaiCertificateId: fssaiCertificateId ?? this.fssaiCertificateId,
    websiteUrl: websiteUrl ?? this.websiteUrl,
    socialMediaLinks: socialMediaLinks ?? this.socialMediaLinks,
    legalCompliance: legalCompliance ?? this.legalCompliance,
  );
}

final sellerFormActionProvider = NotifierProvider<SellerFormActionNotifier, SellerFormState>(
  SellerFormActionNotifier.new,
);

final sellerOnboardingProvider = sellerFormActionProvider;

class SellerFormActionNotifier extends Notifier<SellerFormState> {
  @override
  SellerFormState build() => const SellerFormState();

  void updateReg(SellerRegState Function(SellerRegState s) f) =>
      state = state.copyWith(reg: f(state.reg));

  void toggleCategory(String c) {
    final set = {...state.reg.categories};
    set.contains(c) ? set.remove(c) : set.add(c);
    if (set.isEmpty) return;
    state = state.copyWith(reg: state.reg.copyWith(categories: set));
  }

  void addPendingImage(XFile file) =>
      state = state.copyWith(queuedImages: [...state.queuedImages, file]);

  void removePendingImage(XFile file) => state = state.copyWith(
    queuedImages: state.queuedImages.where((f) => f.path != file.path).toList(),
  );

  void markImageForDelete(String imageId) =>
      state = state.copyWith(pendingDeleteImageIds: {...state.pendingDeleteImageIds, imageId});

  void unmarkImageForDelete(String imageId) => state = state.copyWith(
    pendingDeleteImageIds: state.pendingDeleteImageIds.where((id) => id != imageId).toSet(),
  );

  void addPendingDocument(PendingDocument doc) =>
      state = state.copyWith(pendingDocuments: [...state.pendingDocuments, doc]);

  void removePendingDocument(PendingDocument doc) => state = state.copyWith(
    pendingDocuments: state.pendingDocuments.where((d) => d != doc).toList(),
  );

  void addPendingCertificate(PendingCertificate cert) =>
      state = state.copyWith(pendingCertificates: [...state.pendingCertificates, cert]);

  void removePendingCertificate(PendingCertificate cert) => state = state.copyWith(
    pendingCertificates: state.pendingCertificates.where((c) => c != cert).toList(),
  );

  String? get currentSellerId {
    final id = ref.read(mySellerProfileProvider).value?.id;
    return (id == null || id.isEmpty) ? null : id;
  }

  void setAvailability(AvailabilityValue availability) =>
      state = state.copyWith(availability: availability);

  void updateDays(Set<String> days) =>
      state = state.copyWith(availability: state.availability.copyWith(days: days));

  void updateHours({TimeOfDay? from, TimeOfDay? to}) =>
      state = state.copyWith(availability: state.availability.copyWith(from: from, to: to));

  Future<bool> saveAvailableDays({
    required String sellerId,
    AvailabilityValue? availability,
  }) async {
    final value = availability ?? state.availability;
    try {
      await ref.read(sellerOnBoardingRepository).updateSellerAvailableDaysRepo(
        sellerID: sellerId,
        data: value.toJson(),
      );
      state = state.copyWith(availability: value);
      ref.invalidate(sellerAvailableDaysProvider(sellerId));
      return true;
    } catch (e) {
      state = state.copyWith(error: e);
      return false;
    }
  }

  Future<void> _flushPendingUploads(String sellerId) async {
    state = state.copyWith(isUploadingImages: true);
    try {
      for (final file in List.of(state.queuedImages)) {
        await ref.read(uploadImagesBySellerIdUsecase).call(sellerId: sellerId, file: file);
        removePendingImage(file);
      }
      for (final imageId in List.of(state.pendingDeleteImageIds)) {
        await ref.read(deleteSellerImagesByIDUsecase).call(imageId: imageId, sellerId: sellerId);
        unmarkImageForDelete(imageId);
      }
    } finally {
      state = state.copyWith(isUploadingImages: false);
      ref.invalidate(fetchSellerUploadedImagesProvider(sellerId));
    }

    final repo = ref.read(sellerOnBoardingRepository);
    for (final doc in List.of(state.pendingDocuments)) {
      await repo.uploadKYCDocumentRepo(
        sellerId: sellerId,
        documentType: doc.type,
        documentNumber: doc.number,
        file: doc.file,
      );
      removePendingDocument(doc);
    }
    ref.invalidate(sellerCertificatesProvider(sellerId));

    for (final cert in List.of(state.pendingCertificates)) {
      await repo.uploadCertificateRepo(
        sellerId: sellerId,
        file: cert.file,
        certificateName: cert.name,
        certificateNumber: cert.certificateNumber.toString(),
        certificateType: cert.type.toString(),
        issueAuthority: cert.issuingAuthority.toString(),
        issueDate: cert.issueDate,
        hasExpiry: cert.hasExpiry,
        expiryDate: cert.expiryDate,
      );
      removePendingCertificate(cert);
    }
    ref.invalidate(sellerCertificatesProvider(sellerId));
  }

  SellerProfileRequest _mergeAvailability(SellerProfileRequest request) {
    if (request.availableDays != null && request.availableDays!.isNotEmpty) {
      return request;
    }
    final avail = state.availability;
    return request.copyWith(
      availableDaysType: avail.daysType.api,
      availableDays: kWeekDays.where(avail.days.contains).toList(),
      availableFromTime: formatApiTime(avail.from),
      availableToTime: formatApiTime(avail.to),
    );
  }

  Future<bool> save(SellerProfileRequest request) async {
    state = state.copyWith(isSaving: true, clearError: true);
    try {
      final req = _mergeAvailability(request);
      await ref.read(createAndDraftSellerUsecase).call(request: req);
      final seller = await ref.read(mySellerProfileProvider.notifier).refresh();
      if (seller == null) {
        throw Exception('Draft was saved but the seller profile could not be loaded.');
      }
      await _flushPendingUploads(seller.id);
      await saveAvailableDays(sellerId: seller.id, availability: state.availability);
      return true;
    } catch (e) {
      state = state.copyWith(error: e);
      return false;
    } finally {
      state = state.copyWith(isSaving: false);
    }
  }

  Future<bool> submit(SellerProfileRequest request) async {
    state = state.copyWith(isSubmitting: true, clearError: true);
    try {
      final req = _mergeAvailability(request);
      var sellerId = currentSellerId;
      if (sellerId == null) {
        await ref.read(createAndDraftSellerUsecase).call(request: req);
        final seller = await ref.read(mySellerProfileProvider.notifier).refresh();
        if (seller == null) {
          throw Exception('Draft was saved but the seller profile could not be loaded.');
        }
        sellerId = seller.id;
      }

      await ref.read(submitSellerProfileUsecase).call(sellerId);
      await _flushPendingUploads(sellerId);
      await saveAvailableDays(sellerId: sellerId, availability: state.availability);
      await ref.read(mySellerProfileProvider.notifier).refresh();
      return true;
    } catch (e) {
      state = state.copyWith(error: e);
      return false;
    } finally {
      state = state.copyWith(isSubmitting: false);
    }
  }

  Future<bool> update(SellerProfileRequest request, String sellerId) async {
    state = state.copyWith(isSubmitting: true, clearError: true);
    try {
      final req = _mergeAvailability(request);
      if (!req.isEmpty) {
        await ref.read(updateSellerProfileUseCase).call(request: req, sellerId: sellerId);
      }
      await _flushPendingUploads(sellerId);
      await saveAvailableDays(sellerId: sellerId, availability: state.availability);
      await ref.read(mySellerProfileProvider.notifier).refresh();
      return true;
    } catch (e) {
      state = state.copyWith(error: e);
      return false;
    } finally {
      state = state.copyWith(isSubmitting: false);
    }
  }
}

class SellerFormState {
  final SellerRegState reg;
  final bool isSaving;
  final bool isSubmitting;
  final bool isUploadingImages;
  final List<XFile> queuedImages;
  final Set<String> pendingDeleteImageIds;
  final List<PendingDocument> pendingDocuments;
  final List<PendingCertificate> pendingCertificates;
  final AvailabilityValue availability;
  final Object? error;

  const SellerFormState({
    this.reg = const SellerRegState(),
    this.isSaving = false,
    this.isSubmitting = false,
    this.isUploadingImages = false,
    this.queuedImages = const [],
    this.pendingDeleteImageIds = const {},
    this.pendingDocuments = const [],
    this.pendingCertificates = const [],
    this.availability = const AvailabilityValue(),
    this.error,
  });

  bool get isBusy => isSaving || isSubmitting || isUploadingImages;

  SellerFormState copyWith({
    SellerRegState? reg,
    bool? isSaving,
    bool? isSubmitting,
    bool? isUploadingImages,
    List<XFile>? queuedImages,
    Set<String>? pendingDeleteImageIds,
    List<PendingDocument>? pendingDocuments,
    List<PendingCertificate>? pendingCertificates,
    AvailabilityValue? availability,
    Object? error,
    bool clearError = false,
  }) => SellerFormState(
    reg: reg ?? this.reg,
    isSaving: isSaving ?? this.isSaving,
    isSubmitting: isSubmitting ?? this.isSubmitting,
    isUploadingImages: isUploadingImages ?? this.isUploadingImages,
    queuedImages: queuedImages ?? this.queuedImages,
    pendingDeleteImageIds: pendingDeleteImageIds ?? this.pendingDeleteImageIds,
    pendingDocuments: pendingDocuments ?? this.pendingDocuments,
    pendingCertificates: pendingCertificates ?? this.pendingCertificates,
    availability: availability ?? this.availability,
    error: clearError ? null : (error ?? this.error),
  );
}

class PendingDocument {
  const PendingDocument({required this.type, required this.number, required this.file});

  final String type;
  final String number;
  final XFile file;
}

class PendingCertificate {
  const PendingCertificate({
    required this.name,
    required this.file,
    required this.issueDate,
    required this.hasExpiry,
    this.certificateNumber,
    this.issuingAuthority,
    this.type,
    this.expiryDate,
  });

  final String? type;
  final String name;
  final String? certificateNumber;
  final String? issuingAuthority;
  final XFile file;
  final DateTime issueDate;
  final bool hasExpiry;
  final DateTime? expiryDate;
}

class SellerActionState {
  const SellerActionState({
    this.isSaving = false,
    this.isSubmitting = false,
    this.isUploading = false,
    this.pendingImages = const [],
    this.pendingDocuments = const [],
    this.pendingCertificates = const [],
    this.pendingDeleteImageIds = const {},
    this.error,
  });

  final bool isSaving;
  final bool isSubmitting;
  final bool isUploading;
  final List<XFile> pendingImages;
  final Set<String> pendingDeleteImageIds;
  final List<PendingDocument>? pendingDocuments;
  final List<PendingCertificate>? pendingCertificates;
  final Object? error;

  bool get isBusy => isSaving || isSubmitting || isUploading;

  SellerActionState copyWith({
    bool? isSaving,
    bool? isSubmitting,
    bool? isUploading,
    List<XFile>? pendingImages,
    Set<String>? pendingDeleteImageIds,
    Object? error,
    bool clearError = false,
    List<PendingDocument>? pendingDocuments,
    List<PendingCertificate>? pendingCertificates,
  }) {
    return SellerActionState(
      isSaving: isSaving ?? this.isSaving,
      isSubmitting: isSubmitting ?? this.isSubmitting,
      isUploading: isUploading ?? this.isUploading,
      pendingImages: pendingImages ?? this.pendingImages,
      error: clearError ? null : (error ?? this.error),
      pendingDocuments: pendingDocuments ?? this.pendingDocuments,
      pendingCertificates: pendingCertificates ?? this.pendingCertificates,
      pendingDeleteImageIds: pendingDeleteImageIds ?? this.pendingDeleteImageIds,
    );
  }
}
