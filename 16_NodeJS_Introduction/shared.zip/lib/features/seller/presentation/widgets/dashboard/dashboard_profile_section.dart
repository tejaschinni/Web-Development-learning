import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';

class DashboardProfileSection extends ConsumerWidget {
  const DashboardProfileSection({super.key, this.onViewProfile, this.onEditAvatar});
  final VoidCallback? onViewProfile;
  final VoidCallback? onEditAvatar;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sellerAsync = ref.watch(mySellerProfileProvider);

    return sellerAsync.when(
      data: (data) {
        return Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFFEAF6EE),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFFCFE8D6)),
          ),
          child: LayoutBuilder(
            builder: (context, c) {
              final compact = c.maxWidth < 420;
              final button = _OutlineArrowButton('View Profile', onPressed: onViewProfile!);
              final info = Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Wrap(
                    spacing: 8,
                    runSpacing: 4,
                    crossAxisAlignment: WrapCrossAlignment.center,
                    children: [
                      Text(
                        data!.displayName.toString(),
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF0B2F6B),
                        ),
                      ),
                      _Pill(data.approvalStatus.toUpperCase(), icon: Icons.check_circle),
                    ],
                  ),
                  const Gap(4),
                  Text(
                    data.sellerType.replaceAll('_', ' ').toUpperCase(),
                    style: TextStyle(fontSize: 12, color: Color(0xFF33425B)),
                  ),
                  const Gap(2),
                  Row(
                    children: [
                      Icon(Icons.location_on_outlined, size: 14, color: AppColors.muted),
                      const Gap(2),
                      Text(data.address, style: TextStyle(fontSize: 12, color: AppColors.muted)),
                    ],
                  ),
                ],
              );

              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Stack(
                        clipBehavior: Clip.none,
                        children: [
                          Container(
                            width: 60,
                            height: 60,
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              color: Color(0xFFFFE0B2),
                            ),
                            child: const Icon(
                              Icons.ramen_dining,
                              size: 30,
                              color: Color(0xFFB3541E),
                            ),
                          ),
                          Positioned(
                            right: -2,
                            bottom: -2,
                            child: InkWell(
                              onTap: onEditAvatar ?? onViewProfile,
                              borderRadius: BorderRadius.circular(10),
                              child: Container(
                                padding: const EdgeInsets.all(4),
                                decoration: const BoxDecoration(
                                  color: AppColors.green,
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(Icons.edit, size: 11, color: Colors.white),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const Gap(12),
                      Expanded(child: info),
                      if (!compact) button,
                    ],
                  ),
                  if (compact) ...[
                    const Gap(10),
                    Align(alignment: Alignment.centerRight, child: button),
                  ],
                ],
              );
            },
          ),
        );
      },
      error: ((error, stackTrace) {
        return Text("No Profile Found");
      }),
      loading: () {
        return Center(child: CircularProgressIndicator());
      },
    );
  }
}

class _Pill extends StatelessWidget {
  const _Pill(this.text, {this.icon});
  final String text;
  final IconData? icon;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
    decoration: BoxDecoration(
      color: const Color(0xFFDDF3E2),
      borderRadius: BorderRadius.circular(20),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (icon != null) ...[Icon(icon, size: 13, color: AppColors.green), const Gap(4)],
        Text(
          text,
          style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.green),
        ),
      ],
    ),
  );
}

class _OutlineArrowButton extends StatelessWidget {
  const _OutlineArrowButton(this.label, {required this.onPressed});
  final String label;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) => OutlinedButton(
    onPressed: onPressed,
    style: OutlinedButton.styleFrom(
      foregroundColor: AppColors.green,
      side: const BorderSide(color: AppColors.green),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(label, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
        const Gap(6),
        const Icon(Icons.arrow_forward, size: 15),
      ],
    ),
  );
}
