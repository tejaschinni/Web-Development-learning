import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:society_seva/app/theme/app_theme.dart';

/// Radius selector: slider steps (1, 3, 5, 10, ...) + a "Custom" option
/// where the user types any radius between [minRadius] and [maxRadius].
///
/// Usage:
///   RegistrationRadiusSliderWidget(
///     value: s.deliveryRadius,            // int? (km), null = nothing / invalid
///     onChanged: (km) => n.update((x) => x.copyWith(deliveryRadius: km)),
///   )
/// onChanged gives null while the custom field is empty or out of range,
/// so treat null as "not valid yet" in your step validation.
class RegistrationRadiusSliderWidget extends StatefulWidget {
  final int? value;
  final ValueChanged<int?> onChanged;
  final List<int> steps;
  final int minRadius;
  final int maxRadius;

  const RegistrationRadiusSliderWidget({
    super.key,
    required this.value,
    required this.onChanged,
    this.steps = const [1, 3, 5, 10, 15, 20, 25, 50],
    this.minRadius = 1,
    this.maxRadius = 200,
  });

  @override
  State<RegistrationRadiusSliderWidget> createState() => _RegistrationRadiusSliderWidgetState();
}

class _RegistrationRadiusSliderWidgetState extends State<RegistrationRadiusSliderWidget> {
  late bool _custom;
  late final TextEditingController _ctrl;

  @override
  void initState() {
    super.initState();
    // a saved value that isn't one of the steps (e.g. 7) opens in custom mode
    _custom = widget.value != null && !widget.steps.contains(widget.value);
    _ctrl = TextEditingController(text: _custom ? '${widget.value}' : '');
  }

  @override
  void didUpdateWidget(covariant RegistrationRadiusSliderWidget old) {
    super.didUpdateWidget(old);
    // value changed from outside (e.g. profile loaded)
    if (widget.value != old.value && widget.value != null) {
      final isStep = widget.steps.contains(widget.value);
      if (!isStep && !_custom) _custom = true;
      if (_custom && _ctrl.text != '${widget.value}') {
        _ctrl.text = '${widget.value}';
      }
    }
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  int get _sliderIndex {
    final v = widget.value;
    if (v == null) return 0;
    var best = 0;
    for (var k = 1; k < widget.steps.length; k++) {
      if ((widget.steps[k] - v).abs() < (widget.steps[best] - v).abs()) best = k;
    }
    return best;
  }

  String? get _error {
    if (!_custom || _ctrl.text.isEmpty) return null;
    final n = int.tryParse(_ctrl.text);
    if (n == null || n < widget.minRadius || n > widget.maxRadius) {
      return 'Enter ${widget.minRadius}–${widget.maxRadius} km';
    }
    return null;
  }

  void _toggleCustom(bool on) {
    setState(() => _custom = on);
    if (on) {
      _ctrl.text = widget.value?.toString() ?? '';
      _onTyped(_ctrl.text);
    } else {
      // back to slider -> snap to nearest step
      widget.onChanged(widget.steps[_sliderIndex]);
    }
  }

  void _onTyped(String text) {
    final n = int.tryParse(text);
    final ok = n != null && n >= widget.minRadius && n <= widget.maxRadius;
    setState(() {}); // refresh error text
    widget.onChanged(ok ? n : null);
  }

  @override
  Widget build(BuildContext context) {
    final steps = widget.steps;
    final idx = _sliderIndex;
    final v = widget.value;

    return Container(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Service / delivery radius',
                style: GoogleFonts.hind(fontSize: 12, color: AppColors.muted),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                decoration: BoxDecoration(
                  color: AppColors.green.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  v == null ? 'Not set' : '$v km',
                  style: GoogleFonts.hind(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: AppColors.green,
                  ),
                ),
              ),
            ],
          ),

          // Slider (disabled while custom is on)
          Opacity(
            opacity: _custom ? 0.4 : 1,
            child: SliderTheme(
              data: SliderTheme.of(context).copyWith(
                activeTrackColor: AppColors.green,
                inactiveTrackColor: AppColors.border,
                thumbColor: AppColors.green,
                overlayColor: AppColors.green.withValues(alpha: 0.12),
                trackHeight: 4,
                activeTickMarkColor: Colors.white,
                inactiveTickMarkColor: AppColors.muted.withValues(alpha: 0.5),
              ),
              child: Slider(
                value: idx.toDouble(),
                min: 0,
                max: (steps.length - 1).toDouble(),
                divisions: steps.length - 1,
                label: '${steps[idx]} km',
                onChanged: _custom ? null : (x) => widget.onChanged(steps[x.round()]),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                for (var k = 0; k < steps.length; k++)
                  Text(
                    '${steps[k]}',
                    style: GoogleFonts.hind(
                      fontSize: 10,
                      fontWeight: !_custom && v != null && k == idx
                          ? FontWeight.w700
                          : FontWeight.w400,
                      color: !_custom && v != null && k == idx ? AppColors.green : AppColors.muted,
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 8),

          // Custom toggle
          FilterChip(
            label: Text('Custom radius', style: GoogleFonts.hind(fontSize: 12)),
            selected: _custom,
            selectedColor: AppColors.green.withValues(alpha: 0.15),
            checkmarkColor: AppColors.green,
            side: BorderSide(color: _custom ? AppColors.green : AppColors.border),
            onSelected: _toggleCustom,
          ),

          if (_custom) ...[
            const SizedBox(height: 8),
            TextField(
              controller: _ctrl,
              keyboardType: TextInputType.number,
              inputFormatters: [
                FilteringTextInputFormatter.digitsOnly,
                LengthLimitingTextInputFormatter(widget.maxRadius.toString().length),
              ],
              style: const TextStyle(fontSize: 13),
              onChanged: _onTyped,
              decoration: InputDecoration(
                hintText: 'Enter radius',
                hintStyle: AppTheme.hind(12, c: const Color(0xFF9E9E9E)),
                suffixText: 'km',
                errorText: _error,
                isDense: true,
                filled: true,
                fillColor: Colors.white,
                contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 13),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: AppColors.border),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: AppColors.border),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: const BorderSide(color: AppColors.green),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
