import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/lable_widget.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/registration_radius_slider_widget.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/registration_text_field_widget.dart';

class RegistrationAddressStep extends StatelessWidget {
  const RegistrationAddressStep({
    super.key,
    required this.selected,
    required this.devicePoint,
    required this.hasLocationPermission,
    required this.locating,
    required this.permissionReady,
    required this.serviceDisabled,
    required this.permission,
    required this.geocoding,
    required this.locationError,
    required this.onMapCreated,
    required this.onMapTap,
    required this.onRequestLocation,
    required this.isActive,
    required this.addressController,
    required this.cityController,
    required this.stateController,
    required this.countryController,
    required this.pinCodeController,
    required this.deliveryRadius,
    required this.onRadiusChanged,
    required this.onAddressChanged,
    required this.onCityChanged,
    required this.onStateChanged,
    required this.onCountryChanged,
    required this.onPinCodeChanged,
    this.onSearchAddress,
  });

  final bool isActive;
  final LatLng? selected;
  final LatLng? devicePoint;
  final bool hasLocationPermission;
  final bool locating;
  final bool permissionReady;
  final bool serviceDisabled;
  final LocationPermission permission;
  final bool geocoding;
  final String? locationError;
  final void Function(GoogleMapController controller) onMapCreated;
  final void Function(LatLng point) onMapTap;
  final VoidCallback onRequestLocation;

  final TextEditingController addressController;
  final TextEditingController cityController;
  final TextEditingController stateController;
  final TextEditingController countryController;
  final TextEditingController pinCodeController;
  final int? deliveryRadius;
  final ValueChanged<int?> onRadiusChanged;
  final ValueChanged<String> onAddressChanged;
  final ValueChanged<String> onCityChanged;
  final ValueChanged<String> onStateChanged;
  final ValueChanged<String> onCountryChanged;
  final ValueChanged<String> onPinCodeChanged;
  final VoidCallback? onSearchAddress;

  static const _fallbackPoint = LatLng(20.5937, 78.9629);

  @override
  Widget build(BuildContext context) {
    final point = selected;
    final target = point ?? devicePoint ?? _fallbackPoint;
    final zoom = (point != null || devicePoint != null) ? 16.0 : 5.0;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Gap(8),

        if (isActive)
          SizedBox(
            height: 300,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Stack(
                children: [
                  GoogleMap(
                    initialCameraPosition: CameraPosition(target: target, zoom: zoom),
                    gestureRecognizers: <Factory<OneSequenceGestureRecognizer>>{
                      Factory<OneSequenceGestureRecognizer>(() => EagerGestureRecognizer()),
                    },
                    myLocationEnabled: hasLocationPermission,
                    myLocationButtonEnabled: false,
                    zoomControlsEnabled: false,
                    mapToolbarEnabled: false,
                    markers: point == null
                        ? const {}
                        : {Marker(markerId: const MarkerId('seller-location'), position: point)},
                    onMapCreated: onMapCreated,
                    onTap: onMapTap,
                  ),
                  Positioned(
                    right: 12,
                    top: 12,
                    child: Material(
                      color: Theme.of(context).colorScheme.surface,
                      shape: const CircleBorder(),
                      child: IconButton(
                        tooltip: 'Use my current location',
                        onPressed: locating ? null : onRequestLocation,
                        icon: locating
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              )
                            : const Icon(Icons.my_location),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        const Gap(8),
        Text(
          locationError ??
              (permissionReady && !hasLocationPermission
                  ? 'Location permission is off. You can still tap the map or type an address to choose your location.'
                  : point == null
                  ? 'Tap the map, click the location icon, or type your address below to set your location.'
                  : 'Location selected: (${point.latitude.toStringAsFixed(4)}, ${point.longitude.toStringAsFixed(4)}). Address details are auto-filled.'),
          style: GoogleFonts.hind(
            fontSize: 12,
            color: locationError != null ? Colors.red : AppColors.muted,
          ),
        ),
        if (serviceDisabled || (permissionReady && !hasLocationPermission))
          Align(
            alignment: Alignment.centerLeft,
            child: TextButton.icon(
              onPressed: serviceDisabled
                  ? Geolocator.openLocationSettings
                  : permission == LocationPermission.deniedForever
                  ? Geolocator.openAppSettings
                  : onRequestLocation,
              icon: const Icon(Icons.location_searching),
              label: Text(
                serviceDisabled
                    ? 'Open device location settings'
                    : permission == LocationPermission.deniedForever
                    ? 'Open app settings'
                    : 'Allow location access',
              ),
            ),
          ),
        if (geocoding) ...[
          const Gap(6),
          const LinearProgressIndicator(),
          const Gap(4),
          Text(
            'Searching address / coordinates...',
            style: GoogleFonts.hind(fontSize: 11, color: AppColors.muted),
          ),
        ],
        const Gap(16),

        const LableWidget('Address', required: false),
        RegistrationTextFieldWidget(
          controller: addressController,
          hint: 'Search or enter address (e.g. MG Road, Pune)',
          icon: Icons.home_work_outlined,
          maxLineLength: 2,
          suffixIcon: IconButton(
            tooltip: 'Search location on map',
            icon: const Icon(Icons.search, size: 20, color: AppColors.green),
            onPressed: onSearchAddress,
          ),
          onChanged: onAddressChanged,
          onFieldSubmitted: (_) => onSearchAddress?.call(),
        ),
        const Gap(16),

        const LableWidget('City', required: false),
        RegistrationTextFieldWidget(
          controller: cityController,
          hint: 'City',
          icon: Icons.location_city,
          maxLineLength: 1,
          onChanged: onCityChanged,
          onFieldSubmitted: (_) => onSearchAddress?.call(),
        ),
        const Gap(16),
        const LableWidget('State', required: false),
        RegistrationTextFieldWidget(
          controller: stateController,
          hint: 'State',
          icon: Icons.map,
          maxLineLength: 1,
          onChanged: onStateChanged,
        ),
        const Gap(16),
        const LableWidget('Country', required: false),
        RegistrationTextFieldWidget(
          controller: countryController,
          hint: 'Country',
          icon: Icons.public,
          maxLineLength: 1,
          onChanged: onCountryChanged,
        ),
        const Gap(16),
        const LableWidget('PinCode', required: false),
        RegistrationTextFieldWidget(
          controller: pinCodeController,
          hint: 'PinCode',
          icon: Icons.pin_drop_outlined,
          keyboard: TextInputType.number,
          maxLineLength: 1,
          onChanged: onPinCodeChanged,
          onFieldSubmitted: (_) => onSearchAddress?.call(),
        ),
        const Gap(16),
        const LableWidget('Service / Delivery Radius', required: false),
        RegistrationRadiusSliderWidget(
          value: deliveryRadius,
          onChanged: onRadiusChanged,
        ),
      ],
    );
  }
}
