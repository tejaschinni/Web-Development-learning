import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/lable_widget.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/registration_section_card_widget.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/registration_text_field_widget.dart';

class RegistrationBasicInfo extends StatelessWidget {
  final SellerRegState s;
  final void Function(SellerRegState Function(SellerRegState s) f) onUpdate;
  final TextEditingController? displayNameController;
  final TextEditingController? businessNameController;
  final TextEditingController? bioController;

  const RegistrationBasicInfo({
    super.key,
    required this.onUpdate,
    required this.s,
    this.displayNameController,
    this.businessNameController,
    this.bioController,
  });

  @override
  Widget build(BuildContext context) {
    return RegistrationSectionCardWidget(
      color: AppColors.green.withValues(alpha: 150),
      icon: Icons.person,
      title: 'Basic Details',
      subtitle: 'Tell us about yourself.',
      children: [
        const LableWidget('Display Name', required: true),
        RegistrationTextFieldWidget(
          controller: displayNameController,
          hint: 'Display Name',
          icon: Icons.person_outline,
          initial: s.fullName,
          onChanged: (v) => onUpdate((x) => x.copyWith(fullName: v)),
        ),
        const Gap(12),
        const LableWidget('Business Name', required: true),
        RegistrationTextFieldWidget(
          controller: businessNameController,
          hint: 'Business Name',
          icon: Icons.storefront,
          initial: s.businessName,
          onChanged: (v) => onUpdate((x) => x.copyWith(businessName: v)),
        ),
        const Gap(12),
        const LableWidget('Bio', required: true),
        RegistrationTextFieldWidget(
          controller: bioController,
          hint: 'Bio',
          icon: Icons.description,
          maxLineLength: 2,
          initial: s.description,
          onChanged: (v) => onUpdate((x) => x.copyWith(description: v)),
        ),
        const Gap(12),
        const LableWidget('Business Type', required: true),
        _SellerTypeGrid(
          selected: s.sellerKind,
          onSelect: (k) => onUpdate((x) => x.copyWith(sellerKind: k)),
        ),
      ],
    );
  }
}

class _SellerTypeGrid extends StatelessWidget {
  final SellerKind? selected;
  final ValueChanged<SellerKind> onSelect;
  const _SellerTypeGrid({required this.selected, required this.onSelect});

  @override
  Widget build(BuildContext context) {
    // HugeIcons constants are List<List<dynamic>> in hugeicons 1.x
    const items = <(SellerKind, List<List<dynamic>>, String)>[
      (SellerKind.individual, HugeIcons.strokeRoundedHome01, 'Individual /\nHome-based seller'),
      (SellerKind.smallBusiness, HugeIcons.strokeRoundedStore01, 'Small business /\nShop'),
      (SellerKind.registered, HugeIcons.strokeRoundedBuilding03, 'Registered\nbusiness'),
      (SellerKind.artist, HugeIcons.strokeRoundedPaintBoard, 'Artist / Creator'),
      (SellerKind.workshop, HugeIcons.strokeRoundedUserGroup, 'Workshop / Class\nprovider'),
    ];

    return LayoutBuilder(
      builder: (context, c) {
        final w = (c.maxWidth - 16) / 3;
        return Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (final (k, icon, label) in items)
              InkWell(
                onTap: () => onSelect(k),
                child: Container(
                  width: w,
                  height: 84,
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: selected == k ? AppColors.greenSoft : Colors.white,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: selected == k ? AppColors.green : AppColors.border,
                      width: selected == k ? 1.5 : 1,
                    ),
                  ),
                  child: Stack(
                    children: [
                      Center(
                        child: Column(
                          mainAxisAlignment: .center,
                          children: [
                            HugeIcon(icon: icon, color: Colors.orange.shade800, size: 28),
                            const SizedBox(height: 4),
                            Text(label, textAlign: TextAlign.center, style: AppTheme.hind(10)),
                          ],
                        ),
                      ),
                      if (selected == k)
                        Positioned(
                          right: 0,
                          top: 0,
                          child: CircleAvatar(
                            radius: 8,
                            backgroundColor: AppColors.green,
                            child: HugeIcon(
                              icon: HugeIcons.strokeRoundedTick02,
                              size: 11,
                              color: Colors.white,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
          ],
        );
      },
    );
  }
}
