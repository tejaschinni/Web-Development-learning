// import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:society_seva/features/seller/domain/entities/certificate_entity.dart';
import 'package:society_seva/features/seller/domain/enum/certificate_type.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/image_source_sheet.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/seller_text_field.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';

class CertificatesStep extends ConsumerStatefulWidget {
  const CertificatesStep({super.key, required this.sellerId});

  /// Empty string until the draft exists.
  final String sellerId;

  @override
  ConsumerState<CertificatesStep> createState() => _CertificatesStepState();
}

class _CertificatesStepState extends ConsumerState<CertificatesStep> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _certificateNumber = TextEditingController();
  final _issuingAuthority = TextEditingController();
  XFile? _file;
  DateTime? _issueDate;
  bool _hasExpiry = false;
  DateTime? _expiryDate;
  CertificateType selected = CertificateType.values.first;

  static final _dateFormat = DateFormat('dd MMM yyyy');

  @override
  void dispose() {
    _name.dispose();
    _certificateNumber.dispose();
    _issuingAuthority.dispose();
    super.dispose();
  }

  Future<void> _pickCertificateFile() async {
    // final result = await FilePicker.pickFiles(
    //   type: FileType.custom,
    //   allowedExtensions: ['pdf', 'jpg', 'jpeg', 'png'],
    // );
    // final picked = result?.files.single;
    // if (picked?.path == null) return; // dismissed, or path unavailable
    // setState(() => _file = XFile(picked!.path!, name: picked.name));

    final source = await chooseImageSource(context);
    if (source == null) return;
    final picker = ImagePicker();
    final file = await picker.pickImage(source: source, imageQuality: 85, maxWidth: 2000);
    if (file == null) return;
    setState(() => _file = XFile(file.path, name: file.name));
  }

  Future<void> _pickDate({required bool isExpiry}) async {
    final now = DateTime.now();
    final initial = isExpiry ? (_expiryDate ?? _issueDate ?? now) : (_issueDate ?? now);
    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(2000),
      lastDate: DateTime(now.year + 20),
    );
    if (picked == null) return;
    setState(() {
      if (isExpiry) {
        _expiryDate = picked;
      } else {
        _issueDate = picked;
      }
    });
  }

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  void _addCertificate() {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    if (_file == null) {
      _snack('Please upload the certificate (image or PDF)');
      return;
    }
    final issueDate = _issueDate;
    if (issueDate == null) {
      _snack('Please select the certification date');
      return;
    }
    final expiryDate = _expiryDate;
    if (_hasExpiry) {
      if (expiryDate == null) {
        _snack('Please select the expiry date');
        return;
      }
      if (!expiryDate.isAfter(issueDate)) {
        _snack('Expiry date must be after the certification date');
        return;
      }
    }

    ref
        .read(sellerFormActionProvider.notifier)
        .addPendingCertificate(
          PendingCertificate(
            name: _name.text.trim(),
            file: _file!,
            certificateNumber: _certificateNumber.text.trim(),
            issuingAuthority: _issuingAuthority.text.trim(),
            type: selected.value,
            issueDate: issueDate,
            hasExpiry: _hasExpiry,
            expiryDate: _hasExpiry ? expiryDate : null,
          ),
        );

    setState(() {
      _name.clear();
      _certificateNumber.clear();
      _file = null;
      _issueDate = null;
      _hasExpiry = false;
      _expiryDate = null;
    });
  }

  Widget _dateField({
    required String label,
    required DateTime? value,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: InkWell(
        onTap: onTap,
        child: InputDecorator(
          decoration: InputDecoration(
            labelText: label,
            suffixIcon: const Icon(Icons.calendar_today_outlined),
          ),
          child: Text(
            value == null ? 'Select date' : _dateFormat.format(value),
            style: GoogleFonts.hind(),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pendingCertificates = ref.watch(
      sellerFormActionProvider.select((s) => s.pendingCertificates),
    );

    final AsyncValue<List<CertificateEntity>>? uploaded = widget.sellerId == ''
        ? null
        : ref.watch(sellerCertificatesProvider(widget.sellerId));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Gap(8),
        Text(
          'Add any certifications you have. This step is optional.',
          style: Theme.of(context).textTheme.bodySmall,
        ),
        const Gap(16),
        Form(
          key: _formKey,
          child: Column(
            children: [
              DropdownButtonFormField<CertificateType>(
                initialValue: selected,
                decoration: const InputDecoration(labelText: 'Certificate type'),
                items: CertificateType.values
                    .map(
                      (t) => DropdownMenuItem(
                        value: t,
                        child: SizedBox(
                          width: MediaQuery.of(context).size.width * 0.6,
                          child: Text(t.label, style: GoogleFonts.hind(), overflow: .ellipsis),
                        ),
                      ),
                    )
                    .toList(),
                onChanged: (v) => setState(() => selected = v!),
                validator: (v) => v == null ? 'Select a certificate type' : null,
              ),
              const Gap(16),
              SellerTextField(_name, 'Certificate Name'),
              SellerTextField(_certificateNumber, 'Certificate Number'),
              SellerTextField(_issuingAuthority, 'Issuing Authority '),
              _dateField(
                label: 'Certification Date',
                value: _issueDate,
                onTap: () => _pickDate(isExpiry: false),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: Text('This certificate has an expiry date', style: GoogleFonts.hind()),
                value: _hasExpiry,
                onChanged: (v) => setState(() {
                  _hasExpiry = v;
                  if (!v) _expiryDate = null;
                }),
              ),
              if (_hasExpiry)
                _dateField(
                  label: 'Expiry Date',
                  value: _expiryDate,
                  onTap: () => _pickDate(isExpiry: true),
                ),
            ],
          ),
        ),
        OutlinedButton.icon(
          onPressed: _pickCertificateFile,
          icon: Icon(_file == null ? Icons.upload_file_outlined : Icons.check_circle_outline),
          label: Text(
            _file == null ? 'Upload certificate (image or PDF)' : _file!.name,
            overflow: TextOverflow.ellipsis,
            style: GoogleFonts.hind(),
          ),
        ),
        const Gap(12),
        Align(
          alignment: Alignment.centerRight,
          child: FilledButton.tonal(
            onPressed: _addCertificate,
            child: Text('Add certificate', style: GoogleFonts.hind()),
          ),
        ),
        if (pendingCertificates.isNotEmpty) ...[
          const Gap(20),
          const Text(
            'Added certificates',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
          ),
          const Gap(8),
          for (final cert in pendingCertificates)
            Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                leading: const Icon(Icons.verified_outlined),
                title: Text(cert.name, style: GoogleFonts.hind()),
                subtitle: Text(
                  cert.hasExpiry && cert.expiryDate != null
                      ? 'Issued ${_dateFormat.format(cert.issueDate)} · Expires ${_dateFormat.format(cert.expiryDate!)}'
                      : 'Issued ${_dateFormat.format(cert.issueDate)} · No expiry',
                  style: GoogleFonts.hind(),
                ),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () =>
                      ref.read(sellerFormActionProvider.notifier).removePendingCertificate(cert),
                ),
              ),
            ),
        ],
        if (uploaded != null)
          uploaded.when(
            loading: () => const Padding(
              padding: EdgeInsets.symmetric(vertical: 16),
              child: Center(child: CircularProgressIndicator()),
            ),
            // error: (e, _) => const SizedBox.shrink(),
            error: (e, st) {
              debugPrint('certificates error: $e\n$st');
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Text('Could not load certificates: $e'),
              );
            },
            data: (list) {
              if (list.isEmpty) return const SizedBox.shrink();
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Gap(20),
                  const Text(
                    'Uploaded certificates',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                  const Gap(8),
                  for (final cert in list)
                    Card(
                      margin: const EdgeInsets.only(bottom: 8),
                      child: ListTile(
                        leading: const Icon(Icons.verified, color: Colors.green),
                        title: Text(cert.certificateName, style: GoogleFonts.hind()),
                        // subtitle: Text(
                        //   cert.h && cert. != null
                        //       ? 'Issued ${_dateFormat.format(cert.issueDate)} · Expires ${_dateFormat.format(cert.expiryDate!)}'
                        //       : 'Issued ${_dateFormat.format(cert.issueDate)} · No expiry',
                        //   style: GoogleFonts.hind(),
                        // ),
                      ),
                    ),
                ],
              );
            },
          ),
        const Gap(8),
      ],
    );
  }
}
