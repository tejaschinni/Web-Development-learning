import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:society_seva/features/seller/domain/entities/kyc_document_entity.dart';
import 'package:society_seva/features/seller/domain/enum/document_type.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/image_source_sheet.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';

class DocumentsStep extends ConsumerStatefulWidget {
  const DocumentsStep({super.key, required this.sellerId});
  final String sellerId;

  @override
  ConsumerState<DocumentsStep> createState() => _DocumentsStepState();
}

class _DocumentsStepState extends ConsumerState<DocumentsStep> {
  final _formKey = GlobalKey<FormState>();
  final _docNumber = TextEditingController();
  DocumentType _docType = DocumentType.values.first;
  XFile? _docFile;

  @override
  void dispose() {
    _docNumber.dispose();
    super.dispose();
  }

  String? _validateDocNumber(String? v) {
    final value = (v ?? '').trim().toUpperCase();
    if (value.isEmpty) return 'Required';
    switch (_docType.type) {
      case 'AADHAAR':
        return RegExp(r'^\d{12}$').hasMatch(value) ? null : 'Enter a 12-digit Aadhaar number';
      case 'PAN':
        return RegExp(r'^[A-Z]{5}[0-9]{4}[A-Z]$').hasMatch(value)
            ? null
            : 'Enter a valid PAN (e.g. ABCDE1234F)';
      case 'GST_CERTIFICATE':
        return value.length == 15 ? null : 'GSTIN must be 15 characters';
      default:
        return null;
    }
  }

  Future<void> _pickDocumentFile() async {
    final source = await chooseImageSource(context);
    if (source == null) return;
    final picker = ImagePicker();
    final file = await picker.pickImage(source: source, imageQuality: 85, maxWidth: 2000);
    if (file == null) return;
    setState(() => _docFile = file);
  }

  void _addDocument() {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    if (_docFile == null) {
      _snack('Please upload the document');
      return;
    }

    ref
        .read(sellerFormActionProvider.notifier)
        .addPendingDocument(
          PendingDocument(
            type: _docType.type,
            number: _docNumber.text.trim().toUpperCase(),
            file: _docFile!,
          ),
        );

    setState(() {
      _docNumber.clear();
      _docFile = null;
    });
  }

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  /// Downloads a KYC document via GET /api/v1/sellers/{sellerId}/kyc/{file}/file
  /// and reports success. Currently the call returns static placeholder data
  /// (see seller_onboarding_remote_data_source.dart) - swap in a real file
  /// viewer/saver here once that endpoint is live.
  Future<void> _downloadDocument(KycDocumentEntity doc) async {
    try {
      final base64File = await ref
          .read(downloadKycDocumentFileUsecase)
          .call(sellerId: widget.sellerId, documentFileUrl: doc.documentFileUrl);
      _snack('Downloaded ${_label(doc.documentType)} (${base64File.length} chars, base64)');
    } catch (e) {
      _snack('Could not download document: $e');
    }
  }

  String _label(String value) {
    final s = value.toLowerCase().replaceAll('_', ' ');
    return '${s[0].toUpperCase()}${s.substring(1)}';
  }

  @override
  Widget build(BuildContext context) {
    final pendingDocuments = ref.watch(sellerFormActionProvider.select((s) => s.pendingDocuments));
    final AsyncValue<List<KycDocumentEntity>>? uploaded = widget.sellerId == ''
        ? null
        : ref.watch(sellerDocumentProvider(widget.sellerId));
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Gap(8),
        Form(
          key: _formKey,
          child: Column(
            children: [
              DropdownButtonFormField<DocumentType>(
                initialValue: _docType,
                decoration: const InputDecoration(labelText: 'Document Type'),
                items: DocumentType.values
                    .map(
                      (d) => DropdownMenuItem(
                        value: d,
                        child: Text(d.label, style: GoogleFonts.hind()), // "Aadhaar card"
                      ),
                    )
                    .toList(),
                onChanged: (v) => setState(() {
                  _docType = v ?? _docType;
                  _docNumber.clear();
                }),
              ),
              const Gap(20),
              TextFormField(
                controller: _docNumber,
                textCapitalization: TextCapitalization.characters,
                keyboardType: _docType.type == 'AADHAAR' ? TextInputType.number : null,
                validator: _validateDocNumber,
                decoration: InputDecoration(labelText: '${_label(_docType.label)} Number'),
              ),
            ],
          ),
        ),
        const Gap(16),
        OutlinedButton.icon(
          onPressed: _pickDocumentFile,
          icon: Icon(_docFile == null ? Icons.upload_file_outlined : Icons.check_circle_outline),
          label: Text(
            _docFile == null ? 'Upload document' : _docFile!.name,
            overflow: TextOverflow.ellipsis,
            style: GoogleFonts.hind(),
          ),
        ),
        const Gap(12),
        Align(
          alignment: Alignment.centerRight,
          child: FilledButton.tonal(
            onPressed: _addDocument,
            child: Text('Add document', style: GoogleFonts.hind()),
          ),
        ),
        if (pendingDocuments.isNotEmpty) ...[
          const Gap(20),
          const Text(
            'Added documents',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
          ),
          const Gap(8),
          for (final doc in pendingDocuments)
            Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                leading: const Icon(Icons.description_outlined),
                title: Text(_label(doc.type), style: GoogleFonts.hind()),
                subtitle: Text(doc.number, style: GoogleFonts.hind()),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () =>
                      ref.read(sellerFormActionProvider.notifier).removePendingDocument(doc),
                ),
              ),
            ),
        ],
        if (uploaded != null)
          uploaded.when(
            loading: () => const Padding(
              padding: EdgeInsets.symmetric(vertical: 16),
              child: Center(child: CircularProgressIndicator()),
            ),
            // error: (e, _) => const SizedBox.shrink(),
            error: (e, st) {
              debugPrint('certificates error: $e\n$st');
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Text('Could not load certificates: $e'),
              );
            },
            data: (list) {
              if (list.isEmpty) return const SizedBox.shrink();
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Gap(20),
                  const Text(
                    'Uploaded documents',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                  const Gap(8),
                  for (final doc in list)
                    Card(
                      margin: const EdgeInsets.only(bottom: 8),
                      child: ListTile(
                        leading: const Icon(Icons.verified, color: Colors.green),
                        title: Text(_label(doc.documentType), style: GoogleFonts.hind()),
                        subtitle: Text(doc.verificationStatus, style: GoogleFonts.hind()),
                        trailing: IconButton(
                          icon: const Icon(Icons.download_outlined),
                          tooltip: 'Download',
                          onPressed: () => _downloadDocument(doc),
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
        const Gap(8),
      ],
    );
  }
}
