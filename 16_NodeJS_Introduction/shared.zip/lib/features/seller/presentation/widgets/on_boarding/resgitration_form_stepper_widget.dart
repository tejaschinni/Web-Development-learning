import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/profile/presentation/providers/profile_provider.dart';
import 'package:society_seva/features/seller/data/models/request/seller_profile_request.dart';
import 'package:society_seva/features/seller/domain/entities/seller_profile_entity.dart';
import 'package:society_seva/features/seller/domain/enum/seller_type_config.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/registration_steps/registration_address_step.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/registration_steps/registration_basic_info.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/registration_steps/registration_photos_documets_step.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/registration_steps/registration_review_step.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/registration_steps/registration_seller_type_form_step.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/register_availablitiy_step.dart';

class ResgitrationFormStepperWidget extends ConsumerStatefulWidget {
  const ResgitrationFormStepperWidget({
    super.key,
    this.initial,
    this.isEdit,
    this.enableSaveDraft = true,
    this.enableSubmit = true,
  });
  final SellerProfileEntity? initial;
  final bool? isEdit;

  final bool enableSaveDraft;
  final bool enableSubmit;

  @override
  ConsumerState<ResgitrationFormStepperWidget> createState() =>
      _ResgitrationFormStepperWidgetState();
}

class _ResgitrationFormStepperWidgetState extends ConsumerState<ResgitrationFormStepperWidget> {
  static const _labels = [
    'Basic info',
    'Seller type',
    'Address &\nService Area',
    'Photos &\nDocuments',
    'Review &\nSubmit',
  ];
  GoogleMapController? _map;
  LatLng? _selected;
  LatLng? _devicePoint;
  bool _pointChanged = false;
  LocationPermission _permission = LocationPermission.denied;
  bool _permissionReady = false;
  bool _serviceDisabled = false;
  bool _locating = false;
  bool _geocoding = false;
  bool _locationRequested = false;
  String? _locationError;
  int _geocodeRequest = 0;
  bool get _hasLocationPermission =>
      _permission == LocationPermission.whileInUse || _permission == LocationPermission.always;

  String _sellerType = sellerTypes.first;

  int _step = 0;
  bool get _isLast => _step == _labels.length - 1;

  void _next() {
    if (!_isLast) {
      final nextStep = _step + 1;
      setState(() => _step = nextStep);
      if (nextStep == 2 && !_locationRequested && _selected == null) {
        _locationRequested = true;
        _requestLocation();
      }
    }
  }

  void _back() {
    if (_step > 0) setState(() => _step--);
  }

  // Profile already exists or editing -> the main button becomes "Update".
  bool get _isUpdate =>
      widget.isEdit == true ||
      (widget.initial != null && widget.initial!.approvalStatus == "APPROVED");

  bool _isSaving = false;
  bool _isSubmitting = false;
  bool get _busy => _isSaving || _isSubmitting;

  late final _displayNameController = TextEditingController();
  late final _businessNameController = TextEditingController();
  late final _bioController = TextEditingController();
  late final _addressController = TextEditingController();
  late final _cityController = TextEditingController();
  late final _stateController = TextEditingController();
  late final _countryController = TextEditingController();
  late final _pinCodeController = TextEditingController();
  Timer? _debounceTimer;
  bool _isUpdatingAddressFromMap = false;

  @override
  void initState() {
    super.initState();
    final initialSeller = widget.initial ?? ref.read(mySellerProfileProvider).value;
    if (initialSeller != null) {
      _applyInitialSeller(initialSeller);
    } else {
      _cityController.text = 'Pune';
      _stateController.text = 'Maharashtra';
      _countryController.text = 'India';
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        final profile = ref.read(profileControllerProvider).profile;
        if (profile != null) {
          if (_displayNameController.text.isEmpty) {
            _displayNameController.text = profile.fullName;
          }
          ref.read(sellerOnboardingProvider.notifier).updateReg((cur) => cur.copyWith(
            fullName: cur.fullName.isEmpty ? profile.fullName : cur.fullName,
            mobile: cur.mobile.isEmpty ? profile.mobileNumber : cur.mobile,
            email: cur.email.isEmpty ? profile.email : cur.email,
          ));
        }
      });
    }
  }

  @override
  void didUpdateWidget(covariant ResgitrationFormStepperWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.initial != null && widget.initial != oldWidget.initial) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _applyInitialSeller(widget.initial!);
      });
    }
  }

  void _applyInitialSeller(SellerProfileEntity s) {
    if (s.sellerType.isNotEmpty && sellerTypes.contains(s.sellerType)) {
      _sellerType = s.sellerType;
    }
    final bName = (s.businessName != null && s.businessName!.trim().isNotEmpty)
        ? s.businessName!.trim()
        : (s.displayName.isNotEmpty ? s.displayName : '');
    final bioText = (s.bio != null && s.bio!.trim().isNotEmpty)
        ? s.bio!.trim()
        : '';
    final dName = s.displayName.isNotEmpty ? s.displayName : '';

    _displayNameController.text = dName;
    _businessNameController.text = bName;
    _bioController.text = bioText;

    _addressController.text = s.address;
    _cityController.text = s.city;
    _stateController.text = s.state;
    _countryController.text = s.country;
    _pinCodeController.text = s.pinCode;
    if (s.latitude != null && s.longitude != null && !(s.latitude == 0 && s.longitude == 0)) {
      _selected = LatLng(s.latitude!, s.longitude!);
    }

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final userProfile = ref.read(profileControllerProvider).profile;
      final finalDisplayName = dName.isNotEmpty ? dName : (userProfile?.fullName ?? '');
      if (_displayNameController.text.isEmpty && finalDisplayName.isNotEmpty) {
        _displayNameController.text = finalDisplayName;
      }

      ref.read(sellerOnboardingProvider.notifier).updateReg((cur) => cur.copyWith(
        fullName: finalDisplayName,
        mobile: cur.mobile.isNotEmpty ? cur.mobile : (userProfile?.mobileNumber ?? ''),
        email: cur.email.isNotEmpty ? cur.email : (userProfile?.email ?? ''),
        businessName: bName.isNotEmpty ? bName : cur.businessName,
        pickupAddress: s.address,
        city: s.city,
        stateName: s.state,
        country: s.country,
        pinCode: s.pinCode,
        latitude: s.latitude,
        longitude: s.longitude,
        radius: s.deliveryRadiusKm?.toString() ?? cur.radius,
        locality: s.targetArea ?? cur.locality,
        hasFssai: s.fssaiRequired,
        description: bioText.isNotEmpty ? bioText : cur.description,
        fssaiCertificateId: s.fssaiCertificateId ?? cur.fssaiCertificateId,
        websiteUrl: s.websiteUrl ?? cur.websiteUrl,
        socialMediaLinks: s.socialMediaLinks ?? cur.socialMediaLinks,
        legalCompliance: s.legalCompliance ?? cur.legalCompliance,
      ));

      ref.read(sellerOnBoardingRepository).fetchSellerAvailableDaysRepo(sellerID: s.id).then((entity) {
        if (mounted) {
          final avail = AvailabilityValue.fromJson({
            'availableDays': entity.availableDays,
            'daysType': entity.daysType,
            'fromTime': entity.fromTime,
            'toTime': entity.toTime,
          });
          ref.read(sellerFormActionProvider.notifier).setAvailability(avail);
        }
      }).catchError((_) {});
    });
  }

  @override
  void dispose() {
    _debounceTimer?.cancel();
    _displayNameController.dispose();
    _businessNameController.dispose();
    _bioController.dispose();
    _addressController.dispose();
    _cityController.dispose();
    _stateController.dispose();
    _countryController.dispose();
    _pinCodeController.dispose();
    _map?.dispose();
    super.dispose();
  }

  Future<void> _saveDraft() async {
    if (_busy) return;
    setState(() => _isSaving = true);
    try {
      final s = ref.read(sellerOnboardingProvider).reg;
      final point = _selected ?? _devicePoint;
      final userId = ref.read(profileControllerProvider).profile?.id ?? '';
      final availability = ref.read(sellerFormActionProvider).availability;

      final request = SellerProfileRequest(
        userId: userId,
        displayName: _displayNameController.text.trim().isNotEmpty
            ? _displayNameController.text.trim()
            : (s.fullName.isNotEmpty ? s.fullName : (s.businessName.isNotEmpty ? s.businessName : 'Seller')),
        businessName: _businessNameController.text.trim().isNotEmpty
            ? _businessNameController.text.trim()
            : s.businessName,
        sellerType: _sellerType,
        bio: _bioController.text.trim().isNotEmpty
            ? _bioController.text.trim()
            : s.description,
        fssaiRequired: s.hasFssai ?? false,
        fssaiCertificateId: s.fssaiCertificateId,
        websiteUrl: s.websiteUrl,
        socialMediaLinks: s.socialMediaLinks,
        legalCompliance: s.legalCompliance,
        address: s.pickupAddress.isNotEmpty ? s.pickupAddress : (_addressController.text.isNotEmpty ? _addressController.text : 'Pune'),
        city: s.city.isNotEmpty ? s.city : (_cityController.text.isNotEmpty ? _cityController.text : 'Pune'),
        state: s.stateName.isNotEmpty ? s.stateName : (_stateController.text.isNotEmpty ? _stateController.text : 'Maharashtra'),
        country: s.country.isNotEmpty ? s.country : (_countryController.text.isNotEmpty ? _countryController.text : 'India'),
        pinCode: s.pinCode.isNotEmpty ? s.pinCode : (_pinCodeController.text.isNotEmpty ? _pinCodeController.text : '411058'),
        latitude: point?.latitude ?? s.latitude ?? 18.5204,
        longitude: point?.longitude ?? s.longitude ?? 73.8567,
        deliveryRadiusKm: double.tryParse(s.radius) ?? 50.0,
        targetArea: s.locality.isNotEmpty ? s.locality : _addressController.text,
        availableDaysType: availability.daysType.api,
        availableDays: kWeekDays.where(availability.days.contains).toList(),
        availableFromTime: formatApiTime(availability.from),
        availableToTime: formatApiTime(availability.to),
      );

      final notifier = ref.read(sellerFormActionProvider.notifier);
      final currentId = notifier.currentSellerId ?? widget.initial?.id;

      final bool ok;
      if (currentId != null) {
        ok = await notifier.update(request, currentId);
      } else {
        ok = await notifier.save(request);
      }

      if (ok && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(_isUpdate ? 'Seller profile updated' : 'Seller profile and availability saved as draft')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error saving draft: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  Future<void> _submit() async {
    if (_busy) return;
    setState(() => _isSubmitting = true);
    try {
      final s = ref.read(sellerOnboardingProvider).reg;
      final point = _selected ?? _devicePoint;
      final userId = ref.read(profileControllerProvider).profile?.id ?? '';
      final availability = ref.read(sellerFormActionProvider).availability;

      final request = SellerProfileRequest(
        userId: userId,
        displayName: _displayNameController.text.trim().isNotEmpty
            ? _displayNameController.text.trim()
            : (s.fullName.isNotEmpty ? s.fullName : (s.businessName.isNotEmpty ? s.businessName : 'Seller')),
        businessName: _businessNameController.text.trim().isNotEmpty
            ? _businessNameController.text.trim()
            : s.businessName,
        sellerType: _sellerType,
        bio: _bioController.text.trim().isNotEmpty
            ? _bioController.text.trim()
            : s.description,
        fssaiRequired: s.hasFssai ?? false,
        fssaiCertificateId: s.fssaiCertificateId,
        websiteUrl: s.websiteUrl,
        socialMediaLinks: s.socialMediaLinks,
        legalCompliance: s.legalCompliance,
        address: s.pickupAddress.isNotEmpty ? s.pickupAddress : (_addressController.text.isNotEmpty ? _addressController.text : 'Pune'),
        city: s.city.isNotEmpty ? s.city : (_cityController.text.isNotEmpty ? _cityController.text : 'Pune'),
        state: s.stateName.isNotEmpty ? s.stateName : (_stateController.text.isNotEmpty ? _stateController.text : 'Maharashtra'),
        country: s.country.isNotEmpty ? s.country : (_countryController.text.isNotEmpty ? _countryController.text : 'India'),
        pinCode: s.pinCode.isNotEmpty ? s.pinCode : (_pinCodeController.text.isNotEmpty ? _pinCodeController.text : '411058'),
        latitude: point?.latitude ?? s.latitude ?? 18.5204,
        longitude: point?.longitude ?? s.longitude ?? 73.8567,
        deliveryRadiusKm: double.tryParse(s.radius) ?? 50.0,
        targetArea: s.locality.isNotEmpty ? s.locality : _addressController.text,
        availableDaysType: availability.daysType.api,
        availableDays: kWeekDays.where(availability.days.contains).toList(),
        availableFromTime: formatApiTime(availability.from),
        availableToTime: formatApiTime(availability.to),
      );

      final notifier = ref.read(sellerFormActionProvider.notifier);
      final currentId = notifier.currentSellerId ?? widget.initial?.id;

      final bool ok;
      if (_isUpdate && currentId != null) {
        ok = await notifier.update(request, currentId);
      } else {
        ok = await notifier.submit(request);
      }

      if (ok && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(_isUpdate ? 'Seller profile and availability updated' : 'Seller profile submitted successfully')),
        );
        Navigator.of(context).pop();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error submitting profile: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  Future<void> _requestLocation() async {
    if (_locating) return;
    setState(() {
      _locating = true;
      _locationError = null;
    });
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        if (mounted) {
          setState(() {
            _serviceDisabled = true;
            _permissionReady = true;
            _locationError = 'Turn on device location to center the map on you.';
          });
        }
        return;
      }
      if (mounted) setState(() => _serviceDisabled = false);
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (!mounted) return;
      setState(() {
        _permission = permission;
        _permissionReady = true;
      });
      if (permission != LocationPermission.whileInUse && permission != LocationPermission.always) {
        setState(
          () => _locationError = permission == LocationPermission.deniedForever
              ? 'Location access is disabled for this app. You can enable it in Settings or choose a point on the map.'
              : 'Location access was not granted. You can still choose a point on the map.',
        );
        return;
      }
      Position? position;
      try {
        position = await Geolocator.getCurrentPosition(
          locationSettings: const LocationSettings(
            accuracy: LocationAccuracy.high,
            timeLimit: Duration(seconds: 10),
          ),
        );
      } catch (_) {
        position = await Geolocator.getLastKnownPosition();
        if (position == null) rethrow;
      }
      final current = LatLng(position.latitude, position.longitude);
      if (!mounted) return;
      setState(() => _devicePoint = current);
      await _moveTo(current, zoom: 16);
      await _selectPoint(current);
    } catch (_) {
      if (mounted) {
        setState(
          () => _locationError =
              'Could not get your current location. You can still choose a point on the map or type an address.',
        );
      }
    } finally {
      if (mounted) setState(() => _locating = false);
    }
  }

  Future<void> _moveTo(LatLng point, {required double zoom}) async {
    try {
      await _map?.animateCamera(
        CameraUpdate.newCameraPosition(CameraPosition(target: point, zoom: zoom)),
      );
    } catch (_) {
      // The map can be disposed while the step is closing.
    }
  }

  Future<void> _selectPoint(LatLng point) async {
    final requestId = ++_geocodeRequest;
    setState(() {
      _selected = point;
      _pointChanged = true;
      _geocoding = true;
      _locationError = null;
    });

    try {
      final places = await Geocoding().placemarkFromCoordinates(point.latitude, point.longitude);
      if (!mounted || requestId != _geocodeRequest) return;
      if (places.isEmpty) throw StateError('No address found for this point.');
      final place = places.first;
      final locality = [place.subLocality, place.thoroughfare, place.name]
          .whereType<String>()
          .map((value) => value.trim())
          .where((value) => value.isNotEmpty)
          .toSet()
          .join(', ');

      final addressText = locality.isNotEmpty ? locality : (place.locality ?? '');
      final cityText = [place.locality, place.subAdministrativeArea, place.administrativeArea]
          .whereType<String>()
          .map((value) => value.trim())
          .firstWhere((value) => value.isNotEmpty, orElse: () => '');
      final stateText = place.administrativeArea ?? '';
      final countryText = (place.country?.isNotEmpty == true ? place.country : place.isoCountryCode) ?? '';
      final pinCodeText = place.postalCode ?? '';

      _isUpdatingAddressFromMap = true;
      _addressController.text = addressText;
      _cityController.text = cityText;
      _stateController.text = stateText;
      _countryController.text = countryText;
      _pinCodeController.text = pinCodeText;
      _isUpdatingAddressFromMap = false;

      ref.read(sellerOnboardingProvider.notifier).updateReg((cur) => cur.copyWith(
        pickupAddress: addressText,
        city: cityText,
        stateName: stateText,
        country: countryText,
        pinCode: pinCodeText,
        locality: locality,
        latitude: point.latitude,
        longitude: point.longitude,
      ));

      if (addressText.isEmpty || cityText.isEmpty) {
        setState(
          () => _locationError = 'Some address details were unavailable. Please complete the fields.',
        );
      }
    } catch (_) {
      if (mounted && requestId == _geocodeRequest) {
        setState(
          () => _locationError =
              'Could not look up this address. Fill in the address fields to continue.',
        );
      }
    } finally {
      if (mounted && requestId == _geocodeRequest) {
        setState(() => _geocoding = false);
      }
    }
  }

  void _onAddressChanged(String val) {
    if (_isUpdatingAddressFromMap) return;
    ref.read(sellerOnboardingProvider.notifier).updateReg((cur) => cur.copyWith(pickupAddress: val));
    _debounceTimer?.cancel();
    _debounceTimer = Timer(const Duration(milliseconds: 750), () {
      _searchCoordinatesFromAddress();
    });
  }

  void _onCityChanged(String val) {
    if (_isUpdatingAddressFromMap) return;
    ref.read(sellerOnboardingProvider.notifier).updateReg((cur) => cur.copyWith(city: val));
    _debounceTimer?.cancel();
    _debounceTimer = Timer(const Duration(milliseconds: 750), () {
      _searchCoordinatesFromAddress();
    });
  }

  void _onStateChanged(String val) {
    if (_isUpdatingAddressFromMap) return;
    ref.read(sellerOnboardingProvider.notifier).updateReg((cur) => cur.copyWith(stateName: val));
  }

  void _onCountryChanged(String val) {
    if (_isUpdatingAddressFromMap) return;
    ref.read(sellerOnboardingProvider.notifier).updateReg((cur) => cur.copyWith(country: val));
  }

  void _onPinCodeChanged(String val) {
    if (_isUpdatingAddressFromMap) return;
    ref.read(sellerOnboardingProvider.notifier).updateReg((cur) => cur.copyWith(pinCode: val));
    if (val.trim().length >= 6) {
      _debounceTimer?.cancel();
      _debounceTimer = Timer(const Duration(milliseconds: 500), () {
        _searchCoordinatesFromAddress();
      });
    }
  }

  void _onRadiusChanged(int? km) {
    final str = km?.toString() ?? '';
    ref.read(sellerOnboardingProvider.notifier).updateReg((cur) => cur.copyWith(radius: str));
  }

  Future<void> _searchCoordinatesFromAddress() async {
    if (_isUpdatingAddressFromMap) return;
    final address = _addressController.text.trim();
    final city = _cityController.text.trim();
    final state = _stateController.text.trim();
    final pin = _pinCodeController.text.trim();

    final queryParts = [address, city, state, pin].where((s) => s.isNotEmpty).toList();
    if (queryParts.isEmpty) return;

    final query = queryParts.join(', ');
    if (query.length < 3) return;

    setState(() {
      _geocoding = true;
      _locationError = null;
    });

    try {
      List<Location> locations = [];
      try {
        locations = await Geocoding().locationFromAddress(query);
      } catch (_) {
        if (address.isNotEmpty && address != query) {
          locations = await Geocoding().locationFromAddress(address);
        }
      }

      if (!mounted) return;
      if (locations.isNotEmpty) {
        final loc = locations.first;
        final point = LatLng(loc.latitude, loc.longitude);
        setState(() {
          _selected = point;
          _pointChanged = true;
        });
        await _moveTo(point, zoom: 16);
        ref.read(sellerOnboardingProvider.notifier).updateReg((cur) => cur.copyWith(
          latitude: point.latitude,
          longitude: point.longitude,
        ));
      }
    } catch (_) {
      // Address search silently ignores incomplete keystrokes
    } finally {
      if (mounted) setState(() => _geocoding = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    ref.listen<AsyncValue<SellerProfileEntity?>>(mySellerProfileProvider, (previous, next) {
      final seller = next.value;
      if (seller != null && widget.initial == null && previous?.value == null) {
        _applyInitialSeller(seller);
      }
    });

    final formState = ref.watch(sellerOnboardingProvider);
    final s = formState.reg;
    final n = ref.read(sellerOnboardingProvider.notifier);
    return Column(
      children: [
        _StepIndicator(current: _step, labels: _labels),
        Expanded(
          child: IndexedStack(
            index: _step,
            children: [
              _StepScroll(
                children: [
                  RegistrationBasicInfo(
                    onUpdate: n.updateReg,
                    s: s,
                    displayNameController: _displayNameController,
                    businessNameController: _businessNameController,
                    bioController: _bioController,
                  ),
                ],
              ),
              _StepScroll(
                children: [
                  RegistrationSellerTypeFormStep(
                    onUpdate: n.updateReg,
                    s: s,
                    sellerType: _sellerType,
                    onSellerTypeChanged: (v) => setState(() => _sellerType = v ?? _sellerType),
                  ),
                ],
              ),
              _StepScroll(
                children: [
                  // 3. Address with small map
                  RegistrationAddressStep(
                    isActive: _step == 2,
                    selected: _selected,
                    devicePoint: _devicePoint,
                    hasLocationPermission: _hasLocationPermission,
                    locating: _locating,
                    permissionReady: _permissionReady,
                    serviceDisabled: _serviceDisabled,
                    permission: _permission,
                    geocoding: _geocoding,
                    locationError: _locationError,
                    onMapCreated: (controller) {
                      _map = controller;
                      final target = _selected ?? _devicePoint;
                      if (target != null) {
                        _moveTo(target, zoom: 16);
                      }
                    },
                    onMapTap: _selectPoint,
                    onRequestLocation: _requestLocation,
                    addressController: _addressController,
                    cityController: _cityController,
                    stateController: _stateController,
                    countryController: _countryController,
                    pinCodeController: _pinCodeController,
                    deliveryRadius: int.tryParse(s.radius) ?? 50,
                    onRadiusChanged: _onRadiusChanged,
                    onAddressChanged: _onAddressChanged,
                    onCityChanged: _onCityChanged,
                    onStateChanged: _onStateChanged,
                    onCountryChanged: _onCountryChanged,
                    onPinCodeChanged: _onPinCodeChanged,
                    onSearchAddress: () {
                      _debounceTimer?.cancel();
                      _searchCoordinatesFromAddress();
                    },
                  ),
                ],
              ),
              _StepScroll(children: [
                RegistrationPhotosDocumetsStep(
                  sellerId: ref.watch(sellerFormActionProvider.notifier).currentSellerId ?? widget.initial?.id ?? '',
                ),
              ]),
              _StepScroll(
                children: [
                  RegistrationReviewStep(
                    s: s,
                    sellerType: _sellerType,
                    sellerId: ref.watch(sellerFormActionProvider.notifier).currentSellerId ?? widget.initial?.id ?? '',
                    onEdit: (stepIndex) => setState(() => _step = stepIndex),
                  ),
                ],
              ),
            ],
          ),
        ),
        _BottomBar(
          step: _step,
          isLast: _isLast,
          isUpdate: _isUpdate,
          isSaving: _isSaving,
          isSubmitting: _isSubmitting,
          canSaveDraft: widget.enableSaveDraft && !_busy,
          canSubmit: widget.enableSubmit && !_busy && RegistrationReviewStep.missingFields(s, _sellerType).isEmpty,
          onBack: _back,
          onNext: _next,
          onSaveDraft: _saveDraft,
          onSubmit: _submit,
        ),
      ],
    );
  }
}

class _StepScroll extends StatelessWidget {
  const _StepScroll({required this.children});
  final List<Widget> children;

  @override
  Widget build(BuildContext context) => SingleChildScrollView(
    padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
    child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: children),
  );
}

class _BottomBar extends StatelessWidget {
  const _BottomBar({
    required this.step,
    required this.isLast,
    required this.isUpdate,
    required this.isSaving,
    required this.isSubmitting,
    required this.canSaveDraft,
    required this.canSubmit,
    required this.onBack,
    required this.onNext,
    required this.onSaveDraft,
    required this.onSubmit,
  });
  final int step;
  final bool isLast, isUpdate, isSaving, isSubmitting;
  final bool canSaveDraft, canSubmit;
  final VoidCallback onBack, onNext, onSaveDraft, onSubmit;

  Widget _loader() =>
      const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2));

  @override
  Widget build(BuildContext context) {
    final busy = isSaving || isSubmitting;
    final outlined = OutlinedButton.styleFrom(
      minimumSize: const Size(0, 52),
      foregroundColor: AppColors.green,
      padding: const EdgeInsets.symmetric(horizontal: 20),
      side: const BorderSide(color: AppColors.green),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
    );
    final filled = FilledButton.styleFrom(
      minimumSize: const Size(0, 52),
      padding: const EdgeInsets.symmetric(horizontal: 20),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
    );

    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
        child: Row(
          children: [
            if (step > 0) ...[
              Expanded(
                child: OutlinedButton(
                  style: outlined,
                  onPressed: busy ? null : onBack,
                  child: const Text('Back'),
                ),
              ),
              const SizedBox(width: 8),
            ],
            if (isLast) ...[
              Expanded(
                child: OutlinedButton(
                  style: outlined,
                  onPressed: canSaveDraft ? onSaveDraft : null,
                  child: isSaving ? _loader() : const Text('Save as Draft'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                flex: 2,
                child: FilledButton(
                  style: filled,
                  onPressed: canSubmit ? onSubmit : null,
                  child: isSubmitting ? _loader() : Text(isUpdate ? 'Update' : 'Submit'),
                ),
              ),
            ] else
              Expanded(
                flex: 2,
                child: FilledButton(style: filled, onPressed: onNext, child: const Text('Next')),
              ),
          ],
        ),
      ),
    );
  }
}

class _StepIndicator extends StatelessWidget {
  const _StepIndicator({required this.current, required this.labels});
  final int current;
  final List<String> labels;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,

        children: List.generate(labels.length, (idx) {
          final active = idx <= current;
          final isFirst = idx == 0;
          final isLast = idx == labels.length - 1;

          return Expanded(
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Divider(
                        thickness: 2,
                        height: 2,
                        color: isFirst
                            ? Colors.transparent
                            : (idx <= current ? AppColors.green : AppColors.border),
                      ),
                    ),
                    CircleAvatar(
                      radius: 15,
                      backgroundColor: active ? AppColors.green : AppColors.bg,
                      child: Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: active ? AppColors.green : AppColors.border,
                            width: 1.5,
                          ),
                        ),
                        alignment: Alignment.center,
                        child: idx < current
                            ? const Icon(Icons.check, size: 16, color: Colors.white)
                            : Text(
                                '${idx + 1}',
                                style: TextStyle(
                                  color: active ? Colors.white : AppColors.muted,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                      ),
                    ),
                    Expanded(
                      child: Divider(
                        thickness: 2,
                        height: 2,
                        color: isLast
                            ? Colors.transparent
                            : (idx < current ? AppColors.green : AppColors.border),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  labels[idx],
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 10,
                    height: 1.2,
                    color: active ? AppColors.green : AppColors.muted,
                    fontWeight: active ? FontWeight.w600 : FontWeight.w400,
                  ),
                ),
              ],
            ),
          );
        }),
      ),
    );
  }
}
