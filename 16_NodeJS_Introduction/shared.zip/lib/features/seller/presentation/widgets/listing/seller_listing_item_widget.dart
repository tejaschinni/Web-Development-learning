import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/domain/entities/seller_listing_entity.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_listing_provider.dart';
import 'package:society_seva/features/seller/presentation/screens/listing/seller_listing_screen.dart'
    hide ListingType;

enum _MenuAction { edit, toggle, outOfStock, delete }

class SellerListingItemWidget extends ConsumerWidget {
  final SellerListingEntity item;
  final ValueChanged<bool> onToggle;
  final VoidCallback onEdit;
  final VoidCallback onOutOfStock;
  final VoidCallback onDelete;

  const SellerListingItemWidget({
    super.key,
    required this.item,
    required this.onToggle,
    required this.onEdit,
    required this.onOutOfStock,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final status = fromApi(item.availabilityStatus);
    final isActive = status == ListingStatus.active;

    // first approved image for this listing
    final imageUrl = ref
        .watch(sellerListingImagesProvider(item.id))
        .valueOrNull
        ?.where((image) => image.moderationStatus.toUpperCase() == 'APPROVED')
        .firstOrNull
        ?.imageUrl;

    final info = <String>[if (item.quantityAvailable != 0) 'Stock: ${item.quantityAvailable}'];
    final priceText = '\u20B9 ${_fmt(item.basePrice.toDouble())}';

    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
        boxShadow: const [BoxShadow(color: Color(0x0A000000), blurRadius: 6, offset: Offset(0, 2))],
      ),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: _Thumb(url: imageUrl, type: ListingType.product),
          ),
          const Gap(12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: AppColors.ink,
                  ),
                ),
                const Gap(6),
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        priceText,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                          color: AppColors.ink,
                        ),
                      ),
                    ),
                    const Gap(10),
                    _StatusChip(status: status),
                  ],
                ),
                if (info.isNotEmpty) ...[
                  const Gap(6),
                  Text(
                    info.join('  |  '),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 12, color: Color(0xFF4A6785)),
                  ),
                ],
              ],
            ),
          ),
          PopupMenuButton<_MenuAction>(
            padding: EdgeInsets.zero,
            icon: const Icon(Icons.more_vert, color: AppColors.muted, size: 20),
            onSelected: (a) {
              switch (a) {
                case _MenuAction.edit:
                  onEdit();
                case _MenuAction.toggle:
                  onToggle(!isActive);
                case _MenuAction.outOfStock:
                  onOutOfStock();
                case _MenuAction.delete:
                  onDelete();
              }
            },
            itemBuilder: (_) => [
              const PopupMenuItem(value: _MenuAction.edit, child: Text('Edit')),
              PopupMenuItem(
                value: _MenuAction.toggle,
                child: Text(isActive ? 'Pause' : 'Activate'),
              ),
              if (status != ListingStatus.outOfStock)
                const PopupMenuItem(
                  value: _MenuAction.outOfStock,
                  child: Text('Mark out of stock'),
                ),
              const PopupMenuItem(value: _MenuAction.delete, child: Text('Delete')),
            ],
          ),
        ],
      ),
    );
  }

  String _fmt(double v) => v == v.roundToDouble() ? v.toInt().toString() : v.toStringAsFixed(2);
}

class _StatusChip extends StatelessWidget {
  final ListingStatus status;
  const _StatusChip({required this.status});

  @override
  Widget build(BuildContext context) {
    late final String label;
    late final Color fg;
    late final Color bg;
    switch (status) {
      case ListingStatus.active:
        label = 'Active';
        fg = AppColors.green;
        bg = const Color(0xFFE8F5EE);
      case ListingStatus.paused:
        label = 'Paused';
        fg = const Color(0xFFB45309);
        bg = const Color(0xFFFEF3C7);
      case ListingStatus.outOfStock:
        label = 'Out of Stock';
        fg = const Color(0xFFB91C1C);
        bg = const Color(0xFFFEE2E2);
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
      child: Text(
        label,
        style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: fg),
      ),
    );
  }
}

class _Thumb extends StatelessWidget {
  final String? url;
  final ListingType type;
  const _Thumb({required this.url, required this.type});

  @override
  Widget build(BuildContext context) {
    final fallback = Container(
      width: 76,
      height: 76,
      color: const Color(0xFFF1F3F6),
      child: Icon(
        type == ListingType.product ? Icons.shopping_basket_outlined : Icons.handyman_outlined,
        color: AppColors.muted,
      ),
    );
    if (url == null || url!.isEmpty) return fallback;
    return Image.network(
      url!,
      width: 76,
      height: 76,
      fit: BoxFit.cover,
      errorBuilder: (_, _, _) => fallback,
    );
  }
}
