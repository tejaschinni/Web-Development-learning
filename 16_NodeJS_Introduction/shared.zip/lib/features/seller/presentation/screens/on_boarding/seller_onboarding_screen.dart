import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/resgitration_form_stepper_widget.dart';

class SellerOnboardingScreen extends ConsumerStatefulWidget {
  final bool? isEdit;
  const SellerOnboardingScreen({super.key, this.isEdit = false});

  @override
  ConsumerState<ConsumerStatefulWidget> createState() => _SellerOnboardingScreenState();
}

class _SellerOnboardingScreenState extends ConsumerState<SellerOnboardingScreen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() => ref.invalidate(mySellerProfileProvider));
  }

  @override
  Widget build(BuildContext context) {
    final sellerAsync = ref.watch(mySellerProfileProvider);
    final isEditMode = widget.isEdit == true;

    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        elevation: 0,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              isEditMode ? 'Update Seller Profile' : 'Seller Registration',
              style: AppTheme.hind(c: Colors.black87, 17, w: FontWeight.w700),
            ),
            Text(
              isEditMode
                  ? 'Update your business details, address and availability'
                  : 'Create your seller account to list food and\nArt & Creative products or services',
              style: AppTheme.hind(c: AppColors.muted, 10.5),
            ),
          ],
        ),
        toolbarHeight: 64,
      ),
      body: sellerAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => ResgitrationFormStepperWidget(initial: null, isEdit: isEditMode),
        data: (seller) => seller == null
            ? ResgitrationFormStepperWidget(initial: null, isEdit: isEditMode)
            : ResgitrationFormStepperWidget(initial: seller, isEdit: isEditMode),
      ),
    );
  }
}

