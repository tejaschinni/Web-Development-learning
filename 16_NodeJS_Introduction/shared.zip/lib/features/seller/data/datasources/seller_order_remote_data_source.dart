import 'dart:convert';
import 'dart:developer';

import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/seller/data/models/order_status_history_model.dart';
import 'package:society_seva/features/seller/data/models/seller_order_model.dart';

abstract class SellerOrderRemoteDataSource {
  Future<PageResponse<SellerOrderModel>> fetchSellerOrdersDataSource({required String sellerId});

  Future<SellerOrderModel> transitionOrderDataSource({
    required String orderId,
    required String newStatus,
    String? note,
  });

  Future<String> fetchBuyerIdDataSource({required String buyerId});
  Future<List<OrderStatusHistoryModel>> fetchOrderStatusHistoryDataSource({
    required String orderID,
  });
}

class SellerOrderRemoteDataSourceImpl implements SellerOrderRemoteDataSource {
  SellerOrderRemoteDataSourceImpl(this._apiClient);

  // ignore: unused_field
  final ApiClient _apiClient;

  static const _mockOrdersJson = {
    "content": [
      {
        "id": "3a73a114-04fd-4d1b-b7f0-0b135e09dd3f",
        "orderNumber": "ORD-20261016-V6W81S",
        "buyerId": "d5029c8d-fe2d-4012-a296-26b7d5ef5177",
        "sellerId": "a5077570-6bf6-4879-9753-478949dd5876",
        "orderType": "PRODUCT_ORDER",
        "orderStatus": "CREATED",
        "subtotalAmount": 1200.0,
        "discountAmount": 0.0,
        "platformCommission": 120.0,
        "welfareFundAmount": 60.0,
        "sellerEarning": 1020.0,
        "totalAmount": 1200.0,
        "paymentStatus": "PENDING",
        "items": [
          {
            "id": "78969f1d-022e-4123-b62c-c1b430ef5b7b",
            "listingId": "c4b6cb03-683c-4c55-b9ea-c656a430ec33",
            "titleSnapshot": "Basmati Rice",
            "quantity": 10,
            "unitPrice": 120.0,
            "totalPrice": 1200.0
          }
        ],
        "createdAt": "2026-10-16T09:09:31.460080Z"
      }
    ],
    "empty": false,
    "first": true,
    "last": true,
    "number": 0,
    "numberOfElements": 1,
    "pageable": {
      "offset": 0,
      "pageNumber": 0,
      "pageSize": 20,
      "paged": true,
      "sort": {"empty": true, "sorted": false, "unsorted": true},
      "unpaged": false
    },
    "size": 20,
    "sort": {"empty": true, "sorted": false, "unsorted": true},
    "totalElements": 1,
    "totalPages": 1
  };

  static const _mockHistoryJson = [
    {
      "changedBy": "d5029c8d-fe2d-4012-a296-26b7d5ef5177",
      "createdAt": "2026-10-19T06:59:05.131818Z",
      "id": "55657a25-e2d3-4153-8321-3aba762f6170",
      "newStatus": "CREATED",
      "note": "Order created from cart",
      "orderId": "1dfa2464-d786-4b15-99da-0b6f79bf4e2d"
    },
    {
      "changedBy": "d5029c8d-fe2d-4012-a296-26b7d5ef5177",
      "createdAt": "2026-10-19T07:27:38.973392Z",
      "id": "811cb831-1433-4164-b37c-d4f238f8a173",
      "newStatus": "PAYMENT_PENDING",
      "note": "Payment initiated",
      "oldStatus": "CREATED",
      "orderId": "1dfa2464-d786-4b15-99da-0b6f79bf4e2d"
    },
    {
      "createdAt": "2026-10-19T07:29:34.686032Z",
      "id": "d82a498a-1da5-491b-a0bd-0934fe923608",
      "newStatus": "PAID",
      "note": "Payment successful",
      "oldStatus": "PAYMENT_PENDING",
      "orderId": "1dfa2464-d786-4b15-99da-0b6f79bf4e2d"
    }
  ];

  @override
  Future<PageResponse<SellerOrderModel>> fetchSellerOrdersDataSource({
    required String sellerId,
  }) async {
    log('[OFFLINE] GET ${ApiEndpoints.orders}?sellerId=$sellerId');
    return PageResponse.fromJson(
      Map<String, dynamic>.from(_mockOrdersJson),
      SellerOrderModel.fromJson,
    );
  }

  @override
  Future<SellerOrderModel> transitionOrderDataSource({
    required String orderId,
    required String newStatus,
    String? note,
  }) async {
    final params = <String, dynamic>{
      'newStatus': newStatus,
      if (note != null && note.isNotEmpty) 'note': note,
    };
    print('[OFFLINE] POST ${ApiEndpoints.orderTransition(orderId)} params: ${jsonEncode(params)}');
    log('[OFFLINE] POST ${ApiEndpoints.orderTransition(orderId)} params: ${jsonEncode(params)}');

    final baseOrder = SellerOrderModel.fromJson(
      Map<String, dynamic>.from((_mockOrdersJson['content'] as List)[0] as Map),
    );

    return SellerOrderModel(
      id: orderId,
      orderNumber: baseOrder.orderNumber,
      buyerId: baseOrder.buyerId,
      sellerId: baseOrder.sellerId,
      orderType: baseOrder.orderType,
      orderStatus: newStatus,
      subtotalAmount: baseOrder.subtotalAmount,
      discountAmount: baseOrder.discountAmount,
      platformCommission: baseOrder.platformCommission,
      welfareFundAmount: baseOrder.welfareFundAmount,
      sellerEarning: baseOrder.sellerEarning,
      totalAmount: baseOrder.totalAmount,
      paymentStatus: 'PAID',
      items: baseOrder.items,
      createdAt: baseOrder.createdAt,
    );
  }

  @override
  Future<String> fetchBuyerIdDataSource({required String buyerId}) async {
    log('[OFFLINE] GET ${ApiEndpoints.fetchBuyerNameFromID(buyerId)}');
    return 'Rajesh Sharma';
  }

  @override
  Future<List<OrderStatusHistoryModel>> fetchOrderStatusHistoryDataSource({
    required String orderID,
  }) async {
    log('[OFFLINE] GET ${ApiEndpoints.orderStatusHistory(orderID)}');
    return _mockHistoryJson.map(OrderStatusHistoryModel.fromJson).toList();
  }
}
