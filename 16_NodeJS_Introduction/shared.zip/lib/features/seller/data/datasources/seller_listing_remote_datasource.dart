import 'dart:convert';
import 'dart:developer';
import 'package:image_picker/image_picker.dart';
import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/seller/data/models/food_detail_model.dart';
import 'package:society_seva/features/seller/data/models/request/food_additional_information_request.dart';
import 'package:society_seva/features/seller/data/models/request/seller_listing_basic_info_request.dart';
import 'package:society_seva/features/seller/data/models/request/service_additional_information_request.dart';
import 'package:society_seva/features/seller/data/models/seller_listing_image_model.dart';
import 'package:society_seva/features/seller/data/models/seller_listing_model.dart';
import 'package:society_seva/features/seller/data/models/service_detail_model.dart';
import 'package:society_seva/features/seller/data/models/service_slot_model.dart';

abstract class SellerListingRemoteDatasource {
  Future<PageResponse<SellerListingModel>> fetchMyListingDataSource({required String sellerId});

  Future<SellerListingModel> fetchListingByIdDataSource({required String listingID});

  Future<List<SellerListingImageModel>> getListingImagesDataSource(String listingId);

  Future<SellerListingModel?> createListingDataSource({
    required SellerListingBasicInfoRequest request,
  });

  Future<SellerListingModel?> submitListingDataSource({required String listingId});

  Future<SellerListingModel?> updateSubmitListingDataSource({
    required String listingId,
    required SellerListingBasicInfoRequest request,
  });

  Future<SellerListingImageModel> uploadSellerShopImagesDataSource(String sellerId, XFile file);

  Future<bool> additionalFoodInformationDataSource({
    required FoodAdditionalInformationRequest request,
    required String listingId,
  });

  Future<bool> additionalServiceInformationDataSource({
    required ServiceAdditionalInformationRequest request,
    required String listingId,
  });

  Future<FoodListingDetailsModel?> updateAdditionalFoodInformationDataSource({
    required FoodAdditionalInformationRequest request,
    required String listingId,
  });

  Future<ServiceListingDetailsModel?> updateAdditionalServiceInformationDataSource({
    required ServiceAdditionalInformationRequest request,
    required String listingId,
  });

  Future<FoodListingDetailsModel> fetchAdditionalFoodInformationDataSource({
    required String listingId,
  });

  Future<ServiceListingDetailsModel> fetchAdditionalServiceInformationDataSource({
    required String listingId,
  });

  Future<List<ServiceSlotModel>> saveServiceSlotsDataSource({
    required String listingId,
    required String date,
    required List<Map<String, String>> windows,
  });

  Future<List<DateTime>> fetchServiceAvailableDatesDataSource({
    required String listingId,
    required String fromDate,
    required String toDate,
  });
  Future<List<ServiceSlotModel>> getServiceAvailableSlotsDataSource({
    required String listingId,
    required String date,
  });
  Future<void> deleteServiceSlotsDataSource({required String listingId, required String date});

  Future<void> deleteListingImageDataSource({required String listingId, required String imageId});
}

class SellerListingRemoteDataSourceImpl implements SellerListingRemoteDatasource {
  SellerListingRemoteDataSourceImpl(this._apiClient);
  // ignore: unused_field
  final ApiClient _apiClient;

  static const _mockMyListingsJson = {
    "content": [
      {
        "id": "e3cabf71-a385-46a7-b26a-c8ad4f885445",
        "sellerId": "79f2900f-4da3-4342-b638-e19d4a57ff8f",
        "categoryId": "377ecc8c-7405-45c1-b935-c7c160481cac",
        "additionalCategoryIds": [],
        "listingType": "FOOD",
        "title": "Kanda Pohe",
        "description": "Freshly homemade kanda pohe with nuts",
        "basePrice": 45.0,
        "isFree": false,
        "quantityAvailable": "6",
        "availabilityStatus": "AVAILABLE",
        "approvalStatus": "DRAFT",
        "moderationStatus": "PENDING",
        "sponsoredStatus": "NOT_SPONSORED",
        "averageRating": 0.0,
        "totalReviews": 0,
        "tagNames": ["breakfast", "pohe", "poha", "nashta"],
        "createdAt": "2026-10-15T11:43:01.790602Z"
      }
    ],
    "empty": false,
    "first": true,
    "last": true,
    "number": 0,
    "numberOfElements": 1,
    "pageable": {
      "offset": 0,
      "pageNumber": 0,
      "pageSize": 20,
      "paged": true,
      "sort": {"empty": true, "sorted": false, "unsorted": true},
      "unpaged": false
    },
    "size": 20,
    "sort": {"empty": true, "sorted": false, "unsorted": true},
    "totalElements": 1,
    "totalPages": 1
  };

  static const _mockListingByIdJson = {
    "id": "c8099e5b-a354-4e38-8c67-609d2045a60d",
    "sellerId": "087a6434-d6e3-4c58-acec-c1638d8e9bfd",
    "categoryId": "377ecc8c-7405-45c1-b935-c7c160481cac",
    "additionalCategoryIds": [],
    "listingType": "FOOD",
    "title": "Kanda Pohe",
    "description": "Freshly homemade kanda pohe with nuts",
    "basePrice": 45.0,
    "isFree": false,
    "quantityAvailable": "5",
    "availabilityStatus": "AVAILABLE",
    "approvalStatus": "APPROVED",
    "moderationStatus": "PENDING",
    "sponsoredStatus": "NOT_SPONSORED",
    "averageRating": 0.0,
    "totalReviews": 0,
    "tagNames": ["breakfast", "pohe", "poha", "nashta"],
    "createdAt": "2026-10-13T10:52:25.512065Z",
    "updatedAt": "2026-10-15T13:59:49.502763Z"
  };

  static const _mockCreatedListingJson = {
    "id": "c8099e5b-a354-4e38-8c67-609d2045a60d",
    "sellerId": "087a6434-d6e3-4c58-acec-c1638d8e9bfd",
    "categoryId": "377ecc8c-7405-45c1-b935-c7c160481cac",
    "additionalCategoryIds": [],
    "listingType": "FOOD",
    "title": "Kanda Pohe",
    "description": "Freshly homemade kanda pohe with nuts",
    "basePrice": 45.0,
    "isFree": false,
    "quantityAvailable": "6",
    "availabilityStatus": "AVAILABLE",
    "approvalStatus": "DRAFT",
    "moderationStatus": "PENDING",
    "sponsoredStatus": "NOT_SPONSORED",
    "averageRating": 0.0,
    "totalReviews": 0,
    "tagNames": ["breakfast", "pohe", "poha", "nashta"],
    "createdAt": "2026-10-13T10:52:25.512065Z"
  };

  static const _mockSubmittedListingJson = {
    "id": "c4b6cb03-683c-4c55-b9ea-c656a430ec33",
    "sellerId": "a5077570-6bf6-4879-9753-478949dd5876",
    "categoryId": "138e46e8-cece-4212-ab4c-4d7102a530f5",
    "additionalCategoryIds": ["1365c716-6b84-4bc1-bd6e-d2e71cf049a1"],
    "listingType": "GROCERY",
    "title": "Basmati Rice",
    "description": "Raw Basmati Rice",
    "basePrice": 120.0,
    "priceUnit": "KG",
    "isFree": false,
    "quantityAvailable": "100",
    "availabilityStatus": "AVAILABLE",
    "approvalStatus": "SUBMITTED",
    "moderationStatus": "PENDING",
    "sponsoredStatus": "NOT_SPONSORED",
    "averageRating": 0.0,
    "totalReviews": 0,
    "tagNames": ["rice", "basmati", "chawal", "bhat"],
    "createdAt": "2026-10-16T08:38:12.536537Z",
    "updatedAt": "2026-10-16T08:40:17.953191Z"
  };

  static const _mockUpdatedListingJson = {
    "id": "5baf6f40-ac30-4822-8871-118e7d181e9e",
    "sellerId": "e4a25158-0ff2-4ed2-8cd7-f70c8f98362a",
    "societyId": "25044e48-02a8-45fd-a03e-066ee6d87263",
    "categoryId": "377ecc8c-7405-45c1-b935-c7c160481cac",
    "additionalCategoryIds": [],
    "listingType": "FOOD",
    "title": "Pohe",
    "description": "Homemade pohe",
    "basePrice": 50.0,
    "isFree": false,
    "quantityAvailable": "2",
    "availabilityStatus": "AVAILABLE",
    "approvalStatus": "SUBMITTED",
    "moderationStatus": "PENDING",
    "sponsoredStatus": "NOT_SPONSORED",
    "averageRating": 0.0,
    "totalReviews": 0,
    "tagNames": [],
    "createdAt": "2026-09-04T06:23:58.491876Z",
    "updatedAt": "2026-09-04T09:44:29.763309Z"
  };

  static const _mockFoodDetailsJson = {
    "id": "a074b48b-7fb8-4c5d-9875-f1a92b6540e1",
    "listingId": "c8099e5b-a354-4e38-8c67-609d2045a60d",
    "preparationTime": "1970-01-01T00:00:20Z",
    "spiceLevel": 3,
    "spiceLevelText": "MEDIUM",
    "freshnessDeclaration": "fresh",
    "isFrozenItem": false,
    "fssaiRequired": true,
    "servingSizes": [
      {
        "id": "5803066e-63a0-4d4f-bb34-8b735c464eba",
        "sizeValue": 1,
        "sizeUnit": "Plate",
        "description": "Half Plate",
        "price": 35,
        "quantityAvailable": 4,
        "isAvailable": true
      },
      {
        "id": "21ee87cf-0c6c-4f7e-9a78-6585e97f5ba9",
        "sizeValue": 2,
        "sizeUnit": "Plate",
        "description": "Full Plate",
        "price": 55,
        "quantityAvailable": 6,
        "isAvailable": true
      },
      {
        "id": "5d767518-ed97-45c3-9775-c214e0ef7d11",
        "sizeValue": 1,
        "sizeUnit": "KG",
        "description": "1 KG Pohe",
        "price": 850,
        "quantityAvailable": 0,
        "isAvailable": false
      }
    ]
  };

  static const _mockUpdatedFoodDetailsJson = {
    "id": "5bac0404-ab68-4a6d-832a-c1d101c5cca2",
    "listingId": "5baf6f40-ac30-4822-8871-118e7d181e9e",
    "preparationTime": "1970-01-01T00:00:10Z",
    "spiceLevel": 1,
    "spiceLevelText": "MEDIUM",
    "freshnessDeclaration": "fresh",
    "isFrozenItem": false,
    "fssaiRequired": false,
    "servingSizes": [
      {
        "id": "269cd909-3608-4f8b-818b-ef5620e525ad",
        "sizeValue": 1,
        "sizeUnit": "Plate",
        "description": "Half Plate",
        "price": 25,
        "quantityAvailable": 4,
        "isAvailable": true
      },
      {
        "id": "06c01f7a-68f3-4e83-b036-24f28d6aa675",
        "sizeValue": 2,
        "sizeUnit": "Plate",
        "description": "Full Plate",
        "price": 50,
        "quantityAvailable": 5,
        "isAvailable": true
      }
    ]
  };

  static const _mockServiceDetailsJson = {
    "id": "833e5b98-89f6-47d5-9534-d413c7b9c916",
    "listingId": "9b05a332-e24f-4a55-aa6c-a80b57a067d7",
    "serviceDurationMinutes": 90,
    "serviceLocationType": "COMMON_AREA",
    "homeVisitAvailable": true,
    "onlineAvailable": false,
    "certificateRequired": false
  };

  static const _mockListingImagesJson = [
    {
      "id": "53894873-cae9-40e6-95e7-2e1961532799",
      "listingId": "5baf6f40-ac30-4822-8871-118e7d181e9e",
      "imageUrl":
          "http://192.168.1.42:8080/society_rest/api/v1/listings/5baf6f40-ac30-4822-8871-118e7d181e9e/images/1788503779179-1ba9d479-b576-469d-8e60-15ff1263ce9f-luffy-zoro-a9fjxt06uboi7x3l_copy.png",
      "moderationStatus": "APPROVED",
      "displayOrder": 1,
      "createdAt": "2026-09-04T06:36:19.187784Z"
    },
    {
      "id": "02022d55-f4ee-47a7-9bee-c7496273a0ae",
      "listingId": "5baf6f40-ac30-4822-8871-118e7d181e9e",
      "imageUrl":
          "http://192.168.1.42:8080/society_rest/api/v1/listings/5baf6f40-ac30-4822-8871-118e7d181e9e/images/1790852633021-3d7ee645-f9ad-4551-96fe-7f9c6aacd910-luffy-zoro-a9fjxt06uboi7x3l_copy.png",
      "moderationStatus": "PENDING",
      "displayOrder": 1,
      "createdAt": "2026-10-01T11:03:53.059865Z"
    }
  ];

  static const _mockServiceSlotsJson = [
    {
      "startsAt": "2026-10-19T10:00:00",
      "endsAt": "2026-10-19T11:30:00",
      "durationMinutes": 90,
      "timeZone": "Asia/Kolkata",
      "status": "AVAILABLE"
    },
    {
      "startsAt": "2026-10-19T12:00:00",
      "endsAt": "2026-10-19T13:30:00",
      "durationMinutes": 90,
      "timeZone": "Asia/Kolkata",
      "status": "AVAILABLE"
    },
    {
      "startsAt": "2026-10-19T14:00:00",
      "endsAt": "2026-10-19T15:30:00",
      "durationMinutes": 90,
      "timeZone": "Asia/Kolkata",
      "status": "AVAILABLE"
    },
    {
      "startsAt": "2026-10-19T16:00:00",
      "endsAt": "2026-10-19T17:30:00",
      "durationMinutes": 90,
      "timeZone": "Asia/Kolkata",
      "status": "AVAILABLE"
    }
  ];

  static const _mockAvailableDatesJson = [
    "2026-10-22",
    "2026-10-23",
    "2026-10-24",
    "2026-10-25",
    "2026-10-26",
    "2026-10-28",
    "2026-10-29",
    "2026-10-30"
  ];

  @override
  Future<PageResponse<SellerListingModel>> fetchMyListingDataSource({
    required String sellerId,
  }) async {
    log('[OFFLINE] GET ${ApiEndpoints.myListing}?sellerId=$sellerId');
    return PageResponse.fromJson(
      Map<String, dynamic>.from(_mockMyListingsJson),
      SellerListingModel.fromJson,
    );
  }

  @override
  Future<List<SellerListingImageModel>> getListingImagesDataSource(String listingId) async {
    log('[OFFLINE] GET ${ApiEndpoints.listingImages(listingId)}');
    return _mockListingImagesJson
        .map((img) => SellerListingImageModel.fromJson(Map<String, dynamic>.from(img)))
        .toList()
      ..sort((a, b) => a.displayOrder.compareTo(b.displayOrder));
  }

  @override
  Future<SellerListingModel?> createListingDataSource({
    required SellerListingBasicInfoRequest request,
  }) async {
    final payload = request.toJson();
    print('[OFFLINE] POST ${ApiEndpoints.listings} payload: ${jsonEncode(payload)}');
    log('[OFFLINE] POST ${ApiEndpoints.listings} payload: ${jsonEncode(payload)}');

    return SellerListingModel.fromJson({
      ..._mockCreatedListingJson,
      if (request.sellerId != null) 'sellerId': request.sellerId,
      if (request.categoryId != null) 'categoryId': request.categoryId,
      if (request.listingType != null) 'listingType': request.listingType,
      if (request.title != null) 'title': request.title,
      if (request.description != null) 'description': request.description,
      if (request.basePrice != null) 'basePrice': request.basePrice,
      if (request.isFree != null) 'isFree': request.isFree,
      if (request.quantityAvailable != null) 'quantityAvailable': request.quantityAvailable.toString(),
      if (request.tagNames != null) 'tagNames': request.tagNames,
    });
  }

  @override
  Future<SellerListingImageModel> uploadSellerShopImagesDataSource(
    String listingId,
    XFile file,
  ) async {
    print('[OFFLINE] POST ${ApiEndpoints.listingImages(listingId)} file: ${file.path} (${file.name})');
    log('[OFFLINE] POST ${ApiEndpoints.listingImages(listingId)} file: ${file.path} (${file.name})');

    return SellerListingImageModel(
      id: "53894873-cae9-40e6-95e7-2e1961532799",
      listingId: listingId,
      imageUrl:
          "5baf6f40-ac30-4822-8871-118e7d181e9e/1788503779179-1ba9d479-b576-469d-8e60-15ff1263ce9f-luffy-zoro-a9fjxt06uboi7x3l_copy.png",
      moderationStatus: "PENDING",
      displayOrder: 1,
      createdAt: DateTime.now(),
    );
  }

  @override
  Future<bool> additionalFoodInformationDataSource({
    required FoodAdditionalInformationRequest request,
    required String listingId,
  }) async {
    final payload = request.toJson();
    print('[OFFLINE] POST ${ApiEndpoints.listingFoodDetails(listingId)} payload: ${jsonEncode(payload)}');
    log('[OFFLINE] POST ${ApiEndpoints.listingFoodDetails(listingId)} payload: ${jsonEncode(payload)}');
    return true;
  }

  @override
  Future<bool> additionalServiceInformationDataSource({
    required ServiceAdditionalInformationRequest request,
    required String listingId,
  }) async {
    final payload = request.toJson();
    print('[OFFLINE] POST ${ApiEndpoints.listingServiceDetails(listingId)} payload: ${jsonEncode(payload)}');
    log('[OFFLINE] POST ${ApiEndpoints.listingServiceDetails(listingId)} payload: ${jsonEncode(payload)}');
    return true;
  }

  @override
  Future<SellerListingModel?> submitListingDataSource({required String listingId}) async {
    print('[OFFLINE] POST ${ApiEndpoints.submitListings(listingId)}');
    log('[OFFLINE] POST ${ApiEndpoints.submitListings(listingId)}');
    return SellerListingModel.fromJson({
      ..._mockSubmittedListingJson,
      'id': listingId,
    });
  }

  @override
  Future<SellerListingModel?> updateSubmitListingDataSource({
    required String listingId,
    required SellerListingBasicInfoRequest request,
  }) async {
    final payload = request.toJson();
    print('[OFFLINE] PATCH ${ApiEndpoints.listing(listingId)} payload: ${jsonEncode(payload)}');
    log('[OFFLINE] PATCH ${ApiEndpoints.listing(listingId)} payload: ${jsonEncode(payload)}');

    return SellerListingModel.fromJson({
      ..._mockUpdatedListingJson,
      'id': listingId,
      if (request.title != null) 'title': request.title,
      if (request.description != null) 'description': request.description,
      if (request.basePrice != null) 'basePrice': request.basePrice,
      if (request.quantityAvailable != null) 'quantityAvailable': request.quantityAvailable.toString(),
    });
  }

  @override
  Future<SellerListingModel> fetchListingByIdDataSource({required String listingID}) async {
    log('[OFFLINE] GET ${ApiEndpoints.listing(listingID)}');
    return SellerListingModel.fromJson({
      ..._mockListingByIdJson,
      'id': listingID,
    });
  }

  @override
  Future<FoodListingDetailsModel> fetchAdditionalFoodInformationDataSource({
    required String listingId,
  }) async {
    log('[OFFLINE] GET ${ApiEndpoints.listingFoodDetails(listingId)}');
    return FoodListingDetailsModel.fromJson({
      ..._mockFoodDetailsJson,
      'listingId': listingId,
    });
  }

  @override
  Future<ServiceListingDetailsModel> fetchAdditionalServiceInformationDataSource({
    required String listingId,
  }) async {
    log('[OFFLINE] GET ${ApiEndpoints.listingServiceDetails(listingId)}');
    return ServiceListingDetailsModel.fromJson({
      ..._mockServiceDetailsJson,
      'listingId': listingId,
    });
  }

  @override
  Future<FoodListingDetailsModel?> updateAdditionalFoodInformationDataSource({
    required FoodAdditionalInformationRequest request,
    required String listingId,
  }) async {
    final payload = request.toJson();
    print('[OFFLINE] PATCH ${ApiEndpoints.listingFoodDetails(listingId)} payload: ${jsonEncode(payload)}');
    log('[OFFLINE] PATCH ${ApiEndpoints.listingFoodDetails(listingId)} payload: ${jsonEncode(payload)}');

    return FoodListingDetailsModel.fromJson({
      ..._mockUpdatedFoodDetailsJson,
      'listingId': listingId,
    });
  }

  @override
  Future<ServiceListingDetailsModel?> updateAdditionalServiceInformationDataSource({
    required ServiceAdditionalInformationRequest request,
    required String listingId,
  }) async {
    final payload = request.toJson();
    print('[OFFLINE] PATCH ${ApiEndpoints.listingServiceDetails(listingId)} payload: ${jsonEncode(payload)}');
    log('[OFFLINE] PATCH ${ApiEndpoints.listingServiceDetails(listingId)} payload: ${jsonEncode(payload)}');

    return ServiceListingDetailsModel.fromJson({
      ..._mockServiceDetailsJson,
      'listingId': listingId,
    });
  }

  @override
  Future<List<ServiceSlotModel>> saveServiceSlotsDataSource({
    required String listingId,
    required String date,
    required List<Map<String, String>> windows,
  }) async {
    final endpoint = ApiEndpoints.serviceAvailability(listingId, date);
    final payload = {'windows': windows};
    print('[OFFLINE] PUT $endpoint payload: ${jsonEncode(payload)}');
    log('[OFFLINE] PUT $endpoint payload: ${jsonEncode(payload)}');

    return _mockServiceSlotsJson
        .map((item) => ServiceSlotModel.fromJson(Map<String, dynamic>.from(item)))
        .toList();
  }

  @override
  Future<void> deleteServiceSlotsDataSource({
    required String listingId,
    required String date,
  }) async {
    final endpoint = ApiEndpoints.serviceAvailability(listingId, date);
    print('[OFFLINE] DELETE $endpoint');
    log('[OFFLINE] DELETE $endpoint');
  }

  @override
  Future<void> deleteListingImageDataSource({
    required String listingId,
    required String imageId,
  }) async {
    final endpoint = ApiEndpoints.listingImageById(listingId, imageId);
    print('[OFFLINE] DELETE $endpoint');
    log('[OFFLINE] DELETE $endpoint');
  }

  @override
  Future<List<ServiceSlotModel>> getServiceAvailableSlotsDataSource({
    required String listingId,
    required String date,
  }) async {
    log('[OFFLINE] GET ${ApiEndpoints.serviceScheduleSlots(listingId)}?date=$date');
    return _mockServiceSlotsJson
        .map((slot) => ServiceSlotModel.fromJson(Map<String, dynamic>.from(slot)))
        .where((slot) => slot.isAvailable)
        .toList()
      ..sort((first, second) => first.startsAt.compareTo(second.startsAt));
  }

  @override
  Future<List<DateTime>> fetchServiceAvailableDatesDataSource({
    required String listingId,
    required String fromDate,
    required String toDate,
  }) async {
    log('[OFFLINE] GET ${ApiEndpoints.serviceScheduleDates(listingId)}?from=$fromDate&to=$toDate');
    return _mockAvailableDatesJson
        .map(DateTime.tryParse)
        .whereType<DateTime>()
        .map((date) => DateTime(date.year, date.month, date.day))
        .toList();
  }
}
