import 'dart:developer';

import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/seller/data/models/seller_category_model.dart';
import 'package:society_seva/features/shop/data/models/shop_category_model.dart';

abstract class SellerCategoryRemoteDatasource {
  Future<PageResponse<CategoriesModel>> fetchCategoriesDataSource({
    String? categoryType,
    String? parentCategoryId,
    bool? rootsOnly,
    String? search,
  });

  Future<List<ShopCategoryModel>> fetchCategoriesTreeDataSource({String? categoryType});
}

class SellerCategoryRemoteDatasourceImpl implements SellerCategoryRemoteDatasource {
  SellerCategoryRemoteDatasourceImpl(this._apiClient);
  // ignore: unused_field
  final ApiClient _apiClient;

  static const _mockCategoriesJson = {
    "content": [
      {
        "id": "377ecc8c-7405-45c1-b935-c7c160481cac",
        "name": "Breakfast",
        "slug": "breakfast",
        "categoryType": "FOOD",
        "requiresCertificate": false,
        "isActive": true,
        "displayOrder": 0,
        "createdAt": "2026-08-28T09:30:10.887686Z",
        "updatedAt": "2026-08-28T09:30:10.887686Z"
      },
      {
        "id": "df53b2c6-5171-488b-9855-5f87b06cbfd6",
        "name": "Cake",
        "slug": "cake",
        "categoryType": "FOOD",
        "requiresCertificate": false,
        "isActive": true,
        "displayOrder": 1,
        "createdAt": "2026-09-28T10:19:31.733588Z",
        "updatedAt": "2026-09-28T10:19:31.733588Z"
      },
      {
        "id": "c47a9601-d2e8-4d12-a8f5-8b58d58a7fa6",
        "name": "Dietician",
        "slug": "dietician",
        "categoryType": "CONSULTANCY",
        "requiresCertificate": false,
        "isActive": true,
        "displayOrder": 1,
        "createdAt": "2026-09-28T10:16:21.505182Z",
        "updatedAt": "2026-09-28T10:16:21.505182Z"
      },
      {
        "id": "7f35bf85-2fc2-4884-a5f9-8ded5cbfc251",
        "name": "Dinner",
        "slug": "dinner",
        "categoryType": "FOOD",
        "requiresCertificate": false,
        "isActive": true,
        "displayOrder": 1,
        "createdAt": "2026-09-28T10:19:25.968927Z",
        "updatedAt": "2026-09-28T10:19:25.968927Z"
      },
      {
        "id": "c90428e0-ccbe-4d4c-b335-72a4c75592ae",
        "name": "Electrician",
        "slug": "electrician",
        "categoryType": "SERVICE",
        "requiresCertificate": false,
        "isActive": true,
        "displayOrder": 1,
        "createdAt": "2026-09-23T12:24:19.947572Z",
        "updatedAt": "2026-09-28T10:23:55.835955Z"
      },
      {
        "id": "e2ac149e-9fdc-4898-8247-7956700833cf",
        "name": "Fitness Trainer",
        "slug": "fitness-trainer",
        "categoryType": "CONSULTANCY",
        "requiresCertificate": false,
        "isActive": true,
        "displayOrder": 1,
        "createdAt": "2026-09-28T10:16:39.968138Z",
        "updatedAt": "2026-09-28T10:16:39.968138Z"
      },
      {
        "id": "08d24e05-49cb-4f9e-bba5-6963fa6925ce",
        "parentCategoryId": "c90428e0-ccbe-4d4c-b335-72a4c75592ae",
        "name": "Ran repair",
        "slug": "ran-repair",
        "categoryType": "SERVICE",
        "requiresCertificate": false,
        "isActive": true,
        "displayOrder": 1,
        "createdAt": "2026-09-23T12:28:51.966082Z",
        "updatedAt": "2026-09-23T12:28:51.966082Z"
      },
      {
        "id": "74358bb8-dbc7-455b-92e7-a1201ac2c6d7",
        "parentCategoryId": "c90428e0-ccbe-4d4c-b335-72a4c75592ae",
        "name": "Repair",
        "slug": "repair",
        "categoryType": "SERVICE",
        "requiresCertificate": false,
        "isActive": true,
        "displayOrder": 1,
        "createdAt": "2026-09-23T12:26:10.117571Z",
        "updatedAt": "2026-09-23T12:26:10.117571Z"
      },
      {
        "id": "153e2eb3-f39a-4b99-92ad-8c205ba99a43",
        "name": "Tution Classes",
        "slug": "tution-classes",
        "categoryType": "SERVICE",
        "requiresCertificate": false,
        "isActive": true,
        "displayOrder": 1,
        "createdAt": "2026-09-28T10:15:38.257769Z",
        "updatedAt": "2026-09-28T10:15:38.257769Z"
      }
    ],
    "empty": false,
    "first": true,
    "last": true,
    "number": 0,
    "numberOfElements": 9,
    "pageable": {
      "offset": 0,
      "pageNumber": 0,
      "pageSize": 20,
      "paged": true,
      "sort": {
        "empty": false,
        "sorted": true,
        "unsorted": false
      },
      "unpaged": false
    },
    "size": 20,
    "sort": {
      "empty": false,
      "sorted": true,
      "unsorted": false
    },
    "totalElements": 9,
    "totalPages": 1
  };

  static const _mockCategoriesTreeJson = [
    {
      "id": "c90428e0-ccbe-4d4c-b335-72a4c75592ae",
      "name": "Electrician",
      "slug": "electrician",
      "categoryType": "SERVICE",
      "requiresCertificate": false,
      "isActive": true,
      "displayOrder": 1,
      "subCategories": [
        {
          "id": "08d24e05-49cb-4f9e-bba5-6963fa6925ce",
          "name": "Ran repair",
          "slug": "ran-repair",
          "categoryType": "SERVICE",
          "requiresCertificate": false,
          "isActive": true,
          "displayOrder": 1,
          "subCategories": []
        },
        {
          "id": "74358bb8-dbc7-455b-92e7-a1201ac2c6d7",
          "name": "Repair",
          "slug": "repair",
          "categoryType": "SERVICE",
          "requiresCertificate": false,
          "isActive": true,
          "displayOrder": 1,
          "subCategories": []
        }
      ]
    },
    {
      "id": "153e2eb3-f39a-4b99-92ad-8c205ba99a43",
      "name": "Tution Classes",
      "slug": "tution-classes",
      "categoryType": "SERVICE",
      "requiresCertificate": false,
      "isActive": true,
      "displayOrder": 1,
      "subCategories": []
    }
  ];

  @override
  Future<PageResponse<CategoriesModel>> fetchCategoriesDataSource({
    String? categoryType,
    String? parentCategoryId,
    bool? rootsOnly,
    String? search,
  }) async {
    try {
      final response = await _apiClient.get(
        ApiEndpoints.allCategory,
        queryParameters: {
          'isActive': true,
          'categoryType': categoryType,
          'parentCategoryId': parentCategoryId,
          'rootsOnly': rootsOnly,
          'search': search,
        },
      );
      return PageResponse.fromJson(
        Map<String, dynamic>.from(response.data as Map),
        CategoriesModel.fromJson,
      );
    } catch (_) {
      log('[SellerCategoryRemoteDatasource] Offline: returning mock categories');
      final contentList = (_mockCategoriesJson['content'] as List<dynamic>)
          .map((item) => CategoriesModel.fromJson(Map<String, dynamic>.from(item as Map)))
          .where((cat) {
            if (categoryType != null && categoryType.isNotEmpty) {
              if (cat.categoryType.toUpperCase() != categoryType.toUpperCase()) return false;
            }
            if (search != null && search.isNotEmpty) {
              if (!cat.name.toLowerCase().contains(search.toLowerCase())) return false;
            }
            return true;
          })
          .toList();

      return PageResponse<CategoriesModel>(
        content: contentList,
        page: 0,
        size: 20,
        totalElements: contentList.length,
        totalPages: 1,
        first: true,
        last: true,
      );
    }
  }

  @override
  Future<List<ShopCategoryModel>> fetchCategoriesTreeDataSource({String? categoryType}) async {
    try {
      final response = await _apiClient.get(
        ApiEndpoints.categoryTree,
        queryParameters: {'isActive': true, 'categoryType': categoryType},
      );

      final data = response.data;
      if (data is List) {
        return data
            .whereType<Map>()
            .map((item) => ShopCategoryModel.fromJson(Map<String, dynamic>.from(item)))
            .toList(growable: false);
      }
    } catch (_) {
      log('[SellerCategoryRemoteDatasource] Offline: returning mock categories tree');
    }

    return _mockCategoriesTreeJson
        .map((item) => ShopCategoryModel.fromJson(Map<String, dynamic>.from(item)))
        .toList(growable: false);
  }
}
