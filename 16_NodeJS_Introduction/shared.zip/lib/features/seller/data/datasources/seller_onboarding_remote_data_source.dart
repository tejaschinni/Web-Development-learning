import 'dart:convert';
import 'dart:developer';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/features/seller/data/models/certificate_model.dart';
import 'package:society_seva/features/seller/data/models/kyc_document_model.dart';
import 'package:society_seva/features/seller/data/models/seller_availabledays_model.dart';
import 'package:society_seva/features/seller/data/models/seller_image_model.dart';
import 'package:society_seva/features/seller/data/models/seller_profile_model.dart';
import 'package:society_seva/features/seller/data/models/request/seller_profile_request.dart';

abstract class SellerOnboardingRemoteDataSource {
  Future<SellerProfileModel?> createAndSaveAsDraftDataSource({
    required SellerProfileRequest request,
  });
  Future<SellerProfileModel?> submitDartDataSource({required String sellerId});
  Future<void> uploadSellerShopImagesDataSource(String sellerId, XFile file);
  Future<List<SellerImageModel>> fetchSellerUploadedImagesDataSource(String sellerId);
  Future<SellerProfileModel?> mySellerProfileDataSource();
  Future<SellerProfileModel?> fetchSellerProfileByIDDataSource(String sellerID);
  Future<SellerProfileModel?> updateProfileDataSource({
    required SellerProfileRequest request,
    required String sellerID,
  });
  Future<void> deleteUploadedSellerImagesDataSource({
    required String sellerID,
    required String imageId,
  });

  Future<CertificateModel?> uploadCertificateDataSource({
    required String sellerId,
    required XFile file,
    required String certificateName,
    required String certificateType,
    required DateTime issueDate,
    required bool hasExpiry,
    required String issueAuthority,
    required String certificateNumber,
    DateTime? expiryDate,
  });

  Future<List<CertificateModel>> fetchCertificatesDataSource(String sellerId);

  Future<List<KycDocumentModel>> fetchKycDocumentDataSource(String sellerId);

  Future<bool> uploadKYCDocumentDataSource({
    required XFile file,
    required String documentType,
    required String documentNumber,
    required String sellerId,
  });

  Future<String> downloadKycDocumentFileDataSource({
    required String sellerId,
    required String documentFileUrl,
  });

  Future<String> downloadCertificateFileDataSource({
    required String sellerId,
    required String documentFileUrl,
  });

  Future<AvailableDaysModel> fetchSellerAvailableDaysDataSource({required String sellerID});

  Future<AvailableDaysModel> updateSellerAvailableDaysDataSource({
    required String sellerID,
    required Map<String, dynamic> data,
  });
}

class SellerOnboardingRemoteDataSourceImpl implements SellerOnboardingRemoteDataSource {
  SellerOnboardingRemoteDataSourceImpl({required ApiClient apiClient}) : _apiClient = apiClient;

  // ignore: unused_field
  final ApiClient _apiClient;

  static const _mockSellerProfileJson = {
    "id": "79f2900f-4da3-4342-b638-e19d4a57ff8f",
    "userId": "fcfa719a-e112-4ab2-876d-cdedac6da02a",
    "displayName": "Veer foods",
    "businessName": "Veer Foods & Kitchen",
    "bio": "Delicious home-cooked meals, daily tiffin and fresh bakes.",
    "sellerType": "FOOD_SELLER",
    "availabilityStatus": "AVAILABLE",
    "approvalStatus": "DRAFT",
    "fssaiStatus": "PENDING",
    "fssaiRequired": true,
    "renewalStatus": "NA",
    "totalListings": 0,
    "averageRating": 0.0,
    "rejectedOrders": 0,
    "cancelledOrders": 0,
    "totalOrders": 0,
    "totalReviews": 0,
    "address": "Warje",
    "city": "Pune",
    "state": "maharashtra",
    "country": "india",
    "pinCode": "411058",
    "createdAt": "2026-10-13T11:58:22.558144Z",
    "updatedAt": "2026-10-13T11:58:22.558144Z"
  };

  static const _mockSubmittedProfileJson = {
    "id": "6bb204d2-54d9-43c1-9ed6-2ffffb9a254b",
    "userId": "d0faea6d-01cc-4b4f-aa19-29b4a3c36d74",
    "societyId": "25044e48-02a8-45fd-a03e-066ee6d87263",
    "displayName": "Vipl Food Seller",
    "businessName": "Vipl Food Seller",
    "sellerType": "FOOD_SELLER",
    "bio": "Quality Food",
    "availabilityStatus": "BUSY",
    "approvalStatus": "SUBMITTED",
    "fssaiStatus": "PENDING",
    "fssaiRequired": true,
    "renewalStatus": "NA",
    "averageRating": 0.0,
    "rejectedOrders": 0,
    "cancelledOrders": 0,
    "totalOrders": 0,
    "totalReviews": 0,
    "createdAt": "2026-08-28T09:48:31.238903Z",
    "updatedAt": "2026-08-28T09:52:39.777111Z"
  };

  static const _mockAvailableDaysJson = {
    "sellerId": "a5077570-6bf6-4879-9753-478949dd5876",
    "daysType": "CUSTOM",
    "availableDays": ["MONDAY", "FRIDAY"],
    "fromTime": "10:00 AM",
    "toTime": "10:00 PM"
  };

  static const _mockSellerImagesJson = [
    {
      "id": "f79ceba4-ae54-4408-8056-8633f436a2fe",
      "sellerId": "6bb204d2-54d9-43c1-9ed6-2ffffb9a254b",
      "imageUrl":
          "6bb204d2-54d9-43c1-9ed6-2ffffb9a254b/images/1787911189446-c058f6ea-d0a0-41f3-8bc9-a9dbd210cc87-luffy-zoro-a9fjxt06uboi7x3l_copy.png",
      "moderationStatus": "PENDING",
      "displayOrder": 0,
      "createdAt": "2026-08-28T09:59:49.453056Z",
      "updatedAt": "2026-08-28T09:59:49.453056Z"
    }
  ];

  static const _mockKycDocumentsJson = [
    {
      "id": "ee6561b2-c9b7-4ffb-b388-03ef0558dcb8",
      "sellerId": "79f2900f-4da3-4342-b638-e19d4a57ff8f",
      "documentType": "AADHAAR",
      "documentFileUrl": "2d47e8b5-d9ed-4f78-a1ac-0d99ab8fffd8",
      "verificationStatus": "PENDING",
      "createdAt": "2026-10-15T08:58:20.101965Z",
      "updatedAt": "2026-10-15T08:58:20.101965Z"
    },
    {
      "id": "7845e760-f6a8-4d50-9999-90fa8f40d09a",
      "sellerId": "79f2900f-4da3-4342-b638-e19d4a57ff8f",
      "documentType": "PAN",
      "documentFileUrl": "af54af01-c066-4b79-820f-533447c2c907",
      "verificationStatus": "PENDING",
      "createdAt": "2026-10-15T08:55:04.860008Z",
      "updatedAt": "2026-10-15T08:55:04.860008Z"
    }
  ];

  static const _mockCertificatesJson = [
    {
      "id": "528e870f-9607-48d7-a229-a6c94b4cc427",
      "sellerId": "79f2900f-4da3-4342-b638-e19d4a57ff8f",
      "certificateType": "COOKING CLASSES CERTIFICATE",
      "certificateName": "",
      "issuingAuthority": "",
      "certificateFileUrl": "8782b102-b4b7-4f74-969a-c0b2415bc085",
      "verificationStatus": "PENDING",
      "createdAt": "2026-10-15T09:31:46.597265Z",
      "updatedAt": "2026-10-15T09:31:46.597265Z"
    }
  ];

  @override
  Future<SellerProfileModel?> createAndSaveAsDraftDataSource({
    required SellerProfileRequest request,
  }) async {
    final payload = request.toJson();
    print('[OFFLINE] POST ${ApiEndpoints.createSellerProfile} payload: ${jsonEncode(payload)}');
    log('[OFFLINE] POST ${ApiEndpoints.createSellerProfile} payload: ${jsonEncode(payload)}');

    // Return mock created profile model using payload or defaults
    return SellerProfileModel(
      id: "79f2900f-4da3-4342-b638-e19d4a57ff8f",
      userId: request.userId.isNotEmpty ? request.userId : "fcfa719a-e112-4ab2-876d-cdedac6da02a",
      societyId: request.societyId?.toString(),
      displayName: request.displayName.isNotEmpty ? request.displayName : "Veer foods",
      businessName: request.businessName,
      sellerType: request.sellerType.isNotEmpty ? request.sellerType : "FOOD_SELLER",
      bio: request.bio,
      availabilityStatus: "AVAILABLE",
      approvalStatus: "DRAFT",
      fssaiStatus: "PENDING",
      fssaiRequired: request.fssaiRequired ?? true,
      fssaiCertificateId: request.fssaiCertificateId,
      socialMediaLinks: request.socialMediaLinks,
      websiteUrl: request.websiteUrl,
      legalCompliance: request.legalCompliance,
      renewalStatus: "NA",
      totalListings: 0,
      averageRating: 0.0,
      rejectedOrders: 0,
      cancelledOrders: 0,
      totalOrders: 0,
      totalReviews: 0,
      address: request.address.isNotEmpty ? request.address : "Warje",
      city: request.city.isNotEmpty ? request.city : "Pune",
      state: request.state.isNotEmpty ? request.state : "maharashtra",
      country: request.country.isNotEmpty ? request.country : "india",
      pinCode: request.pinCode.isNotEmpty ? request.pinCode : "411058",
      latitude: request.latitude,
      longitude: request.longitude,
      geofencePolygon: request.geofencePolygon,
      deliveryRadiusKm: request.deliveryRadiusKm,
      targetArea: request.targetArea,
      createdAt: "2026-10-13T11:58:22.558144Z",
      updatedAt: "2026-10-13T11:58:22.558144Z",
    );
  }

  @override
  Future<void> deleteUploadedSellerImagesDataSource({
    required String sellerID,
    required String imageId,
  }) async {
    print('[OFFLINE] DELETE ${ApiEndpoints.deleteImages(sellerID, imageId)}');
    log('[OFFLINE] DELETE ${ApiEndpoints.deleteImages(sellerID, imageId)}');
  }

  @override
  Future<SellerProfileModel?> fetchSellerProfileByIDDataSource(String sellerID) async {
    log('[OFFLINE] GET ${ApiEndpoints.sellerByID(sellerID)}');
    return SellerProfileModel.fromJson(_mockSellerProfileJson);
  }

  @override
  Future<List<SellerImageModel>> fetchSellerUploadedImagesDataSource(String sellerId) async {
    log('[OFFLINE] GET ${ApiEndpoints.fetchSellerImages(sellerId)}');
    return _mockSellerImagesJson.map(SellerImageModel.fromJson).toList();
  }

  @override
  Future<SellerProfileModel?> mySellerProfileDataSource() async {
    log('[OFFLINE] GET ${ApiEndpoints.sellerProfile}');
    return SellerProfileModel.fromJson(_mockSellerProfileJson);
  }

  @override
  Future<SellerProfileModel?> submitDartDataSource({required String sellerId}) async {
    print('[OFFLINE] POST ${ApiEndpoints.submitSellerProfile(sellerId)} (no body)');
    log('[OFFLINE] POST ${ApiEndpoints.submitSellerProfile(sellerId)} (no body)');
    return SellerProfileModel.fromJson(_mockSubmittedProfileJson);
  }

  @override
  Future<SellerProfileModel?> updateProfileDataSource({
    required SellerProfileRequest request,
    required String sellerID,
  }) async {
    final payload = request.toJson();
    print('[OFFLINE] PATCH ${ApiEndpoints.createSellerProfile}/$sellerID payload: ${jsonEncode(payload)}');
    log('[OFFLINE] PATCH ${ApiEndpoints.createSellerProfile}/$sellerID payload: ${jsonEncode(payload)}');

    return SellerProfileModel(
      id: sellerID,
      userId: request.userId.isNotEmpty ? request.userId : "fcfa719a-e112-4ab2-876d-cdedac6da02a",
      societyId: request.societyId?.toString(),
      displayName: request.displayName.isNotEmpty ? request.displayName : "Rajesh Sharma",
      businessName: request.businessName ?? "Rajesh Home Bakers",
      sellerType: request.sellerType.isNotEmpty ? request.sellerType : "HOME_KITCHEN",
      bio: request.bio ?? "Specializing in homemade cakes, cookies, and festive desserts.",
      availabilityStatus: "AVAILABLE",
      approvalStatus: "DRAFT",
      fssaiStatus: "PENDING",
      fssaiRequired: request.fssaiRequired ?? true,
      fssaiCertificateId: request.fssaiCertificateId ?? "FSSAI12345678901",
      socialMediaLinks: request.socialMediaLinks ?? "https://instagram.com/rajeshhomebakers,https://facebook.com/rajeshhomebakers",
      websiteUrl: request.websiteUrl ?? "https://rajeshhomebakers.com",
      legalCompliance: request.legalCompliance ?? "FSSAI",
      renewalStatus: "NA",
      totalListings: 0,
      averageRating: 0.0,
      rejectedOrders: 0,
      cancelledOrders: 0,
      totalOrders: 0,
      totalReviews: 0,
      address: request.address.isNotEmpty ? request.address : "Flat 302, Green Residency, Sector 62",
      city: request.city.isNotEmpty ? request.city : "Noida",
      state: request.state.isNotEmpty ? request.state : "Uttar Pradesh",
      country: request.country.isNotEmpty ? request.country : "India",
      pinCode: request.pinCode.isNotEmpty ? request.pinCode : "201301",
      latitude: request.latitude ?? 28.6139,
      longitude: request.longitude ?? 77.2090,
      geofencePolygon: request.geofencePolygon ?? "[[28.6139,77.2090],[28.6150,77.2105],[28.6120,77.2120],[28.6105,77.2085]]",
      deliveryRadiusKm: request.deliveryRadiusKm ?? 10.5,
      targetArea: request.targetArea ?? "Noida Sector 62, Sector 63, Indirapuram",
      createdAt: "2026-10-13T11:58:22.558144Z",
      updatedAt: "2026-10-13T11:58:22.558144Z",
    );
  }

  @override
  Future<void> uploadSellerShopImagesDataSource(String sellerId, XFile file) async {
    print('[OFFLINE] POST ${ApiEndpoints.fetchSellerImages(sellerId)} file: ${file.path} (${file.name})');
    log('[OFFLINE] POST ${ApiEndpoints.fetchSellerImages(sellerId)} file: ${file.path} (${file.name})');
  }

  @override
  Future<List<CertificateModel>> fetchCertificatesDataSource(String sellerId) async {
    log('[OFFLINE] GET ${ApiEndpoints.certificate(sellerId)}');
    return _mockCertificatesJson.map(CertificateModel.fromJson).toList();
  }

  @override
  Future<CertificateModel?> uploadCertificateDataSource({
    required String sellerId,
    required XFile file,
    required String certificateName,
    required String certificateType,
    required DateTime issueDate,
    required bool hasExpiry,
    required String issueAuthority,
    required String certificateNumber,
    DateTime? expiryDate,
  }) async {
    final dateFormate = DateFormat('yyyy-MM-dd');
    final payloadLog = {
      'sellerId': sellerId,
      'certificateType': certificateType,
      'certificateName': certificateName,
      'certificateNumber': certificateNumber,
      'issuingAuthority': issueAuthority,
      'issueDate': dateFormate.format(issueDate),
      'expiryDate': hasExpiry && expiryDate != null ? dateFormate.format(expiryDate) : null,
      'filePath': file.path,
    };
    print('[OFFLINE] POST ${ApiEndpoints.certificate(sellerId)} payload: ${jsonEncode(payloadLog)}');
    log('[OFFLINE] POST ${ApiEndpoints.certificate(sellerId)} payload: ${jsonEncode(payloadLog)}');

    return CertificateModel(
      id: "528e870f-9607-48d7-a229-a6c94b4cc427",
      sellerId: sellerId,
      certificateType: certificateType,
      certificateName: certificateName,
      issuingAuthority: issueAuthority,
      certificateFileUrl: "8782b102-b4b7-4f74-969a-c0b2415bc085",
      verificationStatus: "PENDING",
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
  }

  @override
  Future<List<KycDocumentModel>> fetchKycDocumentDataSource(String sellerId) async {
    log('[OFFLINE] GET ${ApiEndpoints.fetchKycDocument(sellerId)}');
    return _mockKycDocumentsJson.map(KycDocumentModel.fromJson).toList();
  }

  @override
  Future<bool> uploadKYCDocumentDataSource({
    required XFile file,
    required String documentType,
    required String documentNumber,
    required String sellerId,
  }) async {
    final payloadLog = {
      'sellerId': sellerId,
      'documentType': documentType,
      'documentNumber': documentNumber,
      'filePath': file.path,
    };
    print('[OFFLINE] POST ${ApiEndpoints.uploadKycDocument(sellerId)} payload: ${jsonEncode(payloadLog)}');
    log('[OFFLINE] POST ${ApiEndpoints.uploadKycDocument(sellerId)} payload: ${jsonEncode(payloadLog)}');
    return true;
  }

  @override
  Future<String> downloadKycDocumentFileDataSource({
    required String sellerId,
    required String documentFileUrl,
  }) async {
    log('[OFFLINE] GET ${ApiEndpoints.kycDocumentFile(sellerId, documentFileUrl)}');
    // Return mock 1x1 transparent png base64 string
    return "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==";
  }

  @override
  Future<String> downloadCertificateFileDataSource({
    required String sellerId,
    required String documentFileUrl,
  }) async {
    log('[OFFLINE] GET ${ApiEndpoints.certificateFile(sellerId, documentFileUrl)}');
    return "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==";
  }

  @override
  Future<AvailableDaysModel> fetchSellerAvailableDaysDataSource({required String sellerID}) async {
    log('[OFFLINE] GET ${ApiEndpoints.fetchavailableDays(sellerID)}');
    return AvailableDaysModel.fromJson(_mockAvailableDaysJson);
  }

  @override
  Future<AvailableDaysModel> updateSellerAvailableDaysDataSource({
    required String sellerID,
    required Map<String, dynamic> data,
  }) async {
    print('[OFFLINE] PATCH ${ApiEndpoints.fetchavailableDays(sellerID)} payload: ${jsonEncode(data)}');
    log('[OFFLINE] PATCH ${ApiEndpoints.fetchavailableDays(sellerID)} payload: ${jsonEncode(data)}');
    return AvailableDaysModel.fromJson({
      ..._mockAvailableDaysJson,
      ...data,
      "sellerId": sellerID,
    });
  }
}
