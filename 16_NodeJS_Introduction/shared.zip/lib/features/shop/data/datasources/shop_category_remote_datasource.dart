import 'dart:convert';

import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/features/shop/data/models/shop_category_model.dart';

class ShopCategoryRemoteDataSource {
  ShopCategoryRemoteDataSource({required this._apiClient});

  final ApiClient _apiClient;

  Future<List<ShopCategoryModel>> fetchCategoryTree() async {
    final response = await _apiClient.get(ApiEndpoints.categoryTree);

    final data = response.data;

    if (data is! List) {
      throw const FormatException('Invalid category tree response: expected a JSON array.');
    }

    return data
        .whereType<Map>()
        .map((item) => ShopCategoryModel.fromJson(Map<String, dynamic>.from(item)))
        .toList(growable: false);
  }

  Future<ShopCategoryModel> fetchCategoryById(String categoryId) async {
    final response = await _apiClient.get("${ApiEndpoints.allCategory}/$categoryId");

    final data = response.data;

    return ShopCategoryModel.fromJson(data);
  }
}
