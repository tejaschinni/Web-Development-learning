import 'package:flutter/material.dart';

class BlinkingWidget extends StatefulWidget {
  const BlinkingWidget({
    super.key,
    required this.child,
    this.enabled = true,
    this.duration = const Duration(milliseconds: 800),
    this.minOpacity = 0.2,
    this.curve = Curves.easeInOut,
  });

  final Widget child;
  final bool enabled;
  final Duration duration;
  final double minOpacity;
  final Curve curve;

  @override
  State<BlinkingWidget> createState() => _BlinkingWidgetState();
}

class _BlinkingWidgetState extends State<BlinkingWidget> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late Animation<double> _opacity;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: widget.duration);
    _buildAnimation();
    _controller.value = 1.0;
    if (widget.enabled) _startBlinking();
  }

  void _buildAnimation() {
    _opacity = Tween<double>(
      begin: widget.minOpacity,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: widget.curve));
  }

  void _startBlinking() {
    _controller.repeat(reverse: true);
  }

  void _stopBlinking() {
    _controller.stop();
    _controller.animateTo(1.0, duration: const Duration(milliseconds: 150));
  }

  @override
  void didUpdateWidget(covariant BlinkingWidget oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (oldWidget.minOpacity != widget.minOpacity || oldWidget.curve != widget.curve) {
      _buildAnimation();
    }

    if (oldWidget.duration != widget.duration) {
      _controller.duration = widget.duration;
      if (widget.enabled) _startBlinking();
    }

    if (oldWidget.enabled != widget.enabled) {
      widget.enabled ? _startBlinking() : _stopBlinking();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (MediaQuery.of(context).disableAnimations) return widget.child;

    return FadeTransition(opacity: _opacity, child: widget.child);
  }
}
