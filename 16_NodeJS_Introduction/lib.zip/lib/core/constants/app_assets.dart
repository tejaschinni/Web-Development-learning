import 'app_svgs.dart';

export 'app_svgs.dart';

/// Centralized asset path constants for the Society Seva application.
abstract final class AppAssets {
  AppAssets._();

  // ---------------------------------------------------------------------------
  // Base Directory Paths
  // ---------------------------------------------------------------------------
  static const String images = 'assets/images';
  static const String logos = 'assets/images/logo';
  static const String icons = 'assets/images/img';

  // ---------------------------------------------------------------------------
  // Backgrounds & General Images
  // ---------------------------------------------------------------------------
  static const String bg = '$images/bg.png';
  static const String hDash = '$images/h-dash.png';
  static const String hDashS = '$images/h-dash-s.png';
  static const String introBg = '$images/intro-bg.png';
  static const String navBg = '$images/nav-bg.png';

  // ---------------------------------------------------------------------------
  // Logos
  // ---------------------------------------------------------------------------
  static const String logo = '$logos/logo.png';
  static const String logoHorizontal = '$logos/h-logo.png';
  static const String logoVerticalBig = '$logos/v-logo-big.png';
  static const String logoVerticalSmall = '$logos/v-logo-small.png';
  static const String logoIcon = '$logos/icon.png';

  // ---------------------------------------------------------------------------
  // SVG Icons - Categories
  // ---------------------------------------------------------------------------
  static const String categoryArtProducts = AppSvgs.categoryArtProducts;
  static const String categoryCleaning = AppSvgs.categoryCleaning;
  static const String categoryFood = AppSvgs.categoryFood;
  static const String categoryOthers = AppSvgs.categoryOthers;
  static const String categoryRepair = AppSvgs.categoryRepair;
  static const String categoryService = AppSvgs.categoryService;

  // Category Icon Aliases
  static const String iconCategoryArtProducts = AppSvgs.categoryArtProducts;
  static const String iconCategoryCleaning = AppSvgs.categoryCleaning;
  static const String iconCategoryFood = AppSvgs.categoryFood;
  static const String iconCategoryOthers = AppSvgs.categoryOthers;
  static const String iconCategoryRepair = AppSvgs.categoryRepair;
  static const String iconCategoryService = AppSvgs.categoryService;

  // ---------------------------------------------------------------------------
  // SVG Icons - Order & Request Statuses
  // ---------------------------------------------------------------------------
  static const String completed = AppSvgs.completed;
  static const String delivered = AppSvgs.delivered;
  static const String outForDelivery = AppSvgs.outForDelivery;
  static const String pending = AppSvgs.pending;
  static const String preparingFood = AppSvgs.preparingFood;
  static const String preparingNonFood = AppSvgs.preparingNonFood;
  static const String processing = AppSvgs.processing;
  static const String readyForPickup = AppSvgs.readyForPickup;
  static const String rejected = AppSvgs.rejected;

  // Status Icon Aliases
  static const String iconCompleted = AppSvgs.completed;
  static const String iconDelivered = AppSvgs.delivered;
  static const String iconOutForDelivery = AppSvgs.outForDelivery;
  static const String iconPending = AppSvgs.pending;
  static const String iconPreparingFood = AppSvgs.preparingFood;
  static const String iconPreparingNonFood = AppSvgs.preparingNonFood;
  static const String iconProcessing = AppSvgs.processing;
  static const String iconReadyForPickup = AppSvgs.readyForPickup;
  static const String iconRejected = AppSvgs.rejected;
}
