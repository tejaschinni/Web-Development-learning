/// Constants for all SVG assets located under `assets/images/img/`.
abstract final class AppSvgs {
  AppSvgs._();

  /// Base directory path for SVG images.
  static const String basePath = 'assets/images/img';

  // ---------------------------------------------------------------------------
  // Categories
  // ---------------------------------------------------------------------------
  static const String categoryArtProducts = '$basePath/category_art_products.svg';
  static const String categoryCleaning = '$basePath/category_cleaning.svg';
  static const String categoryFood = '$basePath/category_food.svg';
  static const String categoryOthers = '$basePath/category_others.svg';
  static const String categoryRepair = '$basePath/category_repair.svg';
  static const String categoryService = '$basePath/category_service.svg';

  // ---------------------------------------------------------------------------
  // Order & Service Request Statuses
  // ---------------------------------------------------------------------------
  static const String completed = '$basePath/completed.svg';
  static const String delivered = '$basePath/delivered.svg';
  static const String outForDelivery = '$basePath/out_for_delivery.svg';
  static const String pending = '$basePath/pending.svg';
  static const String preparingFood = '$basePath/preparing_food.svg';
  static const String preparingNonFood = '$basePath/preparing_non_food.svg';
  static const String processing = '$basePath/processing.svg';
  static const String readyForPickup = '$basePath/ready_for_pickup.svg';
  static const String rejected = '$basePath/rejected.svg';

  // ---------------------------------------------------------------------------
  // Collections
  // ---------------------------------------------------------------------------
  /// All category SVGs.
  static const List<String> categories = [
    categoryArtProducts,
    categoryCleaning,
    categoryFood,
    categoryOthers,
    categoryRepair,
    categoryService,
  ];

  /// All status SVGs.
  static const List<String> statuses = [
    completed,
    delivered,
    outForDelivery,
    pending,
    preparingFood,
    preparingNonFood,
    processing,
    readyForPickup,
    rejected,
  ];

  /// Complete list of all SVG paths in `assets/images/img/`.
  static const List<String> all = [
    ...categories,
    ...statuses,
  ];

  // ---------------------------------------------------------------------------
  // Helper Resolvers
  // ---------------------------------------------------------------------------

  /// Resolves a category slug or name (e.g. 'food', 'cleaning', 'repair')
  /// to its corresponding SVG path.
  static String? getCategorySvg(String? categoryKey) {
    if (categoryKey == null || categoryKey.isEmpty) return null;
    final normalized = categoryKey.toLowerCase().trim();

    if (normalized.contains('food') ||
        normalized.contains('breakfast') ||
        normalized.contains('lunch') ||
        normalized.contains('dinner') ||
        normalized.contains('meal') ||
        normalized.contains('bakery')) {
      return categoryFood;
    }
    if (normalized.contains('clean') ||
        normalized.contains('maid') ||
        normalized.contains('housekeeping')) {
      return categoryCleaning;
    }
    if (normalized.contains('repair') ||
        normalized.contains('electric') ||
        normalized.contains('plumb') ||
        normalized.contains('appliance') ||
        normalized.contains('carpenter')) {
      return categoryRepair;
    }
    if (normalized.contains('art') ||
        normalized.contains('craft') ||
        normalized.contains('product') ||
        normalized.contains('handmade')) {
      return categoryArtProducts;
    }
    if (normalized.contains('service') ||
        normalized.contains('salon') ||
        normalized.contains('tutor') ||
        normalized.contains('fitness')) {
      return categoryService;
    }
    if (normalized.contains('other')) {
      return categoryOthers;
    }

    return null;
  }

  /// Resolves an order / tracking status string (e.g. 'PENDING', 'DELIVERED')
  /// to its corresponding SVG path.
  static String? getStatusSvg(String? statusKey) {
    if (statusKey == null || statusKey.isEmpty) return null;
    final normalized = statusKey.toUpperCase().trim();

    return switch (normalized) {
      'PENDING' || 'PLACED' => pending,
      'PROCESSING' || 'ACCEPTED' || 'CONFIRMED' => processing,
      'PREPARING_FOOD' => preparingFood,
      'PREPARING_NON_FOOD' => preparingNonFood,
      'PREPARING' || 'IN_SERVICE' => preparingFood,
      'READY' || 'READY_FOR_PICKUP' || 'READY_FOR_HANDOFF' => readyForPickup,
      'OUT_FOR_DELIVERY' => outForDelivery,
      'DELIVERED' => delivered,
      'COMPLETED' || 'PICKED_UP' => completed,
      'REJECTED' || 'CANCELLED' || 'CANCELED' => rejected,
      _ => null,
    };
  }
}
