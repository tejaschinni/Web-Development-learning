class ApiEndpoints {
  static const String root = '/';

  static const String sendAuthOtp = '/api/v1/auth/otp/send';

  static const String verifyAuthOtp = '/api/v1/auth/otp/verify';

  static const String completeProfile = '/api/v1/auth/register/complete';

  static const String currentUser = '/api/v1/users/me';

  static const String locationContext = '/api/v1/locations/context';
  static const String locationAddresses = '/api/v1/locations/addresses';
  static const String activeLocation = '/api/v1/locations/active';
  static String locationAddress(String id) => '/api/v1/locations/addresses/$id';

  static const String sendPhoneNumberOtp = '/api/v1/users/me/phone-number/send-otp';

  static const String verifyPhoneNumberOtp = '/api/v1/users/me/phone-number';

  static const String health = '/api/v1/health';

  static const String cacheStats = '/api/v1/cache/stats';

  static const String activeSocieties = '/api/v1/societies/active';

  static const String currentUserMemberships = '/api/v1/users/me/memberships';

  static String currentUserFlats = '/api/v1/users/me/flats';

  static const String categoryTree = '/api/v1/categories/tree';

  static const String allCategory = '/api/v1/categories';

  static const String listings = '/api/v1/listings';

  static const String searchListings = '/api/v1/listings/search';

  static const String recentSearches = '/api/v1/listings/search/history/recent';

  static const String searchHistory = '/api/v1/listings/search/history';

  static String searchHistoryItem(String id) => '$searchHistory/$id';

  static const String guestSession = '/api/v1/guest/session';

  static const String guestListings = '/api/v1/guest/listings';

  static String guestListing(String id) => '/api/v1/guest/listings/$id';

  static const String guestTrending = '/api/v1/guest/trending';

  static const String guestSearchActivity = '/api/v1/guest/activity/search';

  static const String guestViewActivity = '/api/v1/guest/activity/view';

  static String submitListings(String listingId) => '/api/v1/listings/$listingId/submit';

  static String listing(String id) => '/api/v1/listings/$id';

  static String sellerListings(String sellerId) => '/api/v1/listings/seller/$sellerId';

  static String discoverListings(String categoryId) => '/api/v1/listings/discover/$categoryId';

  static String listingImages(String listingId) => '/api/v1/listings/$listingId/images';

  static String listingFoodDetails(String listingId) => '/api/v1/listings/$listingId/food-details';

  static String listingServiceDetails(String listingId) =>
      '/api/v1/listings/$listingId/service-details';

  static String serviceScheduleDates(String listingId) =>
      '/api/v1/service-schedules/listings/$listingId/dates';

  static String serviceScheduleSlots(String listingId) =>
      '/api/v1/service-schedules/listings/$listingId/slots';

  static const String cart = '/api/v1/cart';

  static const String cartItems = '/api/v1/cart/items';

  static String cartItem(String itemId) => '/api/v1/cart/items/$itemId';

  static const String deliveryOptions = '/api/v1/delivery/options';

  static const String checkoutOrder = '/api/v1/orders/checkout';

  static const String payments = '/api/v1/payments';

  static String payment(String paymentId) => '/api/v1/payments/$paymentId';

  static const String myPayments = '/api/v1/payments/mine';

  static String confirmOrderReceipt(String orderId) =>
      '/api/v1/delivery/orders/$orderId/confirm-receipt';

  static const String sellers = '/api/v1/sellers';

  static String societyBuildings(String societyId) =>
      '/api/v1/societies/$societyId/buildings/active';

  static String societyFloors(String societyId, String buildingId) =>
      '/api/v1/societies/$societyId/buildings/$buildingId/floors/active';

  static String societyFlats(String societyId) => '/api/v1/societies/$societyId/flats/active';

  static String societyFlatsByBuilding(String societyId, String buildingId) =>
      '/api/v1/societies/$societyId/flats/by-building/$buildingId/active';

  static String societyImages(String societyId) => '/api/v1/societies/$societyId/images';

  static String societyWorkers(String societyId) => '/api/v1/societies/$societyId/workers';

  static String societyMembers(String societyId) =>
      '/api/v1/societies/$societyId/members/request-access';

  static String societyMember(String societyId, String memberId) =>
      '/api/v1/societies/$societyId/members/$memberId';

  static String cancelSocietyMemberRequest(String societyId) =>
      '/api/v1/societies/$societyId/members/request-cancel';

  static String cacheClearAll = '/api/v1/cache';

  static String cacheClearById(String cacheId) => '/api/v1/cache/$cacheId';

  static String createSellerProfile = '/api/v1/sellers';

  static String submitSellerProfile(String sellerId) => '/api/v1/sellers/$sellerId/submit';

  static String fetchSellerImages(String sellerID) => '/api/v1/sellers/$sellerID/images';

  static String sellerByID(String sellerID) => '/api/v1/sellers/$sellerID';

  static String uploadKycDocument(String sellerID) => '/api/v1/sellers/$sellerID/kyc';

  static String fetchKycDocument(String sellerID) => '/api/v1/sellers/$sellerID/kyc';

  static String deleteImages(String sellerID, String imageId) =>
      '/api/v1/seller/$sellerID/images/$imageId';

  static String kycDocumentFile(String sellerId, String documentFileUrl) =>
      '/api/v1/sellers/$sellerId/kyc/$documentFileUrl/file';

  static String serviceAvailability(String listingId, String date) =>
      '/api/v1/service-schedules/listings/$listingId/availability/$date';

  static String listingImageById(String listingId, String imageId) =>
      '/api/v1/listings/$listingId/images/$imageId';

  static const String orders = '/api/v1/orders';

  static const String myOrders = '/api/v1/orders/mine';

  static String orderStatusHistory(String orderId) => '/api/v1/orders/$orderId/history';

  static String orderTransition(String orderId) => '/api/v1/orders/$orderId/transition';

  static String sellerProfile = '/api/v1/sellers/my-profile';

  static String certificate(String sellerID) => '/api/v1/sellers/$sellerID/certificates';

  static String myListing = '/api/v1/listings/mine';

  static String listingImage(String sellerID) => '/api/v1/sellers/$sellerID/images';

  static String fetchBuyerNameFromID(String buyerId) => '/api/v1/users/$buyerId';

  static String selleravailableDays(String sellerId) => '/api/v1/sellers/$sellerId/available-days';

  static String sellerMatchMe = '/api/v1/buyer-requirements/seller/matching';

  static String buyerRequirementNotInterested(String requirementId) =>
      '/api/v1/buyer-requirements/$requirementId/not-interested';

  static String buyerRequirementOffers(String requirementId) =>
      '/api/v1/buyer-requirements/$requirementId/offers';
}
