import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/features/auth/data/models/auth_tokens.dart';
import 'package:society_seva/features/auth/data/models/google_auth_request.dart';
import 'package:society_seva/features/auth/data/models/registration.dart';
import 'package:society_seva/features/auth/domain/repositories/auth_repository.dart';

class AuthRepositoryImpl implements AuthRepository {
  AuthRepositoryImpl(this._apiClient);

  final ApiClient _apiClient;

  @override
  Future<AuthOtpSent> sendAuthOtp({required String mobileNumber}) async {
    final response = await _apiClient.post(
      ApiEndpoints.sendAuthOtp,
      data: {'mobileNumber': mobileNumber},
    );
    return AuthOtpSent.fromJson(response.data as Map<String, dynamic>);
  }

  @override
  Future<AuthOtpVerification> verifyAuthOtp({
    required String registrationToken,
    required String otp,
  }) async {
    final response = await _apiClient.post(
      ApiEndpoints.verifyAuthOtp,
      data: {'registrationToken': registrationToken, 'otp': otp},
    );
    return AuthOtpVerification.fromJson(response.data as Map<String, dynamic>);
  }

  @override
  Future<AuthOtpVerification> completeProfile(CompleteProfileRequest request) async {
    final response = await _apiClient.post(ApiEndpoints.completeProfile, data: request.toJson());
    return AuthOtpVerification.fromJson(response.data as Map<String, dynamic>);
  }

  @override
  Future<AuthTokens> refresh({required String refreshToken}) async {
    final response = await _apiClient.post(
      '/api/v1/auth/refresh',
      data: {'refreshToken': refreshToken},
    );

    return AuthTokens.fromJson(response.data as Map<String, dynamic>);
  }

  @override
  Future<void> logout({required String refreshToken}) async {
    await _apiClient.post('/api/v1/auth/logout', data: {'refreshToken': refreshToken});
  }

  @override
  Future<AuthTokens> googleLogin({required String idToken}) async {
    final response = await _apiClient.post(
      '/api/v1/auth/google',
      data: GoogleAuthRequest(idToken: idToken).toJson(),
    );

    return AuthTokens.fromJson(response.data as Map<String, dynamic>);
  }
}
