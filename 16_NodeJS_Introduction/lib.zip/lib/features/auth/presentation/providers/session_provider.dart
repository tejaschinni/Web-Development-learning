import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/core/models/session.dart';
import 'package:society_seva/core/storage/secure_storage.dart';

class AuthSessionState {
  const AuthSessionState({required this.isAuthenticated, this.session});

  final bool isAuthenticated;
  final AuthSession? session;

  factory AuthSessionState.unauthenticated() =>
      const AuthSessionState(isAuthenticated: false);

  factory AuthSessionState.authenticated(AuthSession session) =>
      AuthSessionState(isAuthenticated: true, session: session);
}

final appSessionProvider = FutureProvider<AuthSessionState>((ref) async {
  final storage = AppSecureStorage();
  final savedSession = await storage.readSession();
  final accessToken = savedSession['accessToken'];
  final refreshToken = savedSession['refreshToken'];

  // Bypass login: authenticate with dummy tokens if unauthenticated
  if (accessToken == null || refreshToken == null || accessToken.isEmpty || refreshToken.isEmpty) {
    return AuthSessionState.authenticated(
      const AuthSession(
        accessToken: 'dummy_access_token_bypassed',
        refreshToken: 'dummy_refresh_token_bypassed',
      ),
    );
  }

  return AuthSessionState.authenticated(
    AuthSession(accessToken: accessToken, refreshToken: refreshToken),
  );
});
