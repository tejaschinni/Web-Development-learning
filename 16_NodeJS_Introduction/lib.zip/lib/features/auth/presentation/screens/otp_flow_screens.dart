import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:society_seva/core/config/app_config.dart';
import 'package:society_seva/core/providers/app_providers.dart';
import 'package:society_seva/features/auth/presentation/providers/auth_provider.dart';
import 'package:society_seva/features/auth/presentation/providers/registration_provider.dart';

class OtpVerificationScreen extends ConsumerStatefulWidget {
  const OtpVerificationScreen({super.key});

  @override
  ConsumerState<OtpVerificationScreen> createState() => _OtpVerificationScreenState();
}

class _OtpVerificationScreenState extends ConsumerState<OtpVerificationScreen> {
  final _otpController = TextEditingController();

  @override
  void dispose() {
    _otpController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final registrationState = ref.watch(registrationControllerProvider);
    final showDevelopmentOtp =
        ref.watch(appConfigProvider).environment == AppEnvironment.development;
    final pending = registrationState.valueOrNull;
    final developmentOtp = pending?.developmentOtp;
    _otpController.text = developmentOtp??"";
    ref.listen(registrationControllerProvider, (_, next) {
      final code = next.valueOrNull?.smsOtp;
      if (code != null && code.isNotEmpty) {
        _fillOtp(code);
      }
    });
    final capturedCode = pending?.smsOtp;
    if (capturedCode != null && capturedCode.isNotEmpty && _otpController.text != capturedCode) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          _fillOtp(capturedCode);
        }
      });
    }
    if (pending == null) {
      return registrationState.isLoading
          ? const Scaffold(body: Center(child: CircularProgressIndicator()))
          : const _MissingOtpSession();
    }

    return Scaffold(
      appBar: AppBar(title: Text('Verify mobile number', style: GoogleFonts.hind())),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                'Enter the 6-digit OTP sent to ${_maskMobile(pending.mobileNumber)}',
                style: GoogleFonts.hind(fontSize: 16),
              ),
              const Gap(24),
              if (registrationState.hasError) ...[
                _ErrorMessage(message: registrationState.error.toString()),
                const Gap(12),
              ],
              if (showDevelopmentOtp && developmentOtp != null) ...[
                Text('Development OTP', style: GoogleFonts.hind(fontWeight: FontWeight.w600)),
                SelectableText(
                  developmentOtp,
                  style: GoogleFonts.hind(fontSize: 24, fontWeight: FontWeight.w700),
                ),
                const Gap(16),
              ],
              TextField(
                controller: _otpController,
                enabled: !registrationState.isLoading,
                keyboardType: TextInputType.number,
                autofillHints: const [AutofillHints.oneTimeCode],
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(6),
                ],
                decoration: const InputDecoration(labelText: '6-digit OTP'),
              ),
              const Gap(8),
              TextButton(
                onPressed: registrationState.isLoading
                    ? null
                    : () => ref.read(registrationControllerProvider.notifier).resendOtp(),
                child: Text('Resend OTP', style: GoogleFonts.hind()),
              ),
              const Gap(8),
              FilledButton(
                onPressed: registrationState.isLoading ? null : _verify,
                child: registrationState.isLoading
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : Text('Verify OTP', style: GoogleFonts.hind()),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _fillOtp(String code) {
    _otpController.value = TextEditingValue(
      text: code,
      selection: TextSelection.collapsed(offset: code.length),
    );
  }

  Future<void> _verify() async {
    await ref.read(registrationControllerProvider.notifier).verifyOtp(_otpController.text.trim());
    if (!mounted) {
      return;
    }

    if (ref.read(authControllerProvider).valueOrNull?.isAuthenticated == true) {
      context.go('/');
    } else if (ref.read(registrationControllerProvider).valueOrNull?.profileCompletionRequired ==
        true) {
      context.go('/complete-profile');
    }
  }
}

class CompleteProfileScreen extends ConsumerStatefulWidget {
  const CompleteProfileScreen({super.key});

  @override
  ConsumerState<CompleteProfileScreen> createState() => _CompleteProfileScreenState();
}

class _CompleteProfileScreenState extends ConsumerState<CompleteProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  final _fullNameController = TextEditingController();
  final _emailController = TextEditingController();
  final _dateOfBirthController = TextEditingController();
  String _gender = 'PREFER_NOT_TO_SAY';
  String _preferredLanguage = 'en';

  @override
  void dispose() {
    _fullNameController.dispose();
    _emailController.dispose();
    _dateOfBirthController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final registrationState = ref.watch(registrationControllerProvider);
    final pending = registrationState.valueOrNull;
    if (pending == null || !pending.profileCompletionRequired) {
      return const _MissingOtpSession();
    }

    return Scaffold(
      appBar: AppBar(title: Text('Complete your profile', style: GoogleFonts.hind())),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.all(24),
            children: [
              Text('A few details to finish setting up your account.', style: GoogleFonts.hind()),
              const Gap(20),
              if (registrationState.hasError) ...[
                _ErrorMessage(message: registrationState.error.toString()),
                const Gap(12),
              ],
              TextFormField(
                controller: _fullNameController,
                textCapitalization: TextCapitalization.words,
                decoration: const InputDecoration(labelText: 'Full name'),
                validator: _requiredField('Full name'),
              ),
              const Gap(16),
              DropdownButtonFormField<String>(
                initialValue: _gender,
                decoration: const InputDecoration(labelText: 'Gender'),
                items: const [
                  DropdownMenuItem(value: 'MALE', child: Text('Male')),
                  DropdownMenuItem(value: 'FEMALE', child: Text('Female')),
                  DropdownMenuItem(value: 'OTHER', child: Text('Other')),
                  DropdownMenuItem(value: 'PREFER_NOT_TO_SAY', child: Text('Prefer not to say')),
                ],
                onChanged: registrationState.isLoading
                    ? null
                    : (value) => setState(() => _gender = value ?? _gender),
              ),
              const Gap(16),
              DropdownButtonFormField<String>(
                initialValue: _preferredLanguage,
                decoration: const InputDecoration(labelText: 'Preferred language'),
                items: const [
                  DropdownMenuItem(value: 'en', child: Text('English')),
                  DropdownMenuItem(value: 'hi', child: Text('Hindi')),
                  DropdownMenuItem(value: 'mr', child: Text('Marathi')),
                  DropdownMenuItem(value: 'gu', child: Text('Gujarati')),
                  DropdownMenuItem(value: 'bn', child: Text('Bengali')),
                  DropdownMenuItem(value: 'ta', child: Text('Tamil')),
                  DropdownMenuItem(value: 'te', child: Text('Telugu')),
                  DropdownMenuItem(value: 'kn', child: Text('Kannada')),
                  DropdownMenuItem(value: 'ml', child: Text('Malayalam')),
                ],
                onChanged: registrationState.isLoading
                    ? null
                    : (value) => setState(() => _preferredLanguage = value ?? _preferredLanguage),
              ),
              const Gap(16),
              TextFormField(
                controller: _emailController,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(labelText: 'Email'),
                validator: (value) {
                  final email = value?.trim() ?? '';
                  if (email.isEmpty || !email.contains('@')) {
                    return 'Enter a valid email address';
                  }
                  return null;
                },
              ),
              const Gap(16),
              TextFormField(
                controller: _dateOfBirthController,
                readOnly: true,
                decoration: const InputDecoration(labelText: 'Date of birth'),
                onTap: registrationState.isLoading ? null : _selectDateOfBirth,
                validator: _requiredField('Date of birth'),
              ),
              const Gap(24),
              FilledButton(
                onPressed: registrationState.isLoading ? null : _submit,
                child: registrationState.isLoading
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : Text('Complete profile', style: GoogleFonts.hind()),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String? Function(String?) _requiredField(String label) => (value) {
    return value == null || value.trim().isEmpty ? '$label is required' : null;
  };

  Future<void> _selectDateOfBirth() async {
    final now = DateTime.now();
    final selected = await showDatePicker(
      context: context,
      initialDate: DateTime(now.year - 18, now.month, now.day),
      firstDate: DateTime(1900),
      lastDate: now,
    );
    if (selected != null) {
      _dateOfBirthController.text =
          '${selected.year.toString().padLeft(4, '0')}-'
          '${selected.month.toString().padLeft(2, '0')}-'
          '${selected.day.toString().padLeft(2, '0')}';
    }
  }

  Future<void> _submit() async {
    if (!(_formKey.currentState?.validate() ?? false)) {
      return;
    }

    await ref
        .read(registrationControllerProvider.notifier)
        .completeProfile(
          fullName: _fullNameController.text.trim(),
          gender: _gender,
          preferredLanguage: _preferredLanguage,
          email: _emailController.text.trim(),
          dateOfBirth: _dateOfBirthController.text,
        );
    if (mounted && ref.read(authControllerProvider).valueOrNull?.isAuthenticated == true) {
      context.go('/');
    }
  }
}

class _MissingOtpSession extends StatelessWidget {
  const _MissingOtpSession();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: FilledButton(
          onPressed: () => context.go('/login'),
          child: Text('Return to mobile sign-in', style: GoogleFonts.hind()),
        ),
      ),
    );
  }
}

class _ErrorMessage extends StatelessWidget {
  const _ErrorMessage({required this.message});

  final String message;

  @override
  Widget build(BuildContext context) {
    return Text(message, style: GoogleFonts.hind(color: Colors.red.shade700));
  }
}

String _maskMobile(String value) {
  if (value.length < 4) {
    return value;
  }
  return '${value.substring(0, 2)} XXXX ${value.substring(value.length - 2)}';
}
