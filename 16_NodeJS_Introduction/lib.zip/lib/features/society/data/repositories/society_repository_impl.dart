import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/features/society/data/models/membership_models.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/society/data/models/society_models.dart';
import 'package:society_seva/features/society/data/repositories/society_repository.dart';

class SocietyRepositoryImpl implements SocietyRepository {
  SocietyRepositoryImpl(this._apiClient);

  final ApiClient _apiClient;

  @override
  Future<PageResponse<Flat>> getCurrentUserFlats(PageableQuery query) {
    return _getPage(ApiEndpoints.currentUserFlats, query, Flat.fromJson);
  }

  @override
  Future<PageResponse<SocietyMembershipSummary>> getCurrentUserMemberships(PageableQuery query) {
    return _getPage(ApiEndpoints.currentUserMemberships, query, SocietyMembershipSummary.fromJson);
  }

  @override
  Future<PageResponse<Society>> getActiveSocieties(PageableQuery query) {
    return _getPage(ApiEndpoints.activeSocieties, query, Society.fromJson);
  }

  @override
  Future<PageResponse<Building>> getBuildings(String societyId, PageableQuery query) {
    return _getPage(ApiEndpoints.societyBuildings(societyId), query, Building.fromJson);
  }

  @override
  Future<PageResponse<Floor>> getFloors(String societyId, String buildingId, PageableQuery query) {
    return _getPage(ApiEndpoints.societyFloors(societyId, buildingId), query, Floor.fromJson);
  }

  @override
  Future<PageResponse<Flat>> getFlats(String societyId, PageableQuery query) {
    return _getPage(ApiEndpoints.societyFlats(societyId), query, Flat.fromJson);
  }

  @override
  Future<PageResponse<Flat>> getFlatsByBuilding(
    String societyId,
    String buildingId,
    PageableQuery query,
  ) {
    return _getPage(
      ApiEndpoints.societyFlatsByBuilding(societyId, buildingId),
      query,
      Flat.fromJson,
    );
  }

  @override
  Future<PageResponse<SocietyImage>> getImages(String societyId, PageableQuery query) {
    return _getPage(ApiEndpoints.societyImages(societyId), query, SocietyImage.fromJson);
  }

  @override
  Future<List<SocietyWorker>> getWorkers(String societyId) async {
    final response = await _apiClient.get(ApiEndpoints.societyWorkers(societyId));
    final data = response.data;
    if (data is! List) {
      return const [];
    }
    return data
        .whereType<Map>()
        .map((item) => SocietyWorker.fromJson(Map<String, dynamic>.from(item)))
        .toList();
  }

  @override
  Future<SocietyMember> createMember(String societyId, CreateSocietyMemberRequest request) async {
    final response = await _apiClient.post(
      ApiEndpoints.societyMembers(societyId),
      data: request.toJson(),
    );
    return SocietyMember.fromJson(response.data as Map<String, dynamic>);
  }

  @override
  Future<SocietyMember> getMember(String societyId, String memberId) async {
    final response = await _apiClient.get(ApiEndpoints.societyMember(societyId, memberId));
    return SocietyMember.fromJson(response.data as Map<String, dynamic>);
  }

  @override
  Future<SocietyMember> updateMember(
    String societyId,
    String memberId,
    UpdateSocietyMemberRequest request,
  ) async {
    final response = await _apiClient.patch(
      ApiEndpoints.societyMember(societyId, memberId),
      data: request.toJson(),
    );
    return SocietyMember.fromJson(response.data as Map<String, dynamic>);
  }

  @override
  Future<void> cancelMemberRequest({
    required String societyId,
    required String userId,
    required String memberId,
  }) async {
    await _apiClient.delete(
      ApiEndpoints.cancelSocietyMemberRequest(societyId),
      data: {'userId': userId, 'memberId': memberId},
    );
  }

  Future<PageResponse<T>> _getPage<T>(
    String path,
    PageableQuery query,
    T Function(Map<String, dynamic>) fromJson,
  ) async {
    try {
      final response = await _apiClient.get(path, queryParameters: query.toQueryParameters());
      return PageResponse.fromJson(response.data as Map<String, dynamic>, fromJson);
    } catch (_) {
      return PageResponse<T>(
        content: const [],
        page: query.page,
        size: query.size,
        totalElements: 0,
        totalPages: 0,
        first: true,
        last: true,
      );
    }
  }
}
