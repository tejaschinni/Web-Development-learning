/// Enum representing the possible states for a seller's onboarding / account status.
enum SellerAccountStatus {
  draft,
  submitted,
  underReview,
  approved,
  rejected,
  suspended,
  inactive;

  static SellerAccountStatus fromString(String? value) {
    if (value == null) return SellerAccountStatus.submitted;
    switch (value.trim().toUpperCase()) {
      case 'DRAFT':
      case 'DRAFTED':
        return SellerAccountStatus.draft;
      case 'SUBMITTED':
      case 'CREATED':
        return SellerAccountStatus.submitted;
      case 'UNDER_REVIEW':
      case 'PENDING':
      case 'VERIFICATION_PENDING':
        return SellerAccountStatus.underReview;
      case 'APPROVED':
        return SellerAccountStatus.approved;
      case 'REJECTED':
      case 'NOT_APPROVED':
        return SellerAccountStatus.rejected;
      case 'SUSPENDED':
        return SellerAccountStatus.suspended;
      case 'INACTIVE':
        return SellerAccountStatus.inactive;
      default:
        return SellerAccountStatus.submitted;
    }
  }
}
