enum CertificateType {
  cookingCertificate('COOKING_CERTIFICATE', 'Cooking Certificate'),
  culinaryDiploma('CULINARY_DIPLOMA', 'Culinary Diploma / Degree'),
  foodHandler('FOOD_HANDLER', 'Food Handler Certificate'),
  foodSafety('FOOD_SAFETY', 'Food Safety Training Certificate'),
  hygieneRating('HYGIENE_RATING', 'Hygiene Rating Certificate'),
  healthCertificate('HEALTH_CERTIFICATE', 'Health / Medical Fitness Certificate'),
  bakingCertificate('BAKING_CERTIFICATE', 'Baking / Pastry Certificate'),
  tradeLicense('TRADE_LICENSE', 'Trade License'),
  other('OTHER', 'Other');

  final String value;
  final String label;

  const CertificateType(this.value, this.label);
}
