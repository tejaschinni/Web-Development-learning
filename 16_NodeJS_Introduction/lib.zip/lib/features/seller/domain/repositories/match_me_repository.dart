import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/seller/data/datasources/match_me_remote_datasource.dart';
import 'package:society_seva/features/seller/domain/entities/match_me_entity.dart';
import 'package:society_seva/features/seller/domain/entities/match_me_offer_entity.dart';

abstract class MatchMeRepository {
  Future<PageResponse<MatchMeEntity>> fetchMatcingRequirmentForSellerRepo({
    int page = 0,
    int size = 20,
  });

  Future<void> markNotInterestedRepo({required String requirementId});

  Future<MatchMeOfferEntity> postOfferRepo({
    required String requirementId,
    required CreateMatchMeOfferRequest request,
  });

  Future<List<MatchMeOfferEntity>> fetchOffersForRequirementRepo({
    required String requirementId,
  });
}

class MatchMeRepositoryImpl implements MatchMeRepository {
  MatchMeRepositoryImpl(this.matchMeRemoteDataSource);
  final MatchMeRemoteDataSource matchMeRemoteDataSource;

  @override
  Future<PageResponse<MatchMeEntity>> fetchMatcingRequirmentForSellerRepo({
    int page = 0,
    int size = 20,
  }) async {
    final result = await matchMeRemoteDataSource.fetchMatcingRequirmentForSellerDataSource(
      page: page,
      size: size,
    );
    return result;
  }

  @override
  Future<void> markNotInterestedRepo({required String requirementId}) {
    return matchMeRemoteDataSource.sellerNotIntrestedInRequirmentDataSource(
      requirmentID: requirementId,
    );
  }

  @override
  Future<MatchMeOfferEntity> postOfferRepo({
    required String requirementId,
    required CreateMatchMeOfferRequest request,
  }) {
    return matchMeRemoteDataSource.postOfferForRequirement(
      requirementId: requirementId,
      request: request,
    );
  }

  @override
  Future<List<MatchMeOfferEntity>> fetchOffersForRequirementRepo({
    required String requirementId,
  }) {
    return matchMeRemoteDataSource.fetchPostedOffers(requirementId: requirementId);
  }
}
