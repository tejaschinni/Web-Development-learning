import 'package:society_seva/features/seller/data/datasources/places_remote_datasource.dart';
import 'package:society_seva/features/seller/domain/entities/address_entity.dart';
import 'package:society_seva/features/seller/domain/entities/place_details_entity.dart';

abstract interface class PlacesRepository {
  Future<List<AddressSuggestion>> autocomplete(String query);
  Future<PlaceDetails?> getDetails(String placeId);

  Future<PlaceDetails?> geocodeAddress(String address);
}

class PlacesRepositoryImpl implements PlacesRepository {
  PlacesRepositoryImpl(this._remote);
  final PlacesRemoteDataSource _remote;

  @override
  Future<List<AddressSuggestion>> autocomplete(String query) async {
    final raw = await _remote.autocomplete(query);
    return raw
        .map(
          (p) =>
              AddressSuggestion(placeId: p['placeId'] as String, text: p['text']['text'] as String),
        )
        .toList();
  }

  @override
  Future<PlaceDetails?> getDetails(String placeId) async {
    final j = await _remote.details(placeId);
    if (j == null) return null;
    final comps = (j['addressComponents'] as List?) ?? [];
    String pick(List<String> types) {
      for (final t in types) {
        for (final c in comps) {
          if ((c['types'] as List).contains(t)) return (c['longText'] ?? '') as String;
        }
      }
      return '';
    }

    return PlaceDetails(
      address: j['formattedAddress'] ?? '',
      lat: (j['location']['latitude'] as num).toDouble(),
      lng: (j['location']['longitude'] as num).toDouble(),
      city: pick(['locality', 'administrative_area_level_3', 'administrative_area_level_2']),
      state: pick(['administrative_area_level_1']),
      country: pick(['country']),
      pinCode: pick(['postal_code']),
    );
  }

  @override
  Future<PlaceDetails?> geocodeAddress(String address) async {
    try {
      final locs = await _remote.locationsFromAddress(address);
      if (locs.isEmpty) return null;
      final l = locs.first;
      final marks = await _remote.placemarksFromCoordinates(l.latitude, l.longitude);
      final m = marks.isNotEmpty ? marks.first : null;
      return PlaceDetails(
        address: address,
        lat: l.latitude,
        lng: l.longitude,
        city: m?.locality ?? m?.subAdministrativeArea ?? '',
        state: m?.administrativeArea ?? '',
        country: m?.country ?? '',
        pinCode: m?.postalCode ?? '',
      );
    } catch (_) {
      return null;
    }
  }
}
