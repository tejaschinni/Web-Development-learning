class PlaceDetails {
  const PlaceDetails({
    required this.address,
    required this.lat,
    required this.lng,
    this.city = '',
    this.state = '',
    this.country = '',
    this.pinCode = '',
  });
  final String address, city, state, country, pinCode;
  final double lat, lng;
}
