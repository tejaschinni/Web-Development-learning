class MatchMeOfferEntity {
  final String id;
  final String requirementId;
  final String sellerId;
  final String sellerName;
  final double offeredPrice;
  final String notes;
  final DateTime? availableFrom;
  final DateTime? availableTo;
  final String status;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  const MatchMeOfferEntity({
    required this.id,
    required this.requirementId,
    required this.sellerId,
    required this.sellerName,
    required this.offeredPrice,
    required this.notes,
    this.availableFrom,
    this.availableTo,
    required this.status,
    this.createdAt,
    this.updatedAt,
  });

  bool get isPending => status.toUpperCase() == 'PENDING';
  bool get isAccepted => status.toUpperCase() == 'ACCEPTED';
  bool get isRejected => status.toUpperCase() == 'REJECTED';
}

class CreateMatchMeOfferRequest {
  final String sellerId;
  final String offeredPrice;
  final String notes;
  final DateTime availableFrom;
  final DateTime availableTo;

  const CreateMatchMeOfferRequest({
    required this.sellerId,
    required this.offeredPrice,
    required this.notes,
    required this.availableFrom,
    required this.availableTo,
  });

  Map<String, dynamic> toJson() => {
    'sellerId': sellerId,
    'offeredPrice': offeredPrice,
    'notes': notes,
    'availableFrom': availableFrom.toUtc().toIso8601String(),
    'availableTo': availableTo.toUtc().toIso8601String(),
  };
}
