class AddressSuggestion {
  const AddressSuggestion({required this.placeId, required this.text});
  final String placeId;
  final String text;
}
