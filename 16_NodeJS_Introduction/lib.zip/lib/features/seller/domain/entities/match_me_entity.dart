class MatchMeEntity {
  final String id;
  final String buyerId;
  final String categoryId;
  final String title;
  final String description;
  final int quantity;
  final String unit;
  final int budgetMin;
  final int budgetMax;
  final DateTime requiredBy;
  final String address;
  final String city;
  final String state;
  final String pinCode;
  final double latitude;
  final double longitude;
  final int offerCount;
  final String status;
  final List<dynamic> discussingSellers;
  final DateTime createdAt;

  const MatchMeEntity({
    required this.id,
    required this.buyerId,
    required this.categoryId,
    required this.title,
    required this.description,
    required this.quantity,
    required this.unit,
    required this.budgetMin,
    required this.budgetMax,
    required this.requiredBy,
    required this.address,
    required this.city,
    required this.state,
    required this.pinCode,
    required this.latitude,
    required this.longitude,
    required this.offerCount,
    required this.status,
    required this.discussingSellers,
    required this.createdAt,
  });

  MatchMeEntity copyWith({
    String? id,
    String? buyerId,
    String? categoryId,
    String? title,
    String? description,
    int? quantity,
    String? unit,
    int? budgetMin,
    int? budgetMax,
    DateTime? requiredBy,
    String? address,
    String? city,
    String? state,
    String? pinCode,
    double? latitude,
    double? longitude,
    int? offerCount,
    String? status,
    List<dynamic>? discussingSellers,
    DateTime? createdAt,
  }) {
    return MatchMeEntity(
      id: id ?? this.id,
      buyerId: buyerId ?? this.buyerId,
      categoryId: categoryId ?? this.categoryId,
      title: title ?? this.title,
      description: description ?? this.description,
      quantity: quantity ?? this.quantity,
      unit: unit ?? this.unit,
      budgetMin: budgetMin ?? this.budgetMin,
      budgetMax: budgetMax ?? this.budgetMax,
      requiredBy: requiredBy ?? this.requiredBy,
      address: address ?? this.address,
      city: city ?? this.city,
      state: state ?? this.state,
      pinCode: pinCode ?? this.pinCode,
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
      offerCount: offerCount ?? this.offerCount,
      status: status ?? this.status,
      discussingSellers: discussingSellers ?? this.discussingSellers,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}
