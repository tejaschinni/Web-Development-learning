import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/domain/enum/seller_account_status.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/status/seller_status_actions.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/status/seller_status_app_bar.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/status/seller_status_banner.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/status/seller_status_content_card.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/status/seller_status_graphic.dart';

export 'package:society_seva/features/seller/domain/enum/seller_account_status.dart';

class SellerStatusScreen extends ConsumerStatefulWidget {
  const SellerStatusScreen({
    super.key,
    this.status,
    this.submittedOn,
    this.referenceId,
    this.approvedOn,
    this.sellerType,
    this.category,
    this.serviceArea,
    this.rejectionReason,
    this.suspendedReason,
    this.suspendedOn,
    this.inactiveReason,
    this.inactivatedOn,
  });

  final SellerAccountStatus? status;
  final String? submittedOn;
  final String? referenceId;
  final String? approvedOn;
  final String? sellerType;
  final String? category;
  final String? serviceArea;
  final String? rejectionReason;
  final String? suspendedReason;
  final String? suspendedOn;
  final String? inactiveReason;
  final String? inactivatedOn;

  @override
  ConsumerState<SellerStatusScreen> createState() => _SellerStatusScreenState();
}

class _SellerStatusScreenState extends ConsumerState<SellerStatusScreen> {
  SellerAccountStatus get _effectiveStatus {
    if (widget.status != null) return widget.status!;
    final profile = ref.watch(mySellerProfileProvider).valueOrNull;
    if (profile != null && profile.approvalStatus.isNotEmpty) {
      return SellerAccountStatus.fromString(profile.approvalStatus);
    }
    return SellerAccountStatus.submitted;
  }

  void _goToDashboard() {
    context.go('/modules/seller/sellerDashboard');
  }

  void _onCreateFirstListing() {
    context.push('/modules/seller/addListing');
  }

  void _onUpdateAndResubmit() {
    context.push('/modules/seller/onboarding', extra: true);
  }

  void _onActivateAccount() {
    context.push('/modules/seller/addListing');
  }

  void _onContactSupport() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'SEVA Support',
              style: AppTheme.display(18, w: FontWeight.w700, c: AppColors.ink),
            ),
            const Gap(12),
            Text(
              'For assistance with your seller account or account review status, please reach out to our support team:',
              style: AppTheme.hind(14, c: AppColors.muted),
            ),
            const Gap(16),
            ListTile(
              leading: const CircleAvatar(
                backgroundColor: AppColors.greenSoft,
                child: Icon(Icons.email_outlined, color: AppColors.green),
              ),
              title: Text('Email Support', style: AppTheme.hind(14, w: FontWeight.w600, c: AppColors.ink)),
              subtitle: Text('support@vasundharaseva.com', style: AppTheme.hind(13, c: AppColors.muted)),
              contentPadding: EdgeInsets.zero,
            ),
            ListTile(
              leading: const CircleAvatar(
                backgroundColor: AppColors.greenSoft,
                child: Icon(Icons.phone_outlined, color: AppColors.green),
              ),
              title: Text('Helpline', style: AppTheme.hind(14, w: FontWeight.w600, c: AppColors.ink)),
              subtitle: Text('+91 1800 200 4567 (10 AM - 6 PM)', style: AppTheme.hind(13, c: AppColors.muted)),
              contentPadding: EdgeInsets.zero,
            ),
            const Gap(16),
            SizedBox(
              width: double.infinity,
              height: 46,
              child: ElevatedButton(
                onPressed: () => Navigator.pop(ctx),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.green,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: Text('Close', style: AppTheme.hind(15, w: FontWeight.w600, c: AppColors.surface)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final currentStatus = _effectiveStatus;

    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: const SellerStatusAppBar(),
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const Gap(8),
              _buildTitle(currentStatus),
              const Gap(6),
              _buildSubtitle(currentStatus),
              const Gap(22),
              SellerStatusGraphic(status: currentStatus),
              const Gap(20),
              SellerStatusBanner(status: currentStatus),
              const Gap(16),
              SellerStatusContentCard(
                status: currentStatus,
                submittedOn: widget.submittedOn,
                referenceId: widget.referenceId,
                approvedOn: widget.approvedOn,
                sellerType: widget.sellerType,
                category: widget.category,
                serviceArea: widget.serviceArea,
                rejectionReason: widget.rejectionReason,
                suspendedReason: widget.suspendedReason,
                suspendedOn: widget.suspendedOn,
                inactiveReason: widget.inactiveReason,
                inactivatedOn: widget.inactivatedOn,
              ),
              const Gap(24),
              SellerStatusActions(
                status: currentStatus,
                onGoToDashboard: _goToDashboard,
                onCreateListing: _onCreateFirstListing,
                onUpdateAndResubmit: _onUpdateAndResubmit,
                onContactSupport: _onContactSupport,
                onActivateAccount: _onActivateAccount,
              ),
              const Gap(16),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTitle(SellerAccountStatus status) {
    String text;
    switch (status) {
      case SellerAccountStatus.draft:
        text = 'Application Drafted';
        break;
      case SellerAccountStatus.submitted:
        text = 'Seller Registration Submitted';
        break;
      case SellerAccountStatus.underReview:
        text = 'Verification Pending';
        break;
      case SellerAccountStatus.approved:
        text = 'Seller Account Approved';
        break;
      case SellerAccountStatus.rejected:
        text = 'Application Not Approved';
        break;
      case SellerAccountStatus.suspended:
        text = 'Seller Account Suspended';
        break;
      case SellerAccountStatus.inactive:
        text = 'Inactive Account';
        break;
    }

    return Text(
      text,
      textAlign: TextAlign.center,
      style: AppTheme.display(22, w: FontWeight.w800, c: AppColors.ink),
    );
  }

  Widget _buildSubtitle(SellerAccountStatus status) {
    String text;
    switch (status) {
      case SellerAccountStatus.draft:
        text = 'Your seller profile is saved as draft. You can edit and submit whenever you are ready.';
        break;
      case SellerAccountStatus.submitted:
        text = 'Thank you! Your seller application has\nbeen submitted successfully.';
        break;
      case SellerAccountStatus.underReview:
        text = 'Your application is under review.';
        break;
      case SellerAccountStatus.approved:
        text = 'You can now create listings and start accepting orders.';
        break;
      case SellerAccountStatus.rejected:
        text = 'We are unable to approve your seller account\nat this time.';
        break;
      case SellerAccountStatus.suspended:
        text = 'Your account is currently suspended.';
        break;
      case SellerAccountStatus.inactive:
        text = 'Your seller account is currently inactive.';
        break;
    }

    return Text(
      text,
      textAlign: TextAlign.center,
      style: AppTheme.hind(13.5, c: AppColors.muted, h: 1.3),
    );
  }
}
