import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/seller/domain/entities/seller_listing_entity.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_listing_provider.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/seller/presentation/widgets/listing/seller_listing_item_widget.dart';

enum ListingType { product, service }

enum ListingStatus { active, paused, outOfStock }

enum ListingFilter { all, active, paused, outOfStock }

class MyListingsScreen extends ConsumerStatefulWidget {
  const MyListingsScreen({super.key});

  @override
  ConsumerState<MyListingsScreen> createState() => _MyListingsScreenState();
}

class _MyListingsScreenState extends ConsumerState<MyListingsScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _addListing() {
    context.push('/modules/seller/addListing');
  }

  @override
  Widget build(BuildContext context) {
    // final seller = ref.watch(
    //   mySellerProfileProvider.select((async) {
    //     final s = async.valueOrNull;
    //     return s == null ? null : (id: s.id, name: s.displayName);
    //   }),
    // );
    // final args = (sellerID: seller != null ? seller.id : "");
    // final listingsAsync = ref.watch(sellerListingProvider(args));

    final seller = ref.watch(
      mySellerProfileProvider.select((async) {
        final s = async.valueOrNull;
        return s == null ? null : (id: s.id, name: s.displayName);
      }),
    );

    final sellerId = seller?.id ?? '';
    final hasSeller = sellerId.isNotEmpty;

    // Not watched (no API call) until a seller id exists
    final AsyncValue<PageResponse<SellerListingEntity>>? listingsAsync = hasSeller
        ? ref.watch(sellerListingProvider((sellerID: sellerId)))
        : null;
    return RefreshIndicator(
      onRefresh: () async => ref.invalidate(sellerListingProvider((sellerID: sellerId.toString()))),
      child: Scaffold(
        body: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
                child: Text(
                  'My Listings',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700, color: AppColors.ink),
                ),
              ),
              TabBar(
                controller: _tabController,
                labelColor: AppColors.green,
                unselectedLabelColor: AppColors.muted,
                indicatorColor: AppColors.green,
                indicatorWeight: 2.5,
                dividerColor: AppColors.ink,
                labelStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
                tabs: const [
                  Tab(text: 'Products'),
                  Tab(text: 'Services'),
                ],
              ),
              Expanded(
                child: listingsAsync == null
                    ? const Center(child: CircularProgressIndicator())
                    : listingsAsync.when(
                        loading: () => const Center(child: CircularProgressIndicator()),
                        error: (e, _) => _ErrorView(
                          message: 'Could not load listings',
                          details: e.toString(),
                          onRetry: () =>
                              ref.invalidate(sellerListingProvider((sellerID: sellerId))),
                          onAdd: _addListing,
                        ),
                        data: (page) {
                          return TabBarView(
                            controller: _tabController,
                            children: [
                              _ListingsTab(
                                type: ListingType.product,
                                list: page.content
                                    .where((e) => e.listingType.toLowerCase() == 'food')
                                    .toList(),
                              ),
                              _ListingsTab(
                                type: ListingType.service,
                                list: page.content
                                    .where((e) => e.listingType.toLowerCase() != 'food')
                                    .toList(),
                              ),
                            ],
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: _addListing,
          backgroundColor: AppColors.green,
          foregroundColor: Colors.white,
          icon: const Icon(Icons.add),
          label: const Text('Add Listing', style: TextStyle(fontWeight: FontWeight.w600)),
        ),
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  final String message;
  final String details;
  final VoidCallback onRetry;
  final VoidCallback onAdd;

  const _ErrorView({
    required this.message,
    required this.details,
    required this.onRetry,
    required this.onAdd,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline, size: 48, color: AppColors.red),
            const Gap(12),
            Text(
              message,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: AppColors.ink,
              ),
            ),
            const Gap(6),
            Text(
              details,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 12, color: AppColors.muted),
            ),
            const Gap(16),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                OutlinedButton.icon(
                  onPressed: onRetry,
                  icon: const Icon(Icons.refresh),
                  label: const Text('Retry'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.green,
                    side: const BorderSide(color: AppColors.green),
                  ),
                ),
                const Gap(12),
                FilledButton.icon(
                  onPressed: onAdd,
                  icon: const Icon(Icons.add),
                  label: const Text('Add listing'),
                  style: FilledButton.styleFrom(backgroundColor: AppColors.green),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _ListingsTab extends ConsumerStatefulWidget {
  final ListingType type;
  final List<SellerListingEntity> list;
  const _ListingsTab({required this.type, required this.list});

  @override
  ConsumerState<_ListingsTab> createState() => _ListingsTabState();
}

class _ListingsTabState extends ConsumerState<_ListingsTab> with AutomaticKeepAliveClientMixin {
  final _searchController = TextEditingController();
  String _query = '';

  @override
  bool get wantKeepAlive => true;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _confirmDelete(SellerListingEntity item) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete listing?'),
        content: Text('"${item.title}" will be removed permanently.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
    // if (ok == true) ref.read(myListingsProvider.notifier).delete(item.id);
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
          child: TextField(
            controller: _searchController,
            onChanged: (v) => setState(() => _query = v),
            decoration: InputDecoration(
              hintText: 'Search listings...',
              hintStyle: const TextStyle(color: AppColors.muted, fontSize: 14),
              prefixIcon: const Icon(Icons.search, color: AppColors.muted),
              suffixIcon: _query.isEmpty
                  ? null
                  : IconButton(
                      icon: const Icon(Icons.close, size: 18),
                      onPressed: () {
                        _searchController.clear();
                        setState(() => _query = '');
                      },
                    ),
              filled: true,
              fillColor: Colors.white,
              contentPadding: const EdgeInsets.symmetric(vertical: 0),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(28),
                borderSide: const BorderSide(color: AppColors.border),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(28),
                borderSide: const BorderSide(color: AppColors.green),
              ),
            ),
          ),
        ),
        Gap(15), // SizedBox(

        Expanded(
          child: widget.list.isEmpty
              ? _EmptyState(type: widget.type)
              : ListView.separated(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 96),
                  itemCount: widget.list.length,
                  separatorBuilder: (_, _) => const Gap(10),
                  itemBuilder: (_, i) {
                    final item = widget.list[i];
                    return SellerListingItemWidget(
                      item: item,
                      onToggle: (v) {},
                      onEdit: () {
                        context.push(
                          '/modules/seller/addListing',
                          extra: {'isEdit': true, 'listingId': item.id},
                        );
                      },
                      onOutOfStock: () {},
                      onDelete: () => () {},
                    );
                  },
                ),
        ),
      ],
    );
  }
}

class _EmptyState extends StatelessWidget {
  final ListingType type;
  const _EmptyState({required this.type});

  @override
  Widget build(BuildContext context) {
    final noun = type == ListingType.product ? 'products' : 'services';
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.inbox_outlined, size: 48, color: AppColors.muted),
          const Gap(8),
          Text('No $noun found', style: const TextStyle(fontSize: 15, color: AppColors.muted)),
        ],
      ),
    );
  }
}

ListingStatus fromApi(String? value) {
  final v = (value ?? '').toLowerCase().replaceAll(RegExp(r'[\s_\-]'), '');
  switch (v) {
    case 'active':
    case 'available':
      return ListingStatus.active;
    case 'paused':
    case 'inactive':
    case 'unavailable':
      return ListingStatus.paused;
    case 'outofstock':
    case 'soldout':
      return ListingStatus.outOfStock;
    default:
      return ListingStatus.paused; // safe fallback for unknown values
  }
}
