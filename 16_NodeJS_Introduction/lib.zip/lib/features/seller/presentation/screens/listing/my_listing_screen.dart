import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/seller/domain/entities/seller_listing_entity.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_listing_provider.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/seller/presentation/widgets/dashboard_app_bar_widget.dart';
import 'package:society_seva/features/seller/presentation/widgets/listing/my_list_item_widget.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/seller_text_field.dart';

enum ListingFilter { all, approved, draft, outOfStock }

class MyListingScreen extends ConsumerStatefulWidget {
  const MyListingScreen({super.key});

  @override
  ConsumerState<MyListingScreen> createState() => _MyListingScreenState();
}

class _MyListingScreenState extends ConsumerState<MyListingScreen> {
  ListingFilter _filter = ListingFilter.all;
  final _searchCtrl = TextEditingController();
  Timer? _debounce;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _searchCtrl.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _searchCtrl.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 250), () {
      if (!mounted) return;
      setState(() => _query = _searchCtrl.text.trim().toLowerCase());
    });
  }

  void _addListing() => context.push('/modules/seller/addListing');

  // ── Adjust these 4 helpers to your listing model's real field names ──
  // Replace `dynamic` with your model class (e.g. ListingModel).
  bool _isPublished(SellerListingEntity i) =>
      i.approvalStatus.toString().toUpperCase() == 'PUBLISHED' ||
      i.approvalStatus.toString().toUpperCase() == 'APPROVED';
  bool _isDraft(SellerListingEntity i) => i.approvalStatus.toString().toUpperCase() == 'DRAFT';
  bool _isOutOfStock(SellerListingEntity i) =>
      i.additionalCategoryIds.toString().toUpperCase() == 'OUT_OF_STOCK' ||
      (i.quantityAvailable != 0 && i.quantityAvailable <= 0);
  String _titleOf(SellerListingEntity i) => (i.title).toString();
  // ─────────────────────────────────────────────────────────────────────

  bool _matchesFilter(dynamic i) => switch (_filter) {
    ListingFilter.all => true,
    ListingFilter.approved => _isPublished(i),
    ListingFilter.draft => _isDraft(i),
    ListingFilter.outOfStock => _isOutOfStock(i),
  };

  bool _matchesSearch(dynamic i) => _query.isEmpty || _titleOf(i).toLowerCase().contains(_query);

  @override
  Widget build(BuildContext context) {
    // final seller = ref.watch(
    //   mySellerProfileProvider.select((async) {
    //     final s = async.valueOrNull;
    //     return s == null ? null : (id: s.id, name: s.displayName);
    //   }),
    // );
    // final args = (sellerID: seller != null ? seller.id : "");
    // final listingsAsync = ref.watch(sellerListingProvider(args));
    final seller = ref.watch(
      mySellerProfileProvider.select((async) {
        final s = async.valueOrNull;
        return s == null ? null : (id: s.id, name: s.displayName);
      }),
    );

    final sellerId = seller?.id ?? '';
    final hasSeller = sellerId.isNotEmpty;

    final AsyncValue<PageResponse<SellerListingEntity>>? listingsAsync = hasSeller
        ? ref.watch(sellerListingProvider((sellerID: sellerId)))
        : null;

    final all = listingsAsync?.valueOrNull?.content ?? const [];
    final counts = <ListingFilter, int>{
      ListingFilter.all: all.length,
      ListingFilter.approved: all.where(_isPublished).length,
      ListingFilter.draft: all.where(_isDraft).length,
      ListingFilter.outOfStock: all.where(_isOutOfStock).length,
    };
    String label(ListingFilter f) => switch (f) {
      ListingFilter.all => 'All (${counts[f]})',
      ListingFilter.approved => 'Approved (${counts[f]})',
      ListingFilter.draft => 'Draft (${counts[f]})',
      ListingFilter.outOfStock => 'Out of Stock (${counts[f]})',
    };

    return Scaffold(
      body: Column(
        children: [
          DashboardAppBarWidget(onOpenProfile: () => context.push('/profile')),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
            child: Column(
              children: [
                Row(
                  children: [
                    const Expanded(
                      child: Text(
                        'My Listings',
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                      ),
                    ),
                    ElevatedButton.icon(
                      onPressed: _addListing,
                      icon: const Icon(Icons.add, size: 18),
                      label: const Text('Create New Listing'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.navy,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      ),
                    ),
                  ],
                ),
                const Gap(10),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: ListingFilter.values.map((f) {
                      final sel = f == _filter;
                      return Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: ChoiceChip(
                          label: Text(
                            label(f),
                            style: AppTheme.hind(12, c: sel ? Colors.white : AppColors.muted),
                          ),
                          selected: sel,
                          showCheckmark: false,
                          selectedColor: const Color(0xFF1D4ED8),
                          onSelected: (_) => setState(() => _filter = f),
                        ),
                      );
                    }).toList(),
                  ),
                ),
                const Gap(10),
                Row(
                  children: [
                    Expanded(
                      child: SellerTextField(
                        _searchCtrl,
                        'Search by product name',
                        suffixIcon: Icons.search_outlined,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const Gap(10),
          Expanded(
            child: RefreshIndicator(
              onRefresh: () async {
                ref.invalidate(sellerListingProvider((sellerID: sellerId)));
                await ref.read(sellerListingProvider((sellerID: sellerId)).future);
              },
              child: listingsAsync == null
                  ? const Center(child: CircularProgressIndicator())
                  : listingsAsync.when(
                      data: (listing) {
                        final items = listing.content
                            .where((i) => _matchesFilter(i) && _matchesSearch(i))
                            .toList();

                        if (items.isEmpty) {
                          return ListView(
                            physics: const AlwaysScrollableScrollPhysics(),
                            children: [
                              const Gap(80),
                              Center(
                                child: Text(
                                  _query.isNotEmpty || _filter != ListingFilter.all
                                      ? 'No listings match your search'
                                      : 'No listings yet',
                                  style: AppTheme.hind(14, c: AppColors.muted),
                                ),
                              ),
                            ],
                          );
                        }

                        return ListView.builder(
                          physics: const AlwaysScrollableScrollPhysics(),
                          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                          itemCount: items.length,
                          itemBuilder: (context, index) {
                            final item = items[index];
                            return MyListItemWidget(
                              item: item,
                              onDelete: () {},
                              onEdit: () => context.push(
                                '/modules/seller/addListing',
                                extra: {'isEdit': true, 'listingId': item.id},
                              ),
                              onOutOfStock: () {},
                              onToggle: (v) {},
                            );
                          },
                        );
                      },
                      loading: () => const Center(child: CircularProgressIndicator()),
                      error: (e, _) => ListView(
                        physics: const AlwaysScrollableScrollPhysics(),
                        children: [
                          _ErrorView(
                            message: 'Could not load listings',
                            details: e.toString(),
                            onRetry: () =>
                                ref.invalidate(sellerListingProvider((sellerID: sellerId))),
                            onAdd: () {},
                          ),
                        ],
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  final String message;
  final String details;
  final VoidCallback onRetry;
  final VoidCallback onAdd;

  const _ErrorView({
    required this.message,
    required this.details,
    required this.onRetry,
    required this.onAdd,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline, size: 48, color: AppColors.red),
            const Gap(12),
            Text(
              message,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: AppColors.ink,
              ),
            ),
            const Gap(6),
            Text(
              details,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 12, color: AppColors.muted),
            ),
            const Gap(16),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                OutlinedButton.icon(
                  onPressed: onRetry,
                  icon: const Icon(Icons.refresh),
                  label: const Text('Retry'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.green,
                    side: const BorderSide(color: AppColors.green),
                  ),
                ),
                const Gap(12),
                FilledButton.icon(
                  onPressed: onAdd,
                  icon: const Icon(Icons.add),
                  label: const Text('Add listing'),
                  style: FilledButton.styleFrom(backgroundColor: AppColors.green),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
