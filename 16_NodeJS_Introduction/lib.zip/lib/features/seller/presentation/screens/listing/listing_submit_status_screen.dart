import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/screens/dashboard/seller_dashboard_screen.dart';

class _Header extends StatelessWidget {
  const _Header({required this.onBack});
  final VoidCallback? onBack;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(4, 4, 16, 0),
    child: Row(
      children: [
        IconButton(onPressed: onBack, icon: const Icon(Icons.arrow_back)),
        const Spacer(),
        const Text(
          'Vasundhara SEVA',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.green),
        ),
        const Spacer(),
        const Gap(48),
      ],
    ),
  );
}

class ListingSubmitStatusScreen extends ConsumerStatefulWidget {
  const ListingSubmitStatusScreen({super.key, required this.ispublished, required this.title});
  final String title;
  final bool? ispublished;

  @override
  ConsumerState<ConsumerStatefulWidget> createState() => _ListingSubmitStatusScreenState();
}

class _ListingSubmitStatusScreenState extends ConsumerState<ListingSubmitStatusScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            _Header(
              onBack: () {
                try {
                  ref.read(sellerDashboardTabProvider.notifier).state = 2;
                } catch (_) {
                  context.push('/modules/seller/listings');
                }
              },
            ),
            SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(24, 20, 24, 24),
              child: Column(
                children: [
                  const Gap(10),

                  const Text(
                    'Listing Published!',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                      color: Color(0xFF101828),
                      letterSpacing: -0.4,
                    ),
                  ),
                  const Gap(28),
                  widget.ispublished == true
                      ? const _PublishedBagIllustration()
                      : const _ClipboardIllustration(),
                  const Gap(32),

                  // Subtitle
                  Text(
                    widget.ispublished == true
                        ? 'Your listing is now live!'
                        : 'Your listing has been submitted for review.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF1D2939),
                    ),
                  ),
                  const Gap(8),
                  Text(
                    '${widget.title}\nis published and visible to customers.',
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 13, color: Color(0xFF475467), height: 1.45),
                  ),
                  const Gap(32),
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton(
                      onPressed: () {
                        ref.read(sellerDashboardTabProvider.notifier).state = 2;

                        context.go('/modules/seller/sellerDashboard');
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF027A48),
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                        elevation: 0,
                      ),
                      child: const Text(
                        'View My Listing',
                        style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
                      ),
                    ),
                  ),
                  const Gap(12),

                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: OutlinedButton(
                      onPressed: () {
                        context.push('/modules/seller/addListing');
                      },
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: Color(0xFF027A48)),
                        foregroundColor: const Color(0xFF027A48),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                      child: const Text(
                        'Add Another Listing',
                        style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ),
                  const Gap(20),

                  // Footnote from mockup
                  const Text(
                    'After admin approval, the listing is published\nand visible to customers.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 11, color: Color(0xFF98A2B3)),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ClipboardIllustration extends StatelessWidget {
  const _ClipboardIllustration();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 140,
      height: 140,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Soft blue background glow circle
          Container(
            width: 130,
            height: 130,
            decoration: const BoxDecoration(color: Color(0xFFEFF8FF), shape: BoxShape.circle),
          ),

          // Clipboard body
          Container(
            width: 78,
            height: 98,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFF2E90FA), width: 2.2),
              boxShadow: const [
                BoxShadow(color: Color(0x182E90FA), blurRadius: 16, offset: Offset(0, 8)),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Clip at top
                Center(
                  child: Container(
                    width: 32,
                    height: 8,
                    decoration: const BoxDecoration(
                      color: Color(0xFF2E90FA),
                      borderRadius: BorderRadius.vertical(bottom: Radius.circular(4)),
                    ),
                  ),
                ),
                const Gap(14),

                // Checklist line 1
                _ChecklistLine(color: const Color(0xFF2E90FA)),
                const Gap(8),
                // Checklist line 2
                _ChecklistLine(color: const Color(0xFF2E90FA)),
                const Gap(8),
                // Checklist line 3
                _ChecklistLine(color: const Color(0xFFB2DDFF)),
              ],
            ),
          ),

          // Green checkmark badge at bottom right
          Positioned(
            right: 18,
            bottom: 14,
            child: Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: const Color(0xFF12B76A),
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 3),
                boxShadow: const [
                  BoxShadow(color: Color(0x2812B76A), blurRadius: 8, offset: Offset(0, 3)),
                ],
              ),
              child: const Icon(Icons.check, size: 20, color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }
}

class _ChecklistLine extends StatelessWidget {
  const _ChecklistLine({required this.color});
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Row(
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(2)),
          ),
          const Gap(6),
          Expanded(
            child: Container(
              height: 5,
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.6),
                borderRadius: BorderRadius.circular(3),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _PublishedBagIllustration extends StatelessWidget {
  const _PublishedBagIllustration();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 170,
      height: 150,
      child: Stack(
        alignment: Alignment.center,
        children: [
          CustomPaint(size: const Size(170, 150), painter: const _ConfettiPainter()),
          Positioned(
            bottom: 12,
            child: Stack(
              clipBehavior: Clip.none,
              alignment: Alignment.center,
              children: [
                // Bag Handle
                Positioned(
                  top: -16,
                  child: Container(
                    width: 36,
                    height: 28,
                    decoration: BoxDecoration(
                      border: Border.all(color: const Color(0xFFF79009), width: 3.5),
                      borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
                    ),
                  ),
                ),
                Container(
                  width: 86,
                  height: 94,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFEC84B), Color(0xFFF79009)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: const [
                      BoxShadow(color: Color(0x30F79009), blurRadius: 18, offset: Offset(0, 8)),
                    ],
                  ),
                  child: Center(
                    child: Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.25),
                        shape: BoxShape.circle,
                      ),
                    ),
                  ),
                ),

                // Big Green Checkmark Badge overlay
                Positioned(
                  child: Container(
                    width: 42,
                    height: 42,
                    decoration: BoxDecoration(
                      color: const Color(0xFF12B76A),
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white, width: 3),
                      boxShadow: const [
                        BoxShadow(color: Color(0x3012B76A), blurRadius: 10, offset: Offset(0, 4)),
                      ],
                    ),
                    child: const Icon(Icons.check, size: 24, color: Colors.white),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ConfettiPainter extends CustomPainter {
  const _ConfettiPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..style = PaintingStyle.fill;

    // Confetti particles coordinates & colors
    final particles = [
      // Left side
      const _Particle(x: 24, y: 35, color: Color(0xFF1570EF), radius: 3.5, shape: 0),
      const _Particle(x: 32, y: 70, color: Color(0xFFF04438), radius: 4.0, shape: 1),
      const _Particle(x: 18, y: 105, color: Color(0xFF12B76A), radius: 3.0, shape: 0),
      const _Particle(x: 42, y: 25, color: Color(0xFFF79009), radius: 3.2, shape: 1),
      // Top side
      const _Particle(x: 65, y: 16, color: Color(0xFF7A5AF8), radius: 3.5, shape: 1),
      const _Particle(x: 85, y: 8, color: Color(0xFFF04438), radius: 4.2, shape: 0),
      const _Particle(x: 108, y: 18, color: Color(0xFF12B76A), radius: 3.8, shape: 1),
      // Right side
      const _Particle(x: 130, y: 32, color: Color(0xFFF79009), radius: 3.6, shape: 0),
      const _Particle(x: 148, y: 55, color: Color(0xFF1570EF), radius: 4.0, shape: 1),
      const _Particle(x: 142, y: 92, color: Color(0xFFF04438), radius: 3.2, shape: 0),
      const _Particle(x: 154, y: 118, color: Color(0xFF12B76A), radius: 3.5, shape: 1),
      // Bottom accents
      const _Particle(x: 28, y: 132, color: Color(0xFF7A5AF8), radius: 3.0, shape: 0),
      const _Particle(x: 138, y: 136, color: Color(0xFFF79009), radius: 3.4, shape: 0),
    ];

    for (final p in particles) {
      paint.color = p.color;
      if (p.shape == 0) {
        canvas.drawCircle(Offset(p.x, p.y), p.radius, paint);
      } else {
        // Draw small rotated rectangle/capsule
        canvas.save();
        canvas.translate(p.x, p.y);
        canvas.rotate(math.pi / 4);
        canvas.drawRRect(
          RRect.fromRectAndRadius(
            Rect.fromCenter(center: Offset.zero, width: p.radius * 2.2, height: p.radius * 1.2),
            const Radius.circular(2),
          ),
          paint,
        );
        canvas.restore();
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _Particle {
  const _Particle({
    required this.x,
    required this.y,
    required this.color,
    required this.radius,
    required this.shape,
  });

  final double x;
  final double y;
  final Color color;
  final double radius;
  final int shape; // 0 = circle, 1 = rect
}
