import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:intl/intl.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/core/constants/app_assets.dart';
import 'package:society_seva/features/seller/domain/entities/match_me_entity.dart';
import 'package:society_seva/features/seller/domain/entities/match_me_offer_entity.dart';
import 'package:society_seva/features/seller/presentation/provider/match_me_provider.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';

class MatchMeRequestScreen extends ConsumerStatefulWidget {
  const MatchMeRequestScreen({super.key});

  @override
  ConsumerState<MatchMeRequestScreen> createState() => _MatchMeRequestScreenState();
}

class _MatchMeRequestScreenState extends ConsumerState<MatchMeRequestScreen> {
  final _currencyFormat = NumberFormat.currency(locale: 'en_IN', symbol: '₹', decimalDigits: 0);
  final _dateFormat = DateFormat('EEE, d MMM • h:mm a');

  @override
  Widget build(BuildContext context) {
    final matchingAsync = ref.watch(matchingRequirementsProvider);
    final actionState = ref.watch(matchMeActionProvider);
    final sellerProfile = ref.watch(mySellerProfileProvider).valueOrNull;

    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        scrolledUnderElevation: 1,
        leading: IconButton(
          icon: const HugeIcon(
            icon: HugeIcons.strokeRoundedArrowLeft01,
            color: AppColors.ink,
            size: 24,
          ),
          onPressed: () => Navigator.of(context).maybePop(),
        ),
        title: Text(
          'Match Me Leads',
          style: GoogleFonts.plusJakartaSans(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: AppColors.ink,
          ),
        ),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            icon: const HugeIcon(
              icon: HugeIcons.strokeRoundedRefresh,
              color: AppColors.green,
              size: 22,
            ),
            onPressed: () => ref.invalidate(matchingRequirementsProvider),
          ),
        ],
      ),
      body: matchingAsync.when(
        loading: () => const Center(
          child: CircularProgressIndicator(color: AppColors.green),
        ),
        error: (err, stack) => _buildErrorState(err),
        data: (requirements) {
          if (requirements.isEmpty) {
            return _buildEmptyState();
          }

          return RefreshIndicator(
            color: AppColors.green,
            onRefresh: () async => ref.invalidate(matchingRequirementsProvider),
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
              itemCount: requirements.length + 1,
              separatorBuilder: (context, index) => const Gap(14),
              itemBuilder: (context, index) {
                if (index == 0) {
                  return _buildHeaderBanner(requirements.length);
                }
                final item = requirements[index - 1];
                return _buildRequirementCard(item, actionState, sellerProfile?.id ?? '');
              },
            ),
          );
        },
      ),
    );
  }

  Widget _buildHeaderBanner(int count) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppColors.greenSoft.withValues(alpha: 0.9),
            const Color(0xFFF0FDF4),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.green.withValues(alpha: 0.2)),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: AppColors.green.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(
              child: SvgPicture.asset(
                AppAssets.categoryService,
                width: 26,
                height: 26,
              ),
            ),
          ),
          const Gap(14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '$count Direct Requirement${count == 1 ? '' : 's'} Matched',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: AppColors.greenDeep,
                  ),
                ),
                const Gap(3),
                Text(
                  'Buyers in your locality are actively requesting items & services you offer.',
                  style: GoogleFonts.hind(
                    fontSize: 12,
                    color: AppColors.ink.withValues(alpha: 0.75),
                    height: 1.25,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRequirementCard(
    MatchMeEntity item,
    MatchMeActionState actionState,
    String loggedInSellerId,
  ) {
    final isActing = actionState.isActionLoading(item.id);

    // Pick SVG icon based on title/description hints
    final categorySvg = AppSvgs.getCategorySvg(item.title) ??
        AppSvgs.getCategorySvg(item.description) ??
        AppAssets.categoryFood;

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
        boxShadow: const [
          BoxShadow(
            color: Color(0x08000000),
            blurRadius: 8,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Top row: Category icon, Title, Status badge
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 10),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 44,
                  height: 44,
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: AppColors.bg,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: SvgPicture.asset(
                    categorySvg,
                    fit: BoxFit.contain,
                  ),
                ),
                const Gap(12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        item.title,
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                          color: AppColors.ink,
                          height: 1.25,
                        ),
                      ),
                      const Gap(4),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: item.status.toUpperCase() == 'OPEN'
                                  ? AppColors.greenSoft
                                  : AppColors.orangeSoft,
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(
                              item.status.toUpperCase(),
                              style: GoogleFonts.hind(
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                                color: item.status.toUpperCase() == 'OPEN'
                                    ? AppColors.green
                                    : AppColors.orange,
                              ),
                            ),
                          ),
                          const Gap(8),
                          Text(
                            item.quantity > 0 ? '${item.quantity} ${item.unit}' : item.unit,
                            style: GoogleFonts.hind(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: AppColors.muted,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Description
          if (item.description.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                item.description,
                style: GoogleFonts.hind(
                  fontSize: 13,
                  color: AppColors.ink.withValues(alpha: 0.85),
                  height: 1.35,
                ),
              ),
            ),

          const Gap(12),
          const Divider(height: 1, color: AppColors.border),
          const Gap(10),

          // Budget & Timing Details
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                // Budget pill
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                    decoration: BoxDecoration(
                      color: AppColors.greenSoft.withValues(alpha: 0.5),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: AppColors.green.withValues(alpha: 0.2)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'BUDGET',
                          style: GoogleFonts.hind(
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 0.5,
                            color: AppColors.greenDeep,
                          ),
                        ),
                        const Gap(2),
                        Text(
                          '${_currencyFormat.format(item.budgetMin)} - ${_currencyFormat.format(item.budgetMax)}',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            color: AppColors.green,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const Gap(10),
                // Required by pill
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                    decoration: BoxDecoration(
                      color: AppColors.bg,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'REQUIRED BY',
                          style: GoogleFonts.hind(
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 0.5,
                            color: AppColors.muted,
                          ),
                        ),
                        const Gap(2),
                        Text(
                          _dateFormat.format(item.requiredBy),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: GoogleFonts.hind(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: AppColors.ink,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Location
          if (item.address.isNotEmpty || item.city.isNotEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Padding(
                    padding: EdgeInsets.only(top: 2),
                    child: HugeIcon(
                      icon: HugeIcons.strokeRoundedLocation01,
                      size: 15,
                      color: AppColors.muted,
                    ),
                  ),
                  const Gap(6),
                  Expanded(
                    child: Text(
                      [
                        item.address,
                        item.city,
                        if (item.pinCode.isNotEmpty) item.pinCode,
                      ].where((s) => s.isNotEmpty).join(', '),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.hind(
                        fontSize: 12,
                        color: AppColors.muted,
                        height: 1.3,
                      ),
                    ),
                  ),
                ],
              ),
            ),

          const Gap(14),
          const Divider(height: 1, color: AppColors.border),

          // Bottom Bar: Offers Count & Action Buttons
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                // View offers button
                TextButton.icon(
                  style: TextButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                    visualDensity: VisualDensity.compact,
                  ),
                  icon: const HugeIcon(
                    icon: HugeIcons.strokeRoundedFile02,
                    size: 16,
                    color: AppColors.ink,
                  ),
                  label: Text(
                    '${item.offerCount} Offer${item.offerCount == 1 ? '' : 's'}',
                    style: GoogleFonts.hind(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: AppColors.ink,
                    ),
                  ),
                  onPressed: () => _openViewOffersSheet(context, item, loggedInSellerId),
                ),
                const Spacer(),

                // Not interested button
                OutlinedButton(
                  onPressed: isActing
                      ? null
                      : () => _handleNotInterested(item.id),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.muted,
                    side: const BorderSide(color: AppColors.border),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    visualDensity: VisualDensity.compact,
                  ),
                  child: Text(
                    'Not Interested',
                    style: GoogleFonts.hind(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                const Gap(8),

                // Post Offer button
                FilledButton.icon(
                  onPressed: isActing
                      ? null
                      : () => _openPostOfferSheet(context, item, loggedInSellerId),
                  icon: const HugeIcon(
                    icon: HugeIcons.strokeRoundedTag01,
                    size: 15,
                    color: Colors.white,
                  ),
                  label: Text(
                    'Send Offer',
                    style: GoogleFonts.hind(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                  style: FilledButton.styleFrom(
                    backgroundColor: AppColors.green,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    visualDensity: VisualDensity.compact,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _handleNotInterested(String requirementId) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(
          'Dismiss Requirement?',
          style: GoogleFonts.plusJakartaSans(fontSize: 17, fontWeight: FontWeight.w700),
        ),
        content: Text(
          'This requirement will be removed from your Match Me leads.',
          style: GoogleFonts.hind(fontSize: 14),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: Text('Cancel', style: GoogleFonts.hind(color: AppColors.muted)),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.red),
            onPressed: () => Navigator.of(ctx).pop(true),
            child: Text('Dismiss', style: GoogleFonts.hind(fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );

    if (confirmed != true || !mounted) return;

    final success = await ref
        .read(matchMeActionProvider.notifier)
        .markNotInterested(requirementId);

    if (!mounted) return;

    if (success) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Requirement dismissed.', style: GoogleFonts.hind()),
          backgroundColor: AppColors.ink,
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }

  void _openPostOfferSheet(BuildContext context, MatchMeEntity item, String sellerId) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _PostOfferBottomSheet(
        requirement: item,
        sellerId: sellerId,
      ),
    );
  }

  void _openViewOffersSheet(BuildContext context, MatchMeEntity item, String sellerId) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _ViewOffersBottomSheet(
        requirement: item,
        loggedInSellerId: sellerId,
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 80,
              height: 80,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.greenSoft,
                shape: BoxShape.circle,
              ),
              child: SvgPicture.asset(
                AppAssets.categoryService,
                colorFilter: const ColorFilter.mode(AppColors.green, BlendMode.srcIn),
              ),
            ),
            const Gap(20),
            Text(
              'No Matching Leads Right Now',
              textAlign: TextAlign.center,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: AppColors.ink,
              ),
            ),
            const Gap(8),
            Text(
              'When buyers in your area post custom requests in your categories, they will appear right here.',
              textAlign: TextAlign.center,
              style: GoogleFonts.hind(
                fontSize: 14,
                color: AppColors.muted,
                height: 1.4,
              ),
            ),
            const Gap(24),
            OutlinedButton.icon(
              icon: const HugeIcon(
                icon: HugeIcons.strokeRoundedRefresh,
                size: 16,
                color: AppColors.green,
              ),
              label: Text(
                'Refresh Leads',
                style: GoogleFonts.hind(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: AppColors.green,
                ),
              ),
              onPressed: () => ref.invalidate(matchingRequirementsProvider),
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: AppColors.green),
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildErrorState(Object error) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const HugeIcon(
              icon: HugeIcons.strokeRoundedAlertCircle,
              size: 48,
              color: AppColors.red,
            ),
            const Gap(16),
            Text(
              'Unable to Load Match Me Leads',
              textAlign: TextAlign.center,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 17,
                fontWeight: FontWeight.w700,
                color: AppColors.ink,
              ),
            ),
            const Gap(8),
            Text(
              error.toString(),
              textAlign: TextAlign.center,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              style: GoogleFonts.hind(
                fontSize: 13,
                color: AppColors.muted,
              ),
            ),
            const Gap(20),
            FilledButton.icon(
              icon: const HugeIcon(
                icon: HugeIcons.strokeRoundedRefresh,
                size: 16,
                color: Colors.white,
              ),
              label: Text(
                'Try Again',
                style: GoogleFonts.hind(fontSize: 14, fontWeight: FontWeight.w600),
              ),
              onPressed: () => ref.invalidate(matchingRequirementsProvider),
              style: FilledButton.styleFrom(
                backgroundColor: AppColors.green,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// POST OFFER BOTTOM SHEET
// ---------------------------------------------------------------------------
class _PostOfferBottomSheet extends ConsumerStatefulWidget {
  const _PostOfferBottomSheet({
    required this.requirement,
    required this.sellerId,
  });

  final MatchMeEntity requirement;
  final String sellerId;

  @override
  ConsumerState<_PostOfferBottomSheet> createState() => _PostOfferBottomSheetState();
}

class _PostOfferBottomSheetState extends ConsumerState<_PostOfferBottomSheet> {
  final _formKey = GlobalKey<FormState>();
  final _priceController = TextEditingController();
  final _notesController = TextEditingController();

  late DateTime _availableFrom;
  late DateTime _availableTo;
  bool _isSubmitting = false;

  @override
  void initState() {
    super.initState();
    _availableFrom = DateTime.now();
    _availableTo = widget.requirement.requiredBy.isAfter(DateTime.now())
        ? widget.requirement.requiredBy
        : DateTime.now().add(const Duration(days: 3));
    // Pre-populate with budget average
    if (widget.requirement.budgetMin > 0) {
      _priceController.text = widget.requirement.budgetMin.toString();
    }
  }

  @override
  void dispose() {
    _priceController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _pickDate({required bool isFrom}) async {
    final initialDate = isFrom ? _availableFrom : _availableTo;
    final picked = await showDatePicker(
      context: context,
      initialDate: initialDate,
      firstDate: DateTime.now().subtract(const Duration(days: 1)),
      lastDate: DateTime.now().add(const Duration(days: 365)),
      builder: (context, child) => Theme(
        data: Theme.of(context).copyWith(
          colorScheme: const ColorScheme.light(primary: AppColors.green),
        ),
        child: child!,
      ),
    );

    if (picked != null) {
      setState(() {
        if (isFrom) {
          _availableFrom = DateTime(
            picked.year,
            picked.month,
            picked.day,
            _availableFrom.hour,
            _availableFrom.minute,
          );
        } else {
          _availableTo = DateTime(
            picked.year,
            picked.month,
            picked.day,
            _availableTo.hour,
            _availableTo.minute,
          );
        }
      });
    }
  }

  Future<void> _submitOffer() async {
    if (!_formKey.currentState!.validate()) return;

    final sellerId = widget.sellerId.isNotEmpty
        ? widget.sellerId
        : (ref.read(mySellerProfileProvider).valueOrNull?.id ?? '');

    if (sellerId.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Seller profile not loaded. Please ensure you are logged in as a seller.',
            style: GoogleFonts.hind(),
          ),
          backgroundColor: AppColors.red,
        ),
      );
      return;
    }

    setState(() => _isSubmitting = true);

    final request = CreateMatchMeOfferRequest(
      sellerId: sellerId,
      offeredPrice: _priceController.text.trim(),
      notes: _notesController.text.trim(),
      availableFrom: _availableFrom,
      availableTo: _availableTo,
    );

    final success = await ref.read(matchMeActionProvider.notifier).postOffer(
          requirementId: widget.requirement.id,
          request: request,
        );

    setState(() => _isSubmitting = false);

    if (!mounted) return;

    if (success) {
      Navigator.of(context).pop();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Offer posted successfully!',
            style: GoogleFonts.hind(color: Colors.white, fontWeight: FontWeight.w600),
          ),
          backgroundColor: AppColors.green,
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Failed to post offer. Please try again.',
            style: GoogleFonts.hind(),
          ),
          backgroundColor: AppColors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('EEE, d MMM yyyy');

    return Container(
      padding: EdgeInsets.only(
        top: 20,
        left: 20,
        right: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              // Top drag bar
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppColors.border,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const Gap(16),

              // Title
              Text(
                'Post Offer to Buyer',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: AppColors.ink,
                ),
              ),
              const Gap(4),
              Text(
                'Requirement: "${widget.requirement.title}"',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.hind(
                  fontSize: 13,
                  color: AppColors.muted,
                ),
              ),
              const Gap(12),

              // Budget reference card
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: AppColors.greenSoft.withValues(alpha: 0.5),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppColors.green.withValues(alpha: 0.2)),
                ),
                child: Row(
                  children: [
                    const HugeIcon(
                      icon: HugeIcons.strokeRoundedInformationCircle,
                      size: 18,
                      color: AppColors.green,
                    ),
                    const Gap(8),
                    Expanded(
                      child: Text(
                        'Buyer\'s Budget: ₹${widget.requirement.budgetMin} - ₹${widget.requirement.budgetMax} • Qty: ${widget.requirement.quantity} ${widget.requirement.unit}',
                        style: GoogleFonts.hind(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: AppColors.greenDeep,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const Gap(16),

              // Offered Price Input
              Text(
                'Your Price Quote (₹) *',
                style: GoogleFonts.hind(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: AppColors.ink,
                ),
              ),
              const Gap(6),
              TextFormField(
                controller: _priceController,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(
                  prefixText: '₹ ',
                  prefixStyle: GoogleFonts.plusJakartaSans(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: AppColors.ink,
                  ),
                  hintText: 'e.g. 3500.00',
                  hintStyle: GoogleFonts.hind(color: AppColors.muted),
                  filled: true,
                  fillColor: AppColors.bg,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: AppColors.border),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: AppColors.border),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: AppColors.green, width: 1.5),
                  ),
                ),
                validator: (val) {
                  if (val == null || val.trim().isEmpty) {
                    return 'Please enter your quote price';
                  }
                  final numVal = double.tryParse(val.trim());
                  if (numVal == null || numVal <= 0) {
                    return 'Please enter a valid positive amount';
                  }
                  return null;
                },
              ),
              const Gap(16),

              // Notes / Proposal description
              Text(
                'Offer Notes & Proposal Details *',
                style: GoogleFonts.hind(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: AppColors.ink,
                ),
              ),
              const Gap(6),
              TextFormField(
                controller: _notesController,
                maxLines: 3,
                decoration: InputDecoration(
                  hintText: 'Describe deliverables, menu, timing, inclusion/exclusions...',
                  hintStyle: GoogleFonts.hind(color: AppColors.muted, fontSize: 13),
                  filled: true,
                  fillColor: AppColors.bg,
                  contentPadding: const EdgeInsets.all(12),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: AppColors.border),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: AppColors.border),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: AppColors.green, width: 1.5),
                  ),
                ),
                validator: (val) {
                  if (val == null || val.trim().isEmpty) {
                    return 'Please describe what is included in your offer';
                  }
                  return null;
                },
              ),
              const Gap(16),

              // Validity / Availability Dates
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Available From',
                          style: GoogleFonts.hind(
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            color: AppColors.ink,
                          ),
                        ),
                        const Gap(6),
                        InkWell(
                          onTap: () => _pickDate(isFrom: true),
                          borderRadius: BorderRadius.circular(12),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                            decoration: BoxDecoration(
                              color: AppColors.bg,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: AppColors.border),
                            ),
                            child: Row(
                              children: [
                                const HugeIcon(
                                  icon: HugeIcons.strokeRoundedCalendar01,
                                  size: 15,
                                  color: AppColors.green,
                                ),
                                const Gap(6),
                                Expanded(
                                  child: Text(
                                    dateFormat.format(_availableFrom),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: GoogleFonts.hind(fontSize: 12, color: AppColors.ink),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Gap(12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Available To',
                          style: GoogleFonts.hind(
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            color: AppColors.ink,
                          ),
                        ),
                        const Gap(6),
                        InkWell(
                          onTap: () => _pickDate(isFrom: false),
                          borderRadius: BorderRadius.circular(12),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                            decoration: BoxDecoration(
                              color: AppColors.bg,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: AppColors.border),
                            ),
                            child: Row(
                              children: [
                                const HugeIcon(
                                  icon: HugeIcons.strokeRoundedCalendar01,
                                  size: 15,
                                  color: AppColors.green,
                                ),
                                const Gap(6),
                                Expanded(
                                  child: Text(
                                    dateFormat.format(_availableTo),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: GoogleFonts.hind(fontSize: 12, color: AppColors.ink),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const Gap(24),

              // Submit Button
              SizedBox(
                width: double.infinity,
                height: 48,
                child: FilledButton(
                  onPressed: _isSubmitting ? null : _submitOffer,
                  style: FilledButton.styleFrom(
                    backgroundColor: AppColors.green,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: _isSubmitting
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                        )
                      : Text(
                          'Send Offer to Buyer',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                          ),
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// VIEW OFFERS BOTTOM SHEET
// ---------------------------------------------------------------------------
class _ViewOffersBottomSheet extends ConsumerWidget {
  const _ViewOffersBottomSheet({
    required this.requirement,
    required this.loggedInSellerId,
  });

  final MatchMeEntity requirement;
  final String loggedInSellerId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final offersAsync = ref.watch(requirementOffersProvider(requirement.id));
    final currency = NumberFormat.currency(locale: 'en_IN', symbol: '₹', decimalDigits: 0);
    final dateFormat = DateFormat('d MMM yyyy, h:mm a');

    return Container(
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.75,
      ),
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: AppColors.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          const Gap(16),

          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Posted Offers',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: AppColors.ink,
                      ),
                    ),
                    const Gap(2),
                    Text(
                      'For: "${requirement.title}"',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.hind(fontSize: 13, color: AppColors.muted),
                    ),
                  ],
                ),
              ),
              IconButton(
                icon: const HugeIcon(
                  icon: HugeIcons.strokeRoundedRefresh,
                  size: 20,
                  color: AppColors.green,
                ),
                onPressed: () => ref.invalidate(requirementOffersProvider(requirement.id)),
              ),
            ],
          ),
          const Gap(12),
          const Divider(height: 1, color: AppColors.border),
          const Gap(12),

          Expanded(
            child: offersAsync.when(
              loading: () => const Center(
                child: CircularProgressIndicator(color: AppColors.green),
              ),
              error: (err, _) => Center(
                child: Text(
                  'Unable to load offers: $err',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.hind(color: AppColors.red),
                ),
              ),
              data: (offers) {
                if (offers.isEmpty) {
                  return Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const HugeIcon(
                            icon: HugeIcons.strokeRoundedFile02,
                            size: 40,
                            color: AppColors.muted,
                          ),
                          const Gap(12),
                          Text(
                            'No Offers Posted Yet',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              color: AppColors.ink,
                            ),
                          ),
                          const Gap(6),
                          Text(
                            'Be the first seller to send an offer to this buyer!',
                            textAlign: TextAlign.center,
                            style: GoogleFonts.hind(color: AppColors.muted, fontSize: 13),
                          ),
                        ],
                      ),
                    ),
                  );
                }

                return ListView.separated(
                  itemCount: offers.length,
                  separatorBuilder: (context, index) => const Gap(12),
                  itemBuilder: (context, idx) {
                    final offer = offers[idx];
                    final isMyOffer = loggedInSellerId.isNotEmpty &&
                        offer.sellerId == loggedInSellerId;

                    return Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: isMyOffer
                            ? AppColors.greenSoft.withValues(alpha: 0.35)
                            : AppColors.bg,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: isMyOffer ? AppColors.green : AppColors.border,
                          width: isMyOffer ? 1.5 : 1,
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Row(
                                  children: [
                                    Text(
                                      offer.sellerName.isNotEmpty
                                          ? offer.sellerName
                                          : 'Seller ${offer.sellerId.substring(0, offer.sellerId.length > 6 ? 6 : offer.sellerId.length)}',
                                      style: GoogleFonts.plusJakartaSans(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w700,
                                        color: AppColors.ink,
                                      ),
                                    ),
                                    if (isMyOffer) ...[
                                      const Gap(6),
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 6, vertical: 2),
                                        decoration: BoxDecoration(
                                          color: AppColors.green,
                                          borderRadius: BorderRadius.circular(4),
                                        ),
                                        child: Text(
                                          'YOU',
                                          style: GoogleFonts.hind(
                                            fontSize: 9,
                                            fontWeight: FontWeight.w700,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ],
                                ),
                              ),
                              // Status badge
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                decoration: BoxDecoration(
                                  color: offer.isAccepted
                                      ? AppColors.greenSoft
                                      : (offer.isRejected
                                          ? AppColors.redSoft
                                          : AppColors.orangeSoft),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Text(
                                  offer.status.toUpperCase(),
                                  style: GoogleFonts.hind(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                    color: offer.isAccepted
                                        ? AppColors.green
                                        : (offer.isRejected ? AppColors.red : AppColors.orange),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const Gap(8),

                          // Price
                          Text(
                            currency.format(offer.offeredPrice),
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                              color: AppColors.green,
                            ),
                          ),
                          const Gap(4),

                          // Notes
                          if (offer.notes.isNotEmpty)
                            Text(
                              offer.notes,
                              style: GoogleFonts.hind(
                                fontSize: 13,
                                color: AppColors.ink.withValues(alpha: 0.85),
                                height: 1.35,
                              ),
                            ),

                          // Dates
                          if (offer.availableFrom != null || offer.availableTo != null) ...[
                            const Gap(8),
                            Row(
                              children: [
                                const HugeIcon(
                                  icon: HugeIcons.strokeRoundedCalendar01,
                                  size: 14,
                                  color: AppColors.muted,
                                ),
                                const Gap(6),
                                Expanded(
                                  child: Text(
                                    'Available: ${offer.availableFrom != null ? DateFormat('d MMM').format(offer.availableFrom!) : ''} - ${offer.availableTo != null ? DateFormat('d MMM yyyy').format(offer.availableTo!) : ''}',
                                    style: GoogleFonts.hind(
                                      fontSize: 12,
                                      color: AppColors.muted,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],

                          if (offer.createdAt != null) ...[
                            const Gap(4),
                            Text(
                              'Posted: ${dateFormat.format(offer.createdAt!)}',
                              style: GoogleFonts.hind(fontSize: 11, color: AppColors.muted),
                            ),
                          ],
                        ],
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
