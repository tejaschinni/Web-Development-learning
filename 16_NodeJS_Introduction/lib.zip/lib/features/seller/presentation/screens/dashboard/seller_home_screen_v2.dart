import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_listing_provider.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_order_provider.dart';
import 'package:society_seva/features/seller/presentation/screens/dashboard/seller_dashboard_screen.dart';
import 'package:society_seva/features/seller/presentation/widgets/dashboard/dashboard_card_wiget.dart';
import 'package:society_seva/features/seller/presentation/widgets/dashboard/dashboard_listing_section.dart';
import 'package:society_seva/features/seller/presentation/widgets/dashboard/dashboard_profile_section.dart';
import 'package:society_seva/features/seller/presentation/widgets/dashboard/dashboard_section_header_widget.dart';
import 'package:society_seva/features/seller/presentation/widgets/dashboard_app_bar_widget.dart';

const _twoColumnBreakpoint = 700.0;

class SellerHomeScreenV2 extends ConsumerWidget {
  const SellerHomeScreenV2({super.key});

  void _createListing(BuildContext context) {
    context.push('/modules/seller/addListing');
  }

  void _navigateToOrders(BuildContext context, WidgetRef ref) {
    try {
      ref.read(sellerDashboardTabProvider.notifier).state = 1;
    } catch (_) {
      context.push('/modules/seller/orders');
    }
  }

  void _navigateToListings(BuildContext context, WidgetRef ref) {
    try {
      ref.read(sellerDashboardTabProvider.notifier).state = 2;
    } catch (_) {
      context.push('/modules/seller/listings');
    }
  }

  void _navigateToProfile(BuildContext context, WidgetRef ref) {
    try {
      ref.read(sellerDashboardTabProvider.notifier).state = 4;
    } catch (_) {
      context.push('/profile');
    }
  }

  void _navigateToSellerProfileEdit(BuildContext context) {
    context.push('/modules/seller/onboarding', extra: true);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sellerProfileAsync = ref.watch(mySellerProfileProvider);
    final sellerId = sellerProfileAsync.valueOrNull?.id ?? '';
    final hasSeller = sellerId.isNotEmpty;

    final listingsAsync = hasSeller ? ref.watch(sellerListingProvider((sellerID: sellerId))) : null;
    final ordersAsync = hasSeller ? ref.watch(sellerOrdersProvider(sellerId)) : null;

    final listings = listingsAsync?.valueOrNull?.content;
    final orders = ordersAsync?.valueOrNull?.content;

    const pendingStatuses = {'CREATED', 'PAID', 'PENDING', 'REQUESTED'};
    const preparingStatuses = {'ACCEPTED', 'PREPARING', 'IN_SERVICE'};
    const outForDeliveryStatuses = {'READY_FOR_PICKUP', 'OUT_FOR_DELIVERY'};
    const completedStatuses = {'COMPLETED', 'DELIVERED'};

    final activeListingsCount =
        listings?.where((l) {
          final availability = l.availabilityStatus.toUpperCase();
          final approval = l.approvalStatus.toUpperCase();
          return availability == 'AVAILABLE' || approval == 'APPROVED' || approval == 'PUBLISHED';
        }).length ??
        0;

    final pendingOrders = orders
        ?.where((o) => pendingStatuses.contains(o.orderStatus.toUpperCase()))
        .toList();
    final preparingOrders = orders
        ?.where((o) => preparingStatuses.contains(o.orderStatus.toUpperCase()))
        .toList();
    final outForDeliveryOrders = orders
        ?.where((o) => outForDeliveryStatuses.contains(o.orderStatus.toUpperCase()))
        .toList();
    final completedOrders = orders
        ?.where((o) => completedStatuses.contains(o.orderStatus.toUpperCase()))
        .toList();

    final totalEarnings = completedOrders?.fold<double>(
      0.0,
      (sum, o) => sum + (o.sellerEarning > 0 ? o.sellerEarning : o.totalAmount),
    );

    String countText(int? n) => n?.toString() ?? '-';
    final earningsText = totalEarnings == null ? '-' : totalEarnings.toStringAsFixed(0);
    final bool isLoading = (listingsAsync?.isLoading ?? false) || (ordersAsync?.isLoading ?? false);
    if (isLoading) {
      return Scaffold(
        backgroundColor: AppColors.bg,
        body: const Center(child: CircularProgressIndicator(color: AppColors.green)),
      );
    }
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final twoCol = constraints.maxWidth >= _twoColumnBreakpoint;
            void onCreate() => _createListing(context);
            void onOrders() => _navigateToOrders(context, ref);
            void onListings() => _navigateToListings(context, ref);
            void onProfile() => _navigateToProfile(context, ref);
            void onSellerProfileEdit() => _navigateToSellerProfileEdit(context);

            Widget pair(Widget a, Widget b) => twoCol
                ? Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(child: a),
                      const Gap(12),
                      Expanded(child: b),
                    ],
                  )
                : Column(children: [a, const Gap(12), b]);

            return Column(
              children: [
                DashboardAppBarWidget(onOpenProfile: onProfile),
                Expanded(
                  child: RefreshIndicator(
                    onRefresh: () async {
                      ref.invalidate(mySellerProfileProvider);
                      ref.invalidate(sellerListingProvider((sellerID: sellerId)));
                      ref.invalidate(sellerOrdersProvider(sellerId));
                    },
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                      child: Center(
                        child: ConstrainedBox(
                          constraints: const BoxConstraints(maxWidth: 1100),
                          child: Column(
                            children: [
                              DashboardProfileSection(
                                onViewProfile: onProfile,
                                onEditAvatar: onSellerProfileEdit,
                              ),
                              const Gap(12),
                              _QuickActions(
                                onCreateListing: onCreate,
                                onViewListings: onListings,
                                onViewOrders: onOrders,
                                activeListingsCount: countText(activeListingsCount),
                                pendingOrdersCount: countText(pendingOrders?.length),
                                monthlyEarnings: '₹$earningsText',
                              ),
                              const Gap(12),
                              _OrderOverview(
                                onViewAllOrders: onOrders,
                                pendingCount: (pendingOrders?.length ?? 0).toString(),
                                preparingCount: (preparingOrders?.length ?? 0).toString(),
                                outForDeliveryCount: (outForDeliveryOrders?.length ?? 0).toString(),
                                completedCount: (completedOrders?.length ?? 0).toString(),
                              ),
                              const Gap(12),
                              pair(
                                DashboardListingSection(
                                  onCreate: onCreate,
                                  onViewAll: onListings,
                                  listing: listings ?? [],
                                ),
                                _EarningsOverview(onViewOrders: onOrders),
                              ),
                              const Gap(12),
                              pair(
                                _ProfileDocuments(onOpenSellerProfile: onSellerProfileEdit),
                                const _HelpSupport(),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _Pill extends StatelessWidget {
  const _Pill(this.text, {this.icon});
  final String text;
  final IconData? icon;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
    decoration: BoxDecoration(
      color: const Color(0xFFDDF3E2),
      borderRadius: BorderRadius.circular(20),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (icon != null) ...[Icon(icon, size: 13, color: AppColors.green), const Gap(4)],
        Text(
          text,
          style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.green),
        ),
      ],
    ),
  );
}

class _ListRow extends StatelessWidget {
  const _ListRow({required this.icon, required this.label, this.value, this.onTap});
  final IconData icon;
  final String label;
  final String? value;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    child: Padding(
      padding: const EdgeInsets.symmetric(vertical: 11),
      child: Row(
        children: [
          Icon(icon, size: 20, color: AppColors.navy),
          const Gap(12),
          Expanded(child: Text(label, style: AppTheme.hind(13.5))),
          if (value != null) Text(value!, style: AppTheme.hind(13.5, w: FontWeight.w700)),
          const Gap(4),
          const Icon(Icons.chevron_right, size: 20, color: AppColors.muted),
        ],
      ),
    ),
  );
}

class _Action {
  const _Action(this.icon, this.title, this.subtitle, this.bg, this.fg, {this.subtitleColor});
  final IconData icon;
  final String title;
  final String subtitle;
  final Color bg;
  final Color fg;
  final Color? subtitleColor;
}

class _QuickActions extends StatelessWidget {
  const _QuickActions({
    required this.onCreateListing,
    required this.onViewListings,
    required this.onViewOrders,
    this.activeListingsCount = '-',
    this.pendingOrdersCount = '-',
    this.monthlyEarnings = '-',
  });

  final VoidCallback onCreateListing;
  final VoidCallback onViewListings;
  final VoidCallback onViewOrders;
  final String activeListingsCount;
  final String pendingOrdersCount;
  final String monthlyEarnings;

  void _handleAction(BuildContext context, _Action a) {
    if (a.title.startsWith('Create')) {
      onCreateListing();
    } else if (a.title.startsWith('My Listings')) {
      onViewListings();
    } else if (a.title.startsWith('Orders')) {
      onViewOrders();
    } else if (a.title.startsWith('Availability')) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Seller availability schedule feature is coming soon')),
      );
    } else if (a.title.startsWith('Payouts')) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Seller payouts and wallet details screen is coming soon')),
      );
    } else if (a.title.startsWith('Reports')) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Seller reports and analytics screen is coming soon')),
      );
    }
  }

  Widget _tile(BuildContext context, _Action a, {double? width}) => SizedBox(
    width: width,
    child: InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: () => _handleAction(context, a),
      child: Container(
        padding: const EdgeInsets.fromLTRB(10, 12, 8, 12),
        constraints: const BoxConstraints(minHeight: 108),
        decoration: BoxDecoration(color: a.bg, borderRadius: BorderRadius.circular(12)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            a.title.startsWith('Create')
                ? CircleAvatar(
                    radius: 15,
                    backgroundColor: a.fg,
                    child: Icon(a.icon, size: 18, color: Colors.white),
                  )
                : Icon(a.icon, size: 28, color: a.fg),
            const Gap(10),
            Text(
              a.title,
              style: AppTheme.hind(12.5, w: FontWeight.w700, c: AppColors.blue),
            ),
            if (a.subtitle.isNotEmpty) ...[
              const Gap(2),
              Text(
                a.subtitle,
                style: TextStyle(fontSize: 11, color: a.subtitleColor ?? AppColors.muted),
              ),
            ],
          ],
        ),
      ),
    ),
  );

  @override
  Widget build(BuildContext context) {
    final items = [
      const _Action(Icons.add, 'Create New\nListing', '', Color(0xFFE3F5E8), AppColors.green),
      _Action(
        Icons.list_alt,
        'My Listings',
        '$activeListingsCount Active',
        const Color(0xFFEBE6FA),
        const Color(0xFF5B3FC4),
      ),
      _Action(
        Icons.shopping_bag,
        'Orders',
        '$pendingOrdersCount Pending',
        const Color(0xFFFFEBD6),
        const Color(0xFFE67A1F),
        subtitleColor: const Color(0xFFE67A1F),
      ),
      const _Action(
        Icons.calendar_month,
        'Availability',
        'Set Schedule',
        Color(0xFFDDEBFF),
        Color(0xFF1B5FD6),
      ),
      _Action(
        Icons.account_balance_wallet,
        'Payouts',
        '${monthlyEarnings != '-' ? monthlyEarnings : '-'}\nThis Month',
        const Color(0xFFFFE1E6),
        const Color(0xFFD6334C),
        subtitleColor: const Color(0xFFD6334C),
      ),
      const _Action(Icons.bar_chart, 'Reports', 'View Sales', Color(0xFFEBE6FA), Color(0xFF5B3FC4)),
    ];
    return LayoutBuilder(
      builder: (context, c) {
        if (c.maxWidth >= 640) {
          return Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              for (var i = 0; i < items.length; i++) ...[
                Expanded(child: _tile(context, items[i])),
                if (i != items.length - 1) const Gap(10),
              ],
            ],
          );
        }
        return SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          physics: const BouncingScrollPhysics(),
          child: IntrinsicHeight(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                for (var i = 0; i < items.length; i++) ...[
                  _tile(context, items[i], width: 108),
                  if (i != items.length - 1) const Gap(10),
                ],
              ],
            ),
          ),
        );
      },
    );
  }
}

class _OrderStat {
  const _OrderStat(this.icon, this.count, this.label, this.bg, this.fg);
  final IconData icon;
  final String count;
  final String label;
  final Color bg;
  final Color fg;
}

class _OrderOverview extends StatelessWidget {
  const _OrderOverview({
    this.onViewAllOrders,
    required this.pendingCount,
    required this.preparingCount,
    required this.outForDeliveryCount,
    required this.completedCount,
  });
  final VoidCallback? onViewAllOrders;
  final String pendingCount;
  final String preparingCount;
  final String outForDeliveryCount;
  final String completedCount;

  @override
  Widget build(BuildContext context) {
    final List<_OrderStat> stats = [
      _OrderStat(
        Icons.hourglass_bottom,
        pendingCount,
        'Pending\nAcceptance',
        Color(0xFFFFF0DD),
        Color(0xFFE67A1F),
      ),
      _OrderStat(
        Icons.soup_kitchen,
        preparingCount,
        'Preparing\n',
        Color(0xFFDDEBFF),
        Color(0xFF1B5FD6),
      ),
      _OrderStat(
        Icons.local_shipping,
        outForDeliveryCount,
        'Out for\nDelivery',
        Color(0xFFDDF3E2),
        AppColors.green,
      ),
      _OrderStat(
        Icons.check_circle,
        completedCount,
        'Completed\n(This Month)',
        Color(0xFFEDEFF3),
        Color(0xFF4A5568),
      ),
    ];
    return DashboardCardWidget(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          DashboardSectionHeaderWidget(
            'Order Overview',
            action: 'View All Orders',
            onActionTap: onViewAllOrders,
          ),
          LayoutBuilder(
            builder: (context, c) {
              const gap = 8.0;
              final cols = c.maxWidth >= 440 ? 4 : 2;
              final w = (c.maxWidth - gap * (cols - 1)) / cols;
              return Wrap(
                spacing: gap,
                runSpacing: gap,
                children: [
                  for (final s in stats)
                    SizedBox(
                      width: w,
                      child: InkWell(
                        onTap: onViewAllOrders,
                        borderRadius: BorderRadius.circular(12),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
                          decoration: BoxDecoration(
                            color: s.bg,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(
                            children: [
                              Icon(s.icon, size: 26, color: s.fg),
                              const Gap(8),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      s.count,
                                      style: AppTheme.hind(
                                        20,
                                        w: FontWeight.w800,
                                        c: AppColors.navy,
                                      ),
                                    ),
                                    Text(
                                      s.label,
                                      style: const TextStyle(
                                        fontSize: 10.5,
                                        color: Color(0xFF33425B),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }
}

class _EarningsOverview extends StatelessWidget {
  const _EarningsOverview({this.onViewOrders});
  final VoidCallback? onViewOrders;

  Widget _bar(double h) => Container(
    width: 8,
    height: h,
    decoration: BoxDecoration(color: AppColors.green, borderRadius: BorderRadius.circular(3)),
  );

  @override
  Widget build(BuildContext context) {
    return DashboardCardWidget(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          DashboardSectionHeaderWidget(
            'Earnings Overview',
            action: 'View Details',
            onActionTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Detailed earnings statement screen is coming soon')),
              );
            },
          ),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFFDDF3E2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Total Earnings (This Month)',
                        style: TextStyle(fontSize: 11.5, color: Color(0xFF33425B)),
                      ),
                      const Gap(4),
                      Wrap(
                        crossAxisAlignment: WrapCrossAlignment.center,
                        spacing: 8,
                        children: [
                          Text(
                            '₹ 5,240',
                            style: AppTheme.hind(24, w: FontWeight.w800, c: AppColors.blue),
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.trending_up, size: 16, color: AppColors.green),
                              const Gap(2),
                              Text(
                                '+18%',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.green,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [_bar(16), const Gap(4), _bar(26), const Gap(4), _bar(40)],
                ),
              ],
            ),
          ),
          const Gap(6),
          _ListRow(
            icon: Icons.assignment_turned_in_outlined,
            label: 'Completed Orders',
            value: '12',
            onTap: onViewOrders,
          ),
          const Divider(height: 1, color: AppColors.border),
          _ListRow(
            icon: Icons.hourglass_empty,
            label: 'Pending Payout',
            value: '₹ 2,480',
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Pending payouts details screen is coming soon')),
              );
            },
          ),
          const Divider(height: 1, color: AppColors.border),
          _ListRow(
            icon: Icons.account_balance_wallet_outlined,
            label: 'Total Payout (Till Date)',
            value: '₹ 18,760',
            onTap: () {
              ScaffoldMessenger.of(
                context,
              ).showSnackBar(const SnackBar(content: Text('Payout history screen is coming soon')));
            },
          ),
        ],
      ),
    );
  }
}

// ───────────────────────── profile & help ─────────────────────────

class _ProfileDocuments extends StatelessWidget {
  const _ProfileDocuments({this.onOpenSellerProfile});
  final VoidCallback? onOpenSellerProfile;

  @override
  Widget build(BuildContext context) {
    return DashboardCardWidget(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const DashboardSectionHeaderWidget(
            'Profile & Documents',
            trailing: _Pill('Verified', icon: Icons.check_circle),
          ),
          _ListRow(
            icon: Icons.person_outline,
            label: 'Personal & Business Details',
            onTap:
                onOpenSellerProfile ??
                () => context.push('/modules/seller/onboarding', extra: true),
          ),
          const Divider(height: 1, color: AppColors.border),
          _ListRow(
            icon: Icons.description_outlined,
            label: 'Documents (FSSAI, ID, etc.)',
            onTap:
                onOpenSellerProfile ??
                () => context.push('/modules/seller/onboarding', extra: true),
          ),
          const Divider(height: 1, color: AppColors.border),
          _ListRow(
            icon: Icons.account_balance_outlined,
            label: 'Bank & Payout Details',
            onTap:
                onOpenSellerProfile ??
                () => context.push('/modules/seller/onboarding', extra: true),
          ),
        ],
      ),
    );
  }
}

class _HelpSupport extends StatelessWidget {
  const _HelpSupport();

  @override
  Widget build(BuildContext context) {
    return DashboardCardWidget(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const DashboardSectionHeaderWidget('Help & Support'),
          _ListRow(
            icon: Icons.help_outline,
            label: 'FAQs for Sellers',
            onTap: () {
              ScaffoldMessenger.of(context)
                  .showSnackBar(const SnackBar(content: Text('Seller FAQs screen is coming soon')));
            },
          ),
          const Divider(height: 1, color: AppColors.border),
          _ListRow(
            icon: Icons.headset_mic_outlined,
            label: 'Contact Support',
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Contact support screen is coming soon')),
              );
            },
          ),
          const Divider(height: 1, color: AppColors.border),
          _ListRow(
            icon: Icons.menu_book_outlined,
            label: 'Seller Guidelines',
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Seller guidelines screen is coming soon')),
              );
            },
          ),
          const Divider(height: 1, color: AppColors.border),
          _ListRow(
            icon: Icons.restaurant_menu,
            label: 'Food Safety & Compliance (FSSAI)',
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Food safety & compliance guidelines are coming soon'),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
