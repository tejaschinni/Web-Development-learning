import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/domain/entities/seller_profile_entity.dart';
import 'package:society_seva/features/seller/domain/enum/seller_account_status.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/seller/presentation/screens/dashboard/seller_dashboard_screen.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/status/seller_status_actions.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/status/seller_status_banner.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/status/seller_status_content_card.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/status/seller_status_graphic.dart';

class SellerDashboardProfileTab extends ConsumerWidget {
  const SellerDashboardProfileTab({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profileAsync = ref.watch(mySellerProfileProvider);

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: RefreshIndicator(
          color: AppColors.green,
          onRefresh: () async {
            ref.invalidate(mySellerProfileProvider);
          },
          child: profileAsync.when(
            data: (seller) {
              if (seller == null) {
                return _buildEmptyProfile(context);
              }

              final status = SellerAccountStatus.fromString(seller.approvalStatus);

              if (status == SellerAccountStatus.approved) {
                return _buildApprovedProfile(context, ref, seller);
              } else {
                return _buildSellerStatusSection(context, ref, seller, status);
              }
            },
            loading: () => const Center(
              child: CircularProgressIndicator(color: AppColors.green),
            ),
            error: (err, stack) => Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.error_outline, size: 48, color: AppColors.red),
                    const Gap(12),
                    Text(
                      'Failed to load seller profile',
                      style: AppTheme.display(16, w: FontWeight.w700, c: AppColors.ink),
                    ),
                    const Gap(6),
                    Text(
                      err.toString(),
                      textAlign: TextAlign.center,
                      style: AppTheme.hind(13, c: AppColors.muted),
                    ),
                    const Gap(16),
                    ElevatedButton(
                      onPressed: () => ref.invalidate(mySellerProfileProvider),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.green,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      ),
                      child: Text('Retry', style: AppTheme.hind(14, w: FontWeight.w600, c: AppColors.surface)),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Empty Profile (No seller registered yet)
  // ---------------------------------------------------------------------------
  Widget _buildEmptyProfile(BuildContext context) {
    return SingleChildScrollView(
      physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 36),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 80,
              height: 80,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Color(0xFFEAF6EE),
              ),
              child: const Icon(Icons.storefront_outlined, size: 42, color: AppColors.green),
            ),
            const Gap(16),
            Text(
              'No Seller Profile Found',
              style: AppTheme.display(20, w: FontWeight.w700, c: AppColors.ink),
            ),
            const Gap(8),
            Text(
              'Start selling your goods or services in your society by setting up your seller profile.',
              textAlign: TextAlign.center,
              style: AppTheme.hind(14, c: AppColors.muted, h: 1.3),
            ),
            const Gap(24),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                onPressed: () => context.push('/modules/seller/onboarding'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.green,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: Text(
                  'Create Seller Profile',
                  style: AppTheme.hind(15, w: FontWeight.w700, c: AppColors.surface),
                ),
              ),
            ),
            const Gap(12),
            TextButton(
              onPressed: () => context.push('/profile'),
              child: Text(
                'Go to Resident Profile',
                style: AppTheme.hind(14, w: FontWeight.w600, c: AppColors.green),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // 1. Seller Status Section (for drafted, rejected, suspended, submitted, etc.)
  // ---------------------------------------------------------------------------
  Widget _buildSellerStatusSection(
    BuildContext context,
    WidgetRef ref,
    SellerProfileEntity seller,
    SellerAccountStatus status,
  ) {
    final formattedTypes = seller.sellerTypeList.isNotEmpty
        ? seller.sellerTypeList.map((t) => t.replaceAll('_', ' ')).join(', ')
        : 'General Seller';

    return SingleChildScrollView(
      physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Gap(8),
          _buildStatusTitle(status),
          const Gap(6),
          _buildStatusSubtitle(status),
          const Gap(20),
          SellerStatusGraphic(status: status),
          const Gap(20),
          SellerStatusBanner(status: status),
          const Gap(16),
          SellerStatusContentCard(
            status: status,
            submittedOn: seller.createdAt.isNotEmpty ? seller.createdAt : null,
            referenceId: seller.id.isNotEmpty ? seller.id : null,
            approvedOn: seller.updatedAt.isNotEmpty ? seller.updatedAt : null,
            sellerType: formattedTypes,
            category: seller.capableCategoryIds?.join(', '),
            serviceArea: seller.targetArea ?? seller.city,
          ),
          const Gap(24),
          SellerStatusActions(
            status: status,
            onGoToDashboard: () => ref.read(sellerDashboardTabProvider.notifier).state = 0,
            onCreateListing: () => ref.read(sellerDashboardTabProvider.notifier).state = 2,
            onUpdateAndResubmit: () => context.push('/modules/seller/onboarding', extra: true),
            onContactSupport: () => _showContactSupportModal(context),
            onActivateAccount: () => context.push('/modules/seller/onboarding', extra: true),
          ),
          const Gap(16),
          TextButton.icon(
            onPressed: () => context.push('/profile'),
            icon: const Icon(Icons.person_outline, size: 18, color: AppColors.muted),
            label: Text(
              'Switch to Resident Profile',
              style: AppTheme.hind(13.5, w: FontWeight.w600, c: AppColors.muted),
            ),
          ),
          const Gap(24),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // 2. Approved Seller Profile View (with details and edit option)
  // ---------------------------------------------------------------------------
  Widget _buildApprovedProfile(
    BuildContext context,
    WidgetRef ref,
    SellerProfileEntity seller,
  ) {
    return SingleChildScrollView(
      physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header Card
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.border),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.03),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Stack(
                      clipBehavior: Clip.none,
                      children: [
                        Container(
                          width: 68,
                          height: 68,
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            color: Color(0xFFFFE0B2),
                          ),
                          child: const Icon(
                            Icons.ramen_dining,
                            size: 34,
                            color: Color(0xFFB3541E),
                          ),
                        ),
                        Positioned(
                          right: -2,
                          bottom: -2,
                          child: InkWell(
                            onTap: () => context.push('/modules/seller/onboarding', extra: true),
                            borderRadius: BorderRadius.circular(12),
                            child: Container(
                              padding: const EdgeInsets.all(5),
                              decoration: const BoxDecoration(
                                color: AppColors.green,
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(Icons.edit, size: 12, color: Colors.white),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const Gap(14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  seller.displayName,
                                  style: AppTheme.display(17, w: FontWeight.w700, c: AppColors.ink),
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFDDF3E2),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const Icon(Icons.check_circle, size: 13, color: AppColors.green),
                                    const Gap(4),
                                    Text(
                                      'APPROVED',
                                      style: AppTheme.hind(11, w: FontWeight.w700, c: AppColors.green),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          if (seller.businessName != null && seller.businessName!.isNotEmpty) ...[
                            const Gap(2),
                            Text(
                              seller.businessName!,
                              style: AppTheme.hind(13.5, w: FontWeight.w500, c: AppColors.muted),
                            ),
                          ],
                          const Gap(6),
                          Row(
                            children: [
                              const Icon(Icons.star_rounded, size: 16, color: Color(0xFFF59E0B)),
                              const Gap(3),
                              Text(
                                '${seller.averageRating.toStringAsFixed(1)} ',
                                style: AppTheme.hind(12.5, w: FontWeight.w700, c: AppColors.ink),
                              ),
                              Text(
                                '(${seller.totalReviews} reviews)',
                                style: AppTheme.hind(12, c: AppColors.muted),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                if (seller.bio != null && seller.bio!.isNotEmpty) ...[
                  const Gap(14),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppColors.bg,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      seller.bio!,
                      style: AppTheme.hind(13, c: AppColors.ink, h: 1.35),
                    ),
                  ),
                ],
                const Gap(12),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: seller.sellerTypeList.map((type) {
                    return Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: AppColors.greenSoft,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: AppColors.green.withValues(alpha: 0.3)),
                      ),
                      child: Text(
                        type.replaceAll('_', ' '),
                        style: AppTheme.hind(11.5, w: FontWeight.w600, c: AppColors.greenDeep),
                      ),
                    );
                  }).toList(),
                ),
                const Gap(16),
                SizedBox(
                  width: double.infinity,
                  height: 44,
                  child: ElevatedButton.icon(
                    onPressed: () => context.push('/modules/seller/onboarding', extra: true),
                    icon: const Icon(Icons.edit_outlined, size: 16),
                    label: Text(
                      'Edit Seller Profile',
                      style: AppTheme.hind(14, w: FontWeight.w700, c: AppColors.surface),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.green,
                      elevation: 0,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
              ],
            ),
          ),

          const Gap(16),

          // Performance Stats Grid
          Row(
            children: [
              Expanded(
                child: _buildMetricCard(
                  title: 'Total Orders',
                  value: seller.totalOrders.toString(),
                  icon: Icons.shopping_bag_outlined,
                  color: AppColors.navy,
                ),
              ),
              const Gap(10),
              Expanded(
                child: _buildMetricCard(
                  title: 'Active Listings',
                  value: seller.totalListings.toString(),
                  icon: Icons.storefront_outlined,
                  color: AppColors.green,
                ),
              ),
            ],
          ),
          const Gap(10),
          Row(
            children: [
              Expanded(
                child: _buildMetricCard(
                  title: 'Store Rating',
                  value: '${seller.averageRating.toStringAsFixed(1)} ★',
                  icon: Icons.star_outline_rounded,
                  color: const Color(0xFFF59E0B),
                ),
              ),
              const Gap(10),
              Expanded(
                child: _buildMetricCard(
                  title: 'Total Reviews',
                  value: seller.totalReviews.toString(),
                  icon: Icons.rate_review_outlined,
                  color: const Color(0xFF3B82F6),
                ),
              ),
            ],
          ),

          const Gap(16),

          // Store Information Card
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.border),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Store & Operating Details',
                      style: AppTheme.display(15, w: FontWeight.w700, c: AppColors.ink),
                    ),
                    InkWell(
                      onTap: () => context.push('/modules/seller/onboarding', extra: true),
                      child: Text(
                        'Edit',
                        style: AppTheme.hind(13, w: FontWeight.w600, c: AppColors.green),
                      ),
                    ),
                  ],
                ),
                const Divider(height: 20, thickness: 0.8, color: AppColors.border),
                _buildInfoRow(
                  icon: Icons.location_on_outlined,
                  label: 'Store Address',
                  value: '${seller.address}, ${seller.city}, ${seller.state} - ${seller.pinCode}',
                ),
                const Divider(height: 20, thickness: 0.8, color: AppColors.border),
                _buildInfoRow(
                  icon: Icons.near_me_outlined,
                  label: 'Delivery / Target Area',
                  value: '${seller.targetArea ?? seller.city} (${seller.deliveryRadiusKm ?? 5.0} km radius)',
                ),
                if (seller.websiteUrl != null && seller.websiteUrl!.isNotEmpty) ...[
                  const Divider(height: 20, thickness: 0.8, color: AppColors.border),
                  _buildInfoRow(
                    icon: Icons.language_outlined,
                    label: 'Website',
                    value: seller.websiteUrl!,
                  ),
                ],
                if (seller.socialMediaLinks != null && seller.socialMediaLinks!.isNotEmpty) ...[
                  const Divider(height: 20, thickness: 0.8, color: AppColors.border),
                  _buildInfoRow(
                    icon: Icons.share_outlined,
                    label: 'Social Media',
                    value: seller.socialMediaLinks!,
                  ),
                ],
              ],
            ),
          ),

          const Gap(16),

          // Legal & Compliance Card
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.border),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Compliance & Certification',
                  style: AppTheme.display(15, w: FontWeight.w700, c: AppColors.ink),
                ),
                const Divider(height: 20, thickness: 0.8, color: AppColors.border),
                _buildInfoRow(
                  icon: Icons.verified_user_outlined,
                  label: 'FSSAI Status',
                  value: seller.fssaiRequired
                      ? (seller.fssaiCertificateId != null && seller.fssaiCertificateId!.isNotEmpty
                          ? 'Certified (${seller.fssaiCertificateId})'
                          : 'Required - ${seller.fssaiStatus}')
                      : 'Not Required',
                ),
                if (seller.legalCompliance != null && seller.legalCompliance!.isNotEmpty) ...[
                  const Divider(height: 20, thickness: 0.8, color: AppColors.border),
                  _buildInfoRow(
                    icon: Icons.gavel_outlined,
                    label: 'Legal Compliance',
                    value: seller.legalCompliance!,
                  ),
                ],
              ],
            ),
          ),

          const Gap(20),

          // Quick Navigation Buttons
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => ref.read(sellerDashboardTabProvider.notifier).state = 2,
                  icon: const Icon(Icons.storefront_outlined, size: 16),
                  label: const Text('Listings'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.navy,
                    side: const BorderSide(color: AppColors.border, width: 1.2),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                ),
              ),
              const Gap(10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => ref.read(sellerDashboardTabProvider.notifier).state = 1,
                  icon: const Icon(Icons.shopping_bag_outlined, size: 16),
                  label: const Text('Orders'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.navy,
                    side: const BorderSide(color: AppColors.border, width: 1.2),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                ),
              ),
            ],
          ),
          const Gap(12),
          Center(
            child: TextButton.icon(
              onPressed: () => context.push('/profile'),
              icon: const Icon(Icons.person_outline, size: 18, color: AppColors.muted),
              label: Text(
                'Switch to Resident Profile',
                style: AppTheme.hind(13.5, w: FontWeight.w600, c: AppColors.muted),
              ),
            ),
          ),
          const Gap(24),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Helper Widgets
  // ---------------------------------------------------------------------------
  Widget _buildMetricCard({
    required String title,
    required String value,
    required IconData icon,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, size: 20, color: color),
          ),
          const Gap(10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  value,
                  style: AppTheme.display(16, w: FontWeight.w800, c: AppColors.ink),
                ),
                Text(
                  title,
                  style: AppTheme.hind(12, c: AppColors.muted),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 18, color: AppColors.muted),
        const Gap(10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: AppTheme.hind(12, c: AppColors.muted),
              ),
              const Gap(2),
              Text(
                value,
                style: AppTheme.hind(13.5, w: FontWeight.w600, c: AppColors.ink),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildStatusTitle(SellerAccountStatus status) {
    String text;
    switch (status) {
      case SellerAccountStatus.draft:
        text = 'Application Drafted';
        break;
      case SellerAccountStatus.submitted:
        text = 'Seller Registration Submitted';
        break;
      case SellerAccountStatus.underReview:
        text = 'Verification Pending';
        break;
      case SellerAccountStatus.approved:
        text = 'Seller Account Approved';
        break;
      case SellerAccountStatus.rejected:
        text = 'Application Not Approved';
        break;
      case SellerAccountStatus.suspended:
        text = 'Seller Account Suspended';
        break;
      case SellerAccountStatus.inactive:
        text = 'Inactive Account';
        break;
    }

    return Text(
      text,
      textAlign: TextAlign.center,
      style: AppTheme.display(22, w: FontWeight.w800, c: AppColors.ink),
    );
  }

  Widget _buildStatusSubtitle(SellerAccountStatus status) {
    String text;
    switch (status) {
      case SellerAccountStatus.draft:
        text = 'Your seller profile is saved as draft. You can edit and submit whenever you are ready.';
        break;
      case SellerAccountStatus.submitted:
        text = 'Thank you! Your seller application has\nbeen submitted successfully.';
        break;
      case SellerAccountStatus.underReview:
        text = 'Your application is under review.';
        break;
      case SellerAccountStatus.approved:
        text = 'You can now create listings and start accepting orders.';
        break;
      case SellerAccountStatus.rejected:
        text = 'We are unable to approve your seller account\nat this time.';
        break;
      case SellerAccountStatus.suspended:
        text = 'Your account is currently suspended.';
        break;
      case SellerAccountStatus.inactive:
        text = 'Your seller account is currently inactive.';
        break;
    }

    return Text(
      text,
      textAlign: TextAlign.center,
      style: AppTheme.hind(13.5, c: AppColors.muted, h: 1.3),
    );
  }

  void _showContactSupportModal(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'SEVA Support',
              style: AppTheme.display(18, w: FontWeight.w700, c: AppColors.ink),
            ),
            const Gap(12),
            Text(
              'For assistance with your seller account or account review status, please reach out to our support team:',
              style: AppTheme.hind(14, c: AppColors.muted),
            ),
            const Gap(16),
            ListTile(
              leading: const CircleAvatar(
                backgroundColor: AppColors.greenSoft,
                child: Icon(Icons.email_outlined, color: AppColors.green),
              ),
              title: Text('Email Support', style: AppTheme.hind(14, w: FontWeight.w600, c: AppColors.ink)),
              subtitle: Text('support@vasundharaseva.com', style: AppTheme.hind(13, c: AppColors.muted)),
              contentPadding: EdgeInsets.zero,
            ),
            ListTile(
              leading: const CircleAvatar(
                backgroundColor: AppColors.greenSoft,
                child: Icon(Icons.phone_outlined, color: AppColors.green),
              ),
              title: Text('Helpline', style: AppTheme.hind(14, w: FontWeight.w600, c: AppColors.ink)),
              subtitle: Text('+91 1800 200 4567 (10 AM - 6 PM)', style: AppTheme.hind(13, c: AppColors.muted)),
              contentPadding: EdgeInsets.zero,
            ),
            const Gap(16),
            SizedBox(
              width: double.infinity,
              height: 46,
              child: ElevatedButton(
                onPressed: () => Navigator.pop(ctx),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.green,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: Text('Close', style: AppTheme.hind(15, w: FontWeight.w600, c: AppColors.surface)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
