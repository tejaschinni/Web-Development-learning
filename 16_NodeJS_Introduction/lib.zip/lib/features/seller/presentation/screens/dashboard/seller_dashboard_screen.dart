import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/features/auth/presentation/providers/auth_provider.dart';
import 'package:society_seva/features/location/presentation/widgets/location_header_button.dart';
import 'package:society_seva/features/profile/presentation/widgets/seller_mode_app_bar_action.dart';
import 'package:society_seva/features/seller/presentation/screens/dashboard/seller_dashboard_profile_tab.dart';
import 'package:society_seva/features/seller/presentation/screens/dashboard/seller_home_screen_v2.dart';
import 'package:society_seva/features/seller/presentation/screens/listing/my_listing_screen.dart';
import 'package:society_seva/features/seller/presentation/screens/order/seller_orders_screen.dart';
import 'package:society_seva/features/seller/presentation/widgets/dashboard/dashboard_placeholder.dart';
import 'package:society_seva/features/seller/presentation/widgets/dashboard/seller_bottom_nav_bar.dart';

/// Controls the active tab index in SellerDashboardScreen:
/// 0: Home (SellerHomeScreenV2)
/// 1: Orders (SellerOrdersScreen)
/// 2: Listings (MyListingsScreen)
/// 3: Reviews
/// 4: Profile (SellerDashboardProfileTab)
final sellerDashboardTabProvider = StateProvider<int>((ref) => 0);

class SellerDashboardScreen extends ConsumerStatefulWidget {
  const SellerDashboardScreen({super.key});

  @override
  ConsumerState<SellerDashboardScreen> createState() => _SellerDashboardScreenState();
}

class _SellerDashboardScreenState extends ConsumerState<SellerDashboardScreen> {
  static const _tabs = <Widget>[
    SellerHomeScreenV2(),
    SellerOrdersScreen(),
    MyListingScreen(),
    DashboardPlaceholder(title: 'Reviews', icon: Icons.reviews_outlined),
    SellerDashboardProfileTab(),
  ];
  Future<void> _logout() async {
    final shouldLogout = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Log out?', style: GoogleFonts.hind()),
        content: Text('Are you sure you want to logout?', style: GoogleFonts.hind()),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: Text('Cancel', style: GoogleFonts.hind()),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: Text('Logout', style: GoogleFonts.hind()),
          ),
        ],
      ),
    );
    if (shouldLogout != true || !mounted) return;
    final failureMessage = await ref.read(authControllerProvider.notifier).logout();
    if (failureMessage != null && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Signed out locally, but server logout failed: $failureMessage',
            style: GoogleFonts.hind(),
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Image.asset(
              'assets/images/logo/v-logo-big.png',
              fit: BoxFit.scaleDown,
              height: 35,
              alignment: Alignment.centerLeft,
            ),
            const Gap(10),
            Flexible(child: LocationHeaderButton(compact: true)),
          ],
        ),
        actions: [
          const SellerModeAppBarAction(),
          // IconButton(
          //   onPressed: () => context.push('/profile'),
          //   icon: const HugeIcon(icon: HugeIcons.strokeRoundedUser),
          //   tooltip: 'Profile',
          // ),
          IconButton(
            onPressed: _logout,
            icon: const HugeIcon(icon: HugeIcons.strokeRoundedLogout02),
            tooltip: 'Logout',
          ),
        ],
      ),
      // IndexedStack keeps each tab's state when switching tabs.
      body: IndexedStack(index: ref.watch(sellerDashboardTabProvider), children: _tabs),
      bottomNavigationBar: SellerBottomNavBar(
        currentIndex: ref.watch(sellerDashboardTabProvider),
        onTap: (i) => ref.read(sellerDashboardTabProvider.notifier).state = i,
      ),
    );
  }
}
