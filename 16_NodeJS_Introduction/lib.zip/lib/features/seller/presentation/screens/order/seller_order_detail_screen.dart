import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:society_seva/app/router/app_router.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/core/constants/app_assets.dart';
import 'package:society_seva/features/seller/domain/entities/seller_order_entity.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_order_provider.dart';
import 'package:society_seva/features/seller/presentation/widgets/dashboard/order_widget.dart';

class OrderDetailsScreen extends ConsumerWidget {
  const OrderDetailsScreen({super.key, this.orderDetailEntity});
  final OrderDetailsArgs? orderDetailEntity;

  Future<void> _changeStatus(
    BuildContext context,
    WidgetRef ref,
    SellerOrderEntity order,
    String status, {
    String? note,
  }) async {
    if (status == 'REJECTED') {
      final confirm = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text(
            'Reject Order',
            style: GoogleFonts.plusJakartaSans(fontWeight: FontWeight.w700),
          ),
          content: Text(
            'Are you sure you want to reject order ${order.orderNumber}?',
            style: GoogleFonts.hind(),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text('Cancel', style: GoogleFonts.hind(color: AppColors.muted)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.red,
                foregroundColor: Colors.white,
              ),
              onPressed: () => Navigator.pop(ctx, true),
              child: Text('Reject', style: GoogleFonts.hind(fontWeight: FontWeight.w600)),
            ),
          ],
        ),
      );

      if (confirm != true || !context.mounted) return;
    }

    final isBusy = ref.read(sellerOrderActionProvider).isBusy(order.id);
    if (isBusy) return;

    final ok = await ref.read(sellerOrderActionProvider.notifier).transition(
          sellerId: order.sellerId,
          orderId: order.id,
          newStatus: status,
          note: note ?? (status == 'REJECTED' ? 'Item not available' : null),
        );

    if (!context.mounted) return;
    if (ok) {
      final message = switch (status) {
        'ACCEPTED' => 'Order accepted successfully',
        'REJECTED' => 'Order rejected',
        'PREPARING' => 'Order updated to Preparing',
        'READY_FOR_PICKUP' => 'Order is now Ready for Pickup',
        'OUT_FOR_DELIVERY' => 'Order is Out for Delivery',
        'COMPLETED' => 'Order marked as Completed',
        _ => 'Order updated to $status',
      };

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message, style: GoogleFonts.hind()),
          backgroundColor: status == 'REJECTED' ? AppColors.red : AppColors.green,
        ),
      );

      if (status == 'ACCEPTED') {
        final updatedOrder = order.copyWith(orderStatus: status);
        context.push('/modules/seller/orderAccepted', extra: updatedOrder);
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Could not update order status to $status', style: GoogleFonts.hind()),
          backgroundColor: AppColors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    if (orderDetailEntity == null) {
      return Scaffold(
        backgroundColor: AppColors.bg,
        body: SafeArea(
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('No order specified'),
                const Gap(10),
                ElevatedButton(
                  onPressed: () => context.pop(),
                  child: const Text('Back to Orders'),
                ),
              ],
            ),
          ),
        ),
      );
    }

    final initialOrder = orderDetailEntity!.order;
    // Watch for live order status updates
    final sellerOrders =
        ref.watch(sellerOrdersProvider(initialOrder.sellerId)).valueOrNull?.content;
    final SellerOrderEntity orderDetail = sellerOrders
            ?.where((o) => o.id == initialOrder.id)
            .firstOrNull ??
        initialOrder;

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Column(
          children: [
            const OrderHeader(),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Center(
                    child: Text(
                      'Order Details',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 22,
                        fontWeight: FontWeight.w700,
                        color: AppColors.ink,
                      ),
                    ),
                  ),
                  const Gap(14),

                  // Dynamic Banner according to order status
                  _buildStatusBanner(orderDetail),

                  const Gap(12),
                  AppCard(
                    child: Column(
                      children: [
                        _row('Order ID', _Bold(orderDetail.orderNumber)),
                        _row(
                          'Order Status',
                          StatusBadge(
                            label: _statusLabel(orderDetail.orderStatus),
                            background: _statusBadgeBg(orderDetail.orderStatus),
                            foreground: _statusBadgeFg(orderDetail.orderStatus),
                          ),
                        ),
                        _row(
                          'Order Date',
                          _Txt(
                            DateFormat('d MMM yyyy, hh:mm a')
                                .format(orderDetail.createdAt.toLocal()),
                          ),
                        ),
                        _row(
                          'Customer',
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _Txt(orderDetailEntity!.buyerName.toString()),
                              const Gap(6),
                              Row(
                                children: [
                                  const Icon(Icons.phone, size: 14, color: AppColors.green),
                                  const Gap(4),
                                  _Txt('+91 98765 43210'),
                                  const Spacer(),
                                  _chatButton(),
                                ],
                              ),
                            ],
                          ),
                        ),
                        _row('Delivery Type', const _Bold('Pickup')),
                        _row(
                          'Pickup Date',
                          _Txt(
                            DateFormat('d MMM yyyy').format(orderDetail.createdAt.toLocal()),
                          ),
                        ),
                        _row('Pickup Time', const _Txt('12:00 PM - 1:00 PM'), last: true),
                      ],
                    ),
                  ),
                  const Gap(12),
                  AppCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Items (${orderDetail.items.length})',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            color: AppColors.ink,
                          ),
                        ),
                        const Gap(10),
                        ListView.separated(
                          itemCount: orderDetail.items.length,
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          separatorBuilder: (context, index) => const Gap(8),
                          itemBuilder: (context, index) {
                            final item = orderDetail.items[index];
                            return Row(
                              children: [
                                Container(
                                  width: 40,
                                  height: 40,
                                  padding: const EdgeInsets.all(6),
                                  decoration: BoxDecoration(
                                    color: AppColors.greenSoft,
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: SvgPicture.asset(
                                    AppAssets.categoryFood,
                                    fit: BoxFit.contain,
                                  ),
                                ),
                                const Gap(10),
                                Expanded(child: _Txt(item.titleSnapshot)),
                                _Txt('x ${item.quantity}'),
                                const Gap(16),
                                _Bold('\u20B9 ${item.unitPrice}'),
                              ],
                            );
                          },
                        ),
                        const Divider(height: 24, color: AppColors.border),
                        Row(
                          children: [
                            Expanded(child: _Bold('Total Amount')),
                            _Bold('\u20B9 ${orderDetail.totalAmount}'),
                          ],
                        ),
                        const Gap(8),
                        Row(
                          children: [
                            const Expanded(child: _Txt('Payment Status')),
                            StatusBadge(
                              label: orderDetail.paymentStatus.toUpperCase(),
                              background: AppColors.greenSoft,
                              foreground: AppColors.green,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            // Dynamic Bottom Action Buttons according to status
            Container(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
              decoration: const BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Color(0x0A000000),
                    blurRadius: 8,
                    offset: Offset(0, -3),
                  ),
                ],
              ),
              child: _buildBottomActions(context, ref, orderDetail),
            ),
          ],
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Status Banners
  // ---------------------------------------------------------------------------
  Widget _buildStatusBanner(SellerOrderEntity order) {
    final status = order.orderStatus.toUpperCase().trim();

    // 1. Pending approval
    if (status == 'CREATED' ||
        status == 'PENDING' ||
        status == 'PAID' ||
        status == 'PAYMENT_PENDING') {
      return _banner(
        color: AppColors.orange,
        bgColor: AppColors.orangeSoft,
        title: 'Pending Acceptance',
        subtitle: 'Please review order items and accept or reject within 1 hour.',
        svgIcon: AppAssets.pending,
      );
    }

    // 2. Approved / Accepted
    if (status == 'ACCEPTED' || status == 'APPROVED') {
      return _banner(
        color: AppColors.green,
        bgColor: AppColors.greenSoft,
        title: 'Order Approved',
        subtitle: 'Order is confirmed. Prepare the items and mark ready for fulfillment.',
        svgIcon: AppAssets.processing,
      );
    }

    // 3. Preparing
    if (status == 'PREPARING' || status == 'IN_SERVICE') {
      return _banner(
        color: AppColors.orange,
        bgColor: AppColors.orangeSoft,
        title: 'Preparing Order',
        subtitle: 'Order is currently being prepared. Update when items are packed.',
        svgIcon: AppAssets.preparingFood,
      );
    }

    // 4. Ready for pickup
    if (status == 'READY_FOR_PICKUP' || status == 'READY') {
      return _banner(
        color: AppColors.blue,
        bgColor: AppColors.blueSoft,
        title: 'Ready for Pickup',
        subtitle: 'Order is ready and waiting for customer pickup / dispatch.',
        svgIcon: AppAssets.readyForPickup,
      );
    }

    // 5. Out for delivery
    if (status == 'OUT_FOR_DELIVERY') {
      return _banner(
        color: AppColors.blue,
        bgColor: AppColors.blueSoft,
        title: 'Out for Delivery',
        subtitle: 'Order is out for delivery to the customer.',
        svgIcon: AppAssets.outForDelivery,
      );
    }

    // 6. Delivery Completed
    if (status == 'COMPLETED' || status == 'DELIVERED' || status == 'PICKED_UP') {
      return _banner(
        color: AppColors.green,
        bgColor: AppColors.greenSoft,
        title: 'Delivery Completed',
        subtitle: 'Order has been successfully delivered and completed.',
        svgIcon: AppAssets.delivered,
      );
    }

    // 7. Rejected
    if (status == 'REJECTED') {
      return _banner(
        color: AppColors.red,
        bgColor: AppColors.redSoft,
        title: 'Order Rejected',
        subtitle: 'This order was rejected and will not be fulfilled.',
        svgIcon: AppAssets.rejected,
      );
    }

    // 8. Cancelled
    if (status == 'CANCELLED' || status == 'CANCELED') {
      return _banner(
        color: AppColors.red,
        bgColor: AppColors.redSoft,
        title: 'Order Cancelled',
        subtitle: 'This order was cancelled by the customer or store.',
        svgIcon: AppAssets.rejected,
      );
    }

    return const SizedBox.shrink();
  }

  Widget _banner({
    required Color color,
    required Color bgColor,
    required String title,
    required String subtitle,
    String? svgIcon,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withValues(alpha: 0.3)),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: svgIcon != null
                ? SvgPicture.asset(svgIcon, fit: BoxFit.contain)
                : Icon(Icons.info_outline, color: color, size: 24),
          ),
          const Gap(12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: color,
                  ),
                ),
                const Gap(2),
                Text(
                  subtitle,
                  style: GoogleFonts.hind(
                    fontSize: 12.5,
                    color: AppColors.ink.withValues(alpha: 0.8),
                    height: 1.3,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Bottom Buttons
  // ---------------------------------------------------------------------------
  Widget _buildBottomActions(BuildContext context, WidgetRef ref, SellerOrderEntity order) {
    final status = order.orderStatus.toUpperCase().trim();
    final isBusy = ref.watch(sellerOrderActionProvider.select((s) => s.isBusy(order.id)));

    // 1. Pending state: Show [Reject] and [Accept Order]
    if (status == 'CREATED' ||
        status == 'PENDING' ||
        status == 'PAID' ||
        status == 'PAYMENT_PENDING') {
      return Row(
        children: [
          Expanded(
            child: OutlinedAppButton(
              label: 'Reject',
              color: AppColors.red,
              onPressed: isBusy
                  ? () {}
                  : () => _changeStatus(context, ref, order, 'REJECTED'),
            ),
          ),
          const Gap(12),
          Expanded(
            flex: 2,
            child: FilledAppButton(
              label: isBusy ? 'Accepting...' : 'Accept Order',
              onPressed: isBusy
                  ? () {}
                  : () => _changeStatus(context, ref, order, 'ACCEPTED'),
            ),
          ),
        ],
      );
    }

    // 2. Approved / Accepted state: Show [Timeline] and [Start Preparing]
    if (status == 'ACCEPTED' || status == 'APPROVED') {
      return Row(
        children: [
          Expanded(
            child: OutlinedAppButton(
              label: 'Timeline',
              color: AppColors.green,
              onPressed: () => context.push('/modules/seller/orderAccepted', extra: order),
            ),
          ),
          const Gap(12),
          Expanded(
            flex: 2,
            child: FilledAppButton(
              label: isBusy ? 'Updating...' : 'Start Preparing',
              onPressed: isBusy
                  ? () {}
                  : () => _changeStatus(context, ref, order, 'PREPARING'),
            ),
          ),
        ],
      );
    }

    // 3. Preparing state: Show [Timeline] and [Ready for Pickup]
    if (status == 'PREPARING' || status == 'IN_SERVICE') {
      return Row(
        children: [
          Expanded(
            child: OutlinedAppButton(
              label: 'Timeline',
              color: AppColors.green,
              onPressed: () => context.push('/modules/seller/orderAccepted', extra: order),
            ),
          ),
          const Gap(12),
          Expanded(
            flex: 2,
            child: FilledAppButton(
              label: isBusy ? 'Updating...' : 'Ready for Pickup',
              onPressed: isBusy
                  ? () {}
                  : () => _changeStatus(context, ref, order, 'READY_FOR_PICKUP'),
            ),
          ),
        ],
      );
    }

    // 4. Ready for pickup / Out for delivery: Show [Timeline] and [Complete Order]
    if (status == 'READY_FOR_PICKUP' || status == 'READY' || status == 'OUT_FOR_DELIVERY') {
      return Row(
        children: [
          Expanded(
            child: OutlinedAppButton(
              label: 'Timeline',
              color: AppColors.green,
              onPressed: () => context.push('/modules/seller/orderAccepted', extra: order),
            ),
          ),
          const Gap(12),
          Expanded(
            flex: 2,
            child: FilledAppButton(
              label: isBusy ? 'Completing...' : 'Complete Order',
              onPressed: isBusy
                  ? () {}
                  : () => _changeStatus(context, ref, order, 'COMPLETED'),
            ),
          ),
        ],
      );
    }

    // 5. Completed / Delivered: Delivery is completed!
    if (status == 'COMPLETED' || status == 'DELIVERED' || status == 'PICKED_UP') {
      return Row(
        children: [
          Expanded(
            child: OutlinedAppButton(
              label: 'Back to Orders',
              color: AppColors.green,
              onPressed: () => context.pop(),
            ),
          ),
          const Gap(12),
          Expanded(
            flex: 2,
            child: FilledAppButton(
              label: 'View Timeline',
              onPressed: () => context.push('/modules/seller/orderAccepted', extra: order),
            ),
          ),
        ],
      );
    }

    // 6. Rejected or Cancelled: Terminal state
    if (status == 'REJECTED' || status == 'CANCELLED' || status == 'CANCELED') {
      return SizedBox(
        width: double.infinity,
        child: OutlinedAppButton(
          label: 'Back to Orders',
          color: AppColors.ink,
          onPressed: () => context.pop(),
        ),
      );
    }

    // Fallback default
    return SizedBox(
      width: double.infinity,
      child: OutlinedAppButton(
        label: 'Back to Orders',
        color: AppColors.green,
        onPressed: () => context.pop(),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------
  String _statusLabel(String status) {
    return switch (status.toUpperCase()) {
      'CREATED' || 'PENDING' => 'PENDING',
      'PAID' => 'PAID',
      'ACCEPTED' || 'APPROVED' => 'APPROVED',
      'PREPARING' || 'IN_SERVICE' => 'PREPARING',
      'READY' || 'READY_FOR_PICKUP' => 'READY',
      'OUT_FOR_DELIVERY' => 'OUT FOR DELIVERY',
      'COMPLETED' || 'DELIVERED' || 'PICKED_UP' => 'DELIVERED',
      'REJECTED' => 'REJECTED',
      'CANCELLED' || 'CANCELED' => 'CANCELLED',
      _ => status.toUpperCase(),
    };
  }

  Color _statusBadgeBg(String status) {
    return switch (status.toUpperCase()) {
      'ACCEPTED' || 'APPROVED' || 'COMPLETED' || 'DELIVERED' || 'PICKED_UP' =>
        AppColors.greenSoft,
      'REJECTED' || 'CANCELLED' || 'CANCELED' => AppColors.redSoft,
      _ => AppColors.orangeSoft,
    };
  }

  Color _statusBadgeFg(String status) {
    return switch (status.toUpperCase()) {
      'ACCEPTED' || 'APPROVED' || 'COMPLETED' || 'DELIVERED' || 'PICKED_UP' =>
        AppColors.green,
      'REJECTED' || 'CANCELLED' || 'CANCELED' => AppColors.red,
      _ => AppColors.orange,
    };
  }

  Widget _chatButton() => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(
          color: AppColors.greenSoft,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.green.withValues(alpha: 0.4)),
        ),
        child: Row(
          children: [
            const Icon(Icons.chat_bubble_outline, size: 14, color: AppColors.green),
            const Gap(4),
            Text(
              'Chat',
              style: AppTheme.hind(12, w: FontWeight.w600, c: AppColors.green),
            ),
          ],
        ),
      );

  Widget _row(String label, Widget value, {bool last = false}) => Padding(
        padding: EdgeInsets.only(bottom: last ? 0 : 10),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 110,
              child: Text(label, style: AppTheme.hind(13, c: AppColors.muted)),
            ),
            Expanded(child: value),
          ],
        ),
      );
}

class _Txt extends StatelessWidget {
  const _Txt(this.text);
  final String text;
  @override
  Widget build(BuildContext context) => Text(text, style: AppTheme.hind(13.5));
}

class _Bold extends StatelessWidget {
  const _Bold(this.text);
  final String text;
  @override
  Widget build(BuildContext context) =>
      Text(text, style: AppTheme.hind(14, w: FontWeight.w700));
}
