import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:intl/intl.dart';
import 'package:society_seva/app/router/app_router.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/domain/entities/order_status_history_entity.dart';
import 'package:society_seva/features/seller/domain/entities/seller_order_entity.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_order_provider.dart';
import 'package:society_seva/features/seller/presentation/widgets/dashboard/order_widget.dart';

class OrderAcceptedScreen extends ConsumerWidget {
  const OrderAcceptedScreen({super.key, this.order});

  final SellerOrderEntity? order;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    if (order == null) {
      return Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('No order specified'),
                const Gap(10),
                ElevatedButton(
                  onPressed: () => context.pop(),
                  child: const Text('Back to Orders'),
                ),
              ],
            ),
          ),
        ),
      );
    }

    final currentOrder = order!;
    final orderHistoryAsync = ref.watch(orderStatusHistoryProvider(currentOrder.id));
    final buyerNameProvider = ref.watch(buyerNameByUserIdProvider(currentOrder.buyerId));
    final buyerName = buyerNameProvider.valueOrNull ?? 'Customer';

    return Scaffold(
      backgroundColor: Colors.white,
      body: orderHistoryAsync.when(
        data: (data) {
          final effectiveData = data.isNotEmpty
              ? data
              : [
                  OrderStatusHistoryEntity(
                    id: 'hist_${currentOrder.id}',
                    orderId: currentOrder.id,
                    oldStatus: '',
                    newStatus: currentOrder.orderStatus,
                    note: '',
                    createdAt: currentOrder.createdAt,
                  ),
                ];
          final latestStatus = effectiveData.last;
          final isCompleted = currentOrder.orderStatus.toUpperCase() == 'COMPLETED' ||
              latestStatus.newStatus.toUpperCase() == 'COMPLETED';
          final isCancelled = currentOrder.orderStatus.toUpperCase() == 'CANCELLED' ||
              currentOrder.orderStatus.toUpperCase() == 'REJECTED' ||
              latestStatus.newStatus.toUpperCase() == 'CANCELLED' ||
              latestStatus.newStatus.toUpperCase() == 'REJECTED';

          return SafeArea(
            child: Column(
              children: [
                const OrderHeader(),
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                    child: isCancelled
                        ? _buildCancelledView(currentOrder, latestStatus)
                        : isCompleted
                        ? _buildCompletedView(currentOrder, latestStatus, buyerName)
                        : _buildAcceptedTimelineView(currentOrder, effectiveData),
                  ),
                ),
                _buildBottomButtons(
                  context,
                  currentOrder,
                  latestStatus,
                  buyerName,
                  latestStatus.newStatus,
                ),
              ],
            ),
          );
        },
        error: (error, st) {
          return SafeArea(
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text("Error loading order status: $error"),
                  const Gap(12),
                  ElevatedButton(
                    onPressed: () => ref.invalidate(orderStatusHistoryProvider(currentOrder.id)),
                    child: const Text('Retry'),
                  ),
                ],
              ),
            ),
          );
        },
        loading: () {
          return const Center(
            child: CircularProgressIndicator(color: AppColors.green),
          );
        },
      ),
    );
  }

  Widget _buildCancelledView(
    SellerOrderEntity order,
    OrderStatusHistoryEntity latestStatus,
  ) {
    final isCustomerCancelled = latestStatus.note.toLowerCase().contains('customer') ||
        (order.orderStatus.toUpperCase() == 'CANCELLED' &&
            !latestStatus.note.toLowerCase().contains('seller'));

    return Column(
      children: [
        const Gap(10),
        Container(
          width: 58,
          height: 58,
          decoration: const BoxDecoration(
            color: AppColors.red,
            shape: BoxShape.circle,
          ),
          child: const Center(
            child: Icon(Icons.close_rounded, color: Colors.white, size: 36),
          ),
        ),
        const Gap(14),
        Text(
          isCustomerCancelled ? 'Order Cancelled by Customer' : 'Order Cancelled',
          style: AppTheme.display(20, w: FontWeight.w800, c: AppColors.ink),
        ),
        const Gap(8),
        Text(
          isCustomerCancelled
              ? 'This order has been cancelled by the customer.'
              : 'This order has been cancelled.',
          textAlign: TextAlign.center,
          style: AppTheme.hind(14, c: AppColors.muted, h: 1.4),
        ),
        const Gap(24),
        AppCard(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              _summaryRow(
                'Order ID',
                Text('#${order.orderNumber}', style: AppTheme.hind(14, w: FontWeight.w700)),
              ),
              _summaryRow(
                'Cancelled On',
                Text(
                  DateFormat('d MMM yyyy, hh:mm a').format(latestStatus.createdAt.toLocal()),
                  style: AppTheme.hind(13.5),
                ),
              ),
              _summaryRow(
                'Reason',
                Text(
                  latestStatus.note.isNotEmpty ? latestStatus.note : 'Item not available',
                  style: AppTheme.hind(13.5),
                ),
              ),
              _summaryRow(
                'Cancelled By',
                Text(isCustomerCancelled ? 'Customer' : 'You (Seller)', style: AppTheme.hind(13.5)),
              ),
              _summaryRow(
                'Refund Status',
                StatusBadge(
                  label: isCustomerCancelled ? 'Completed' : 'Processing (Automatic)',
                  background: isCustomerCancelled ? AppColors.greenSoft : AppColors.orangeSoft,
                  foreground: isCustomerCancelled ? AppColors.green : AppColors.orange,
                  icon: isCustomerCancelled ? Icons.check_circle : Icons.hourglass_top,
                ),
                last: true,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildCompletedView(
    SellerOrderEntity order,
    OrderStatusHistoryEntity latestStatus,
    String buyerName,
  ) {
    return Column(
      children: [
        const Gap(10),
        Container(
          width: 58,
          height: 58,
          decoration: const BoxDecoration(
            color: AppColors.green,
            shape: BoxShape.circle,
          ),
          child: const Center(
            child: HugeIcon(
              icon: HugeIcons.strokeRoundedCheck,
              color: AppColors.bg,
              size: 36,
            ),
          ),
        ),
        const Gap(14),
        Text(
          'Order Completed',
          style: AppTheme.display(20, w: FontWeight.w800, c: AppColors.ink),
        ),
        const Gap(8),
        Text(
          'The order has been successfully completed.',
          textAlign: TextAlign.center,
          style: AppTheme.hind(14, c: AppColors.muted, h: 1.4),
        ),
        const Gap(24),
        AppCard(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              _summaryRow(
                'Order ID',
                Text('#${order.orderNumber}', style: AppTheme.hind(14, w: FontWeight.w700)),
              ),
              _summaryRow(
                'Completed On',
                Text(
                  DateFormat('d MMM yyyy, hh:mm a').format(latestStatus.createdAt.toLocal()),
                  style: AppTheme.hind(13.5),
                ),
              ),
              _summaryRow('Customer', Text(buyerName, style: AppTheme.hind(13.5))),
              if (order.items.isNotEmpty)
                _summaryRow(
                  'Items',
                  Text(
                    '${order.items.first.titleSnapshot} x ${order.items.first.quantity}',
                    style: AppTheme.hind(13.5),
                  ),
                ),
              _summaryRow(
                'Total Amount',
                Text('\u20B9 ${order.totalAmount}', style: AppTheme.hind(14, w: FontWeight.w700)),
              ),
              _summaryRow(
                'Payment Status',
                StatusBadge(
                  label: order.paymentStatus.toUpperCase() == 'PAID'
                      ? 'Paid Online'
                      : order.paymentStatus.toUpperCase(),
                  background: AppColors.greenSoft,
                  foreground: AppColors.green,
                  icon: Icons.check_circle,
                ),
                last: true,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildAcceptedTimelineView(
    SellerOrderEntity order,
    List<OrderStatusHistoryEntity> history,
  ) {
    final status = order.orderStatus.toUpperCase();
    final isAccepted = status == 'ACCEPTED';

    return Column(
      children: [
        const Gap(10),
        Container(
          width: 58,
          height: 58,
          decoration: const BoxDecoration(
            color: AppColors.green,
            shape: BoxShape.circle,
          ),
          child: const Center(
            child: HugeIcon(
              icon: HugeIcons.strokeRoundedCheck,
              color: AppColors.bg,
              size: 36,
            ),
          ),
        ),
        const Gap(14),
        Text(
          isAccepted ? 'Order Accepted' : _labelFor(status),
          style: AppTheme.display(20, w: FontWeight.w800, c: AppColors.ink),
        ),
        const Gap(8),
        Text(
          isAccepted
              ? 'You have accepted the order.\nNow prepare the order and mark it\nas ready when done.'
              : 'Track order progress and update status as you fulfill the order.',
          textAlign: TextAlign.center,
          style: AppTheme.hind(14, c: AppColors.muted, h: 1.4),
        ),
        const Gap(28),
        _buildStatusTimeline(history),
        const Gap(20),
        _buildInfoTipBanner(status),
      ],
    );
  }

  Widget _summaryRow(String label, Widget right, {bool last = false}) {
    return Padding(
      padding: EdgeInsets.only(bottom: last ? 0 : 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: AppTheme.hind(13.5, c: AppColors.muted)),
          right,
        ],
      ),
    );
  }

  Widget _buildVerticalStep({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String? subtitle,
    required bool isCompleted,
    required bool hasLineBelow,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          children: [
            Icon(icon, color: iconColor, size: 22),
            if (hasLineBelow)
              Container(
                width: 1.5,
                height: 38,
                color: isCompleted ? AppColors.green : AppColors.border,
              ),
          ],
        ),
        const Gap(14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: AppTheme.hind(
                  14,
                  w: isCompleted ? FontWeight.w700 : FontWeight.w500,
                  c: isCompleted ? AppColors.ink : AppColors.muted,
                ),
              ),
              if (subtitle != null) ...[
                const Gap(2),
                Text(subtitle, style: AppTheme.hind(12, c: AppColors.muted)),
              ],
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildInfoTipBanner(String status) {
    String tipText;
    switch (status) {
      case 'ACCEPTED':
        tipText = "Please prepare the order and mark it as 'Ready for Pickup' when it is ready.";
        break;
      case 'PREPARING':
        tipText = "The order is being prepared. Mark it as 'Ready for Pickup' when ready.";
        break;
      case 'READY_FOR_PICKUP':
        tipText = "Order is ready for pickup or dispatch. Hand it over to customer or delivery partner.";
        break;
      case 'OUT_FOR_DELIVERY':
        tipText = "Order is out for delivery. Keep your phone nearby for customer updates.";
        break;
      default:
        tipText = "Keep the order details updated for seamless tracking.";
    }

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.greenSoft,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.green.withValues(alpha: 0.3)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.info_outline_rounded, color: AppColors.green, size: 20),
          const Gap(10),
          Expanded(
            child: Text(
              tipText,
              style: AppTheme.hind(13, c: AppColors.greenDeep, h: 1.3),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomButtons(
    BuildContext context,
    SellerOrderEntity order,
    OrderStatusHistoryEntity latestStatus,
    String name,
    String nextStep,
  ) {
    final status = order.orderStatus.toUpperCase();
    final isTerminal = ['CANCELLED', 'REJECTED', 'COMPLETED'].contains(status);

    String? nextActionLabel;
    switch (status) {
      case 'ACCEPTED':
        nextActionLabel = 'Mark as Preparing';
        break;
      case 'PREPARING':
        nextActionLabel = 'Ready for Pickup / Delivery';
        break;
      case 'READY_FOR_PICKUP':
        nextActionLabel = 'Mark as Out for Delivery';
        break;
      case 'OUT_FOR_DELIVERY':
        nextActionLabel = 'Mark as Completed';
        break;
      default:
        nextActionLabel = null;
    }

    return Container(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: AppColors.border)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (!isTerminal && nextActionLabel != null) ...[
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  context.push(
                    '/modules/seller/orderUpdate',
                    extra: OrderStatusUpdateArgs(order: order, stage: latestStatus),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.green,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                child: Text(
                  nextActionLabel,
                  style: AppTheme.hind(15, w: FontWeight.w700, c: Colors.white),
                ),
              ),
            ),
            const Gap(10),
          ],
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: () {
                context.push(
                  '/modules/seller/orderDetails',
                  extra: OrderDetailsArgs(order: order, buyerName: name),
                );
              },
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: AppColors.border),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: Text(
                'View Order Details',
                style: AppTheme.hind(14, w: FontWeight.w600, c: AppColors.ink),
              ),
            ),
          ),
          const Gap(10),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                context.pop();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: isTerminal ? AppColors.green : Colors.grey.shade100,
                foregroundColor: isTerminal ? Colors.white : AppColors.ink,
                elevation: 0,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: Text(
                'Go to Orders',
                style: AppTheme.hind(
                  14,
                  w: FontWeight.w600,
                  c: isTerminal ? Colors.white : AppColors.ink,
                ),
              ),
            ),
          ),
          if (!isTerminal) ...[
            const Gap(6),
            TextButton(
              onPressed: () {
                context.push(
                  '/modules/seller/orderUpdate',
                  extra: OrderStatusUpdateArgs(order: order, stage: latestStatus),
                );
              },
              child: Text(
                'Update Order Status',
                style: AppTheme.hind(13, w: FontWeight.w600, c: AppColors.blue),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildStatusTimeline(List<OrderStatusHistoryEntity> history, {bool isPaid = false}) {
    final items = _buildTimelineItems(history, isPaid: isPaid);
    final dateFormat = DateFormat('dd MMM yyyy, hh:mm a');

    return Column(
      children: List.generate(items.length, (index) {
        final item = items[index];
        final isFailure =
            item.status == 'CANCELLED' ||
            item.status == 'REJECTED' ||
            item.status == 'PAYMENT_FAILED';

        return _buildVerticalStep(
          icon: item.isCompleted
              ? (isFailure ? Icons.cancel_rounded : Icons.check_circle_rounded)
              : Icons.circle_outlined,
          iconColor: item.isCompleted
              ? (isFailure ? AppColors.red : AppColors.green)
              : AppColors.border,
          title: item.label,
          subtitle: item.isCompleted ? dateFormat.format(item.time!) : null,
          isCompleted: item.isCompleted,
          hasLineBelow: index != items.length - 1,
        );
      }),
    );
  }
}

const Map<String, String> _statusLabels = {
  'CREATED': 'Order Placed',
  'PAYMENT_PENDING': 'Payment Pending',
  'PAID': 'Payment Successful',
  'ACCEPTED': 'Order Accepted',
  'PREPARING': 'Preparing',
  'READY_FOR_PICKUP': 'Ready for Pickup',
  'OUT_FOR_DELIVERY': 'Out for Delivery',
  'COMPLETED': 'Completed',
  'CANCELLED': 'Order Cancelled',
  'REJECTED': 'Order Rejected',
  'PAYMENT_FAILED': 'Payment Failed',
  'REFUNDED': 'Refunded',
};

const List<String> _fulfilmentFlow = [
  'CREATED',
  'ACCEPTED',
  'PREPARING',
  'READY_FOR_PICKUP',
  'OUT_FOR_DELIVERY',
  'COMPLETED',
];

const Set<String> _terminalStatuses = {'CANCELLED', 'REJECTED', 'REFUNDED'};

String _labelFor(String status) =>
    _statusLabels[status] ??
    status.split('_').map((w) => w.isEmpty ? w : w[0] + w.substring(1).toLowerCase()).join(' ');

class _TimelineItem {
  final String status;
  final String label;
  final DateTime? time;
  const _TimelineItem(this.status, this.label, this.time);
  bool get isCompleted => time != null;
}

List<_TimelineItem> _buildTimelineItems(
  List<OrderStatusHistoryEntity> history, {
  bool isPaid = false,
}) {
  final Map<String, OrderStatusHistoryEntity> byStatus = {};
  for (final h in history) {
    final existing = byStatus[h.newStatus];
    if (existing == null || h.createdAt.isAfter(existing.createdAt)) {
      byStatus[h.newStatus] = h;
    }
  }

  final completed = byStatus.values.toList()..sort((a, b) => a.createdAt.compareTo(b.createdAt));

  final items = <_TimelineItem>[
    for (final h in completed) _TimelineItem(h.newStatus, _labelFor(h.newStatus), h.createdAt),
  ];

  if (byStatus.keys.any(_terminalStatuses.contains)) return items;

  int lastIdx = -1;
  for (final s in byStatus.keys) {
    final i = _fulfilmentFlow.indexOf(s);
    if (i > lastIdx) lastIdx = i;
  }

  final pending = <String>[
    for (int i = lastIdx + 1; i < _fulfilmentFlow.length; i++)
      if (!byStatus.containsKey(_fulfilmentFlow[i])) _fulfilmentFlow[i],
  ];

  final paymentDone = isPaid || byStatus.containsKey('PAID');
  if (!paymentDone) {
    final completedIdx = pending.indexOf('COMPLETED');
    if (completedIdx != -1) {
      pending.insert(completedIdx, 'PAID');
    } else {
      pending.add('PAID');
    }
  }

  items.addAll(pending.map((s) => _TimelineItem(s, _labelFor(s), null)));
  return items;
}
