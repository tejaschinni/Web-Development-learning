import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/core/providers/app_providers.dart';
import 'package:society_seva/features/seller/data/datasources/match_me_remote_datasource.dart';
import 'package:society_seva/features/seller/domain/entities/match_me_entity.dart';
import 'package:society_seva/features/seller/domain/entities/match_me_offer_entity.dart';
import 'package:society_seva/features/seller/domain/repositories/match_me_repository.dart';

final matchMeRemoteDataSourceProvider = Provider<MatchMeRemoteDataSource>((ref) {
  return MatchMeRemoteDataSourceImpl(ref.watch(apiClientProvider));
});

final matchMeRepositoryProvider = Provider<MatchMeRepository>((ref) {
  return MatchMeRepositoryImpl(ref.watch(matchMeRemoteDataSourceProvider));
});

/// Fetches paginated matching buyer requirements for the logged-in seller.
final matchingRequirementsPageProvider = FutureProvider.autoDispose
    .family<PageResponse<MatchMeEntity>, int>((ref, page) {
  return ref.watch(matchMeRepositoryProvider).fetchMatcingRequirmentForSellerRepo(page: page);
});

/// Default matching buyer requirements list.
final matchingRequirementsProvider = FutureProvider.autoDispose<List<MatchMeEntity>>((ref) async {
  final page = await ref.watch(matchMeRepositoryProvider).fetchMatcingRequirmentForSellerRepo();
  return page.content;
});

/// Fetches all posted offers for a specific requirement ID.
final requirementOffersProvider = FutureProvider.autoDispose
    .family<List<MatchMeOfferEntity>, String>((ref, requirementId) {
  return ref.watch(matchMeRepositoryProvider).fetchOffersForRequirementRepo(requirementId: requirementId);
});

/// State for handling action execution (submitting offers, marking not interested).
class MatchMeActionState {
  const MatchMeActionState({
    this.actionLoadingId,
    this.isSubmittingOffer = false,
    this.error,
    this.successMessage,
  });

  final String? actionLoadingId;
  final bool isSubmittingOffer;
  final String? error;
  final String? successMessage;

  bool isActionLoading(String id) => actionLoadingId == id;
}

final matchMeActionProvider =
    NotifierProvider<MatchMeActionNotifier, MatchMeActionState>(MatchMeActionNotifier.new);

class MatchMeActionNotifier extends Notifier<MatchMeActionState> {
  @override
  MatchMeActionState build() => const MatchMeActionState();

  Future<bool> markNotInterested(String requirementId) async {
    state = MatchMeActionState(actionLoadingId: requirementId);
    try {
      await ref
          .read(matchMeRepositoryProvider)
          .markNotInterestedRepo(requirementId: requirementId);
      ref.invalidate(matchingRequirementsProvider);
      state = const MatchMeActionState(
        successMessage: 'Requirement dismissed',
      );
      return true;
    } catch (e) {
      state = MatchMeActionState(error: e.toString());
      return false;
    }
  }

  Future<bool> postOffer({
    required String requirementId,
    required CreateMatchMeOfferRequest request,
  }) async {
    state = MatchMeActionState(actionLoadingId: requirementId, isSubmittingOffer: true);
    try {
      await ref.read(matchMeRepositoryProvider).postOfferRepo(
            requirementId: requirementId,
            request: request,
          );
      ref.invalidate(matchingRequirementsProvider);
      ref.invalidate(requirementOffersProvider(requirementId));
      state = const MatchMeActionState(
        successMessage: 'Your offer has been submitted successfully!',
      );
      return true;
    } catch (e) {
      state = MatchMeActionState(error: e.toString());
      return false;
    }
  }
}
