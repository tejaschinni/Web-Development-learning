import 'dart:convert';
import 'dart:developer';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/core/providers/app_providers.dart';
import 'package:society_seva/core/utils/date_formatter.dart';
import 'package:society_seva/features/seller/data/datasources/seller_listing_remote_datasource.dart';
import 'package:society_seva/features/seller/data/models/request/food_additional_information_request.dart';
import 'package:society_seva/features/seller/data/models/request/seller_listing_basic_info_request.dart';
import 'package:society_seva/features/seller/data/models/request/service_additional_information_request.dart';
import 'package:society_seva/features/seller/domain/entities/seller_listing_entity.dart';
import 'package:society_seva/features/seller/domain/entities/seller_listing_images_entity.dart';
import 'package:society_seva/features/seller/domain/entities/service_slot_entity.dart';
import 'package:society_seva/features/seller/domain/enum/category_type.dart';
import 'package:society_seva/features/seller/domain/repositories/seller_listing_repository.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/shop/data/models/shop_category_model.dart';
import 'package:society_seva/features/shop/domain/enums/shop_category_type.dart';

final sellerListingRemoteDataSource = Provider<SellerListingRemoteDatasource>((ref) {
  return SellerListingRemoteDataSourceImpl(ref.watch(apiClientProvider));
});

final sellerListingRemoteRepository = Provider<SellerListingRepository>((ref) {
  return SellerListingRepositoryImpl(ref.watch(sellerListingRemoteDataSource));
});
final sellerListingProvider =
    FutureProvider.family<PageResponse<SellerListingEntity>, ({String sellerID})>((ref, args) {
      return ref.watch(sellerListingRemoteRepository).fetchMyListingRepo(sellerId: args.sellerID);
    });

final sellerListingImagesProvider = FutureProvider.family<List<SellerListingImageEntity>, String>((
  ref,
  id,
) {
  return ref.watch(sellerListingRemoteRepository).getListingImagesRepo(id);
});

final serviceScheduleDatesProvider =
    FutureProvider.family<List<DateTime>, ({String listingId, String from, String to})>((
      ref,
      args,
    ) {
      return ref
          .watch(sellerListingRemoteRepository)
          .fetchServiceAvailableDatesRepo(
            listingId: args.listingId,
            fromDate: args.from,
            toDate: args.to,
          );
    });

final serviceScheduleSlotsProvider =
    FutureProvider.family<List<ServiceSlotEntity>, ({String listingId, String date})>((ref, args) {
      return ref
          .watch(sellerListingRemoteRepository)
          .getServiceAvailableSlotsRepo(listingId: args.listingId, date: args.date);
    });

const kListingSteps = ['Category', 'Basic', 'Pricing', 'Details', 'Photos', 'Review'];
const kMaxListingImages = 6;
const kMaxImageBytes = 5 * 1024 * 1024;

const kPriceUnits = <String, String>{
  'PER_ITEM': 'Per item',
  'PER_PLATE': 'Per plate',
  'PER_KG': 'Per kg',
  'PER_HOUR': 'Per hour',
  'PER_SESSION': 'Per session',
  'FIXED': 'Fixed price',
};
const kServingUnits = <String, String>{
  'PLATE': 'Plate',
  'PIECE': 'Piece',
  'BOWL': 'Bowl',
  'GLASS': 'Glass',
  'CUP': 'Cup',
  'BOX': 'Box',
  'PACKET': 'Packet',
  'DOZEN': 'Dozen',
  'G': 'g',
  'KG': 'Kg',
  'ML': 'ml',
  'L': 'L',
};

const kAvailabilityStatuses = <String, String>{
  'AVAILABLE': 'Available',
  'UNAVAILABLE': 'Unavailable',
  'OUT_OF_STOCK': 'Out of stock',
  'PAUSED': 'Paused',
};

const kLocationTypes = <String, String>{
  'COMMON_AREA': 'Common area',
  'BUYER_FLAT': "Buyer's flat",
  'SELLER_FLAT': "Seller's flat",
  'ONLINE': 'Online',
  'EXTERNAL': 'External',
};

const kSpiceLevels = <String, int>{
  'NOT_APPLICABLE': 0,
  'MILD': 1,
  'MEDIUM': 3,
  'HOT': 4,
  'EXTRA_HOT': 5,
};

const kFoodTypes = <String, String>{
  'VEG': 'Veg',
  'NON_VEG': 'Non-veg',
  'VEGAN': 'Vegan',
  'EGG': 'Eggetarian',
};

enum ListingType {
  food('FOOD', 'Food'),
  product('PRODUCT', 'Product'),
  service('SERVICE', 'Service'),
  classes('CLASS', 'Class'),
  consultation('CONSULTATION', 'Consultation'),
  eventSupport('EVENT_SUPPORT', 'Event support'),
  help('HELP', 'Help'),
  grocery('GROCERY', 'Grocery');

  const ListingType(this.api, this.label);
  final String api;
  final String label;

  bool get isFood => this == food;

  bool get isService =>
      this == service ||
      this == classes ||
      this == consultation ||
      this == eventSupport ||
      this == help;

  bool get hasSlots =>
      this == service ||
      this == classes ||
      this == consultation ||
      this == eventSupport ||
      this == help;

  bool get needsStock => !isFood && !hasSlots;
}

extension CategoryTypeX on CategoryType {
  bool get isFoodCategory => name.toLowerCase().contains('food');
}

double? _d(TextEditingController c) => double.tryParse(c.text.trim());
int? _i(TextEditingController c) => int.tryParse(c.text.trim());
String? _t(TextEditingController c) {
  final v = c.text.trim();
  return v.isEmpty ? null : v;
}

String _two(int n) => n.toString().padLeft(2, '0');
String _hhmm(TimeOfDay t) => '${_two(t.hour)}:${_two(t.minute)}';
String ymd(DateTime d) => '${d.year}-${_two(d.month)}-${_two(d.day)}';

class ServingSizeDraft {
  ServingSizeDraft(VoidCallback onChanged) {
    for (final c in [sizeValue, sizeUnit, description, price, quantity]) {
      c.addListener(onChanged);
    }
  }

  final sizeValue = TextEditingController();
  final sizeUnit = TextEditingController();
  final description = TextEditingController();
  final price = TextEditingController();
  final quantity = TextEditingController();
  bool isAvailable = true;

  String get uniqueKey => '${sizeValue.text.trim()}|${sizeUnit.text.trim().toLowerCase()}';
  bool isValidFor({required bool isFree}) =>
      (_d(sizeValue) ?? 0) > 0 &&
      sizeUnit.text.trim().isNotEmpty &&
      description.text.trim().isNotEmpty &&
      (isFree || (_d(price) ?? 0) > 0) &&
      (_i(quantity) ?? -1) >= 0;
  // bool get isValid =>
  //     (_d(sizeValue) ?? 0) > 0 &&
  //     sizeUnit.text.trim().isNotEmpty &&
  //     description.text.trim().isNotEmpty &&
  //     (_d(price) ?? 0) > 0 &&
  //     (_i(quantity) ?? -1) >= 0;

  Map<String, dynamic> toJson() => {
    'sizeValue': _d(sizeValue),
    'sizeUnit': sizeUnit.text.trim(),
    'description': description.text.trim(),
    'price': _d(price),
    'quantityAvailable': _i(quantity) ?? 0,
    'isAvailable': isAvailable,
  };

  void dispose() {
    for (final c in [sizeValue, sizeUnit, description, price, quantity]) {
      c.dispose();
    }
  }
}

class SlotWindow {
  const SlotWindow(this.startsAt, this.endsAt);
  final String startsAt;
  final String endsAt;
  Map<String, String> toJson() => {'startsAt': startsAt, 'endsAt': endsAt};
}

class ListingFormControllers {
  ListingFormControllers(VoidCallback onChanged) {
    for (final c in all) {
      c.addListener(onChanged);
    }
  }

  // basic
  final title = TextEditingController();
  final description = TextEditingController();
  final tagInput = TextEditingController();
  // pricing
  final basePrice = TextEditingController();
  final quantity = TextEditingController();
  // service
  final duration = TextEditingController();
  final requiredMaterials = TextEditingController();
  final cancellationPolicy = TextEditingController();
  // food
  final prepTime = TextEditingController();
  final ingredients = TextEditingController();
  final allergens = TextEditingController();
  final freshness = TextEditingController();
  final storage = TextEditingController();
  final packaging = TextEditingController();
  final fssaiId = TextEditingController();
  final otherDietary = TextEditingController();

  List<TextEditingController> get all => [
    title,
    description,
    tagInput,
    basePrice,
    quantity,
    duration,
    requiredMaterials,
    cancellationPolicy,
    prepTime,
    ingredients,
    allergens,
    freshness,
    storage,
    packaging,
    fssaiId,
    otherDietary,
  ];

  void dispose() {
    for (final c in all) {
      c.dispose();
    }
  }
}

class ListingFormState {
  const ListingFormState({
    required this.categoryType,
    this.dirtySlotDates = const {},
    this.currentStep = 0,
    this.subcategoryId,
    this.mainCategoryId,
    this.isLoading = false,
    this.containsOnion = true,
    this.containsGarlic = true,
    this.jainFoodAvailable = true,
    this.glutenFree = false,
    this.otherDietary = false,
    this.listingType = ListingType.food,
    this.additionalCategoryIds = const {},
    this.tags = const [],
    this.isFree = false,
    this.priceUnit = 'PER_ITEM',
    this.availabilityStatus = 'AVAILABLE',
    this.locationType = 'COMMON_AREA',
    this.homeVisit = false,
    this.online = false,
    this.certificateRequired = false,
    this.foodType = 'VEG',
    this.spiceLevel = 'MEDIUM',
    this.frozen = false,
    this.fssaiRequired = false,
    this.expiryTime,
    this.servings = const [],
    this.slots = const {},
    this.pendingImages = const [],
    this.remoteImages = const [],
    this.deletingImageIds = const {},
    this.listingId,
    this.detailsSaved = false,
    this.isSaving = false,
    this.isSubmitting = false,
    this.isUploadingImages = false,
    this.error,
    this.revision = 0,
    this.approvalStatus,
  });

  // step 1
  final int currentStep;
  final CategoryType categoryType;
  final Set<String> dirtySlotDates;
  final String? subcategoryId;
  final String? mainCategoryId;
  final String? approvalStatus;
  // step 2
  final ListingType listingType;
  final Set<String> additionalCategoryIds;
  final List<String> tags;
  // step 3
  final bool containsOnion, containsGarlic, jainFoodAvailable, glutenFree, otherDietary;
  final bool isFree;
  final bool isLoading;
  final String priceUnit;
  final String availabilityStatus;
  final Map<String, List<SlotWindow>> slots; // 'yyyy-MM-dd' -> windows
  // step 4 (service)
  final String locationType;
  final bool homeVisit, online, certificateRequired;
  // step 4 (food)
  final String foodType;
  final String spiceLevel;
  final bool frozen, fssaiRequired;
  final DateTime? expiryTime;
  final List<ServingSizeDraft> servings;
  // step 5
  final List<XFile> pendingImages;
  final List<SellerListingImageEntity> remoteImages;
  final Set<String> deletingImageIds;
  // pipeline progress (lets a failed Save resume instead of duplicating)
  final String? listingId;
  final bool detailsSaved;
  final bool isSaving, isSubmitting, isUploadingImages;
  final Object? error;
  final int revision;

  bool get isBusy => isSaving || isSubmitting || isUploadingImages;
  List<SellerListingImageEntity> get visibleRemoteImages =>
      remoteImages.where((i) => !deletingImageIds.contains(i.id)).toList();
  int get totalImageCount => visibleRemoteImages.length + pendingImages.length;
  List<String> get selectedSubcategoryIds => [?subcategoryId, ...additionalCategoryIds];

  static const _keep = Object();

  ListingFormState copyWith({
    int? currentStep,
    CategoryType? categoryType,
    Set<String>? dirtySlotDates,
    Object? subcategoryId = _keep,
    Object? mainCategoryId = _keep,
    ListingType? listingType,
    Set<String>? additionalCategoryIds,
    String? approvalStatus,
    List<String>? tags,
    bool? isLoading,
    bool? isFree,
    bool? containsOnion,
    bool? containsGarlic,
    bool? jainFoodAvailable,
    bool? glutenFree,
    bool? otherDietary,
    String? priceUnit,
    String? availabilityStatus,
    String? locationType,
    bool? homeVisit,
    bool? online,
    bool? certificateRequired,
    String? foodType,
    String? spiceLevel,
    bool? frozen,
    bool? fssaiRequired,
    Object? expiryTime = _keep,
    List<ServingSizeDraft>? servings,
    Map<String, List<SlotWindow>>? slots,
    List<XFile>? pendingImages,
    List<SellerListingImageEntity>? remoteImages,
    Set<String>? deletingImageIds,
    Object? listingId = _keep,
    bool? detailsSaved,
    bool? isSaving,
    bool? isSubmitting,
    bool? isUploadingImages,
    Object? error,
    bool clearError = false,
    int? revision,
  }) => ListingFormState(
    currentStep: currentStep ?? this.currentStep,
    dirtySlotDates: dirtySlotDates ?? this.dirtySlotDates,
    categoryType: categoryType ?? this.categoryType,
    subcategoryId: identical(subcategoryId, _keep) ? this.subcategoryId : subcategoryId as String?,
    listingType: listingType ?? this.listingType,
    additionalCategoryIds: additionalCategoryIds ?? this.additionalCategoryIds,
    approvalStatus: approvalStatus ?? this.approvalStatus,
    tags: tags ?? this.tags,
    isFree: isFree ?? this.isFree,
    priceUnit: priceUnit ?? this.priceUnit,
    mainCategoryId: identical(mainCategoryId, _keep)
        ? this.mainCategoryId
        : mainCategoryId as String?,
    availabilityStatus: availabilityStatus ?? this.availabilityStatus,
    locationType: locationType ?? this.locationType,
    homeVisit: homeVisit ?? this.homeVisit,
    online: online ?? this.online,
    certificateRequired: certificateRequired ?? this.certificateRequired,
    foodType: foodType ?? this.foodType,
    spiceLevel: spiceLevel ?? this.spiceLevel,
    frozen: frozen ?? this.frozen,
    containsOnion: containsOnion ?? this.containsOnion,
    containsGarlic: containsGarlic ?? this.containsGarlic,
    jainFoodAvailable: jainFoodAvailable ?? this.jainFoodAvailable,
    glutenFree: glutenFree ?? this.glutenFree,
    otherDietary: otherDietary ?? this.otherDietary,
    fssaiRequired: fssaiRequired ?? this.fssaiRequired,
    expiryTime: identical(expiryTime, _keep) ? this.expiryTime : expiryTime as DateTime?,
    servings: servings ?? this.servings,
    slots: slots ?? this.slots,
    pendingImages: pendingImages ?? this.pendingImages,
    remoteImages: remoteImages ?? this.remoteImages,
    deletingImageIds: deletingImageIds ?? this.deletingImageIds,
    listingId: identical(listingId, _keep) ? this.listingId : listingId as String?,
    detailsSaved: detailsSaved ?? this.detailsSaved,
    isSaving: isSaving ?? this.isSaving,
    isSubmitting: isSubmitting ?? this.isSubmitting,
    isUploadingImages: isUploadingImages ?? this.isUploadingImages,
    error: clearError ? null : (error ?? this.error),
    revision: revision ?? this.revision,
    isLoading: isLoading ?? this.isLoading,
  );
}

final productListingProvider = NotifierProvider.autoDispose<ListingFormNotifier, ListingFormState>(
  ListingFormNotifier.new,
);

final listingStepValidProvider = Provider.autoDispose<bool>((ref) {
  final s = ref.watch(productListingProvider);
  return ref.read(productListingProvider.notifier).isStepValid(s.currentStep);
});

class ListingFormNotifier extends AutoDisposeNotifier<ListingFormState> {
  late ListingFormControllers controllers;

  // Used on update: only fields that differ from the snapshot are sent, and
  // if nothing differs the API call is skipped entirely.
  Map<String, Object?> _basicSnapshot = {};
  Map<String, Object?> _foodSnapshot = {};
  Map<String, Object?> _serviceSnapshot = {};

  Set<String> _changedKeys(Map<String, Object?> now, Map<String, Object?> before) =>
      now.keys.where((k) => jsonEncode(now[k]) != jsonEncode(before[k])).toSet();

  Map<String, Object?> _basicValues() {
    final s = state, c = controllers;

    log('this is the main category  ${s.mainCategoryId.toString()}');
    return {
      'additionalCategoryIds': (s.additionalCategoryIds.toList()..sort()),
      'basePrice': s.isFree ? 0 : _d(c.basePrice),
      // 'categoryId': s.subcategoryId ?? s.mainCategoryId,
      'categoryId': s.subcategoryId ?? s.mainCategoryId,
      'description': c.description.text.trim(),
      'isFree': s.isFree,
      'listingType': s.listingType.api,
      'priceUnit': s.priceUnit,
      'quantityAvailable': _i(c.quantity),
      'tagNames': s.tags,
      'title': c.title.text.trim(),
    };
  }

  Map<String, Object?> _foodValues() {
    final s = state, c = controllers;
    return {
      'allergens': _t(c.allergens),
      'expiryTime': s.expiryTime != null ? DateFormat('yyyy-MM-dd').format(s.expiryTime!) : '',
      'foodType': s.foodType,
      'freshnessDeclaration': _t(c.freshness),
      'fssaiCertificateId': _t(c.fssaiId),
      'fssaiRequired': s.fssaiRequired,
      'ingredients': c.ingredients.text.trim(),
      'isFrozenItem': s.frozen,
      'packagingDetails': _t(c.packaging),
      'preparationTime': c.prepTime.text.trim(),
      'servingSizes': s.servings
          .map(
            (d) => {
              'description': d.description.text.trim(),
              'isAvailable': d.isAvailable,
              'price': _d(d.price),
              'quantityAvailable': _i(d.quantity),
              'sizeUnit': d.sizeUnit.text.trim(),
              'sizeValue': _d(d.sizeValue),
            },
          )
          .toList(),
      'spiceLevel': s.spiceLevel,
      'storageInstruction': _t(c.storage),
    };
  }

  Map<String, Object?> _serviceValues() {
    final s = state, c = controllers;
    return {
      'cancellationPolicy': _t(c.cancellationPolicy),
      'certificateRequired': s.certificateRequired,
      'homeVisitAvailable': s.homeVisit,
      'onlineAvailable': s.online,
      'requiredMaterials': _t(c.requiredMaterials),
      'serviceDurationMinutes': _i(c.duration),
      'serviceLocationType': s.locationType,
    };
  }

  SellerListingRepository get repo => ref.read(sellerListingRemoteRepository);
  @override
  ListingFormState build() {
    controllers = ListingFormControllers(_onTextChanged);
    ref.onDispose(() {
      controllers.dispose();
      for (final d in state.servings) {
        d.dispose();
      }
    });
    return ListingFormState(
      categoryType: CategoryType.values.first,
      listingType: CategoryType.values.first.isFoodCategory
          ? ListingType.food
          : ListingType.product,
      servings: [ServingSizeDraft(_onTextChanged)],
    );
  }

  bool _isNotFound(Object e) {
    if (e is DioException) return e.response?.statusCode == 404;
    try {
      return (e as dynamic).statusCode == 404;
    } catch (_) {
      return false;
    }
  }

  Future<void> loadSlotsForDate(String date) async {
    final id = state.listingId;
    if (id == null || state.slots.containsKey(date)) return;

    List<ServiceSlotEntity> server;
    try {
      server = await repo.getServiceAvailableSlotsRepo(listingId: id, date: date);
    } catch (e) {
      if (_isNotFound(e)) return;
      rethrow;
    }
    if (server.isEmpty) return;

    final fmt = DateFormat('HH:mm');
    final windows =
        server.map((x) => SlotWindow(fmt.format(x.startsAt), fmt.format(x.endsAt))).toList()
          ..sort((a, b) => a.startsAt.compareTo(b.startsAt));

    if (state.slots.containsKey(date)) return;
    state = state.copyWith(slots: {...state.slots, date: windows});
  }

  Future<void> loadListingForEdit(String listingId) async {
    if (state.listingId == listingId) return;
    state = state.copyWith(isLoading: true, listingId: listingId, clearError: true);

    try {
      final l = await repo.fetchListingByIDRepo(listingId: listingId);
      final type = ListingType.values.firstWhere(
        (t) => t.api == l?.listingType.toString().toUpperCase(),
        orElse: () => ListingType.product,
      );

      final c = controllers;
      c.title.text = l?.title ?? '';
      c.description.text = l?.description ?? '';
      c.basePrice.text = (l?.isFree ?? false) ? '' : (l?.basePrice.toString() ?? '');
      c.quantity.text = l?.quantityAvailable.toString() ?? '';

      var detailsExist = false;
      var servings = state.servings;
      var foodType = state.foodType;
      var spice = state.spiceLevel;
      var frozen = state.frozen, fssai = state.fssaiRequired;
      DateTime? expiry;
      var locationType = state.locationType;
      var homeVisit = state.homeVisit, online = state.online, cert = state.certificateRequired;

      if (type.isFood) {
        try {
          final f = await repo.fetchAdditionalFoodInformationRepo(listingId: listingId); // guess
          detailsExist = true;

          c.prepTime.text = minutesFromEpochString(f.preparationTime?.toString() ?? '').toString();
          c.ingredients.text = f.ingredients ?? '';
          c.allergens.text = f.allergens ?? '';
          c.freshness.text = f.freshnessDeclaration ?? '';
          c.storage.text = f.storageInstruction ?? '';
          c.packaging.text = f.packagingDetails ?? '';
          c.fssaiId.text = f.fssaiCertificateId ?? '';

          foodType = f.foodType ?? foodType;
          spice = f.spiceLevelText ?? spice;
          frozen = f.isFrozenItem ?? false;
          fssai = f.fssaiRequired == true || f.fssaiRequired.toString() == 'true';
          expiry = DateTime.tryParse(f.expiryTime ?? '');

          for (final d in state.servings) {
            d.dispose();
          }
          servings = f.servingSizes.map<ServingSizeDraft>((s) {
            final d = ServingSizeDraft(_onTextChanged);
            d.sizeValue.text = s.sizeValue.toString();
            d.sizeUnit.text = s.sizeUnit;
            d.description.text = s.description;
            d.price.text = s.price.toString();
            d.quantity.text = s.quantityAvailable.toString();
            d.isAvailable = s.isAvailable;
            return d;
          }).toList();

          if (servings.isEmpty) servings = [ServingSizeDraft(_onTextChanged)];
          state = state.copyWith(detailsSaved: true);
        } catch (_) {
          state = state.copyWith(detailsSaved: false);
        }
      } else if (type.isService) {
        try {
          final s = await repo.fetchAdditionalServiceInformationRepo(listingId: listingId); // guess
          detailsExist = true;

          c.duration.text = s.serviceDurationMinutes?.toString() ?? '';
          c.requiredMaterials.text = s.requiredMaterials ?? '';
          c.cancellationPolicy.text = s.cancellationPolicy ?? '';
          locationType = s.serviceLocationType ?? locationType;
          homeVisit = s.homeVisitAvailable ?? false;
          online = s.onlineAvailable ?? false;
          cert = s.certificateRequired ?? false;
          state = state.copyWith(detailsSaved: true);
        } catch (_) {
          state = state.copyWith(detailsSaved: false);
        }
      }

      final images = await repo.getListingImagesRepo(listingId);

      state = state.copyWith(
        isLoading: false,
        currentStep: 0,
        listingType: type,
        categoryType: CategoryType.values.firstWhere(
          (t) => t.isFoodCategory == type.isFood,
          orElse: () => state.categoryType,
        ),
        subcategoryId: l?.categoryId,
        additionalCategoryIds: (l?.additionalCategoryIds ?? const <String>[]).toSet(),
        tags: List<String>.from(l?.tagNames ?? const []),
        isFree: l?.isFree ?? false,
        priceUnit: l?.priceUnit ?? state.priceUnit,
        availabilityStatus: l?.availabilityStatus ?? state.availabilityStatus,
        foodType: foodType,
        spiceLevel: spice,
        frozen: frozen,
        fssaiRequired: fssai,
        approvalStatus: l?.approvalStatus,
        expiryTime: expiry,
        servings: servings,
        locationType: locationType,
        homeVisit: homeVisit,
        online: online,
        certificateRequired: cert,
        remoteImages: images,
        detailsSaved: detailsExist,
      );

      _basicSnapshot = _basicValues();
      _foodSnapshot = (detailsExist && type.isFood) ? _foodValues() : {};
      _serviceSnapshot = (detailsExist && type.isService) ? _serviceValues() : {};
    } catch (e) {
      state = state.copyWith(isLoading: false, listingId: null, error: e);
    }
  }

  void _onTextChanged() => state = state.copyWith(revision: state.revision + 1);

  void next() {
    if (state.currentStep < kListingSteps.length - 1 && isStepValid(state.currentStep)) {
      state = state.copyWith(currentStep: state.currentStep + 1);
    }
  }

  void back() {
    if (state.currentStep > 0) state = state.copyWith(currentStep: state.currentStep - 1);
  }

  void goTo(int step) {
    if (step < state.currentStep ||
        (step == state.currentStep + 1 && isStepValid(state.currentStep))) {
      state = state.copyWith(currentStep: step);
    }
  }

  void selectCategory(CategoryType type) {
    if (type == state.categoryType) return;
    state = state.copyWith(
      categoryType: type,
      subcategoryId: null,
      additionalCategoryIds: {},
      listingType: type.isFoodCategory ? ListingType.food : ListingType.product,
    );
  }

  void selectMainCategory(ShopCategoryModel c) {
    if (c.id == state.mainCategoryId) return;
    state = state.copyWith(
      mainCategoryId: c.id,
      subcategoryId: null,
      additionalCategoryIds: <String>{},
      listingType: switch (c.categoryType) {
        ShopCategoryType.food => ListingType.food,
        ShopCategoryType.service => ListingType.service,
        _ => ListingType.product,
      },
    );
  }

  void hydrateMainCategory(String mainId) {
    if (state.mainCategoryId != null) return;
    state = state.copyWith(
      mainCategoryId: mainId,
      subcategoryId: state.subcategoryId == mainId ? null : state.subcategoryId,
    );
  }

  void toggleSubcategory(String id) {
    final extra = {...state.additionalCategoryIds};
    var primary = state.subcategoryId;

    if (id == primary) {
      primary = extra.isEmpty ? null : extra.first;
      if (primary != null) extra.remove(primary);
    } else if (!extra.remove(id)) {
      if (primary == null) {
        primary = id;
      } else {
        extra.add(id);
      }
    }
    state = state.copyWith(subcategoryId: primary, additionalCategoryIds: extra);
  }

  void selectSubcategory(String id) {
    state = state.copyWith(
      subcategoryId: id,
      additionalCategoryIds: {...state.additionalCategoryIds}..remove(id),
    );
  }

  void setListingType(ListingType t) => state = state.copyWith(listingType: t);

  void toggleAdditionalCategory(String id) {
    final set = {...state.additionalCategoryIds};
    set.contains(id) ? set.remove(id) : set.add(id);
    state = state.copyWith(additionalCategoryIds: set);
  }

  void addTag(String tag) {
    final trimmed = tag.trim();
    if (trimmed.isEmpty) return;
    final tags = [...state.tags];
    if (!tags.contains(trimmed) && tags.length < 10) {
      tags.add(trimmed);
      state = state.copyWith(tags: tags);
    }
  }

  void addTagsFromInput() {
    final parts = controllers.tagInput.text
        .split(',')
        .map((e) => e.trim().toLowerCase())
        .where((e) => e.isNotEmpty);
    final tags = [...state.tags];
    for (final p in parts) {
      if (!tags.contains(p) && tags.length < 10) tags.add(p);
    }
    controllers.tagInput.clear();
    state = state.copyWith(tags: tags);
  }

  void removeTag(String tag) =>
      state = state.copyWith(tags: state.tags.where((t) => t != tag).toList());

  void setFree(bool v) {
    if (v) controllers.basePrice.clear();
    state = state.copyWith(isFree: v);
  }

  void setPriceUnit(String v) => state = state.copyWith(priceUnit: v);
  void setAvailabilityStatus(String v) => state = state.copyWith(availabilityStatus: v);

  String? addSlot(DateTime date, TimeOfDay start, TimeOfDay end) {
    final s = _hhmm(start), e = _hhmm(end);
    if (s.compareTo(e) >= 0) return 'End time must be after start time';
    final key = ymd(date);
    final list = [...?state.slots[key]];
    if (list.any((w) => s.compareTo(w.endsAt) < 0 && e.compareTo(w.startsAt) > 0)) {
      return 'This overlaps an existing window';
    }
    list
      ..add(SlotWindow(s, e))
      ..sort((a, b) => a.startsAt.compareTo(b.startsAt));
    state = state.copyWith(
      slots: {...state.slots, key: list},
      dirtySlotDates: {...state.dirtySlotDates, key},
    );
    return null;
  }

  void removeSlot(String dateKey, SlotWindow w) {
    final list = (state.slots[dateKey] ?? const <SlotWindow>[]).where((x) => x != w).toList();
    state = state.copyWith(
      slots: {...state.slots, dateKey: list},
      dirtySlotDates: {...state.dirtySlotDates, dateKey},
    );
  }

  void setLocationType(String v) => state = state.copyWith(locationType: v);
  void setHomeVisit(bool v) => state = state.copyWith(homeVisit: v);
  void setOnline(bool v) => state = state.copyWith(online: v);
  void setCertificateRequired(bool v) => state = state.copyWith(certificateRequired: v);
  void setFoodType(String v) => state = state.copyWith(foodType: v);
  void setSpiceLevel(String v) => state = state.copyWith(spiceLevel: v);
  void setFrozen(bool v) => state = state.copyWith(frozen: v);
  void setExpiry(DateTime? v) => state = state.copyWith(expiryTime: v);
  void setContainsOnion(bool v) {
    state = state.copyWith(containsOnion: v);
    if (v) {
      addTag('Contains Onion');
    } else {
      removeTag('Contains Onion');
    }
  }

  void setContainsGarlic(bool v) {
    state = state.copyWith(containsGarlic: v);
    if (v) {
      addTag('Contains Garlic');
    } else {
      removeTag('Contains Garlic');
    }
  }

  void setJainFoodAvailable(bool v) {
    state = state.copyWith(jainFoodAvailable: v);
    if (v) {
      addTag('Jain Food Available');
    } else {
      removeTag('Jain Food Available');
    }
  }

  void setGlutenFree(bool v) {
    state = state.copyWith(glutenFree: v);
    if (v) {
      addTag('Gluten Free');
    } else {
      removeTag('Gluten Free');
    }
  }

  void setOtherDietary(bool v) => state = state.copyWith(otherDietary: v);

  void setFssaiRequired(bool v) {
    if (!v) controllers.fssaiId.clear();
    state = state.copyWith(fssaiRequired: v);
  }

  void addServing() =>
      state = state.copyWith(servings: [...state.servings, ServingSizeDraft(_onTextChanged)]);

  void removeServing(int index) {
    if (state.servings.length <= 1) return;
    final list = [...state.servings];
    final removed = list.removeAt(index);
    state = state.copyWith(servings: list);
    WidgetsBinding.instance.addPostFrameCallback((_) => removed.dispose());
  }

  void setServingAvailable(int index, bool v) {
    state.servings[index].isAvailable = v;
    state = state.copyWith(revision: state.revision + 1);
  }

  Future<String?> addPendingImages(List<XFile> files) async {
    final room = kMaxListingImages - state.totalImageCount;
    if (room <= 0) return 'You can add up to $kMaxListingImages photos';
    final accepted = <XFile>[];
    String? msg;
    for (final f in files) {
      if (accepted.length >= room) {
        msg = 'Only $kMaxListingImages photos allowed';
        break;
      }
      if (await f.length() > kMaxImageBytes) {
        msg = 'Each photo must be under 5 MB';
        continue;
      }
      if (state.pendingImages.any((p) => p.path == f.path)) continue;
      accepted.add(f);
    }
    state = state.copyWith(pendingImages: [...state.pendingImages, ...accepted]);
    return msg;
  }

  void removePendingImage(XFile f) => state = state.copyWith(
    pendingImages: state.pendingImages.where((p) => p.path != f.path).toList(),
  );

  void markRemoteForDelete(String id) =>
      state = state.copyWith(deletingImageIds: {...state.deletingImageIds, id});

  void unmarkRemoteForDelete(String id) =>
      state = state.copyWith(deletingImageIds: {...state.deletingImageIds}..remove(id));

  bool isStepValid(int step) {
    final s = state, c = controllers;
    switch (step) {
      case 0:
        return s.mainCategoryId != null || s.subcategoryId != null;
      case 1:
        return _t(c.title) != null && _t(c.description) != null;
      case 2:
        final t = s.listingType;
        if (t.isFood) {
          if (s.servings.isEmpty) return false;
          if (!s.servings.every((d) => d.isValidFor(isFree: s.isFree))) return false;

          return s.servings.map((d) => d.uniqueKey).toSet().length == s.servings.length;
        }
        if (!s.isFree && (_d(c.basePrice) ?? 0) <= 0) return false;
        if (s.priceUnit.isEmpty) return false;

        if (t.needsStock) {
          if ((_i(c.quantity) ?? 0) <= 0) return false;
          if (s.availabilityStatus.isEmpty) return false;
        }
        return true;
      case 3:
        if (s.listingType.isFood) {
          if (_i(c.prepTime) == null || _t(c.ingredients) == null || _t(c.freshness) == null) {
            return false;
          }
          if (s.fssaiRequired && _t(c.fssaiId) == null) return false;
          return true;
        }
        if (s.listingType.isService) return (_i(c.duration) ?? 0) > 0;
        return true;
      case 4:
        return true;

      case 5:
        return true;
      default:
        return false;
    }
  }

  Future<bool> save() => _persist(submit: false);
  Future<bool> submit() => _persist(submit: true);

  Future<bool> _persist({required bool submit}) async {
    if (state.isBusy) {
      debugPrint('PERSIST: Already busy');
      return false;
    }

    state = state.copyWith(isSaving: !submit, isSubmitting: submit, clearError: true);

    try {
      debugPrint('PERSIST: Started');

      final sellerId = ref.read(mySellerProfileProvider).value?.id;

      if (sellerId == null || sellerId.isEmpty) {
        throw Exception('Seller profile not found. Please complete seller registration first.');
      }

      var listingId = state.listingId;

      if (listingId == null) {
        debugPrint('PERSIST: Creating listing');
        listingId = await _createListing(sellerId);
        state = state.copyWith(listingId: listingId);
        debugPrint('PERSIST: Listing created: $listingId');
      } else {
        final currentStatus = state.approvalStatus?.toUpperCase();
        final isApproved = currentStatus == 'APPROVED' || currentStatus == 'APPROVAL';
        if (!isApproved || !submit) {
          debugPrint('PERSIST: Updating listing: $listingId');
          await _updateListing(listingId);
          debugPrint('PERSIST: Listing update step done');
        }
      }

      debugPrint('PERSIST: Saving details');
      await _saveDetails(listingId);
      debugPrint('PERSIST: Details step done');

      debugPrint('PERSIST: Saving slots');
      await _saveSlots(listingId);
      debugPrint('PERSIST: Slots saved');

      debugPrint('PERSIST: Processing images');
      await _flushImages(listingId);
      debugPrint('PERSIST: Images processed');

      if (submit) {
        final currentStatus = state.approvalStatus?.toUpperCase();
        final isApproved = currentStatus == 'APPROVED' || currentStatus == 'APPROVAL';

        if (isApproved) {
          debugPrint('PERSIST: Listing status is approved ($currentStatus), calling update API');
          await _updateListing(listingId, force: true);
          debugPrint('PERSIST: Update API completed for approved listing');
        } else {
          // Status is DRAFT, DRAFTED, SUBMITTED, or newly created
          debugPrint('PERSIST: Listing status is drafted or submitted ($currentStatus), calling submit API');
          await _submitListing(listingId);
          debugPrint('PERSIST: Submit API completed');
        }
      }

      debugPrint('PERSIST: Completed successfully');
      return true;
    } catch (e, stackTrace) {
      debugPrint('PERSIST ERROR: $e');
      debugPrint('$stackTrace');

      state = state.copyWith(error: e);
      return false;
    } finally {
      state = state.copyWith(isSaving: false, isSubmitting: false);
    }
  }

  Future<String> _createListing(String sellerId) async {
    final payload = _basicPayload(sellerId);

    final result = await repo.createListingRepo(request: payload);

    _basicSnapshot = _basicValues();

    return result!.id.toString();
  }

  Future<void> _updateListing(String listingId, {bool force = false}) async {
    final now = _basicValues();
    final changed = _changedKeys(now, _basicSnapshot);

    if (!force && changed.isEmpty) {
      debugPrint('PERSIST: basic info unchanged, skipping update API');
      return;
    }

    final payload = _basicPayload(null, only: force ? null : (changed.isEmpty ? null : changed));

    await repo.updateSubmitListingRepo(listingId: listingId, request: payload);
    _basicSnapshot = now;
  }

  Future<void> _saveDetails(String listingId) async {
    final type = state.listingType;

    if (type.isFood) {
      debugPrint('SAVE DETAIL: type food');
      if (!state.detailsSaved) {
        debugPrint('SAVE DETAIL: detail not saved ');
        await repo.additionalFoodInformationRepo(listingId: listingId, request: _foodPayload());
        _foodSnapshot = _foodValues();
      } else {
        debugPrint('SAVE DETAIL: detail saved');
        final now = _foodValues();
        final changed = _changedKeys(now, _foodSnapshot);
        if (changed.isEmpty) {
          debugPrint('PERSIST: food details unchanged, skipping update API');
          return;
        }
        await repo.updateAdditionalFoodInformationRepo(
          listingId: listingId,
          request: _foodPayload(only: changed),
        );
        _foodSnapshot = now;
      }
    } else if (type.isService) {
      debugPrint('SAVE DETAIL: type service');
      if (!state.detailsSaved) {
        final servicePayload = _servicePayload();
        await repo.additionalServiceInformationRepo(listingId: listingId, request: servicePayload);
        _serviceSnapshot = _serviceValues();

        debugPrint('SAVE DETAIL: detail no saved');
      } else {
        debugPrint('SAVE DETAIL: detail saved ');

        final now = _serviceValues();
        final changed = _changedKeys(now, _serviceSnapshot);
        if (changed.isEmpty) {
          debugPrint('PERSIST: service details unchanged, skipping update API');
          return;
        }
        final servicePayload = _servicePayload(only: changed);

        await repo.updateAdditionalServiceInformationRepo(
          listingId: listingId,
          request: servicePayload,
        );
        _serviceSnapshot = now;
      }
    } else {
      return;
    }

    state = state.copyWith(detailsSaved: true);
  }

  Future<void> _saveSlots(String listingId) async {
    if (!state.listingType.hasSlots) return;

    for (final key in state.dirtySlotDates.toList()) {
      final windows = (state.slots[key] ?? const <SlotWindow>[]).map((w) => w.toJson()).toList();
      await repo.saveServiceSlotsRepo(listingId: listingId, date: key, windows: windows);

      final slots = {...state.slots};
      if (windows.isEmpty) slots.remove(key);
      state = state.copyWith(slots: slots, dirtySlotDates: {...state.dirtySlotDates}..remove(key));
    }
    ref.invalidate(serviceScheduleDatesProvider);
  }

  Future<void> _flushImages(String listingId) async {
    if (state.deletingImageIds.isEmpty && state.pendingImages.isEmpty) return;
    state = state.copyWith(isUploadingImages: true);
    try {
      for (final imageId in List.of(state.deletingImageIds)) {
        await repo.deleteListingImageRepo(listingId: listingId, imageId: imageId);
        state = state.copyWith(deletingImageIds: {...state.deletingImageIds}..remove(imageId));
      }

      for (final file in List.of(state.pendingImages)) {
        await repo.uploadSellerShopImagesRepo(listingId, file /*, displayOrder */);
        removePendingImage(file);
      }
    } finally {
      state = state.copyWith(isUploadingImages: false);
      await refreshRemoteImages(listingId);
    }
  }

  Future<void> refreshRemoteImages(String listingId) async {
    await repo.getListingImagesRepo(listingId);
  }

  Future<void> _submitListing(String listingId) async {
    await repo.submitListingRepo(listingId: listingId);
  }

  SellerListingBasicInfoRequest _basicPayload(String? sellerId, {Set<String>? only}) {
    final s = state, c = controllers;
    bool has(String k) => only == null || only.contains(k);

    return SellerListingBasicInfoRequest(
      additionalCategoryIds: has('additionalCategoryIds') ? s.additionalCategoryIds.toList() : null,
      basePrice: has('basePrice') ? (s.isFree ? 0 : _d(c.basePrice)) : null,
      categoryId: has('categoryId') ? s.subcategoryId ?? s.mainCategoryId : null,
      description: has('description') ? c.description.text.trim() : null,
      isFree: has('isFree') ? s.isFree : null,
      listingType: has('listingType') ? s.listingType.api : null,
      priceUnit: has('priceUnit') ? s.priceUnit : null,
      quantityAvailable: has('quantityAvailable') ? _i(c.quantity) : null,
      sellerId: sellerId,
      tagNames: has('tagNames') ? s.tags : null,
      title: has('title') ? c.title.text.trim() : null,
    );
  }

  FoodAdditionalInformationRequest _foodPayload({Set<String>? only}) {
    final s = state, c = controllers;
    bool has(String k) => only == null || only.contains(k);

    return FoodAdditionalInformationRequest(
      allergens: has('allergens') ? _t(c.allergens) : null,
      expiryTime: has('expiryTime')
          ? (s.expiryTime != null ? DateFormat('yyyy-MM-dd').format(s.expiryTime!) : '')
          : null,
      foodType: has('foodType') ? s.foodType : null,
      freshnessDeclaration: has('freshnessDeclaration') ? _t(c.freshness) : null,
      fssaiCertificateId: has('fssaiCertificateId') ? _t(c.fssaiId) : null,
      fssaiRequired: has('fssaiRequired') ? s.fssaiRequired.toString() : null,
      ingredients: has('ingredients') ? c.ingredients.text.trim() : null,
      isFrozenItem: has('isFrozenItem') ? s.frozen : null,
      packagingDetails: has('packagingDetails') ? _t(c.packaging) : null,
      preparationTime: has('preparationTime') ? c.prepTime.text.trim() : null,
      servingSizes: has('servingSizes')
          ? s.servings
                .map(
                  (d) => ServingSizeRequest(
                    description: d.description.text.trim(),
                    isAvailable: d.isAvailable,
                    price: int.parse(d.price.text.trim()),
                    quantityAvailable: int.parse(d.quantity.text),
                    sizeUnit: d.sizeUnit.text.trim(),
                    sizeValue: int.parse(d.sizeValue.text.trim()),
                  ),
                )
                .toList()
          : null,
      spiceLevel: has('spiceLevel') ? kSpiceLevels[s.spiceLevel] : null,
      spiceLevelText: has('spiceLevel') ? s.spiceLevel : null,
      storageInstruction: has('storageInstruction') ? _t(c.storage) : null,
    );
  }

  ServiceAdditionalInformationRequest _servicePayload({Set<String>? only}) {
    final s = state, c = controllers;
    bool has(String k) => only == null || only.contains(k);

    return ServiceAdditionalInformationRequest(
      cancellationPolicy: has('cancellationPolicy') ? _t(c.cancellationPolicy) : null,
      certificateRequired: has('certificateRequired') ? s.certificateRequired : null,
      homeVisitAvailable: has('homeVisitAvailable') ? s.homeVisit : null,
      onlineAvailable: has('onlineAvailable') ? s.online : null,
      requiredMaterials: has('requiredMaterials') ? _t(c.requiredMaterials) : null,
      serviceDurationMinutes: has('serviceDurationMinutes') ? _i(c.duration) : null,
      serviceLocationType: has('serviceLocationType') ? s.locationType : null,
    );
  }
}
