import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:society_seva/features/seller/domain/enum/seller_type_config.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/delivery_option_widget.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/onboarding_availablitiy_step.dart';
import 'package:society_seva/core/providers/app_providers.dart';
import 'package:society_seva/features/seller/data/datasources/seller_onboarding_remote_data_source.dart';
import 'package:society_seva/features/seller/data/models/request/seller_profile_request.dart';
import 'package:society_seva/features/seller/domain/entities/certificate_entity.dart';
import 'package:society_seva/features/seller/domain/entities/kyc_document_entity.dart';
import 'package:society_seva/features/seller/domain/entities/seller_availabledays_entity.dart';
import 'package:society_seva/features/seller/domain/entities/seller_image_entity.dart';
import 'package:society_seva/features/seller/domain/entities/seller_profile_entity.dart';
import 'package:society_seva/features/seller/domain/repositories/seller_onboarding_repository.dart';
import 'package:society_seva/features/seller/domain/usecase/on_boarding/create_seller_and_daft_usecase.dart';
import 'package:society_seva/features/seller/domain/usecase/on_boarding/delete_seller_image_by_id_use_case.dart';
import 'package:society_seva/features/seller/domain/usecase/on_boarding/download_kyc_document_file_usecase.dart';
import 'package:society_seva/features/seller/domain/usecase/on_boarding/fetch_images_by_seller_id_usecase.dart';
import 'package:society_seva/features/seller/domain/usecase/on_boarding/fetch_seller_profile_by_id_usecase.dart';
import 'package:society_seva/features/seller/domain/usecase/on_boarding/my_seller_profile_usecase.dart';
import 'package:society_seva/features/seller/domain/usecase/on_boarding/submit_seller_usecase.dart';
import 'package:society_seva/features/seller/domain/usecase/on_boarding/update_seller_profile_by_id_use_case.dart';
import 'package:society_seva/features/seller/domain/usecase/on_boarding/upload_images_by_seller_id_usecase.dart';
import 'package:society_seva/features/shop/domain/entities/shop_category.dart';

final sellerOnBoardingRemoteDataSource = Provider<SellerOnboardingRemoteDataSource>((ref) {
  return SellerOnboardingRemoteDataSourceImpl(apiClient: ref.watch(apiClientProvider));
});

final sellerOnBoardingRepository = Provider<SellerOnboardingRepository>((ref) {
  return SellerOnboardingRepositoryImpl(
    sellerOnboardingRemoteDataSource: ref.watch(sellerOnBoardingRemoteDataSource),
  );
});

final mySellerProfileUseCase = Provider<MySellerProfileUsecase>((ref) {
  return MySellerProfileUsecase(ref.watch(sellerOnBoardingRepository));
});

final fetchSellerProfileByIdUsecase = Provider<FetchSellerProfileByIdUsecase>((ref) {
  return FetchSellerProfileByIdUsecase(ref.watch(sellerOnBoardingRepository));
});

final createAndDraftSellerUsecase = Provider<CreateSellerAndDaftUsecase>((ref) {
  return CreateSellerAndDaftUsecase(ref.watch(sellerOnBoardingRepository));
});

final submitSellerProfileUsecase = Provider<SubmitSellerUseCase>((ref) {
  return SubmitSellerUseCase(ref.watch(sellerOnBoardingRepository));
});

final updateSellerProfileUseCase = Provider<UpdateSellerProfileByIdUseCase>((ref) {
  return UpdateSellerProfileByIdUseCase(ref.watch(sellerOnBoardingRepository));
});

final uploadImagesBySellerIdUsecase = Provider<UploadImagesBySellerIdUsecase>((ref) {
  return UploadImagesBySellerIdUsecase(ref.watch(sellerOnBoardingRepository));
});

final deleteSellerImagesByIDUsecase = Provider<DeleteSellerImageByIdUseCase>((ref) {
  return DeleteSellerImageByIdUseCase(ref.watch(sellerOnBoardingRepository));
});

final fetchSellerImagesByIDUsecase = Provider<FetchImagesBySellerIdUsecase>((ref) {
  return FetchImagesBySellerIdUsecase(ref.watch(sellerOnBoardingRepository));
});

final downloadKycDocumentFileUsecase = Provider<DownloadKycDocumentFileUsecase>((ref) {
  return DownloadKycDocumentFileUsecase(ref.watch(sellerOnBoardingRepository));
});

final sellerCertificatesProvider = FutureProvider.autoDispose
    .family<List<CertificateEntity>, String>((ref, sellerId) {
      return ref.read(sellerOnBoardingRepository).fetchCertificatesRepo(sellerId);
    });
final sellerDocumentProvider = FutureProvider.autoDispose.family<List<KycDocumentEntity>, String>((
  ref,
  sellerId,
) {
  return ref.read(sellerOnBoardingRepository).fetchKYCDocumentRepo(sellerId);
});

final sellerAvailableDaysProvider = FutureProvider.autoDispose.family<AvailableDaysEntity, String>((
  ref,
  sellerId,
) {
  return ref.read(sellerOnBoardingRepository).fetchSellerAvailableDaysRepo(sellerID: sellerId);
});

final fetchSellerUploadedImagesProvider =
    AsyncNotifierProvider.family<FetchImagesBySellerIDNotifier, List<SellerImageEntity>?, String>(
      FetchImagesBySellerIDNotifier.new,
    );

class FetchImagesBySellerIDNotifier extends FamilyAsyncNotifier<List<SellerImageEntity>?, String> {
  late FetchImagesBySellerIdUsecase _useCase;

  @override
  Future<List<SellerImageEntity>?> build(String sellerId) async {
    _useCase = ref.read(fetchSellerImagesByIDUsecase);

    return await _useCase.call(sellerId: sellerId);
  }

  Future<List<SellerImageEntity>?> fetchSellerImages() async {
    state = const AsyncLoading();

    state = await AsyncValue.guard(() => _useCase.call(sellerId: arg));
    return state.value;
  }
}

final mySellerProfileProvider =
    AsyncNotifierProvider<MySellerProfileNotifier, SellerProfileEntity?>(
      MySellerProfileNotifier.new,
    );

final sellerProfileByIdProvider = FutureProvider.autoDispose.family<SellerProfileEntity?, String>((
  ref,
  sellerId,
) {
  return ref.read(fetchSellerProfileByIdUsecase).call(sellerId);
});

class MySellerProfileNotifier extends AsyncNotifier<SellerProfileEntity?> {
  late MySellerProfileUsecase _useCase;

  @override
  Future<SellerProfileEntity?> build() async {
    _useCase = ref.read(mySellerProfileUseCase);
    return fetchMySellerProfile();
  }

  Future<SellerProfileEntity?> fetchMySellerProfile() async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() async {
      return await _useCase.call();
    });
    return state.value;
  }

  Future<SellerProfileEntity?> refresh() => fetchMySellerProfile();
}

enum SellerKind { individual, smallBusiness, registered, artist, workshop }

class SellerRegState {
  final int step;
  final String fullName, bio;
  final List<String> sellerTypes;
  final SellerKind? sellerKind;
  final bool? hasFssai;
  final String fssaiCertificateId;
  final String websiteUrl;
  final String socialMediaLinks;
  final String legalCompliance;
  final Set<DeliveryOption> deliveryOptions;
  final Set<String> categories;
  final List<String> capableCategoryIds;
  final List<String> capabilityTags;
  final String capabilitiesDescription;
  final String businessName, city, locality, pickupAddress, radius;
  final String stateName, country, pinCode;
  final double? latitude, longitude;

  // Step 3
  final String language;
  final Set<String> days;
  final TimeOfDay from, to;
  final String description;
  final Map<String, String?> documents;

  const SellerRegState({
    this.step = 0,
    this.fullName = '',
    this.sellerTypes = const [],
    this.bio = '',
    this.sellerKind,
    this.categories = const {'Food'},
    this.businessName = '',
    this.city = '',
    this.locality = '',
    this.pickupAddress = '',
    this.radius = '',
    this.stateName = '',
    this.country = '',
    this.pinCode = '',
    this.latitude,
    this.longitude,
    this.language = '',
    this.days = const {},
    this.from = const TimeOfDay(hour: 9, minute: 0),
    this.to = const TimeOfDay(hour: 18, minute: 0),
    this.description = '',
    this.documents = const {},
    this.hasFssai = false,
    this.fssaiCertificateId = '',
    this.websiteUrl = '',
    this.socialMediaLinks = '',
    this.legalCompliance = '',

    this.capabilitiesDescription = '',
    this.capabilityTags = const [],
    this.capableCategoryIds = const [],
    this.deliveryOptions = const {},
  });

  SellerRegState copyWith({
    int? step,
    String? fullName,
    String? bio,
    List<String>? sellerTypes,
    Set<DeliveryOption>? deliveryOptions,
    SellerKind? sellerKind,
    Set<String>? categories,
    List<String>? capableCategoryIds,
    List<String>? capabilityTags,
    String? capabilitiesDescription,
    String? businessName,
    String? city,
    String? locality,
    String? pickupAddress,
    String? radius,
    String? stateName,
    String? country,
    String? pinCode,
    double? latitude,
    double? longitude,
    String? language,
    Set<String>? days,
    bool? hasFssai,
    String? fssaiCertificateId,
    String? websiteUrl,
    String? socialMediaLinks,
    String? legalCompliance,
    TimeOfDay? from,
    TimeOfDay? to,
    String? description,
    Map<String, String?>? documents,
  }) => SellerRegState(
    step: step ?? this.step,
    fullName: fullName ?? this.fullName,
    bio: bio ?? this.bio,
    sellerKind: sellerKind ?? this.sellerKind,
    categories: categories ?? this.categories,
    businessName: businessName ?? this.businessName,
    city: city ?? this.city,
    locality: locality ?? this.locality,
    pickupAddress: pickupAddress ?? this.pickupAddress,
    radius: radius ?? this.radius,
    stateName: stateName ?? this.stateName,
    country: country ?? this.country,
    pinCode: pinCode ?? this.pinCode,
    latitude: latitude ?? this.latitude,
    longitude: longitude ?? this.longitude,
    language: language ?? this.language,
    days: days ?? this.days,
    from: from ?? this.from,
    to: to ?? this.to,
    description: description ?? this.description,
    documents: documents ?? this.documents,
    hasFssai: hasFssai ?? this.hasFssai,
    fssaiCertificateId: fssaiCertificateId ?? this.fssaiCertificateId,
    websiteUrl: websiteUrl ?? this.websiteUrl,
    socialMediaLinks: socialMediaLinks ?? this.socialMediaLinks,
    legalCompliance: legalCompliance ?? this.legalCompliance,
    sellerTypes: sellerTypes ?? this.sellerTypes,
    capabilitiesDescription: capabilitiesDescription ?? this.capabilitiesDescription,
    capabilityTags: capabilityTags ?? this.capabilityTags,
    capableCategoryIds: capableCategoryIds ?? this.capableCategoryIds,
    deliveryOptions: deliveryOptions ?? this.deliveryOptions,
  );
}

final sellerFormActionProvider = NotifierProvider<SellerFormActionNotifier, SellerFormState>(
  SellerFormActionNotifier.new,
);

final sellerOnboardingProvider = sellerFormActionProvider;

class SellerFormActionNotifier extends Notifier<SellerFormState> {
  @override
  SellerFormState build() => const SellerFormState();

  void updateReg(SellerRegState Function(SellerRegState s) f) =>
      state = state.copyWith(reg: f(state.reg));

  List<String> _cleanTypes(Iterable<dynamic> raw) => raw
      .map((e) => e.toString().trim().toUpperCase())
      .where((t) => categoryFor(t) != null) // ignore unknown values
      .toSet()
      .toList();

  void hydrateSellerTypes(Iterable<dynamic> fromApi) {
    if (state.reg.sellerTypes.isNotEmpty) return;
    final types = _cleanTypes(fromApi);
    if (types.isEmpty) return;
    state = state.copyWith(reg: state.reg.copyWith(sellerTypes: types));
  }

  bool toggleSellerType(String type) {
    final list = [...state.reg.sellerTypes];
    if (list.contains(type)) {
      if (list.length == 1) return false;
      list.remove(type);
    } else {
      list.add(type);
    }
    state = state.copyWith(reg: state.reg.copyWith(sellerTypes: list));
    return true;
  }

  void toggleCapableCategory(ShopCategory category) {
    final ids = [...state.reg.capableCategoryIds];
    var tags = [...state.reg.capabilityTags];

    if (ids.contains(category.id)) {
      ids.remove(category.id);
      final subKeys = category.subCategories.map((s) => s.name.trim().toLowerCase()).toSet();
      tags.removeWhere((t) => subKeys.contains(t.trim().toLowerCase()));
    } else {
      ids.add(category.id);
    }

    state = state.copyWith(
      reg: state.reg.copyWith(capableCategoryIds: ids, capabilityTags: tags),
    );
  }

  void setCapabilitiesDescription(String value) =>
      state = state.copyWith(reg: state.reg.copyWith(capabilitiesDescription: value));

  void toggleCapabilityTag(String name) {
    final key = name.trim().toLowerCase();
    final tags = [...state.reg.capabilityTags];
    final i = tags.indexWhere((t) => t.trim().toLowerCase() == key);
    i >= 0 ? tags.removeAt(i) : tags.add(name.trim());
    state = state.copyWith(reg: state.reg.copyWith(capabilityTags: tags));
  }

  void addCustomCapabilityTag(String name) {
    final t = name.trim();
    if (t.isEmpty) return;
    final exists = state.reg.capabilityTags.any((e) => e.trim().toLowerCase() == t.toLowerCase());
    if (exists) return;
    state = state.copyWith(
      reg: state.reg.copyWith(capabilityTags: [...state.reg.capabilityTags, t]),
    );
  }

  void resetSellerTypes() => state = state.copyWith(reg: state.reg.copyWith(sellerTypes: const []));

  void toggleCategory(String c) {
    final set = {...state.reg.categories};
    set.contains(c) ? set.remove(c) : set.add(c);
    if (set.isEmpty) return;
    state = state.copyWith(reg: state.reg.copyWith(categories: set));
  }

  void addPendingImage(XFile file) =>
      state = state.copyWith(queuedImages: [...state.queuedImages, file]);

  void removePendingImage(XFile file) => state = state.copyWith(
    queuedImages: state.queuedImages.where((f) => f.path != file.path).toList(),
  );

  void markImageForDelete(String imageId) =>
      state = state.copyWith(pendingDeleteImageIds: {...state.pendingDeleteImageIds, imageId});

  void unmarkImageForDelete(String imageId) => state = state.copyWith(
    pendingDeleteImageIds: state.pendingDeleteImageIds.where((id) => id != imageId).toSet(),
  );

  void addPendingDocument(PendingDocument doc) =>
      state = state.copyWith(pendingDocuments: [...state.pendingDocuments, doc]);

  void removePendingDocument(PendingDocument doc) => state = state.copyWith(
    pendingDocuments: state.pendingDocuments.where((d) => d != doc).toList(),
  );

  void addPendingCertificate(PendingCertificate cert) =>
      state = state.copyWith(pendingCertificates: [...state.pendingCertificates, cert]);

  void removePendingCertificate(PendingCertificate cert) => state = state.copyWith(
    pendingCertificates: state.pendingCertificates.where((c) => c != cert).toList(),
  );

  String get currentSellerId {
    try {
      final async = ref.read(mySellerProfileProvider);
      if (async.hasError) return '';
      return async.valueOrNull?.id ?? '';
    } catch (_) {
      return '';
    }
  }

  void setDeliveryOptions(Set<DeliveryOption> v) =>
      state = state.copyWith(reg: state.reg.copyWith(deliveryOptions: v));
  void setAvailability(AvailabilityValue availability) =>
      state = state.copyWith(availability: availability);

  void updateDays(Set<String> days) =>
      state = state.copyWith(availability: state.availability.copyWith(days: days));

  void updateHours({TimeOfDay? from, TimeOfDay? to}) => state = state.copyWith(
    availability: state.availability.copyWith(from: from, to: to),
  );

  Future<bool> saveAvailableDays({
    required String sellerId,
    AvailabilityValue? availability,
  }) async {
    final value = availability ?? state.availability;
    try {
      await ref
          .read(sellerOnBoardingRepository)
          .updateSellerAvailableDaysRepo(sellerID: sellerId, data: value.toJson());
      state = state.copyWith(availability: value);
      ref.invalidate(sellerAvailableDaysProvider(sellerId));
      return true;
    } catch (e) {
      state = state.copyWith(error: e);
      return false;
    }
  }

  Future<void> _flushPendingUploads(String sellerId) async {
    state = state.copyWith(isUploadingImages: true);
    try {
      for (final file in List.of(state.queuedImages)) {
        await ref.read(uploadImagesBySellerIdUsecase).call(sellerId: sellerId, file: file);
        removePendingImage(file);
      }
      for (final imageId in List.of(state.pendingDeleteImageIds)) {
        await ref.read(deleteSellerImagesByIDUsecase).call(imageId: imageId, sellerId: sellerId);
        unmarkImageForDelete(imageId);
      }
    } finally {
      state = state.copyWith(isUploadingImages: false);
      ref.invalidate(fetchSellerUploadedImagesProvider(sellerId));
    }

    final repo = ref.read(sellerOnBoardingRepository);
    for (final doc in List.of(state.pendingDocuments)) {
      await repo.uploadKYCDocumentRepo(
        sellerId: sellerId,
        documentType: doc.type,
        documentNumber: doc.number,
        file: doc.file,
      );
      removePendingDocument(doc);
    }
    ref.invalidate(sellerCertificatesProvider(sellerId));

    for (final cert in List.of(state.pendingCertificates)) {
      await repo.uploadCertificateRepo(
        sellerId: sellerId,
        file: cert.file,
        certificateName: cert.name,
        certificateNumber: cert.certificateNumber.toString(),
        certificateType: cert.type.toString(),
        issueAuthority: cert.issuingAuthority.toString(),
        issueDate: cert.issueDate,
        hasExpiry: cert.hasExpiry,
        expiryDate: cert.expiryDate,
      );
      removePendingCertificate(cert);
    }
    ref.invalidate(sellerCertificatesProvider(sellerId));
  }

  SellerProfileRequest _mergeAvailability(SellerProfileRequest request) {
    if (request.availableDays != null && request.availableDays!.isNotEmpty) {
      return request;
    }
    final avail = state.availability;
    return request.copyWith(
      availableDaysType: avail.daysType.api,
      availableDays: kWeekDays.where(avail.days.contains).toList(),
      availableFromTime: formatApiTime(avail.from),
      availableToTime: formatApiTime(avail.to),
    );
  }

  SellerProfileRequest _mergeCapabilities(SellerProfileRequest request) {
    final reg = state.reg;
    return request.copyWith(
      capableCategoryIds: reg.capableCategoryIds,
      capabilityTags: reg.capabilityTags,
      capabilitiesDescription: reg.capabilitiesDescription.trim().isEmpty
          ? null
          : reg.capabilitiesDescription.trim(),
    );
  }

  Future<bool> save(SellerProfileRequest request) async {
    state = state.copyWith(isSaving: true, clearError: true);
    try {
      final req = _mergeAvailability(request);

      await ref.read(createAndDraftSellerUsecase).call(request: req);
      final seller = await ref.read(mySellerProfileProvider.notifier).refresh();
      if (seller == null) {
        throw Exception('Draft was saved but the seller profile could not be loaded.');
      }
      await _flushPendingUploads(seller.id);
      await saveAvailableDays(sellerId: seller.id, availability: state.availability);
      return true;
    } catch (e) {
      state = state.copyWith(error: e);
      return false;
    } finally {
      state = state.copyWith(isSaving: false);
    }
  }

  Future<bool> submit(SellerProfileRequest request) async {
    state = state.copyWith(isSubmitting: true, clearError: true);
    try {
      final req = _mergeAvailability(request);
      var sellerId = currentSellerId;
      if (sellerId == '') {
        await ref.read(createAndDraftSellerUsecase).call(request: req);
        final seller = await ref.read(mySellerProfileProvider.notifier).refresh();
        if (seller == null) {
          throw Exception('Draft was saved but the seller profile could not be loaded.');
        }
        sellerId = seller.id;
      }
      await ref.read(submitSellerProfileUsecase).call(sellerId);
      await _flushPendingUploads(sellerId);
      await saveAvailableDays(sellerId: sellerId, availability: state.availability);
      await ref.read(mySellerProfileProvider.notifier).refresh();
      return true;
    } catch (e) {
      state = state.copyWith(error: e);
      return false;
    } finally {
      state = state.copyWith(isSubmitting: false);
    }
  }

  Future<bool> update(SellerProfileRequest request, String sellerId) async {
    state = state.copyWith(isSubmitting: true, clearError: true);
    try {
      final req = _mergeCapabilities(_mergeAvailability(request));
      log(req.toJson().toString());
      if (!req.isEmpty) {
        await ref.read(updateSellerProfileUseCase).call(request: req, sellerId: sellerId);
      }
      await _flushPendingUploads(sellerId);
      await saveAvailableDays(sellerId: sellerId, availability: state.availability);
      await ref.read(mySellerProfileProvider.notifier).refresh();
      return true;
    } catch (e) {
      state = state.copyWith(error: e);
      return false;
    } finally {
      state = state.copyWith(isSubmitting: false);
    }
  }
}

class SellerFormState {
  final SellerRegState reg;
  final bool isSaving;
  final bool isSubmitting;
  final bool isUploadingImages;
  final List<XFile> queuedImages;
  final Set<String> pendingDeleteImageIds;
  final List<PendingDocument> pendingDocuments;
  final List<PendingCertificate> pendingCertificates;
  final AvailabilityValue availability;
  final Object? error;

  const SellerFormState({
    this.reg = const SellerRegState(),
    this.isSaving = false,
    this.isSubmitting = false,
    this.isUploadingImages = false,
    this.queuedImages = const [],
    this.pendingDeleteImageIds = const {},
    this.pendingDocuments = const [],
    this.pendingCertificates = const [],
    this.availability = const AvailabilityValue(),
    this.error,
  });

  bool get isBusy => isSaving || isSubmitting || isUploadingImages;

  SellerFormState copyWith({
    SellerRegState? reg,
    bool? isSaving,
    bool? isSubmitting,
    bool? isUploadingImages,
    List<XFile>? queuedImages,
    Set<String>? pendingDeleteImageIds,
    List<PendingDocument>? pendingDocuments,
    List<PendingCertificate>? pendingCertificates,
    AvailabilityValue? availability,
    Object? error,
    bool clearError = false,
  }) => SellerFormState(
    reg: reg ?? this.reg,
    isSaving: isSaving ?? this.isSaving,
    isSubmitting: isSubmitting ?? this.isSubmitting,
    isUploadingImages: isUploadingImages ?? this.isUploadingImages,
    queuedImages: queuedImages ?? this.queuedImages,
    pendingDeleteImageIds: pendingDeleteImageIds ?? this.pendingDeleteImageIds,
    pendingDocuments: pendingDocuments ?? this.pendingDocuments,
    pendingCertificates: pendingCertificates ?? this.pendingCertificates,
    availability: availability ?? this.availability,
    error: clearError ? null : (error ?? this.error),
  );
}

class PendingDocument {
  const PendingDocument({required this.type, required this.number, required this.file});

  final String type;
  final String number;
  final XFile file;
}

class PendingCertificate {
  const PendingCertificate({
    required this.name,
    required this.file,
    required this.issueDate,
    required this.hasExpiry,
    this.certificateNumber,
    this.issuingAuthority,
    this.type,
    this.expiryDate,
  });

  final String? type;
  final String name;
  final String? certificateNumber;
  final String? issuingAuthority;
  final XFile file;
  final DateTime issueDate;
  final bool hasExpiry;
  final DateTime? expiryDate;
}

class SellerActionState {
  const SellerActionState({
    this.isSaving = false,
    this.isSubmitting = false,
    this.isUploading = false,
    this.pendingImages = const [],
    this.pendingDocuments = const [],
    this.pendingCertificates = const [],
    this.pendingDeleteImageIds = const {},
    this.error,
  });

  final bool isSaving;
  final bool isSubmitting;
  final bool isUploading;
  final List<XFile> pendingImages;
  final Set<String> pendingDeleteImageIds;
  final List<PendingDocument>? pendingDocuments;
  final List<PendingCertificate>? pendingCertificates;
  final Object? error;

  bool get isBusy => isSaving || isSubmitting || isUploading;

  SellerActionState copyWith({
    bool? isSaving,
    bool? isSubmitting,
    bool? isUploading,
    List<XFile>? pendingImages,
    Set<String>? pendingDeleteImageIds,
    Object? error,
    bool clearError = false,
    List<PendingDocument>? pendingDocuments,
    List<PendingCertificate>? pendingCertificates,
  }) {
    return SellerActionState(
      isSaving: isSaving ?? this.isSaving,
      isSubmitting: isSubmitting ?? this.isSubmitting,
      isUploading: isUploading ?? this.isUploading,
      pendingImages: pendingImages ?? this.pendingImages,
      error: clearError ? null : (error ?? this.error),
      pendingDocuments: pendingDocuments ?? this.pendingDocuments,
      pendingCertificates: pendingCertificates ?? this.pendingCertificates,
      pendingDeleteImageIds: pendingDeleteImageIds ?? this.pendingDeleteImageIds,
    );
  }
}
