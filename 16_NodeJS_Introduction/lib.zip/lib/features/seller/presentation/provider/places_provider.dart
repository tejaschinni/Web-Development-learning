import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/features/seller/data/datasources/places_remote_datasource.dart';
import 'package:society_seva/features/seller/domain/repositories/place_respository.dart';
import 'package:http/http.dart' as http;

final placesRepositoryProvider = Provider<PlacesRepository>((ref) {
  return PlacesRepositoryImpl(
    PlacesRemoteDataSource(http.Client(), apiKey: 'AIzaSyBCwc1caY_-wmaMsqiUlgURENJHhJ0Fys0'),
  );
});
