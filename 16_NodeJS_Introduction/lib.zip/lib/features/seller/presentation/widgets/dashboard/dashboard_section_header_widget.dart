import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:society_seva/app/theme/app_theme.dart';

class DashboardSectionHeaderWidget extends StatelessWidget {
  const DashboardSectionHeaderWidget(
    this.title, {
    super.key,
    this.action,
    this.onActionTap,
    this.trailing,
  });
  final String title;
  final String? action;
  final VoidCallback? onActionTap;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Row(
      children: [
        Expanded(
          child: Text(
            title,
            style: AppTheme.hind(16, w: FontWeight.w700, c: AppColors.navy),
          ),
        ),
        ?trailing,
        if (action != null)
          InkWell(
            onTap: onActionTap,
            child: Row(
              children: [
                Text(
                  action!,
                  style: AppTheme.hind(12, w: FontWeight.w600, c: AppColors.blue),
                ),
                const Gap(2),
                const Icon(Icons.arrow_forward, size: 14, color: AppColors.blue),
              ],
            ),
          ),
      ],
    ),
  );
}
