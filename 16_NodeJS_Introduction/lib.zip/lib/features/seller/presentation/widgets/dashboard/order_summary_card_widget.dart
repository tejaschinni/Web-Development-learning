import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';

class OrderSummary {
  const OrderSummary({
    required this.requested,
    required this.accepted,
    required this.inProgress,
    required this.upcoming,
  });

  final int requested;
  final int accepted;
  final int inProgress;
  final int upcoming;

  static const empty = OrderSummary(requested: 0, accepted: 0, inProgress: 0, upcoming: 0);

  // Adjust the keys to match your backend response.
  factory OrderSummary.fromJson(Map<String, dynamic> json) => OrderSummary(
    requested: (json['requested'] ?? 0) as int,
    accepted: (json['accepted'] ?? 0) as int,
    inProgress: (json['inProgress'] ?? 0) as int,
    upcoming: (json['upcoming'] ?? 0) as int,
  );
}

final orderSummaryProvider = FutureProvider.autoDispose<OrderSummary>((ref) async {
  // final json = await ref.read(apiClientProvider).get('/seller/orders/summary');
  // return OrderSummary.fromJson(json);
  return OrderSummary.empty;
});

class SellerOrdersSummarySection extends ConsumerWidget {
  const SellerOrdersSummarySection({super.key, this.onTapStatus});

  final void Function(String status)? onTapStatus;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final summaryAsync = ref.watch(orderSummaryProvider);
    final theme = Theme.of(context);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Orders', style: theme.textTheme.titleMedium),
            const Gap(12),
            summaryAsync.when(
              loading: () => const Padding(
                padding: EdgeInsets.symmetric(vertical: 24),
                child: Center(child: CircularProgressIndicator()),
              ),
              error: (e, _) => Row(
                children: [
                  const Expanded(child: Text('Could not load orders')),
                  TextButton(
                    onPressed: () => ref.invalidate(orderSummaryProvider),
                    child: const Text('Retry'),
                  ),
                ],
              ),
              data: (s) => Column(
                children: [
                  _RequestedBanner(count: s.requested, onTap: () => onTapStatus?.call('requested')),
                  const Gap(12),
                  Row(
                    children: [
                      _CountTile(
                        icon: Icons.check_circle_outline,
                        label: 'Accepted',
                        count: s.accepted,
                        onTap: () => onTapStatus?.call('accepted'),
                      ),
                      _CountTile(
                        icon: Icons.local_fire_department_outlined,
                        label: 'In progress',
                        count: s.inProgress,
                        onTap: () => onTapStatus?.call('inProgress'),
                      ),
                      _CountTile(
                        icon: Icons.event_outlined,
                        label: 'Upcoming',
                        count: s.upcoming,
                        onTap: () => onTapStatus?.call('upcoming'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RequestedBanner extends StatelessWidget {
  const _RequestedBanner({required this.count, this.onTap});
  final int count;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final hasRequests = count > 0;

    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: hasRequests ? scheme.primaryContainer : scheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            Icon(hasRequests ? Icons.notifications_active_outlined : Icons.inbox_outlined),
            const Gap(12),
            Expanded(
              child: Text(
                hasRequests
                    ? '$count new order ${count == 1 ? 'request' : 'requests'}'
                    : 'No new order requests',
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
            ),
            if (hasRequests) const Icon(Icons.chevron_right),
          ],
        ),
      ),
    );
  }
}

class _CountTile extends StatelessWidget {
  const _CountTile({required this.icon, required this.label, required this.count, this.onTap});

  final IconData icon;
  final String label;
  final int count;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Expanded(
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Column(
            children: [
              Icon(icon, size: 22),
              const Gap(6),
              Text(
                '$count',
                style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w600),
              ),
              Text(label, style: theme.textTheme.bodySmall),
            ],
          ),
        ),
      ),
    );
  }
}
