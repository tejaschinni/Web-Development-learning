import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/domain/entities/seller_listing_entity.dart';
import 'package:society_seva/features/seller/presentation/widgets/dashboard/dashboard_card_wiget.dart';
import 'package:society_seva/features/seller/presentation/widgets/dashboard/dashboard_section_header_widget.dart';
import 'package:society_seva/features/seller/presentation/widgets/listing/my_list_item_widget.dart';

class DashboardListingSection extends StatelessWidget {
  const DashboardListingSection({
    super.key,
    required this.onCreate,
    this.onViewAll,
    required this.listing,
  });
  final VoidCallback onCreate;
  final VoidCallback? onViewAll;
  final List<SellerListingEntity> listing;

  static const _maxVisible = 4;

  @override
  Widget build(BuildContext context) {
    final visibleItems = listing.take(_maxVisible).toList();
    final hasMore = listing.length > _maxVisible;

    return DashboardCardWidget(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          DashboardSectionHeaderWidget(
            'My Listings',
            action: hasMore ? 'View All' : null,
            onActionTap: hasMore ? onViewAll : null,
          ),
          if (listing.isEmpty)
            _EmptyListings(onCreate: onCreate)
          else ...[
            for (final item in visibleItems)
              MyListItemWidget(
                item: item,
                onDelete: () {},
                onEdit: () => context.push(
                  '/modules/seller/addListing',
                  extra: {'isEdit': true, 'listingId': item.id},
                ),
                onOutOfStock: () {},
                onToggle: (v) {},
              ),
            const Gap(12),
            SizedBox(
              width: double.infinity,
              child: _OutlineArrowButton('Create New Listing', onPressed: onCreate),
            ),
          ],
        ],
      ),
    );
  }
}

class _OutlineArrowButton extends StatelessWidget {
  const _OutlineArrowButton(this.label, {required this.onPressed});
  final String label;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) => OutlinedButton(
    onPressed: onPressed,
    style: OutlinedButton.styleFrom(
      foregroundColor: AppColors.green,
      side: const BorderSide(color: AppColors.green),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(label, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
        const Gap(6),
        const Icon(Icons.arrow_forward, size: 15),
      ],
    ),
  );
}

class _EmptyListings extends StatelessWidget {
  const _EmptyListings({required this.onCreate});
  final VoidCallback onCreate;

  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity,
    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
    decoration: BoxDecoration(
      color: const Color(0xFFEAF6EE),
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: const Color(0xFFCFE8D6)),
    ),
    child: Column(
      children: [
        const Icon(Icons.inventory_2_outlined, size: 28, color: AppColors.muted),
        const Gap(8),
        const Text(
          'No listings yet',
          style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: Color(0xFF0B2F6B)),
        ),
        const Gap(4),
        const Text(
          'Add your first product to start selling.',
          style: TextStyle(fontSize: 12, color: AppColors.muted),
        ),
        const Gap(12),
        _OutlineArrowButton('Add Listing', onPressed: onCreate),
      ],
    ),
  );
}
