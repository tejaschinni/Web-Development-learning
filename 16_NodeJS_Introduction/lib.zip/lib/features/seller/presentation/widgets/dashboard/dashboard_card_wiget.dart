import 'package:flutter/material.dart';
import 'package:society_seva/app/theme/app_theme.dart';

class DashboardCardWidget extends StatelessWidget {
  const DashboardCardWidget({super.key, required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: AppColors.border),
    ),
    child: child,
  );
}
