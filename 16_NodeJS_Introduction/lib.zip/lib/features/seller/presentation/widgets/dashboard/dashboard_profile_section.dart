import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';

class DashboardProfileSection extends ConsumerWidget {
  const DashboardProfileSection({super.key, this.onViewProfile, this.onEditAvatar});
  final VoidCallback? onViewProfile;
  final VoidCallback? onEditAvatar;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sellerAsync = ref.watch(mySellerProfileProvider);

    return sellerAsync.when(
      data: (data) {
        if (data == null) {
          return const SizedBox.shrink();
        }
        final status = data.approvalStatus.toUpperCase();
        Color cardBg = const Color(0xFFEAF6EE);
        Color cardBorder = AppColors.border;
        if (status == 'DRAFT' || status == 'DRAFTED') {
          cardBg = const Color(0xFFFFFBEB);
          cardBorder = const Color(0xFFFDE68A);
        } else if (status == 'REJECTED') {
          cardBg = const Color(0xFFFEF2F2);
          cardBorder = const Color(0xFFFECACA);
        } else if (status == 'SUSPENDED') {
          cardBg = const Color(0xFFFFF7ED);
          cardBorder = const Color(0xFFFED7AA);
        } else if (status == 'SUBMITTED' || status == 'UNDER_REVIEW') {
          cardBg = const Color(0xFFF0F9FF);
          cardBorder = const Color(0xFFBAE6FD);
        }

        return Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: cardBg,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: cardBorder),
          ),
          child: LayoutBuilder(
            builder: (context, c) {
              final compact = c.maxWidth < 420;
              final button = _OutlineArrowButton('View Profile', onPressed: onViewProfile ?? () {});
              final info = Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Wrap(
                    spacing: 8,
                    runSpacing: 4,
                    crossAxisAlignment: WrapCrossAlignment.center,
                    children: [
                      Text(
                        data.displayName.isNotEmpty ? data.displayName : (data.businessName ?? '-'),
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                          color: AppColors.navy,
                        ),
                      ),
                      _Pill(data.approvalStatus.toUpperCase()),
                    ],
                  ),
                  const Gap(6),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: data.sellerTypeList
                        .map((type) => _TypeChip(type.toString()))
                        .toList(),
                  ),
                  const Gap(2),
                  Row(
                    children: [
                      Icon(Icons.location_on_outlined, size: 14, color: AppColors.muted),
                      const Gap(2),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.67,
                        child: Text(data.address, style: AppTheme.hind(12, c: AppColors.muted)),
                      ),
                    ],
                  ),
                ],
              );

              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Stack(
                        clipBehavior: Clip.none,
                        children: [
                          Container(
                            width: 60,
                            height: 60,
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              color: Color(0xFFFFE0B2),
                            ),
                            child: const Icon(
                              Icons.ramen_dining,
                              size: 30,
                              color: Color(0xFFB3541E),
                            ),
                          ),
                          Positioned(
                            right: -2,
                            bottom: -2,
                            child: InkWell(
                              onTap: onEditAvatar ?? onViewProfile,
                              borderRadius: BorderRadius.circular(10),
                              child: Container(
                                padding: const EdgeInsets.all(4),
                                decoration: const BoxDecoration(
                                  color: AppColors.green,
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(Icons.edit, size: 11, color: Colors.white),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const Gap(12),
                      Expanded(child: info),
                      if (!compact) button,
                    ],
                  ),
                  if (compact) ...[
                    const Gap(10),
                    Align(alignment: Alignment.centerRight, child: button),
                  ],
                ],
              );
            },
          ),
        );
      },
      error: ((error, stackTrace) {
        return Text("No Profile Found");
      }),
      loading: () {
        return Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFFEAF6EE),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFFCFE8D6)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  // avatar placeholder
                  Container(
                    width: 60,
                    height: 60,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: Color(0xFFFFE0B2),
                    ),
                    child: const Icon(Icons.ramen_dining, size: 30, color: Color(0xFFB3541E)),
                  ),
                  const Gap(12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '-',
                          style: const TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                            color: Color(0xFF0B2F6B),
                          ),
                        ),
                        const Gap(6),
                        Row(
                          children: [
                            Icon(Icons.location_on_outlined, size: 14, color: AppColors.muted),
                            const Gap(2),
                            Text('-', style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                          ],
                        ),
                      ],
                    ),
                  ),
                  _OutlineArrowButton('View Profile', onPressed: () {}),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

class _TypeChip extends StatelessWidget {
  const _TypeChip(this.label);
  final String label;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: AppColors.border),
    ),
    child: Text(
      label.replaceAll('_', " "),
      style: AppTheme.hind(11, w: FontWeight.w500, c: AppColors.ink),
    ),
  );
}

class _Pill extends StatelessWidget {
  const _Pill(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    Color bg;
    Color fg;
    IconData effectiveIcon;

    final upper = text.toUpperCase();
    if (upper == 'APPROVED') {
      bg = const Color(0xFFDDF3E2);
      fg = AppColors.green;
      effectiveIcon = Icons.check_circle;
    } else if (upper == 'DRAFT' || upper == 'DRAFTED') {
      bg = const Color(0xFFFEF3C7);
      fg = const Color(0xFFD97706);
      effectiveIcon = Icons.edit_note;
    } else if (upper == 'REJECTED') {
      bg = const Color(0xFFFFEBEE);
      fg = AppColors.red;
      effectiveIcon = Icons.cancel_outlined;
    } else if (upper == 'SUSPENDED') {
      bg = const Color(0xFFFFF3E0);
      fg = AppColors.orange;
      effectiveIcon = Icons.block;
    } else {
      bg = const Color(0xFFE0F2FE);
      fg = const Color(0xFF0284C7);
      effectiveIcon = Icons.hourglass_empty_rounded;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(effectiveIcon, size: 13, color: fg),
          const Gap(4),
          Text(
            text,
            style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: fg),
          ),
        ],
      ),
    );
  }
}

class _OutlineArrowButton extends StatelessWidget {
  const _OutlineArrowButton(this.label, {required this.onPressed});
  final String label;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) => OutlinedButton(
    onPressed: onPressed,
    style: OutlinedButton.styleFrom(
      foregroundColor: AppColors.green,
      side: const BorderSide(color: AppColors.green),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(label, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
        const Gap(6),
        const Icon(Icons.arrow_forward, size: 15),
      ],
    ),
  );
}
