import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/domain/entities/certificate_entity.dart';
import 'package:society_seva/features/seller/domain/entities/kyc_document_entity.dart';
import 'package:society_seva/features/seller/domain/enum/certificate_type.dart';
import 'package:society_seva/features/seller/domain/enum/document_type.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/image_grid_widget.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/image_source_sheet.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/lable_widget.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/onboarding_dropdown_list_widget.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/onboarding_section_card_widget.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/onboarding_text_field_widget.dart';

class OnboardingPhotosDocumetsStep extends StatelessWidget {
  const OnboardingPhotosDocumetsStep({
    super.key,
    required this.sellerId,
    this.isFoodSeller = false,
  });
  final String sellerId;
  final bool isFoodSeller;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _PhotosSection(sellerId: sellerId, isFoodSeller: isFoodSeller),
        const Gap(12),
        _DocumentsSection(sellerId: sellerId, isFoodSeller: isFoodSeller),
        const Gap(12),
        _CertificatesSection(sellerId: sellerId),
      ],
    );
  }
}

String _sentence(String value) {
  final s = value.toLowerCase().replaceAll('_', ' ');
  return s.isEmpty ? s : '${s[0].toUpperCase()}${s.substring(1)}';
}

Color get _cardColor => AppColors.green.withValues(alpha: 0.15);

void _snack(BuildContext context, String message) {
  if (!context.mounted) return;
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(message)));
}

class _SubHeading extends StatelessWidget {
  const _SubHeading(this.text);
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(top: 16, bottom: 8),
    child: Text(text, style: GoogleFonts.hind(fontSize: 14, fontWeight: FontWeight.w700)),
  );
}

class _UploadTile extends StatelessWidget {
  const _UploadTile({required this.emptyLabel, required this.fileName, required this.onTap});
  final String emptyLabel;
  final String? fileName;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final done = fileName != null;
    return InkWell(
      borderRadius: BorderRadius.circular(8),
      onTap: onTap,
      child: Container(
        height: 48,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(
          color: done ? AppColors.green.withValues(alpha: 0.08) : Colors.white,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: done ? AppColors.green : AppColors.border),
        ),
        child: Row(
          children: [
            Icon(
              done ? Icons.check_circle : Icons.upload_file_outlined,
              size: 20,
              color: done ? AppColors.green : AppColors.muted,
            ),
            const Gap(10),
            Expanded(
              child: Text(
                fileName ?? emptyLabel,
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.hind(
                  fontSize: 13,
                  color: done ? AppColors.green : AppColors.muted,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DateField extends StatelessWidget {
  const _DateField({required this.label, required this.value, required this.onTap});
  final String label;
  final DateTime? value;
  final VoidCallback onTap;

  static final _format = DateFormat('dd MMM yyyy');

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        LableWidget(label, required: true),
        InkWell(
          borderRadius: BorderRadius.circular(8),
          onTap: onTap,
          child: Container(
            height: 44,
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppColors.border),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    value == null ? 'Select date' : _format.format(value!),
                    style: GoogleFonts.hind(
                      fontSize: 13,
                      color: value == null ? const Color(0xFF9E9E9E) : Colors.black87,
                    ),
                  ),
                ),
                Icon(Icons.calendar_today_outlined, size: 18, color: AppColors.muted),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _ItemTile extends StatelessWidget {
  const _ItemTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.trailing,
    this.iconColor,
  });
  final IconData icon;
  final Color? iconColor;
  final String title, subtitle;
  final Widget trailing;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Icon(icon, color: iconColor ?? AppColors.muted),
          const Gap(10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: GoogleFonts.hind(fontSize: 13, fontWeight: FontWeight.w600)),
                if (subtitle.isNotEmpty)
                  Text(subtitle, style: GoogleFonts.hind(fontSize: 11, color: AppColors.muted)),
              ],
            ),
          ),
          trailing,
        ],
      ),
    );
  }
}

class _PhotosSection extends ConsumerWidget {
  const _PhotosSection({required this.sellerId, required this.isFoodSeller});
  final String sellerId;
  final bool isFoodSeller;

  static final _picker = ImagePicker();

  Future<void> _onAddPhotosPressed(BuildContext context, WidgetRef ref) async {
    final source = await chooseImageSource(context);
    if (source == null) return; // dismissed

    final notifier = ref.read(sellerFormActionProvider.notifier);
    if (source == ImageSource.camera) {
      final file = await _picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 80,
        maxWidth: 1600,
        preferredCameraDevice: CameraDevice.rear,
      );
      if (file == null) return; // user cancelled
      notifier.addPendingImage(file);
    } else {
      final files = await _picker.pickMultiImage(imageQuality: 80, maxWidth: 1600);
      if (files.isEmpty) return; // user cancelled
      for (final file in files) {
        notifier.addPendingImage(file);
      }
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return OnboardingSectionCardWidget(
      color: _cardColor,
      icon: Icons.photo_library_outlined,
      title: 'Photos',
      subtitle: 'Show buyers your shop, work or products.',
      children: [
        if (isFoodSeller)
          Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppColors.border),
            ),
            child: Row(
              children: [
                Icon(Icons.info_outline, size: 18, color: AppColors.green),
                const Gap(8),
                Expanded(
                  child: Text(
                    'Add photos of your kitchen, cooking area, and food preparation space.',
                    style: GoogleFonts.hind(fontSize: 12),
                  ),
                ),
              ],
            ),
          ),
        if (!isFoodSeller)
          Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppColors.border),
            ),
            child: Row(
              children: [
                Icon(Icons.info_outline, size: 18, color: AppColors.green),
                const Gap(8),
                Expanded(
                  child: Text(
                    'Add photos of your shop, workplace, products, or business premises.',
                    style: GoogleFonts.hind(fontSize: 12),
                  ),
                ),
              ],
            ),
          ),
        Consumer(
          builder: (context, ref, _) {
            final isBusy = ref.watch(sellerFormActionProvider.select((s) => s.isBusy));
            final isUploading = ref.watch(
              sellerFormActionProvider.select((s) => s.isUploadingImages),
            );
            return SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: isBusy ? null : () => _onAddPhotosPressed(context, ref),
                icon: isUploading
                    ? const SizedBox(
                        height: 16,
                        width: 16,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.add_photo_alternate_outlined),
                label: Text('Add photos', style: GoogleFonts.hind()),
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.green,
                  side: BorderSide(color: AppColors.green),
                  minimumSize: const Size.fromHeight(44),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
              ),
            );
          },
        ),
        if (sellerId == '')
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              'Save as draft to enable photo upload',
              style: GoogleFonts.hind(fontSize: 11, color: AppColors.muted),
            ),
          ),
        const Gap(12),
        ImageGridWidget(sellerId: sellerId),
      ],
    );
  }
}

class _DocSlot {
  const _DocSlot(this.type, this.title, this.icon) : required = true;
  final String type, title;
  final IconData icon;
  final bool required;
}

const _aadhaarSlot = _DocSlot('AADHAAR', 'Aadhaar card', Icons.badge_outlined);
const _panSlot = _DocSlot('PAN', 'PAN card', Icons.credit_card_outlined);
const _fssaiSlot = _DocSlot('FSSAI_LICENSE', 'FSSAI license', Icons.restaurant_outlined);

String? _validateDocNumber(String type, String? v) {
  final value = (v ?? '').trim().toUpperCase();
  if (value.isEmpty) return 'Required';
  switch (type) {
    case 'AADHAAR':
      return RegExp(r'^\d{12}$').hasMatch(value) ? null : 'Enter a 12-digit Aadhaar number';
    case 'PAN':
      return RegExp(r'^[A-Z]{5}[0-9]{4}[A-Z]$').hasMatch(value)
          ? null
          : 'Enter a valid PAN (e.g. ABCDE1234F)';
    case 'FSSAI_LICENSE':
      return RegExp(r'^\d{14}$').hasMatch(value) ? null : 'Enter a 14-digit FSSAI number';
    case 'GST_CERTIFICATE':
      return value.length == 15 ? null : 'GSTIN must be 15 characters';
    default:
      return null;
  }
}

List<String> missingRequiredDocuments(
  WidgetRef ref,
  String sellerId, {
  required bool isFoodSeller,
}) {
  final pending = ref.read(sellerFormActionProvider).pendingDocuments.map((d) => d.type).toSet();
  final uploaded = sellerId.isEmpty
      ? <String>{}
      : (ref.read(sellerDocumentProvider(sellerId)).asData?.value ?? const <KycDocumentEntity>[])
            .map((d) => d.documentType)
            .toSet();
  final all = {...pending, ...uploaded};
  return [
    _aadhaarSlot,
    _panSlot,
    if (isFoodSeller) _fssaiSlot,
  ].where((s) => !all.contains(s.type)).map((s) => s.title).toList();
}

class _DocumentsSection extends ConsumerWidget {
  const _DocumentsSection({required this.sellerId, required this.isFoodSeller});
  final String sellerId;
  final bool isFoodSeller;

  static const _slotTypes = {'AADHAAR', 'PAN', 'FSSAI_LICENSE'};

  Future<void> _openSheet(
    BuildContext context, {
    _DocSlot? slot,
    PendingDocument? pending,
    KycDocumentEntity? uploaded,
  }) {
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) =>
          _DocumentSheet(sellerId: sellerId, slot: slot, pending: pending, uploaded: uploaded),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final pendingList = ref.watch(sellerFormActionProvider.select((s) => s.pendingDocuments));
    final uploadedList = sellerId.isEmpty
        ? const <KycDocumentEntity>[]
        : (ref.watch(sellerDocumentProvider(sellerId)).asData?.value ??
              const <KycDocumentEntity>[]);

    PendingDocument? pendingOf(String t) {
      for (final d in pendingList) {
        if (d.type == t) return d;
      }
      return null;
    }

    KycDocumentEntity? uploadedOf(String t) {
      for (final d in uploadedList) {
        if (d.documentType == t) return d;
      }
      return null;
    }

    final slots = [_aadhaarSlot, _panSlot, if (isFoodSeller) _fssaiSlot];
    final otherPending = pendingList.where((d) => !_slotTypes.contains(d.type)).toList();
    final otherUploaded = uploadedList.where((d) => !_slotTypes.contains(d.documentType)).toList();

    return OnboardingSectionCardWidget(
      color: _cardColor,
      icon: Icons.verified_user_outlined,
      title: 'Document Verification',
      subtitle: 'Upload required documents (mandatory for registered categories).',
      children: [
        if (isFoodSeller)
          Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppColors.border),
            ),
            child: Row(
              children: [
                Icon(Icons.info_outline, size: 18, color: AppColors.green),
                const Gap(8),
                Expanded(
                  child: Text(
                    'For Food category, FSSAI license is required before you can accept orders.',
                    style: GoogleFonts.hind(fontSize: 12),
                  ),
                ),
              ],
            ),
          ),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 1.25,
          children: [
            for (final slot in slots)
              Builder(
                builder: (context) {
                  final p = pendingOf(slot.type);
                  final u = uploadedOf(slot.type);
                  return _DocTile(
                    title: slot.title,
                    icon: slot.icon,
                    tag: slot.required ? 'Required' : 'Optional',
                    uploaded: p != null || u != null,
                    onTap: () => _openSheet(context, slot: slot, pending: p, uploaded: u),
                  );
                },
              ),
            _DocTile(
              title: 'Other documents',
              icon: Icons.folder_open_outlined,
              tag: 'Optional',
              uploaded: false,
              buttonLabel: 'Add',
              onTap: () => _openSheet(context),
            ),
          ],
        ),
        if (otherPending.isNotEmpty || otherUploaded.isNotEmpty) ...[
          const _SubHeading('Other documents'),
          for (final d in otherPending)
            InkWell(
              onTap: () => _openSheet(context, pending: d),
              child: _ItemTile(
                icon: Icons.description_outlined,
                title: _sentence(d.type),
                subtitle: d.number,
                trailing: const Icon(Icons.chevron_right),
              ),
            ),
          for (final d in otherUploaded)
            InkWell(
              onTap: () => _openSheet(context, uploaded: d),
              child: _ItemTile(
                icon: Icons.verified,
                iconColor: AppColors.green,
                title: _sentence(d.documentType),
                subtitle: d.verificationStatus,
                trailing: const Icon(Icons.chevron_right),
              ),
            ),
        ],
      ],
    );
  }
}

class _DocTile extends StatelessWidget {
  const _DocTile({
    required this.title,
    required this.icon,
    required this.tag,
    required this.uploaded,
    required this.onTap,
    this.buttonLabel = 'Upload',
  });
  final String title, tag, buttonLabel;
  final IconData icon;
  final bool uploaded;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = uploaded ? AppColors.green : AppColors.muted;
    return InkWell(
      borderRadius: BorderRadius.circular(10),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: uploaded ? AppColors.green.withValues(alpha: 0.08) : Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: uploaded ? AppColors.green : AppColors.border),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              children: [
                Icon(icon, size: 26, color: color),
                const Gap(4),
                Text(
                  title,
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.hind(fontSize: 12.5, fontWeight: FontWeight.w700),
                ),
                Text(
                  tag,
                  style: GoogleFonts.hind(
                    fontSize: 10.5,
                    color: tag == 'Required' ? Colors.red.shade400 : AppColors.muted,
                  ),
                ),
              ],
            ),
            Container(
              height: 28,
              alignment: Alignment.center,
              width: double.infinity,
              decoration: BoxDecoration(
                color: uploaded ? AppColors.green : Colors.transparent,
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: AppColors.green),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    uploaded ? Icons.check_circle : Icons.add,
                    size: 14,
                    color: uploaded ? Colors.white : AppColors.green,
                  ),
                  const Gap(4),
                  Text(
                    uploaded ? 'Uploaded' : buttonLabel,
                    style: GoogleFonts.hind(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: uploaded ? Colors.white : AppColors.green,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DocumentSheet extends ConsumerStatefulWidget {
  const _DocumentSheet({required this.sellerId, this.slot, this.pending, this.uploaded});
  final String sellerId;
  final _DocSlot? slot; // null => "Other documents"
  final PendingDocument? pending;
  final KycDocumentEntity? uploaded;

  @override
  ConsumerState<_DocumentSheet> createState() => _DocumentSheetState();
}

class _DocumentSheetState extends ConsumerState<_DocumentSheet> {
  final _formKey = GlobalKey<FormState>();
  final _number = TextEditingController();
  XFile? _file;
  bool _editing = false;
  late DocumentType _otherType = DocumentType.values.firstWhere(
    (d) => !_DocumentsSection._slotTypes.contains(d.type),
    orElse: () => DocumentType.values.first,
  );

  bool get _hasExisting => widget.pending != null || widget.uploaded != null;
  bool get _showForm => !_hasExisting || _editing;
  bool get _typeLocked => widget.slot != null || _hasExisting;

  String get _type =>
      widget.slot?.type ?? widget.pending?.type ?? widget.uploaded?.documentType ?? _otherType.type;

  String get _title => widget.slot?.title ?? _sentence(_type);

  @override
  void dispose() {
    _number.dispose();
    super.dispose();
  }

  Future<void> _pickFile() async {
    final source = await chooseImageSource(context);
    if (source == null) return;
    final file = await ImagePicker().pickImage(source: source, imageQuality: 85, maxWidth: 2000);
    if (file == null) return;
    setState(() => _file = file);
  }

  void _save() {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    if (_file == null) {
      _snack(context, 'Please upload the document');
      return;
    }
    final notifier = ref.read(sellerFormActionProvider.notifier);
    if (widget.pending != null) notifier.removePendingDocument(widget.pending!);
    notifier.addPendingDocument(
      PendingDocument(type: _type, number: _number.text.trim().toUpperCase(), file: _file!),
    );
    Navigator.pop(context);
  }

  void _delete() {
    ref.read(sellerFormActionProvider.notifier).removePendingDocument(widget.pending!);
    Navigator.pop(context);
  }

  Future<void> _download() async {
    try {
      final base64File = await ref
          .read(downloadKycDocumentFileUsecase)
          .call(sellerId: widget.sellerId, documentFileUrl: widget.uploaded!.documentFileUrl);
      if (!mounted) return;
      _snack(context, 'Downloaded $_title (${base64File.length} chars, base64)');
    } catch (e) {
      if (!mounted) return;
      _snack(context, 'Could not download document: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.viewInsetsOf(context).bottom),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    _showForm
                        ? (_hasExisting
                              ? 'Upload new $_title'
                              : 'Add $_title'.replaceFirst('Add Other', 'Add other'))
                        : _title,
                    style: GoogleFonts.hind(fontSize: 16, fontWeight: FontWeight.w700),
                  ),
                ),
                IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(context)),
              ],
            ),
            const Gap(8),
            if (_showForm) _buildForm() else _buildDetails(),
          ],
        ),
      ),
    );
  }

  Widget _buildForm() {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (!_typeLocked) ...[
            const LableWidget('Document type', required: true),
            OnboardingDropdownListWidget<DocumentType>(
              hint: 'Select document type',
              icon: Icons.description_outlined,
              value: _otherType,
              items: DocumentType.values
                  .where((d) => !_DocumentsSection._slotTypes.contains(d.type))
                  .toList(),
              labelBuilder: (d) => d.label,
              onChanged: (v) => setState(() {
                _otherType = v ?? _otherType;
                _number.clear();
              }),
            ),
            const Gap(12),
          ],
          LableWidget('$_title number', required: true),
          TextFormField(
            controller: _number,
            textCapitalization: TextCapitalization.characters,
            keyboardType: _type == 'AADHAAR' || _type == 'FSSAI_LICENSE'
                ? TextInputType.number
                : TextInputType.text,
            validator: (v) => _validateDocNumber(_type, v),
            style: GoogleFonts.hind(fontSize: 13),
            decoration: InputDecoration(
              hintText: 'Enter ${_title.toLowerCase()} number',
              prefixIcon: const Icon(Icons.numbers),
              isDense: true,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
            ),
          ),
          const Gap(12),
          const LableWidget('Document file', required: true),
          _UploadTile(emptyLabel: 'Upload document', fileName: _file?.name, onTap: _pickFile),
          const Gap(16),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              style: FilledButton.styleFrom(backgroundColor: AppColors.green),
              onPressed: _save,
              child: Text(
                _hasExisting ? 'Replace document' : 'Save document',
                style: GoogleFonts.hind(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetails() {
    final p = widget.pending;
    final u = widget.uploaded;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (p != null)
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.file(
              File(p.file.path),
              height: 180,
              width: double.infinity,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                height: 120,
                color: Colors.black12,
                alignment: Alignment.center,
                child: const Icon(Icons.insert_drive_file_outlined, size: 40),
              ),
            ),
          ),
        const Gap(12),
        _detailRow('Type', _sentence(_type)),
        if (p != null) ...[
          _detailRow('Number', p.number),
          _detailRow('File', p.file.name),
          _detailRow('Status', 'Not submitted yet'),
        ],
        if (u != null) _detailRow('Status', u.verificationStatus),
        const Gap(16),
        Row(
          children: [
            if (p != null)
              Expanded(
                child: OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.red,
                    side: const BorderSide(color: Colors.red),
                  ),
                  onPressed: _delete,
                  icon: const Icon(Icons.delete_outline),
                  label: Text('Delete', style: GoogleFonts.hind()),
                ),
              ),
            if (u != null && p == null)
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _download,
                  icon: const Icon(Icons.download_outlined),
                  label: Text('Download', style: GoogleFonts.hind()),
                ),
              ),
            const Gap(10),
            Expanded(
              child: FilledButton.icon(
                style: FilledButton.styleFrom(backgroundColor: AppColors.green),
                onPressed: () => setState(() => _editing = true),
                icon: const Icon(Icons.upload_file_outlined),
                label: Text('Upload new', style: GoogleFonts.hind()),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _detailRow(String k, String v) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 3),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 80,
          child: Text(k, style: GoogleFonts.hind(fontSize: 12, color: AppColors.muted)),
        ),
        Expanded(
          child: Text(v, style: GoogleFonts.hind(fontSize: 13, fontWeight: FontWeight.w600)),
        ),
      ],
    ),
  );
}

// class _DocumentsSection extends ConsumerStatefulWidget {
//   const _DocumentsSection({required this.sellerId});
//   final String sellerId;

//   @override
//   ConsumerState<_DocumentsSection> createState() => _DocumentsSectionState();
// }

class _DocumentsSectionState extends ConsumerState<_DocumentsSection> {
  final _formKey = GlobalKey<FormState>();
  final _docNumber = TextEditingController();
  DocumentType _docType = DocumentType.values.first;
  XFile? _docFile;

  @override
  void dispose() {
    _docNumber.dispose();
    super.dispose();
  }

  String? _validateDocNumber(String? v) {
    final value = (v ?? '').trim().toUpperCase();
    if (value.isEmpty) return 'Required';
    switch (_docType.type) {
      case 'AADHAAR':
        return RegExp(r'^\d{12}$').hasMatch(value) ? null : 'Enter a 12-digit Aadhaar number';
      case 'PAN':
        return RegExp(r'^[A-Z]{5}[0-9]{4}[A-Z]$').hasMatch(value)
            ? null
            : 'Enter a valid PAN (e.g. ABCDE1234F)';
      case 'GST_CERTIFICATE':
        return value.length == 15 ? null : 'GSTIN must be 15 characters';
      default:
        return null;
    }
  }

  Future<void> _pickDocumentFile() async {
    final source = await chooseImageSource(context);
    if (source == null) return;
    final picker = ImagePicker();
    final file = await picker.pickImage(source: source, imageQuality: 85, maxWidth: 2000);
    if (file == null) return;
    setState(() => _docFile = file);
  }

  void _addDocument() {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    if (_docFile == null) {
      _snack(context, 'Please upload the document');
      return;
    }

    ref
        .read(sellerFormActionProvider.notifier)
        .addPendingDocument(
          PendingDocument(
            type: _docType.type,
            number: _docNumber.text.trim().toUpperCase(),
            file: _docFile!,
          ),
        );

    setState(() {
      _docNumber.clear();
      _docFile = null;
    });
  }

  Future<void> _downloadDocument(KycDocumentEntity doc) async {
    try {
      final base64File = await ref
          .read(downloadKycDocumentFileUsecase)
          .call(sellerId: widget.sellerId, documentFileUrl: doc.documentFileUrl);
      if (!mounted) return;
      _snack(
        context,
        'Downloaded ${_sentence(doc.documentType)} (${base64File.length} chars, base64)',
      );
    } catch (e) {
      if (!mounted) return;
      _snack(context, 'Could not download document: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final pendingDocuments = ref.watch(sellerFormActionProvider.select((s) => s.pendingDocuments));
    final AsyncValue<List<KycDocumentEntity>>? uploaded = widget.sellerId == ''
        ? null
        : ref.watch(sellerDocumentProvider(widget.sellerId));

    return OnboardingSectionCardWidget(
      color: _cardColor,
      icon: Icons.badge_outlined,
      title: 'Documents',
      subtitle: 'Upload your identity and business documents.',
      children: [
        Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const LableWidget('Document type', required: true),
              OnboardingDropdownListWidget<DocumentType>(
                hint: 'Select document type',
                icon: Icons.description_outlined,
                value: _docType,
                items: DocumentType.values,
                labelBuilder: (d) => d.label, // "Aadhaar card"
                onChanged: (v) => setState(() {
                  _docType = v ?? _docType;
                  _docNumber.clear();
                }),
              ),
              const Gap(12),
              LableWidget('${_sentence(_docType.label)} number', required: true),
              OnboardingTextFieldWidget(
                hint: 'Enter ${_sentence(_docType.label).toLowerCase()} number',
                icon: Icons.numbers,
                // controller: _docNumber,
                // textCapitalization: TextCapitalization.characters,
                keyboard: _docType.type == 'AADHAAR' ? TextInputType.number : null,
                // validator: _validateDocNumber,
                onChanged: (_) {},
              ),
            ],
          ),
        ),
        const Gap(12),
        const LableWidget('Document file', required: true),
        _UploadTile(
          emptyLabel: 'Upload document',
          fileName: _docFile?.name,
          onTap: _pickDocumentFile,
        ),
        const Gap(12),
        Align(
          alignment: Alignment.centerRight,
          child: FilledButton.tonal(
            onPressed: _addDocument,
            child: Text('Add document', style: GoogleFonts.hind()),
          ),
        ),
        if (pendingDocuments.isNotEmpty) ...[
          const _SubHeading('Added documents'),
          for (final doc in pendingDocuments)
            _ItemTile(
              icon: Icons.description_outlined,
              title: _sentence(doc.type),
              subtitle: doc.number,
              trailing: IconButton(
                icon: const Icon(Icons.delete_outline),
                onPressed: () =>
                    ref.read(sellerFormActionProvider.notifier).removePendingDocument(doc),
              ),
            ),
        ],
        if (uploaded != null)
          uploaded.when(
            loading: () => const Padding(
              padding: EdgeInsets.symmetric(vertical: 16),
              child: Center(child: CircularProgressIndicator()),
            ),
            error: (e, st) {
              debugPrint('documents error: $e\n$st');
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Text('Could not load documents: $e'),
              );
            },
            data: (list) {
              if (list.isEmpty) return const SizedBox.shrink();
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const _SubHeading('Uploaded documents'),
                  for (final doc in list)
                    _ItemTile(
                      icon: Icons.verified,
                      iconColor: Colors.green,
                      title: _sentence(doc.documentType),
                      subtitle: doc.verificationStatus,
                      trailing: IconButton(
                        icon: const Icon(Icons.download_outlined),
                        tooltip: 'Download',
                        onPressed: () => _downloadDocument(doc),
                      ),
                    ),
                ],
              );
            },
          ),
      ],
    );
  }
}

class _CertificatesSection extends ConsumerStatefulWidget {
  const _CertificatesSection({required this.sellerId});
  final String sellerId;

  @override
  ConsumerState<_CertificatesSection> createState() => _CertificatesSectionState();
}

class _CertificatesSectionState extends ConsumerState<_CertificatesSection> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _certificateNumber = TextEditingController();
  final _issuingAuthority = TextEditingController();
  XFile? _file;
  DateTime? _issueDate;
  bool _hasExpiry = false;
  DateTime? _expiryDate;
  CertificateType selected = CertificateType.values.first;

  static final _dateFormat = DateFormat('dd MMM yyyy');

  @override
  void dispose() {
    _name.dispose();
    _certificateNumber.dispose();
    _issuingAuthority.dispose();
    super.dispose();
  }

  Future<void> _pickCertificateFile() async {
    final source = await chooseImageSource(context);
    if (source == null) return;
    final picker = ImagePicker();
    final file = await picker.pickImage(source: source, imageQuality: 85, maxWidth: 2000);
    if (file == null) return;
    setState(() => _file = XFile(file.path, name: file.name));
  }

  Future<void> _pickDate({required bool isExpiry}) async {
    final now = DateTime.now();
    final initial = isExpiry ? (_expiryDate ?? _issueDate ?? now) : (_issueDate ?? now);
    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(2000),
      lastDate: DateTime(now.year + 20),
    );
    if (picked == null) return;
    setState(() {
      if (isExpiry) {
        _expiryDate = picked;
      } else {
        _issueDate = picked;
      }
    });
  }

  void _addCertificate() {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    if (_file == null) {
      _snack(context, 'Please upload the certificate (image or PDF)');
      return;
    }
    final issueDate = _issueDate;
    if (issueDate == null) {
      _snack(context, 'Please select the certification date');
      return;
    }
    final expiryDate = _expiryDate;
    if (_hasExpiry) {
      if (expiryDate == null) {
        _snack(context, 'Please select the expiry date');
        return;
      }
      if (!expiryDate.isAfter(issueDate)) {
        _snack(context, 'Expiry date must be after the certification date');
        return;
      }
    }

    ref
        .read(sellerFormActionProvider.notifier)
        .addPendingCertificate(
          PendingCertificate(
            name: _name.text.trim(),
            file: _file!,
            certificateNumber: _certificateNumber.text.trim(),
            issuingAuthority: _issuingAuthority.text.trim(),
            type: selected.value,
            issueDate: issueDate,
            hasExpiry: _hasExpiry,
            expiryDate: _hasExpiry ? expiryDate : null,
          ),
        );

    setState(() {
      _name.clear();
      _certificateNumber.clear();
      _file = null;
      _issueDate = null;
      _hasExpiry = false;
      _expiryDate = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final pendingCertificates = ref.watch(
      sellerFormActionProvider.select((s) => s.pendingCertificates),
    );
    final AsyncValue<List<CertificateEntity>>? uploaded = widget.sellerId == ''
        ? null
        : ref.watch(sellerCertificatesProvider(widget.sellerId));

    return OnboardingSectionCardWidget(
      color: _cardColor,
      icon: Icons.workspace_premium_outlined,
      title: 'Certificates',
      subtitle: 'Add any certifications you have. This is optional.',
      children: [
        Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const LableWidget('Certificate type', required: true),
              OnboardingDropdownListWidget<CertificateType>(
                hint: 'Select certificate type',
                icon: Icons.workspace_premium_outlined,
                value: selected,
                items: CertificateType.values,
                labelBuilder: (t) => t.label,
                validator: (v) => v == null ? 'Select a certificate type' : null,
                onChanged: (v) => setState(() => selected = v ?? selected),
              ),
              const Gap(12),
              const LableWidget('Certificate name', required: true),
              OnboardingTextFieldWidget(
                hint: 'Certificate name',
                icon: Icons.badge_outlined,

                onChanged: (_) {},
              ),
              const Gap(12),
              const LableWidget('Certificate number'),
              OnboardingTextFieldWidget(
                hint: 'Certificate number',
                icon: Icons.numbers,

                onChanged: (_) {},
              ),
              const Gap(12),
              const LableWidget('Issuing authority'),
              OnboardingTextFieldWidget(
                hint: 'Issuing authority',
                icon: Icons.account_balance_outlined,

                onChanged: (_) {},
              ),
              const Gap(12),
              _DateField(
                label: 'Certification date',
                value: _issueDate,
                onTap: () => _pickDate(isExpiry: false),
              ),
              const Gap(4),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                activeThumbColor: AppColors.green,
                title: Text(
                  'This certificate has an expiry date',
                  style: GoogleFonts.hind(fontSize: 13),
                ),
                value: _hasExpiry,
                onChanged: (v) => setState(() {
                  _hasExpiry = v;
                  if (!v) _expiryDate = null;
                }),
              ),
              if (_hasExpiry) ...[
                const Gap(4),
                _DateField(
                  label: 'Expiry date',
                  value: _expiryDate,
                  onTap: () => _pickDate(isExpiry: true),
                ),
              ],
            ],
          ),
        ),
        const Gap(12),
        const LableWidget('Certificate file', required: true),
        _UploadTile(
          emptyLabel: 'Upload certificate (image or PDF)',
          fileName: _file?.name,
          onTap: _pickCertificateFile,
        ),
        const Gap(12),
        Align(
          alignment: Alignment.centerRight,
          child: FilledButton.tonal(
            onPressed: _addCertificate,
            child: Text('Add certificate', style: GoogleFonts.hind()),
          ),
        ),
        if (pendingCertificates.isNotEmpty) ...[
          const _SubHeading('Added certificates'),
          for (final cert in pendingCertificates)
            _ItemTile(
              icon: Icons.verified_outlined,
              title: cert.name,
              subtitle: cert.hasExpiry && cert.expiryDate != null
                  ? 'Issued ${_dateFormat.format(cert.issueDate)} · Expires ${_dateFormat.format(cert.expiryDate!)}'
                  : 'Issued ${_dateFormat.format(cert.issueDate)} · No expiry',
              trailing: IconButton(
                icon: const Icon(Icons.delete_outline),
                onPressed: () =>
                    ref.read(sellerFormActionProvider.notifier).removePendingCertificate(cert),
              ),
            ),
        ],
        if (uploaded != null)
          uploaded.when(
            loading: () => const Padding(
              padding: EdgeInsets.symmetric(vertical: 16),
              child: Center(child: CircularProgressIndicator()),
            ),
            error: (e, st) {
              debugPrint('certificates error: $e\n$st');
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Text('Could not load certificates: $e'),
              );
            },
            data: (list) {
              if (list.isEmpty) return const SizedBox.shrink();
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const _SubHeading('Uploaded certificates'),
                  for (final cert in list)
                    _ItemTile(
                      icon: Icons.verified,
                      iconColor: Colors.green,
                      title: cert.certificateName,
                      subtitle: '',
                      trailing: const SizedBox.shrink(),
                    ),
                ],
              );
            },
          ),
      ],
    );
  }
}
