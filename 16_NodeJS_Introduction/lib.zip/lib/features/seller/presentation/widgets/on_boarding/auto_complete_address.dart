import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/domain/entities/address_entity.dart';
import 'package:society_seva/features/seller/domain/entities/place_details_entity.dart';
import 'package:society_seva/features/seller/presentation/provider/places_provider.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/onboarding_text_field_widget.dart';

class AddressAutocompleteField extends ConsumerStatefulWidget {
  const AddressAutocompleteField({
    super.key,
    required this.controller,
    required this.onChanged,
    required this.onPlaceSelected,
    this.onSearchAddress,
  });

  final TextEditingController controller;
  final ValueChanged<String> onChanged;
  final ValueChanged<PlaceDetails> onPlaceSelected;
  final VoidCallback? onSearchAddress;

  @override
  ConsumerState<AddressAutocompleteField> createState() => _State();
}

class _State extends ConsumerState<AddressAutocompleteField> {
  Timer? _debounce;
  List<AddressSuggestion> _items = [];
  int _requestId = 0;

  @override
  void dispose() {
    _debounce?.cancel();
    super.dispose();
  }

  void _onChanged(String value) {
    widget.onChanged(value);
    _debounce?.cancel();
    if (value.trim().length < 3) {
      setState(() => _items = []);
      return;
    }
    _debounce = Timer(const Duration(milliseconds: 400), () async {
      final id = ++_requestId;
      final result = await ref.read(placesRepositoryProvider).autocomplete(value.trim());
      if (!mounted || id != _requestId) return;
      setState(() => _items = result);
    });
  }

  Future<void> _select(AddressSuggestion s) async {
    setState(() => _items = []);
    FocusScope.of(context).unfocus();
    final d = await ref.read(placesRepositoryProvider).getDetails(s.placeId);
    if (d != null && mounted) widget.onPlaceSelected(d);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        OnboardingTextFieldWidget(
          controller: widget.controller,
          hint: 'Search or enter address (e.g. MG Road, Pune)',
          icon: Icons.home_work_outlined,
          maxLineLength: 2,
          suffixIcon: IconButton(
            tooltip: 'Search location on map',
            icon: const Icon(Icons.search, size: 20, color: AppColors.green),
            onPressed: () {
              setState(() => _items = []);
              widget.onSearchAddress?.call();
            },
          ),
          onChanged: _onChanged,
          onFieldSubmitted: (_) {
            setState(() => _items = []);
            widget.onSearchAddress?.call();
          },
        ),
        if (_items.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Material(
              color: Theme.of(context).colorScheme.surface,
              elevation: 2,
              clipBehavior: Clip.antiAlias,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: const BorderSide(color: AppColors.border),
              ),
              child: ListView.separated(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                padding: EdgeInsets.zero,
                itemCount: _items.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (_, i) => ListTile(
                  dense: true,
                  leading: const Icon(Icons.location_on_outlined, size: 20),
                  title: Text(
                    _items[i].text,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.hind(fontSize: 13),
                  ),
                  onTap: () {
                    final s = _items[i];
                    setState(() => _items = []);
                    FocusScope.of(context).unfocus();
                    _select(s);
                  },
                ),
              ),
            ),
          ),
      ],
    );
  }
}
