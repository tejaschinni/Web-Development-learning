import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/core/widgets/blinking_widget.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_category_provider.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/shop/domain/entities/shop_category.dart';

String _key(String s) => s.trim().toLowerCase();

class OnboardingDeclaredCapabilitiesStep extends ConsumerStatefulWidget {
  final String? categoryType;

  const OnboardingDeclaredCapabilitiesStep({super.key, this.categoryType});

  @override
  ConsumerState<OnboardingDeclaredCapabilitiesStep> createState() =>
      _OnboardingDeclaredCapabilitiesStepState();
}

class _OnboardingDeclaredCapabilitiesStepState
    extends ConsumerState<OnboardingDeclaredCapabilitiesStep> {
  final _search = TextEditingController();
  final _desc = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _search.dispose();
    _desc.dispose();
    super.dispose();
  }

  @override
  void initState() {
    _desc.text = ref.read(sellerFormActionProvider).reg.capabilitiesDescription;

    ref.listenManual<String>(
      sellerFormActionProvider.select((s) => s.reg.capabilitiesDescription),
      (prev, next) {
        if (_desc.text != next) {
          _desc.value = TextEditingValue(
            text: next,
            selection: TextSelection.collapsed(offset: next.length),
          );
        }
      },
    );
    super.initState();
  }

  bool _matches(String label) => _query.isEmpty || _key(label).contains(_key(_query));

  void _clearSearch() {
    _search.clear();
    setState(() => _query = '');
  }

  void _addCustom(String text, Set<String> knownKeys) {
    final t = text.trim();
    if (t.isEmpty) return;
    ref.read(sellerFormActionProvider.notifier).addCustomCapabilityTag(t);
    _clearSearch();
    FocusScope.of(context).unfocus();
  }

  @override
  Widget build(BuildContext context) {
    final reg = ref.watch(sellerFormActionProvider.select((s) => s.reg));
    final notifier = ref.read(sellerFormActionProvider.notifier);
    final treeAsync = ref.watch(sellerCategoryTreeProvider((categoryType: widget.categoryType)));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Gap(15),
        Text(
          'What do you sell or offer?',
          style: GoogleFonts.hind(fontSize: 20, fontWeight: FontWeight.w700),
        ),
        const Gap(6),
        BlinkingWidget(
          enabled: true,
          duration: const Duration(milliseconds: 500),
          child: Text(
            'Pick your categories, then choose the items or services you can provide. '
            'We will use this to show you customer requests that match what you offer.',
            style: GoogleFonts.hind(fontSize: 12.5, color: AppColors.muted),
          ),
        ),
        const Gap(14),
        treeAsync.when(
          loading: () => const Padding(
            padding: EdgeInsets.symmetric(vertical: 32),
            child: Center(child: CircularProgressIndicator(color: AppColors.green)),
          ),
          error: (e, _) => Padding(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    'Could not load categories.',
                    style: GoogleFonts.hind(fontSize: 12.5, color: Colors.red),
                  ),
                ),
                TextButton(
                  onPressed: () => ref.invalidate(
                    sellerCategoryTreeProvider((categoryType: widget.categoryType)),
                  ),
                  child: const Text('Retry'),
                ),
              ],
            ),
          ),
          data: (categories) => _content(categories, reg, notifier),
        ),
      ],
    );
  }

  Widget _content(
    List<ShopCategory> categories,
    SellerRegState reg,
    SellerFormActionNotifier notifier,
  ) {
    final selectedCategories = [
      for (final c in categories)
        if (reg.capableCategoryIds.contains(c.id)) c,
    ];

    // every subcategory name that exists in the API tree
    final knownKeys = {
      for (final c in categories)
        for (final s in c.subCategories) _key(s.name),
    };

    final tags = reg.capabilityTags;
    bool isTagSelected(String name) => tags.any((t) => _key(t) == _key(name));

    final showAddTile =
        _query.trim().isNotEmpty &&
        !knownKeys.contains(_key(_query)) &&
        !tags.any((t) => _key(t) == _key(_query));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _header('Select categories', 'Select all that apply'),
        const Gap(8),
        _grid([
          for (final c in categories)
            _CapabilityCard(
              label: c.name,
              icon: Icons.category_outlined,
              selected: reg.capableCategoryIds.contains(c.id),
              onTap: () => notifier.toggleCapableCategory(c),
            ),
        ]),

        if (selectedCategories.isNotEmpty || tags.isNotEmpty) ...[
          const Gap(18),
          _buildSearch(knownKeys),
          const Gap(8),
          // if (showAddTile)
          // _AddTile(text: _query.trim(), onTap: () => _addCustom(_query, knownKeys)),
        ],

        if (tags.isNotEmpty) ...[
          const Gap(10),
          _header('Selected (${tags.length})', null),
          const Gap(8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final t in tags)
                _SelectedChip(label: t, onRemove: () => notifier.toggleCapabilityTag(t)),
            ],
          ),
        ],

        for (final c in selectedCategories)
          ...() {
            final subs = c.subCategories.where((s) => s.isActive && _matches(s.name)).toList();
            if (subs.isEmpty) return <Widget>[];
            return [
              const Gap(16),
              _header(c.name, 'Select all that apply'),
              const Gap(8),
              _grid([
                for (final s in subs)
                  _CapabilityCard(
                    label: s.name,
                    selected: isTagSelected(s.name),
                    onTap: () => notifier.toggleCapabilityTag(s.name),
                  ),
              ]),
            ];
          }(),

        if (selectedCategories.isEmpty && tags.isEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 12),
            child: Text(
              'Select a category above to see what you can offer.',
              style: GoogleFonts.hind(fontSize: 12.5, color: AppColors.muted),
            ),
          ),

        if (selectedCategories.isNotEmpty || tags.isNotEmpty) ...[
          const Gap(18),
          Text(
            'Describe what you offer (optional)',
            style: GoogleFonts.hind(fontSize: 15, fontWeight: FontWeight.w700),
          ),
          const Gap(8),
          TextField(
            controller: _desc,
            minLines: 3,
            maxLines: 5,
            maxLength: 300,
            style: GoogleFonts.hind(fontSize: 13),
            onChanged: notifier.setCapabilitiesDescription,
            decoration: InputDecoration(
              hintText: 'e.g. Homemade vegetarian tiffin, bulk orders with 2 days notice',
              hintStyle: GoogleFonts.hind(fontSize: 12, color: const Color(0xFF9E9E9E)),
              filled: true,
              fillColor: Colors.white,
              contentPadding: const EdgeInsets.all(10),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(color: AppColors.border),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(color: AppColors.border),
              ),
              focusedBorder: const OutlineInputBorder(
                borderRadius: BorderRadius.all(Radius.circular(8)),
                borderSide: BorderSide(color: AppColors.green),
              ),
            ),
          ),
        ],
      ],
    );
  }

  Widget _header(String title, String? trailing) => Row(
    children: [
      Expanded(
        child: Text(title, style: GoogleFonts.hind(fontSize: 15, fontWeight: FontWeight.w700)),
      ),
      if (trailing != null)
        Text(trailing, style: GoogleFonts.hind(fontSize: 11.5, color: AppColors.green)),
    ],
  );

  Widget _grid(List<Widget> children) => LayoutBuilder(
    builder: (context, c) {
      final w = (c.maxWidth - 10) / 2;
      return Wrap(
        spacing: 10,
        runSpacing: 10,
        children: [for (final child in children) SizedBox(width: w, child: child)],
      );
    },
  );

  Widget _buildSearch(Set<String> knownKeys) => TextField(
    controller: _search,
    textInputAction: TextInputAction.done,
    style: GoogleFonts.hind(fontSize: 13),
    onChanged: (v) => setState(() => _query = v),
    // onSubmitted: (v) => _addCustom(v, knownKeys),
    decoration: InputDecoration(
      hintText: 'Search ', //or add your own
      hintStyle: GoogleFonts.hind(fontSize: 12, color: const Color(0xFF9E9E9E)),
      prefixIcon: Icon(Icons.search, size: 18, color: AppColors.muted),
      suffixIcon: _query.isEmpty
          ? null
          : IconButton(icon: const Icon(Icons.close, size: 18), onPressed: _clearSearch),
      isDense: true,
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 13),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide(color: AppColors.border),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide(color: AppColors.border),
      ),
      focusedBorder: const OutlineInputBorder(
        borderRadius: BorderRadius.all(Radius.circular(8)),
        borderSide: BorderSide(color: AppColors.green),
      ),
    ),
  );
}

class _SelectedChip extends StatelessWidget {
  final String label;
  final VoidCallback onRemove;

  const _SelectedChip({required this.label, required this.onRemove});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.only(left: 12, right: 6, top: 6, bottom: 6),
      decoration: BoxDecoration(
        color: AppColors.green.withValues(alpha: 0.06),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.green),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Flexible(
            child: Text(
              label,
              overflow: TextOverflow.ellipsis,
              style: GoogleFonts.hind(
                fontSize: 12.5,
                fontWeight: FontWeight.w600,
                color: AppColors.green,
              ),
            ),
          ),
          const Gap(4),
          InkWell(
            onTap: onRemove,
            child: const Icon(Icons.close, size: 16, color: AppColors.green),
          ),
        ],
      ),
    );
  }
}

// class _AddTile extends StatelessWidget {
//   final String text;
//   final VoidCallback onTap;

//   const _AddTile({required this.text, required this.onTap});

//   @override
//   Widget build(BuildContext context) {
//     return InkWell(
//       borderRadius: BorderRadius.circular(8),
//       onTap: onTap,
//       child: Container(
//         padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
//         decoration: BoxDecoration(
//           color: AppColors.green.withValues(alpha: 0.06),
//           borderRadius: BorderRadius.circular(8),
//           border: Border.all(color: AppColors.green),
//         ),
//         child: Row(
//           children: [
//             const Icon(Icons.add_circle_outline, size: 18, color: AppColors.green),
//             const Gap(8),
//             Expanded(
//               child: Text(
//                 'Add "$text"',
//                 overflow: TextOverflow.ellipsis,
//                 style: GoogleFonts.hind(
//                   fontSize: 13,
//                   fontWeight: FontWeight.w600,
//                   color: AppColors.green,
//                 ),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

class _CapabilityCard extends StatelessWidget {
  final String label;
  final IconData? icon;
  final bool selected;
  final VoidCallback onTap;

  const _CapabilityCard({
    required this.label,
    required this.selected,
    required this.onTap,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(8),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        constraints: const BoxConstraints(minHeight: 56),
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: selected ? AppColors.green.withValues(alpha: 0.06) : Colors.white,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: selected ? AppColors.green : AppColors.border,
            width: selected ? 1.5 : 1,
          ),
        ),
        child: Row(
          children: [
            if (icon != null) ...[
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: AppColors.green.withValues(alpha: 0.10),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Icon(icon, size: 20, color: AppColors.green),
              ),
              const Gap(8),
            ],
            Expanded(
              child: Text(
                label,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.hind(
                  fontSize: 12,
                  height: 1.2,
                  fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
                ),
              ),
            ),
            const Gap(4),
            Icon(
              selected ? Icons.check_box : Icons.check_box_outline_blank,
              size: 20,
              color: selected ? AppColors.green : AppColors.muted,
            ),
          ],
        ),
      ),
    );
  }
}
