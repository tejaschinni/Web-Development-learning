import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/lable_widget.dart';

enum AvailableDaysType {
  monToFri('MON_TO_FRI'),
  satSun('SAT_SUN'),
  allDays('ALL_DAYS'),
  custom('CUSTOM');

  final String api;
  const AvailableDaysType(this.api);
}

const kWeekDays = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY'];

String _dayShort(String d) => d[0] + d.substring(1, 3).toLowerCase(); // MONDAY -> Mon

String formatApiTime(TimeOfDay t) {
  final h = t.hourOfPeriod == 0 ? 12 : t.hourOfPeriod;
  final m = t.minute.toString().padLeft(2, '0');
  return '$h:$m ${t.period == DayPeriod.am ? 'AM' : 'PM'}'; // "10:00 PM"
}

TimeOfDay? parseApiTime(String? s) {
  if (s == null) return null;
  final m = RegExp(r'^\s*(\d{1,2}):(\d{2})\s*(AM|PM)\s*$', caseSensitive: false).firstMatch(s);
  if (m == null) return null;
  var h = int.parse(m.group(1)!) % 12;
  if (m.group(3)!.toUpperCase() == 'PM') h += 12;
  return TimeOfDay(hour: h, minute: int.parse(m.group(2)!));
}

class AvailabilityValue {
  final Set<String> days;
  final TimeOfDay from;
  final TimeOfDay to;

  const AvailabilityValue({
    this.days = const {'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY'},
    this.from = const TimeOfDay(hour: 9, minute: 0),
    this.to = const TimeOfDay(hour: 18, minute: 0),
  });

  AvailabilityValue copyWith({Set<String>? days, TimeOfDay? from, TimeOfDay? to}) =>
      AvailabilityValue(days: days ?? this.days, from: from ?? this.from, to: to ?? this.to);

  AvailableDaysType get daysType {
    const monFri = {'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY'};
    const satSun = {'SATURDAY', 'SUNDAY'};
    if (days.length == 7) return AvailableDaysType.allDays;
    if (days.length == 5 && days.containsAll(monFri)) return AvailableDaysType.monToFri;
    if (days.length == 2 && days.containsAll(satSun)) return AvailableDaysType.satSun;
    return AvailableDaysType.custom;
  }

  int _mins(TimeOfDay t) => t.hour * 60 + t.minute;

  bool get isTimeRangeValid => _mins(to) > _mins(from);
  bool get isValid => days.isNotEmpty && isTimeRangeValid;

  Map<String, dynamic> toJson() => {
    'daysType': daysType.api,
    'availableDaysType': daysType.api,
    'availableDays': kWeekDays.where(days.contains).toList(),
    'fromTime': formatApiTime(from),
    'toTime': formatApiTime(to),
    'availableFromTime': formatApiTime(from),
    'availableToTime': formatApiTime(to),
  };

  factory AvailabilityValue.fromJson(Map<String, dynamic> j) {
    final rawDays = (j['availableDays'] as List?)?.map((e) => '$e'.toUpperCase()).toSet() ?? {};
    Set<String> days = rawDays.where(kWeekDays.contains).toSet();
    final fromStr = (j['availableFromTime'] ?? j['fromTime']) as String?;
    final toStr = (j['availableToTime'] ?? j['toTime']) as String?;
    final typeStr = (j['availableDaysType'] ?? j['daysType']) as String?;

    if (days.isEmpty) {
      // fall back to the type when the list is missing
      switch (typeStr) {
        case 'MON_TO_FRI':
          days = kWeekDays.take(5).toSet();
        case 'SAT_SUN':
          days = {'SATURDAY', 'SUNDAY'};
        case 'ALL_DAYS':
          days = kWeekDays.toSet();
        default:
          return AvailabilityValue(
            from: parseApiTime(fromStr) ?? const TimeOfDay(hour: 9, minute: 0),
            to: parseApiTime(toStr) ?? const TimeOfDay(hour: 18, minute: 0),
          );
      }
    }
    return AvailabilityValue(
      days: days,
      from: parseApiTime(fromStr) ?? const TimeOfDay(hour: 9, minute: 0),
      to: parseApiTime(toStr) ?? const TimeOfDay(hour: 18, minute: 0),
    );
  }
}

class OnboardingAvailablitiyStep extends StatelessWidget {
  final AvailabilityValue value;
  final ValueChanged<AvailabilityValue> onChanged;

  const OnboardingAvailablitiyStep({super.key, required this.value, required this.onChanged});

  void _toggle(String day) {
    final set = {...value.days};
    set.contains(day) ? set.remove(day) : set.add(day);
    onChanged(value.copyWith(days: set));
  }

  Future<void> _pick(BuildContext context, {required bool isFrom}) async {
    final t = await showTimePicker(context: context, initialTime: isFrom ? value.from : value.to);
    if (t == null) return;
    onChanged(isFrom ? value.copyWith(from: t) : value.copyWith(to: t));
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const LableWidget('Service Availability', required: true),
        Text(
          'Let buyers know when you are available.',
          style: GoogleFonts.hind(fontSize: 11, color: AppColors.muted),
        ),
        const SizedBox(height: 10),

        // Days
        Wrap(
          spacing: 14,
          runSpacing: 8,
          children: [
            for (final d in kWeekDays)
              InkWell(
                borderRadius: BorderRadius.circular(6),
                onTap: () => _toggle(d),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(
                      width: 22,
                      height: 22,
                      child: Checkbox(
                        value: value.days.contains(d),
                        activeColor: AppColors.green,
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        visualDensity: VisualDensity.compact,
                        side: BorderSide(color: AppColors.border, width: 1.5),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                        onChanged: (_) => _toggle(d),
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(_dayShort(d), style: GoogleFonts.hind(fontSize: 13)),
                  ],
                ),
              ),
          ],
        ),
        if (value.days.isEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              'Select at least one day',
              style: GoogleFonts.hind(fontSize: 11, color: Colors.red),
            ),
          ),
        const SizedBox(height: 14),

        // Times
        Row(
          children: [
            Expanded(
              child: _TimeTile(
                label: 'Available From',
                time: formatApiTime(value.from),
                onTap: () => _pick(context, isFrom: true),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _TimeTile(
                label: 'Available To',
                time: formatApiTime(value.to),
                onTap: () => _pick(context, isFrom: false),
              ),
            ),
          ],
        ),
        if (!value.isTimeRangeValid)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              'End time must be after start time',
              style: GoogleFonts.hind(fontSize: 11, color: Colors.red),
            ),
          ),
      ],
    );
  }
}

class _TimeTile extends StatelessWidget {
  final String label, time;
  final VoidCallback onTap;
  const _TimeTile({required this.label, required this.time, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        LableWidget(label),
        InkWell(
          borderRadius: BorderRadius.circular(8),
          onTap: onTap,
          child: Container(
            height: 44,
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppColors.border),
            ),
            child: Row(
              children: [
                Icon(Icons.access_time, size: 18, color: AppColors.muted),
                const SizedBox(width: 8),
                Expanded(child: Text(time, style: GoogleFonts.hind(fontSize: 13))),
                const Icon(Icons.keyboard_arrow_down, size: 20),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
