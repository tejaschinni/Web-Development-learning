import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:society_seva/app/theme/app_theme.dart';

class SellerStatusAppBar extends StatelessWidget implements PreferredSizeWidget {
  const SellerStatusAppBar({
    super.key,
    this.onBack,
  });

  final VoidCallback? onBack;

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: AppColors.surface,
      elevation: 0,
      scrolledUnderElevation: 0,
      leading: IconButton(
        icon: const Icon(Icons.arrow_back, color: AppColors.ink),
        onPressed: onBack ??
            () {
              if (context.canPop()) {
                context.pop();
              } else {
                context.go('/modules/seller/sellerDashboard');
              }
            },
      ),
      titleSpacing: 0,
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Image.asset(
            'assets/images/logo/h-logo.png',
            height: 32,
            errorBuilder: (context, error, stackTrace) => Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.eco, color: AppColors.green, size: 26),
                const Gap(6),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    RichText(
                      text: TextSpan(
                        children: [
                          TextSpan(
                            text: 'Vasundhara ',
                            style: AppTheme.display(
                              16,
                              w: FontWeight.w800,
                              c: AppColors.green,
                            ),
                          ),
                          TextSpan(
                            text: 'SEVA',
                            style: AppTheme.display(
                              16,
                              w: FontWeight.w800,
                              c: AppColors.red,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Text(
                      'Earn Together  Live Together',
                      style: AppTheme.hind(9, c: AppColors.muted),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
      actions: [
        Stack(
          clipBehavior: Clip.none,
          children: [
            IconButton(
              icon: const Icon(Icons.notifications_none_rounded, color: AppColors.ink, size: 26),
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('No new notifications')),
                );
              },
            ),
            Positioned(
              right: 8,
              top: 8,
              child: Container(
                padding: const EdgeInsets.all(4),
                decoration: const BoxDecoration(
                  color: AppColors.red,
                  shape: BoxShape.circle,
                ),
                child: Text(
                  '3',
                  style: AppTheme.display(10, w: FontWeight.bold, c: AppColors.surface),
                ),
              ),
            ),
          ],
        ),
        Padding(
          padding: const EdgeInsets.only(right: 16, left: 4),
          child: CircleAvatar(
            radius: 17,
            backgroundColor: AppColors.redSoft,
            child: const Icon(Icons.person, color: AppColors.red, size: 22),
          ),
        ),
      ],
    );
  }
}
