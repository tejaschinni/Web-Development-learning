import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/domain/enum/seller_account_status.dart';

class SellerStatusContentCard extends StatelessWidget {
  const SellerStatusContentCard({
    super.key,
    required this.status,
    this.submittedOn,
    this.referenceId,
    this.approvedOn,
    this.sellerType,
    this.category,
    this.serviceArea,
    this.rejectionReason,
    this.suspendedReason,
    this.suspendedOn,
    this.inactiveReason,
    this.inactivatedOn,
  });

  final SellerAccountStatus status;
  final String? submittedOn;
  final String? referenceId;
  final String? approvedOn;
  final String? sellerType;
  final String? category;
  final String? serviceArea;
  final String? rejectionReason;
  final String? suspendedReason;
  final String? suspendedOn;
  final String? inactiveReason;
  final String? inactivatedOn;

  @override
  Widget build(BuildContext context) {
    switch (status) {
      case SellerAccountStatus.draft:
        return _DraftCard(
          lastSavedOn: submittedOn,
          referenceId: referenceId,
        );
      case SellerAccountStatus.submitted:
        return _SubmittedCard(
          submittedOn: submittedOn,
          referenceId: referenceId,
        );
      case SellerAccountStatus.underReview:
        return _UnderReviewStepperCard(
          submittedOn: submittedOn,
        );
      case SellerAccountStatus.approved:
        return _ApprovedCard(
          approvedOn: approvedOn,
          sellerType: sellerType,
          category: category,
          serviceArea: serviceArea,
        );
      case SellerAccountStatus.rejected:
        return _RejectedCard(
          rejectionReason: rejectionReason,
        );
      case SellerAccountStatus.suspended:
        return _SuspendedCard(
          suspendedReason: suspendedReason,
          suspendedOn: suspendedOn,
        );
      case SellerAccountStatus.inactive:
        return _InactiveCard(
          inactiveReason: inactiveReason,
          inactivatedOn: inactivatedOn,
        );
    }
  }
}

// -----------------------------------------------------------------------------
// 0. Draft Card
// -----------------------------------------------------------------------------
class _DraftCard extends StatelessWidget {
  const _DraftCard({this.lastSavedOn, this.referenceId});

  final String? lastSavedOn;
  final String? referenceId;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border),
          ),
          child: Column(
            children: [
              const _DetailRow(
                icon: Icons.edit_note_outlined,
                title: 'Application Status',
                value: 'Draft',
              ),
              const Divider(height: 24, thickness: 0.8, color: AppColors.border),
              _DetailRow(
                icon: Icons.calendar_today_outlined,
                title: 'Last Saved',
                value: lastSavedOn ?? 'Recently',
              ),
              if (referenceId != null && referenceId!.isNotEmpty) ...[
                const Divider(height: 24, thickness: 0.8, color: AppColors.border),
                _DetailRow(
                  icon: Icons.description_outlined,
                  title: 'Draft ID',
                  value: referenceId!,
                ),
              ],
            ],
          ),
        ),
        const Gap(16),
        Text(
          'Your seller application is saved as a draft.\nYou can edit, complete, and submit it when ready.',
          textAlign: TextAlign.center,
          style: AppTheme.hind(12, c: AppColors.muted, h: 1.3),
        ),
      ],
    );
  }
}

// -----------------------------------------------------------------------------
// 1. Submitted Card
// -----------------------------------------------------------------------------
class _SubmittedCard extends StatelessWidget {
  const _SubmittedCard({this.submittedOn, this.referenceId});

  final String? submittedOn;
  final String? referenceId;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border),
          ),
          child: Column(
            children: [
              _DetailRow(
                icon: Icons.calendar_today_outlined,
                title: 'Submitted On',
                value: submittedOn ?? '15 Oct 2026, 11:30 AM',
              ),
              const Divider(height: 24, thickness: 0.8, color: AppColors.border),
              const _DetailRow(
                icon: Icons.hourglass_empty_rounded,
                title: 'Current Status',
                value: 'Submitted',
              ),
              const Divider(height: 24, thickness: 0.8, color: AppColors.border),
              _DetailRow(
                icon: Icons.description_outlined,
                title: 'Reference ID',
                value: referenceId ?? 'SEVA-SELLER-10234',
              ),
            ],
          ),
        ),
        const Gap(16),
        Text(
          'We will review your details and notify you once the\nverification process is complete.',
          textAlign: TextAlign.center,
          style: AppTheme.hind(12, c: AppColors.muted, h: 1.3),
        ),
      ],
    );
  }
}

// -----------------------------------------------------------------------------
// 2. Under Review / Stepper Card
// -----------------------------------------------------------------------------
class _UnderReviewStepperCard extends StatelessWidget {
  const _UnderReviewStepperCard({this.submittedOn});

  final String? submittedOn;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border),
          ),
          child: Column(
            children: [
              _StepperStep(
                title: 'Application Submitted',
                subtitle: submittedOn ?? '15 Oct 2026, 11:30 AM',
                state: _StepState.completed,
                isLast: false,
              ),
              const _StepperStep(
                title: 'Verification Pending',
                subtitle: 'Our team is reviewing your documents.',
                state: _StepState.inProgress,
                isLast: false,
              ),
              const _StepperStep(
                title: 'Approval',
                subtitle: 'You will be notified once approved.',
                state: _StepState.pending,
                isLast: false,
              ),
              const _StepperStep(
                title: 'Start Selling',
                subtitle: 'Create your listings and start accepting orders.',
                state: _StepState.pending,
                isLast: true,
              ),
            ],
          ),
        ),
        const Gap(16),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
          decoration: BoxDecoration(
            color: AppColors.blueSoft,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const Icon(Icons.info_rounded, color: AppColors.blue, size: 20),
              const Gap(10),
              Expanded(
                child: Text(
                  'We may contact you if any additional information or documents are required.',
                  style: AppTheme.hind(12, c: AppColors.navy, h: 1.3),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// -----------------------------------------------------------------------------
// 3. Approved Card
// -----------------------------------------------------------------------------
class _ApprovedCard extends StatelessWidget {
  const _ApprovedCard({
    this.approvedOn,
    this.sellerType,
    this.category,
    this.serviceArea,
  });

  final String? approvedOn;
  final String? sellerType;
  final String? category;
  final String? serviceArea;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: [
          _DetailRow(
            icon: Icons.calendar_today_outlined,
            title: 'Approved On',
            value: approvedOn ?? '17 Oct 2026, 04:20 PM',
          ),
          const Divider(height: 20, thickness: 0.8, color: AppColors.border),
          _DetailRow(
            icon: Icons.storefront_outlined,
            title: 'Seller Type',
            value: sellerType ?? 'Home-based seller',
          ),
          const Divider(height: 20, thickness: 0.8, color: AppColors.border),
          _DetailRow(
            icon: Icons.grid_view_outlined,
            title: 'Category',
            value: category ?? 'Food, Art & Creative',
          ),
          const Divider(height: 20, thickness: 0.8, color: AppColors.border),
          _DetailRow(
            icon: Icons.location_on_outlined,
            title: 'Service Area',
            value: serviceArea ?? 'Kharadi, Pune',
          ),
        ],
      ),
    );
  }
}

// -----------------------------------------------------------------------------
// 4. Rejected Card
// -----------------------------------------------------------------------------
class _RejectedCard extends StatelessWidget {
  const _RejectedCard({this.rejectionReason});

  final String? rejectionReason;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.description_outlined, color: AppColors.red, size: 24),
              const Gap(12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Reason for Rejection',
                      style: AppTheme.hind(14, w: FontWeight.w700, c: AppColors.ink),
                    ),
                    const Gap(4),
                    Text(
                      rejectionReason ??
                          'The FSSAI certificate provided is not valid. Please upload a valid certificate and resubmit your application.',
                      style: AppTheme.hind(12.5, c: AppColors.muted, h: 1.3),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const Gap(18),
        Text(
          'What you can do next',
          style: AppTheme.hind(14.5, w: FontWeight.w700, c: AppColors.ink),
        ),
        const Gap(10),
        const _CheckItem('Review the reason for rejection'),
        const Gap(8),
        const _CheckItem('Update the required information or documents'),
        const Gap(8),
        const _CheckItem('Submit your application again'),
      ],
    );
  }
}

// -----------------------------------------------------------------------------
// 5. Suspended Card
// -----------------------------------------------------------------------------
class _SuspendedCard extends StatelessWidget {
  const _SuspendedCard({this.suspendedReason, this.suspendedOn});

  final String? suspendedReason;
  final String? suspendedOn;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border),
          ),
          child: Column(
            children: [
              _DetailRow(
                icon: Icons.warning_amber_rounded,
                iconColor: AppColors.red,
                title: 'Reason',
                value: suspendedReason ??
                    'Repeated customer complaints regarding product quality.',
              ),
              const Divider(height: 22, thickness: 0.8, color: AppColors.border),
              _DetailRow(
                icon: Icons.calendar_today_outlined,
                iconColor: AppColors.red,
                title: 'Suspended On',
                value: suspendedOn ?? '20 Oct 2026, 10:15 AM',
              ),
            ],
          ),
        ),
        const Gap(18),
        Text(
          'What you can do',
          style: AppTheme.hind(14.5, w: FontWeight.w700, c: AppColors.ink),
        ),
        const Gap(10),
        const _BulletItem('Review the reason for suspension'),
        const Gap(8),
        const _BulletItem('Contact support if you believe this is a mistake'),
        const Gap(8),
        const _BulletItem('Follow the guidelines and apply for reactivation'),
      ],
    );
  }
}

// -----------------------------------------------------------------------------
// 6. Inactive Card
// -----------------------------------------------------------------------------
class _InactiveCard extends StatelessWidget {
  const _InactiveCard({this.inactiveReason, this.inactivatedOn});

  final String? inactiveReason;
  final String? inactivatedOn;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border),
          ),
          child: Column(
            children: [
              _DetailRow(
                icon: Icons.info_outline_rounded,
                iconColor: AppColors.muted,
                title: 'Reason',
                value: inactiveReason ??
                    'You have not published any listings for a long time.',
              ),
              const Divider(height: 22, thickness: 0.8, color: AppColors.border),
              _DetailRow(
                icon: Icons.calendar_today_outlined,
                iconColor: AppColors.muted,
                title: 'Inactivated On',
                value: inactivatedOn ?? '25 Sep 2026, 09:30 AM',
              ),
            ],
          ),
        ),
        const Gap(18),
        Text(
          'What you can do',
          style: AppTheme.hind(14.5, w: FontWeight.w700, c: AppColors.ink),
        ),
        const Gap(10),
        const _BulletItem('Log in and create a new listing to activate your account'),
        const Gap(8),
        const _BulletItem('Update your profile and business details'),
        const Gap(8),
        const _BulletItem('Contact support if you need help'),
      ],
    );
  }
}

// -----------------------------------------------------------------------------
// Reusable Sub-Widgets
// -----------------------------------------------------------------------------
class _DetailRow extends StatelessWidget {
  const _DetailRow({
    required this.icon,
    required this.title,
    required this.value,
    this.iconColor = AppColors.ink,
  });

  final IconData icon;
  final String title;
  final String value;
  final Color iconColor;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 22, color: iconColor),
        const Gap(12),
        Expanded(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                title,
                style: AppTheme.hind(13.5, w: FontWeight.w600, c: AppColors.ink),
              ),
              const Gap(8),
              Flexible(
                child: Text(
                  value,
                  textAlign: TextAlign.end,
                  style: AppTheme.hind(13.5, w: FontWeight.w500, c: AppColors.muted),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

enum _StepState { completed, inProgress, pending }

class _StepperStep extends StatelessWidget {
  const _StepperStep({
    required this.title,
    required this.subtitle,
    required this.state,
    required this.isLast,
  });

  final String title;
  final String subtitle;
  final _StepState state;
  final bool isLast;

  @override
  Widget build(BuildContext context) {
    Widget iconWidget;
    switch (state) {
      case _StepState.completed:
        iconWidget = Container(
          height: 24,
          width: 24,
          decoration: const BoxDecoration(
            color: AppColors.green,
            shape: BoxShape.circle,
          ),
          child: const Icon(Icons.check_rounded, color: AppColors.surface, size: 16),
        );
        break;
      case _StepState.inProgress:
        iconWidget = Container(
          height: 24,
          width: 24,
          decoration: const BoxDecoration(
            color: AppColors.orange,
            shape: BoxShape.circle,
          ),
          child: const Icon(Icons.arrow_downward_rounded, color: AppColors.surface, size: 16),
        );
        break;
      case _StepState.pending:
        iconWidget = Container(
          height: 24,
          width: 24,
          decoration: BoxDecoration(
            color: AppColors.surface,
            shape: BoxShape.circle,
            border: Border.all(color: AppColors.border, width: 2),
          ),
        );
        break;
    }

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          children: [
            iconWidget,
            if (!isLast)
              Container(
                width: 2,
                height: 38,
                color: AppColors.border,
              ),
          ],
        ),
        const Gap(14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: AppTheme.hind(
                  14,
                  w: state == _StepState.pending ? FontWeight.w500 : FontWeight.w700,
                  c: state == _StepState.pending ? AppColors.muted : AppColors.ink,
                ),
              ),
              const Gap(2),
              Text(
                subtitle,
                style: AppTheme.hind(12, c: AppColors.muted),
              ),
              if (!isLast) const Gap(18),
            ],
          ),
        ),
      ],
    );
  }
}

class _CheckItem extends StatelessWidget {
  const _CheckItem(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Container(
          padding: const EdgeInsets.all(2),
          decoration: const BoxDecoration(
            color: AppColors.green,
            shape: BoxShape.circle,
          ),
          child: const Icon(Icons.check_rounded, color: AppColors.surface, size: 14),
        ),
        const Gap(10),
        Expanded(
          child: Text(
            text,
            style: AppTheme.hind(13.5, w: FontWeight.w500, c: AppColors.ink),
          ),
        ),
      ],
    );
  }
}

class _BulletItem extends StatelessWidget {
  const _BulletItem(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          margin: const EdgeInsets.only(top: 7),
          height: 6,
          width: 6,
          decoration: const BoxDecoration(
            color: AppColors.ink,
            shape: BoxShape.circle,
          ),
        ),
        const Gap(10),
        Expanded(
          child: Text(
            text,
            style: AppTheme.hind(13, c: AppColors.ink, h: 1.3),
          ),
        ),
      ],
    );
  }
}
