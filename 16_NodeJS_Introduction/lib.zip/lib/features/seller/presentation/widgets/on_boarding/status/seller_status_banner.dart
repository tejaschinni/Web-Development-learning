import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/domain/enum/seller_account_status.dart';

class SellerStatusBanner extends StatelessWidget {
  const SellerStatusBanner({super.key, required this.status});

  final SellerAccountStatus status;

  @override
  Widget build(BuildContext context) {
    switch (status) {
      case SellerAccountStatus.draft:
        return Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: AppColors.orangeSoft,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppColors.orange.withValues(alpha: 0.3)),
          ),
          child: Column(
            children: [
              Text(
                'Application Saved as Draft',
                style: AppTheme.hind(15, w: FontWeight.w700, c: AppColors.orange),
              ),
              const Gap(2),
              Text(
                'Your profile is saved as draft. Edit and submit when ready.',
                style: AppTheme.hind(12.5, c: AppColors.navy),
              ),
            ],
          ),
        );

      case SellerAccountStatus.submitted:
        return Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: AppColors.blueSoft,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Column(
            children: [
              Text(
                'Application Submitted',
                style: AppTheme.hind(15, w: FontWeight.w700, c: AppColors.blue),
              ),
              const Gap(2),
              Text(
                'Your details have been received.',
                style: AppTheme.hind(12.5, c: AppColors.navy),
              ),
            ],
          ),
        );

      case SellerAccountStatus.underReview:
        return Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: AppColors.orangeSoft,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(2),
                decoration: const BoxDecoration(
                  color: AppColors.orange,
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.check_rounded, color: AppColors.surface, size: 14),
              ),
              const Gap(10),
              Expanded(
                child: Text(
                  'We are verifying your documents and details. This usually takes 1–3 working days.',
                  style: AppTheme.hind(12, w: FontWeight.w500, c: AppColors.ink),
                ),
              ),
            ],
          ),
        );

      case SellerAccountStatus.approved:
        return Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
          decoration: BoxDecoration(
            color: AppColors.greenSoft,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(2),
                decoration: const BoxDecoration(
                  color: AppColors.green,
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.check_rounded, color: AppColors.surface, size: 14),
              ),
              const Gap(10),
              Expanded(
                child: Text(
                  'Your seller account has been verified and approved.',
                  style: AppTheme.hind(12.5, w: FontWeight.w600, c: AppColors.greenDeep),
                ),
              ),
            ],
          ),
        );

      case SellerAccountStatus.rejected:
        return Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: AppColors.redSoft,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(2),
                decoration: const BoxDecoration(
                  color: AppColors.red,
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.arrow_downward_rounded, color: AppColors.surface, size: 14),
              ),
              const Gap(10),
              Expanded(
                child: Text(
                  'Your application was not approved due to the reason below.',
                  style: AppTheme.hind(12, w: FontWeight.w500, c: AppColors.red),
                ),
              ),
            ],
          ),
        );

      case SellerAccountStatus.suspended:
        return Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: AppColors.peach,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(2),
                decoration: const BoxDecoration(
                  color: AppColors.orange,
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.priority_high_rounded, color: AppColors.surface, size: 14),
              ),
              const Gap(10),
              Expanded(
                child: Text(
                  'Your seller account has been suspended due to a violation of SEVA policies.',
                  style: AppTheme.hind(12, w: FontWeight.w500, c: AppColors.ink),
                ),
              ),
            ],
          ),
        );

      case SellerAccountStatus.inactive:
        return Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: AppColors.bg,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppColors.border),
          ),
          child: Center(
            child: Text(
              'Your account is inactive.',
              style: AppTheme.hind(12.5, w: FontWeight.w600, c: AppColors.ink),
            ),
          ),
        );
    }
  }
}
