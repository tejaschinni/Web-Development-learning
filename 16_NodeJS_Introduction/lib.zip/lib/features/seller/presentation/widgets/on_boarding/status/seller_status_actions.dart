import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/domain/enum/seller_account_status.dart';

class SellerStatusActions extends StatelessWidget {
  const SellerStatusActions({
    super.key,
    required this.status,
    required this.onGoToDashboard,
    this.onCreateListing,
    this.onUpdateAndResubmit,
    this.onContactSupport,
    this.onActivateAccount,
  });

  final SellerAccountStatus status;
  final VoidCallback onGoToDashboard;
  final VoidCallback? onCreateListing;
  final VoidCallback? onUpdateAndResubmit;
  final VoidCallback? onContactSupport;
  final VoidCallback? onActivateAccount;

  @override
  Widget build(BuildContext context) {
    switch (status) {
      case SellerAccountStatus.draft:
        return Column(
          children: [
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                onPressed: onUpdateAndResubmit,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.green,
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: Text(
                  'Edit / Complete Application',
                  style: AppTheme.hind(15, w: FontWeight.w700, c: AppColors.surface),
                ),
              ),
            ),
            const Gap(10),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: OutlinedButton(
                onPressed: onGoToDashboard,
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: AppColors.border, width: 1.2),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: Text(
                  'Go to Dashboard',
                  style: AppTheme.hind(15, w: FontWeight.w700, c: AppColors.ink),
                ),
              ),
            ),
          ],
        );

      case SellerAccountStatus.submitted:
        return Column(
          children: [
            if (onUpdateAndResubmit != null) ...[
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  onPressed: onUpdateAndResubmit,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.green,
                    elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                  child: Text(
                    'Edit Application',
                    style: AppTheme.hind(15, w: FontWeight.w700, c: AppColors.surface),
                  ),
                ),
              ),
              const Gap(10),
            ],
            SizedBox(
              width: double.infinity,
              height: 48,
              child: OutlinedButton(
                onPressed: onGoToDashboard,
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: AppColors.green, width: 1.2),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: Text(
                  'Go to Dashboard',
                  style: AppTheme.hind(15, w: FontWeight.w700, c: AppColors.green),
                ),
              ),
            ),
          ],
        );

      case SellerAccountStatus.underReview:
        return Column(
          children: [
            if (onUpdateAndResubmit != null) ...[
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  onPressed: onUpdateAndResubmit,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.green,
                    elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                  child: Text(
                    'Edit Application',
                    style: AppTheme.hind(15, w: FontWeight.w700, c: AppColors.surface),
                  ),
                ),
              ),
              const Gap(10),
            ],
            SizedBox(
              width: double.infinity,
              height: 48,
              child: OutlinedButton(
                onPressed: onGoToDashboard,
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: AppColors.border, width: 1.2),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: Text(
                  'Go to Dashboard',
                  style: AppTheme.hind(15, w: FontWeight.w700, c: AppColors.ink),
                ),
              ),
            ),
          ],
        );

      case SellerAccountStatus.approved:
        return Column(
          children: [
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                onPressed: onCreateListing,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.green,
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: Text(
                  'Create Your First Listing',
                  style: AppTheme.hind(15, w: FontWeight.w700, c: AppColors.surface),
                ),
              ),
            ),
            const Gap(10),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: OutlinedButton(
                onPressed: onGoToDashboard,
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: AppColors.green, width: 1.2),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: Text(
                  'Go to Seller Dashboard',
                  style: AppTheme.hind(15, w: FontWeight.w700, c: AppColors.green),
                ),
              ),
            ),
            const Gap(16),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              decoration: BoxDecoration(
                color: AppColors.greenSoft,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: AppColors.green.withValues(alpha: 0.2)),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.lightbulb_outline_rounded, color: AppColors.green, size: 20),
                  const Gap(10),
                  Expanded(
                    child: Text(
                      'You can manage multiple categories (Food and Art & Creative) under the same SEVA account.',
                      style: AppTheme.hind(11.5, c: AppColors.greenDeep, h: 1.3),
                    ),
                  ),
                ],
              ),
            ),
          ],
        );

      case SellerAccountStatus.rejected:
        return Column(
          children: [
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                onPressed: onUpdateAndResubmit,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.red,
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: Text(
                  'Update and Resubmit',
                  style: AppTheme.hind(15, w: FontWeight.w700, c: AppColors.surface),
                ),
              ),
            ),
            const Gap(10),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: OutlinedButton(
                onPressed: onGoToDashboard,
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: AppColors.border, width: 1.2),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: Text(
                  'Go to Dashboard',
                  style: AppTheme.hind(15, w: FontWeight.w700, c: AppColors.ink),
                ),
              ),
            ),
          ],
        );

      case SellerAccountStatus.suspended:
        return Column(
          children: [
            if (onUpdateAndResubmit != null) ...[
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  onPressed: onUpdateAndResubmit,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.green,
                    elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                  child: Text(
                    'Edit Application',
                    style: AppTheme.hind(15, w: FontWeight.w700, c: AppColors.surface),
                  ),
                ),
              ),
              const Gap(10),
            ],
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                onPressed: onContactSupport,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.orange,
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: Text(
                  'Contact Support',
                  style: AppTheme.hind(15, w: FontWeight.w700, c: AppColors.surface),
                ),
              ),
            ),
            const Gap(10),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: OutlinedButton(
                onPressed: onGoToDashboard,
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: AppColors.orange, width: 1.2),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: Text(
                  'Go to Dashboard',
                  style: AppTheme.hind(15, w: FontWeight.w700, c: AppColors.orange),
                ),
              ),
            ),
          ],
        );

      case SellerAccountStatus.inactive:
        return Column(
          children: [
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                onPressed: onActivateAccount,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.green,
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: Text(
                  'Activate Account',
                  style: AppTheme.hind(15, w: FontWeight.w700, c: AppColors.surface),
                ),
              ),
            ),
            const Gap(10),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: OutlinedButton(
                onPressed: onGoToDashboard,
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: AppColors.green, width: 1.2),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: Text(
                  'Go to Dashboard',
                  style: AppTheme.hind(15, w: FontWeight.w700, c: AppColors.green),
                ),
              ),
            ),
          ],
        );
    }
  }
}
