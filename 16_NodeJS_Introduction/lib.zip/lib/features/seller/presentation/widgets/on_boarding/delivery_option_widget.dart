import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:society_seva/app/theme/app_theme.dart';

enum DeliveryOption {
  pickup('PICKUP', 'Pick-up', 'Buyer will have to pick up the order', Icons.storefront_outlined),
  selfDelivery(
    'SELF_DELIVERY',
    'Self-delivery',
    'Seller will deliver the order',
    Icons.delivery_dining,
  ),
  thirdParty(
    'THIRD_PARTY',
    'Third-party delivery',
    'Delivered through a delivery partner',
    Icons.local_shipping_outlined,
  );

  const DeliveryOption(this.api, this.title, this.subtitle, this.icon);

  final String api;
  final String title;
  final String subtitle;
  final IconData icon;

  static DeliveryOption? fromApi(String v) {
    for (final o in values) {
      if (o.api == v.trim().toUpperCase()) return o;
    }
    return null;
  }
}

class DeliveryOptionsSelector extends StatelessWidget {
  final Set<DeliveryOption> selected;
  final ValueChanged<Set<DeliveryOption>> onChanged;

  const DeliveryOptionsSelector({super.key, required this.selected, required this.onChanged});

  void _toggle(DeliveryOption o) {
    final next = {...selected};
    next.contains(o) ? next.remove(o) : next.add(o);
    onChanged(next);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                'Delivery options',
                style: GoogleFonts.hind(fontSize: 15, fontWeight: FontWeight.w700),
              ),
            ),
            Text(
              'Select all that apply',
              style: GoogleFonts.hind(fontSize: 11.5, color: AppColors.green),
            ),
          ],
        ),
        const Gap(8),
        for (final o in DeliveryOption.values) ...[
          _DeliveryTile(option: o, selected: selected.contains(o), onTap: () => _toggle(o)),
          const Gap(10),
        ],
      ],
    );
  }
}

class _DeliveryTile extends StatelessWidget {
  final DeliveryOption option;
  final bool selected;
  final VoidCallback onTap;

  const _DeliveryTile({required this.option, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final showCharges = option == DeliveryOption.thirdParty && selected;

    return InkWell(
      borderRadius: BorderRadius.circular(8),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: selected ? AppColors.green.withValues(alpha: 0.06) : Colors.white,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: selected ? AppColors.green : AppColors.border,
            width: selected ? 1.5 : 1,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: AppColors.green.withValues(alpha: 0.10),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Icon(option.icon, size: 20, color: AppColors.green),
                ),
                const Gap(10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        option.title,
                        style: GoogleFonts.hind(
                          fontSize: 13,
                          fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
                        ),
                      ),
                      Text(
                        option.subtitle,
                        style: GoogleFonts.hind(fontSize: 11.5, color: AppColors.muted),
                      ),
                    ],
                  ),
                ),
                const Gap(4),
                Icon(
                  selected ? Icons.check_box : Icons.check_box_outline_blank,
                  size: 20,
                  color: selected ? AppColors.green : AppColors.muted,
                ),
              ],
            ),
            if (showCharges) ...[
              const Gap(8),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.amber.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.info_outline, size: 16, color: Colors.orange),
                    const Gap(6),
                    Expanded(
                      child: Text(
                        'Delivery charges will be applicable for third-party delivery.',
                        style: GoogleFonts.hind(fontSize: 11.5),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
