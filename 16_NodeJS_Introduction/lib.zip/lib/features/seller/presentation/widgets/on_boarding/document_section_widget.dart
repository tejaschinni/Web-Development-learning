// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:society_seva/app/theme/app_theme.dart';
// import 'package:society_seva/features/seller/domain/entities/kyc_document_entity.dart';
// import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
// import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/onboarding_section_card_widget.dart';

// class _DocSlot {
//   const _DocSlot(this.type, this.title, this.icon, {this.required = true});
//   final String type, title;
//   final IconData icon;
//   final bool required;
// }

// const _aadhaarSlot = _DocSlot('AADHAAR', 'Aadhaar card', Icons.badge_outlined);
// const _panSlot = _DocSlot('PAN', 'PAN card', Icons.credit_card_outlined);
// const _fssaiSlot = _DocSlot('FSSAI_LICENSE', 'FSSAI license', Icons.restaurant_outlined);

// String? _validateDocNumber(String type, String? v) {
//   final value = (v ?? '').trim().toUpperCase();
//   if (value.isEmpty) return 'Required';
//   switch (type) {
//     case 'AADHAAR':
//       return RegExp(r'^\d{12}$').hasMatch(value) ? null : 'Enter a 12-digit Aadhaar number';
//     case 'PAN':
//       return RegExp(r'^[A-Z]{5}[0-9]{4}[A-Z]$').hasMatch(value)
//           ? null
//           : 'Enter a valid PAN (e.g. ABCDE1234F)';
//     case 'FSSAI_LICENSE':
//       return RegExp(r'^\d{14}$').hasMatch(value) ? null : 'Enter a 14-digit FSSAI number';
//     case 'GST_CERTIFICATE':
//       return value.length == 15 ? null : 'GSTIN must be 15 characters';
//     default:
//       return null;
//   }
// }

// /// Use this in your "Submit / Next" validation.
// /// Returns titles of mandatory documents that are still missing.
// List<String> missingRequiredDocuments(
//   WidgetRef ref,
//   String sellerId, {
//   required bool isFoodSeller,
// }) {
//   final pending = ref.read(sellerFormActionProvider).pendingDocuments.map((d) => d.type).toSet();
//   final uploaded = sellerId.isEmpty
//       ? <String>{}
//       : (ref.read(sellerDocumentProvider(sellerId)).asData?.value ?? const <KycDocumentEntity>[])
//             .map((d) => d.documentType)
//             .toSet();
//   final all = {...pending, ...uploaded};
//   return [
//     _aadhaarSlot,
//     _panSlot,
//     if (isFoodSeller) _fssaiSlot,
//   ].where((s) => !all.contains(s.type)).map((s) => s.title).toList();
// }

// class _DocumentsSection extends ConsumerWidget {
//   const _DocumentsSection({required this.sellerId, required this.isFoodSeller});
//   final String sellerId;
//   final bool isFoodSeller;

//   static const _slotTypes = {'AADHAAR', 'PAN', 'FSSAI_LICENSE'};

//   Future<void> _openSheet(
//     BuildContext context, {
//     _DocSlot? slot,
//     PendingDocument? pending,
//     KycDocumentEntity? uploaded,
//   }) {
//     return showModalBottomSheet(
//       context: context,
//       isScrollControlled: true,
//       useSafeArea: true,
//       backgroundColor: Colors.white,
//       shape: const RoundedRectangleBorder(
//         borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
//       ),
//       builder: (_) =>
//           _DocumentSheet(sellerId: sellerId, slot: slot, pending: pending, uploaded: uploaded),
//     );
//   }

//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     final pendingList = ref.watch(sellerFormActionProvider.select((s) => s.pendingDocuments));
//     final uploadedList = sellerId.isEmpty
//         ? const <KycDocumentEntity>[]
//         : (ref.watch(sellerDocumentProvider(sellerId)).asData?.value ??
//               const <KycDocumentEntity>[]);

//     PendingDocument? pendingOf(String t) {
//       for (final d in pendingList) {
//         if (d.type == t) return d;
//       }
//       return null;
//     }

//     KycDocumentEntity? uploadedOf(String t) {
//       for (final d in uploadedList) {
//         if (d.documentType == t) return d;
//       }
//       return null;
//     }

//     final slots = [_aadhaarSlot, _panSlot, if (isFoodSeller) _fssaiSlot];
//     final otherPending = pendingList.where((d) => !_slotTypes.contains(d.type)).toList();
//     final otherUploaded = uploadedList.where((d) => !_slotTypes.contains(d.documentType)).toList();

//     return OnboardingSectionCardWidget(
//       color: _cardColor,
//       icon: Icons.verified_user_outlined,
//       title: 'Document Verification',
//       subtitle: 'Upload required documents (mandatory for registered categories).',
//       children: [
//         if (isFoodSeller)
//           Container(
//             margin: const EdgeInsets.only(bottom: 12),
//             padding: const EdgeInsets.all(10),
//             decoration: BoxDecoration(
//               color: Colors.white,
//               borderRadius: BorderRadius.circular(8),
//               border: Border.all(color: AppColors.border),
//             ),
//             child: Row(
//               children: [
//                 Icon(Icons.info_outline, size: 18, color: AppColors.green),
//                 const Gap(8),
//                 Expanded(
//                   child: Text(
//                     'For Food category, FSSAI license is required before you can accept orders.',
//                     style: GoogleFonts.hind(fontSize: 12),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         GridView.count(
//           crossAxisCount: 2,
//           shrinkWrap: true,
//           physics: const NeverScrollableScrollPhysics(),
//           mainAxisSpacing: 10,
//           crossAxisSpacing: 10,
//           childAspectRatio: 1.25,
//           children: [
//             for (final slot in slots)
//               Builder(
//                 builder: (context) {
//                   final p = pendingOf(slot.type);
//                   final u = uploadedOf(slot.type);
//                   return _DocTile(
//                     title: slot.title,
//                     icon: slot.icon,
//                     tag: slot.required ? 'Required' : 'Optional',
//                     uploaded: p != null || u != null,
//                     onTap: () => _openSheet(context, slot: slot, pending: p, uploaded: u),
//                   );
//                 },
//               ),
//             _DocTile(
//               title: 'Other documents',
//               icon: Icons.folder_open_outlined,
//               tag: 'Optional',
//               uploaded: false,
//               buttonLabel: 'Add',
//               onTap: () => _openSheet(context),
//             ),
//           ],
//         ),
//         if (otherPending.isNotEmpty || otherUploaded.isNotEmpty) ...[
//           const _SubHeading('Other documents'),
//           for (final d in otherPending)
//             InkWell(
//               onTap: () => _openSheet(context, pending: d),
//               child: _ItemTile(
//                 icon: Icons.description_outlined,
//                 title: _sentence(d.type),
//                 subtitle: d.number,
//                 trailing: const Icon(Icons.chevron_right),
//               ),
//             ),
//           for (final d in otherUploaded)
//             InkWell(
//               onTap: () => _openSheet(context, uploaded: d),
//               child: _ItemTile(
//                 icon: Icons.verified,
//                 iconColor: Colors.green,
//                 title: _sentence(d.documentType),
//                 subtitle: d.verificationStatus,
//                 trailing: const Icon(Icons.chevron_right),
//               ),
//             ),
//         ],
//       ],
//     );
//   }
// }

// class _DocTile extends StatelessWidget {
//   const _DocTile({
//     required this.title,
//     required this.icon,
//     required this.tag,
//     required this.uploaded,
//     required this.onTap,
//     this.buttonLabel = 'Upload',
//   });
//   final String title, tag, buttonLabel;
//   final IconData icon;
//   final bool uploaded;
//   final VoidCallback onTap;

//   @override
//   Widget build(BuildContext context) {
//     final color = uploaded ? AppColors.green : AppColors.muted;
//     return InkWell(
//       borderRadius: BorderRadius.circular(10),
//       onTap: onTap,
//       child: Container(
//         padding: const EdgeInsets.all(10),
//         decoration: BoxDecoration(
//           color: uploaded ? AppColors.green.withValues(alpha: 0.08) : Colors.white,
//           borderRadius: BorderRadius.circular(10),
//           border: Border.all(color: uploaded ? AppColors.green : AppColors.border),
//         ),
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//           children: [
//             Column(
//               children: [
//                 Icon(icon, size: 26, color: color),
//                 const Gap(4),
//                 Text(
//                   title,
//                   textAlign: TextAlign.center,
//                   maxLines: 2,
//                   overflow: TextOverflow.ellipsis,
//                   style: GoogleFonts.hind(fontSize: 12.5, fontWeight: FontWeight.w700),
//                 ),
//                 Text(
//                   tag,
//                   style: GoogleFonts.hind(
//                     fontSize: 10.5,
//                     color: tag == 'Required' ? Colors.red.shade400 : AppColors.muted,
//                   ),
//                 ),
//               ],
//             ),
//             Container(
//               height: 28,
//               alignment: Alignment.center,
//               width: double.infinity,
//               decoration: BoxDecoration(
//                 color: uploaded ? AppColors.green : Colors.transparent,
//                 borderRadius: BorderRadius.circular(6),
//                 border: Border.all(color: AppColors.green),
//               ),
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Icon(
//                     uploaded ? Icons.check_circle : Icons.add,
//                     size: 14,
//                     color: uploaded ? Colors.white : AppColors.green,
//                   ),
//                   const Gap(4),
//                   Text(
//                     uploaded ? 'Uploaded' : buttonLabel,
//                     style: GoogleFonts.hind(
//                       fontSize: 12,
//                       fontWeight: FontWeight.w600,
//                       color: uploaded ? Colors.white : AppColors.green,
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

// /// Bottom sheet: add form  OR  detail view (with delete / upload new).
// class _DocumentSheet extends ConsumerStatefulWidget {
//   const _DocumentSheet({required this.sellerId, this.slot, this.pending, this.uploaded});
//   final String sellerId;
//   final _DocSlot? slot; // null => "Other documents"
//   final PendingDocument? pending;
//   final KycDocumentEntity? uploaded;

//   @override
//   ConsumerState<_DocumentSheet> createState() => _DocumentSheetState();
// }

// class _DocumentSheetState extends ConsumerState<_DocumentSheet> {
//   final _formKey = GlobalKey<FormState>();
//   final _number = TextEditingController();
//   XFile? _file;
//   bool _editing = false;
//   late DocumentType _otherType = DocumentType.values.firstWhere(
//     (d) => !_DocumentsSection._slotTypes.contains(d.type),
//     orElse: () => DocumentType.values.first,
//   );

//   bool get _hasExisting => widget.pending != null || widget.uploaded != null;
//   bool get _showForm => !_hasExisting || _editing;
//   bool get _typeLocked => widget.slot != null || _hasExisting;

//   String get _type =>
//       widget.slot?.type ?? widget.pending?.type ?? widget.uploaded?.documentType ?? _otherType.type;

//   String get _title => widget.slot?.title ?? _sentence(_type);

//   @override
//   void dispose() {
//     _number.dispose();
//     super.dispose();
//   }

//   Future<void> _pickFile() async {
//     final source = await chooseImageSource(context);
//     if (source == null) return;
//     final file = await ImagePicker().pickImage(source: source, imageQuality: 85, maxWidth: 2000);
//     if (file == null) return;
//     setState(() => _file = file);
//   }

//   void _save() {
//     if (!(_formKey.currentState?.validate() ?? false)) return;
//     if (_file == null) {
//       _snack(context, 'Please upload the document');
//       return;
//     }
//     final notifier = ref.read(sellerFormActionProvider.notifier);
//     // "upload new" => replace the old pending one
//     if (widget.pending != null) notifier.removePendingDocument(widget.pending!);
//     notifier.addPendingDocument(
//       PendingDocument(type: _type, number: _number.text.trim().toUpperCase(), file: _file!),
//     );
//     Navigator.pop(context);
//   }

//   void _delete() {
//     ref.read(sellerFormActionProvider.notifier).removePendingDocument(widget.pending!);
//     Navigator.pop(context);
//   }

//   Future<void> _download() async {
//     try {
//       final base64File = await ref
//           .read(downloadKycDocumentFileUsecase)
//           .call(sellerId: widget.sellerId, documentFileUrl: widget.uploaded!.documentFileUrl);
//       if (!mounted) return;
//       _snack(context, 'Downloaded $_title (${base64File.length} chars, base64)');
//     } catch (e) {
//       if (!mounted) return;
//       _snack(context, 'Could not download document: $e');
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//       padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.viewInsetsOf(context).bottom),
//       child: SingleChildScrollView(
//         child: Column(
//           mainAxisSize: MainAxisSize.min,
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Row(
//               children: [
//                 Expanded(
//                   child: Text(
//                     _showForm
//                         ? (_hasExisting
//                               ? 'Upload new $_title'
//                               : 'Add $_title'.replaceFirst('Add Other', 'Add other'))
//                         : _title,
//                     style: GoogleFonts.hind(fontSize: 16, fontWeight: FontWeight.w700),
//                   ),
//                 ),
//                 IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(context)),
//               ],
//             ),
//             const Gap(8),
//             if (_showForm) _buildForm() else _buildDetails(),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _buildForm() {
//     return Form(
//       key: _formKey,
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           if (!_typeLocked) ...[
//             const LableWidget('Document type', required: true),
//             OnboardingDropdownListWidget<DocumentType>(
//               hint: 'Select document type',
//               icon: Icons.description_outlined,
//               value: _otherType,
//               items: DocumentType.values
//                   .where((d) => !_DocumentsSection._slotTypes.contains(d.type))
//                   .toList(),
//               labelBuilder: (d) => d.label,
//               onChanged: (v) => setState(() {
//                 _otherType = v ?? _otherType;
//                 _number.clear();
//               }),
//             ),
//             const Gap(12),
//           ],
//           LableWidget('$_title number', required: true),
//           TextFormField(
//             controller: _number,
//             textCapitalization: TextCapitalization.characters,
//             keyboardType: _type == 'AADHAAR' || _type == 'FSSAI_LICENSE'
//                 ? TextInputType.number
//                 : TextInputType.text,
//             validator: (v) => _validateDocNumber(_type, v),
//             style: GoogleFonts.hind(fontSize: 13),
//             decoration: InputDecoration(
//               hintText: 'Enter ${_title.toLowerCase()} number',
//               prefixIcon: const Icon(Icons.numbers),
//               isDense: true,
//               border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
//             ),
//           ),
//           const Gap(12),
//           const LableWidget('Document file', required: true),
//           _UploadTile(emptyLabel: 'Upload document', fileName: _file?.name, onTap: _pickFile),
//           const Gap(16),
//           SizedBox(
//             width: double.infinity,
//             child: FilledButton(
//               style: FilledButton.styleFrom(backgroundColor: AppColors.green),
//               onPressed: _save,
//               child: Text(
//                 _hasExisting ? 'Replace document' : 'Save document',
//                 style: GoogleFonts.hind(),
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildDetails() {
//     final p = widget.pending;
//     final u = widget.uploaded;
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         if (p != null)
//           ClipRRect(
//             borderRadius: BorderRadius.circular(8),
//             child: Image.file(
//               File(p.file.path),
//               height: 180,
//               width: double.infinity,
//               fit: BoxFit.cover,
//               errorBuilder: (_, __, ___) => Container(
//                 height: 120,
//                 color: Colors.black12,
//                 alignment: Alignment.center,
//                 child: const Icon(Icons.insert_drive_file_outlined, size: 40),
//               ),
//             ),
//           ),
//         const Gap(12),
//         _detailRow('Type', _sentence(_type)),
//         if (p != null) ...[
//           _detailRow('Number', p.number),
//           _detailRow('File', p.file.name),
//           _detailRow('Status', 'Not submitted yet'),
//         ],
//         if (u != null) _detailRow('Status', u.verificationStatus),
//         const Gap(16),
//         Row(
//           children: [
//             if (p != null)
//               Expanded(
//                 child: OutlinedButton.icon(
//                   style: OutlinedButton.styleFrom(
//                     foregroundColor: Colors.red,
//                     side: const BorderSide(color: Colors.red),
//                   ),
//                   onPressed: _delete,
//                   icon: const Icon(Icons.delete_outline),
//                   label: Text('Delete', style: GoogleFonts.hind()),
//                 ),
//               ),
//             if (u != null && p == null)
//               Expanded(
//                 child: OutlinedButton.icon(
//                   onPressed: _download,
//                   icon: const Icon(Icons.download_outlined),
//                   label: Text('Download', style: GoogleFonts.hind()),
//                 ),
//               ),
//             const Gap(10),
//             Expanded(
//               child: FilledButton.icon(
//                 style: FilledButton.styleFrom(backgroundColor: AppColors.green),
//                 onPressed: () => setState(() => _editing = true),
//                 icon: const Icon(Icons.upload_file_outlined),
//                 label: Text('Upload new', style: GoogleFonts.hind()),
//               ),
//             ),
//           ],
//         ),
//       ],
//     );
//   }

//   Widget _detailRow(String k, String v) => Padding(
//     padding: const EdgeInsets.symmetric(vertical: 3),
//     child: Row(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         SizedBox(
//           width: 80,
//           child: Text(k, style: GoogleFonts.hind(fontSize: 12, color: AppColors.muted)),
//         ),
//         Expanded(
//           child: Text(v, style: GoogleFonts.hind(fontSize: 13, fontWeight: FontWeight.w600)),
//         ),
//       ],
//     ),
//   );
// }
