import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/domain/enum/seller_account_status.dart';

class SellerStatusGraphic extends StatelessWidget {
  const SellerStatusGraphic({super.key, required this.status});

  final SellerAccountStatus status;

  @override
  Widget build(BuildContext context) {
    switch (status) {
      case SellerAccountStatus.draft:
      case SellerAccountStatus.submitted:
        return const _SubmittedGraphic();
      case SellerAccountStatus.underReview:
        return const _UnderReviewGraphic();
      case SellerAccountStatus.approved:
        return const _ApprovedGraphic();
      case SellerAccountStatus.rejected:
        return const _RejectedGraphic();
      case SellerAccountStatus.suspended:
        return const _SuspendedGraphic();
      case SellerAccountStatus.inactive:
        return const _InactiveGraphic();
    }
  }
}

class _SubmittedGraphic extends StatelessWidget {
  const _SubmittedGraphic();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 140,
      width: 140,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            height: 120,
            width: 120,
            decoration: const BoxDecoration(
              color: AppColors.blueSoft,
              shape: BoxShape.circle,
            ),
          ),
          Positioned(top: 15, left: 20, child: _dot(AppColors.red, 6)),
          Positioned(top: 45, left: 10, child: _dot(AppColors.blue, 7)),
          Positioned(top: 18, right: 25, child: _dot(AppColors.orange, 6)),
          Positioned(top: 55, right: 12, child: _dot(AppColors.green, 7)),
          Positioned(bottom: 24, left: 15, child: _dot(AppColors.orange, 5)),
          Positioned(bottom: 18, right: 28, child: _dot(AppColors.red, 6)),
          Container(
            width: 62,
            height: 78,
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppColors.blue, width: 2),
              boxShadow: [
                BoxShadow(
                  color: AppColors.shadow,
                  blurRadius: 8,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _line(28, AppColors.blue),
                const Gap(6),
                _line(38, AppColors.blue),
                const Gap(6),
                _line(30, AppColors.blue),
              ],
            ),
          ),
          Positioned(
            right: 26,
            bottom: 22,
            child: Container(
              height: 38,
              width: 38,
              decoration: BoxDecoration(
                color: AppColors.green,
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.surface, width: 2.5),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.green.withValues(alpha: 0.3),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: const Icon(Icons.check_rounded, color: AppColors.surface, size: 24),
            ),
          ),
        ],
      ),
    );
  }
}

class _UnderReviewGraphic extends StatelessWidget {
  const _UnderReviewGraphic();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 140,
      width: 140,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            height: 120,
            width: 120,
            decoration: const BoxDecoration(
              color: AppColors.orangeSoft,
              shape: BoxShape.circle,
            ),
          ),
          Positioned(top: 20, left: 18, child: _dot(AppColors.orange, 5)),
          Positioned(top: 15, right: 25, child: _dot(AppColors.green, 6)),
          Positioned(bottom: 25, left: 16, child: _dot(AppColors.blue, 5)),
          Positioned(bottom: 20, right: 20, child: _dot(AppColors.orange, 6)),
          Container(
            width: 62,
            height: 78,
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppColors.border, width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: AppColors.shadow,
                  blurRadius: 8,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.account_box_outlined, size: 20, color: AppColors.orange),
                    const Gap(4),
                    _line(18, AppColors.muted),
                  ],
                ),
                const Gap(8),
                _line(38, AppColors.muted),
                const Gap(5),
                _line(32, AppColors.muted),
                const Gap(5),
                _line(22, AppColors.muted),
              ],
            ),
          ),
          Positioned(
            right: 20,
            bottom: 22,
            child: Transform.rotate(
              angle: -0.2,
              child: const Icon(
                Icons.search_rounded,
                size: 46,
                color: AppColors.navy,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ApprovedGraphic extends StatelessWidget {
  const _ApprovedGraphic();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 130,
      width: 130,
      child: Center(
        child: CustomPaint(
          size: const Size(100, 100),
          painter: const _ScallopedBadgePainter(color: AppColors.green),
          child: const SizedBox(
            height: 100,
            width: 100,
            child: Center(
              child: Icon(Icons.check_rounded, color: AppColors.surface, size: 54),
            ),
          ),
        ),
      ),
    );
  }
}

class _RejectedGraphic extends StatelessWidget {
  const _RejectedGraphic();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 140,
      width: 140,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            height: 120,
            width: 120,
            decoration: const BoxDecoration(
              color: AppColors.redSoft,
              shape: BoxShape.circle,
            ),
          ),
          Container(
            width: 62,
            height: 78,
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppColors.blue, width: 1.8),
              boxShadow: [
                BoxShadow(
                  color: AppColors.shadow,
                  blurRadius: 8,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _line(28, AppColors.blue),
                const Gap(6),
                _line(38, AppColors.blue),
                const Gap(6),
                _line(30, AppColors.blue),
              ],
            ),
          ),
          Positioned(
            right: 26,
            bottom: 22,
            child: Container(
              height: 38,
              width: 38,
              decoration: BoxDecoration(
                color: AppColors.red,
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.surface, width: 2.5),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.red.withValues(alpha: 0.3),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: const Icon(Icons.close_rounded, color: AppColors.surface, size: 24),
            ),
          ),
        ],
      ),
    );
  }
}

class _SuspendedGraphic extends StatelessWidget {
  const _SuspendedGraphic();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 140,
      width: 140,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            height: 120,
            width: 120,
            decoration: const BoxDecoration(
              color: AppColors.peach,
              shape: BoxShape.circle,
            ),
          ),
          Container(
            height: 82,
            width: 82,
            decoration: BoxDecoration(
              color: AppColors.red,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: AppColors.red.withValues(alpha: 0.25),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Center(
              child: Container(
                height: 12,
                width: 44,
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(6),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _InactiveGraphic extends StatelessWidget {
  const _InactiveGraphic();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 140,
      width: 140,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            height: 120,
            width: 120,
            decoration: const BoxDecoration(
              color: AppColors.bg,
              shape: BoxShape.circle,
            ),
          ),
          SizedBox(
            height: 74,
            width: 74,
            child: Stack(
              children: [
                const Center(
                  child: Icon(
                    Icons.account_circle,
                    size: 74,
                    color: AppColors.muted,
                  ),
                ),
                Positioned(
                  right: 0,
                  bottom: 0,
                  child: Container(
                    padding: const EdgeInsets.all(2),
                    decoration: const BoxDecoration(
                      color: AppColors.surface,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.pause_circle_filled_rounded,
                      size: 28,
                      color: AppColors.ink,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

Widget _dot(Color color, double size) {
  return Container(
    height: size,
    width: size,
    decoration: BoxDecoration(color: color, shape: BoxShape.circle),
  );
}

Widget _line(double width, Color color) {
  return Container(
    height: 3,
    width: width,
    decoration: BoxDecoration(
      color: color,
      borderRadius: BorderRadius.circular(2),
    ),
  );
}

class _ScallopedBadgePainter extends CustomPainter {
  const _ScallopedBadgePainter({required this.color});
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;

    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;
    const points = 16;
    final path = Path();

    for (int i = 0; i < points; i++) {
      final angle = (i * 2 * math.pi) / points;
      final waveRadius = radius - ((i % 2 == 0) ? 0 : 5);
      final x = center.dx + waveRadius * math.cos(angle);
      final y = center.dy + waveRadius * math.sin(angle);
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    path.close();

    canvas.drawShadow(path, color.withValues(alpha: 0.3), 6, true);
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _ScallopedBadgePainter oldDelegate) =>
      oldDelegate.color != color;
}
