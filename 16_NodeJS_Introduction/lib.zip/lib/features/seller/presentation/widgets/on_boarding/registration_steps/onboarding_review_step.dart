import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/profile/presentation/providers/profile_provider.dart';
import 'package:society_seva/features/seller/domain/entities/certificate_entity.dart';
import 'package:society_seva/features/seller/domain/entities/kyc_document_entity.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/image_grid_widget.dart';
import 'package:society_seva/features/seller/presentation/widgets/on_boarding/shared/onboarding_availablitiy_step.dart';

class ReviewStepTargets {
  static const basic = 0;
  static const sellerType = 1;
  static const address = 2;
  static const availability = 1;
  static const media = 3; // photos + documents + certificates
}

class OnboardingReviewStep extends ConsumerWidget {
  const OnboardingReviewStep({
    super.key,
    required this.s,
    required this.sellerType,
    required this.sellerId,
    required this.onEdit,
  });

  final SellerRegState s;
  final List<String> sellerType;
  final String sellerId;
  final ValueChanged<int> onEdit;

  static const _foodType = 'FOOD_SELLER';
  static final _dateFormat = DateFormat('dd MMM yyyy');

  static List<String> missingFields(SellerRegState s, List<String> sellerTypes) {
    final m = <String>[];
    if (s.fullName.trim().isEmpty) m.add('Display name');
    if (s.businessName.trim().isEmpty) m.add('Business name');
    if (sellerTypes.isEmpty) m.add('Seller category');
    if ((sellerTypes.contains(_foodType) || s.hasFssai == true) &&
        s.fssaiCertificateId.trim().isEmpty) {
      m.add('FSSAI / license number');
    }
    if (s.pickupAddress.trim().isEmpty) m.add('Address');
    if (s.city.trim().isEmpty) m.add('City');
    return m;
  }

  static String _or(String? v) => (v == null || v.trim().isEmpty) ? '—' : v.trim();
  static String _sentence(String value) {
    final t = value.toLowerCase().replaceAll('_', ' ');
    return t.isEmpty ? t : '${t[0].toUpperCase()}${t.substring(1)}';
  }

  static String _sentenceList(List<String> values, {String separator = ', '}) =>
      values.where((v) => v.trim().isNotEmpty).map(_sentence).join(separator);

  static String _sellerKindLabel(SellerKind? kind) {
    if (kind == null) return '—';
    switch (kind) {
      case SellerKind.individual:
        return 'Individual / Home-based';
      case SellerKind.smallBusiness:
        return 'Small business / Shop';
      case SellerKind.registered:
        return 'Registered business';
      case SellerKind.artist:
        return 'Artist / Creator';
      case SellerKind.workshop:
        return 'Workshop / Class provider';
    }
  }

  /// Show only the last 4 characters of a document number.
  static String _mask(String n) {
    final v = n.trim();
    if (v.length <= 4) return v;
    return '${'•' * (v.length - 4)}${v.substring(v.length - 4)}';
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final missing = missingFields(s, sellerType);
    final userProfile = ref.watch(profileControllerProvider).profile;
    final formState = ref.watch(sellerFormActionProvider);
    final availability = formState.availability;
    final pendingImages = formState.queuedImages;

    final pendingDocs = formState.pendingDocuments;
    final pendingCerts = formState.pendingCertificates;
    final AsyncValue<List<KycDocumentEntity>>? uploadedDocs = sellerId == ''
        ? null
        : ref.watch(sellerDocumentProvider(sellerId));
    final AsyncValue<List<CertificateEntity>>? uploadedCerts = sellerId == ''
        ? null
        : ref.watch(sellerCertificatesProvider(sellerId));

    final displayName = s.fullName.isNotEmpty ? s.fullName : (userProfile?.fullName ?? '');

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _Banner(missing: missing),
        if (missing.isNotEmpty) const Gap(12),

        _ReviewCard(
          icon: Icons.person,
          title: 'Basic details',
          onEdit: () => onEdit(ReviewStepTargets.basic),
          children: [
            _Row('Display name', _or(displayName)),
            _Row('Business name', _or(s.businessName)),
            if (s.sellerKind != null) _Row('Business type', _sellerKindLabel(s.sellerKind)),
            _Row('Bio', _or(s.description)),
          ],
        ),
        const Gap(12),

        _ReviewCard(
          icon: Icons.storefront,
          title: 'Seller type & business',
          onEdit: () => onEdit(ReviewStepTargets.sellerType),
          children: [
            _Row('Seller type', sellerType.isEmpty ? '—' : _sentenceList(sellerType)),
            if (sellerType.contains(_foodType) || s.hasFssai == true)
              _Row('FSSAI / license', _or(s.fssaiCertificateId))
            else if (s.hasFssai == false)
              const _Row('FSSAI / license', 'Not applicable')
            else
              const _Row('FSSAI / license', '—'),
            _Row('Website', _or(s.websiteUrl)),
            _Row('Social links', _or(s.socialMediaLinks)),
            _Row('Legal compliance', _or(s.legalCompliance)),
          ],
        ),
        const Gap(12),

        _ReviewCard(
          icon: Icons.location_on,
          title: 'Address & service area',
          onEdit: () => onEdit(ReviewStepTargets.address),
          children: [
            _Row('Address', _or(s.pickupAddress)),
            _Row('City', _or(s.city)),
            _Row('State', _or(s.stateName)),
            _Row('Country', _or(s.country)),
            _Row('Pin code', _or(s.pinCode)),
            _Row('Locality', _or(s.locality)),
            _Row('Service radius', s.radius.isEmpty ? '—' : '${s.radius} km'),
            if (s.latitude != null && s.longitude != null && !(s.latitude == 0 && s.longitude == 0))
              _Row(
                'Coordinates',
                '${s.latitude!.toStringAsFixed(4)}, ${s.longitude!.toStringAsFixed(4)}',
              ),
          ],
        ),
        const Gap(12),

        _ReviewCard(
          icon: Icons.schedule,
          title: 'Availability',
          onEdit: () => onEdit(ReviewStepTargets.availability),
          children: [
            _Row('Schedule type', _sentence(availability.daysType.name)),
            const Gap(4),
            const _Label('Active days'),
            const Gap(6),
            availability.days.isEmpty
                ? const _Value('—')
                : Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: [
                      for (final d in kWeekDays)
                        if (availability.days.contains(d))
                          _Chip(d[0] + d.substring(1, 3).toLowerCase()),
                    ],
                  ),
            const Gap(8),
            _Row(
              'Hours',
              '${formatApiTime(availability.from)} – ${formatApiTime(availability.to)}',
            ),
          ],
        ),
        const Gap(12),

        _ReviewCard(
          icon: Icons.photo_library_outlined,
          title: 'Photos',
          onEdit: () => onEdit(ReviewStepTargets.media),
          children: [
            if (pendingImages.isNotEmpty) ...[
              _Row('Pending photos', '${pendingImages.length} photo(s) to upload'),
              const Gap(8),
            ],
            ImageGridWidget(sellerId: sellerId),
          ],
        ),
        const Gap(12),

        _ReviewCard(
          icon: Icons.badge_outlined,
          title: 'Documents',
          onEdit: () => onEdit(ReviewStepTargets.media),
          children: [
            if (pendingDocs.isEmpty && (uploadedDocs?.valueOrNull?.isEmpty ?? true))
              const _Value('No documents added'),
            for (final d in pendingDocs)
              _ListLine(
                icon: Icons.description_outlined,
                title: _sentence(d.type),
                subtitle: _mask(d.number),
                badge: 'To upload',
              ),
            if (uploadedDocs != null)
              ...?uploadedDocs.valueOrNull?.map(
                (d) => _ListLine(
                  icon: Icons.verified,
                  iconColor: Colors.green,
                  title: _sentence(d.documentType),
                  subtitle: d.verificationStatus,
                ),
              ),
          ],
        ),
        const Gap(12),

        _ReviewCard(
          icon: Icons.workspace_premium_outlined,
          title: 'Certificates',
          onEdit: () => onEdit(ReviewStepTargets.media),
          children: [
            if (pendingCerts.isEmpty && (uploadedCerts?.valueOrNull?.isEmpty ?? true))
              const _Value('No certificates added'),
            for (final c in pendingCerts)
              _ListLine(
                icon: Icons.verified_outlined,
                title: c.name,
                subtitle: c.hasExpiry && c.expiryDate != null
                    ? 'Issued ${_dateFormat.format(c.issueDate)} · Expires ${_dateFormat.format(c.expiryDate!)}'
                    : 'Issued ${_dateFormat.format(c.issueDate)} · No expiry',
                badge: 'To upload',
              ),
            if (uploadedCerts != null)
              ...?uploadedCerts.valueOrNull?.map(
                (c) => _ListLine(
                  icon: Icons.verified,
                  iconColor: Colors.green,
                  title: c.certificateName,
                ),
              ),
          ],
        ),
        const Gap(12),

        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: AppColors.green.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(Icons.info_outline, size: 16, color: AppColors.green),
              const Gap(8),
              Expanded(
                child: Text(
                  'You can save as draft and finish later. After you submit, your account '
                  'will be reviewed and you will be notified about the status.',
                  style: GoogleFonts.hind(fontSize: 11, color: AppColors.green),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ───────────────────────── building blocks ─────────────────────────

class _Banner extends StatelessWidget {
  const _Banner({required this.missing});
  final List<String> missing;

  @override
  Widget build(BuildContext context) {
    if (missing.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: AppColors.green.withValues(alpha: 0.12),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          children: [
            Icon(Icons.check_circle, size: 18, color: AppColors.green),
            const Gap(8),
            Expanded(
              child: Text(
                'All required details are filled. Review and submit.',
                style: GoogleFonts.hind(fontSize: 12, color: AppColors.green),
              ),
            ),
          ],
        ),
      );
    }
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.red.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.red.withValues(alpha: 0.4)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.error_outline, size: 18, color: Colors.red),
          const Gap(8),
          Expanded(
            child: Text(
              'Still required: ${missing.join(', ')}',
              style: GoogleFonts.hind(fontSize: 12, color: Colors.red.shade800),
            ),
          ),
        ],
      ),
    );
  }
}

class _ReviewCard extends StatelessWidget {
  const _ReviewCard({
    required this.icon,
    required this.title,
    required this.onEdit,
    required this.children,
  });
  final IconData icon;
  final String title;
  final VoidCallback onEdit;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 14,
                backgroundColor: AppColors.green,
                child: Icon(icon, size: 15, color: Colors.white),
              ),
              const Gap(10),
              Expanded(
                child: Text(
                  title,
                  style: GoogleFonts.hind(fontSize: 14, fontWeight: FontWeight.w700),
                ),
              ),
              TextButton.icon(
                onPressed: onEdit,
                icon: const Icon(Icons.edit_outlined, size: 14),
                label: Text('Edit', style: GoogleFonts.hind(fontSize: 12)),
                style: TextButton.styleFrom(
                  foregroundColor: AppColors.green,
                  visualDensity: VisualDensity.compact,
                ),
              ),
            ],
          ),
          const Divider(height: 16),
          ...children,
        ],
      ),
    );
  }
}

class _Label extends StatelessWidget {
  const _Label(this.text);
  final String text;
  @override
  Widget build(BuildContext context) =>
      Text(text, style: GoogleFonts.hind(fontSize: 12, color: AppColors.muted));
}

class _Value extends StatelessWidget {
  const _Value(this.text);
  final String text;
  @override
  Widget build(BuildContext context) => Text(text, style: GoogleFonts.hind(fontSize: 13));
}

class _Row extends StatelessWidget {
  const _Row(this.label, this.value);
  final String label, value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(width: 110, child: _Label(label)),
          Expanded(child: _Value(value)),
        ],
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  const _Chip(this.text);
  final String text;
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
    decoration: BoxDecoration(
      color: AppColors.green.withValues(alpha: 0.12),
      borderRadius: BorderRadius.circular(12),
    ),
    child: Text(
      text,
      style: GoogleFonts.hind(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.green),
    ),
  );
}

class _ListLine extends StatelessWidget {
  const _ListLine({
    required this.icon,
    required this.title,
    this.subtitle,
    this.badge,
    this.iconColor,
  });
  final IconData icon;
  final Color? iconColor;
  final String title;
  final String? subtitle, badge;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          Icon(icon, size: 20, color: iconColor ?? AppColors.muted),
          const Gap(10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: GoogleFonts.hind(fontSize: 13, fontWeight: FontWeight.w600)),
                if (subtitle != null && subtitle!.isNotEmpty)
                  Text(subtitle!, style: GoogleFonts.hind(fontSize: 11, color: AppColors.muted)),
              ],
            ),
          ),
          if (badge != null)
            Text(badge!, style: GoogleFonts.hind(fontSize: 10, color: AppColors.muted)),
        ],
      ),
    );
  }
}
