import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_listing_provider.dart';
import 'package:society_seva/features/seller/presentation/widgets/listing/listing_form_widgets.dart';

class ListingAdditionalInfoStep extends ConsumerWidget {
  const ListingAdditionalInfoStep({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final type = ref.watch(productListingProvider.select((s) => s.listingType));
    final s = ref.watch(productListingProvider);
    final n = ref.read(productListingProvider.notifier);
    final c = n.controllers;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
      children: [
        StepHeader(
          title: type.isFood ? 'Food Details' : 'Additional Details',
          subtitle: type.isFood
              ? 'Tell buyers about the dish and its serving sizes'
              : type.isService
              ? 'Tell buyers how your service works'
              : 'A few more details about your listing',
        ),
        if (type.isFood)
          const _FoodForm()
        else if (type.isService)
          const _ServiceForm()
        else
          const InfoBanner(
            'No additional details are needed for this listing type. '
            'Tap Next to add photos.',
          ),
        const Gap(8),
        const Text(
          'Tags (Buyer Search keywords)',
          style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.ink),
        ),
        const Gap(8),

        if (s.tags.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Wrap(
              spacing: 8,
              runSpacing: 6,
              children: s.tags.map((tag) {
                return Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: const Color(0xFFEFF8FF),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFFB2DDFF)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        tag,
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                          color: Color(0xFF175CD3),
                        ),
                      ),
                      const SizedBox(width: 4),
                      InkWell(
                        onTap: () => n.removeTag(tag),
                        child: const Icon(Icons.close, size: 14, color: Color(0xFF175CD3)),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
          ),

        TextField(
          controller: c.tagInput,
          onSubmitted: (_) => n.addTagsFromInput,
          style: const TextStyle(fontSize: 13, color: AppColors.ink),
          decoration: InputDecoration(
            hintText: 'Add tag',
            hintStyle: const TextStyle(color: AppColors.muted, fontSize: 13),
            suffixIcon: IconButton(
              icon: const Icon(Icons.add, color: AppColors.green),
              onPressed: n.addTagsFromInput,
            ),
            filled: true,
            fillColor: Colors.white,
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: AppColors.border),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: AppColors.green, width: 1.5),
            ),
          ),
        ),
      ],
    );
  }
}

class _FoodForm extends ConsumerWidget {
  const _FoodForm();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(productListingProvider);
    final n = ref.read(productListingProvider.notifier);
    final c = n.controllers;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: FormTextField(
                label: 'Preparation time (min)',
                controller: c.prepTime,
                required: true,
                hint: 'e.g. 20',
                keyboardType: TextInputType.number,
                inputFormatters: digitsOnly,
              ),
            ),
          ],
        ),
        FormTextField(
          label: 'Ingredients',
          controller: c.ingredients,
          required: true,
          maxLines: 3,
          hint: 'Wheat flour, rice, dal, seasonal vegetables, spices, etc.',
        ),

        _FoodSpecificSection(),
        const Gap(16),
        FormTextField(
          label: 'Allergens (optional)',
          controller: c.allergens,
          hint: 'e.g. nuts, gluten, dairy',
        ),
        // DropdownField(
        //   label: 'Spice level',
        //   value: s.spiceLevel,
        //   items: {for (final k in kSpiceLevels.keys) k: k.replaceAll('_', ' ')},
        //   onChanged: n.setSpiceLevel,
        SpiceLeveDropdownField(
          label: 'Spice level',
          value: s.spiceLevel,
          items: {
            for (final k in kSpiceLevels.keys)
              k: k.split('_').map((w) => w[0] + w.substring(1).toLowerCase()).join(' '),
          },
          indicatorBuilder: (k) => SpiceLevelIndicator(apiValue: k, size: 15),
          onChanged: n.setSpiceLevel,
        ),
        FormTextField(
          label: 'Freshness declaration',
          controller: c.freshness,
          hint: 'e.g. Freshly prepared on order',
          required: true,
        ),
        SwitchRow(title: 'Frozen item', value: s.frozen, onChanged: n.setFrozen),
        FormTextField(
          label: 'Storage instructions (optional)',
          controller: c.storage,
          hint: 'e.g. Consume within 4 hours',
        ),
        FormTextField(
          label: 'Packaging details (optional)',
          controller: c.packaging,
          hint: 'e.g. Eco-friendly container',
        ),
        _ExpiryPicker(value: s.expiryTime, onChanged: n.setExpiry),
        SwitchRow(
          title: 'FSSAI license required',
          value: s.fssaiRequired,
          onChanged: n.setFssaiRequired,
        ),
        if (s.fssaiRequired)
          FormTextField(label: 'FSSAI certificate ID', controller: c.fssaiId, required: true),
      ],
    );
  }
}

class SpiceLevelIndicator extends StatelessWidget {
  const SpiceLevelIndicator({super.key, required this.apiValue, this.size = 16});

  final String apiValue;
  final double size;

  static const _colors = <String, Color>{
    'MILD': AppColors.green, // green
    'MEDIUM': AppColors.orange, // amber
    'HOT': Color(0xFFF4511E), // deep orange
    'EXTRA_HOT': Color(0xFFC62828), // red
  };

  @override
  Widget build(BuildContext context) {
    final level = kSpiceLevels[apiValue];
    if (level == null) return const SizedBox.shrink();

    if (level == 0) {
      return Icon(Icons.block, size: size, color: Colors.grey);
    }

    final color = _colors[apiValue] ?? Colors.orange;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (int i = 0; i < 5; i++)
          Icon(
            Icons.local_fire_department,
            size: size,
            color: i < level ? color : Colors.grey.shade300,
          ),
      ],
    );
  }
}

class SpiceLeveDropdownField extends StatelessWidget {
  const SpiceLeveDropdownField({
    super.key,
    required this.label,
    required this.value,
    required this.items,
    required this.onChanged,
    this.required = false,
    this.indicatorBuilder,
  });

  final String label;
  final String value;
  final Map<String, String> items; // apiValue -> label
  final ValueChanged<String> onChanged;
  final bool required;
  final Widget Function(String apiValue)? indicatorBuilder;

  @override
  Widget build(BuildContext context) {
    final current = value.trim();

    String? selected;
    for (final k in items.keys) {
      if (k.trim().toLowerCase() == current.toLowerCase()) {
        selected = k;
        break;
      }
    }

    final options = <String, String>{
      if (selected == null && current.isNotEmpty) current: current,
      ...items,
    };
    if (selected == null && current.isNotEmpty) selected = current;

    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Label + indicator for the currently selected value
          Row(
            children: [
              FieldLabel(label, required: required),
              if (indicatorBuilder != null && selected != null) ...[
                const Gap(8),
                indicatorBuilder!(selected),
              ],
            ],
          ),
          const Gap(6),
          DropdownButtonFormField<String>(
            key: ValueKey(selected),
            initialValue: selected,
            isExpanded: true,
            style: const TextStyle(fontSize: 14, color: Color(0xFF1F2A3C)),
            decoration: listingInputDecoration(),
            items: [
              for (final e in options.entries)
                DropdownMenuItem(
                  value: e.key,
                  child: Text(e.value, overflow: TextOverflow.ellipsis),
                ),
            ],
            onChanged: (v) {
              if (v != null) onChanged(v);
            },
          ),
        ],
      ),
    );
  }
}

class _ExpiryPicker extends StatelessWidget {
  const _ExpiryPicker({required this.value, required this.onChanged});
  final DateTime? value;
  final ValueChanged<DateTime?> onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const FieldLabel('Expiry (optional)'),
          const Gap(6),
          InkWell(
            borderRadius: BorderRadius.circular(8),
            onTap: () async {
              final now = DateTime.now();
              final d = await showDatePicker(
                context: context,
                initialDate: value ?? now,
                firstDate: now,
                lastDate: now.add(const Duration(days: 365)),
              );
              if (d != null) onChanged(d);
            },
            child: InputDecorator(
              decoration: listingInputDecoration().copyWith(
                suffixIcon: value == null
                    ? const Icon(Icons.calendar_today, size: 18)
                    : IconButton(
                        icon: const Icon(Icons.close, size: 18),
                        onPressed: () => onChanged(null),
                      ),
              ),
              child: Text(
                value == null ? 'Not set' : ymd(value!),
                style: TextStyle(fontSize: 14, color: value == null ? AppColors.muted : null),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _FoodSpecificSection extends ConsumerWidget {
  const _FoodSpecificSection();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(productListingProvider);
    final n = ref.read(productListingProvider.notifier);
    final c = n.controllers;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Food Specific Information',
          style: AppTheme.display(14, w: FontWeight.w600, c: AppColors.ink),
        ),
        const Gap(10),

        _FoodCheckboxTile(
          label: 'Contains Onion',
          value: s.containsOnion,
          onChanged: n.setContainsOnion,
        ),
        _FoodCheckboxTile(
          label: 'Contains Garlic',
          value: s.containsGarlic,
          onChanged: n.setContainsGarlic,
        ),
        _FoodCheckboxTile(
          label: 'Jain Food Available',
          value: s.jainFoodAvailable,
          onChanged: n.setJainFoodAvailable,
        ),
        _FoodCheckboxTile(label: 'Gluten Free', value: s.glutenFree, onChanged: n.setGlutenFree),
        _FoodCheckboxTile(
          label: 'Other (please specify)',
          value: s.otherDietary,
          onChanged: n.setOtherDietary,
        ),
        const Gap(6),

        TextField(
          controller: c.otherDietary,
          onTap: () {
            if (!s.otherDietary) n.setOtherDietary(true);
          },
          onChanged: (text) {
            if (text.isNotEmpty && !s.otherDietary) {
              n.setOtherDietary(true);
            }
          },
          onSubmitted: (text) {
            final trimmed = text.trim();
            if (trimmed.isNotEmpty) {
              n.addTag(trimmed);
              c.otherDietary.clear();
            }
          },
          style: const TextStyle(fontSize: 13, color: AppColors.ink),
          decoration: InputDecoration(
            hintText: 'e.g. No dairy, no nuts, etc.',
            hintStyle: const TextStyle(color: Color(0xFF98A2B3), fontSize: 13),
            filled: true,
            fillColor: Colors.white,
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: Color(0xFFD0D5DD)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: Color(0xFF12B76A), width: 1.5),
            ),
          ),
        ),
      ],
    );
  }
}

class _FoodCheckboxTile extends StatelessWidget {
  const _FoodCheckboxTile({required this.label, required this.value, required this.onChanged});

  final String label;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => onChanged(!value),
      borderRadius: BorderRadius.circular(6),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(
          children: [
            Container(
              width: 20,
              height: 20,
              decoration: BoxDecoration(
                color: value ? AppColors.green : Colors.white,
                borderRadius: BorderRadius.circular(4),
                border: Border.all(color: value ? AppColors.green : AppColors.ink, width: 1.5),
              ),
              child: value ? const Icon(Icons.check, size: 14, color: Colors.white) : null,
            ),
            const Gap(10),
            Text(
              label,
              style: AppTheme.hind(14, w: FontWeight.w500, c: AppColors.ink),
            ),
          ],
        ),
      ),
    );
  }
}

class _ServiceForm extends ConsumerWidget {
  const _ServiceForm();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(productListingProvider);
    final n = ref.read(productListingProvider.notifier);
    final c = n.controllers;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        FormTextField(
          label: 'Duration (minutes)',
          controller: c.duration,
          required: true,
          hint: 'e.g. 90',
          keyboardType: TextInputType.number,
          inputFormatters: digitsOnly,
        ),
        DropdownField(
          label: 'Service location',
          value: s.locationType,
          items: kLocationTypes,
          onChanged: n.setLocationType,
          required: true,
        ),
        SwitchRow(title: 'Home visit available', value: s.homeVisit, onChanged: n.setHomeVisit),
        SwitchRow(title: 'Online available', value: s.online, onChanged: n.setOnline),
        SwitchRow(
          title: 'Certificate required',
          value: s.certificateRequired,
          onChanged: n.setCertificateRequired,
        ),
        const Gap(8),
        FormTextField(
          label: 'Required materials (optional)',
          controller: c.requiredMaterials,
          maxLines: 3,
          hint: 'Anything the buyer needs to arrange',
        ),
        FormTextField(
          label: 'Cancellation policy (optional)',
          controller: c.cancellationPolicy,
          maxLines: 3,
          hint: 'e.g. Free cancellation up to 24 hours before',
        ),
      ],
    );
  }
}
