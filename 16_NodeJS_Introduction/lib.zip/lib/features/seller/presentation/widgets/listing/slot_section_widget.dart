import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:intl/intl.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_listing_provider.dart';
import 'package:society_seva/features/seller/presentation/widgets/listing/listing_form_widgets.dart';

class SlotsSection extends ConsumerStatefulWidget {
  const SlotsSection({super.key});
  @override
  ConsumerState<SlotsSection> createState() => _SlotsSectionState();
}

class _SlotsSectionState extends ConsumerState<SlotsSection> {
  late DateTime _from;
  late DateTime _to;
  String? _selected; // yyyy-MM-dd
  bool _loadingSlots = false;
  bool _slotsError = false;

  static DateTime _today() {
    final n = DateTime.now();
    return DateTime(n.year, n.month, n.day);
  }

  @override
  void initState() {
    super.initState();
    _from = _today();
    _to = _from.add(const Duration(days: 7));
  }

  Future<void> _pickFrom() async {
    final today = _today();
    final d = await showDatePicker(
      context: context,
      initialDate: _from.isBefore(today) ? today : _from,
      firstDate: today, // past dates are invalid
      lastDate: today.add(const Duration(days: 365)),
      helpText: 'From date',
    );
    if (d == null) return;
    setState(() {
      _from = d;
      if (_to.isBefore(_from)) _to = _from;
    });
  }

  Future<void> _pickTo() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _to.isBefore(_from) ? _from : _to,
      firstDate: _from,
      lastDate: _from.add(const Duration(days: 365)),
      helpText: 'To date',
    );
    if (d != null) setState(() => _to = d);
  }

  Future<bool> _ensureLoaded(String key) async {
    final n = ref.read(productListingProvider.notifier);
    try {
      await n.loadSlotsForDate(key);
      return true;
    } catch (e, st) {
      debugPrint('loadSlotsForDate failed for $key: $e\n$st');
      return false;
    }
  }

  Future<void> _selectDate(String key) async {
    setState(() {
      _selected = key;
      _slotsError = false;
    });
    if (ref.read(productListingProvider).slots.containsKey(key)) return;

    setState(() => _loadingSlots = true);
    final ok = await _ensureLoaded(key);
    if (!mounted) return;
    setState(() {
      _loadingSlots = false;
      _slotsError = !ok;
    });
  }

  Future<void> _addSlot() async {
    final n = ref.read(productListingProvider.notifier);
    final today = _today();

    final date = await showDatePicker(
      context: context,
      initialDate: today,
      firstDate: today,
      lastDate: today.add(const Duration(days: 90)),
      helpText: 'Slot date',
    );
    if (date == null || !mounted) return;

    final start = await showTimePicker(
      context: context,
      initialTime: const TimeOfDay(hour: 10, minute: 0),
      helpText: 'Start time',
    );
    if (start == null || !mounted) return;

    final end = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(hour: (start.hour + 1) % 24, minute: start.minute),
      helpText: 'End time',
    );
    if (end == null || !mounted) return;

    // Directly add a new slot for the selected date without requiring prior loading.
    final error = n.addSlot(date, start, end);
    if (!mounted) return;
    if (error != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error)));
    } else {
      setState(() {
        _selected = ymd(date);
        _slotsError = false;
      });
    }
  }

  String _pretty(String key) => DateFormat('EEE, dd MMM').format(DateTime.parse(key));

  @override
  Widget build(BuildContext context) {
    final listingId = ref.watch(productListingProvider.select((s) => s.listingId));
    final slots = ref.watch(productListingProvider.select((s) => s.slots));
    final n = ref.read(productListingProvider.notifier);

    final fmt = DateFormat('dd MMM yyyy');
    AsyncValue<List<DateTime>>? datesAsync;
    if (listingId != null) {
      datesAsync = ref.watch(
        serviceScheduleDatesProvider((listingId: listingId, from: ymd(_from), to: ymd(_to))),
      );
    }

    final serverKeys = datesAsync?.valueOrNull?.map(ymd) ?? const <String>[];
    final dates = <String>{...serverKeys, ...slots.keys}.toList()..sort();

    final selected = (_selected != null && dates.contains(_selected)) ? _selected : null;
    final windows = selected == null
        ? const <SlotWindow>[]
        : (slots[selected] ?? const <SlotWindow>[]);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SectionTitle('Available time slots'),

        // From / To
        Row(
          children: [
            Expanded(
              child: _DateBox(label: 'From', value: fmt.format(_from), onTap: _pickFrom),
            ),
            const Gap(12),
            Expanded(
              child: _DateBox(label: 'To', value: fmt.format(_to), onTap: _pickTo),
            ),
          ],
        ),
        const Gap(12),

        // Dates
        if (datesAsync != null && datesAsync.isLoading && dates.isEmpty)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 12),
            child: Center(child: CircularProgressIndicator(color: AppColors.green)),
          )
        else if (datesAsync != null && datesAsync.hasError && dates.isEmpty)
          Row(
            children: [
              const Expanded(
                child: Text(
                  'Could not load available dates',
                  style: TextStyle(fontSize: 12.5, color: AppColors.red),
                ),
              ),
              TextButton(
                onPressed: () => ref.invalidate(serviceScheduleDatesProvider),
                child: const Text('Retry'),
              ),
            ],
          )
        else if (dates.isEmpty)
          const Padding(
            padding: EdgeInsets.only(bottom: 10),
            child: Text(
              'No slots in this range. Add a time slot below; you can also add them later.',
              style: TextStyle(fontSize: 12.5, color: AppColors.muted),
            ),
          )
        else
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final d in dates)
                ChoiceChip(
                  label: Text(_pretty(d)),
                  selected: selected == d,
                  selectedColor: AppColors.greenSoft,
                  labelStyle: TextStyle(
                    fontSize: 12.5,
                    fontWeight: selected == d ? FontWeight.w700 : FontWeight.w500,
                    color: selected == d ? AppColors.greenDeep : AppColors.ink,
                  ),
                  side: BorderSide(color: selected == d ? AppColors.green : AppColors.border),
                  onSelected: (_) => _selectDate(d),
                ),
            ],
          ),

        // Slots of the selected date
        if (selected != null) ...[
          const Gap(14),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              border: Border.all(color: AppColors.border),
              borderRadius: BorderRadius.circular(10),
              color: Colors.white,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _pretty(selected),
                  style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
                ),
                const Gap(8),
                if (_loadingSlots)
                  const SizedBox(
                    height: 20,
                    width: 20,
                    child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.green),
                  )
                else if (_slotsError)
                  Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'Could not load slots for this date',
                          style: TextStyle(fontSize: 12.5, color: AppColors.red),
                        ),
                      ),
                      TextButton(
                        onPressed: () => _selectDate(selected),
                        child: const Text('Retry'),
                      ),
                    ],
                  )
                else if (windows.isEmpty)
                  const Text(
                    'No time windows on this date.',
                    style: TextStyle(fontSize: 12.5, color: AppColors.muted),
                  )
                else
                  Wrap(
                    spacing: 8,
                    runSpacing: 4,
                    children: [
                      for (final w in windows)
                        InputChip(
                          label: Text('${w.startsAt} – ${w.endsAt}'),
                          onDeleted: () => n.removeSlot(selected, w),
                        ),
                    ],
                  ),
              ],
            ),
          ),
        ],

        const Gap(12),
        OutlinedButton.icon(
          onPressed: _addSlot,
          icon: const Icon(Icons.add),
          label: const Text('Add time slot'),
          style: OutlinedButton.styleFrom(
            foregroundColor: AppColors.green,
            side: const BorderSide(color: AppColors.green),
          ),
        ),
      ],
    );
  }
}

class _DateBox extends StatelessWidget {
  const _DateBox({required this.label, required this.value, required this.onTap});

  final String label;
  final String value;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.ink),
        ),
        const SizedBox(height: 6),
        InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(8),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 13),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppColors.border),
            ),
            child: Row(
              children: [
                const Icon(Icons.calendar_today_rounded, size: 16, color: AppColors.muted),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(value, style: const TextStyle(fontSize: 13, color: AppColors.ink)),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
