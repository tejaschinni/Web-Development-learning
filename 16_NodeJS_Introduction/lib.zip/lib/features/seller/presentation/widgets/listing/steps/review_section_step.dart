// lib/features/seller/presentation/widgets/listing/steps/review_section_step.dart

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_category_provider.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_listing_provider.dart';

import 'package:society_seva/features/seller/presentation/widgets/listing/listing_form_widgets.dart'
    show InfoBanner, StepHeader, kNavy;

class ListingReviewStep extends ConsumerWidget {
  const ListingReviewStep({super.key});

  static String _v(String? text) {
    final t = text?.trim() ?? '';
    return t.isEmpty ? '—' : t;
  }

  static String _yn(bool b) => b ? 'Yes' : 'No';

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(productListingProvider);
    final n = ref.read(productListingProvider.notifier);
    final c = n.controllers;

    final subsAsync = ref.watch(
      sellerCategoryTreeProvider((categoryType: s.categoryType.name.toUpperCase())),
    );
    final nameById = <String, String>{
      for (final e in (subsAsync.valueOrNull ?? [])) e.id.toString(): e.name,
    };

    final isFood = s.listingType.isFood;
    final isService = s.listingType.isService;
    final isApproved = s.approvalStatus?.toUpperCase() == 'APPROVED' ||
        s.approvalStatus?.toUpperCase() == 'APPROVAL';
    final incomplete = [
      for (var i = 0; i < kListingSteps.length - 1; i++)
        if (!n.isStepValid(i)) i,
    ];

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
      children: [
        StepHeader(
          title: 'Review Listing',
          subtitle: isApproved
              ? 'Check your changes, then update your listing'
              : 'Check everything before you save or submit',
        ),

        if (true)
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Chip(
                label: Text('Status: ${s.approvalStatus ?? '-'}'),
                backgroundColor: const Color(0xFFE9F6EC),
                side: BorderSide.none,
              ),
            ),
          ),

        if (incomplete.isNotEmpty)
          InfoBanner(
            'Some required details are missing in: '
            '${incomplete.map((i) => kListingSteps[i]).join(', ')}. '
            'Tap Edit on those sections to finish them.',
            color: const Color(0xFFFFEBEB),
            icon: Icons.warning_amber_rounded,
          ),

        // ── category ──
        _Section(
          title: 'Category',
          step: 0,
          children: [
            _Row('Category', s.categoryType.label),
            _Row('Subcategory', nameById[s.subcategoryId] ?? _v(s.subcategoryId)),
            if (s.additionalCategoryIds.isNotEmpty)
              _Row(
                'Also listed under',
                s.additionalCategoryIds.map((id) => nameById[id] ?? id).join(', '),
              ),
          ],
        ),

        // ── basic ──
        _Section(
          title: 'Basic Details',
          step: 1,
          children: [
            _Row('Listing type', s.listingType.label),
            _Row('Title', _v(c.title.text)),
            _Row('Description', _v(c.description.text)),
            if (s.tags.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Wrap(
                  spacing: 6,
                  runSpacing: 4,
                  children: [
                    for (final t in s.tags)
                      Chip(label: Text(t), visualDensity: VisualDensity.compact),
                  ],
                ),
              ),
          ],
        ),

        // ── pricing ──
        _Section(
          title: 'Pricing & Availability',
          step: 2,
          children: [
            if (isFood)
              const _Row('Price', 'Set per serving size')
            else ...[
              _Row('Price', s.isFree ? 'Free' : '₹ ${_v(c.basePrice.text)}'),
              if (!s.isFree) _Row('Price unit', kPriceUnits[s.priceUnit] ?? s.priceUnit),
            ],
            if (!isService) _Row('Quantity', _v(c.quantity.text)),
            _Row(
              'Availability',
              kAvailabilityStatuses[s.availabilityStatus] ?? s.availabilityStatus,
            ),
            if (isService)
              _Row(
                'Time slots',
                s.slots.isEmpty
                    ? 'None added'
                    : (s.slots.keys.toList()..sort())
                          .map(
                            (d) =>
                                '$d: ${s.slots[d]!.map((w) => '${w.startsAt}–${w.endsAt}').join(', ')}',
                          )
                          .join('\n'),
              ),
          ],
        ),
        _Section(
          title: isFood ? 'Food Details' : 'Additional Details',
          step: 3,
          children: [
            if (isFood) ...[
              _Row('Preparation time', '${_v(c.prepTime.text)} min'),
              _Row('Food type', kFoodTypes[s.foodType] ?? s.foodType),
              _Row('Ingredients', _v(c.ingredients.text)),
              _Row('Allergens', _v(c.allergens.text)),
              _Row('Spice level', s.spiceLevel.replaceAll('_', ' ')),
              _Row('Freshness', _v(c.freshness.text)),
              _Row('Frozen item', _yn(s.frozen)),
              _Row('Storage', _v(c.storage.text)),
              _Row('Packaging', _v(c.packaging.text)),
              _Row('Expiry', s.expiryTime == null ? '—' : ymd(s.expiryTime!)),
              _Row('FSSAI required', _yn(s.fssaiRequired)),
              if (s.fssaiRequired) _Row('FSSAI certificate ID', _v(c.fssaiId.text)),
              const Gap(6),
              const Text(
                'Serving sizes',
                style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700),
              ),
              const Gap(6),
              for (final d in s.servings)
                Container(
                  margin: const EdgeInsets.only(bottom: 6),
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF6F8FB),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          '${_v(d.description.text)}  (${d.sizeValue.text.trim()} ${d.sizeUnit.text.trim()})',
                          style: const TextStyle(fontSize: 13),
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            '₹ ${_v(d.price.text)}',
                            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
                          ),
                          Text(
                            d.isAvailable ? 'Qty ${_v(d.quantity.text)}' : 'Unavailable',
                            style: const TextStyle(fontSize: 11, color: AppColors.muted),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
            ] else if (isService) ...[
              _Row('Duration', '${_v(c.duration.text)} min'),
              _Row('Location', kLocationTypes[s.locationType] ?? s.locationType),
              _Row('Home visit', _yn(s.homeVisit)),
              _Row('Online', _yn(s.online)),
              _Row('Certificate required', _yn(s.certificateRequired)),
              _Row('Required materials', _v(c.requiredMaterials.text)),
              _Row('Cancellation policy', _v(c.cancellationPolicy.text)),
            ] else
              const _Row('Details', 'No additional details needed'),
          ],
        ),

        // ── photos ──
        _Section(
          title: 'Photos (${s.totalImageCount})',
          step: 4,
          children: [
            if (s.totalImageCount == 0)
              const Text('No photos added', style: TextStyle(color: AppColors.muted, fontSize: 13))
            else
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final img in s.visibleRemoteImages)
                    _Thumb(
                      Image.network(
                        img.imageUrl,
                        fit: BoxFit.cover,
                        errorBuilder: (_, _, _) => const Icon(Icons.broken_image_outlined),
                      ),
                    ),
                  for (final f in s.pendingImages)
                    _Thumb(Image.file(File(f.path), fit: BoxFit.cover)),
                ],
              ),
            if (s.pendingImages.isNotEmpty)
              const Padding(
                padding: EdgeInsets.only(top: 8),
                child: Text(
                  'New photos are uploaded when you save.',
                  style: TextStyle(fontSize: 11.5, color: AppColors.muted),
                ),
              ),
          ],
        ),
      ],
    );
  }
}

class _Section extends ConsumerWidget {
  const _Section({required this.title, required this.step, required this.children});
  final String title;
  final int step;
  final List<Widget> children;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.fromLTRB(14, 8, 8, 12),
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.border),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: kNavy),
                ),
              ),
              TextButton.icon(
                onPressed: () => ref.read(productListingProvider.notifier).goTo(step),
                icon: const Icon(Icons.edit_outlined, size: 16),
                label: const Text('Edit'),
                style: TextButton.styleFrom(foregroundColor: AppColors.green),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(right: 6),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: children),
          ),
        ],
      ),
    );
  }
}

class _Row extends StatelessWidget {
  const _Row(this.label, this.value);
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 120,
          child: Text(label, style: const TextStyle(fontSize: 12.5, color: AppColors.muted)),
        ),
        Expanded(
          child: Text(value, style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w500)),
        ),
      ],
    ),
  );
}

class _Thumb extends StatelessWidget {
  const _Thumb(this.image);
  final Widget image;

  @override
  Widget build(BuildContext context) => ClipRRect(
    borderRadius: BorderRadius.circular(8),
    child: SizedBox(width: 64, height: 64, child: image),
  );
}
