import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_category_provider.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_listing_provider.dart';
import 'package:society_seva/features/shop/data/models/shop_category_model.dart';

ShopCategoryModel? _resolveMain(List<ShopCategoryModel> cats, ListingFormState l) {
  if (l.mainCategoryId != null) {
    return cats.where((c) => c.id == l.mainCategoryId).firstOrNull;
  }
  final subId = l.subcategoryId;
  if (subId == null) return null;
  return cats.where((c) => c.id == subId || c.subCategories.any((s) => s.id == subId)).firstOrNull;
}

class SelectCategoryStep extends ConsumerWidget {
  const SelectCategoryStep({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final listing = ref.watch(productListingProvider);
    final notifier = ref.read(productListingProvider.notifier);
    final categoryTreeAsync = ref.watch(sellerCategoryTreeProvider((categoryType: '')));

    return categoryTreeAsync.when(
      loading: () => const Padding(
        padding: EdgeInsets.symmetric(vertical: 60),
        child: Center(child: CircularProgressIndicator(color: AppColors.green)),
      ),
      error: (e, _) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline_rounded, size: 48, color: AppColors.red),
            const SizedBox(height: 12),
            Text(
              'Failed to load categories',
              style: AppTheme.display(16, w: FontWeight.w600, c: AppColors.ink),
            ),
            const SizedBox(height: 6),
            Text(
              e.toString(),
              textAlign: TextAlign.center,
              style: AppTheme.hind(12, c: AppColors.muted),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () => ref.invalidate(sellerCategoryTreeProvider((categoryType: ''))),
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.green),
              child: const Text('Retry', style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
      data: (categories) {
        if (categories.isEmpty) {
          return const Center(child: Text('No categories found.'));
        }
        final selected = _resolveMain(categories, listing);
        if (listing.mainCategoryId == null && selected != null) {
          WidgetsBinding.instance.addPostFrameCallback(
            (_) => notifier.hydrateMainCategory(selected.id),
          );
        }

        return ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          children: [
            Text(
              'Create New Listing',
              style: AppTheme.display(20, w: FontWeight.w800, c: AppColors.ink),
            ),
            const SizedBox(height: 4),
            Text(
              'Select the category for your listing',
              style: AppTheme.hind(13, c: AppColors.muted),
            ),
            const SizedBox(height: 20),

            _label('Main Category'),
            const SizedBox(height: 6),
            _DropdownField(
              hint: 'Select main category',
              icon: selected == null
                  ? HugeIcons.strokeRoundedGridView
                  : _categoryIcon(selected.name),
              iconColor: selected == null ? AppColors.muted : _categoryColor(selected.name),
              text: selected?.name,
              onTap: () async {
                final result = await showModalBottomSheet<ShopCategoryModel>(
                  context: context,
                  isScrollControlled: true,
                  backgroundColor: Colors.white,
                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                  ),
                  builder: (_) =>
                      _MainCategorySheet(categories: categories, selectedId: selected?.id),
                );

                if (result != null && result.id != selected?.id) {
                  notifier.selectMainCategory(result);
                } else {}
              },
            ),
            const SizedBox(height: 20),

            _label('Subcategories (Optional)'),
            const Gap(6),
            _DropdownField(
              hint: selected == null ? 'Select a main category first' : 'Select subcategories',
              icon: HugeIcons.strokeRoundedCheckList,
              iconColor: AppColors.green,
              text: listing.additionalCategoryIds.isEmpty
                  ? null
                  : '${listing.additionalCategoryIds.length} selected',
              enabled: selected != null && selected.subCategories.isNotEmpty,
              onTap: () {
                if (selected == null) return;
                showModalBottomSheet<void>(
                  context: context,
                  isScrollControlled: true,
                  backgroundColor: Colors.white,
                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                  ),
                  builder: (_) => _SubcategorySheet(category: selected),
                );
              },
            ),
            if (selected != null && selected.subCategories.isEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(
                  'No subcategories for ${selected.name}. You can proceed to the next step.',
                  style: AppTheme.hind(12, c: AppColors.muted),
                ),
              ),

            if (selected != null && listing.selectedSubcategoryIds.isNotEmpty) ...[
              const Gap(12),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: listing.selectedSubcategoryIds.map((id) {
                  final name =
                      selected.subCategories
                          .where((s) => s.id == id)
                          .map((s) => s.name)
                          .firstOrNull ??
                      id;
                  return Chip(
                    label: Text(name, style: AppTheme.hind(12, c: AppColors.greenDeep)),
                    backgroundColor: AppColors.greenSoft,
                    deleteIcon: const Icon(Icons.close, size: 14, color: AppColors.green),
                    onDeleted: () => notifier.toggleSubcategory(id),
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    side: BorderSide(color: AppColors.green.withValues(alpha: 0.3)),
                  );
                }).toList(),
              ),
            ],
          ],
        );
      },
    );
  }

  Widget _label(String t) => Text(
    t,
    style: AppTheme.hind(13, w: FontWeight.w600, c: AppColors.ink),
  );
}

class _DropdownField extends StatelessWidget {
  const _DropdownField({
    required this.hint,
    required this.icon,
    required this.iconColor,
    required this.onTap,
    this.text,
    this.enabled = true,
  });

  final String hint;
  final String? text;
  final List<List<dynamic>> icon;
  final Color iconColor;
  final bool enabled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: enabled ? 1 : 0.5,
      child: InkWell(
        onTap: enabled ? onTap : null,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border),
          ),
          child: Row(
            children: [
              HugeIcon(icon: icon, size: 20, color: iconColor),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  text ?? hint,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTheme.hind(
                    14,
                    w: text == null ? FontWeight.w400 : FontWeight.w600,
                    c: text == null ? AppColors.muted : AppColors.ink,
                  ),
                ),
              ),
              HugeIcon(icon: HugeIcons.strokeRoundedArrowDown01, size: 20, color: AppColors.muted),
            ],
          ),
        ),
      ),
    );
  }
}

/// Shared search box used in both sheets.
class _SheetSearch extends StatelessWidget {
  const _SheetSearch({required this.controller, required this.hint, required this.onChanged});

  final TextEditingController controller;
  final String hint;
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 8),
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAF9),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          const Icon(Icons.search, size: 20, color: AppColors.muted),
          const SizedBox(width: 8),
          Expanded(
            child: TextField(
              controller: controller,
              onChanged: onChanged,
              decoration: InputDecoration(
                hintText: hint,
                hintStyle: const TextStyle(fontSize: 13, color: AppColors.muted),
                border: InputBorder.none,
                isDense: true,
                contentPadding: const EdgeInsets.symmetric(vertical: 12),
              ),
            ),
          ),
          if (controller.text.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.clear, size: 18, color: AppColors.muted),
              onPressed: () {
                controller.clear();
                onChanged('');
              },
            ),
        ],
      ),
    );
  }
}

Widget _sheetHeader(BuildContext context, String title) => Padding(
  padding: const EdgeInsets.fromLTRB(16, 14, 8, 8),
  child: Row(
    children: [
      Expanded(
        child: Text(
          title,
          style: AppTheme.display(16, w: FontWeight.w800, c: AppColors.ink),
        ),
      ),
      IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(context)),
    ],
  ),
);

class _MainCategorySheet extends StatefulWidget {
  const _MainCategorySheet({required this.categories, this.selectedId});

  final List<ShopCategoryModel> categories;
  final String? selectedId;

  @override
  State<_MainCategorySheet> createState() => _MainCategorySheetState();
}

class _MainCategorySheetState extends State<_MainCategorySheet> {
  final _controller = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final items = widget.categories
        .where(
          (c) => c.name.toLowerCase().contains(_query) || c.slug.toLowerCase().contains(_query),
        )
        .toList();

    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.7,
        child: Column(
          children: [
            _sheetHeader(context, 'Select Main Category'),
            _SheetSearch(
              controller: _controller,
              hint: 'Search category...',
              onChanged: (v) => setState(() => _query = v.trim().toLowerCase()),
            ),
            Expanded(
              child: items.isEmpty
                  ? Center(
                      child: Text(
                        'No matching categories',
                        style: AppTheme.hind(13, c: AppColors.muted),
                      ),
                    )
                  : ListView.separated(
                      itemCount: items.length,
                      separatorBuilder: (_, _) => const Divider(height: 1, color: AppColors.border),
                      itemBuilder: (_, i) {
                        final c = items[i];
                        final isSel = c.id == widget.selectedId;
                        final color = _categoryColor(c.name);
                        return ListTile(
                          leading: Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color: color.withValues(alpha: 0.12),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: AppTheme.hi(_categoryIcon(c.categoryType.name), c: color, s: 22),
                          ),
                          title: Text(
                            c.name,
                            style: AppTheme.hind(
                              14,
                              w: isSel ? FontWeight.w700 : FontWeight.w500,
                              c: isSel ? AppColors.greenDeep : AppColors.ink,
                            ),
                          ),
                          trailing: isSel
                              ? const Icon(Icons.check_circle_rounded, color: AppColors.green)
                              : null,
                          onTap: () => Navigator.pop(context, c),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SubcategorySheet extends ConsumerStatefulWidget {
  const _SubcategorySheet({required this.category});

  final ShopCategoryModel category;

  @override
  ConsumerState<_SubcategorySheet> createState() => _SubcategorySheetState();
}

class _SubcategorySheetState extends ConsumerState<_SubcategorySheet> {
  final _controller = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final listing = ref.watch(productListingProvider);
    final notifier = ref.read(productListingProvider.notifier);
    final selectedIds = listing.selectedSubcategoryIds;

    final items = widget.category.subCategories
        .where((s) => s.name.toLowerCase().contains(_query))
        .toList();

    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.75,
        child: Column(
          children: [
            _sheetHeader(context, 'Select ${widget.category.name} Subcategories'),
            _SheetSearch(
              controller: _controller,
              hint: 'Search subcategories...',
              onChanged: (v) => setState(() => _query = v.trim().toLowerCase()),
            ),
            Expanded(
              child: items.isEmpty
                  ? Center(
                      child: Text(
                        'No matching subcategories',
                        style: AppTheme.hind(13, c: AppColors.muted),
                      ),
                    )
                  : ListView.separated(
                      itemCount: items.length,
                      separatorBuilder: (_, _) => const Divider(height: 1, color: AppColors.border),
                      itemBuilder: (_, i) {
                        final sub = items[i];
                        final isSel =
                            selectedIds.contains(sub.id) || listing.subcategoryId == sub.id;
                        return CheckboxListTile(
                          value: isSel,
                          onChanged: (_) => notifier.toggleSubcategory(sub.id),

                          activeColor: AppColors.green,
                          controlAffinity: ListTileControlAffinity.trailing,
                          secondary: Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color: const Color(0xFFF4F7F5),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: AppTheme.hi(
                              _subcategoryIcon(sub.name),
                              s: 22,
                              c: AppColors.green,
                            ),
                          ),
                          title: Text(
                            sub.name,
                            style: AppTheme.hind(
                              14,
                              w: isSel ? FontWeight.w600 : FontWeight.w500,
                              c: isSel ? AppColors.greenDeep : AppColors.ink,
                            ),
                          ),
                        );
                      },
                    ),
            ),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                child: SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: ElevatedButton(
                    onPressed: () => Navigator.pop(context),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.green,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    child: Text(
                      selectedIds.isEmpty ? 'Done' : 'Done (${selectedIds.length} selected)',
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

typedef HIcon = List<List<dynamic>>;

HIcon _categoryIcon(String name) {
  final l = name.toLowerCase();
  if (l.contains('food')) return HugeIcons.strokeRoundedRestaurant01;
  if (l.contains('art') || l.contains('creative')) return HugeIcons.strokeRoundedPaintBoard;
  if (l.contains('service')) return HugeIcons.strokeRoundedWrench01;
  if (l.contains('grocery')) return HugeIcons.strokeRoundedShoppingBasket01;
  return HugeIcons.strokeRoundedGridView;
}

Color _categoryColor(String name) {
  final l = name.toLowerCase();
  if (l.contains('food')) return const Color(0xFFE28B14);
  if (l.contains('art') || l.contains('creative')) return const Color(0xFF8B3FD8);
  if (l.contains('service')) return AppColors.blue;
  return AppColors.green;
}

HIcon _subcategoryIcon(String name) {
  final l = name.toLowerCase();
  if (l.contains('meal') || l.contains('tiffin')) return HugeIcons.strokeRoundedRiceBowl01;
  if (l.contains('snack') || l.contains('namkeen')) return HugeIcons.strokeRoundedCookie;
  if (l.contains('cake') || l.contains('bakery')) return HugeIcons.strokeRoundedCake;
  if (l.contains('sweet') || l.contains('dessert')) return HugeIcons.strokeRoundedIceCream01;
  if (l.contains('pickle') || l.contains('chutney')) return HugeIcons.strokeRoundedJar;
  if (l.contains('festival')) return HugeIcons.strokeRoundedParty;
  if (l.contains('catering')) return HugeIcons.strokeRoundedChefHat;
  if (l.contains('gift') || l.contains('craft')) return HugeIcons.strokeRoundedGif01;
  if (l.contains('artwork') || l.contains('paint')) return HugeIcons.strokeRoundedPaintBrush01;
  if (l.contains('jewel')) return HugeIcons.strokeRoundedDiamond01;
  if (l.contains('decor')) return HugeIcons.strokeRoundedHome01;
  if (l.contains('tutor')) return HugeIcons.strokeRoundedTeacher;
  if (l.contains('repair')) return HugeIcons.strokeRoundedTools;
  if (l.contains('beauty') || l.contains('salon')) return HugeIcons.strokeRoundedSpam;
  return HugeIcons.strokeRoundedCheckmarkCircle02;
}
