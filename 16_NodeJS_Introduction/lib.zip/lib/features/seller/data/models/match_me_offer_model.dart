import 'package:society_seva/features/seller/domain/entities/match_me_offer_entity.dart';

class MatchMeOfferModel extends MatchMeOfferEntity {
  const MatchMeOfferModel({
    required super.id,
    required super.requirementId,
    required super.sellerId,
    required super.sellerName,
    required super.offeredPrice,
    required super.notes,
    super.availableFrom,
    super.availableTo,
    required super.status,
    super.createdAt,
    super.updatedAt,
  });

  factory MatchMeOfferModel.fromJson(Map<String, dynamic> json) {
    return MatchMeOfferModel(
      id: json['id']?.toString() ?? '',
      requirementId: json['requirementId']?.toString() ?? '',
      sellerId: json['sellerId']?.toString() ?? '',
      sellerName: json['sellerName']?.toString() ?? '',
      offeredPrice: (json['offeredPrice'] as num?)?.toDouble() ??
          double.tryParse(json['offeredPrice']?.toString() ?? '0') ??
          0.0,
      notes: json['notes']?.toString() ?? '',
      availableFrom: json['availableFrom'] != null
          ? DateTime.tryParse(json['availableFrom'].toString())
          : null,
      availableTo: json['availableTo'] != null
          ? DateTime.tryParse(json['availableTo'].toString())
          : null,
      status: json['status']?.toString() ?? 'PENDING',
      createdAt: json['createdAt'] != null
          ? DateTime.tryParse(json['createdAt'].toString())
          : null,
      updatedAt: json['updatedAt'] != null
          ? DateTime.tryParse(json['updatedAt'].toString())
          : null,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'requirementId': requirementId,
    'sellerId': sellerId,
    'sellerName': sellerName,
    'offeredPrice': offeredPrice,
    'notes': notes,
    'availableFrom': availableFrom?.toIso8601String(),
    'availableTo': availableTo?.toIso8601String(),
    'status': status,
    'createdAt': createdAt?.toIso8601String(),
    'updatedAt': updatedAt?.toIso8601String(),
  };
}
