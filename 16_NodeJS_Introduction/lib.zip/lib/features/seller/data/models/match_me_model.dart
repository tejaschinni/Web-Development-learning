import 'dart:convert';

import 'package:society_seva/features/seller/domain/entities/match_me_entity.dart';

MatchMeModel matchMeModelFromJson(String str) => MatchMeModel.fromJson(json.decode(str));

String matchMeModelToJson(MatchMeModel data) => json.encode(data.toJson());

class MatchMeModel extends MatchMeEntity {
  const MatchMeModel({
    required super.id,
    required super.buyerId,
    required super.categoryId,
    required super.title,
    required super.description,
    required super.quantity,
    required super.unit,
    required super.budgetMin,
    required super.budgetMax,
    required super.requiredBy,
    required super.address,
    required super.city,
    required super.state,
    required super.pinCode,
    required super.latitude,
    required super.longitude,
    required super.offerCount,
    required super.status,
    required super.discussingSellers,
    required super.createdAt,
  });

  factory MatchMeModel.fromJson(Map<String, dynamic> json) {
    return MatchMeModel(
      id: json['id']?.toString() ?? '',
      buyerId: json['buyerId']?.toString() ?? '',
      categoryId: json['categoryId']?.toString() ?? '',
      title: json['title']?.toString() ?? '',
      description: json['description']?.toString() ?? '',
      quantity: (json['quantity'] as num?)?.toInt() ?? 0,
      unit: json['unit']?.toString() ?? '',
      budgetMin: (json['budgetMin'] as num?)?.toInt() ?? 0,
      budgetMax: (json['budgetMax'] as num?)?.toInt() ?? 0,
      requiredBy: json['requiredBy'] != null
          ? DateTime.tryParse(json['requiredBy'].toString()) ?? DateTime.now()
          : DateTime.now(),
      address: json['address']?.toString() ?? '',
      city: json['city']?.toString() ?? '',
      state: json['state']?.toString() ?? '',
      pinCode: json['pinCode']?.toString() ?? '',
      latitude: (json['latitude'] as num?)?.toDouble() ?? 0.0,
      longitude: (json['longitude'] as num?)?.toDouble() ?? 0.0,
      offerCount: (json['offerCount'] as num?)?.toInt() ?? 0,
      status: json['status']?.toString() ?? 'OPEN',
      discussingSellers: List<dynamic>.from(json['discussingSellers'] ?? const []),
      createdAt: json['createdAt'] != null
          ? DateTime.tryParse(json['createdAt'].toString()) ?? DateTime.now()
          : DateTime.now(),
    );
  }

  factory MatchMeModel.fromEntity(MatchMeEntity entity) {
    return MatchMeModel(
      id: entity.id,
      buyerId: entity.buyerId,
      categoryId: entity.categoryId,
      title: entity.title,
      description: entity.description,
      quantity: entity.quantity,
      unit: entity.unit,
      budgetMin: entity.budgetMin,
      budgetMax: entity.budgetMax,
      requiredBy: entity.requiredBy,
      address: entity.address,
      city: entity.city,
      state: entity.state,
      pinCode: entity.pinCode,
      latitude: entity.latitude,
      longitude: entity.longitude,
      offerCount: entity.offerCount,
      status: entity.status,
      discussingSellers: entity.discussingSellers,
      createdAt: entity.createdAt,
    );
  }

  MatchMeEntity toEntity() {
    return MatchMeEntity(
      id: id,
      buyerId: buyerId,
      categoryId: categoryId,
      title: title,
      description: description,
      quantity: quantity,
      unit: unit,
      budgetMin: budgetMin,
      budgetMax: budgetMax,
      requiredBy: requiredBy,
      address: address,
      city: city,
      state: state,
      pinCode: pinCode,
      latitude: latitude,
      longitude: longitude,
      offerCount: offerCount,
      status: status,
      discussingSellers: discussingSellers,
      createdAt: createdAt,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'buyerId': buyerId,
    'categoryId': categoryId,
    'title': title,
    'description': description,
    'quantity': quantity,
    'unit': unit,
    'budgetMin': budgetMin,
    'budgetMax': budgetMax,
    'requiredBy': requiredBy.toIso8601String(),
    'address': address,
    'city': city,
    'state': state,
    'pinCode': pinCode,
    'latitude': latitude,
    'longitude': longitude,
    'offerCount': offerCount,
    'status': status,
    'discussingSellers': discussingSellers,
    'createdAt': createdAt.toIso8601String(),
  };
}
