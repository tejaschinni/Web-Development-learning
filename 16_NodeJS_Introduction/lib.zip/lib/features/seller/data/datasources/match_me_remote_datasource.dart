import 'dart:developer';

import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/seller/data/models/match_me_model.dart';
import 'package:society_seva/features/seller/data/models/match_me_offer_model.dart';
import 'package:society_seva/features/seller/domain/entities/match_me_offer_entity.dart';

abstract class MatchMeRemoteDataSource {
  Future<PageResponse<MatchMeModel>> fetchMatcingRequirmentForSellerDataSource({
    int page = 0,
    int size = 20,
  });

  Future<void> sellerNotIntrestedInRequirmentDataSource({required String requirmentID});

  Future<MatchMeOfferModel> postOfferForRequirement({
    required String requirementId,
    required CreateMatchMeOfferRequest request,
  });

  Future<List<MatchMeOfferModel>> fetchPostedOffers({required String requirementId});

  Future<void> sellerInterestedRequirmentDataSource();

  Future<List<MatchMeOfferModel>> fetchPostedoffer({required String requirmentID});
}

class MatchMeRemoteDataSourceImpl implements MatchMeRemoteDataSource {
  MatchMeRemoteDataSourceImpl(this._apiClient);
  final ApiClient _apiClient;

  static bool useDummyData = false;

  static final List<Map<String, dynamic>> _dummyRequirements = [
    {
      "id": "ccf27896-d1e4-4eca-87c4-bdf65d711dfb",
      "buyerId": "d5029c8d-fe2d-4012-a296-26b7d5ef5177",
      "categoryId": "0ed8f5ae-d665-48cc-bac3-7c6db5b56846",
      "title": "Looking for homemade pure veg catering for 25 people",
      "description": "Need lunch delivery on Saturday afternoon with Gujarati dal, roti, and sweets",
      "quantity": 25,
      "unit": "plates",
      "budgetMin": 2500,
      "budgetMax": 5000,
      "requiredBy": "2026-10-24T13:00:00Z",
      "address": "Lane No 1, Bhagyoday Colony, Hingne Budrukh, Karvenagar",
      "city": "Pune",
      "state": "Maharashtra",
      "pinCode": "411052",
      "latitude": 18.488523,
      "longitude": 73.818888,
      "offerCount": 0,
      "status": "OPEN",
      "discussingSellers": [],
      "createdAt": "2026-10-24T10:15:43.702201Z",
    },
    {
      "id": "7a8b9c0d-1e2f-4a3b-9c8d-5e6f7a8b9c0d",
      "buyerId": "a1b2c3d4-e5f6-4a1b-8c2d-3e4f5a6b7c8d",
      "categoryId": "df53b2c6-5171-488b-9855-5f87b06cbfd6",
      "title": "Need custom chocolate truffle birthday cake (1.5 kg)",
      "description": "Custom birthday cake with eggless chocolate truffle, needed by Sunday 5 PM.",
      "quantity": 1,
      "unit": "cake",
      "budgetMin": 800,
      "budgetMax": 1500,
      "requiredBy": "2026-10-26T17:00:00Z",
      "address": "Flat 304, Marvel Zephyr, Karvenagar",
      "city": "Pune",
      "state": "Maharashtra",
      "pinCode": "411052",
      "latitude": 18.489100,
      "longitude": 73.817500,
      "offerCount": 1,
      "status": "OPEN",
      "discussingSellers": [],
      "createdAt": "2026-10-24T11:30:00.000000Z",
    },
  ];

  static final Map<String, List<Map<String, dynamic>>> _dummyOffers = {
    "ccf27896-d1e4-4eca-87c4-bdf65d711dfb": [
      {
        "id": "2d140fb4-7557-4583-a51c-83f9ddac0b30",
        "requirementId": "ccf27896-d1e4-4eca-87c4-bdf65d711dfb",
        "sellerId": "f059c1f8-042a-4ad5-9889-7540beef8199",
        "sellerName": "Vasundhara Seller",
        "offeredPrice": 3500,
        "notes": "Includes 25 plates of Gujarati thali with dessert, delivered by 1:00 PM",
        "availableFrom": "2026-10-24T12:00:00Z",
        "availableTo": "2026-10-30T12:00:00Z",
        "status": "ACCEPTED",
        "createdAt": "2026-10-24T10:16:58.829588Z",
        "updatedAt": "2026-10-24T10:18:07.803821Z",
      },
    ],
  };

  @override
  Future<PageResponse<MatchMeModel>> fetchMatcingRequirmentForSellerDataSource({
    int page = 0,
    int size = 20,
  }) async {
    if (useDummyData) {
      return PageResponse<MatchMeModel>(
        content: _dummyRequirements.map(MatchMeModel.fromJson).toList(),
        page: page,
        size: size,
        totalElements: _dummyRequirements.length,
        totalPages: 1,
        first: true,
        last: true,
      );
    }

    log('[MatchMeRemoteDataSource] GET ${ApiEndpoints.sellerMatchMe}');
    try {
      final response = await _apiClient.get(
        ApiEndpoints.sellerMatchMe,
        queryParameters: {'page': page, 'size': size},
      );
      final data = response.data;
      if (data is Map<String, dynamic>) {
        return PageResponse.fromJson(data, MatchMeModel.fromJson);
      } else if (data is Map) {
        return PageResponse.fromJson(Map<String, dynamic>.from(data), MatchMeModel.fromJson);
      }
      throw Exception('Unexpected response format');
    } catch (e) {
      log('[MatchMeRemoteDataSource] Failed to fetch requirements from API, falling back to mock: $e');
      return PageResponse<MatchMeModel>(
        content: _dummyRequirements.map(MatchMeModel.fromJson).toList(),
        page: page,
        size: size,
        totalElements: _dummyRequirements.length,
        totalPages: 1,
        first: true,
        last: true,
      );
    }
  }

  @override
  Future<void> sellerNotIntrestedInRequirmentDataSource({required String requirmentID}) async {
    final endpoint = ApiEndpoints.buyerRequirementNotInterested(requirmentID);
    log('[MatchMeRemoteDataSource] POST $endpoint');

    if (useDummyData) {
      _dummyRequirements.removeWhere((item) => item['id'] == requirmentID);
      return;
    }

    try {
      await _apiClient.post(endpoint);
      _dummyRequirements.removeWhere((item) => item['id'] == requirmentID);
    } catch (e) {
      log('[MatchMeRemoteDataSource] POST not-interested error: $e');
      _dummyRequirements.removeWhere((item) => item['id'] == requirmentID);
    }
  }

  @override
  Future<MatchMeOfferModel> postOfferForRequirement({
    required String requirementId,
    required CreateMatchMeOfferRequest request,
  }) async {
    final endpoint = ApiEndpoints.buyerRequirementOffers(requirementId);
    log('[MatchMeRemoteDataSource] POST $endpoint with body: ${request.toJson()}');

    if (useDummyData) {
      final mock = MatchMeOfferModel(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        requirementId: requirementId,
        sellerId: request.sellerId,
        sellerName: 'Vasundhara Seller',
        offeredPrice: double.tryParse(request.offeredPrice) ?? 0.0,
        notes: request.notes,
        availableFrom: request.availableFrom,
        availableTo: request.availableTo,
        status: 'PENDING',
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );
      _dummyOffers.putIfAbsent(requirementId, () => []).insert(0, mock.toJson());
      return mock;
    }

    try {
      final response = await _apiClient.post(endpoint, data: request.toJson());
      final data = response.data;
      if (data is Map<String, dynamic>) {
        return MatchMeOfferModel.fromJson(data);
      } else if (data is Map) {
        return MatchMeOfferModel.fromJson(Map<String, dynamic>.from(data));
      }
      throw Exception('Unexpected response format when creating offer');
    } catch (e) {
      log('[MatchMeRemoteDataSource] POST offer error, falling back to mock: $e');
      final mock = MatchMeOfferModel(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        requirementId: requirementId,
        sellerId: request.sellerId,
        sellerName: 'Vasundhara Seller',
        offeredPrice: double.tryParse(request.offeredPrice) ?? 0.0,
        notes: request.notes,
        availableFrom: request.availableFrom,
        availableTo: request.availableTo,
        status: 'PENDING',
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );
      _dummyOffers.putIfAbsent(requirementId, () => []).insert(0, mock.toJson());
      return mock;
    }
  }

  @override
  Future<List<MatchMeOfferModel>> fetchPostedOffers({required String requirementId}) async {
    final endpoint = ApiEndpoints.buyerRequirementOffers(requirementId);
    log('[MatchMeRemoteDataSource] GET $endpoint');

    if (useDummyData) {
      final list = _dummyOffers[requirementId] ?? [];
      return list.map(MatchMeOfferModel.fromJson).toList();
    }

    try {
      final response = await _apiClient.get(endpoint);
      final data = response.data;
      if (data is List) {
        return data
            .whereType<Map>()
            .map((item) => MatchMeOfferModel.fromJson(Map<String, dynamic>.from(item)))
            .toList();
      }
      return const [];
    } catch (e) {
      log('[MatchMeRemoteDataSource] GET offers error, falling back to mock: $e');
      final list = _dummyOffers[requirementId] ?? [];
      return list.map(MatchMeOfferModel.fromJson).toList();
    }
  }

  @override
  Future<List<MatchMeOfferModel>> fetchPostedoffer({required String requirmentID}) {
    return fetchPostedOffers(requirementId: requirmentID);
  }

  @override
  Future<void> sellerInterestedRequirmentDataSource() async {
    log('[MatchMeRemoteDataSource] Seller interested hook called');
  }
}
