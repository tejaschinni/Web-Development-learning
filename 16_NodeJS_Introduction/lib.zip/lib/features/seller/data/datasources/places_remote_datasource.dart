import 'package:society_seva/features/seller/domain/entities/address_entity.dart';
import 'package:society_seva/features/seller/domain/entities/place_details_entity.dart';

import 'dart:convert';

import 'package:geocoding/geocoding.dart' as geo;
import 'package:http/http.dart' as http;

abstract interface class PlacesRemoteDatasource {
  Future<List<AddressSuggestion>> autocomplete(String query);
  Future<PlaceDetails?> getDetails(String placeId);

  Future<PlaceDetails?> geocodeAddress(String address);
}

class PlacesRemoteDataSource {
  PlacesRemoteDataSource(this._client, {required this.apiKey, geo.Geocoding? geocoding})
    : _geocoding = geocoding ?? geo.Geocoding();
  final http.Client _client;
  final String apiKey;
  final geo.Geocoding _geocoding;

  Future<List<Map<String, dynamic>>> autocomplete(String input) async {
    final res = await _client.post(
      Uri.parse('https://places.googleapis.com/v1/places:autocomplete'),
      headers: {'Content-Type': 'application/json', 'X-Goog-Api-Key': apiKey},
      body: jsonEncode({
        'input': input,
        'includedRegionCodes': ['in'],
      }),
    );
    if (res.statusCode != 200) return [];
    final list = (jsonDecode(res.body)['suggestions'] as List?) ?? [];
    return list.map((s) => s['placePrediction']).whereType<Map<String, dynamic>>().toList();
  }

  Future<Map<String, dynamic>?> details(String placeId) async {
    final res = await _client.get(
      Uri.parse('https://places.googleapis.com/v1/places/$placeId'),
      headers: {
        'X-Goog-Api-Key': apiKey,
        'X-Goog-FieldMask': 'formattedAddress,location,addressComponents',
      },
    );
    if (res.statusCode != 200) return null;
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  Future<List<geo.Location>> locationsFromAddress(String address) =>
      _geocoding.locationFromAddress(address);

  Future<List<geo.Placemark>> placemarksFromCoordinates(double lat, double lng) =>
      _geocoding.placemarkFromCoordinates(lat, lng);
}
