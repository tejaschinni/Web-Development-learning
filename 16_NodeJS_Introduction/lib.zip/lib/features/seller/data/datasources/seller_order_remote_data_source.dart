import 'dart:developer';

import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/seller/data/models/order_status_history_model.dart';
import 'package:society_seva/features/seller/data/models/seller_order_model.dart';

abstract class SellerOrderRemoteDataSource {
  Future<PageResponse<SellerOrderModel>> fetchSellerOrdersDataSource({required String sellerId});

  Future<SellerOrderModel> transitionOrderDataSource({
    required String orderId,
    required String newStatus,
    String? note,
  });

  Future<String> fetchBuyerIdDataSource({required String buyerId});
  Future<List<OrderStatusHistoryModel>> fetchOrderStatusHistoryDataSource({
    required String orderID,
  });
}

class SellerOrderRemoteDataSourceImpl implements SellerOrderRemoteDataSource {
  SellerOrderRemoteDataSourceImpl(this._apiClient);

  final ApiClient _apiClient;

  /// Set to true to return dummy data for development and offline testing.
  static bool useDummyData = true;

  static List<SellerOrderModel> dummyOrders = [
    SellerOrderModel(
      id: '3a73a114-04fd-4d1b-b7f0-0b135e09dd3f',
      orderNumber: 'ORD-20261016-V6W81S',
      buyerId: 'd5029c8d-fe2d-4012-a296-26b7d5ef5177',
      sellerId: 'a5077570-6bf6-4879-9753-478949dd5876',
      orderType: 'PRODUCT_ORDER',
      orderStatus: 'CREATED',
      subtotalAmount: 1200.0,
      discountAmount: 0.0,
      platformCommission: 120.0,
      welfareFundAmount: 60.0,
      sellerEarning: 1020.0,
      totalAmount: 1200.0,
      paymentStatus: 'PENDING',
      items: const [
        SellerOrderItemModel(
          id: '78969f1d-022e-4123-b62c-c1b430ef5b7b',
          listingId: 'c4b6cb03-683c-4c55-b9ea-c656a430ec33',
          titleSnapshot: 'Basmati Rice',
          quantity: 10,
          unitPrice: 120.0,
          totalPrice: 1200.0,
        ),
      ],
      createdAt: DateTime.parse('2026-10-16T09:09:31.460080Z'),
    ),
    SellerOrderModel(
      id: '1dfa2464-d786-4b15-99da-0b6f79bf4e2d',
      orderNumber: 'ORD-20261019-A8K29Z',
      buyerId: 'd5029c8d-fe2d-4012-a296-26b7d5ef5177',
      sellerId: 'a5077570-6bf6-4879-9753-478949dd5876',
      orderType: 'FOOD_ORDER',
      orderStatus: 'PAID',
      subtotalAmount: 350.0,
      discountAmount: 0.0,
      platformCommission: 35.0,
      welfareFundAmount: 15.0,
      sellerEarning: 300.0,
      totalAmount: 350.0,
      paymentStatus: 'PAID',
      items: const [
        SellerOrderItemModel(
          id: '99018f1d-022e-4123-b62c-c1b430ef5b99',
          listingId: 'c8099e5b-a354-4e38-8c67-609d2045a60d',
          titleSnapshot: 'Kanda Pohe (Full Plate)',
          quantity: 2,
          unitPrice: 55.0,
          totalPrice: 110.0,
        ),
        SellerOrderItemModel(
          id: '99028f1d-022e-4123-b62c-c1b430ef5b98',
          listingId: 'df53b2c6-5171-488b-9855-5f87b06cbfd6',
          titleSnapshot: 'Chocolate Truffle Cake',
          quantity: 1,
          unitPrice: 240.0,
          totalPrice: 240.0,
        ),
      ],
      createdAt: DateTime.parse('2026-10-19T07:29:34.686032Z'),
    ),
  ];

  static Map<String, List<OrderStatusHistoryModel>> dummyOrderHistory = {
    '3a73a114-04fd-4d1b-b7f0-0b135e09dd3f': [
      OrderStatusHistoryModel(
        id: '91234a25-e2d3-4153-8321-3aba762f6199',
        orderId: '3a73a114-04fd-4d1b-b7f0-0b135e09dd3f',
        oldStatus: '',
        newStatus: 'CREATED',
        note: 'Order placed by customer',
        createdAt: DateTime.parse('2026-10-16T09:09:31.460080Z'),
      ),
    ],
    '1dfa2464-d786-4b15-99da-0b6f79bf4e2d': [
      OrderStatusHistoryModel(
        id: '55657a25-e2d3-4153-8321-3aba762f6170',
        orderId: '1dfa2464-d786-4b15-99da-0b6f79bf4e2d',
        oldStatus: '',
        newStatus: 'CREATED',
        note: 'Order created from cart',
        createdAt: DateTime.parse('2026-10-19T06:59:05.131818Z'),
      ),
      OrderStatusHistoryModel(
        id: '811cb831-1433-4164-b37c-d4f238f8a173',
        orderId: '1dfa2464-d786-4b15-99da-0b6f79bf4e2d',
        oldStatus: 'CREATED',
        newStatus: 'PAYMENT_PENDING',
        note: 'Payment initiated',
        createdAt: DateTime.parse('2026-10-19T07:27:38.973392Z'),
      ),
      OrderStatusHistoryModel(
        id: 'd82a498a-1da5-491b-a0bd-0934fe923608',
        orderId: '1dfa2464-d786-4b15-99da-0b6f79bf4e2d',
        oldStatus: 'PAYMENT_PENDING',
        newStatus: 'PAID',
        note: 'Payment successful',
        createdAt: DateTime.parse('2026-10-19T07:29:34.686032Z'),
      ),
    ],
  };

  @override
  Future<PageResponse<SellerOrderModel>> fetchSellerOrdersDataSource({
    required String sellerId,
  }) async {
    if (useDummyData) {
      return PageResponse<SellerOrderModel>(
        content: dummyOrders,
        page: 0,
        size: 20,
        totalElements: dummyOrders.length,
        totalPages: 1,
        first: true,
        last: true,
      );
    }
    try {
      final response = await _apiClient.get(
        ApiEndpoints.orders,
        queryParameters: {'sellerId': sellerId},
      );
      return PageResponse.fromJson(
        Map<String, dynamic>.from(response.data as Map),
        SellerOrderModel.fromJson,
      );
    } catch (_) {
      return PageResponse<SellerOrderModel>(
        content: dummyOrders,
        page: 0,
        size: 20,
        totalElements: dummyOrders.length,
        totalPages: 1,
        first: true,
        last: true,
      );
    }
  }

  @override
  Future<SellerOrderModel> transitionOrderDataSource({
    required String orderId,
    required String newStatus,
    String? note,
  }) async {
    final idx = dummyOrders.indexWhere((o) => o.id == orderId);
    if (idx != -1) {
      final old = dummyOrders[idx];
      final updated = SellerOrderModel(
        id: old.id,
        orderNumber: old.orderNumber,
        buyerId: old.buyerId,
        sellerId: old.sellerId,
        orderType: old.orderType,
        orderStatus: newStatus,
        subtotalAmount: old.subtotalAmount,
        discountAmount: old.discountAmount,
        platformCommission: old.platformCommission,
        welfareFundAmount: old.welfareFundAmount,
        sellerEarning: old.sellerEarning,
        totalAmount: old.totalAmount,
        paymentStatus: old.paymentStatus,
        items: old.items,
        createdAt: old.createdAt,
      );
      dummyOrders[idx] = updated;

      final historyList = dummyOrderHistory.putIfAbsent(orderId, () {
        return [
          OrderStatusHistoryModel(
            id: 'hist_init_${DateTime.now().millisecondsSinceEpoch}',
            orderId: orderId,
            oldStatus: '',
            newStatus: 'CREATED',
            note: 'Order placed by customer',
            createdAt: old.createdAt,
          ),
        ];
      });

      historyList.add(
        OrderStatusHistoryModel(
          id: 'hist_${DateTime.now().millisecondsSinceEpoch}',
          orderId: orderId,
          oldStatus: old.orderStatus,
          newStatus: newStatus,
          note: note ?? (newStatus == 'REJECTED' ? 'Item not available' : 'Status updated to $newStatus'),
          createdAt: DateTime.now(),
        ),
      );

      if (useDummyData) return updated;
    }

    try {
      final params = <String, dynamic>{
        'newStatus': newStatus,
        if (note != null && note.isNotEmpty) 'note': note,
      };
      log('[SellerOrderDataSource] POST ${ApiEndpoints.orderTransition(orderId)} payload: $params');

      final response = await _apiClient.post(
        ApiEndpoints.orderTransition(orderId),
        queryParameters: params,
      );
      return SellerOrderModel.fromJson(response.data as Map<String, dynamic>);
    } catch (_) {
      if (idx != -1) return dummyOrders[idx];
      throw Exception('Order not found');
    }
  }

  @override
  Future<String> fetchBuyerIdDataSource({required String buyerId}) async {
    if (useDummyData) return 'Priya Sharma';
    try {
      final response = await _apiClient.get(ApiEndpoints.fetchBuyerNameFromID(buyerId));
      if (response.statusCode == 200) {
        return response.data['fullName'] ?? 'Priya Sharma';
      }
      return 'Priya Sharma';
    } catch (_) {
      return 'Priya Sharma';
    }
  }

  @override
  Future<List<OrderStatusHistoryModel>> fetchOrderStatusHistoryDataSource({
    required String orderID,
  }) async {
    if (useDummyData) {
      if (dummyOrderHistory.containsKey(orderID)) {
        return dummyOrderHistory[orderID]!;
      }
      final order = dummyOrders.where((o) => o.id == orderID).firstOrNull;
      if (order != null) {
        final list = [
          OrderStatusHistoryModel(
            id: 'hist_${orderID}_created',
            orderId: orderID,
            oldStatus: '',
            newStatus: 'CREATED',
            note: 'Order placed by customer',
            createdAt: order.createdAt,
          ),
          if (order.orderStatus != 'CREATED')
            OrderStatusHistoryModel(
              id: 'hist_${orderID}_${order.orderStatus.toLowerCase()}',
              orderId: orderID,
              oldStatus: 'CREATED',
              newStatus: order.orderStatus,
              note: 'Order ${order.orderStatus.toLowerCase()}',
              createdAt: DateTime.now(),
            ),
        ];
        dummyOrderHistory[orderID] = list;
        return list;
      }
      return dummyOrderHistory.values.firstOrNull ?? const [];
    }
    try {
      log('[SellerOrderDataSource] GET ${ApiEndpoints.orderStatusHistory(orderID)} ');

      final response = await _apiClient.get(ApiEndpoints.orderStatusHistory(orderID));

      final List<dynamic> data = response.data as List<dynamic>;
      return data
          .map((item) => OrderStatusHistoryModel.fromJson(item as Map<String, dynamic>))
          .toList();
    } catch (e) {
      return dummyOrderHistory[orderID] ?? dummyOrderHistory.values.firstOrNull ?? const [];
    }
  }
}
