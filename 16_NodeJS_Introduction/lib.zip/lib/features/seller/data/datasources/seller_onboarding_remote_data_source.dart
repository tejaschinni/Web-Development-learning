import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/widgets.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/features/seller/data/models/certificate_model.dart';
import 'package:society_seva/features/seller/data/models/kyc_document_model.dart';
import 'package:society_seva/features/seller/data/models/seller_availabledays_model.dart';
import 'package:society_seva/features/seller/data/models/seller_image_model.dart';
import 'package:society_seva/features/seller/data/models/seller_profile_model.dart';
import 'package:society_seva/features/seller/data/models/request/seller_profile_request.dart';

abstract class SellerOnboardingRemoteDataSource {
  Future<SellerProfileModel?> createAndSaveAsDraftDataSource({
    required SellerProfileRequest request,
  });
  Future<SellerProfileModel?> submitDartDataSource({required String sellerId});
  Future<void> uploadSellerShopImagesDataSource(String sellerId, XFile file);
  Future<List<SellerImageModel>> fetchSellerUploadedImagesDataSource(String sellerId);
  Future<SellerProfileModel?> mySellerProfileDataSource();
  Future<SellerProfileModel?> fetchSellerProfileByIDDataSource(String sellerID);
  Future<SellerProfileModel?> updateProfileDataSource({
    required SellerProfileRequest request,
    required String sellerID,
  });
  Future<void> deleteUploadedSellerImagesDataSource({
    required String sellerID,
    required String imageId,
  });

  Future<CertificateModel?> uploadCertificateDataSource({
    required String sellerId,
    required XFile file,
    required String certificateName,
    required String certificateType,
    required DateTime issueDate,
    required bool hasExpiry,
    required String issueAuthority,
    required String certificateNumber,
    DateTime? expiryDate,
  });

  Future<List<CertificateModel>> fetchCertificatesDataSource(String sellerId);

  Future<List<KycDocumentModel>> fetchKycDocumentDataSource(String sellerId);

  Future<bool> uploadKYCDocumentDataSource({
    required XFile file,
    required String documentType,
    required String documentNumber,
    required String sellerId,
  });

  Future<String> downloadKycDocumentFileDataSource({
    required String sellerId,
    required String documentFileUrl,
  });
  Future<AvailableDaysModel> fetchSellerAvailableDaysDataSource({required String sellerID});

  Future<AvailableDaysModel> updateSellerAvailableDaysDataSource({
    required String sellerID,
    required Map<String, dynamic> data,
  });
}

class SellerOnboardingRemoteDataSourceImpl implements SellerOnboardingRemoteDataSource {
  SellerOnboardingRemoteDataSourceImpl({required this._apiClient});

  final ApiClient _apiClient;

  /// Set to true to use dummy data directly in the datasource (for development & offline testing).
  /// Set to false to hit live backend API endpoints.
  static bool useDummyData = true;

  /// Initial seller status. Default is 'APPROVED' (approved).
  /// Change this string if needed: 'DRAFT', 'SUBMITTED', 'UNDER_REVIEW', 'APPROVED', 'REJECTED', 'SUSPENDED', 'INACTIVE'
  static String initialApprovalStatus = 'APPROVED';

  /// Stateful in-memory dummy seller profile for development & testing.
  static SellerProfileModel dummySellerProfile = SellerProfileModel(
    id: 'seller_dummy_001',
    userId: 'user_dummy_001',
    displayName: 'Rahul Sharma',
    businessName: 'Sharma Foods & Delights',
    bio: 'Authentic homemade snacks and baked goods prepared fresh daily with quality ingredients.',
    sellerTypeList: const ['FOOD_MAKER', 'KITCHEN'],
    availabilityStatus: 'AVAILABLE',
    approvalStatus: initialApprovalStatus,
    fssaiStatus: 'APPROVED',
    fssaiRequired: true,
    fssaiCertificateId: 'FSSAI-12345678901234',
    renewalStatus: 'ACTIVE',
    totalListings: 2,
    averageRating: 4.8,
    rejectedOrders: 0,
    cancelledOrders: 0,
    totalOrders: 15,
    totalReviews: 8,
    address: 'Flat 402, Building B, Green Meadows Society',
    city: 'Pune',
    state: 'Maharashtra',
    country: 'India',
    pinCode: '411045',
    latitude: 18.5204,
    longitude: 73.8567,
    deliveryRadiusKm: 10.0,
    targetArea: 'Baner & Balewadi',
    websiteUrl: 'https://sharmafoods.example.com',
    socialMediaLinks: 'instagram.com/sharmafoods',
    legalCompliance: 'Standard FSSAI and local municipal food license compliance maintained.',
    capabilitiesDescription: 'Specialized in fresh organic baking and evening snacks.',
    capabilityTags: const ['Freshly Baked', 'Organic', 'Vegetarian'],
    capableCategoryIds: const ['food_category_1', 'food_category_2'],
    createdAt: '2026-01-15T10:00:00Z',
    updatedAt: '2026-02-01T15:30:00Z',
  );

  static AvailableDaysModel dummyAvailableDays = const AvailableDaysModel(
    sellerId: 'seller_dummy_001',
    daysType: 'ALL_DAYS',
    availableDays: ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY'],
    fromTime: '09:00:00',
    toTime: '21:00:00',
  );

  static final List<SellerImageModel> dummySellerImages = [
    SellerImageModel(
      id: 'img_dummy_001',
      sellerId: 'seller_dummy_001',
      imageUrl: 'https://images.unsplash.com/photo-1556910103-1c02745aae4d',
      moderationStatus: 'APPROVED',
      displayOrder: 1,
      createdAt: DateTime.now().subtract(const Duration(days: 10)),
      updatedAt: DateTime.now().subtract(const Duration(days: 10)),
    ),
  ];

  static final List<CertificateModel> dummyCertificates = [
    CertificateModel(
      id: 'cert_dummy_001',
      sellerId: 'seller_dummy_001',
      certificateType: 'FSSAI_REGISTRATION',
      certificateName: 'FSSAI Food Safety Certificate',
      issuingAuthority: 'Food Safety and Standards Authority of India',
      certificateFileUrl: 'https://example.com/certificates/fssai.pdf',
      verificationStatus: 'VERIFIED',
      createdAt: DateTime.now().subtract(const Duration(days: 30)),
      updatedAt: DateTime.now().subtract(const Duration(days: 30)),
    ),
  ];

  static final List<KycDocumentModel> dummyKycDocuments = [
    KycDocumentModel(
      id: 'kyc_dummy_001',
      sellerId: 'seller_dummy_001',
      documentType: 'AADHAAR',
      documentFileUrl: 'https://example.com/kyc/aadhaar.pdf',
      verificationStatus: 'VERIFIED',
      createdAt: DateTime.now().subtract(const Duration(days: 30)),
      updatedAt: DateTime.now().subtract(const Duration(days: 30)),
    ),
  ];

  SellerProfileModel _mergeProfileRequest(SellerProfileRequest request, {required String status}) {
    return dummySellerProfile.copyWith(
      displayName: request.displayName.isNotEmpty ? request.displayName : dummySellerProfile.displayName,
      businessName: request.businessName ?? dummySellerProfile.businessName,
      bio: request.bio ?? dummySellerProfile.bio,
      sellerTypeList: request.sellerTypeList.isNotEmpty ? request.sellerTypeList : dummySellerProfile.sellerTypeList,
      approvalStatus: status,
      fssaiRequired: request.fssaiRequired ?? dummySellerProfile.fssaiRequired,
      fssaiCertificateId: request.fssaiCertificateId ?? dummySellerProfile.fssaiCertificateId,
      websiteUrl: request.websiteUrl ?? dummySellerProfile.websiteUrl,
      socialMediaLinks: request.socialMediaLinks ?? dummySellerProfile.socialMediaLinks,
      legalCompliance: request.legalCompliance ?? dummySellerProfile.legalCompliance,
      address: request.address.isNotEmpty ? request.address : dummySellerProfile.address,
      city: request.city.isNotEmpty ? request.city : dummySellerProfile.city,
      state: request.state.isNotEmpty ? request.state : dummySellerProfile.state,
      country: request.country.isNotEmpty ? request.country : dummySellerProfile.country,
      pinCode: request.pinCode.isNotEmpty ? request.pinCode : dummySellerProfile.pinCode,
      latitude: request.latitude ?? dummySellerProfile.latitude,
      longitude: request.longitude ?? dummySellerProfile.longitude,
      deliveryRadiusKm: request.deliveryRadiusKm ?? dummySellerProfile.deliveryRadiusKm,
      targetArea: request.targetArea ?? dummySellerProfile.targetArea,
      capabilitiesDescription: request.capabilitiesDescription ?? dummySellerProfile.capabilitiesDescription,
      capabilityTags: request.capabilityTags ?? dummySellerProfile.capabilityTags,
      capableCategoryIds: request.capableCategoryIds ?? dummySellerProfile.capableCategoryIds,
      updatedAt: DateTime.now().toIso8601String(),
    );
  }

  @override
  Future<SellerProfileModel?> createAndSaveAsDraftDataSource({
    required SellerProfileRequest request,
  }) async {
    dummySellerProfile = _mergeProfileRequest(request, status: 'DRAFT');
    if (useDummyData) {
      return dummySellerProfile;
    }
    try {
      final response = await _apiClient.post(
        ApiEndpoints.createSellerProfile,
        data: request.toJson(),
      );
      return SellerProfileModel.fromJson(response.data);
    } catch (_) {
      return dummySellerProfile;
    }
  }

  @override
  Future<void> deleteUploadedSellerImagesDataSource({
    required String sellerID,
    required String imageId,
  }) async {
    dummySellerImages.removeWhere((img) => img.id == imageId);
    if (useDummyData) return;
    try {
      await _apiClient.delete(ApiEndpoints.deleteImages(sellerID, imageId));
    } on DioException catch (e) {
      debugPrint("Dio Exception on delete images ${e.error}");
    }
  }

  @override
  Future<SellerProfileModel?> fetchSellerProfileByIDDataSource(String sellerID) async {
    if (useDummyData) {
      return dummySellerProfile;
    }
    try {
      final response = await _apiClient.get(ApiEndpoints.sellerByID(sellerID));
      return SellerProfileModel.fromJson(response.data);
    } on DioException catch (e) {
      if (e.response?.statusCode == 404) return null;
      return dummySellerProfile;
    } catch (_) {
      return dummySellerProfile;
    }
  }

  @override
  Future<List<SellerImageModel>> fetchSellerUploadedImagesDataSource(String sellerId) async {
    if (useDummyData) {
      return dummySellerImages;
    }
    try {
      final response = await _apiClient.get(ApiEndpoints.fetchSellerImages(sellerId));
      final List<dynamic> data = response.data as List<dynamic>;
      return data.map((item) => SellerImageModel.fromJson(item as Map<String, dynamic>)).toList();
    } catch (_) {
      return dummySellerImages;
    }
  }

  @override
  Future<SellerProfileModel?> mySellerProfileDataSource() async {
    if (useDummyData) {
      return dummySellerProfile;
    }
    try {
      final response = await _apiClient.get(ApiEndpoints.sellerProfile);
      return SellerProfileModel.fromJson(response.data);
    } on DioException catch (e) {
      if (e.response?.statusCode == 404) return null;
      return dummySellerProfile;
    } catch (_) {
      return dummySellerProfile;
    }
  }

  @override
  Future<SellerProfileModel?> submitDartDataSource({required String sellerId}) async {
    dummySellerProfile = dummySellerProfile.copyWith(approvalStatus: 'SUBMITTED');
    if (useDummyData) {
      return dummySellerProfile;
    }
    try {
      final response = await _apiClient.post(ApiEndpoints.submitSellerProfile(sellerId));
      return SellerProfileModel.fromJson(response.data);
    } catch (_) {
      return dummySellerProfile;
    }
  }

  @override
  Future<SellerProfileModel?> updateProfileDataSource({
    required SellerProfileRequest request,
    required String sellerID,
  }) async {
    dummySellerProfile = _mergeProfileRequest(
      request,
      status: dummySellerProfile.approvalStatus.isNotEmpty ? dummySellerProfile.approvalStatus : 'DRAFT',
    );
    if (useDummyData) {
      return dummySellerProfile;
    }
    try {
      final response = await _apiClient.patch(
        '${ApiEndpoints.createSellerProfile}/$sellerID',
        data: request.toJson(),
      );
      return SellerProfileModel.fromJson(response.data);
    } catch (_) {
      return dummySellerProfile;
    }
  }

  @override
  Future<void> uploadSellerShopImagesDataSource(String sellerId, XFile file) async {
    dummySellerImages.add(
      SellerImageModel(
        id: 'img_dummy_${DateTime.now().millisecondsSinceEpoch}',
        sellerId: sellerId,
        imageUrl: file.path,
        moderationStatus: 'APPROVED',
        displayOrder: dummySellerImages.length + 1,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      ),
    );
    if (useDummyData) return;
    final form = FormData();
    form.files.add(MapEntry('file', await MultipartFile.fromFile(file.path, filename: file.name)));
    await _apiClient.post(ApiEndpoints.fetchSellerImages(sellerId), data: form);
  }

  @override
  Future<List<CertificateModel>> fetchCertificatesDataSource(String sellerId) async {
    if (useDummyData) {
      return dummyCertificates;
    }
    try {
      final response = await _apiClient.get(ApiEndpoints.certificate(sellerId));
      final List<dynamic> data = response.data as List<dynamic>;
      return data.map((item) => CertificateModel.fromJson(item as Map<String, dynamic>)).toList();
    } catch (_) {
      return dummyCertificates;
    }
  }

  @override
  Future<CertificateModel?> uploadCertificateDataSource({
    required String sellerId,
    required XFile file,
    required String certificateName,
    required String certificateType,
    required DateTime issueDate,
    required bool hasExpiry,
    required String issueAuthority,
    required String certificateNumber,
    DateTime? expiryDate,
  }) async {
    final cert = CertificateModel(
      id: 'cert_dummy_${DateTime.now().millisecondsSinceEpoch}',
      sellerId: sellerId,
      certificateType: certificateType,
      certificateName: certificateName,
      issuingAuthority: issueAuthority,
      certificateFileUrl: 'https://example.com/certificates/${file.name}',
      verificationStatus: 'PENDING',
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
    dummyCertificates.add(cert);
    if (useDummyData) {
      return cert;
    }
    try {
      final form = FormData();
      final dateFormate = DateFormat('yyyy-MM-dd');
      form.files.add(
        MapEntry('file', await MultipartFile.fromFile(file.path, filename: file.name)),
      );
      final formData = FormData.fromMap({
        'file': await MultipartFile.fromFile(file.path, filename: file.name),
        'certificateType': certificateType,
        'certificateName': certificateName,
        'certificateNumber': certificateNumber,
        'issuingAuthority': issueAuthority,
        'issueDate': dateFormate.format(issueDate),
        'expiryDate': hasExpiry ? dateFormate.format(expiryDate!) : null,
      });

      final response = await _apiClient.post(ApiEndpoints.certificate(sellerId), data: formData);

      if (response.statusCode == 200) {
        CertificateModel model = CertificateModel.fromJson(response.data);
        return model;
      }
      return cert;
    } catch (e) {
      return cert;
    }
  }

  @override
  Future<List<KycDocumentModel>> fetchKycDocumentDataSource(String sellerId) async {
    if (useDummyData) {
      return dummyKycDocuments;
    }
    try {
      final response = await _apiClient.get(ApiEndpoints.fetchKycDocument(sellerId));
      final List<dynamic> data = response.data as List<dynamic>;
      return data.map((item) => KycDocumentModel.fromJson(item as Map<String, dynamic>)).toList();
    } catch (_) {
      return dummyKycDocuments;
    }
  }

  @override
  Future<bool> uploadKYCDocumentDataSource({
    required XFile file,
    required String documentType,
    required String documentNumber,
    required String sellerId,
  }) async {
    final doc = KycDocumentModel(
      id: 'kyc_dummy_${DateTime.now().millisecondsSinceEpoch}',
      sellerId: sellerId,
      documentType: documentType,
      documentFileUrl: 'https://example.com/kyc/${file.name}',
      verificationStatus: 'PENDING',
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
    dummyKycDocuments.add(doc);
    if (useDummyData) {
      return true;
    }
    try {
      final formData = FormData.fromMap({
        'file': await MultipartFile.fromFile(file.path, filename: file.name),
        'documentType': documentType,
        'documentNumber': documentNumber,
      });

      final response = await _apiClient.post(
        ApiEndpoints.uploadKycDocument(sellerId),
        data: formData,
      );

      if (response.statusCode == 200) {
        KycDocumentModel kycDocumentModel = KycDocumentModel.fromJson(response.data);
        return kycDocumentModel.verificationStatus.toLowerCase() == "pending";
      }
      return true;
    } catch (e) {
      return true;
    }
  }

  @override
  Future<String> downloadKycDocumentFileDataSource({
    required String sellerId,
    required String documentFileUrl,
  }) async {
    if (useDummyData) {
      return 'dummy_kyc_document_content';
    }
    try {
      final response = await _apiClient.get(ApiEndpoints.kycDocumentFile(sellerId, documentFileUrl));
      return response.data as String;
    } catch (_) {
      return 'dummy_kyc_document_content';
    }
  }

  @override
  Future<AvailableDaysModel> fetchSellerAvailableDaysDataSource({required String sellerID}) async {
    if (useDummyData) {
      return dummyAvailableDays;
    }
    try {
      final response = await _apiClient.get(ApiEndpoints.selleravailableDays(sellerID));
      return AvailableDaysModel.fromJson(response.data);
    } catch (_) {
      return dummyAvailableDays;
    }
  }

  @override
  Future<AvailableDaysModel> updateSellerAvailableDaysDataSource({
    required String sellerID,
    required Map<String, dynamic> data,
  }) async {
    dummyAvailableDays = AvailableDaysModel(
      sellerId: sellerID,
      daysType: data['daysType'] as String? ?? dummyAvailableDays.daysType,
      availableDays: (data['availableDays'] as List<dynamic>?)?.map((e) => e.toString()).toList() ??
          dummyAvailableDays.availableDays,
      fromTime: data['fromTime'] as String? ?? dummyAvailableDays.fromTime,
      toTime: data['toTime'] as String? ?? dummyAvailableDays.toTime,
    );
    if (useDummyData) {
      return dummyAvailableDays;
    }
    try {
      final response = await _apiClient.patch(
        ApiEndpoints.selleravailableDays(sellerID),
        data: jsonEncode(data),
      );
      return AvailableDaysModel.fromJson(response.data);
    } catch (_) {
      return dummyAvailableDays;
    }
  }
}
