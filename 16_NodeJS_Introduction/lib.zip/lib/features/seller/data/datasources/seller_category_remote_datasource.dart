import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/seller/data/models/seller_category_model.dart';
import 'package:society_seva/features/shop/data/models/shop_category_model.dart';

abstract class SellerCategoryRemoteDatasource {
  Future<PageResponse<CategoriesModel>> fetchCategoriesDataSource({
    String? categoryType,
    String? parentCategoryId,
    bool? rootsOnly,
    String? search,
  });

  Future<List<ShopCategoryModel>> fetchCategoriesTreeDataSource({String? categoryType});
}

class SellerCategoryRemoteDatasourceImpl implements SellerCategoryRemoteDatasource {
  SellerCategoryRemoteDatasourceImpl(this._apiClient);
  final ApiClient _apiClient;

  static bool useDummyData = true;

  static final List<CategoriesModel> _dummyCategories = [
    CategoriesModel.fromJson({
      "id": "377ecc8c-7405-45c1-b935-c7c160481cac",
      "name": "Breakfast",
      "slug": "breakfast",
      "categoryType": "FOOD",
      "requiresCertificate": false,
      "isActive": true,
      "displayOrder": 0,
      "createdAt": "2026-08-28T09:30:10.887686Z",
      "updatedAt": "2026-08-28T09:30:10.887686Z",
    }),
    CategoriesModel.fromJson({
      "id": "df53b2c6-5171-488b-9855-5f87b06cbfd6",
      "name": "Cake",
      "slug": "cake",
      "categoryType": "FOOD",
      "requiresCertificate": false,
      "isActive": true,
      "displayOrder": 1,
      "createdAt": "2026-09-28T10:19:31.733588Z",
      "updatedAt": "2026-09-28T10:19:31.733588Z",
    }),
    CategoriesModel.fromJson({
      "id": "c47a9601-d2e8-4d12-a8f5-8b58d58a7fa6",
      "name": "Dietician",
      "slug": "dietician",
      "categoryType": "CONSULTANCY",
      "requiresCertificate": false,
      "isActive": true,
      "displayOrder": 1,
      "createdAt": "2026-09-28T10:16:21.505182Z",
      "updatedAt": "2026-09-28T10:16:21.505182Z",
    }),
    CategoriesModel.fromJson({
      "id": "7f35bf85-2fc2-4884-a5f9-8ded5cbfc251",
      "name": "Dinner",
      "slug": "dinner",
      "categoryType": "FOOD",
      "requiresCertificate": false,
      "isActive": true,
      "displayOrder": 1,
      "createdAt": "2026-09-28T10:19:25.968927Z",
      "updatedAt": "2026-09-28T10:19:25.968927Z",
    }),
    CategoriesModel.fromJson({
      "id": "c90428e0-ccbe-4d4c-b335-72a4c75592ae",
      "name": "Electrician",
      "slug": "electrician",
      "categoryType": "SERVICE",
      "requiresCertificate": false,
      "isActive": true,
      "displayOrder": 1,
      "createdAt": "2026-09-23T12:24:19.947572Z",
      "updatedAt": "2026-09-28T10:23:55.835955Z",
    }),
    CategoriesModel.fromJson({
      "id": "e2ac149e-9fdc-4898-8247-7956700833cf",
      "name": "Fitness Trainer",
      "slug": "fitness-trainer",
      "categoryType": "CONSULTANCY",
      "requiresCertificate": false,
      "isActive": true,
      "displayOrder": 1,
      "createdAt": "2026-09-28T10:16:39.968138Z",
      "updatedAt": "2026-09-28T10:16:39.968138Z",
    }),
    CategoriesModel.fromJson({
      "id": "08d24e05-49cb-4f9e-bba5-6963fa6925ce",
      "name": "Ran repair",
      "slug": "ran-repair",
      "categoryType": "SERVICE",
      "requiresCertificate": false,
      "isActive": true,
      "displayOrder": 1,
      "createdAt": "2026-09-23T12:28:51.966082Z",
      "updatedAt": "2026-09-23T12:28:51.966082Z",
    }),
    CategoriesModel.fromJson({
      "id": "74358bb8-dbc7-455b-92e7-a1201ac2c6d7",
      "name": "Repair",
      "slug": "repair",
      "categoryType": "SERVICE",
      "requiresCertificate": false,
      "isActive": true,
      "displayOrder": 1,
      "createdAt": "2026-09-23T12:26:10.117571Z",
      "updatedAt": "2026-09-23T12:26:10.117571Z",
    }),
    CategoriesModel.fromJson({
      "id": "153e2eb3-f39a-4b99-92ad-8c205ba99a43",
      "name": "Tution Classes",
      "slug": "tution-classes",
      "categoryType": "SERVICE",
      "requiresCertificate": false,
      "isActive": true,
      "displayOrder": 1,
      "createdAt": "2026-09-28T10:15:38.257769Z",
      "updatedAt": "2026-09-28T10:15:38.257769Z",
    }),
  ];

  static final List<ShopCategoryModel> _dummyCategoryTree = [
    ShopCategoryModel.fromJson({
      "id": "c90428e0-ccbe-4d4c-b335-72a4c75592ae",
      "name": "Electrician",
      "slug": "electrician",
      "categoryType": "SERVICE",
      "requiresCertificate": false,
      "isActive": true,
      "displayOrder": 1,
      "subCategories": [
        {
          "id": "08d24e05-49cb-4f9e-bba5-6963fa6925ce",
          "name": "Ran repair",
          "slug": "ran-repair",
          "categoryType": "SERVICE",
          "requiresCertificate": false,
          "isActive": true,
          "displayOrder": 1,
          "subCategories": [],
        },
        {
          "id": "74358bb8-dbc7-455b-92e7-a1201ac2c6d7",
          "name": "Repair",
          "slug": "repair",
          "categoryType": "SERVICE",
          "requiresCertificate": false,
          "isActive": true,
          "displayOrder": 1,
          "subCategories": [],
        },
      ],
    }),
    ShopCategoryModel.fromJson({
      "id": "153e2eb3-f39a-4b99-92ad-8c205ba99a43",
      "name": "Tution Classes",
      "slug": "tution-classes",
      "categoryType": "SERVICE",
      "requiresCertificate": false,
      "isActive": true,
      "displayOrder": 1,
      "subCategories": [],
    }),
    ShopCategoryModel.fromJson({
      "id": "377ecc8c-7405-45c1-b935-c7c160481cac",
      "name": "Breakfast",
      "slug": "breakfast",
      "categoryType": "FOOD",
      "requiresCertificate": false,
      "isActive": true,
      "displayOrder": 0,
      "subCategories": [
        {
          "id": "df53b2c6-5171-488b-9855-5f87b06cbfd6",
          "name": "Cake",
          "slug": "cake",
          "categoryType": "FOOD",
          "requiresCertificate": false,
          "isActive": true,
          "displayOrder": 1,
          "subCategories": [],
        },
      ],
    }),
  ];

  @override
  Future<PageResponse<CategoriesModel>> fetchCategoriesDataSource({
    String? categoryType,
    String? parentCategoryId,
    bool? rootsOnly,
    String? search,
  }) async {
    final filtered = categoryType != null && categoryType.isNotEmpty
        ? _dummyCategories
            .where((c) => c.categoryType.toUpperCase() == categoryType.toUpperCase())
            .toList()
        : _dummyCategories;

    if (useDummyData) {
      return PageResponse<CategoriesModel>(
        content: filtered,
        page: 0,
        size: 50,
        totalElements: filtered.length,
        totalPages: 1,
        first: true,
        last: true,
      );
    }
    try {
      final response = await _apiClient.get(
        ApiEndpoints.allCategory,
        queryParameters: {
          'isActive': true,
          'categoryType': categoryType,
          'parentCategoryId': parentCategoryId,
          'rootsOnly': rootsOnly,
          'search': search,
        },
      );
      return PageResponse.fromJson(
        Map<String, dynamic>.from(response.data as Map),
        CategoriesModel.fromJson,
      );
    } catch (_) {
      return PageResponse<CategoriesModel>(
        content: filtered,
        page: 0,
        size: 50,
        totalElements: filtered.length,
        totalPages: 1,
        first: true,
        last: true,
      );
    }
  }

  @override
  Future<List<ShopCategoryModel>> fetchCategoriesTreeDataSource({String? categoryType}) async {
    final filtered = categoryType != null && categoryType.isNotEmpty
        ? _dummyCategoryTree
            .where((c) => c.categoryType.name.toUpperCase() == categoryType.toUpperCase())
            .toList()
        : _dummyCategoryTree;

    if (useDummyData) {
      return filtered;
    }
    try {
      final response = await _apiClient.get(
        ApiEndpoints.categoryTree,
        queryParameters: {'isActive': true, 'categoryType': categoryType},
      );

      final data = response.data;

      if (data is! List) {
        return filtered;
      }
      final result = data
          .whereType<Map>()
          .map((item) => ShopCategoryModel.fromJson(Map<String, dynamic>.from(item)))
          .toList(growable: false);
      return result.isNotEmpty ? result : filtered;
    } catch (_) {
      return filtered;
    }
  }
}
