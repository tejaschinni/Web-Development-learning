import 'dart:developer';

import 'package:dio/dio.dart';
import 'package:image_picker/image_picker.dart';
import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/seller/data/models/food_detail_model.dart';
import 'package:society_seva/features/seller/data/models/request/food_additional_information_request.dart';
import 'package:society_seva/features/seller/data/models/request/seller_listing_basic_info_request.dart';
import 'package:society_seva/features/seller/data/models/request/service_additional_information_request.dart';
import 'package:society_seva/features/seller/data/models/seller_listing_image_model.dart';
import 'package:society_seva/features/seller/data/models/seller_listing_model.dart';
import 'package:society_seva/features/seller/data/models/service_detail_model.dart';
import 'package:society_seva/features/seller/data/models/service_slot_model.dart';

abstract class SellerListingRemoteDatasource {
  Future<PageResponse<SellerListingModel>> fetchMyListingDataSource({required String sellerId});

  Future<SellerListingModel> fetchListingByIdDataSource({required String listingID});

  Future<List<SellerListingImageModel>> getListingImagesDataSource(String listingId);

  Future<SellerListingModel?> createListingDataSource({
    required SellerListingBasicInfoRequest request,
  });

  Future<SellerListingModel?> submitListingDataSource({required String listingId});

  Future<SellerListingModel?> updateSubmitListingDataSource({
    required String listingId,
    required SellerListingBasicInfoRequest request,
  });

  Future<SellerListingImageModel> uploadSellerShopImagesDataSource(String sellerId, XFile file);

  Future<bool> additionalFoodInformationDataSource({
    required FoodAdditionalInformationRequest request,
    required String listingId,
  });

  Future<bool> additionalServiceInformationDataSource({
    required ServiceAdditionalInformationRequest request,
    required String listingId,
  });

  Future<FoodListingDetailsModel?> updateAdditionalFoodInformationDataSource({
    required FoodAdditionalInformationRequest request,
    required String listingId,
  });

  Future<ServiceListingDetailsModel?> updateAdditionalServiceInformationDataSource({
    required ServiceAdditionalInformationRequest request,
    required String listingId,
  });

  Future<FoodListingDetailsModel> fetchAdditionalFoodInformationDataSource({
    required String listingId,
  });

  Future<ServiceListingDetailsModel> fetchAdditionalServiceInformationDataSource({
    required String listingId,
  });

  Future<List<ServiceSlotModel>> saveServiceSlotsDataSource({
    required String listingId,
    required String date,
    required List<Map<String, String>> windows,
  });

  Future<List<DateTime>> fetchServiceAvailableDatesDataSource({
    required String listingId,
    required String fromDate,
    required String toDate,
  });
  Future<List<ServiceSlotModel>> getServiceAvailableSlotsDataSource({
    required String listingId,
    required String date,
  });
  Future<void> deleteServiceSlotsDataSource({required String listingId, required String date});

  Future<void> deleteListingImageDataSource({required String listingId, required String imageId});
}

class SellerListingRemoteDataSourceImpl implements SellerListingRemoteDatasource {
  SellerListingRemoteDataSourceImpl(this._apiClient);
  final ApiClient _apiClient;

  static bool useDummyData = true;

  static final List<SellerListingModel> _dummyListings = [
    SellerListingModel.fromJson({
      "id": "c8099e5b-a354-4e38-8c67-609d2045a60d",
      "sellerId": "087a6434-d6e3-4c58-acec-c1638d8e9bfd",
      "categoryId": "377ecc8c-7405-45c1-b935-c7c160481cac",
      "additionalCategoryIds": [],
      "listingType": "FOOD",
      "title": "Kanda Pohe",
      "description": "Freshly homemade kanda pohe with nuts",
      "basePrice": 45,
      "priceUnit": "Plate",
      "isFree": false,
      "quantityAvailable": 6,
      "availabilityStatus": "AVAILABLE",
      "approvalStatus": "DRAFT",
      "moderationStatus": "PENDING",
      "sponsoredStatus": "NOT_SPONSORED",
      "averageRating": 0.0,
      "totalReviews": 0,
      "tagNames": [
        "breakfast",
        "pohe",
        "poha",
        "nashta",
      ],
      "createdAt": "2026-10-13T10:52:25.512065Z",
      "updatedAt": "2026-10-15T13:59:49.502763Z",
    }),
    SellerListingModel.fromJson({
      "id": "c4b6cb03-683c-4c55-b9ea-c656a430ec33",
      "sellerId": "a5077570-6bf6-4879-9753-478949dd5876",
      "categoryId": "138e46e8-cece-4212-ab4c-4d7102a530f5",
      "additionalCategoryIds": [
        "1365c716-6b84-4bc1-bd6e-d2e71cf049a1",
      ],
      "listingType": "GROCERY",
      "title": "Basmati Rice",
      "description": "Raw Basmati Rice",
      "basePrice": 120,
      "priceUnit": "KG",
      "isFree": false,
      "quantityAvailable": 100,
      "availabilityStatus": "AVAILABLE",
      "approvalStatus": "APPROVED",
      "moderationStatus": "APPROVED",
      "sponsoredStatus": "NOT_SPONSORED",
      "averageRating": 4.5,
      "totalReviews": 8,
      "tagNames": [
        "rice",
        "basmati",
        "chawal",
        "bhat",
      ],
      "createdAt": "2026-10-16T08:38:12.536537Z",
      "updatedAt": "2026-10-16T08:40:17.953191Z",
    }),
    SellerListingModel.fromJson({
      "id": "9b05a332-e24f-4a55-aa6c-a80b57a067d7",
      "sellerId": "a5077570-6bf6-4879-9753-478949dd5876",
      "categoryId": "c90428e0-ccbe-4d4c-b335-72a4c75592ae",
      "additionalCategoryIds": [],
      "listingType": "SERVICE",
      "title": "Ceiling Fan & Appliance Repair",
      "description": "Quick on-demand repair for ceiling fans, switches, and home appliances.",
      "basePrice": 250,
      "priceUnit": "Visit",
      "isFree": false,
      "quantityAvailable": 5,
      "availabilityStatus": "AVAILABLE",
      "approvalStatus": "APPROVED",
      "moderationStatus": "APPROVED",
      "sponsoredStatus": "NOT_SPONSORED",
      "averageRating": 4.8,
      "totalReviews": 12,
      "tagNames": [
        "repair",
        "electrician",
        "fan repair",
      ],
      "createdAt": "2026-10-14T08:00:00.000000Z",
      "updatedAt": "2026-10-16T10:00:00.000000Z",
    }),
    SellerListingModel.fromJson({
      "id": "5baf6f40-ac30-4822-8871-118e7d181e9e",
      "sellerId": "e4a25158-0ff2-4ed2-8cd7-f70c8f98362a",
      "categoryId": "377ecc8c-7405-45c1-b935-c7c160481cac",
      "additionalCategoryIds": [],
      "listingType": "FOOD",
      "title": "Homemade Thepla & Chutney",
      "description": "Fresh and soft methi theplas served with pickle and mango chutney.",
      "basePrice": 80,
      "priceUnit": "Pack",
      "isFree": false,
      "quantityAvailable": 15,
      "availabilityStatus": "AVAILABLE",
      "approvalStatus": "APPROVED",
      "moderationStatus": "APPROVED",
      "sponsoredStatus": "NOT_SPONSORED",
      "averageRating": 4.9,
      "totalReviews": 28,
      "tagNames": ["thepla", "gujarati", "breakfast"],
      "createdAt": "2026-09-04T06:23:58.491876Z",
      "updatedAt": "2026-09-04T09:44:29.763309Z",
    }),
  ];

  static final List<SellerListingImageModel> _dummyListingImages = [
    SellerListingImageModel.fromJson({
      "id": "53894873-cae9-40e6-95e7-2e1961532799",
      "listingId": "c8099e5b-a354-4e38-8c67-609d2045a60d",
      "imageUrl": "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=600",
      "moderationStatus": "APPROVED",
      "displayOrder": 1,
      "createdAt": "2026-09-04T06:36:19.187784Z",
    }),
    SellerListingImageModel.fromJson({
      "id": "02022d55-f4ee-47a7-9bee-c7496273a0ae",
      "listingId": "c4b6cb03-683c-4c55-b9ea-c656a430ec33",
      "imageUrl": "https://images.unsplash.com/photo-1586201375761-83865001e31c?w=600",
      "moderationStatus": "PENDING",
      "displayOrder": 1,
      "createdAt": "2026-10-01T11:03:53.059865Z",
    }),
    SellerListingImageModel.fromJson({
      "id": "f79ceba4-ae54-4408-8056-8633f436a2fe",
      "listingId": "9b05a332-e24f-4a55-aa6c-a80b57a067d7",
      "imageUrl": "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=600",
      "moderationStatus": "APPROVED",
      "displayOrder": 1,
      "createdAt": "2026-09-28T09:59:49.453056Z",
    }),
  ];

  static final Map<String, FoodListingDetailsModel> _dummyFoodDetails = {
    "c8099e5b-a354-4e38-8c67-609d2045a60d": FoodListingDetailsModel.fromJson({
      "id": "a074b48b-7fb8-4c5d-9875-f1a92b6540e1",
      "listingId": "c8099e5b-a354-4e38-8c67-609d2045a60d",
      "preparationTime": "1970-01-01T00:00:20Z",
      "spiceLevel": 3,
      "spiceLevelText": "MEDIUM",
      "freshnessDeclaration": "fresh",
      "isFrozenItem": false,
      "fssaiRequired": true,
      "servingSizes": [
        {
          "id": "5803066e-63a0-4d4f-bb34-8b735c464eba",
          "sizeValue": 1,
          "sizeUnit": "Plate",
          "description": "Half Plate",
          "price": 35,
          "quantityAvailable": 4,
          "isAvailable": true,
        },
        {
          "id": "21ee87cf-0c6c-4f7e-9a78-6585e97f5ba9",
          "sizeValue": 2,
          "sizeUnit": "Plate",
          "description": "Full Plate",
          "price": 55,
          "quantityAvailable": 6,
          "isAvailable": true,
        },
        {
          "id": "5d767518-ed97-45c3-9775-c214e0ef7d11",
          "sizeValue": 1,
          "sizeUnit": "KG",
          "description": "1 KG Pohe",
          "price": 850,
          "quantityAvailable": 0,
          "isAvailable": false,
        },
      ],
    }),
  };

  static final Map<String, ServiceListingDetailsModel> _dummyServiceDetails = {
    "9b05a332-e24f-4a55-aa6c-a80b57a067d7": ServiceListingDetailsModel.fromJson({
      "id": "833e5b98-89f6-47d5-9534-d413c7b9c916",
      "listingId": "9b05a332-e24f-4a55-aa6c-a80b57a067d7",
      "serviceDurationMinutes": 90,
      "serviceLocationType": "COMMON_AREA",
      "homeVisitAvailable": true,
      "onlineAvailable": false,
      "certificateRequired": false,
    }),
  };

  @override
  Future<PageResponse<SellerListingModel>> fetchMyListingDataSource({
    required String sellerId,
  }) async {
    if (useDummyData) {
      return PageResponse<SellerListingModel>(
        content: List.of(_dummyListings),
        page: 0,
        size: 20,
        totalElements: _dummyListings.length,
        totalPages: 1,
        first: true,
        last: true,
      );
    }
    final queryParameters = {'sellerId': sellerId};
    log(
      '[SellerListingDataSource] GET ${ApiEndpoints.myListing} '
      'queryParameters: $queryParameters',
    );
    try {
      final response = await _apiClient.get(ApiEndpoints.myListing, queryParameters: queryParameters);
      return PageResponse.fromJson(
        Map<String, dynamic>.from(response.data as Map),
        SellerListingModel.fromJson,
      );
    } catch (_) {
      return PageResponse<SellerListingModel>(
        content: List.of(_dummyListings),
        page: 0,
        size: 20,
        totalElements: _dummyListings.length,
        totalPages: 1,
        first: true,
        last: true,
      );
    }
  }

  @override
  Future<List<SellerListingImageModel>> getListingImagesDataSource(String listingId) async {
    if (useDummyData) {
      final matches = _dummyListingImages.where((image) => image.listingId == listingId).toList();
      return matches.isNotEmpty ? matches : List.of(_dummyListingImages);
    }
    log('[SellerListingDataSource] GET ${ApiEndpoints.listingImages(listingId)}');
    try {
      final response = await _apiClient.get(ApiEndpoints.listingImages(listingId));
      final images = response.data as List<dynamic>? ?? const [];
      final result = images
          .whereType<Map>()
          .map((image) => SellerListingImageModel.fromJson(Map<String, dynamic>.from(image)))
          .toList()
        ..sort((a, b) => a.displayOrder.compareTo(b.displayOrder));
      return result.isNotEmpty ? result : List.of(_dummyListingImages);
    } catch (_) {
      return List.of(_dummyListingImages);
    }
  }

  @override
  Future<SellerListingModel?> createListingDataSource({
    required SellerListingBasicInfoRequest request,
  }) async {
    if (useDummyData) {
      final newListing = SellerListingModel(
        id: 'lst-${DateTime.now().millisecondsSinceEpoch}',
        sellerId: request.sellerId ?? '087a6434-d6e3-4c58-acec-c1638d8e9bfd',
        categoryId: request.categoryId ?? '377ecc8c-7405-45c1-b935-c7c160481cac',
        additionalCategoryIds: request.additionalCategoryIds ?? [],
        listingType: request.listingType ?? 'FOOD',
        title: request.title ?? 'New Listing',
        description: request.description ?? '',
        basePrice: request.basePrice ?? 45.0,
        priceUnit: request.priceUnit ?? 'Plate',
        isFree: request.isFree ?? false,
        quantityAvailable: request.quantityAvailable ?? 1,
        availabilityStatus: 'AVAILABLE',
        approvalStatus: 'DRAFT',
        moderationStatus: 'PENDING',
        sponsoredStatus: 'NOT_SPONSORED',
        averageRating: 0.0,
        totalReviews: 0,
        tagNames: request.tagNames ?? [],
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );
      _dummyListings.insert(0, newListing);
      return newListing;
    }
    final payload = request.toJson();
    log('[SellerListingDataSource] POST ${ApiEndpoints.listings} payload: $payload');
    try {
      final response = await _apiClient.post(ApiEndpoints.listings, data: payload);
      return SellerListingModel.fromJson(response.data);
    } on DioException catch (e) {
      if (e.response?.statusCode == 404) return null;
      rethrow;
    }
  }

  @override
  Future<SellerListingImageModel> uploadSellerShopImagesDataSource(
    String listingId,
    XFile file,
  ) async {
    if (useDummyData) {
      final newImage = SellerListingImageModel(
        id: 'img-${DateTime.now().millisecondsSinceEpoch}',
        listingId: listingId,
        imageUrl: file.path,
        moderationStatus: 'PENDING',
        displayOrder: _dummyListingImages.length + 1,
        createdAt: DateTime.now(),
      );
      _dummyListingImages.add(newImage);
      return newImage;
    }
    final form = FormData();
    form.files.add(MapEntry('file', await MultipartFile.fromFile(file.path, filename: file.name)));
    form.fields.add(const MapEntry('displayOrder', '1'));
    log(
      '[SellerListingDataSource] POST ${ApiEndpoints.listingImages(listingId)} '
      'payload: file=${file.path}, fields=${form.fields}',
    );
    try {
      final response = await _apiClient.post(ApiEndpoints.listingImages(listingId), data: form);
      return SellerListingImageModel.fromJson(response.data);
    } catch (_) {
      final fallbackImage = SellerListingImageModel(
        id: 'img-${DateTime.now().millisecondsSinceEpoch}',
        listingId: listingId,
        imageUrl: file.path,
        moderationStatus: 'PENDING',
        displayOrder: 1,
        createdAt: DateTime.now(),
      );
      _dummyListingImages.add(fallbackImage);
      return fallbackImage;
    }
  }

  @override
  Future<bool> additionalFoodInformationDataSource({
    required FoodAdditionalInformationRequest request,
    required String listingId,
  }) async {
    if (useDummyData) {
      final foodModel = FoodListingDetailsModel(
        id: 'food-${DateTime.now().millisecondsSinceEpoch}',
        listingId: listingId,
        preparationTime: request.preparationTime ?? '20',
        spiceLevel: request.spiceLevel ?? 3,
        spiceLevelText: request.spiceLevelText ?? 'MEDIUM',
        freshnessDeclaration: request.freshnessDeclaration ?? 'fresh',
        isFrozenItem: request.isFrozenItem ?? false,
        fssaiRequired: request.fssaiRequired == 'true',
        expiryTime: request.expiryTime,
        ingredients: request.ingredients,
        allergens: request.allergens,
        foodType: request.foodType,
        storageInstruction: request.storageInstruction,
        packagingDetails: request.packagingDetails,
        fssaiCertificateId: request.fssaiCertificateId,
        servingSizes: (request.servingSizes ?? [])
            .map(
              (s) => ServingSizeModel(
                id: 'ss-${DateTime.now().millisecondsSinceEpoch}',
                sizeValue: s.sizeValue ?? 1,
                sizeUnit: s.sizeUnit ?? 'Plate',
                description: s.description ?? '',
                price: s.price ?? 0,
                quantityAvailable: s.quantityAvailable ?? 1,
                isAvailable: s.isAvailable ?? true,
              ),
            )
            .toList(),
      );
      _dummyFoodDetails[listingId] = foodModel;
      return true;
    }
    final payload = request.toJson();
    log(
      '[SellerListingDataSource] POST ${ApiEndpoints.listingFoodDetails(listingId)} '
      'payload: $payload',
    );
    try {
      final response = await _apiClient.post(
        ApiEndpoints.listingFoodDetails(listingId),
        data: payload,
      );
      return response.statusCode == 200;
    } on DioException catch (e) {
      if (e.response?.statusCode == 404) return false;
      return true;
    }
  }

  @override
  Future<bool> additionalServiceInformationDataSource({
    required ServiceAdditionalInformationRequest request,
    required String listingId,
  }) async {
    if (useDummyData) {
      final serviceModel = ServiceListingDetailsModel(
        id: 'srv-${DateTime.now().millisecondsSinceEpoch}',
        listingId: listingId,
        serviceDurationMinutes: request.serviceDurationMinutes ?? 90,
        serviceLocationType: request.serviceLocationType ?? 'COMMON_AREA',
        homeVisitAvailable: request.homeVisitAvailable ?? true,
        onlineAvailable: request.onlineAvailable ?? false,
        requiredMaterials: request.requiredMaterials,
        cancellationPolicy: request.cancellationPolicy,
        certificateRequired: request.certificateRequired ?? false,
      );
      _dummyServiceDetails[listingId] = serviceModel;
      return true;
    }
    final payload = request.toJson();
    log(
      '[SellerListingDataSource] POST ${ApiEndpoints.listingServiceDetails(listingId)} '
      'payload: $payload',
    );
    try {
      final response = await _apiClient.post(
        ApiEndpoints.listingServiceDetails(listingId),
        data: payload,
      );
      return response.statusCode == 200;
    } on DioException catch (e) {
      if (e.response?.statusCode == 404) return false;
      return true;
    }
  }

  @override
  Future<SellerListingModel?> submitListingDataSource({required String listingId}) async {
    if (useDummyData) {
      final index = _dummyListings.indexWhere((l) => l.id == listingId);
      if (index != -1) {
        final existing = _dummyListings[index];
        final updated = SellerListingModel(
          id: existing.id,
          sellerId: existing.sellerId,
          categoryId: existing.categoryId,
          additionalCategoryIds: existing.additionalCategoryIds,
          listingType: existing.listingType,
          title: existing.title,
          description: existing.description,
          basePrice: existing.basePrice,
          priceUnit: existing.priceUnit,
          isFree: existing.isFree,
          quantityAvailable: existing.quantityAvailable,
          availabilityStatus: existing.availabilityStatus,
          approvalStatus: 'SUBMITTED',
          moderationStatus: existing.moderationStatus,
          sponsoredStatus: existing.sponsoredStatus,
          averageRating: existing.averageRating,
          totalReviews: existing.totalReviews,
          tagNames: existing.tagNames,
          createdAt: existing.createdAt,
          updatedAt: DateTime.now(),
        );
        _dummyListings[index] = updated;
        return updated;
      }
      return _dummyListings.firstOrNull;
    }
    log('[SellerListingDataSource] POST ${ApiEndpoints.submitListings(listingId)}');
    try {
      final response = await _apiClient.post(ApiEndpoints.submitListings(listingId));
      return SellerListingModel.fromJson(response.data);
    } on DioException catch (e) {
      if (e.response?.statusCode == 404) return null;
      rethrow;
    }
  }

  @override
  Future<SellerListingModel?> updateSubmitListingDataSource({
    required String listingId,
    required SellerListingBasicInfoRequest request,
  }) async {
    if (useDummyData) {
      final index = _dummyListings.indexWhere((l) => l.id == listingId);
      if (index != -1) {
        final existing = _dummyListings[index];
        final updated = SellerListingModel(
          id: existing.id,
          sellerId: existing.sellerId,
          categoryId: request.categoryId ?? existing.categoryId,
          additionalCategoryIds: request.additionalCategoryIds ?? existing.additionalCategoryIds,
          listingType: request.listingType ?? existing.listingType,
          title: request.title ?? existing.title,
          description: request.description ?? existing.description,
          basePrice: request.basePrice ?? existing.basePrice,
          priceUnit: request.priceUnit ?? existing.priceUnit,
          isFree: request.isFree ?? existing.isFree,
          quantityAvailable: request.quantityAvailable ?? existing.quantityAvailable,
          availabilityStatus: existing.availabilityStatus,
          approvalStatus: existing.approvalStatus,
          moderationStatus: existing.moderationStatus,
          sponsoredStatus: existing.sponsoredStatus,
          averageRating: existing.averageRating,
          totalReviews: existing.totalReviews,
          tagNames: request.tagNames ?? existing.tagNames,
          createdAt: existing.createdAt,
          updatedAt: DateTime.now(),
        );
        _dummyListings[index] = updated;
        return updated;
      }
      return null;
    }
    final payload = request.toJson();
    log('[SellerListingDataSource] PATCH ${ApiEndpoints.listing(listingId)} payload: $payload');
    try {
      final response = await _apiClient.patch(ApiEndpoints.listing(listingId), data: payload);
      return SellerListingModel.fromJson(response.data);
    } on DioException catch (e) {
      if (e.response?.statusCode == 404) return null;
      rethrow;
    }
  }

  @override
  Future<SellerListingModel> fetchListingByIdDataSource({required String listingID}) async {
    if (useDummyData) {
      return _dummyListings.firstWhere(
        (l) => l.id == listingID,
        orElse: () => _dummyListings.isNotEmpty ? _dummyListings.first : throw Exception('Listing not found'),
      );
    }
    log('[SellerListingDataSource] GET ${ApiEndpoints.listing(listingID)}');
    try {
      final response = await _apiClient.get(ApiEndpoints.listing(listingID));
      return SellerListingModel.fromJson(response.data);
    } catch (_) {
      return _dummyListings.firstWhere(
        (l) => l.id == listingID,
        orElse: () => _dummyListings.first,
      );
    }
  }

  @override
  Future<FoodListingDetailsModel> fetchAdditionalFoodInformationDataSource({
    required String listingId,
  }) async {
    if (useDummyData) {
      if (_dummyFoodDetails.containsKey(listingId)) {
        return _dummyFoodDetails[listingId]!;
      }
      if (_dummyFoodDetails.isNotEmpty) {
        return _dummyFoodDetails.values.first;
      }
    }
    log('[SellerListingDataSource] GET ${ApiEndpoints.listingFoodDetails(listingId)}');
    try {
      final response = await _apiClient.get(ApiEndpoints.listingFoodDetails(listingId));
      return FoodListingDetailsModel.fromJson(response.data);
    } catch (_) {
      return _dummyFoodDetails[listingId] ??
          _dummyFoodDetails.values.firstOrNull ??
          FoodListingDetailsModel(
            id: 'dummy-food',
            listingId: listingId,
            preparationTime: '1970-01-01T00:00:20Z',
            spiceLevel: 3,
            spiceLevelText: 'MEDIUM',
            freshnessDeclaration: 'fresh',
            isFrozenItem: false,
            fssaiRequired: true,
            servingSizes: [],
          );
    }
  }

  @override
  Future<ServiceListingDetailsModel> fetchAdditionalServiceInformationDataSource({
    required String listingId,
  }) async {
    if (useDummyData) {
      if (_dummyServiceDetails.containsKey(listingId)) {
        return _dummyServiceDetails[listingId]!;
      }
      if (_dummyServiceDetails.isNotEmpty) {
        return _dummyServiceDetails.values.first;
      }
    }
    log('[SellerListingDataSource] GET ${ApiEndpoints.listingServiceDetails(listingId)}');
    try {
      final response = await _apiClient.get(ApiEndpoints.listingServiceDetails(listingId));
      return ServiceListingDetailsModel.fromJson(response.data);
    } catch (_) {
      return _dummyServiceDetails[listingId] ??
          _dummyServiceDetails.values.firstOrNull ??
          ServiceListingDetailsModel(
            id: 'dummy-srv',
            listingId: listingId,
            serviceDurationMinutes: 90,
            serviceLocationType: 'COMMON_AREA',
            homeVisitAvailable: true,
            onlineAvailable: false,
            certificateRequired: false,
          );
    }
  }

  @override
  Future<FoodListingDetailsModel?> updateAdditionalFoodInformationDataSource({
    required FoodAdditionalInformationRequest request,
    required String listingId,
  }) async {
    if (useDummyData) {
      final updated = FoodListingDetailsModel(
        id: 'food-${DateTime.now().millisecondsSinceEpoch}',
        listingId: listingId,
        preparationTime: request.preparationTime ?? '20',
        spiceLevel: request.spiceLevel ?? 3,
        spiceLevelText: request.spiceLevelText ?? 'MEDIUM',
        freshnessDeclaration: request.freshnessDeclaration ?? 'fresh',
        isFrozenItem: request.isFrozenItem ?? false,
        fssaiRequired: request.fssaiRequired == 'true',
        expiryTime: request.expiryTime,
        ingredients: request.ingredients,
        allergens: request.allergens,
        foodType: request.foodType,
        storageInstruction: request.storageInstruction,
        packagingDetails: request.packagingDetails,
        fssaiCertificateId: request.fssaiCertificateId,
        servingSizes: (request.servingSizes ?? [])
            .map(
              (s) => ServingSizeModel(
                id: 'ss-${DateTime.now().millisecondsSinceEpoch}',
                sizeValue: s.sizeValue ?? 1,
                sizeUnit: s.sizeUnit ?? 'Plate',
                description: s.description ?? '',
                price: s.price ?? 0,
                quantityAvailable: s.quantityAvailable ?? 1,
                isAvailable: s.isAvailable ?? true,
              ),
            )
            .toList(),
      );
      _dummyFoodDetails[listingId] = updated;
      return updated;
    }
    final payload = request.toJson();
    log(
      '[SellerListingDataSource] PATCH ${ApiEndpoints.listingFoodDetails(listingId)} '
      'payload: $payload',
    );
    try {
      final response = await _apiClient.patch(
        ApiEndpoints.listingFoodDetails(listingId),
        data: payload,
      );
      if (response.statusCode == 200) {
        return FoodListingDetailsModel.fromJson(response.data);
      } else {
        return null;
      }
    } on DioException catch (e) {
      if (e.response?.statusCode == 404) return null;
      rethrow;
    }
  }

  @override
  Future<ServiceListingDetailsModel?> updateAdditionalServiceInformationDataSource({
    required ServiceAdditionalInformationRequest request,
    required String listingId,
  }) async {
    if (useDummyData) {
      final updated = ServiceListingDetailsModel(
        id: 'srv-${DateTime.now().millisecondsSinceEpoch}',
        listingId: listingId,
        serviceDurationMinutes: request.serviceDurationMinutes ?? 90,
        serviceLocationType: request.serviceLocationType ?? 'COMMON_AREA',
        homeVisitAvailable: request.homeVisitAvailable ?? true,
        onlineAvailable: request.onlineAvailable ?? false,
        requiredMaterials: request.requiredMaterials,
        cancellationPolicy: request.cancellationPolicy,
        certificateRequired: request.certificateRequired ?? false,
      );
      _dummyServiceDetails[listingId] = updated;
      return updated;
    }
    final payload = request.toJson();
    log(
      '[SellerListingDataSource] PATCH ${ApiEndpoints.listingServiceDetails(listingId)} '
      'payload: $payload',
    );
    try {
      final response = await _apiClient.patch(
        ApiEndpoints.listingServiceDetails(listingId),
        data: payload,
      );
      if (response.statusCode == 200) {
        return ServiceListingDetailsModel.fromJson(response.data);
      } else {
        return null;
      }
    } on DioException catch (e) {
      if (e.response?.statusCode == 404) return null;
      rethrow;
    }
  }

  @override
  Future<List<ServiceSlotModel>> saveServiceSlotsDataSource({
    required String listingId,
    required String date,
    required List<Map<String, String>> windows,
  }) async {
    if (useDummyData) {
      final targetDate = DateTime.tryParse(date) ?? DateTime.now();
      final y = targetDate.year;
      final m = targetDate.month;
      final d = targetDate.day;
      return windows.map((w) {
        final startParts = (w['startsAt'] ?? '10:00').split(':');
        final endParts = (w['endsAt'] ?? '11:30').split(':');
        final startH = int.tryParse(startParts[0]) ?? 10;
        final startM = startParts.length > 1 ? (int.tryParse(startParts[1]) ?? 0) : 0;
        final endH = int.tryParse(endParts[0]) ?? 11;
        final endM = endParts.length > 1 ? (int.tryParse(endParts[1]) ?? 30) : 30;
        final startsAt = DateTime(y, m, d, startH, startM);
        final endsAt = DateTime(y, m, d, endH, endM);
        final duration = endsAt.difference(startsAt).inMinutes;
        return ServiceSlotModel(
          startsAt: startsAt,
          endsAt: endsAt,
          durationMinutes: duration > 0 ? duration : 60,
          timeZone: 'Asia/Kolkata',
          status: 'AVAILABLE',
        );
      }).toList();
    }
    final endpoint = ApiEndpoints.serviceAvailability(listingId, date);
    final payload = {'windows': windows};
    log('[SellerListingDataSource] PUT $endpoint payload: $payload');

    final response = await _apiClient.put(endpoint, data: payload);
    log("reponse from wile saving time slots ${response.data} ");
    final data = response.data as List<dynamic>;
    return data.map((item) => ServiceSlotModel.fromJson(Map<String, dynamic>.from(item))).toList();
  }

  @override
  Future<void> deleteServiceSlotsDataSource({
    required String listingId,
    required String date,
  }) async {
    if (useDummyData) return;
    final endpoint = ApiEndpoints.serviceAvailability(listingId, date);
    log('[SellerListingDataSource] DELETE $endpoint');
  }

  @override
  Future<void> deleteListingImageDataSource({
    required String listingId,
    required String imageId,
  }) async {
    if (useDummyData) {
      _dummyListingImages.removeWhere((i) => i.id == imageId);
      return;
    }
    final endpoint = ApiEndpoints.listingImageById(listingId, imageId);
    log('[SellerListingDataSource] DELETE $endpoint');
  }

  @override
  Future<List<ServiceSlotModel>> getServiceAvailableSlotsDataSource({
    required String listingId,
    required String date,
  }) async {
    if (useDummyData) {
      final targetDate = DateTime.tryParse(date) ?? DateTime.now();
      final y = targetDate.year;
      final m = targetDate.month;
      final d = targetDate.day;
      return [
        ServiceSlotModel(
          startsAt: DateTime(y, m, d, 10, 0),
          endsAt: DateTime(y, m, d, 11, 30),
          durationMinutes: 90,
          timeZone: 'Asia/Kolkata',
          status: 'AVAILABLE',
        ),
        ServiceSlotModel(
          startsAt: DateTime(y, m, d, 12, 0),
          endsAt: DateTime(y, m, d, 13, 30),
          durationMinutes: 90,
          timeZone: 'Asia/Kolkata',
          status: 'AVAILABLE',
        ),
        ServiceSlotModel(
          startsAt: DateTime(y, m, d, 14, 0),
          endsAt: DateTime(y, m, d, 15, 30),
          durationMinutes: 90,
          timeZone: 'Asia/Kolkata',
          status: 'AVAILABLE',
        ),
        ServiceSlotModel(
          startsAt: DateTime(y, m, d, 16, 0),
          endsAt: DateTime(y, m, d, 17, 30),
          durationMinutes: 90,
          timeZone: 'Asia/Kolkata',
          status: 'AVAILABLE',
        ),
      ];
    }
    try {
      final response = await _apiClient.get(
        ApiEndpoints.serviceScheduleSlots(listingId),
        queryParameters: {"date": date},
      );
      final slots = response.data;
      if (slots is! List) return const [];
      return slots
          .whereType<Map>()
          .map((slot) => ServiceSlotModel.fromJson(Map<String, dynamic>.from(slot)))
          .where((slot) => slot.isAvailable)
          .toList()
        ..sort((first, second) => first.startsAt.compareTo(second.startsAt));
    } catch (_) {
      final targetDate = DateTime.tryParse(date) ?? DateTime.now();
      final y = targetDate.year;
      final m = targetDate.month;
      final d = targetDate.day;
      return [
        ServiceSlotModel(
          startsAt: DateTime(y, m, d, 10, 0),
          endsAt: DateTime(y, m, d, 11, 30),
          durationMinutes: 90,
          timeZone: 'Asia/Kolkata',
          status: 'AVAILABLE',
        ),
        ServiceSlotModel(
          startsAt: DateTime(y, m, d, 12, 0),
          endsAt: DateTime(y, m, d, 13, 30),
          durationMinutes: 90,
          timeZone: 'Asia/Kolkata',
          status: 'AVAILABLE',
        ),
      ];
    }
  }

  @override
  Future<List<DateTime>> fetchServiceAvailableDatesDataSource({
    required String listingId,
    required String fromDate,
    required String toDate,
  }) async {
    if (useDummyData) {
      final now = DateTime.now();
      return List.generate(
        10,
        (i) => DateTime(now.year, now.month, now.day + i),
      );
    }
    try {
      final response = await _apiClient.get(
        ApiEndpoints.serviceScheduleDates(listingId),
        queryParameters: {'from': fromDate, 'to': toDate},
      );

      log("Reponse for aaialble Date ${response.data}");
      final dates = response.data;
      if (dates is! List) return const [];
      return dates
          .whereType<String>()
          .map(DateTime.tryParse)
          .whereType<DateTime>()
          .map((date) => DateTime(date.year, date.month, date.day))
          .toList();
    } catch (_) {
      final now = DateTime.now();
      return List.generate(
        10,
        (i) => DateTime(now.year, now.month, now.day + i),
      );
    }
  }
}
