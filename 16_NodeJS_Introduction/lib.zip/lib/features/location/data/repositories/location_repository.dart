import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/features/location/data/models/saved_address.dart';

class LocationRepository {
  LocationRepository(this._client);
  final ApiClient _client;

  Future<LocationContext> getContext() async {
    final response = await _client.get(ApiEndpoints.locationContext);
    return LocationContext.fromJson(
      Map<String, dynamic>.from(response.data as Map),
    );
  }

  Future<List<SavedAddress>> getAddresses() async {
    final response = await _client.get(ApiEndpoints.locationAddresses);
    return (response.data as List)
        .whereType<Map>()
        .map((item) => SavedAddress.fromJson(Map<String, dynamic>.from(item)))
        .toList();
  }

  Future<SavedAddress> saveAddress(
    SavedAddress address, {
    bool makeDefault = true,
  }) async {
    final response = await _client.post(
      ApiEndpoints.locationAddresses,
      data: address.toJson(makeDefault: makeDefault),
    );
    return SavedAddress.fromJson(
      Map<String, dynamic>.from(response.data as Map),
    );
  }

  Future<LocationContext> setActive(
    SavedAddress address, {
    int radiusKm = 5,
  }) async {
    final response = await _client.put(
      ApiEndpoints.activeLocation,
      data: {
        'addressId': address.id,
        'discoveryMode': 'NEARBY',
        'radiusKm': radiusKm,
      },
    );
    return LocationContext.fromJson(
      Map<String, dynamic>.from(response.data as Map),
    );
  }

  Future<void> deleteAddress(String id) async {
    await _client.delete(ApiEndpoints.locationAddress(id));
  }

  Future<void> makeDefault(String id) async {
    await _client.patch(
      ApiEndpoints.locationAddress(id),
      data: {'makeDefault': true},
    );
  }
}
