import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/core/network/api_exception.dart';
import 'package:society_seva/features/profile/data/models/update_profile_request.dart';
import 'package:society_seva/features/profile/data/models/phone_number_requests.dart';
import 'package:society_seva/features/profile/data/models/user_profile_model.dart';

abstract class ProfileRemoteDataSource {
  Future<UserProfileModel> getCurrentUser();

  Future<UserProfileModel> updateProfile(UpdateProfileRequest request);

  Future<void> deleteAccount();

  Future<Map<String, dynamic>> sendPhoneNumberOtp(
    SendPhoneNumberOtpRequest request,
  );

  Future<UserProfileModel> verifyPhoneNumberOtp(
    VerifyPhoneNumberOtpRequest request,
  );
}

class ProfileRemoteDataSourceImpl implements ProfileRemoteDataSource {
  ProfileRemoteDataSourceImpl(this._apiClient);

  final ApiClient _apiClient;

  @override
  Future<UserProfileModel> getCurrentUser() async {
    try {
      final response = await _apiClient.get(ApiEndpoints.currentUser);
      return UserProfileModel.fromJson(response.data as Map<String, dynamic>);
    } catch (_) {
      // Dummy profile fallback when login is bypassed or API is unreachable
      return const UserProfileModel(
        id: 'user_dummy_001',
        fullName: 'Rahul Sharma',
        gender: 'MALE',
        dateOfBirth: '1992-05-15',
        mobileNumber: '+91 98765 43210',
        email: 'rahul.sharma@example.com',
        emailVerified: true,
        preferredLanguage: 'English',
        accountStatus: 'ACTIVE',
        roles: ['RESIDENT', 'SELLER'],
      );
    }
  }

  @override
  Future<UserProfileModel> updateProfile(UpdateProfileRequest request) async {
    try {
      final response = await _apiClient.put(
        ApiEndpoints.currentUser,
        data: request.toJson(),
      );
      return UserProfileModel.fromJson(response.data as Map<String, dynamic>);
    } catch (_) {
      return UserProfileModel(
        id: 'user_dummy_001',
        fullName: request.fullName.isNotEmpty ? request.fullName : 'Rahul Sharma',
        gender: request.gender.isNotEmpty ? request.gender : 'MALE',
        dateOfBirth: request.dateOfBirth.isNotEmpty ? request.dateOfBirth : '1992-05-15',
        mobileNumber: '+91 98765 43210',
        email: request.email.isNotEmpty ? request.email : 'rahul.sharma@example.com',
        emailVerified: true,
        preferredLanguage: request.preferredLanguage.isNotEmpty ? request.preferredLanguage : 'English',
        profilePhotoUrl: request.profilePhotoUrl.isNotEmpty ? request.profilePhotoUrl : null,
        accountStatus: 'ACTIVE',
        roles: const ['RESIDENT', 'SELLER'],
      );
    }
  }

  @override
  Future<void> deleteAccount() async {
    await _apiClient.delete(ApiEndpoints.currentUser);
  }

  @override
  Future<Map<String, dynamic>> sendPhoneNumberOtp(
    SendPhoneNumberOtpRequest request,
  ) async {
    final response = await _apiClient.post(
      ApiEndpoints.sendPhoneNumberOtp,
      data: request.toJson(),
    );
    final data = _mapResponse(response.data);
    _throwForEmbeddedError(data);
    return data;
  }

  @override
  Future<UserProfileModel> verifyPhoneNumberOtp(
    VerifyPhoneNumberOtpRequest request,
  ) async {
    final response = await _apiClient.put(
      ApiEndpoints.verifyPhoneNumberOtp,
      data: request.toJson(),
    );
    final data = _mapResponse(response.data);
    _throwForEmbeddedError(data);
    return UserProfileModel.fromJson(data);
  }

  Map<String, dynamic> _mapResponse(Object? data) {
    if (data is! Map) {
      throw const ApiException(
        message: 'The server returned an invalid response.',
      );
    }
    return Map<String, dynamic>.from(data);
  }

  void _throwForEmbeddedError(Map<String, dynamic> data) {
    final status = data['status'];
    final success = data['success'];
    if ((status is num && status >= 400) || success == false) {
      throw ApiException(
        message:
            (data['message'] ?? data['detail'] ?? 'Phone verification failed.')
                .toString(),
        statusCode: status is num ? status.toInt() : null,
        requestId: data['requestId']?.toString(),
      );
    }
  }
}
