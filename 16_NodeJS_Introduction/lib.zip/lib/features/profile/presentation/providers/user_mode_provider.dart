import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/core/storage/secure_storage.dart'; // adjust path

enum UserMode { user, seller }

// Overridden in main() with the saved value.
final initialAppModeProvider = Provider<UserMode>((ref) => UserMode.user);

class UserModeNotifier extends Notifier<UserMode> {
  @override
  UserMode build() => ref.read(initialAppModeProvider);

  Future<void> setMode(UserMode mode) async {
    state = mode;
    await AppSecureStorage().saveUserMode(userMode: mode.name);
  }

  Future<void> reset() async {
    state = UserMode.user;
    await AppSecureStorage().clearUserMode();
  }
}

final userModeProvider = NotifierProvider<UserModeNotifier, UserMode>(UserModeNotifier.new);
