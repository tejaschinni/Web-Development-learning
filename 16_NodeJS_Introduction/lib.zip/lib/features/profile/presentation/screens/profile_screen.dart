import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/features/auth/presentation/providers/auth_provider.dart';
import 'package:society_seva/features/profile/domain/entities/user_profile.dart';
import 'package:society_seva/features/profile/presentation/providers/profile_provider.dart';
import 'package:society_seva/features/profile/presentation/widgets/seller_role_section.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';

class ProfileScreen extends ConsumerStatefulWidget {
  const ProfileScreen({super.key});

  @override
  ConsumerState<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends ConsumerState<ProfileScreen> {
  static const _primary = Color(0xFF176B55);
  static const _background = Color(0xFFF6F8F7);
  static const _border = Color(0xFFE5EAE7);
  static const _text = Color(0xFF202925);
  static const _muted = Color(0xFF78837D);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        ref.read(profileControllerProvider.notifier).load();
        ref.read(mySellerProfileProvider.notifier).fetchMySellerProfile();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(profileControllerProvider);

    final UserProfile? profile = state.profile;

    return Scaffold(backgroundColor: _background, body: _buildBody(context, state, profile));
  }

  Widget _buildProfileActions() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Row(
        children: [
          const Spacer(),
          OutlinedButton.icon(
            onPressed: () => context.push('/profile/edit'),
            icon: const HugeIcon(icon: HugeIcons.strokeRoundedEdit03, size: 17, color: _primary),
            label: Text(
              'Edit profile',
              style: GoogleFonts.hind(fontSize: 14, fontWeight: FontWeight.w600, color: _primary),
            ),
            style: OutlinedButton.styleFrom(
              backgroundColor: Colors.white,
              side: const BorderSide(color: _border),
              minimumSize: const Size(0, 42),
              padding: const EdgeInsets.symmetric(horizontal: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
          ),
          const Gap(8),
          IconButton(
            tooltip: 'Log out',
            onPressed: _logout,
            style: IconButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: _muted,
              minimumSize: const Size(44, 44),
              side: const BorderSide(color: _border),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            icon: const HugeIcon(icon: HugeIcons.strokeRoundedLogout02, size: 19, color: _muted),
          ),
        ],
      ),
    );
  }

  Widget _buildBody(BuildContext context, ProfileState state, UserProfile? profile) {
    if (state.status == ProfileStatus.loading && profile == null) {
      return const Center(child: CircularProgressIndicator(color: _primary));
    }

    if (profile == null) {
      return _ErrorView(
        message: state.errorMessage ?? 'We could not load your profile.',
        onRetry: () => ref.read(profileControllerProvider.notifier).load(force: true),
      );
    }

    final isDeleting = state.status == ProfileStatus.deleting;

    return RefreshIndicator(
      color: _primary,
      onRefresh: () => ref.read(profileControllerProvider.notifier).load(force: true),
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
        children: [
          _buildProfileActions(),

          _ProfileHeader(profile: profile, onEdit: () => context.push('/profile/edit')),
          const Gap(24),

          if (state.errorMessage != null) ...[
            _InlineError(message: state.errorMessage!),
            const Gap(16),
          ],

          _SectionHeading(title: 'Your community', subtitle: 'Get more out of Society Seva.'),
          const Gap(12),
          _ActionCard(
            icon: HugeIcons.strokeRoundedUserGroup,
            title: 'Join my society',
            subtitle: 'Connect with your residential community',
            onTap: () => context.push('/society-onboarding'),
          ),
          const Gap(10),

          SellerRoleSection(),

          const Gap(26),
          _SectionHeading(
            title: 'Orders & payments',
            subtitle: 'Review purchases and payment transactions.',
          ),
          const Gap(12),
          _ActionCard(
            icon: HugeIcons.strokeRoundedShoppingBag01,
            title: 'My orders',
            subtitle: 'View order details and delivery progress',
            onTap: () => context.push('/shop/orders'),
          ),
          const Gap(10),
          _ActionCard(
            icon: HugeIcons.strokeRoundedWallet01,
            title: 'Payment history',
            subtitle: 'View payment methods, amounts, and statuses',
            onTap: () => context.push('/shop/payments'),
          ),

          const Gap(26),
          _SectionHeading(
            title: 'Contact details',
            subtitle: 'How people and Society Seva can reach you.',
          ),
          const Gap(12),
          _SectionCard(
            children: [
              _DetailRow(
                icon: HugeIcons.strokeRoundedMail01,
                label: 'Email address',
                value: profile.email,
              ),
              _CardDivider(),
              _DetailRow(
                icon: HugeIcons.strokeRoundedCall,
                label: 'Mobile number',
                value: profile.mobileNumber,
              ),
            ],
          ),

          const Gap(24),
          _SectionHeading(
            title: 'Personal information',
            subtitle: 'Your profile details and preferences.',
          ),
          const Gap(12),
          _SectionCard(
            children: [
              _DetailRow(icon: HugeIcons.strokeRoundedUser, label: 'Gender', value: profile.gender),
              _CardDivider(),
              _DetailRow(
                icon: HugeIcons.strokeRoundedCalendar03,
                label: 'Date of birth',
                value: profile.dateOfBirth,
              ),
              _CardDivider(),
              _DetailRow(
                icon: HugeIcons.strokeRoundedLanguageCircle,
                label: 'App language',
                value: _languageName(profile.preferredLanguage),
              ),
            ],
          ),

          const Gap(24),
          _SectionHeading(title: 'Account', subtitle: 'Your account status and access.'),
          const Gap(12),
          _SectionCard(
            children: [
              _DetailRow(
                icon: HugeIcons.strokeRoundedShield01,
                label: 'Account status',
                value: profile.accountStatus,
                valueColor: _statusColor(profile.accountStatus),
              ),
              _CardDivider(),
              _RolesRow(roles: profile.roles),
            ],
          ),

          const Gap(28),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFFFFF6F5),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFFF4DEDB)),
            ),
            child: Row(
              children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: const Color(0xFFFBE4E1),
                    borderRadius: BorderRadius.circular(13),
                  ),
                  child: const Center(
                    child: HugeIcon(
                      icon: HugeIcons.strokeRoundedDelete02,
                      color: Color(0xFFB42318),
                      size: 22,
                    ),
                  ),
                ),
                const Gap(12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Delete account',
                        style: GoogleFonts.hind(
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                          color: const Color(0xFFB42318),
                        ),
                      ),
                      Text(
                        'Permanently remove your account',
                        style: GoogleFonts.hind(fontSize: 12, color: _muted),
                      ),
                    ],
                  ),
                ),
                TextButton(
                  onPressed: isDeleting ? null : () => _confirmDelete(context),
                  child: Text(
                    isDeleting ? 'Deleting…' : 'Delete',
                    style: GoogleFonts.hind(
                      fontWeight: FontWeight.w600,
                      color: const Color(0xFFB42318),
                    ),
                  ),
                ),
              ],
            ),
          ),

          const Gap(24),
          Center(
            child: Column(
              children: [
                const HugeIcon(icon: HugeIcons.strokeRoundedHome01, color: _primary, size: 23),
                const Gap(6),
                Text(
                  'Society Seva',
                  style: GoogleFonts.hind(fontSize: 14, fontWeight: FontWeight.w600, color: _text),
                ),
                Text(
                  'Your community, closer together.',
                  style: GoogleFonts.hind(fontSize: 12, color: _muted),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _logout() async {
    final shouldLogout = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text('Log out?', style: GoogleFonts.hind(fontWeight: FontWeight.w700)),
        content: Text('Are you sure you want to log out?', style: GoogleFonts.hind()),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: Text('Cancel', style: GoogleFonts.hind()),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: Text('Logout', style: GoogleFonts.hind()),
          ),
        ],
      ),
    );

    if (shouldLogout != true || !mounted) return;

    final failureMessage = await ref.read(authControllerProvider.notifier).logout();

    if (!mounted) return;

    if (failureMessage != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Signed out locally, but server logout failed: $failureMessage',
            style: GoogleFonts.hind(),
          ),
        ),
      );
    }
  }

  String _languageName(String code) {
    const languages = {'en': 'English', 'hi': 'हिन्दी (Hindi)', 'mr': 'मराठी (Marathi)'};

    return languages[code.toLowerCase()] ?? code;
  }

  Color _statusColor(String status) {
    switch (status.toUpperCase()) {
      case 'ACTIVE':
        return const Color(0xFF16804A);
      case 'PENDING':
        return const Color(0xFFAA6A08);
      case 'SUSPENDED':
      case 'BLOCKED':
      case 'DELETED':
        return const Color(0xFFB42318);
      default:
        return _text;
    }
  }

  Future<void> _confirmDelete(BuildContext context) async {
    final shouldDelete = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        icon: const HugeIcon(
          icon: HugeIcons.strokeRoundedDelete02,
          size: 34,
          color: Color(0xFFB42318),
        ),
        title: Text('Delete your account?', style: GoogleFonts.hind(fontWeight: FontWeight.w700)),
        content: Text(
          'This permanently deletes your Society Seva account. '
          'This action cannot be undone.',
          style: GoogleFonts.hind(color: _muted),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: Text('Cancel', style: GoogleFonts.hind()),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFFB42318)),
            child: Text('Delete account', style: GoogleFonts.hind(fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );

    if (shouldDelete != true || !mounted) return;

    final deleted = await ref.read(profileControllerProvider.notifier).deleteAccount();

    if (deleted && mounted) {
      this.context.go('/login');
    }
  }
}

class _ProfileHeader extends StatelessWidget {
  const _ProfileHeader({required this.profile, required this.onEdit});

  final UserProfile profile;
  final VoidCallback onEdit;

  static const _primary = Color(0xFF176B55);
  static const _text = Color(0xFF202925);
  static const _muted = Color(0xFF78837D);

  @override
  Widget build(BuildContext context) {
    final photoUrl = profile.profilePhotoUrl;
    final hasPhoto = photoUrl != null && photoUrl.isNotEmpty;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 26, 20, 24),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFE7F3EB), Color(0xFFF5F8F4)],
        ),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: const Color(0xFFDCE9E0)),
      ),
      child: Column(
        children: [
          GestureDetector(
            onTap: hasPhoto ? () => _showFullPhoto(context, photoUrl) : null,
            child: Container(
              width: 108,
              height: 108,
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 3),
                boxShadow: [
                  BoxShadow(
                    color: _primary.withValues(alpha: 0.10),
                    blurRadius: 18,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: ClipOval(
                child: hasPhoto
                    ? Image.network(
                        photoUrl,
                        fit: BoxFit.cover,
                        errorBuilder: (_, _, _) => _placeholder(),
                      )
                    : _placeholder(),
              ),
            ),
          ),
          const Gap(16),
          Text(
            profile.fullName.isEmpty ? 'Society Seva member' : profile.fullName,
            textAlign: TextAlign.center,
            style: GoogleFonts.hind(
              fontSize: 25,
              height: 1.3,
              fontWeight: FontWeight.w700,
              color: _text,
            ),
          ),
          const Gap(5),
          Text(
            'Society Seva member',
            textAlign: TextAlign.center,
            style: GoogleFonts.hind(fontSize: 14, color: _muted),
          ),
        ],
      ),
    );
  }

  void _showFullPhoto(BuildContext context, String? photoUrl) {
    if (photoUrl == null || photoUrl.isEmpty) return;

    showDialog<void>(
      context: context,
      barrierColor: Colors.black87,
      builder: (dialogContext) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(16),
        child: Stack(
          alignment: Alignment.topRight,
          children: [
            Center(
              child: InteractiveViewer(
                minScale: 0.8,
                maxScale: 4,
                child: Image.network(
                  photoUrl,
                  fit: BoxFit.contain,
                  errorBuilder: (_, _, _) =>
                      const Icon(Icons.broken_image_outlined, color: Colors.white, size: 56),
                ),
              ),
            ),
            IconButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              icon: const Icon(Icons.close_rounded, color: Colors.white, size: 28),
              tooltip: 'Close photo',
            ),
          ],
        ),
      ),
    );
  }

  Widget _placeholder() {
    return Container(
      color: const Color(0xFFDCEBE0),
      alignment: Alignment.center,
      child: const HugeIcon(icon: HugeIcons.strokeRoundedUser, size: 48, color: _primary),
    );
  }
}

class _SectionHeading extends StatelessWidget {
  const _SectionHeading({required this.title, required this.subtitle});

  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: GoogleFonts.hind(
            fontSize: 19,
            fontWeight: FontWeight.w700,
            color: const Color(0xFF202925),
          ),
        ),
        const Gap(2),
        Text(subtitle, style: GoogleFonts.hind(fontSize: 13, color: const Color(0xFF78837D))),
      ],
    );
  }
}

class _ActionCard extends StatelessWidget {
  const _ActionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final dynamic icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Color(0xFFE5EAE7)),
          ),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: const Color(0xFFE8F2EB),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Center(
                  child: HugeIcon(icon: icon, size: 24, color: const Color(0xFF176B55)),
                ),
              ),
              const Gap(14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: GoogleFonts.hind(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: const Color(0xFF202925),
                      ),
                    ),
                    const Gap(2),
                    Text(
                      subtitle,
                      style: GoogleFonts.hind(fontSize: 12, color: const Color(0xFF78837D)),
                    ),
                  ],
                ),
              ),
              const Gap(8),
              const Icon(Icons.arrow_forward_ios_rounded, size: 16, color: Color(0xFF78837D)),
            ],
          ),
        ),
      ),
    );
  }
}

class _SectionCard extends StatelessWidget {
  const _SectionCard({required this.children});

  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFFE5EAE7)),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF1D392B).withValues(alpha: 0.025),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(children: children),
    );
  }
}

class _DetailRow extends StatelessWidget {
  const _DetailRow({required this.icon, required this.label, required this.value, this.valueColor});

  final dynamic icon;
  final String label;
  final String value;
  final Color? valueColor;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 15),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: const Color(0xFFF0F5F1),
              borderRadius: BorderRadius.circular(13),
            ),
            child: Center(
              child: HugeIcon(icon: icon, size: 20, color: const Color(0xFF176B55)),
            ),
          ),
          const Gap(12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: GoogleFonts.hind(fontSize: 12, color: const Color(0xFF78837D))),
                const Gap(3),
                Text(
                  value.isEmpty ? 'Not provided' : value,
                  style: GoogleFonts.hind(
                    fontSize: 15,
                    fontWeight: FontWeight.w500,
                    color: valueColor ?? const Color(0xFF202925),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _CardDivider extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return const Divider(height: 1, thickness: 1, indent: 52, color: Color(0xFFEFF1EF));
  }
}

class _RolesRow extends StatelessWidget {
  const _RolesRow({required this.roles});

  final List<String> roles;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 15),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: const Color(0xFFF0F5F1),
              borderRadius: BorderRadius.circular(13),
            ),
            child: const Center(
              child: HugeIcon(
                icon: HugeIcons.strokeRoundedShield01,
                size: 20,
                color: Color(0xFF176B55),
              ),
            ),
          ),
          const Gap(12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Your roles',
                  style: GoogleFonts.hind(fontSize: 12, color: const Color(0xFF78837D)),
                ),
                const Gap(8),
                if (roles.isEmpty)
                  Text(
                    'No roles assigned',
                    style: GoogleFonts.hind(fontSize: 14, color: const Color(0xFF202925)),
                  )
                else
                  Wrap(
                    spacing: 7,
                    runSpacing: 7,
                    children: roles.map((role) {
                      return Container(
                        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE8F2EB),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          _formatRole(role),
                          style: GoogleFonts.hind(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: const Color(0xFF176B55),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _formatRole(String role) {
    return role
        .replaceAll('_', ' ')
        .toLowerCase()
        .split(' ')
        .map((word) => word.isEmpty ? word : '${word[0].toUpperCase()}${word.substring(1)}')
        .join(' ');
  }
}

class _InlineError extends StatelessWidget {
  const _InlineError({required this.message});

  final String message;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF0EF),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: const Color(0xFFF4DEDB)),
      ),
      child: Row(
        children: [
          const HugeIcon(
            icon: HugeIcons.strokeRoundedAlertSquare,
            color: Color(0xFFB42318),
            size: 22,
          ),
          const Gap(10),
          Expanded(
            child: Text(
              message,
              style: GoogleFonts.hind(fontSize: 13, color: const Color(0xFFB42318)),
            ),
          ),
        ],
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.message, required this.onRetry});

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 88,
              height: 88,
              decoration: BoxDecoration(
                color: const Color(0xFFE8F2EB),
                borderRadius: BorderRadius.circular(28),
              ),
              child: const Center(
                child: HugeIcon(
                  icon: HugeIcons.strokeRoundedCloudOff,
                  size: 42,
                  color: Color(0xFF176B55),
                ),
              ),
            ),
            const Gap(20),
            Text(
              'Something went wrong',
              style: GoogleFonts.hind(
                fontSize: 21,
                fontWeight: FontWeight.w700,
                color: const Color(0xFF202925),
              ),
            ),
            const Gap(8),
            Text(
              message,
              textAlign: TextAlign.center,
              style: GoogleFonts.hind(fontSize: 14, color: const Color(0xFF78837D)),
            ),
            const Gap(22),
            FilledButton.icon(
              onPressed: onRetry,
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFF176B55),
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 13),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              icon: const HugeIcon(
                icon: HugeIcons.strokeRoundedRefresh01,
                color: Colors.white,
                size: 19,
              ),
              label: Text(
                'Try again',
                style: GoogleFonts.hind(fontWeight: FontWeight.w600, color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
