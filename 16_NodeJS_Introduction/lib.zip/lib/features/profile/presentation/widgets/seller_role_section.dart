import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:society_seva/features/profile/presentation/providers/user_mode_provider.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/seller/domain/enum/seller_account_status.dart';

class SellerRoleSection extends ConsumerWidget {
  const SellerRoleSection({super.key});

  static const _textPrimary = Color(0xFF202925);
  static const _textSecondary = Color(0xFF78837D);
  static const _borderColor = Color(0xFFE5EAE7);
  static const _iconBackground = Color(0xFFE8F2EB);
  static const _iconColor = Color(0xFF176B55);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sellerAsync = ref.watch(mySellerProfileProvider);

    return sellerAsync.when(
      loading: () => const SizedBox.shrink(),
      error: (_, _) => _buildActionCard(
        icon: Icons.storefront_outlined,
        title: 'Become a seller',
        onTap: () {
          context.push('/modules/seller/onboarding', extra: false);
        },
      ),
      data: (seller) {
        final status = seller?.approvalStatus;

        if (status == 'APPROVED') {
          return Consumer(
            builder: (context, ref, _) {
              final isSeller = ref.watch(userModeProvider) == UserMode.seller;

              return _buildSellerModeCard(context: context, ref: ref, isSeller: isSeller);
            },
          );
        }

        final (title, subtitle, icon) = switch (status?.toUpperCase()) {
          'DRAFT' || 'DRAFTED' => ('Complete seller application', 'Draft saved', Icons.edit_note),
          'PENDING' => (
            'Seller application',
            'Submitted, waiting for approval',
            Icons.hourglass_top,
          ),
          'SUBMITTED' => (
            'Seller application',
            'Submitted, waiting for approval',
            Icons.hourglass_top,
          ),
          'REJECTED' => (
            'Seller application',
            'Rejected. Update and resubmit',
            Icons.error_outline,
          ),
          _ => (
            'Become a seller',
            'Offer products and services locally',
            Icons.storefront_outlined,
          ),
        };

        return _buildActionCard(
          icon: icon,
          title: title,
          subtitle: subtitle,
          onTap: () {
            final upper = status?.toUpperCase();
            if (upper == 'SUBMITTED' ||
                upper == 'PENDING' ||
                upper == 'UNDER_REVIEW' ||
                upper == 'REJECTED') {
              context.push('/modules/seller/status', extra: SellerAccountStatus.fromString(status));
            } else {
              context.push('/modules/seller/onboarding', extra: true);
            }
          },
        );
      },
    );
  }

  Widget _buildActionCard({
    required IconData icon,
    required String title,
    String? subtitle,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _borderColor),
          ),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: _iconBackground,
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Center(child: Icon(icon, size: 24, color: _iconColor)),
              ),
              const Gap(14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: GoogleFonts.hind(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: _textPrimary,
                      ),
                    ),
                    if (subtitle != null) ...[
                      const Gap(2),
                      Text(subtitle, style: GoogleFonts.hind(fontSize: 12, color: _textSecondary)),
                    ],
                  ],
                ),
              ),
              const Gap(8),
              const Icon(Icons.arrow_forward_ios_rounded, size: 16, color: _textSecondary),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSellerModeCard({
    required BuildContext context,
    required WidgetRef ref,
    required bool isSeller,
  }) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _borderColor),
        ),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: _iconBackground,
                borderRadius: BorderRadius.circular(15),
              ),
              child: const Center(child: Icon(Icons.swap_horiz, size: 24, color: _iconColor)),
            ),
            const Gap(14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Seller mode',
                    style: GoogleFonts.hind(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      color: _textPrimary,
                    ),
                  ),
                  const Gap(2),
                  Text(
                    isSeller
                        ? 'You are using the seller dashboard'
                        : 'Switch to your seller dashboard',
                    style: GoogleFonts.hind(fontSize: 12, color: _textSecondary),
                  ),
                ],
              ),
            ),
            const Gap(8),
            Switch.adaptive(
              value: isSeller,
              activeTrackColor: _iconColor,
              onChanged: (value) async {
                // Preserve the existing mode persistence and navigation.
                await ref
                    .read(userModeProvider.notifier)
                    .setMode(value ? UserMode.seller : UserMode.user);

                if (!context.mounted) return;

                if (value) {
                  context.go('/modules/seller/sellerDashboard');
                } else {
                  context.go('/');
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}
