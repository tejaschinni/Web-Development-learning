import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/shop/domain/entities/shop_seller.dart';

class ShopSellerRemoteDataSource {
  const ShopSellerRemoteDataSource({required this.apiClient});

  final ApiClient apiClient;

  Future<PageResponse<ShopSeller>> getSellers({
    required String societyId,
    required PageableQuery pageable,
  }) async {
    final response = await apiClient.get(
      ApiEndpoints.sellers,
      queryParameters: {
        if (societyId.isNotEmpty) 'societyId': societyId,
        ...pageable.toQueryParameters(),
      },
    );

    return PageResponse.fromJson(
      Map<String, dynamic>.from(response.data as Map),
      ShopSeller.fromJson,
    );
  }
}
