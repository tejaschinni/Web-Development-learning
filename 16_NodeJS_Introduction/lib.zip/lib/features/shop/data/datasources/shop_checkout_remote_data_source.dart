import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/shop/data/models/shop_checkout_models.dart';

class ShopCheckoutRemoteDataSource {
  const ShopCheckoutRemoteDataSource({required this.apiClient});

  final ApiClient apiClient;

  Future<ShopDeliveryOptions> getDeliveryOptions({
    required String sellerId,
    String? addressId,
    String? orderType,
  }) async {
    final response = await apiClient.get(
      ApiEndpoints.deliveryOptions,
      queryParameters: {
        'sellerId': sellerId,
        if (addressId != null && addressId.isNotEmpty) 'addressId': addressId,
        if (orderType != null && orderType.isNotEmpty) 'orderType': orderType,
      },
    );
    return ShopDeliveryOptions.fromJson(Map<String, dynamic>.from(response.data as Map));
  }

  Future<ShopOrderResult> checkoutOrder({
    required String cartId,
    required String fulfillmentMethod,
    String? deliveryAddressId,
    DateTime? scheduledAt,
    String? buyerNote,
  }) async {
    final response = await apiClient.post(
      ApiEndpoints.checkoutOrder,
      queryParameters: {'cartId': cartId},
      data: {
        'fulfillmentMethod': fulfillmentMethod,
        if (deliveryAddressId != null && deliveryAddressId.isNotEmpty)
          'deliveryAddressId': deliveryAddressId,
        if (scheduledAt != null) 'scheduledAt': scheduledAt.toUtc().toIso8601String(),
        if (buyerNote != null && buyerNote.trim().isNotEmpty) 'buyerNote': buyerNote.trim(),
      },
    );
    return ShopOrderResult.fromJson(Map<String, dynamic>.from(response.data as Map));
  }

  Future<ShopPaymentResult> createCashPayment({required String orderId}) async {
    final response = await apiClient.post(
      ApiEndpoints.payments,
      data: {'orderId': orderId, 'paymentMethod': 'CASH'},
    );
    return ShopPaymentResult.fromJson(Map<String, dynamic>.from(response.data as Map));
  }

  Future<ShopPaymentResult> getPayment(String paymentId) async {
    final response = await apiClient.get(ApiEndpoints.payment(paymentId));
    return ShopPaymentResult.fromJson(Map<String, dynamic>.from(response.data as Map));
  }

  Future<List<ShopOrderResult>> getMyOrders() async {
    final orders = <ShopOrderResult>[];
    var pageNumber = 0;
    while (true) {
      final response = await apiClient.get(
        ApiEndpoints.myOrders,
        queryParameters: {'page': pageNumber, 'size': 50},
      );
      if (response.data is List) {
        orders.addAll(
          (response.data as List).whereType<Map>().map(
            (order) => ShopOrderResult.fromJson(Map<String, dynamic>.from(order)),
          ),
        );
        return orders;
      }
      final page = PageResponse.fromJson(
        Map<String, dynamic>.from(response.data as Map),
        ShopOrderResult.fromJson,
      );
      orders.addAll(page.content);
      if (page.last || page.content.isEmpty) return orders;
      pageNumber++;
    }
  }

  Future<List<ShopPaymentResult>> getMyPayments() async {
    final payments = <ShopPaymentResult>[];
    var pageNumber = 0;
    while (true) {
      final response = await apiClient.get(
        ApiEndpoints.myPayments,
        queryParameters: {'page': pageNumber, 'size': 50},
      );
      if (response.data is List) {
        payments.addAll(
          (response.data as List).whereType<Map>().map(
            (payment) => ShopPaymentResult.fromJson(Map<String, dynamic>.from(payment)),
          ),
        );
        return payments;
      }
      final page = PageResponse.fromJson(
        Map<String, dynamic>.from(response.data as Map),
        ShopPaymentResult.fromJson,
      );
      payments.addAll(page.content);
      if (page.last || page.content.isEmpty) return payments;
      pageNumber++;
    }
  }

  Future<List<ShopOrderHistoryEntry>> getOrderHistory(String orderId) async {
    final response = await apiClient.get(ApiEndpoints.orderStatusHistory(orderId));
    return (response.data as List)
        .whereType<Map>()
        .map((entry) => ShopOrderHistoryEntry.fromJson(Map<String, dynamic>.from(entry)))
        .toList();
  }

  Future<ShopDeliveryReceipt> confirmReceipt(String orderId) async {
    final response = await apiClient.post(ApiEndpoints.confirmOrderReceipt(orderId));
    return ShopDeliveryReceipt.fromJson(Map<String, dynamic>.from(response.data as Map));
  }
}
