import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/features/shop/domain/entities/shop_cart.dart';

class ShopCartRemoteDataSource {
  const ShopCartRemoteDataSource({required this.apiClient});

  final ApiClient apiClient;

  Future<ShopCart> getCart() async {
    final response = await apiClient.get(ApiEndpoints.cart);
    return ShopCart.fromJson(Map<String, dynamic>.from(response.data as Map));
  }

  Future<ShopCart> addItem({
    required String listingId,
    required int quantity,
    required bool replaceExistingCart,
    String? foodServingSizeId,
  }) async {
    final body = <String, dynamic>{
      'listingId': listingId,
      'quantity': quantity,
      'replaceExistingCart': replaceExistingCart ? 'true' : 'false',
      'foodServingSizeId': ?foodServingSizeId,
    };
    final response = await apiClient.post(ApiEndpoints.cartItems, data: body);
    return ShopCart.fromJson(Map<String, dynamic>.from(response.data as Map));
  }

  Future<ShopCart> updateItemQuantity({required String itemId, required int quantity}) async {
    final response = await apiClient.patch(
      ApiEndpoints.cartItem(itemId),
      data: {'quantity': quantity.toString()},
    );
    return ShopCart.fromJson(Map<String, dynamic>.from(response.data as Map));
  }

  Future<void> deleteItem(String itemId) async {
    await apiClient.delete(ApiEndpoints.cartItem(itemId));
  }

  Future<void> deleteCart() async {
    await apiClient.delete(ApiEndpoints.cart);
  }
}
