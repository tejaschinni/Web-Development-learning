import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing_details.dart';

class ShopListingRemoteDataSource {
  const ShopListingRemoteDataSource({required this.apiClient});

  final ApiClient apiClient;

  Future<PageResponse<ShopListing>> getListings({
    required String societyId,
    required PageableQuery pageable,
  }) async {
    final response = await apiClient.get(
      ApiEndpoints.listings,
      queryParameters: {
        if (societyId.isNotEmpty) 'societyId': societyId,
        ...pageable.toQueryParameters(),
      },
    );

    return PageResponse.fromJson(
      Map<String, dynamic>.from(response.data as Map),
      ShopListing.fromJson,
    );
  }

  Future<PageResponse<ShopListing>> getCategoryListings({
    required String categoryId,
    required String societyId,
    required PageableQuery pageable,
  }) async {
    final response = await apiClient.get(
      ApiEndpoints.discoverListings(categoryId),
      queryParameters: {
        if (societyId.isNotEmpty) 'societyId': societyId,
        ...pageable.toQueryParameters(),
      },
    );

    return PageResponse.fromJson(
      Map<String, dynamic>.from(response.data as Map),
      ShopListing.fromJson,
    );
  }

  Future<PageResponse<ShopListing>> searchListings({
    required String query,
    String? categoryId,
    String? societyId,
    String? sellerId,
    String? listingType,
    double? minPrice,
    double? maxPrice,
    bool? isFree,
    double? minRating,
    String? availabilityStatus,
    bool? inStockOnly,
    bool? sponsoredOnly,
    String? foodType,
    bool? isFrozen,
    String? sortBy,
    required PageableQuery pageable,
  }) async {
    final response = await apiClient.get(
      ApiEndpoints.searchListings,
      queryParameters: {
        if (query.trim().isNotEmpty) 'query': query.trim(),
        'categoryId': ?categoryId,
        'societyId': ?societyId,
        'sellerId': ?sellerId,
        'listingType': ?listingType,
        'minPrice': ?minPrice,
        'maxPrice': ?maxPrice,
        'isFree': ?isFree,
        'minRating': ?minRating,
        'availabilityStatus': ?availabilityStatus,
        'inStockOnly': ?inStockOnly,
        'sponsoredOnly': ?sponsoredOnly,
        'foodType': ?foodType,
        'isFrozen': ?isFrozen,
        'sortBy': ?sortBy,
        ...pageable.toQueryParameters(),
      },
    );
    return PageResponse.fromJson(
      Map<String, dynamic>.from(response.data as Map),
      ShopListing.fromJson,
    );
  }

  Future<List<String>> getRecentSearches() async {
    final response = await apiClient.get(
      ApiEndpoints.recentSearches,
      queryParameters: {'limit': 10},
    );
    final data = response.data;
    return data is List
        ? data
              .whereType<Map>()
              .map((item) => (item['searchQuery'] ?? '').toString())
              .where((query) => query.isNotEmpty)
              .toList()
        : const [];
  }

  Future<void> deleteRecentSearch(String query) async {
    await apiClient.delete(ApiEndpoints.searchHistory, queryParameters: {'query': query});
  }

  Future<void> clearRecentSearches() async {
    await apiClient.delete(ApiEndpoints.searchHistory);
  }

  Future<ShopListing> getListing({required String listingId}) async {
    final response = await apiClient.get(ApiEndpoints.listing(listingId));

    return ShopListing.fromJson(Map<String, dynamic>.from(response.data as Map));
  }

  Future<PageResponse<ShopListing>> getSellerListings({
    required String sellerId,
    required PageableQuery pageable,
  }) async {
    final response = await apiClient.get(
      ApiEndpoints.sellerListings(sellerId),
      queryParameters: pageable.toQueryParameters(),
    );
    return PageResponse.fromJson(
      Map<String, dynamic>.from(response.data as Map),
      ShopListing.fromJson,
    );
  }

  Future<List<ShopListingImage>> getListingImages(String listingId) async {
    final response = await apiClient.get(ApiEndpoints.listingImages(listingId));
    final images = response.data as List<dynamic>? ?? const [];
    return images
        .whereType<Map>()
        .map((image) => ShopListingImage.fromJson(Map<String, dynamic>.from(image)))
        .toList()
      ..sort((a, b) => a.displayOrder.compareTo(b.displayOrder));
  }

  Future<ShopFoodDetails> getFoodDetails(String listingId) async {
    final response = await apiClient.get(ApiEndpoints.listingFoodDetails(listingId));
    return ShopFoodDetails.fromJson(Map<String, dynamic>.from(response.data as Map));
  }

  Future<ShopServiceDetails> getServiceDetails(String listingId) async {
    final response = await apiClient.get(ApiEndpoints.listingServiceDetails(listingId));
    return ShopServiceDetails.fromJson(Map<String, dynamic>.from(response.data as Map));
  }

  Future<List<DateTime>> getServiceAvailableDates({
    required String listingId,
    required String from,
    required String to,
  }) async {
    final response = await apiClient.get(
      ApiEndpoints.serviceScheduleDates(listingId),
      queryParameters: {'from': from, 'to': to},
    );
    final dates = response.data;
    if (dates is! List) return const [];
    return dates
        .whereType<String>()
        .map(DateTime.tryParse)
        .whereType<DateTime>()
        .map((date) => DateTime(date.year, date.month, date.day))
        .toList();
  }

  Future<List<ServiceScheduleSlot>> getServiceAvailableSlots({
    required String listingId,
    required String date,
  }) async {
    final response = await apiClient.get(
      ApiEndpoints.serviceScheduleSlots(listingId),
      queryParameters: {'date': date},
    );
    final slots = response.data;
    if (slots is! List) return const [];
    return slots
        .whereType<Map>()
        .map((slot) => ServiceScheduleSlot.fromJson(Map<String, dynamic>.from(slot)))
        .where((slot) => slot.isAvailable)
        .toList()
      ..sort((first, second) => first.startsAt.compareTo(second.startsAt));
  }
}
