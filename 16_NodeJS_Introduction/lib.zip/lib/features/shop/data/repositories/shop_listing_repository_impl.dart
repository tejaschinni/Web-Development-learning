import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/shop/data/datasources/shop_listing_remote_data_source.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing_details.dart';
import 'package:society_seva/features/shop/domain/repositories/shop_listing_repository.dart';

class ShopListingRepositoryImpl implements ShopListingRepository {
  const ShopListingRepositoryImpl({required this.remoteDataSource});

  final ShopListingRemoteDataSource remoteDataSource;

  @override
  Future<PageResponse<ShopListing>> getListings({
    required String societyId,
    required PageableQuery pageable,
  }) {
    return remoteDataSource.getListings(societyId: societyId, pageable: pageable);
  }

  @override
  Future<PageResponse<ShopListing>> getCategoryListings({
    required String categoryId,
    required String societyId,
    required PageableQuery pageable,
  }) {
    return remoteDataSource.getCategoryListings(
      categoryId: categoryId,
      societyId: societyId,
      pageable: pageable,
    );
  }

  @override
  Future<PageResponse<ShopListing>> searchListings({required String query, String? categoryId, String? societyId, String? sellerId, String? listingType, double? minPrice, double? maxPrice, bool? isFree, double? minRating, String? availabilityStatus, bool? inStockOnly, bool? sponsoredOnly, String? foodType, bool? isFrozen, String? sortBy, required PageableQuery pageable}) =>
      remoteDataSource.searchListings(query: query, categoryId: categoryId, societyId: societyId, sellerId: sellerId, listingType: listingType, minPrice: minPrice, maxPrice: maxPrice, isFree: isFree, minRating: minRating, availabilityStatus: availabilityStatus, inStockOnly: inStockOnly, sponsoredOnly: sponsoredOnly, foodType: foodType, isFrozen: isFrozen, sortBy: sortBy, pageable: pageable);

  @override
  Future<List<String>> getRecentSearches() => remoteDataSource.getRecentSearches();

  @override
  Future<void> deleteRecentSearch(String query) => remoteDataSource.deleteRecentSearch(query);

  @override
  Future<void> clearRecentSearches() => remoteDataSource.clearRecentSearches();

  @override
  Future<ShopListing> getListing(String listingId) {
    return remoteDataSource.getListing(listingId: listingId);
  }

  @override
  Future<List<ShopListingImage>> getListingImages(String listingId) {
    return remoteDataSource.getListingImages(listingId);
  }

  @override
  Future<ShopFoodDetails> getFoodDetails(String listingId) {
    return remoteDataSource.getFoodDetails(listingId);
  }

  @override
  Future<ShopServiceDetails> getServiceDetails(String listingId) {
    return remoteDataSource.getServiceDetails(listingId);
  }
}
