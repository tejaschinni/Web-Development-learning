import 'package:flutter/foundation.dart';

@immutable
class ServiceBookingSelection {
  const ServiceBookingSelection({
    required this.listingId,
    required this.serviceName,
    required this.sellerName,
    required this.scheduledAt,
    required this.endsAt,
    required this.locationType,
    required this.locationTitle,
    required this.locationSubtitle,
  });

  final String listingId;
  final String serviceName;
  final String sellerName;
  final DateTime scheduledAt;
  final DateTime endsAt;
  final String locationType;
  final String locationTitle;
  final String locationSubtitle;
}
