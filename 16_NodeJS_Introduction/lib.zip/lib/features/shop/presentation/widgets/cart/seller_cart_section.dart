import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/shop/data/models/shop_cart_seller_group.dart';
import 'package:society_seva/features/shop/presentation/widgets/cart/cart_item_tile.dart';

class SellerCartSection extends StatelessWidget {
  final CartSellerGroup group;
  final ValueChanged<String> onIncrease;
  final ValueChanged<String> onDecrease;
  final ValueChanged<String> onRemove;

  const SellerCartSection({
    super.key,
    required this.group,
    required this.onIncrease,
    required this.onDecrease,
    required this.onRemove,
  });

  double get _sellerSubtotal => group.items.fold(0, (total, item) => total + item.lineTotal);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.border),
        boxShadow: const [BoxShadow(color: AppColors.shadow, blurRadius: 12, offset: Offset(0, 4))],
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: AppColors.greenSoft,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: AppTheme.hi(HugeIcons.strokeRoundedStore01, c: AppColors.green, s: 20),
                ),
                const Gap(11),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        group.sellerName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: AppTheme.hind(16, w: FontWeight.w700, c: AppColors.ink),
                      ),
                      const Gap(1),
                      Text(
                        '${group.items.length} ${group.items.length == 1 ? 'item' : 'items'}',
                        style: AppTheme.hind(12, w: FontWeight.w500, c: AppColors.muted),
                      ),
                    ],
                  ),
                ),
                Text(
                  '₹${_sellerSubtotal.toStringAsFixed(0)}',
                  style: AppTheme.display(15, w: FontWeight.w700, c: AppColors.ink),
                ),
              ],
            ),
          ),
          const Divider(height: 1, color: AppColors.border),
          ...group.items.map(
            (item) => CartItemTile(
              item: item,
              onIncrease: () => onIncrease(item.id),
              onDecrease: () => onDecrease(item.id),
              onRemove: () => onRemove(item.id),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 2, 16, 10),
            child: Align(
              alignment: Alignment.centerLeft,
              child: TextButton.icon(
                onPressed: () {
                  // TODO: Navigate to this seller's storefront.
                },
                style: TextButton.styleFrom(
                  foregroundColor: AppColors.green,
                  padding: EdgeInsets.zero,
                  minimumSize: const Size(44, 44),
                ),
                icon: AppTheme.hi(HugeIcons.strokeRoundedStore01, c: AppColors.green, s: 17),
                label: Text(
                  'View seller store',
                  style: AppTheme.hind(13, w: FontWeight.w600, c: AppColors.green),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
