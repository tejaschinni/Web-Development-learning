import 'package:flutter/material.dart';
import 'package:society_seva/app/theme/app_theme.dart';

class PriceRow extends StatelessWidget {
  final String label;
  final String value;
  final bool isTotal;

  const PriceRow({super.key, required this.label, required this.value, this.isTotal = false});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Text(
            label,
            style: AppTheme.hind(
              isTotal ? 15 : 13,
              w: isTotal ? FontWeight.w700 : FontWeight.w500,
              c: isTotal ? AppColors.ink : AppColors.muted,
            ),
          ),
        ),
        Text(
          value,
          style: AppTheme.display(
            isTotal ? 17 : 13,
            w: isTotal ? FontWeight.w800 : FontWeight.w600,
            c: isTotal ? AppColors.greenDeep : AppColors.ink,
          ),
        ),
      ],
    );
  }
}
