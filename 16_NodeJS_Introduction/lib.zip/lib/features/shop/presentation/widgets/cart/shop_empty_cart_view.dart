import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/app/theme/app_theme.dart';

class EmptyCartView extends StatelessWidget {
  const EmptyCartView({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 96,
                height: 96,
                decoration: BoxDecoration(
                  color: AppColors.greenSoft,
                  shape: BoxShape.circle,
                  boxShadow: const [
                    BoxShadow(color: AppColors.shadow, blurRadius: 16, offset: Offset(0, 5)),
                  ],
                ),
                child: AppTheme.hi(
                  HugeIcons.strokeRoundedShoppingCart02,
                  c: AppColors.green,
                  s: 40,
                ),
              ),
              const Gap(22),
              Text(
                'Your cart is empty',
                textAlign: TextAlign.center,
                style: AppTheme.display(22, w: FontWeight.w800, c: AppColors.ink),
              ),
              const Gap(7),
              Text(
                'Add products or food from sellers in your society '
                'and they will appear here.',
                textAlign: TextAlign.center,
                style: AppTheme.hind(14, w: FontWeight.w500, h: 1.45, c: AppColors.muted),
              ),
              const Gap(24),
              FilledButton(
                onPressed: () {
                  Navigator.of(context).maybePop();
                },
                style: FilledButton.styleFrom(
                  backgroundColor: AppColors.green,
                  foregroundColor: AppColors.surface,
                  minimumSize: const Size(160, 48),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                child: Text(
                  'Explore Shop',
                  style: AppTheme.hind(15, w: FontWeight.w700, c: AppColors.surface),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
