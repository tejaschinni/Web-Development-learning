import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:go_router/go_router.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/shop/domain/entities/shop_category.dart';
import 'package:society_seva/features/shop/domain/enums/shop_category_type.dart';
import 'package:society_seva/features/shop/data/models/shop_checkout_models.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_cart_provider.dart';
import 'package:society_seva/features/shop/presentation/screens/shop_order_tracking_screen.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_category_provider.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_listing_provider.dart';
import 'package:society_seva/features/shop/presentation/widgets/category/shop_category_list_shimmer.dart';
import 'package:society_seva/features/shop/presentation/widgets/category/shop_category_load_error.dart';
import 'package:society_seva/features/shop/presentation/widgets/listing/shop_listing_card.dart';
import 'package:society_seva/features/shop/presentation/widgets/listing/shop_popular_listings_shimmer.dart';
import 'package:society_seva/features/shop/presentation/widgets/shop_header.dart';

final sevaNavProvider = StateProvider<int>((_) => 0);
final sevaFavsProvider = StateProvider<Set<String>>((_) => {});

const _orange = Color(0xFFF26A1B);
const _green = Color(0xFF2E9B3E);
const _blue = Color(0xFF3B82F6);
const _forest = Color(0xFF0E5A34);

class SevaHomeScreen extends ConsumerWidget {
  const SevaHomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final activeOrders =
        (ref.watch(shopMyOrdersProvider).valueOrNull ?? const <ShopOrderResult>[])
            .where((order) => order.isActive)
            .toList()
          ..sort((first, second) {
            final firstCreated = DateTime.tryParse(first.createdAt ?? '') ?? DateTime(0);
            final secondCreated = DateTime.tryParse(second.createdAt ?? '') ?? DateTime(0);
            return secondCreated.compareTo(firstCreated);
          });

    return Scaffold(
      backgroundColor: const Color(0xFFFBFCFA),
      // bottomNavigationBar: const _SevaNav(),
      body: SafeArea(
        bottom: false,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Gap(2),
              ShopHeader(onCartTap: () => context.push('/shop/cart')),
              if (activeOrders.isNotEmpty) ...[
                Gap(12),
                _ActiveOrderBanner(order: activeOrders.first),
              ],
              Gap(12),
              SearchBar(onTap: () => context.push('/shop/search')),
              Gap(14),
              _IntentCards(),
              SectionTitle(
                title: 'Top Categories',
                onSeeAll: () {
                  context.push('/shop/categories' /* extra: societyId */);
                },
              ),
              Categories(
                onCategoryTap: (category) {
                  final listingType = category.categoryType == ShopCategoryType.service
                      ? 'service'
                      : 'product';

                  context.push(
                    '/shop/$listingType/category/${category.id}?name=${Uri.encodeComponent(category.name)}',
                    /* extra: societyId, */
                  );
                },
              ),
              Gap(16),
              _Banner(),
              SectionTitle(
                title: 'Popular near you',
                onSeeAll: () {
                  // TODO: Navigate to popular listing.
                  context.push('/shop/listings' /*, extra: societyId */);
                },
              ),
              Popular(),
              SectionTitle(title: 'Services near you'),
              Services(),
              SectionTitle(title: 'Recent needs from your community'),
              _Needs(),
              //
            ],
          ),
        ),
      ),
    );
  }
}

class _ActiveOrderBanner extends ConsumerWidget {
  const _ActiveOrderBanner({required this.order});

  final ShopOrderResult order;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final firstItem = order.items.isEmpty ? null : order.items.first;
    final sellerIdShort = order.sellerId.length > 8
        ? order.sellerId.substring(0, 8)
        : order.sellerId;
    final sellerProfile = ref.watch(sellerProfileByIdProvider(order.sellerId)).valueOrNull;
    final sellerName = sellerProfile?.displayName.trim().isNotEmpty == true
        ? sellerProfile!.displayName.trim()
        : sellerProfile?.businessName?.trim().isNotEmpty == true
        ? sellerProfile!.businessName!.trim()
        : order.sellerName?.trim().isNotEmpty == true
        ? order.sellerName!.trim()
        : 'Seller $sellerIdShort';

    return Material(
      color: theme.colorScheme.primaryContainer.withValues(alpha: 0.58),
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: () =>
            context.push('/shop/orders/${order.id}', extra: ShopOrderTrackingData.fromOrder(order)),
        borderRadius: BorderRadius.circular(14),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              HugeIcon(
                icon: HugeIcons.strokeRoundedDeliveryTruck01,
                size: 24,
                color: theme.colorScheme.primary,
              ),
              const Gap(11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Order in progress · ${order.statusLabel}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: AppTheme.display(13, c: theme.colorScheme.onSurface),
                    ),
                    const Gap(2),
                    Text(
                      firstItem == null ? sellerName : '${firstItem.title} · $sellerName',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: AppTheme.hind(12, c: theme.colorScheme.onSurfaceVariant),
                    ),
                  ],
                ),
              ),
              const Gap(8),
              HugeIcon(
                icon: HugeIcons.strokeRoundedArrowRight01,
                size: 18,
                color: theme.colorScheme.primary,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class SearchBar extends StatelessWidget {
  const SearchBar({super.key, required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(18),
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border, width: 1.4),
      ),
      child: Row(
        children: [
          AppTheme.hi(HugeIcons.strokeRoundedSearch01, s: 26),
          const Gap(12),
          Expanded(
            child: Text(
              'Search for food, services, products, people...',
              style: AppTheme.hind(15, c: AppColors.muted),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          Gap(8),
          AppTheme.hi(HugeIcons.strokeRoundedFilterHorizontal, s: 24),
        ],
      ),
    ),
  );
}

// ───────────── I need / I have / Match me ─────────────
class _IntentCards extends StatelessWidget {
  const _IntentCards();
  @override
  Widget build(BuildContext context) {
    Widget card(
      String t,
      String l1,
      String l2,
      Icn icon,
      Color c,
      Color bg, {
      VoidCallback? onTap,
    }) =>
        Expanded(
          child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(18),
            child: Container(
              padding: const EdgeInsets.fromLTRB(8, 10, 8, 10),
              decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(18)),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 35,
                    height: 35,
                    decoration: BoxDecoration(color: c, shape: BoxShape.circle),
                    child: Center(child: AppTheme.hi(icon, c: Colors.white, s: 20)),
                  ),
                  const Gap(8),
                  Text(t, style: AppTheme.display(14), maxLines: 1),
                  const Gap(2),
                  Text('$l1\n$l2', style: AppTheme.hind(12, c: c, h: 1.2)),
                ],
              ),
            ),
          ),
        );
    return Row(
      children: [
        card(
          'I NEED',
          'Find what',
          'you need',
          HugeIcons.strokeRoundedShoppingCart02,
          _orange,
          const Color(0xFFFDEBDD),
        ),
        const Gap(8),
        card(
          'I HAVE',
          'Offer what',
          'you have',
          HugeIcons.strokeRoundedTag01,
          _green,
          const Color(0xFFE5F4E7),
        ),
        const Gap(8),
        card(
          'MATCH ME',
          'Connect with',
          'right people',
          HugeIcons.strokeRoundedUserGroup,
          _blue,
          const Color(0xFFE3EEFD),
          onTap: () => context.push('/modules/seller/matchme'),
        ),
      ],
    );
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle({super.key, required this.title, this.onSeeAll, this.size = 16});

  final String title;
  final double size;
  final VoidCallback? onSeeAll;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(top: 18, bottom: 10),
    child: Row(
      children: [
        Expanded(
          child: Text(title, style: AppTheme.display(size, w: FontWeight.w700)),
        ),

        if (onSeeAll != null)
          InkWell(
            onTap: onSeeAll,
            borderRadius: BorderRadius.circular(8),
            child: Row(
              children: [
                Text(
                  'See all',
                  style: AppTheme.hind(14, w: FontWeight.w700, c: _forest),
                ),
                const Gap(4),
                AppTheme.hi(HugeIcons.strokeRoundedArrowRight01, c: _forest, s: 18),
              ],
            ),
          ),
      ],
    ),
  );
}

// ───────────── Categories ─────────────
class Categories extends ConsumerWidget {
  const Categories({super.key, required this.onCategoryTap});

  final ValueChanged<ShopCategory> onCategoryTap;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final categoriesAsync = ref.watch(shopCategoriesProvider);

    return categoriesAsync.when(
      loading: () => const CategoryListShimmer(),
      error: (error, stack) =>
          CategoryLoadError(onRetry: () => ref.invalidate(shopCategoriesProvider)),
      data: (categories) {
        final topLevelCategories =
            categories.where((category) => category.isActive && category.isTopLevel).toList()
              ..sort((a, b) => a.displayOrder.compareTo(b.displayOrder));

        if (topLevelCategories.isEmpty) {
          return const SizedBox.shrink();
        }

        // Keep the existing 2-row layout.
        // final row1 = topLevelCategories.take(5).toList();
        // final row2 = topLevelCategories.skip(5).take(5).toList();

        // return Column(
        //   children: [
        // _buildCategoryRow(row1),
        // const Gap(6),
        // if (row2.isNotEmpty) _buildCategoryRow(row2),
        //   ],
        // );

        return _buildCategoryRow(topLevelCategories);
      },
    );
  }

  Widget _buildCategoryRow(List<ShopCategory> categories) {
    // return Row(
    //   children: [
    //     for (final (index, category) in categories.indexed) ...[
    //       if (index > 0) const Gap(8),
    //       Expanded(child: _buildCategoryItem(category)),
    //     ],
    //   ],
    // );

    return SizedBox(
      height: 80,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: categories.length,
        separatorBuilder: (_, _) => const Gap(8),
        itemBuilder: (context, index) {
          final category = categories[index];

          return _buildCategoryItem(category);
        },
      ),
    );
  }

  Widget _buildCategoryItem(ShopCategory category) {
    final style = _categoryStyleFor(category);

    return InkWell(
      onTap: () => onCategoryTap(category),
      borderRadius: BorderRadius.circular(16),
      child: Container(
        height: 78,
        padding: .symmetric(horizontal: 18, vertical: 4),
        decoration: BoxDecoration(color: style.background, borderRadius: BorderRadius.circular(16)),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AppTheme.hi(style.icon, c: style.foreground, s: 30),
            const Gap(6),
            Text(
              style.label,
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: AppTheme.hind(12, w: FontWeight.w600, h: 1.1),
            ),
            if (category.slug.toLowerCase() == 'more')
              Text(
                'Property, Jobs,\nCommunity, Help & more',
                textAlign: TextAlign.center,
                style: AppTheme.hind(8, c: AppColors.muted, h: 1.1),
              ),
          ],
        ),
      ),
    );
  }
}

typedef _CategoryStyle = ({String label, Icn icon, Color foreground, Color background});

_CategoryStyle _categoryStyleFor(ShopCategory category) {
  final slug = category.slug.toLowerCase();

  switch (slug) {
    case 'food':
    case 'breakfast':
    case 'dinner':
      return (
        label: category.name,
        icon: HugeIcons.strokeRoundedDish01,
        foreground: _orange,
        background: const Color(0xFFFDEBDD),
      );

    case 'bake':
    case 'cake':
      return (
        label: category.name,
        icon: HugeIcons.strokeRoundedCake,
        foreground: _orange,
        background: const Color(0xFFFDEBDD),
      );

    case 'health-fitness':
    case 'health':
    case 'fitness':
    case 'fitness-trainer':
      return (
        label: 'Health &\nFitness',
        icon: HugeIcons.strokeRoundedDumbbell01,
        foreground: const Color(0xFFE5334F),
        background: const Color(0xFFFDE8EB),
      );

    case 'beauty-care':
    case 'beauty':
      return (
        label: 'Beauty &\nCare',
        icon: HugeIcons.strokeRoundedSparkles,
        foreground: const Color(0xFFC026A8),
        background: const Color(0xFFF6E7F6),
      );

    case 'education-career':
    case 'education':
    case 'tution-classes':
    case 'classes':
    case 'class':
      return (
        label: 'Education &\nCareer',
        icon: HugeIcons.strokeRoundedMortarboard01,
        foreground: _blue,
        background: const Color(0xFFE3EEFD),
      );

    case 'kids':
      return (
        label: category.name,
        icon: HugeIcons.strokeRoundedBaby01,
        foreground: const Color(0xFFF59E0B),
        background: const Color(0xFFFFF1D6),
      );

    case 'events-occasion':
    case 'events':
      return (
        label: 'Events &\nOccasion',
        icon: HugeIcons.strokeRoundedParty,
        foreground: const Color(0xFFE5334F),
        background: const Color(0xFFFDE8EB),
      );

    case 'art-creation':
    case 'art':
      return (
        label: 'Art &\nCreation',
        icon: HugeIcons.strokeRoundedPaintBoard,
        foreground: const Color(0xFF7C4DDB),
        background: const Color(0xFFEDE7FA),
      );

    case 'buy-sell':
      return (
        label: 'Buy & Sell',
        icon: HugeIcons.strokeRoundedShoppingBag01,
        foreground: _green,
        background: const Color(0xFFE5F4E7),
      );

    case 'services':
    case 'electric':
    case 'electrician':
    case 'repair':
      return (
        label: category.name,
        icon: HugeIcons.strokeRoundedWrench01,
        foreground: _blue,
        background: const Color(0xFFE3EEFD),
      );

    default:
      // Reuse the icon mapping from ExploreCategories.
      return (
        label: category.name,
        icon: _categoryIconFor(category),
        foreground: _blue,
        background: const Color(0xFFE3EEFD),
      );
  }
}

List<List<dynamic>> _categoryIconFor(ShopCategory category) {
  switch (category.slug.toLowerCase()) {
    case 'breakfast':
      return HugeIcons.strokeRoundedCoffee01;

    case 'dinner':
      return HugeIcons.strokeRoundedDish01;

    case 'electric':
    case 'electrician':
      return HugeIcons.strokeRoundedPlug01;

    case 'repair':
    case 'ran-repair':
      return HugeIcons.strokeRoundedTools;

    case 'classes':
      return HugeIcons.strokeRoundedBookOpen01;

    default:
      switch (category.categoryType) {
        case ShopCategoryType.food:
          return HugeIcons.strokeRoundedRestaurant01;

        case ShopCategoryType.service:
          return HugeIcons.strokeRoundedTools;

        case ShopCategoryType.product:
          return HugeIcons.strokeRoundedShoppingBag01;

        case ShopCategoryType.unknown:
          return HugeIcons.strokeRoundedGridView;
      }
  }
}

// ───────────── Banner ─────────────
class _Banner extends StatelessWidget {
  const _Banner();
  @override
  Widget build(BuildContext context) => Container(
    height: 150,
    clipBehavior: Clip.antiAlias,
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(22),
      gradient: const LinearGradient(colors: [Color(0xFFE6F3E3), Color(0xFFF4F9F1)]),
    ),
    child: Row(
      children: [
        Expanded(
          flex: 5,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 12, 0, 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Support Your\nNeighborhood',
                  style: AppTheme.display(16, w: FontWeight.w800, c: _forest, h: 1.05),
                ),
                const Gap(8),
                Text('Buy, Sell, Share and\nGrow Together', style: AppTheme.hind(12, h: 1.2)),
                const Spacer(),
                Container(
                  width: 38,
                  height: 38,
                  decoration: const BoxDecoration(color: _forest, shape: BoxShape.circle),
                  child: Center(
                    child: AppTheme.hi(HugeIcons.strokeRoundedArrowRight01, c: Colors.white, s: 24),
                  ),
                ),
              ],
            ),
          ),
        ),
        Expanded(
          flex: 5,
          child: Image.asset(
            'assets/images/h-dash-s.png',
            fit: BoxFit.fitHeight,
            alignment: Alignment.centerRight,
          ),
        ),
      ],
    ),
  );
}

class Popular extends ConsumerWidget {
  const Popular({super.key, this.societyId});

  final String? societyId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final listingsAsync = ref.watch(shopPopularListingsProvider(societyId ?? ''));

    return listingsAsync.when(
      loading: () => const PopularListingsShimmer(),
      error: (error, stack) => SizedBox(
        height: 226,
        child: Center(
          child: TextButton.icon(
            onPressed: () {
              ref.invalidate(shopPopularListingsProvider(societyId ?? ''));
            },
            icon: const Icon(Icons.refresh),
            label: const Text('Unable to load listings'),
          ),
        ),
      ),
      data: (state) {
        if (state.items.isEmpty) {
          return const SizedBox(
            height: 226,
            child: Center(child: Text('No popular listings available yet')),
          );
        }

        return SizedBox(
          height: 238,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: state.items.length,
            separatorBuilder: (_, _) => const Gap(10),
            itemBuilder: (context, index) {
              // return _PopularListingCard(listing: state.items[index], societyId: societyId);
              return ListingCard(listing: state.items[index]);
            },
          ),
        );
      },
    );
  }
}

// ───────────── Services near you ─────────────
class Services extends StatelessWidget {
  const Services({super.key});

  // final String? societyId;

  static const _s = <(String, Icn, Color, Color)>[
    ('Home\nServices', HugeIcons.strokeRoundedHome07, _forest, Color(0xFFE5F4E7)),
    ('AC Repair', HugeIcons.strokeRoundedWrench01, _blue, Color(0xFFE3EEFD)),
    ('Painting', HugeIcons.strokeRoundedPaintBrush01, _orange, Color(0xFFFDEBDD)),
    ('Packers &\nMovers', HugeIcons.strokeRoundedTruck, _green, Color(0xFFE5F4E7)),
    ('Pet Care', HugeIcons.strokeRoundedPawPrint, _orange, Color(0xFFFDEBDD)),
    (
      'IT & Digital\nServices',
      HugeIcons.strokeRoundedComputerPhoneSync,
      Color(0xFF7C4DDB),
      Color(0xFFEDE7FA),
    ),
    (
      'Salon & Beauty\nServices',
      HugeIcons.strokeRoundedScissor01,
      Color(0xFFE5334F),
      Color(0xFFFDE8EB),
    ),
  ];
  @override
  Widget build(BuildContext context) => SizedBox(
    height: 104,
    child: Row(
      children: [
        Expanded(
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: _s.length,
            separatorBuilder: (_, _) => const Gap(14),
            itemBuilder: (_, i) => SizedBox(
              width: 60,
              child: Column(
                children: [
                  Container(
                    width: 54,
                    height: 54,
                    decoration: BoxDecoration(color: _s[i].$4, shape: BoxShape.circle),
                    child: Center(child: AppTheme.hi(_s[i].$2, c: _s[i].$3, s: 30)),
                  ),
                  const Gap(6),
                  Text(_s[i].$1, textAlign: TextAlign.center, style: AppTheme.hind(12, h: 1.15)),
                ],
              ),
            ),
          ),
        ),
        Container(
          width: 44,
          height: 44,
          margin: const EdgeInsets.only(left: 8, bottom: 30),
          decoration: BoxDecoration(
            color: Colors.white,
            shape: BoxShape.circle,
            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .1), blurRadius: 8)],
          ),
          child: Center(child: AppTheme.hi(HugeIcons.strokeRoundedArrowRight01, s: 22)),
        ),
      ],
    ),
  );
}

// ───────────── Recent needs ─────────────
class _Needs extends StatelessWidget {
  const _Needs();
  static const _n = [
    (
      'P',
      Color(0xFF7C4DDB),
      '2h ago',
      'Looking for Maths Tutor',
      'Class 5, in Gera World of Joy',
      'Respond',
    ),
    (
      'S',
      _blue,
      '3h ago',
      'Need Birthday Decorator',
      'For 25 people, this weekend',
      'View Details',
    ),
    ('A', _orange, '5h ago', 'Looking for Home Cook', 'Vegetarian, 5 days a week', 'Respond'),
  ];
  @override
  Widget build(BuildContext context) => SizedBox(
    height: 148,
    child: ListView.separated(
      scrollDirection: Axis.horizontal,
      itemCount: _n.length,
      separatorBuilder: (_, _) => const Gap(10),
      itemBuilder: (_, i) {
        final n = _n[i];
        return Container(
          width: 250,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: .06),
                blurRadius: 10,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    radius: 15,
                    backgroundColor: n.$2,
                    child: Text(n.$1, style: AppTheme.display(15, c: Colors.white)),
                  ),
                  const Gap(10),
                  Text(n.$3, style: AppTheme.hind(14, c: AppColors.muted)),
                ],
              ),
              const Gap(8),
              Text(n.$4, style: AppTheme.display(14, w: FontWeight.w800)),
              Text(n.$5, style: AppTheme.hind(12, c: AppColors.muted)),
              const Spacer(),
              Btn(n.$6, style: 1, pad: 8),
            ],
          ),
        );
      },
    ),
  );
}

class Btn extends StatelessWidget {
  const Btn(
    this.label, {
    super.key,
    this.onTap,
    this.style = 0,
    this.icon,
    this.expand = true,
    this.pad = 14,
  });

  /// style: 0 = filled green, 1 = outlined, 2 = soft, 3 = orange
  final String label;
  final VoidCallback? onTap;
  final int style;
  final Icn? icon;
  final bool expand;
  final double pad;
  @override
  Widget build(BuildContext context) {
    final bg = [AppColors.green, Colors.white, const Color(0xFFEDF1EC), AppColors.orange][style];
    final fg = [Colors.white, AppColors.green, AppColors.green, AppColors.ink][style];
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: expand ? double.infinity : null,
        padding: EdgeInsets.symmetric(vertical: pad, horizontal: 18),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(16),
          border: style == 1 ? Border.all(color: AppColors.green, width: 1) : null,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (icon != null) ...[AppTheme.hi(icon!, c: fg, s: 20), const Gap(8)],
            Text(
              label,
              style: AppTheme.hind(16, w: FontWeight.w700, c: fg),
            ),
          ],
        ),
      ),
    );
  }
}
