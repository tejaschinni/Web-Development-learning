import 'dart:async';

import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:society_seva/core/storage/local_cache.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_search_provider.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_listing_provider.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing.dart';
import 'package:society_seva/features/shop/domain/entities/shop_category.dart';
import 'package:society_seva/features/shop/domain/entities/shop_seller.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/shop/presentation/widgets/listing/shop_listing_card.dart';

// class _SearchUi {
//   static const background = Color(0xFFF6F8F7);
//   static const surface = Color(0xFFFFFFFF);
//   static const primary = Color(0xFF176B55);
//   static const primarySoft = Color(0xFFE5F2EC);
//   static const border = Color(0xFFE5EAE7);
//   static const text = Color(0xFF202925);
//   static const muted = Color(0xFF78837D);
//   static const peach = Color(0xFFFFF0E7);
//   static const lavender = Color(0xFFF0EDFA);
//   static const shadow = Color(0x0A20352B);
// }

class ShopSearchScreen extends ConsumerStatefulWidget {
  const ShopSearchScreen({super.key, this.initialQuery});

  final String? initialQuery;

  @override
  ConsumerState<ShopSearchScreen> createState() => _ShopSearchScreenState();
}

class _ShopSearchScreenState extends ConsumerState<ShopSearchScreen> {
  late final TextEditingController _searchController;
  final FocusNode _searchFocusNode = FocusNode();

  bool _hasQuery = false;
  List<String> _recentSearches = [];
  Timer? _debounce;
  bool _historyLoaded = false;
  String? _categoryId;
  String? _sellerId;
  String? _listingType;
  String? _sortBy;
  double? _minPrice;
  double? _maxPrice;
  bool? _isFree;
  double? _minRating;
  String? _availabilityStatus;
  bool? _inStockOnly;
  bool? _sponsoredOnly;
  String? _foodType;
  bool? _isFrozen;
  String? _societyId;
  List<ShopCategory> _categories = [];
  List<ShopSeller> _sellers = [];
  ShopSearchFilter? _activeFilter;
  static const _historyCacheKey = 'app:shop:search_history';

  @override
  void initState() {
    super.initState();

    _searchController = TextEditingController(text: widget.initialQuery ?? '');

    _hasQuery = _searchController.text.trim().isNotEmpty;

    _searchController.addListener(_onSearchChanged);
    _loadRecentSearches();
    if (_hasQuery) _search(_searchController.text.trim());

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _searchFocusNode.requestFocus();
    });
  }

  void _onSearchChanged() {
    final query = _searchController.text.trim();
    final hasQuery = query.isNotEmpty;

    if (hasQuery != _hasQuery) {
      setState(() => _hasQuery = hasQuery);
    }

    _debounce?.cancel();

    if (query.length < 2) {
      if (_activeFilter != null) {
        setState(() => _activeFilter = null);
      }
      return;
    }

    _debounce = Timer(
      const Duration(milliseconds: 400),
      () => _search(_searchController.text.trim()),
    );
  }

  Future<void> _loadRecentSearches() async {
    final cache = LocalCache.instance;
    List<String> local = [];
    try {
      final saved = await cache.readJson(_historyCacheKey);
      local = (saved?['searches'] as List<dynamic>? ?? const []).map((e) => e.toString()).toList();
    } catch (_) {}
    if (mounted) {
      setState(() {
        _recentSearches = local;
        _historyLoaded = true;
      });
    }
    try {
      final remote = await ref.read(shopRecentSearchesProvider.future);
      if (!mounted) return;
      setState(() => _recentSearches = remote);
      await _saveLocalHistory(remote);
    } catch (_) {
      // Local history remains available when the history service is offline.
    }
  }

  Future<void> _saveLocalHistory(List<String> searches) async {
    try {
      await LocalCache.instance.writeJson(_historyCacheKey, {
        'searches': searches.take(10).toList(),
      });
    } catch (_) {}
  }

  void _search(String query) {
    query = query.trim();
    if (query.length < 2) return;

    final filter = ShopSearchFilter(
      query: query,
      societyId: _societyId,
      categoryId: _categoryId,
      sellerId: _sellerId,
      listingType: _listingType,
      minPrice: _minPrice,
      maxPrice: _maxPrice,
      isFree: _isFree,
      minRating: _minRating,
      availabilityStatus: _availabilityStatus,
      inStockOnly: _inStockOnly,
      sponsoredOnly: _sponsoredOnly,
      foodType: _foodType,
      isFrozen: _isFrozen,
      sortBy: _sortBy,
    );

    setState(() => _activeFilter = filter);
    unawaited(_recordSearch(query));
  }

  Future<void> _recordSearch(String query) async {
    final alreadyRecent =
        _recentSearches.isNotEmpty && _recentSearches.first.toLowerCase() == query.toLowerCase();
    if (alreadyRecent) return;
    final next = [
      query,
      ..._recentSearches.where((item) => item.toLowerCase() != query.toLowerCase()),
    ].take(10).toList();
    setState(() => _recentSearches = next);
    await _saveLocalHistory(next);
    // Successful search requests create server-side history in the API.
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _searchController
      ..removeListener(_onSearchChanged)
      ..dispose();

    _searchFocusNode.dispose();

    super.dispose();
  }

  Future<void> _removeRecentSearch(String value) async {
    final next = _recentSearches.where((item) => item != value).toList();
    setState(() => _recentSearches = next);
    await _saveLocalHistory(next);
    try {
      await ref.read(shopListingRepositoryProvider).deleteRecentSearch(value);
    } catch (_) {}
  }

  Future<void> _clearRecentSearches() async {
    setState(() => _recentSearches.clear());
    await _saveLocalHistory([]);
    try {
      await ref.read(shopListingRepositoryProvider).clearRecentSearches();
    } catch (_) {}
  }

  void _selectRecentSearch(String value) {
    _searchController.text = value;

    _searchController.selection = TextSelection.fromPosition(
      TextPosition(offset: _searchController.text.length),
    );
  }

  void _clearSearch() {
    _searchController.clear();
    _searchFocusNode.requestFocus();
  }

  @override
  Widget build(BuildContext context) {
    // final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Column(
          children: [
            _SearchHeader(
              controller: _searchController,
              focusNode: _searchFocusNode,
              hasQuery: _hasQuery,
              onBack: () => Navigator.of(context).pop(),
              onClear: _clearSearch,
              onSubmit: (value) => _search(value.trim()),
              onFilter: () => _showFilters(context),
            ),
            Expanded(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 220),
                switchInCurve: Curves.easeOutCubic,
                child: _hasQuery
                    ? _SearchResults(
                        key: const ValueKey('results'),
                        query: _searchController.text.trim(),
                        searchFilter: _activeFilter,
                      )
                    : _SearchEmptyState(
                        key: const ValueKey('empty'),
                        recentSearches: _recentSearches,
                        onRecentSearchTap: _selectRecentSearch,
                        onRecentSearchRemove: _removeRecentSearch,
                        onClearAll: _clearRecentSearches,
                        loading: !_historyLoaded,
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showFilters(BuildContext context) {
    setState(() {
      _categories = ref.read(shopCategoriesForSearchProvider).valueOrNull ?? _categories;
      _sellers = ref.read(shopSearchSellersProvider).valueOrNull ?? _sellers;
    });
    if (ref.read(shopCategoriesForSearchProvider).valueOrNull == null) {
      unawaited(
        ref
            .read(shopCategoriesForSearchProvider.future)
            .then((value) {
              if (mounted) setState(() => _categories = value);
            })
            .catchError((_) {}),
      );
    }
    if (ref.read(shopSearchSellersProvider).valueOrNull == null) {
      unawaited(
        ref
            .read(shopSearchSellersProvider.future)
            .then((value) {
              if (mounted) setState(() => _sellers = value);
            })
            .catchError((_) {}),
      );
    }
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      backgroundColor: AppColors.bg,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (_) {
        final baseTheme = Theme.of(context);

        return Theme(
          data: baseTheme.copyWith(
            colorScheme: baseTheme.colorScheme.copyWith(
              primary: AppColors.green,
              surface: Colors.white,
            ),
            inputDecorationTheme: InputDecorationTheme(
              filled: true,
              fillColor: Colors.white,
              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
              hintStyle: const TextStyle(color: AppColors.muted),
              labelStyle: const TextStyle(color: AppColors.muted),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: const BorderSide(color: AppColors.border),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: const BorderSide(color: AppColors.border),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: const BorderSide(color: AppColors.green, width: 1.4),
              ),
            ),
          ),
          child: _SearchFilterSheet(
            categories: _categories,
            sellers: _sellers,
            categoryId: _categoryId,
            sellerId: _sellerId,
            listingType: _listingType,
            sortBy: _sortBy,
            societyId: _societyId,
            minPrice: _minPrice,
            maxPrice: _maxPrice,
            isFree: _isFree,
            minRating: _minRating,
            availabilityStatus: _availabilityStatus,
            inStockOnly: _inStockOnly,
            sponsoredOnly: _sponsoredOnly,
            foodType: _foodType,
            isFrozen: _isFrozen,
            onApply: (filters) {
              // Keep your existing onApply body unchanged.
            },
          ),
        );
      },
    );
  }
}

class _SearchHeader extends StatelessWidget {
  const _SearchHeader({
    required this.controller,
    required this.focusNode,
    required this.hasQuery,
    required this.onBack,
    required this.onClear,
    required this.onFilter,
    required this.onSubmit,
  });

  final TextEditingController controller;
  final FocusNode focusNode;
  final bool hasQuery;
  final VoidCallback onBack;
  final VoidCallback onClear;
  final VoidCallback onFilter;
  final ValueChanged<String> onSubmit;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 16, 16),
      child: Row(
        children: [
          IconButton(
            onPressed: onBack,
            tooltip: 'Back',
            style: IconButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: AppColors.ink,
              side: const BorderSide(color: AppColors.border),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            ),
            icon: const HugeIcon(icon: HugeIcons.strokeRoundedArrowLeft01, size: 22),
          ),
          const Gap(8),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border),
                boxShadow: const [
                  BoxShadow(color: AppColors.shadow, blurRadius: 14, offset: Offset(0, 4)),
                ],
              ),
              child: TextField(
                controller: controller,
                focusNode: focusNode,
                textInputAction: TextInputAction.search,
                onSubmitted: onSubmit,
                maxLines: 1,
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: AppColors.ink,
                  fontWeight: FontWeight.w500,
                ),
                decoration: InputDecoration(
                  hintText: 'Search products, food & services',
                  hintStyle: theme.textTheme.bodySmall?.copyWith(color: AppColors.muted),
                  prefixIcon: const Padding(
                    padding: EdgeInsets.all(13),
                    child: HugeIcon(
                      icon: HugeIcons.strokeRoundedSearch01,
                      size: 20,
                      color: AppColors.green,
                    ),
                  ),
                  suffixIcon: hasQuery
                      ? IconButton(
                          onPressed: onClear,
                          tooltip: 'Clear',
                          icon: const HugeIcon(
                            icon: HugeIcons.strokeRoundedCancel01,
                            size: 18,
                            color: AppColors.muted,
                          ),
                        )
                      : null,
                  fillColor: Colors.transparent,
                  border: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(vertical: 15, horizontal: 4),
                ),
              ),
            ),
          ),
          const Gap(10),
          Material(
            color: AppColors.greenSoft,
            borderRadius: BorderRadius.circular(16),
            child: InkWell(
              onTap: onFilter,
              borderRadius: BorderRadius.circular(16),
              child: const SizedBox(
                width: 48,
                height: 48,
                child: Center(
                  child: HugeIcon(
                    icon: HugeIcons.strokeRoundedFilter,
                    size: 21,
                    color: AppColors.green,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SearchEmptyState extends StatelessWidget {
  const _SearchEmptyState({
    super.key,
    required this.recentSearches,
    required this.onRecentSearchTap,
    required this.onRecentSearchRemove,
    required this.onClearAll,
    required this.loading,
  });

  final List<String> recentSearches;
  final ValueChanged<String> onRecentSearchTap;
  final ValueChanged<String> onRecentSearchRemove;
  final VoidCallback onClearAll;
  final bool loading;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return ListView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
      children: [
        Text(
          'Find your next favourite',
          style: theme.textTheme.headlineSmall?.copyWith(
            color: AppColors.ink,
            fontWeight: FontWeight.w800,
            letterSpacing: -0.7,
          ),
        ),
        const Gap(6),
        Text(
          'Discover products, homemade food and services near you.',
          style: AppTheme.hind(14, c: AppColors.muted),
        ),
        const Gap(28),
        if (loading && recentSearches.isEmpty)
          LinearProgressIndicator(color: AppColors.green, backgroundColor: AppColors.greenSoft),
        if (recentSearches.isNotEmpty) ...[
          _SearchSectionHeader(
            title: 'Recent searches',
            actionText: 'Clear all',
            onAction: onClearAll,
          ),
          const Gap(12),
          _RecentSearchList(
            searches: recentSearches,
            onTap: onRecentSearchTap,
            onRemove: onRecentSearchRemove,
          ),
        ] else if (!loading) ...[
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: AppColors.border),
            ),
            child: Column(
              children: [
                Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    color: AppColors.greenSoft,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Center(
                    child: HugeIcon(
                      icon: HugeIcons.strokeRoundedSearch01,
                      size: 28,
                      color: AppColors.green,
                    ),
                  ),
                ),
                const Gap(14),
                Text(
                  'Your search journey starts here',
                  textAlign: TextAlign.center,
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w700,
                    color: AppColors.ink,
                  ),
                ),
                const Gap(6),
                Text(
                  'Try searching for snacks, groceries or a service.',
                  textAlign: TextAlign.center,
                  style: theme.textTheme.bodySmall?.copyWith(color: AppColors.muted, height: 1.5),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }
}

class _RecentSearchList extends StatelessWidget {
  const _RecentSearchList({required this.searches, required this.onTap, required this.onRemove});

  final List<String> searches;
  final ValueChanged<String> onTap;
  final ValueChanged<String> onRemove;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: [
          for (var i = 0; i < searches.length; i++) ...[
            InkWell(
              onTap: () => onTap(searches[i]),
              borderRadius: BorderRadius.vertical(
                top: i == 0 ? const Radius.circular(20) : Radius.zero,
                bottom: i == searches.length - 1 ? const Radius.circular(20) : Radius.zero,
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                child: Row(
                  children: [
                    Container(
                      width: 38,
                      height: 38,
                      decoration: BoxDecoration(
                        color: i.isEven ? AppColors.greenSoft : AppColors.lavender,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Center(
                        child: HugeIcon(
                          icon: HugeIcons.strokeRoundedClock01,
                          size: 19,
                          color: i.isEven ? AppColors.green : const Color(0xFF7965B5),
                        ),
                      ),
                    ),
                    const Gap(12),
                    Expanded(
                      child: Text(
                        searches[i],
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: AppColors.ink,
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    IconButton(
                      visualDensity: VisualDensity.compact,
                      onPressed: () => onRemove(searches[i]),
                      tooltip: 'Remove',
                      icon: const HugeIcon(
                        icon: HugeIcons.strokeRoundedCancel01,
                        size: 17,
                        color: AppColors.muted,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            if (i < searches.length - 1)
              const Divider(height: 1, indent: 64, endIndent: 14, color: AppColors.border),
          ],
        ],
      ),
    );
  }
}

class _SearchResults extends ConsumerWidget {
  const _SearchResults({super.key, required this.query, required this.searchFilter});

  final String query;
  final ShopSearchFilter? searchFilter;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);

    final AsyncValue<PageResponse<ShopListing>> state = searchFilter == null
        ? const AsyncLoading<PageResponse<ShopListing>>()
        : ref.watch(shopSearchListingsProvider(searchFilter!));

    final results = state.valueOrNull?.content ?? const <ShopListing>[];

    return ListView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
      children: [
        Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Search results',
                    style: AppTheme.display(22, w: FontWeight.w700, c: AppColors.ink),
                  ),
                  const Gap(4),
                  Text(
                    'Results for "$query"',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.bodySmall?.copyWith(color: AppColors.muted),
                  ),
                ],
              ),
            ),
            if (searchFilter != null)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
                decoration: BoxDecoration(
                  color: AppColors.greenSoft,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    HugeIcon(
                      icon: HugeIcons.strokeRoundedGridView,
                      size: 16,
                      color: AppColors.green,
                    ),
                    Gap(6),
                    Text(
                      'Explore',
                      style: TextStyle(
                        color: AppColors.green,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
        const Gap(18),

        if (state.isLoading && results.isEmpty) ...[
          const LinearProgressIndicator(
            color: AppColors.green,
            backgroundColor: AppColors.greenSoft,
          ),
          const Gap(24),
          const Center(
            child: Text(
              'Finding something good for you...',
              style: TextStyle(color: AppColors.muted),
            ),
          ),
        ] else if (state.hasError) ...[
          _SearchMessageCard(
            icon: HugeIcons.strokeRoundedAlertCircle,
            title: 'Could not load results',
            message: 'Check your connection and try searching again.',
            actionLabel: 'Retry',
            onAction: () {
              if (searchFilter != null) {
                ref.invalidate(shopSearchListingsProvider(searchFilter!));
              }
            },
          ),
        ] else if (searchFilter == null) ...[
          const _SearchMessageCard(
            icon: HugeIcons.strokeRoundedSearch01,
            title: 'Keep typing',
            message: 'Enter at least 2 characters to search the marketplace.',
          ),
        ] else if (results.isEmpty) ...[
          const _SearchMessageCard(
            icon: HugeIcons.strokeRoundedSearch01,
            title: 'No listings found',
            message: 'Try another keyword or adjust your filters.',
          ),
        ] else ...[
          Text(
            'Discover listings',
            style: theme.textTheme.titleSmall?.copyWith(
              color: AppColors.ink,
              fontWeight: FontWeight.w700,
            ),
          ),
          const Gap(12),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            padding: EdgeInsets.zero,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 14,
              childAspectRatio: 0.68,
            ),
            itemCount: results.length,
            itemBuilder: (context, index) {
              return ListingCard(listing: results[index]);
            },
          ),
          if (state.isLoading) ...[
            const Gap(16),
            const LinearProgressIndicator(
              color: AppColors.green,
              backgroundColor: AppColors.greenSoft,
            ),
          ],
        ],
      ],
    );
  }
}

class _SearchMessageCard extends StatelessWidget {
  const _SearchMessageCard({
    required this.icon,
    required this.title,
    required this.message,
    this.actionLabel,
    this.onAction,
  });

  final dynamic icon;
  final String title;
  final String message;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 30),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: [
          Container(
            width: 58,
            height: 58,
            decoration: BoxDecoration(
              color: AppColors.greenSoft,
              borderRadius: BorderRadius.circular(18),
            ),
            child: Center(
              child: HugeIcon(icon: icon, size: 26, color: AppColors.green),
            ),
          ),
          const Gap(16),
          Text(
            title,
            textAlign: TextAlign.center,
            style: theme.textTheme.titleMedium?.copyWith(
              color: AppColors.ink,
              fontWeight: FontWeight.w700,
            ),
          ),
          const Gap(8),
          Text(
            message,
            textAlign: TextAlign.center,
            style: theme.textTheme.bodyMedium?.copyWith(color: AppColors.muted, height: 1.5),
          ),
          if (actionLabel != null && onAction != null) ...[
            const Gap(18),
            FilledButton(onPressed: onAction, child: Text(actionLabel!)),
          ],
        ],
      ),
    );
  }
}

class _SearchFilterSheet extends StatefulWidget {
  const _SearchFilterSheet({
    required this.categories,
    required this.sellers,
    required this.societyId,
    required this.categoryId,
    required this.sellerId,
    required this.listingType,
    required this.sortBy,
    required this.minPrice,
    required this.maxPrice,
    required this.isFree,
    required this.minRating,
    required this.availabilityStatus,
    required this.inStockOnly,
    required this.sponsoredOnly,
    required this.foodType,
    required this.isFrozen,
    required this.onApply,
  });

  final List<ShopCategory> categories;
  final List<ShopSeller> sellers;
  final String? societyId;
  final String? categoryId;
  final String? sellerId;
  final String? listingType;
  final String? sortBy;
  final double? minPrice;
  final double? maxPrice;
  final bool? isFree;
  final double? minRating;
  final String? availabilityStatus;
  final bool? inStockOnly;
  final bool? sponsoredOnly;
  final String? foodType;
  final bool? isFrozen;
  final ValueChanged<_SearchFilterValues> onApply;

  @override
  State<_SearchFilterSheet> createState() => _SearchFilterSheetState();
}

class _SearchFilterSheetState extends State<_SearchFilterSheet> {
  String selectedType = 'All';
  String selectedSort = 'Recommended';
  String? categoryId;
  String? sellerId;
  String? societyId;
  String? availabilityStatus;
  String? foodType;
  bool? isFree;
  bool? inStockOnly;
  bool? sponsoredOnly;
  bool? isFrozen;
  double? minRating;
  late final TextEditingController minPriceController;
  late final TextEditingController maxPriceController;

  final types = const ['All', 'Products', 'Food', 'Services', 'Sellers'];

  final sorts = const [
    'Recommended',
    'Price: Low to High',
    'Price: High to Low',
    'Rating',
    'Newest',
    'Popular',
  ];

  @override
  void initState() {
    super.initState();
    categoryId = widget.categoryId;
    sellerId = widget.sellerId;
    societyId = widget.societyId;
    availabilityStatus = widget.availabilityStatus;
    foodType = widget.foodType;
    isFree = widget.isFree;
    inStockOnly = widget.inStockOnly;
    sponsoredOnly = widget.sponsoredOnly;
    isFrozen = widget.isFrozen;
    minRating = widget.minRating;
    minPriceController = TextEditingController(text: widget.minPrice?.toString() ?? '');
    maxPriceController = TextEditingController(text: widget.maxPrice?.toString() ?? '');
    selectedType = switch (widget.listingType) {
      'PRODUCT' => 'Products',
      'FOOD' => 'Food',
      'SERVICE' => 'Services',
      _ => 'All',
    };
    selectedSort = switch (widget.sortBy) {
      'price_asc' => 'Price: Low to High',
      'price_desc' => 'Price: High to Low',
      'rating_desc' => 'Rating',
      _ => 'Recommended',
    };
  }

  @override
  void dispose() {
    minPriceController.dispose();
    maxPriceController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return SafeArea(
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Refine your search',
                style: theme.textTheme.titleLarge?.copyWith(
                  color: AppColors.ink,
                  fontWeight: FontWeight.w800,
                  letterSpacing: -0.4,
                ),
              ),
              Text(
                'Filter results',
                style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700),
              ),

              const Gap(24),

              Text(
                'Show',
                style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
              ),

              const Gap(10),

              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: types.map((type) {
                  return _FilterChip(
                    label: type,
                    selected: selectedType == type,
                    onTap: () {
                      setState(() {
                        selectedType = type;
                      });
                    },
                  );
                }).toList(),
              ),

              const Gap(18),
              Text(
                'Category',
                style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
              ),
              const Gap(8),
              DropdownButtonFormField<String?>(
                initialValue: categoryId,
                isExpanded: true,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                ),
                hint: const Text('All categories'),
                items: [
                  const DropdownMenuItem<String?>(value: null, child: Text('All categories')),
                  ..._flattenCategories(widget.categories).map(
                    (category) => DropdownMenuItem(value: category.id, child: Text(category.name)),
                  ),
                ],
                onChanged: (value) => setState(() => categoryId = value),
              ),

              const Gap(16),
              Text(
                'Society',
                style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
              ),
              const Gap(8),
              DropdownButtonFormField<String?>(
                initialValue: societyId,
                isExpanded: true,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                ),
                hint: const Text('Platform-wide'),
                items: const [
                  DropdownMenuItem<String?>(value: null, child: Text('Platform-wide')),
                  DropdownMenuItem<String?>(
                    value: 'ACTIVE_LOCATION',
                    child: Text('Use active location'),
                  ),
                ],
                onChanged: (value) => setState(() => societyId = value),
              ),

              const Gap(16),
              Text(
                'Price range',
                style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
              ),
              const Gap(8),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: minPriceController,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: const InputDecoration(
                        labelText: 'Min price',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  const Gap(12),
                  Expanded(
                    child: TextField(
                      controller: maxPriceController,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: const InputDecoration(
                        labelText: 'Max price',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                ],
              ),

              const Gap(16),
              Text(
                'Minimum rating',
                style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
              ),
              Slider(
                value: minRating ?? 0,
                min: 0,
                max: 5,
                divisions: 10,
                label: (minRating ?? 0) == 0 ? 'Any' : minRating!.toStringAsFixed(1),
                onChanged: (value) => setState(() => minRating = value == 0 ? null : value),
              ),

              const Gap(8),
              Text(
                'Availability',
                style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
              ),
              Wrap(
                spacing: 8,
                children: [
                  for (final option in <String?>[null, 'AVAILABLE', 'UNAVAILABLE'])
                    _FilterChip(
                      label: option ?? 'Any',
                      selected: availabilityStatus == option,
                      onTap: () => setState(() => availabilityStatus = option),
                    ),
                ],
              ),

              const Gap(8),
              Text(
                'Food type',
                style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
              ),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final option in <String?>[null, 'VEG', 'NON_VEG', 'VEGAN', 'JAIN', 'OTHER'])
                    _FilterChip(
                      label: option?.replaceAll('_', ' ') ?? 'Any',
                      selected: foodType == option,
                      onTap: () => setState(() => foodType = option),
                    ),
                ],
              ),

              const Gap(8),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Free listings'),
                value: isFree ?? false,
                onChanged: (value) => setState(() => isFree = value ? true : null),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('In stock only'),
                value: inStockOnly ?? false,
                onChanged: (value) => setState(() => inStockOnly = value ? true : null),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Sponsored only'),
                value: sponsoredOnly ?? false,
                onChanged: (value) => setState(() => sponsoredOnly = value ? true : null),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Frozen food'),
                value: isFrozen ?? false,
                onChanged: (value) => setState(() => isFrozen = value ? true : null),
              ),

              const Gap(16),
              Text(
                'Seller',
                style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
              ),
              const Gap(8),
              DropdownButtonFormField<String?>(
                initialValue: sellerId,
                isExpanded: true,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                ),
                hint: const Text('All sellers'),
                items: [
                  const DropdownMenuItem<String?>(value: null, child: Text('All sellers')),
                  ...widget.sellers.map(
                    (seller) => DropdownMenuItem(
                      value: seller.id,
                      child: Text(seller.businessName ?? seller.displayName),
                    ),
                  ),
                ],
                onChanged: (value) => setState(() => sellerId = value),
              ),

              const Gap(22),

              Text(
                'Sort by',
                style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
              ),

              const Gap(10),

              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: sorts.map((sort) {
                  return _FilterChip(
                    label: sort,
                    selected: selectedSort == sort,
                    onTap: () {
                      setState(() {
                        selectedSort = sort;
                      });
                    },
                  );
                }).toList(),
              ),

              const Gap(24),

              SizedBox(
                width: double.infinity,
                height: 50,
                child: FilledButton(
                  onPressed: () {
                    widget.onApply(
                      _SearchFilterValues(
                        societyId: societyId,
                        categoryId: categoryId,
                        sellerId: sellerId,
                        listingType: switch (selectedType) {
                          'Products' => 'PRODUCT',
                          'Food' => 'FOOD',
                          'Services' => 'SERVICE',
                          _ => null,
                        },
                        minPrice: double.tryParse(minPriceController.text),
                        maxPrice: double.tryParse(maxPriceController.text),
                        isFree: isFree,
                        minRating: minRating,
                        availabilityStatus: availabilityStatus,
                        inStockOnly: inStockOnly,
                        sponsoredOnly: sponsoredOnly,
                        foodType: foodType,
                        isFrozen: isFrozen,
                        sortBy: switch (selectedSort) {
                          'Price: Low to High' => 'price_asc',
                          'Price: High to Low' => 'price_desc',
                          'Rating' => 'rating_desc',
                          'Newest' => 'newest',
                          'Popular' => 'popular',
                          _ => 'relevance',
                        },
                      ),
                    );
                    Navigator.of(context).pop();
                  },
                  style: FilledButton.styleFrom(
                    backgroundColor: AppColors.green,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                  child: const Text('Apply filters'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

List<ShopCategory> _flattenCategories(List<ShopCategory> categories) => [
  for (final category in categories) ...[category, ..._flattenCategories(category.subCategories)],
];

class _SearchFilterValues {
  const _SearchFilterValues({
    required this.societyId,
    required this.categoryId,
    required this.sellerId,
    required this.listingType,
    required this.minPrice,
    required this.maxPrice,
    required this.isFree,
    required this.minRating,
    required this.availabilityStatus,
    required this.inStockOnly,
    required this.sponsoredOnly,
    required this.foodType,
    required this.isFrozen,
    required this.sortBy,
  });
  final String? societyId;
  final String? categoryId;
  final String? sellerId;
  final String? listingType;
  final double? minPrice;
  final double? maxPrice;
  final bool? isFree;
  final double? minRating;
  final String? availabilityStatus;
  final bool? inStockOnly;
  final bool? sponsoredOnly;
  final String? foodType;
  final bool? isFrozen;
  final String? sortBy;
}

class _FilterChip extends StatelessWidget {
  const _FilterChip({required this.label, required this.selected, required this.onTap});

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: selected ? AppColors.greenSoft : Colors.white,
      borderRadius: BorderRadius.circular(13),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(13),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(13),
            border: Border.all(color: selected ? AppColors.green : AppColors.border),
          ),
          child: Text(
            label,
            style: TextStyle(
              color: selected ? AppColors.green : AppColors.ink,
              fontSize: 13,
              fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
            ),
          ),
        ),
      ),
    );
  }
}

class _SearchSectionHeader extends StatelessWidget {
  const _SearchSectionHeader({required this.title, this.actionText, this.onAction});

  final String title;
  final String? actionText;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Row(
      children: [
        Expanded(
          child: Text(
            title,
            style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
          ),
        ),
        if (actionText != null) TextButton(onPressed: onAction, child: Text(actionText!)),
      ],
    );
  }
}
