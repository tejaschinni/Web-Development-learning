import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/features/shop/data/models/shop_checkout_models.dart';
import 'package:society_seva/features/shop/domain/entities/service_booking_selection.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_cart_provider.dart';

import 'shop_checkout_screen.dart';
import 'shop_order_placed_screen.dart';

class ShopCheckoutConfirmationScreen extends ConsumerStatefulWidget {
  final ShopCheckoutSubmission submission;

  const ShopCheckoutConfirmationScreen({super.key, required this.submission});

  @override
  ConsumerState<ShopCheckoutConfirmationScreen> createState() =>
      _ShopCheckoutConfirmationScreenState();
}

class _ShopCheckoutConfirmationScreenState extends ConsumerState<ShopCheckoutConfirmationScreen> {
  late ShopCheckoutData _checkout;

  PaymentMethod _paymentMethod = PaymentMethod.cashOnDelivery;
  ShopOrderResult? _createdOrder;
  ShopPaymentResult? _createdPayment;
  bool _isPlacingOrder = false;

  @override
  void initState() {
    super.initState();
    final submission = widget.submission;
    final cart = submission.cart;
    _checkout = ShopCheckoutData(
      sellerGroups: [
        ShopCheckoutSellerGroup(
          sellerId: cart.sellerId,
          sellerName: cart.sellerName.isNotEmpty ? cart.sellerName : 'Seller',
          items: cart.items
              .map(
                (item) => ShopCheckoutItem(
                  id: item.id,
                  name: item.listingName,
                  variant: null,
                  price: item.unitPriceSnapshot,
                  quantity: item.quantity,
                  isFood: item.isFood,
                ),
              )
              .toList(),
          fulfillmentMethod: submission.fulfillmentMethod,
          location: submission.fulfillmentDetail,
        ),
      ],
      subtotal: cart.subtotal,
      tax: 0,
      serviceCharge: 0,
      platformCharge: 0,
      welfareFund: 0,
      fulfillmentCharges: 0,
    );
  }

  void _selectPaymentMethod(PaymentMethod method) {
    setState(() {
      _paymentMethod = method;
    });
  }

  Future<void> _confirmOrder() async {
    if (_isPlacingOrder || _paymentMethod != PaymentMethod.cashOnDelivery) return;

    setState(() {
      _isPlacingOrder = true;
    });

    try {
      final api = ref.read(shopCheckoutRemoteDataSourceProvider);
      final order =
          _createdOrder ??
          await api.checkoutOrder(
            cartId: widget.submission.cart.id,
            fulfillmentMethod: widget.submission.fulfillmentMethod.apiValue,
            deliveryAddressId: widget.submission.deliveryAddressId,
            scheduledAt: widget.submission.scheduledAt,
            buyerNote: widget.submission.buyerNote,
          );
      if (_createdOrder == null && mounted) setState(() => _createdOrder = order);

      final createdPayment = _createdPayment ?? await api.createCashPayment(orderId: order.id);
      if (mounted) setState(() => _createdPayment = createdPayment);

      var payment = createdPayment;
      try {
        payment = await api.getPayment(createdPayment.id);
        if (mounted) setState(() => _createdPayment = payment);
      } catch (_) {
        payment = createdPayment;
      }

      if (!mounted) return;
      final submission = widget.submission;
      final createdAt = DateTime.tryParse(order.createdAt ?? '')?.toLocal();
      context.go(
        '/shop/order-placed',
        extra: ShopOrderPlacedData(
          checkoutId: order.orderNumber.isNotEmpty ? order.orderNumber : order.id,
          createdAtLabel: createdAt == null
              ? 'just now'
              : MaterialLocalizations.of(context).formatMediumDate(createdAt),
          sellerOrders: [
            ShopSellerOrderPlaced(
              orderId: order.id,
              sellerId: order.sellerId,
              sellerName: submission.cart.sellerName.isNotEmpty
                  ? submission.cart.sellerName
                  : 'Seller',
              itemCount: order.items.fold(0, (sum, item) => sum + item.quantity),
              total: order.totalAmount,
              fulfillmentLabel: submission.fulfillmentMethod.title,
              fulfillmentDetail: submission.fulfillmentDetail,
              statusLabel: order.orderStatus,
            ),
          ],
          totalAmount: order.totalAmount,
          paymentMethodLabel: 'Cash',
          paymentStatusLabel: payment.paymentStatus,
        ),
      );
    } catch (error) {
      if (mounted) {
        final message = _createdOrder == null
            ? 'Unable to place your order: $error'
            : 'Order ${_createdOrder!.orderNumber} was created, but cash payment could not be initialized. Try again.';
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
      }
    } finally {
      if (mounted) {
        setState(() {
          _isPlacingOrder = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Theme(
      data: theme.copyWith(textTheme: GoogleFonts.hindTextTheme(theme.textTheme)),
      child: Scaffold(
        backgroundColor: theme.colorScheme.surface,
        appBar: _buildAppBar(context),
        body: SafeArea(
          child: Column(
            children: [
              Expanded(
                child: CustomScrollView(
                  physics: const BouncingScrollPhysics(),
                  slivers: [
                    SliverToBoxAdapter(child: _buildCheckoutHeader(context)),
                    if (widget.submission.serviceBookingSelection case final selection?)
                      SliverToBoxAdapter(child: _buildServiceBookingSummary(context, selection)),
                    SliverPadding(
                      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                      sliver: SliverList.separated(
                        itemCount: _checkout.sellerGroups.length,
                        separatorBuilder: (_, _) => const Gap(14),
                        itemBuilder: (context, index) {
                          return _SellerOrderReviewCard(group: _checkout.sellerGroups[index]);
                        },
                      ),
                    ),
                    SliverToBoxAdapter(child: _buildPaymentSection(context)),
                    SliverToBoxAdapter(child: _buildBillSummary(context)),
                    SliverToBoxAdapter(child: _buildImportantInformation(context)),
                    const SliverToBoxAdapter(child: Gap(120)),
                  ],
                ),
              ),
              _buildBottomBar(context),
            ],
          ),
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context) {
    final theme = Theme.of(context);

    return AppBar(
      elevation: 0,
      scrolledUnderElevation: 0,
      backgroundColor: theme.colorScheme.surface,
      leading: IconButton(
        onPressed: _isPlacingOrder ? null : () => Navigator.of(context).maybePop(),
        icon: HugeIcon(
          icon: HugeIcons.strokeRoundedArrowLeft01,
          size: 24,
          color: theme.colorScheme.onSurface,
        ),
      ),
      titleSpacing: 0,
      title: Text(
        'Checkout',
        style: GoogleFonts.hind(
          fontSize: 22,
          fontWeight: FontWeight.w700,
          color: theme.colorScheme.onSurface,
        ),
      ),
    );
  }

  Widget _buildCheckoutHeader(BuildContext context) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: theme.colorScheme.surfaceContainerLow,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: theme.colorScheme.outlineVariant),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: theme.colorScheme.primaryContainer,
                borderRadius: BorderRadius.circular(12),
              ),
              child: HugeIcon(
                icon: HugeIcons.strokeRoundedCheckmarkCircle02,
                size: 21,
                color: theme.colorScheme.primary,
              ),
            ),
            const Gap(12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Review your order',
                    style: GoogleFonts.hind(
                      fontSize: 17,
                      fontWeight: FontWeight.w800,
                      color: theme.colorScheme.onSurface,
                    ),
                  ),
                  const Gap(3),
                  Text(
                    'Check your items, fulfillment and payment '
                    'before placing the order.',
                    style: GoogleFonts.hind(
                      fontSize: 13,
                      height: 1.4,
                      fontWeight: FontWeight.w500,
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildServiceBookingSummary(BuildContext context, ServiceBookingSelection selection) {
    final theme = Theme.of(context);
    final start = selection.scheduledAt.toLocal();
    final end = selection.endsAt.toLocal();
    final date = MaterialLocalizations.of(context).formatMediumDate(start);
    final time =
        '${TimeOfDay.fromDateTime(start).format(context)} - '
        '${TimeOfDay.fromDateTime(end).format(context)}';

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: theme.colorScheme.secondaryContainer.withValues(alpha: 0.45),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Service appointment', style: GoogleFonts.hind(fontWeight: FontWeight.w700)),
            const Gap(4),
            Text(selection.serviceName, style: GoogleFonts.hind(fontWeight: FontWeight.w600)),
            Text('$date · $time', style: GoogleFonts.hind(fontSize: 13)),
            Text(
              '${selection.locationTitle} · ${selection.locationSubtitle}',
              style: GoogleFonts.hind(fontSize: 13, color: theme.colorScheme.onSurfaceVariant),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPaymentSection(BuildContext context) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      child: Container(
        decoration: BoxDecoration(
          color: theme.colorScheme.surface,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: theme.colorScheme.outlineVariant),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
              child: Text(
                'Payment method',
                style: GoogleFonts.hind(
                  fontSize: 17,
                  fontWeight: FontWeight.w800,
                  color: theme.colorScheme.onSurface,
                ),
              ),
            ),
            _PaymentOption(
              method: PaymentMethod.cashOnDelivery,
              selected: _paymentMethod == PaymentMethod.cashOnDelivery,
              onTap: () {
                _selectPaymentMethod(PaymentMethod.cashOnDelivery);
              },
            ),
            _PaymentOption(
              method: PaymentMethod.wallet,
              selected: _paymentMethod == PaymentMethod.wallet,
              enabled: false,
              disabledReason: 'Unavailable',
              onTap: () {},
            ),
            _PaymentOption(
              method: PaymentMethod.upi,
              selected: _paymentMethod == PaymentMethod.upi,
              enabled: false,
              disabledReason: 'Coming soon',
              onTap: () {},
            ),
            _PaymentOption(
              method: PaymentMethod.card,
              selected: _paymentMethod == PaymentMethod.card,
              enabled: false,
              disabledReason: 'Coming soon',
              onTap: () {},
            ),
            const Gap(7),
          ],
        ),
      ),
    );
  }

  Widget _buildBillSummary(BuildContext context) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: theme.colorScheme.surfaceContainerLow,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: theme.colorScheme.outlineVariant),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Bill summary',
              style: GoogleFonts.hind(
                fontSize: 18,
                fontWeight: FontWeight.w800,
                color: theme.colorScheme.onSurface,
              ),
            ),
            const Gap(14),
            _CheckoutPriceRow(label: 'Item subtotal', value: _formatPrice(_checkout.subtotal)),
            const Padding(padding: EdgeInsets.symmetric(vertical: 14), child: Divider(height: 1)),
            _CheckoutPriceRow(label: 'Total', value: _formatPrice(_checkout.total), isTotal: true),
          ],
        ),
      ),
    );
  }

  Widget _buildImportantInformation(BuildContext context) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      child: Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: theme.colorScheme.surfaceContainerLow,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            HugeIcon(
              icon: HugeIcons.strokeRoundedInformationCircle,
              size: 19,
              color: theme.colorScheme.onSurfaceVariant,
            ),
            const Gap(9),
            Expanded(
              child: Text(
                'Prices and availability are verified again when '
                'the order is placed. Your cart may be split into '
                'separate orders for each seller.',
                style: GoogleFonts.hind(
                  fontSize: 12,
                  height: 1.45,
                  fontWeight: FontWeight.w500,
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBottomBar(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        border: Border(top: BorderSide(color: theme.colorScheme.outlineVariant)),
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Total',
                    style: GoogleFonts.hind(
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                  const Gap(1),
                  Text(
                    _formatPrice(_checkout.total),
                    style: GoogleFonts.hind(
                      fontSize: 21,
                      fontWeight: FontWeight.w800,
                      color: theme.colorScheme.onSurface,
                    ),
                  ),
                ],
              ),
            ),
            const Gap(14),
            FilledButton(
              onPressed: _isPlacingOrder ? null : _confirmOrder,
              style: FilledButton.styleFrom(
                minimumSize: const Size(0, 52),
                padding: const EdgeInsets.symmetric(horizontal: 20),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              ),
              child: _isPlacingOrder
                  ? SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.2,
                        color: theme.colorScheme.onPrimary,
                      ),
                    )
                  : Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          'Place order',
                          style: GoogleFonts.hind(fontSize: 15, fontWeight: FontWeight.w700),
                        ),
                        const Gap(8),
                        HugeIcon(
                          icon: HugeIcons.strokeRoundedArrowRight01,
                          size: 19,
                          color: theme.colorScheme.onPrimary,
                        ),
                      ],
                    ),
            ),
          ],
        ),
      ),
    );
  }

  String _formatPrice(double value) {
    return '₹${value.toStringAsFixed(value % 1 == 0 ? 0 : 2)}';
  }
}

class _SellerOrderReviewCard extends StatelessWidget {
  final ShopCheckoutSellerGroup group;

  const _SellerOrderReviewCard({required this.group});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: theme.colorScheme.outlineVariant),
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 13),
            child: Row(
              children: [
                Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(
                    color: theme.colorScheme.surfaceContainerHighest,
                    borderRadius: BorderRadius.circular(11),
                  ),
                  child: HugeIcon(
                    icon: HugeIcons.strokeRoundedStore01,
                    size: 20,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
                const Gap(11),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        group.sellerName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.hind(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                          color: theme.colorScheme.onSurface,
                        ),
                      ),
                      Text(
                        '${group.items.length} ${group.items.length == 1 ? 'item' : 'items'}',
                        style: GoogleFonts.hind(
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Divider(height: 1, color: theme.colorScheme.outlineVariant),
          ...group.items.map((item) => _CheckoutItemRow(item: item)),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 15),
            child: _FulfillmentSummary(method: group.fulfillmentMethod, location: group.location),
          ),
        ],
      ),
    );
  }
}

class _CheckoutItemRow extends StatelessWidget {
  final ShopCheckoutItem item;

  const _CheckoutItemRow({required this.item});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 13, 16, 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 62,
            height: 62,
            decoration: BoxDecoration(
              color: theme.colorScheme.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(12),
            ),
            child: HugeIcon(
              icon: item.isFood
                  ? HugeIcons.strokeRoundedRestaurant02
                  : HugeIcons.strokeRoundedImage01,
              size: 25,
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          const Gap(11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.name,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.hind(
                    fontSize: 14,
                    height: 1.25,
                    fontWeight: FontWeight.w700,
                    color: theme.colorScheme.onSurface,
                  ),
                ),
                if (item.variant != null) ...[
                  const Gap(2),
                  Text(
                    item.variant!,
                    style: GoogleFonts.hind(
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
                const Gap(5),
                Text(
                  'Qty ${item.quantity}',
                  style: GoogleFonts.hind(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
          const Gap(8),
          Text(
            '₹${(item.price * item.quantity).toStringAsFixed(0)}',
            style: GoogleFonts.hind(
              fontSize: 14,
              fontWeight: FontWeight.w800,
              color: theme.colorScheme.onSurface,
            ),
          ),
        ],
      ),
    );
  }
}

class _FulfillmentSummary extends StatelessWidget {
  final FulfillmentMethod method;
  final String location;

  const _FulfillmentSummary({required this.method, required this.location});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.all(11),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerLow,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          HugeIcon(icon: method.icon, size: 18, color: theme.colorScheme.primary),
          const Gap(8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  method.title,
                  style: GoogleFonts.hind(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: theme.colorScheme.onSurface,
                  ),
                ),
                const Gap(1),
                Text(
                  location,
                  style: GoogleFonts.hind(
                    fontSize: 11,
                    height: 1.3,
                    fontWeight: FontWeight.w500,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PaymentOption extends StatelessWidget {
  final PaymentMethod method;
  final bool selected;
  final bool enabled;
  final String? disabledReason;
  final VoidCallback onTap;

  const _PaymentOption({
    required this.method,
    required this.selected,
    required this.onTap,
    this.enabled = true,
    this.disabledReason,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    final titleColor = enabled ? theme.colorScheme.onSurface : theme.colorScheme.onSurfaceVariant;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: enabled ? onTap : null,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(
            children: [
              _RadioIndicator(selected: selected, enabled: enabled),
              const Gap(11),
              HugeIcon(
                icon: method.icon,
                size: 20,
                color: enabled ? theme.colorScheme.onSurfaceVariant : theme.colorScheme.outline,
              ),
              const Gap(10),
              Expanded(
                child: Text(
                  method.title,
                  style: GoogleFonts.hind(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: titleColor,
                  ),
                ),
              ),
              if (disabledReason != null)
                Text(
                  disabledReason!,
                  style: GoogleFonts.hind(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _RadioIndicator extends StatelessWidget {
  final bool selected;
  final bool enabled;

  const _RadioIndicator({required this.selected, required this.enabled});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      width: 21,
      height: 21,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(
          color: !enabled
              ? theme.colorScheme.outline
              : selected
              ? theme.colorScheme.primary
              : theme.colorScheme.outline,
          width: selected ? 6 : 1.5,
        ),
      ),
    );
  }
}

enum PaymentMethod { cashOnDelivery, wallet, upi, card }

extension PaymentMethodX on PaymentMethod {
  String get title {
    switch (this) {
      case PaymentMethod.cashOnDelivery:
        return 'Cash on delivery';
      case PaymentMethod.wallet:
        return 'Society Seva Wallet';
      case PaymentMethod.upi:
        return 'UPI';
      case PaymentMethod.card:
        return 'Credit / Debit Card';
    }
  }

  dynamic get icon {
    switch (this) {
      case PaymentMethod.cashOnDelivery:
        return HugeIcons.strokeRoundedMoney03;
      case PaymentMethod.wallet:
        return HugeIcons.strokeRoundedWallet01;
      case PaymentMethod.upi:
        return HugeIcons.strokeRoundedQrCode;
      case PaymentMethod.card:
        return HugeIcons.strokeRoundedCreditCard;
    }
  }
}

class ShopCheckoutData {
  final List<ShopCheckoutSellerGroup> sellerGroups;
  final double subtotal;
  final double tax;
  final double serviceCharge;
  final double platformCharge;
  final double welfareFund;
  final double fulfillmentCharges;

  const ShopCheckoutData({
    required this.sellerGroups,
    required this.subtotal,
    required this.tax,
    required this.serviceCharge,
    required this.platformCharge,
    required this.welfareFund,
    required this.fulfillmentCharges,
  });

  double get total =>
      subtotal + tax + serviceCharge + platformCharge + welfareFund + fulfillmentCharges;
}

class ShopCheckoutSellerGroup {
  final String sellerId;
  final String sellerName;
  final List<ShopCheckoutItem> items;
  final FulfillmentMethod fulfillmentMethod;
  final String location;

  const ShopCheckoutSellerGroup({
    required this.sellerId,
    required this.sellerName,
    required this.items,
    required this.fulfillmentMethod,
    required this.location,
  });
}

class ShopCheckoutItem {
  final String id;
  final String name;
  final String? variant;
  final double price;
  final int quantity;
  final bool isFood;

  const ShopCheckoutItem({
    required this.id,
    required this.name,
    required this.variant,
    required this.price,
    required this.quantity,
    required this.isFood,
  });
}

class ShopCheckoutMockData {
  static const data = ShopCheckoutData(
    sellerGroups: [
      ShopCheckoutSellerGroup(
        sellerId: 'seller_sagar',
        sellerName: "Sagar's Kitchen",
        items: [
          ShopCheckoutItem(
            id: 'item_1',
            name: 'Paneer Butter Masala',
            variant: 'Half · Serves 1',
            price: 180,
            quantity: 1,
            isFood: true,
          ),
          ShopCheckoutItem(
            id: 'item_2',
            name: 'Butter Naan',
            variant: '2 pieces',
            price: 60,
            quantity: 1,
            isFood: true,
          ),
        ],
        fulfillmentMethod: FulfillmentMethod.deliverToMyFlat,
        location: 'Flat B-1204',
      ),
      ShopCheckoutSellerGroup(
        sellerId: 'seller_neha',
        sellerName: "Neha's Bakery",
        items: [
          ShopCheckoutItem(
            id: 'item_3',
            name: 'Chocolate Truffle Cake',
            variant: '500 g',
            price: 420,
            quantity: 1,
            isFood: true,
          ),
        ],
        fulfillmentMethod: FulfillmentMethod.pickupFromSeller,
        location: 'Pickup from Neha’s Bakery',
      ),
    ],
    subtotal: 660,
    tax: 33,
    serviceCharge: 13.20,
    platformCharge: 6.60,
    welfareFund: 13.20,
    fulfillmentCharges: 0,
  );
}

class _CheckoutPriceRow extends StatelessWidget {
  final String label;
  final String value;
  final bool isTotal;

  const _CheckoutPriceRow({required this.label, required this.value, this.isTotal = false});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Row(
      children: [
        Expanded(
          child: Text(
            label,
            style: GoogleFonts.hind(
              fontSize: isTotal ? 15 : 13,
              fontWeight: isTotal ? FontWeight.w700 : FontWeight.w500,
              color: isTotal ? theme.colorScheme.onSurface : theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ),
        Text(
          value,
          style: GoogleFonts.hind(
            fontSize: isTotal ? 17 : 13,
            fontWeight: isTotal ? FontWeight.w800 : FontWeight.w600,
            color: theme.colorScheme.onSurface,
          ),
        ),
      ],
    );
  }
}
