import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:society_seva/app/theme/app_theme.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:society_seva/features/seller/presentation/provider/seller_onboarding_provider.dart';
import 'package:society_seva/features/shop/data/models/shop_product.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing_details.dart';
import 'package:society_seva/features/shop/domain/enums/shop_listing_type.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_listing_provider.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_cart_provider.dart';
import 'package:society_seva/features/shop/presentation/widgets/category/shop_cart_actions.dart';
import 'package:society_seva/features/shop/presentation/widgets/product_details/circle_button.dart';
import 'package:society_seva/features/shop/presentation/widgets/product_details/quantity_selector.dart';

class ProductDetailsScreen extends ConsumerStatefulWidget {
  const ProductDetailsScreen({super.key, required this.productId, required this.listing});

  final String productId;
  final ShopListing? listing;

  @override
  ConsumerState<ProductDetailsScreen> createState() => _ProductDetailsScreenState();
}

class _ProductDetailsScreenState extends ConsumerState<ProductDetailsScreen> {
  int _quantity = 1;
  bool _isDescriptionExpanded = false;
  ShopFoodServingSize? _selectedServingSize;

  ShopProduct get _product =>
      ShopProduct(listing: widget.listing!, servingSize: _selectedServingSize);

  final PageController _imagePageController = PageController();
  int _currentImagePage = 0;

  @override
  void dispose() {
    _imagePageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final textTheme = GoogleFonts.hindTextTheme(theme.textTheme);
    final cart = ref.watch(shopCartProvider).valueOrNull;
    final listing = widget.listing;
    if (listing == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Product details')),
        body: const Center(child: Text('Listing details are unavailable')),
      );
    }

    final imagesAsync = ref.watch(shopListingImagesProvider(widget.productId));
    final foodDetailsAsync = listing.listingType == ShopListingType.food
        ? ref.watch(shopFoodDetailsProvider(widget.productId))
        : null;
    final foodDetails = foodDetailsAsync?.valueOrNull;
    final imageUrls =
        imagesAsync.valueOrNull
            ?.where((image) => image.moderationStatus.toUpperCase() == 'APPROVED')
            .map((image) => image.imageUrl)
            .where((url) => url.trim().isNotEmpty)
            .toList() ??
        <String>[];
    final availableServingSizes = foodDetails?.servingSizes
        .where((size) => size.isAvailable && size.quantityAvailable > 0)
        .toList();
    final hasServingSizes = foodDetails?.servingSizes.isNotEmpty == true;
    final selectedServingSize = availableServingSizes
        ?.where((size) => size.id == _selectedServingSize?.id)
        .firstOrNull;
    final maxQuantity = listing.listingType == ShopListingType.food
        ? selectedServingSize?.quantityAvailable ?? listing.quantityAvailable
        : listing.quantityAvailable;
    final hasValidServingSelection = !hasServingSizes || selectedServingSize != null;
    final canAddToCart =
        listing.isAvailable &&
        listing.isApproved &&
        (listing.listingType != ShopListingType.food ||
            foodDetails != null && hasValidServingSelection) &&
        (maxQuantity == null || _quantity <= maxQuantity);

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(child: _buildTopBar(context, cart?.itemCount ?? 0)),

            SliverToBoxAdapter(child: _buildProductImage(context, imageUrls)),

            SliverToBoxAdapter(child: _buildProductInformation(context, textTheme)),

            if (listing.listingType == ShopListingType.food)
              SliverToBoxAdapter(
                child: foodDetails == null
                    ? foodDetailsAsync!.when(
                        loading: () => const Padding(
                          padding: EdgeInsets.all(20),
                          child: Center(child: CircularProgressIndicator()),
                        ),
                        error: (error, stackTrace) => TextButton.icon(
                          onPressed: () =>
                              ref.invalidate(shopFoodDetailsProvider(widget.productId)),
                          icon: const Icon(Icons.refresh),
                          label: const Text('Unable to load serving sizes. Try again.'),
                        ),
                        data: (_) => const SizedBox.shrink(),
                      )
                    : _buildFoodServingSizes(context, textTheme, foodDetails),
              ),

            SliverToBoxAdapter(child: _buildDivider(context)),

            SliverToBoxAdapter(child: _buildAboutSection(context, textTheme)),

            SliverToBoxAdapter(child: _buildDivider(context)),

            SliverToBoxAdapter(child: _buildSellerSection(context, textTheme)),

            SliverToBoxAdapter(child: _buildDivider(context)),

            SliverToBoxAdapter(child: _buildAvailabilitySection(context, textTheme)),

            const SliverToBoxAdapter(child: Gap(120)),
          ],
        ),
      ),

      bottomNavigationBar: _buildBottomBar(context, textTheme, canAddToCart, maxQuantity),
    );
  }

  // TOP BAR
  Widget _buildTopBar(BuildContext context, int cartItemCount) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
      child: Row(
        children: [
          CircleButton(
            icon: HugeIcons.strokeRoundedArrowLeft01,
            onTap: () {
              Navigator.of(context).pop();
            },
          ),

          const Spacer(),

          CircleButton(
            icon: HugeIcons.strokeRoundedShoppingCart02,
            badgeCount: cartItemCount,
            onTap: () {
              context.push('/shop/cart');
            },
          ),
        ],
      ),
    );
  }

  // PRODUCT IMAGE

  Widget _buildProductImage(BuildContext context, List<String> imageUrls) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        height: 330,
        width: double.infinity,
        decoration: BoxDecoration(
          color: AppColors.bg,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: AppColors.border),
          boxShadow: const [
            BoxShadow(color: AppColors.shadow, blurRadius: 18, offset: Offset(0, 6)),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: Stack(
            children: [
              Positioned.fill(
                child: imageUrls.isEmpty
                    ? _imagePlaceholder(theme)
                    : PageView.builder(
                        controller: _imagePageController,
                        itemCount: imageUrls.length,
                        onPageChanged: (index) {
                          setState(() => _currentImagePage = index);
                        },
                        itemBuilder: (context, index) {
                          return GestureDetector(
                            onTap: () => _openFullScreenGallery(context, imageUrls, index),
                            child: Image.network(
                              imageUrls[index],
                              fit: BoxFit.cover,
                              width: double.infinity,
                              errorBuilder: (context, error, stackTrace) =>
                                  _imagePlaceholder(theme),
                            ),
                          );
                        },
                      ),
              ),

              if (imageUrls.length > 1)
                Positioned(
                  bottom: 12,
                  left: 0,
                  right: 0,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(
                      imageUrls.length,
                      (index) => AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        margin: const EdgeInsets.symmetric(horizontal: 3),
                        width: _currentImagePage == index ? 18 : 7,
                        height: 7,
                        decoration: BoxDecoration(
                          color: _currentImagePage == index
                              ? AppColors.green
                              : AppColors.ink.withValues(alpha: 0.5),
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                  ),
                ),

              if (_product.isPopular)
                Positioned(
                  top: 14,
                  left: 14,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
                    decoration: BoxDecoration(
                      color: AppColors.green,
                      borderRadius: BorderRadius.circular(9),
                    ),
                    child: Text(
                      'POPULAR',
                      style: AppTheme.hind(
                        11,
                        w: FontWeight.w800,
                        c: AppColors.surface,
                      ).copyWith(letterSpacing: 0.4),
                    ),
                  ),
                ),

              if (_product.isVeg)
                Positioned(
                  right: 14,
                  top: 14,
                  child: Container(
                    height: 25,
                    width: 25,
                    padding: const EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(7),
                    ),
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: AppColors.green, width: 1.5),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  void _openFullScreenGallery(BuildContext context, List<String> imageUrls, int initialIndex) {
    if (imageUrls.isEmpty) return;

    final pageController = PageController(initialPage: initialIndex);
    showDialog<void>(
      context: context,
      barrierColor: Colors.black,
      builder: (dialogContext) {
        var currentPage = initialIndex;

        return StatefulBuilder(
          builder: (context, setDialogState) {
            return Dialog.fullscreen(
              backgroundColor: Colors.black,
              child: Stack(
                children: [
                  PageView.builder(
                    controller: pageController,
                    itemCount: imageUrls.length,
                    onPageChanged: (index) {
                      setDialogState(() => currentPage = index);
                      if (mounted) {
                        setState(() => _currentImagePage = index);
                      }
                    },
                    itemBuilder: (context, index) {
                      return Center(
                        child: InteractiveViewer(
                          minScale: 1,
                          maxScale: 4,
                          panEnabled: true,
                          scaleEnabled: true,
                          child: Image.network(
                            imageUrls[index],
                            fit: BoxFit.contain,
                            width: MediaQuery.sizeOf(context).width,
                            height: MediaQuery.sizeOf(context).height,
                            errorBuilder: (context, error, stackTrace) => const Center(
                              child: Icon(
                                Icons.broken_image_outlined,
                                color: Colors.white70,
                                size: 48,
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                  Positioned(
                    top: MediaQuery.paddingOf(context).top + 12,
                    left: 16,
                    child: IconButton(
                      onPressed: () => Navigator.of(dialogContext).pop(),
                      style: IconButton.styleFrom(
                        backgroundColor: Colors.black54,
                        foregroundColor: Colors.white,
                      ),
                      icon: const Icon(Icons.close),
                      tooltip: 'Close image viewer',
                    ),
                  ),
                  if (imageUrls.length > 1)
                    Positioned(
                      top: MediaQuery.paddingOf(context).top + 22,
                      right: 20,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: Colors.black54,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          '${currentPage + 1} / ${imageUrls.length}',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                  if (imageUrls.length > 1)
                    Positioned(
                      bottom: MediaQuery.paddingOf(context).bottom + 24,
                      left: 0,
                      right: 0,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(
                          imageUrls.length,
                          (index) => AnimatedContainer(
                            duration: const Duration(milliseconds: 180),
                            margin: const EdgeInsets.symmetric(horizontal: 3),
                            width: currentPage == index ? 18 : 7,
                            height: 7,
                            decoration: BoxDecoration(
                              color: currentPage == index ? Colors.white : Colors.white54,
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            );
          },
        );
      },
    ).whenComplete(pageController.dispose);
  }

  Widget _imagePlaceholder(ThemeData theme) {
    return Container(
      color: AppColors.bg,
      child: Center(
        child: HugeIcon(
          icon: HugeIcons.strokeRoundedImage01,
          size: 64,
          color: AppColors.muted.withValues(alpha: 0.35),
        ),
      ),
    );
  }

  Widget _buildFoodServingSizes(
    BuildContext context,
    TextTheme textTheme,
    ShopFoodDetails details,
  ) {
    final sizes = details.servingSizes
        .where((size) => size.isAvailable && size.quantityAvailable > 0)
        .toList();

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Choose a serving size',
            style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800),
          ),
          const Gap(8),
          if (sizes.isEmpty)
            Text('No serving sizes are currently available', style: textTheme.bodyMedium)
          else
            ...sizes.map(
              (size) => RadioGroup(
                groupValue: _selectedServingSize?.id,
                onChanged: (id) {
                  if (id == null) return;
                  setState(() {
                    _selectedServingSize = sizes.firstWhere((item) => item.id == id);
                  });
                },
                child: RadioListTile<String>(
                  value: size.id,
                  contentPadding: EdgeInsets.zero,
                  title: Text(size.description),
                  subtitle: Text('${size.quantityAvailable} available'),
                  secondary: Text(
                    '₹${size.price.toStringAsFixed(0)}',
                    style: AppTheme.display(16, w: FontWeight.w800, c: AppColors.ink),
                  ),
                  activeColor: AppColors.green,
                ),
              ),
            ),
          if (details.spiceLevelText.isNotEmpty || details.freshnessDeclaration.isNotEmpty)
            Text(
              [
                details.spiceLevelText,
                details.freshnessDeclaration,
              ].where((value) => value.isNotEmpty).join(' · '),
              style: textTheme.bodySmall?.copyWith(color: AppColors.muted),
            ),
        ],
      ),
    );
  }

  // PRODUCT INFORMATION
  Widget _buildProductInformation(BuildContext context, TextTheme textTheme) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _product.name,
            style: AppTheme.display(25, w: FontWeight.w800, c: AppColors.ink, h: 1.1),
          ),

          const Gap(5),

          Text(
            _product.variant,
            style: textTheme.bodyMedium?.copyWith(
              color: AppColors.muted,
              fontWeight: FontWeight.w500,
            ),
          ),

          const Gap(13),

          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                decoration: BoxDecoration(
                  color: AppColors.greenSoft,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    HugeIcon(
                      icon: HugeIcons.strokeRoundedStar,
                      size: 15,
                      color: AppColors.greenDeep,
                    ),
                    const Gap(4),
                    Text(
                      _product.rating.toStringAsFixed(1),
                      style: textTheme.labelLarge?.copyWith(
                        fontWeight: FontWeight.w800,
                        color: AppColors.greenDeep,
                      ),
                    ),
                  ],
                ),
              ),

              const Gap(8),

              Text(
                '${_product.reviewCount} reviews',
                style: textTheme.bodyMedium?.copyWith(
                  color: AppColors.muted,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),

          const Gap(17),

          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '₹${_product.price.toStringAsFixed(0)}',
                style: AppTheme.display(25, w: FontWeight.w800, c: AppColors.ink),
              ),

              if (_product.originalPrice != null) ...[
                const Gap(9),
                Padding(
                  padding: const EdgeInsets.only(bottom: 3),
                  child: Text(
                    '₹${_product.originalPrice}',
                    style: textTheme.bodyMedium?.copyWith(
                      decoration: TextDecoration.lineThrough,
                      color: AppColors.muted,
                    ),
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }

  // ABOUT
  Widget _buildAboutSection(BuildContext context, TextTheme textTheme) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'About this item',
            style: textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w800,
              color: AppColors.ink,
            ),
          ),

          const Gap(8),

          AnimatedCrossFade(
            duration: const Duration(milliseconds: 180),
            crossFadeState: _isDescriptionExpanded
                ? CrossFadeState.showSecond
                : CrossFadeState.showFirst,
            firstChild: Text(
              _product.description,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              style: textTheme.bodyMedium?.copyWith(color: AppColors.muted, height: 1.45),
            ),
            secondChild: Text(
              _product.description,
              style: textTheme.bodyMedium?.copyWith(color: AppColors.muted, height: 1.45),
            ),
          ),

          if (_product.description.length > 120)
            Padding(
              padding: const EdgeInsets.only(top: 5),
              child: GestureDetector(
                onTap: () {
                  setState(() {
                    _isDescriptionExpanded = !_isDescriptionExpanded;
                  });
                },
                child: Text(
                  _isDescriptionExpanded ? 'Show less' : 'Read more',
                  style: textTheme.labelLarge?.copyWith(
                    color: AppColors.green,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  // SELLER
  Widget _buildSellerSection(BuildContext context, TextTheme textTheme) {
    final seller = ref.watch(sellerProfileByIdProvider(_product.sellerId)).valueOrNull;
    final sellerName = seller?.displayName.trim().isNotEmpty == true
        ? seller!.displayName
        : _product.sellerName;
    final sellerRating = seller?.averageRating ?? _product.sellerRating;
    final sellerReviewCount = seller?.totalReviews ?? _product.sellerReviewCount;

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      child: Material(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: () => context.push('/shop/seller/${_product.sellerId}'),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: AppColors.border),
              boxShadow: const [
                BoxShadow(color: AppColors.shadow, blurRadius: 12, offset: Offset(0, 3)),
              ],
            ),
            child: Row(
              children: [
                Container(
                  height: 54,
                  width: 54,
                  decoration: BoxDecoration(
                    color: AppColors.greenSoft,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: HugeIcon(
                    icon: HugeIcons.strokeRoundedStore01,
                    size: 26,
                    color: AppColors.green,
                  ),
                ),

                const Gap(12),

                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Flexible(
                            child: Text(
                              sellerName,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800),
                            ),
                          ),
                          const Gap(5),
                          HugeIcon(
                            icon: HugeIcons.strokeRoundedCheckmarkCircle02,
                            size: 16,
                            color: AppColors.green,
                          ),
                        ],
                      ),

                      const Gap(2),

                      Row(
                        children: [
                          HugeIcon(
                            icon: HugeIcons.strokeRoundedStar,
                            size: 14,
                            color: AppColors.green,
                          ),
                          const Gap(3),
                          Text(
                            '${sellerRating.toStringAsFixed(1)} · $sellerReviewCount reviews',
                            style: textTheme.bodySmall?.copyWith(color: AppColors.muted),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                HugeIcon(
                  icon: HugeIcons.strokeRoundedArrowRight01,
                  size: 20,
                  color: AppColors.muted,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // AVAILABILITY
  Widget _buildAvailabilitySection(BuildContext context, TextTheme textTheme) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 18),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.greenSoft,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            Container(
              height: 38,
              width: 38,
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(11),
              ),
              child: Center(
                child: HugeIcon(
                  icon: HugeIcons.strokeRoundedLocation01,
                  size: 19,
                  color: AppColors.green,
                ),
              ),
            ),

            const Gap(11),

            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Available in your society',
                    style: textTheme.labelLarge?.copyWith(fontWeight: FontWeight.w800),
                  ),
                  const Gap(1),
                  Text(
                    'Delivery to your registered flat',
                    style: textTheme.bodySmall?.copyWith(color: AppColors.muted),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // BOTTOM BAR
  Widget _buildBottomBar(
    BuildContext context,
    TextTheme textTheme,
    bool canAddToCart,
    int? maxQuantity,
  ) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: const Border(top: BorderSide(color: AppColors.border)),
        boxShadow: const [
          BoxShadow(color: AppColors.shadow, blurRadius: 14, offset: Offset(0, -4)),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 11, 16, 10),
          child: Row(
            children: [
              QuantitySelector(
                quantity: _quantity,
                onDecrease: () {
                  if (_quantity > 1) {
                    setState(() {
                      _quantity--;
                    });
                  }
                },
                onIncrease: () {
                  if (maxQuantity != null && _quantity >= maxQuantity) return;
                  setState(() {
                    _quantity++;
                  });
                },
              ),

              const Gap(12),

              Expanded(
                child: SizedBox(
                  height: 50,
                  child: FilledButton(
                    onPressed: canAddToCart ? _addToCart : null,
                    style: FilledButton.styleFrom(
                      backgroundColor: AppColors.green,
                      foregroundColor: AppColors.surface,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                    child: Text(
                      'ADD TO CART • ₹${(_product.price * _quantity).toStringAsFixed(0)}',
                      style: textTheme.labelLarge?.copyWith(
                        fontWeight: FontWeight.w800,
                        color: AppColors.surface,
                        letterSpacing: 0.15,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _addToCart() async {
    await addListingToCart(
      context,
      ref,
      widget.listing!,
      quantity: _quantity,
      servingSize: _selectedServingSize,
    );
  }

  Widget _buildDivider(BuildContext context) {
    return Divider(height: 1, thickness: 1, color: AppColors.border.withValues(alpha: 0.45));
  }
}
