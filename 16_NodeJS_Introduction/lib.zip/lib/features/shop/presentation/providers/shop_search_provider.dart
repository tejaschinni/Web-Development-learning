import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing.dart';
import 'package:society_seva/features/shop/domain/entities/shop_seller.dart';
import 'package:society_seva/features/shop/domain/entities/shop_category.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_listing_provider.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_seller_provider.dart';
import 'package:society_seva/features/shop/presentation/providers/shop_category_provider.dart';
import 'package:society_seva/features/location/presentation/providers/location_provider.dart';

final activeSearchSocietyIdProvider = Provider<String?>((ref) {
  return ref.watch(locationContextProvider).valueOrNull?.activeAddress?.id;
});

final shopSearchListingsProvider = FutureProvider.family<PageResponse<ShopListing>, ShopSearchFilter>((ref, filter) {
  return ref.watch(shopListingRepositoryProvider).searchListings(
    query: filter.query,
    categoryId: filter.categoryId,
    societyId: filter.societyId == 'ACTIVE_LOCATION' ? ref.watch(activeSearchSocietyIdProvider) : filter.societyId,
    sellerId: filter.sellerId,
    listingType: filter.listingType,
    minPrice: filter.minPrice,
    maxPrice: filter.maxPrice,
    isFree: filter.isFree,
    minRating: filter.minRating,
    availabilityStatus: filter.availabilityStatus,
    inStockOnly: filter.inStockOnly,
    sponsoredOnly: filter.sponsoredOnly,
    foodType: filter.foodType,
    isFrozen: filter.isFrozen,
    sortBy: filter.sortBy,
    pageable: const PageableQuery(page: 0, size: 20),
  );
});

final shopCategoriesForSearchProvider = FutureProvider<List<ShopCategory>>((ref) async {
  return ref.watch(shopCategoryRepositoryProvider).getCategories();
});

final shopRecentSearchesProvider = FutureProvider<List<String>>((ref) {
  return ref.watch(shopListingRepositoryProvider).getRecentSearches();
});

final shopSearchSellersProvider = FutureProvider<List<ShopSeller>>((ref) async {
  final page = await ref.watch(shopSellerRepositoryProvider).getSellers(
    societyId: '',
    pageable: const PageableQuery(page: 0, size: 100),
  );
  return page.content;
});

class ShopSearchFilter {
  const ShopSearchFilter({required this.query, this.societyId, this.categoryId, this.sellerId, this.listingType, this.minPrice, this.maxPrice, this.isFree, this.minRating, this.availabilityStatus, this.inStockOnly, this.sponsoredOnly, this.foodType, this.isFrozen, this.sortBy});
  final String query;
  final String? societyId;
  final String? categoryId;
  final String? sellerId;
  final String? listingType;
  final double? minPrice;
  final double? maxPrice;
  final bool? isFree;
  final double? minRating;
  final String? availabilityStatus;
  final bool? inStockOnly;
  final bool? sponsoredOnly;
  final String? foodType;
  final bool? isFrozen;
  final String? sortBy;

  @override
  bool operator ==(Object other) => other is ShopSearchFilter && query == other.query && societyId == other.societyId && categoryId == other.categoryId && sellerId == other.sellerId && listingType == other.listingType && minPrice == other.minPrice && maxPrice == other.maxPrice && isFree == other.isFree && minRating == other.minRating && availabilityStatus == other.availabilityStatus && inStockOnly == other.inStockOnly && sponsoredOnly == other.sponsoredOnly && foodType == other.foodType && isFrozen == other.isFrozen && sortBy == other.sortBy;
  @override
  int get hashCode => Object.hash(query, societyId, categoryId, sellerId, listingType, minPrice, maxPrice, isFree, minRating, availabilityStatus, inStockOnly, sponsoredOnly, foodType, isFrozen, sortBy);
}
