import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/core/network/page_response.dart';
import 'package:society_seva/features/guest/data/models/guest_session.dart';
import 'package:society_seva/features/shop/domain/entities/shop_listing.dart';

class GuestRemoteDataSource {
  const GuestRemoteDataSource({required this.apiClient});

  final ApiClient apiClient;

  Future<GuestSession> startSession(GuestSessionRequest request) async {
    final response = await apiClient.post(ApiEndpoints.guestSession, data: request.toJson());
    return GuestSession.fromJson(Map<String, dynamic>.from(response.data as Map));
  }

  Future<PageResponse<ShopListing>> getListings({
    String? societyId,
    String? query,
    String? categoryId,
    String? listingType,
    required PageableQuery pageable,
  }) async {
    final response = await apiClient.get(
      ApiEndpoints.guestListings,
      queryParameters: {
        if (societyId != null && societyId.isNotEmpty) 'societyId': societyId,
        if (query != null && query.isNotEmpty) 'query': query,
        if (categoryId != null && categoryId.isNotEmpty) 'categoryId': categoryId,
        if (listingType != null && listingType.isNotEmpty) 'listingType': listingType,
        ...pageable.toQueryParameters(),
      },
    );
    return PageResponse.fromJson(Map<String, dynamic>.from(response.data as Map), _listingFromJson);
  }

  Future<ShopListing> getListing(String listingId) async {
    final response = await apiClient.get(ApiEndpoints.guestListing(listingId));
    return _listingFromJson(Map<String, dynamic>.from(response.data as Map));
  }

  Future<List<ShopListing>> getTrending({String? societyId, int limit = 10}) async {
    final response = await apiClient.get(
      ApiEndpoints.guestTrending,
      queryParameters: {
        if (societyId != null && societyId.isNotEmpty) 'societyId': societyId,
        'limit': limit,
      },
    );
    final data = response.data;
    if (data is! List) return const [];
    return data.whereType<Map>().map((entry) {
      final listing = entry['listing'];
      return _listingFromJson(Map<String, dynamic>.from(listing is Map ? listing : entry));
    }).toList();
  }

  Future<void> recordSearch({
    required String searchQuery,
    String? category,
    double? latitude,
    double? longitude,
    required int resultCount,
  }) async {
    await apiClient.post(
      ApiEndpoints.guestSearchActivity,
      data: {
        'searchQuery': searchQuery,
        'category': category,
        'latitude': latitude,
        'longitude': longitude,
        'resultCount': resultCount,
      },
    );
  }

  Future<void> recordView({required String listingId, required bool isTrending}) async {
    await apiClient.post(
      ApiEndpoints.guestViewActivity,
      data: {'listingId': listingId, 'isTrending': isTrending},
    );
  }

  static ShopListing _listingFromJson(Map<String, dynamic> json) {
    return ShopListing.fromJson({
      ...json,
      'id': json['listingId'] ?? json['id'],
      'title': json['title'] ?? json['name'],
      'approvalStatus': json['approvalStatus'] ?? 'APPROVED',
      'availabilityStatus': json['availabilityStatus'] ?? 'AVAILABLE',
    });
  }
}
