import 'package:society_seva/core/network/api_client.dart';
import 'package:society_seva/core/network/api_endpoints.dart';
import 'package:society_seva/core/network/api_exception.dart';
import 'package:society_seva/features/system/data/models/system_health_model.dart';

abstract class SystemRepository {
  Future<SystemHealth> getHealth();
}

class SystemRepositoryImpl implements SystemRepository {
  SystemRepositoryImpl(this._apiClient);

  final ApiClient _apiClient;

  @override
  Future<SystemHealth> getHealth() async {
    try {
      final response = await _apiClient.get(ApiEndpoints.health);
      if (response.data is Map<String, dynamic>) {
        return SystemHealth.fromJson(response.data as Map<String, dynamic>);
      }
      throw const ApiException(message: 'Unexpected health response format.');
    } on ApiException {
      rethrow;
    }
  }
}
