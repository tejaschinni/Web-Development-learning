import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:society_seva/app/app.dart';
import 'package:society_seva/core/config/app_config.dart';
import 'package:society_seva/core/storage/local_cache.dart';
import 'package:society_seva/core/storage/secure_storage.dart';
import 'package:society_seva/features/profile/presentation/providers/user_mode_provider.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await dotenv.load(fileName: '.env', isOptional: true);
  await LocalCache.instance.initialize();

  final config = AppConfig.environmentFor(null);
  final savedMode = await AppSecureStorage().readUserMode();
  final initialMode = UserMode.values.firstWhere(
    (m) => m.name == savedMode,
    orElse: () => UserMode.user,
  );

  runApp(SocietySevaApp(config: config, initialMode: initialMode));
}
